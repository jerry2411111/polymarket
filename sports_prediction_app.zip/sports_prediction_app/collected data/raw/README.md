# Retain source evidence

Keep original responses here when running collectors. Preserve source timestamps and identifiers so model inputs and historical quotes can be verified.
