# Use research tables

Build dated game, player, team and weather tables before generating model features. Use `data collecting/query_sql.py` from the project root for SQL queries. Keep dashboard storage persistent to retain saved purchase amounts.
