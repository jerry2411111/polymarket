"""Publish one odds interface per provider; keep pooled soccer performance intact."""
import ast,datetime as dt,hashlib,json,re,sqlite3
from pathlib import Path
from build_history_catalog import DB
from probe_history import ROOT
from league_odds import source_table,refresh_views,export_provider,COMMON_PRE,COMMON_INGAME,SOCCER_LEAGUES

def patch_collectors():
    folder=ROOT/'data collecting'
    skip={'eu_schema.py','league_odds.py','unify_game_leagues.py','generate_data_catalog.py',
          'catalog_render.py','verify_missing_data.py','record_supporting_gaps.py'}
    us_writers={'build_history_odds.py','build_mlb_odds.py','build_nhl_odds.py','build_eu_odds.py',
                'apply_odds_eligibility.py','season_labels.py'}
    changed=[]
    for path in folder.glob('*.py'):
        if path.name in skip:continue
        old=s=path.read_text(encoding='utf-8-sig')
        for provider in ['polymarket','kalshi']:
            for kind in ['pre_match','in_game']:
                s=s.replace(provider+'_eu_soccer_'+kind,source_table(provider,kind,True))
        s=re.sub(r"\b(provider|p)\+'_eu_soccer_(pre_match|in_game)'",r"'_source_'+\1+'_soccer_\2'",s)
        s=re.sub(r"\b(provider|p)\+'_eu_soccer_'\+kind",r"'_source_'+\1+'_soccer_'+kind",s)
        if path.name in us_writers:
            s=re.sub(r"\b(provider|p)\+'_'\+(kind|k)\b",r"'_source_'+\1+'_us_'+\2",s)
            s=s.replace('{p}_{kind}', '_source_{p}_us_{kind}')
        if path.name in us_writers or path.name in {'build_epl_odds.py'}:
            s=re.sub(r'export\(([^\n;]+?),rows,(columns|cols)\)',r'export(\1,rows,\2,db=db)',s)
        if path.name=='validate_requested_revision.py':
            s=s.replace("  assert not any(r['name'].startswith('draw_') for r in db.execute('PRAGMA table_info('+table+')'));checks['no_artificial_draw_columns']+=1",
                "  drawcols=[r['name'] for r in db.execute('PRAGMA table_info('+table+')') if r['name'].startswith('draw_')]\n  assert not db.execute('SELECT 1 FROM '+table+\" WHERE game_type<>'Soccer' AND (\"+' OR '.join(c+' IS NOT NULL' for c in drawcols)+') LIMIT 1').fetchone();checks['no_artificial_draw_values']+=1")
        if s!=old:
            ast.parse(s,filename=path.name);path.write_text(s,encoding='utf-8');changed.append(path.name)
    return changed

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    assert not db.execute('SELECT 1 FROM sqlite_master WHERE name=?',(source_table('polymarket','pre_match'),)).fetchone(), 'Already migrated'
    expected={}; before={}
    for provider in ['polymarket','kalshi']:
        for kind,cols in [('pre_match',COMMON_PRE),('in_game',COMMON_INGAME)]:
            rows=[]
            for soccer in [False,True]:
                name=provider+('_eu_soccer_' if soccer else '_')+kind
                for r in db.execute('SELECT * FROM '+name):
                    row=dict(r)
                    if soccer:row['league']='La Liga' if row['competition']=='LaLiga' else row['competition']
                    rows.append({c:row.get(c) for c in cols})
            expected[provider,kind]=sorted(rows,key=lambda r:r['game_id'])
            before[provider+'_'+kind]=len(rows)
    with db:
        for provider in ['polymarket','kalshi']:
            for kind in ['pre_match','in_game']:
                for soccer in [False,True]:
                    old=provider+('_eu_soccer_' if soccer else '_')+kind
                    db.execute('ALTER TABLE '+old+' RENAME TO '+source_table(provider,kind,soccer))
        refresh_views(db)
        for (provider,kind),wanted in expected.items():
            actual=[dict(r) for r in db.execute('SELECT * FROM '+provider+'_'+kind+' ORDER BY game_id')]
            assert actual==wanted,(provider,kind,'A value changed beyond the league/schema mapping')
            assert len({r['game_id'] for r in actual})==len(actual)
        assert {r[0] for r in db.execute("SELECT DISTINCT league FROM main WHERE game_type='Soccer'")}==set(SOCCER_LEAGUES)
    exports={}
    for provider in ['polymarket','kalshi']:
        for kind in ['pre_match','in_game']:exports[provider+'_'+kind]=export_provider(db,provider,kind)
    removed=[]
    for provider in ['polymarket','kalshi']:
        folder=ROOT/'data/result/eu_soccer'/provider
        for kind in ['pre_match','in_game']:
            for ext in ['.csv','.parquet']:
                path=(folder/(kind+ext)).resolve()
                assert path.is_relative_to(ROOT.resolve())
                if path.exists():path.unlink();removed.append(str(path.relative_to(ROOT)))
        if folder.exists() and not any(folder.iterdir()):folder.rmdir()
    changed=patch_collectors()
    counts=[dict(r) for r in db.execute('SELECT league,count(DISTINCT game_id) AS games FROM main GROUP BY league ORDER BY league')]
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PASS',game_counts=counts,
        before_provider_rows=before,after_provider_rows=exports,all_existing_odds_scores_times_ids_exactly_preserved=True,
        soccer_performance='Unchanged; combined across all six competitions by user instruction.',
        output_tables=['polymarket_pre_match','kalshi_pre_match','polymarket_in_game','kalshi_in_game'],
        league_values=SOCCER_LEAGUES,removed_duplicate_export_files=removed,updated_collector_files=changed)
    (ROOT/'reports/game_league_schema_revision.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    db.close();print(json.dumps(report),flush=True)

if __name__=='__main__':main()
