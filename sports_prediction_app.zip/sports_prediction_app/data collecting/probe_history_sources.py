import json,re
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT
URLS=['https://www.salaryswish.com/coaches/history','https://www.nhl.com/utah/news/utah-s-nhl-franchise-officially-named-the-utah-mammoth-release-5-7-25','https://www.mlb.com/athletics/news/a-s-break-ground-on-new-las-vegas-stadium']
def main():
 c=HistoryClient()
 for url in URLS:
  try:
   b,r=c.get(url,document=True);s=BeautifulSoup(b,'html.parser')
   if url.endswith('coaches/history'):
    for table in s.find_all('table'):
     print('COACH TABLE',[[x.get_text(' ',strip=True) for x in tr.find_all(['th','td'],recursive=False)] for tr in table.find_all('tr')[:6]])
    links=sorted({a['href'] for a in s.select('a[href*="/staff/"]')});print('STAFF LINKS',links)
  except Exception as e:print('SOURCE ERROR',url,str(e))
if __name__=='__main__':main()
