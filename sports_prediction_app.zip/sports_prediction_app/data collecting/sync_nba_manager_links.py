"""Link verified NBA head coaches to existing t-1 profiles using canonical IDs."""
import collections
import datetime as dt
import hashlib
import json
import sqlite3
from build_history_catalog import DB
from probe_history import ROOT


def sync(db):
    before = db.execute("SELECT game_id,manager_id,as_of_date FROM game_manager_profiles WHERE game_id LIKE 'NBA_%' ORDER BY 1,2,3").fetchall()
    facts = db.execute("SELECT manager_id,game_id,game_date,team_name FROM _manager_game_results WHERE league='NBA' ORDER BY game_id,manager_id").fetchall()
    profiles = {(pid, day): team for pid, day, team in db.execute("SELECT manager_id,as_of_date,team FROM manager_profiles WHERE league='NBA'")}
    targets, missing = [], []
    for pid, gid, game_date, team in facts:
        prior = (dt.date.fromisoformat(game_date) - dt.timedelta(days=1)).isoformat()
        if profiles.get((pid, prior)) == team:
            assert db.execute('SELECT 1 FROM _nba_manager_game_audit WHERE manager_id=? AND game_id=?', (pid, gid)).fetchone()
            targets.append((gid, pid, prior))
        else:
            missing.append(dict(game_id=gid, manager_id=pid, as_of_date=prior, reason='No matching-team profile for this coach on t-1'))
    assert len(targets) == len(set(targets))
    target_set = set(targets)
    removed = [tuple(row) for row in before if tuple(row) not in target_set]
    now = dt.datetime.now(dt.UTC).isoformat()
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _replaced_profile_links (entity TEXT,game_id TEXT,person_id TEXT,as_of_date TEXT,reason TEXT,recorded_at_utc TEXT,PRIMARY KEY(entity,game_id,person_id,as_of_date)) STRICT')
        db.executemany('INSERT OR IGNORE INTO _replaced_profile_links VALUES (?,?,?,?,?,?)',
                       [('manager', gid, pid, day, 'Superseded noncanonical sample link; reconstructed from verified NBA coach/game facts and an existing t-1 profile', now) for gid, pid, day in removed])
        db.execute("DELETE FROM game_manager_profiles WHERE game_id LIKE 'NBA_%'")
        db.executemany('INSERT INTO game_manager_profiles VALUES (?,?,?)', targets)
    actual = db.execute("SELECT game_id,manager_id,as_of_date FROM game_manager_profiles WHERE game_id LIKE 'NBA_%' ORDER BY 1,2,3").fetchall()
    assert [tuple(r) for r in actual] == sorted(targets)
    assert not db.execute("PRAGMA foreign_key_check('game_manager_profiles')").fetchall()
    team_games = db.execute("SELECT count(*) FROM _team_game_results WHERE league='NBA'").fetchone()[0]
    return dict(generated_at_utc=now, status='WORKING', coverage_status='PARTIALLY WORKING',
                previously_linked=len(before), linked=len(targets), replaced_legacy_links=removed,
                verified_coach_game_facts=len(facts), team_games=team_games,
                unattributed_team_games=team_games-len(facts), missing_prior_profiles=missing,
                source='Previously verified official-identity NBA coach/game audit plus matching-team dated profiles.',
                limitation='Head coach of record, not a claim of physical presence at every game. Missing or temporary-team assignments are not inferred.')


if __name__ == '__main__':
    db = sqlite3.connect(DB, timeout=60)
    out = sync(db)
    (ROOT/'reports/nba_manager_links_validation.json').write_text(json.dumps(out, indent=2), encoding='utf-8')
    print(json.dumps({k:v for k,v in out.items() if k!='missing_prior_profiles'}), flush=True)
    print('Missing prior profiles', len(out['missing_prior_profiles']), flush=True)
    db.close()
