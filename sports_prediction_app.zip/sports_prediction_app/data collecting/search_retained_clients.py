"""Bounded searches across already captured official client code; redact credential literals."""
import argparse,json,re,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

def main():
    p=argparse.ArgumentParser();p.add_argument('host');p.add_argument('pattern');p.add_argument('--per-file',type=int,default=3);p.add_argument('--limit',type=int,default=30);p.add_argument('--width',type=int,default=450);a=p.parse_args();db=sqlite3.connect(DB);rx=re.compile(a.pattern,re.I);n=0
    for rid,m in db.execute("SELECT request_id,metadata_json FROM _request_audit WHERE json_extract(metadata_json,'$.endpoint') LIKE ? AND json_extract(metadata_json,'$.status')=200",('https://'+a.host+'/%',)):
        r=json.loads(m)
        if not re.search(r'\.js(?:\?|$)',r['endpoint']):continue
        text=(ROOT/r['raw_file']).read_text(encoding='utf-8',errors='replace')
        if text.lstrip().lower().startswith('<!doctype html'):continue
        for j,hit in enumerate(rx.finditer(text)):
            if j>=a.per_file:break
            context=text[max(0,hit.start()-100):min(hit.start()+a.width,hit.end()+a.width)].replace('\\"','"');context=re.sub(r'(?i)((?:api[_-]?key|key|token|secret|password)[\w-]*["\x27]?\s*[:=]\s*["\x27])[^"\x27]+',r'\1[redacted]',context);print(json.dumps(dict(request_id=rid,endpoint=r['endpoint'],offset=hit.start(),context=context)));n+=1
            if n>=a.limit:return

if __name__=='__main__':main()
