"""Repair the derived team-map view to use the dated profile source directly."""
import sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB,timeout=60)
kind=db.execute("SELECT type FROM sqlite_master WHERE name='player_current_team'").fetchone()[0]
assert kind=='view'
db.execute('DROP VIEW player_current_team')
db.execute('CREATE VIEW player_current_team AS SELECT player_id,player_name,game_type,league,team AS current_team,as_of_date FROM player_profiles')
assert db.execute("SELECT COUNT(*) FROM player_current_team WHERE league='NBA'").fetchone()[0]==618133
assert db.execute('SELECT COUNT(*) FROM player_current_team').fetchone()[0]==db.execute('SELECT COUNT(*) FROM player_profiles').fetchone()[0]
db.commit();db.close();print('Dated team map repaired and row counts verified')
