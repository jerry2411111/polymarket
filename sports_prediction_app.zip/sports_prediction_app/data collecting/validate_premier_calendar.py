"""Raw equality, local/UTC time conversion, date scope and complete-season team-count validation."""
import collections,datetime as dt,hashlib,json,sqlite3
from zoneinfo import ZoneInfo
from build_history_catalog import DB
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB);cache={};checks=collections.Counter();seasons=collections.defaultdict(list);dates=[]
    for mid,b in db.execute('SELECT * FROM _official_epl_calendar'):
        r=json.loads(b);rid=r['request_id']
        if rid not in cache:
            meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);body=(ROOT/meta['raw_file']).read_bytes();assert hashlib.sha256(body).hexdigest()==meta['sha256'];cache[rid]=json.loads(body);checks['source_sha256']+=1
        raw=cache[rid]['data'][int(r['pointer'].rsplit('/',1)[-1])];assert raw==r['raw'] and raw['matchId']==mid;assert r['home']==raw['homeTeam'] and r['away']==raw['awayTeam'];assert r['competition_id']==raw['competitionId']=='8';assert r['location']==raw['ground'];checks['raw_calendar_fields']+=1
        local=dt.datetime.fromisoformat(raw['kickoff']).replace(tzinfo=ZoneInfo(raw['kickoffTimezoneString']));assert local.tzname()==raw['kickoffTimezone'] and local.astimezone(dt.UTC).isoformat()==r['scheduled_start_utc'];assert r['date']==local.date().isoformat() and '2024-01-01'<=r['date']<='2026-09-14';checks['timezone_and_scope']+=1
        if r['status']=='FullTime':
            h,a=raw['homeTeam']['score'],raw['awayTeam']['score'];assert r['winner']==('Draw' if h==a else raw['homeTeam']['name'] if h>a else raw['awayTeam']['name']);seasons[r['season']].append(r);dates.append(r['date']);checks['official_score_and_winner']+=1
    summary=[]
    for season,gs in sorted(seasons.items()):
        home=collections.Counter(g['home']['id'] for g in gs);away=collections.Counter(g['away']['id'] for g in gs);pairs=[(g['home']['id'],g['away']['id']) for g in gs];assert len(pairs)==len(set(pairs));complete=season in ['2024-25','2025-26']
        if complete:assert len(gs)==380 and len(home)==len(away)==20 and set(home)==set(away) and all(home[t]==away[t]==19 for t in home);checks['complete_380_game_20_team_season']+=1
        summary.append(dict(season=season,games=len(gs),home_teams=len(home),away_teams=len(away),complete_season=complete,coverage='Full official league season' if complete else 'Only dates inside requested collection window'))
    assert len(seasons['2024-25'])==len(seasons['2025-26'])==380
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',coverage_status='OFFICIAL_CALENDAR_ONLY',checks=dict(checks),completed_games=len(dates),earliest=min(dates),latest=max(dates),seasons=summary,limitations=['These counts include all official Premier League fixtures in the date window, whether or not historical odds exist. Only games with usable odds will enter the main tables.','Other cups and league fixtures incorrectly tagged as EPL cannot join this calendar merely through provider tags.','Scheduled and actual opening times remain separate internally.'])
    (ROOT/'reports/epl_calendar_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
