"""One four-column public request log, with reproducibility details inside SQL."""
import csv,datetime as dt,json,sqlite3
from pathlib import Path
from urllib.parse import urlsplit

DDL='''CREATE TABLE IF NOT EXISTS _request_audit (
 request_number INTEGER PRIMARY KEY,request_id TEXT NOT NULL UNIQUE,
 request_type TEXT NOT NULL,requested_data TEXT NOT NULL,return_status TEXT NOT NULL,
 metadata_json TEXT NOT NULL) STRICT'''

def connect(root):
 path=Path(root)/'data/result/sentinent_snake.sqlite';path.parent.mkdir(parents=True,exist_ok=True)
 db=sqlite3.connect(path,timeout=60);db.execute('PRAGMA busy_timeout=60000');db.execute(DDL);db.commit();return db
def describe(r):
 u=r['endpoint'];path=urlsplit(u).path;p=r.get('parameters',{});provider='Kalshi' if 'kalshi.com' in u else 'Polymarket' if 'polymarket.com' in u else 'NBA' if 'nba.com' in u else 'NOAA' if 'noaa.gov' in u else 'SalarySwish' if 'salaryswish.com' in u else urlsplit(u).hostname
 if '/docs' in u or '/documentation/' in path or path.endswith(('.yaml','.md','openapi.json','api-docs')):kind='API documentation';purpose=path.rstrip('/').rsplit('/',1)[-1]
 elif 'statsapi.mlb.com' in u and path.endswith('/schedule'):kind='Official MLB schedule and scores';purpose='Games on '+str(p.get('date'))
 elif 'statsapi.mlb.com' in u and path.endswith('/transactions'):kind='Official MLB dated player moves';purpose=('Player '+str(p['playerId'])+'; '+str(p.get('startDate'))+' through '+str(p.get('endDate'))) if p.get('playerId') else 'Published transactions on '+str(p.get('date'))
 elif 'statsapi.mlb.com' in u and path.endswith('/coaches'):kind='Official MLB dated manager roster';purpose='Team '+path.split('/teams/')[-1].split('/')[0]+' on '+str(p.get('date'))
 elif 'statsapi.mlb.com' in u and '/game/' in path and path.endswith('/feed/live'):kind='Official MLB game report';purpose='Game '+path.split('/game/')[1].split('/')[0]+'; scores, inning clocks and player statistics'
 elif 'baseballsavant.mlb.com' in u and path=='/gf':kind='Official MLB game statistics';purpose='Game '+str(p.get('game_pk'))
 elif 'api-web.nhle.com' in u and '/schedule/' in path:kind='Official NHL schedule and scores';purpose='Seven-day schedule beginning '+path.rsplit('/',1)[-1]
 elif 'api-web.nhle.com' in u and '/gamecenter/' in path:kind='Official NHL game report';purpose='Game '+path.split('/gamecenter/')[1].split('/')[0]+'; '+path.rsplit('/',1)[-1]
 elif 'api-web.nhle.com' in u and '/v2/player/' in path:kind='Official NHL player history';purpose='Player '+path.split('/v2/player/')[1].replace('/','; ')
 elif 'records.nhl.com' in u and '/site/api/coach' in path:kind='Official NHL coach identity/history';purpose=path.rsplit('/',1)[-1]+'; '+str(p.get('cayenneExp') or 'Native coach career and team records')
 elif 'opendata-download-metobs.smhi.se' in u:kind='Official SMHI weather';purpose=path.removeprefix('/api/version/').replace('/','; ')
 elif 'premier-league-prod.pulselive.com' in u and path.endswith('/v2/matches'):kind='Official Premier League calendar';purpose='Season '+str(p.get('season'))+'; '+urlsplit(u).query.replace('&','; ')
 elif 'premier-league-prod.pulselive.com' in u and '/matches/' in path:kind='Official Premier League game report';purpose='Game '+path.split('/matches/')[1].replace('/','; ')
 elif 'premier-league-prod.pulselive.com' in u and '/players/' in path:kind='Official Premier League player profile/history';purpose=path.split('/players/')[1].replace('/','; ')
 elif 'premier-league-prod.pulselive.com' in u and '/managers/' in path:kind='Official Premier League manager profile/history';purpose=path.split('/managers/')[1].replace('/','; ')
 elif 'firebasedatabase.app' in u and 'bundesliga' in u:kind='Official Bundesliga calendar/results';purpose=path.replace('/all/DFL-COM-000001/','')+'; '+str(p)
 elif 'laliga.com' in u and '/results/' in path:kind='Official LaLiga archive results';purpose=path.split('/results/')[1]
 elif 'ma-api.ligue1.fr' in u:kind='Official Ligue 1 calendar/results';purpose=path.strip('/')+'; season '+str(p.get('season','current'))
 elif 'seriea-api.prd.sdp.deltatre.digital' in u:kind='Official Serie A calendar/results';purpose=path.removeprefix('/v1/serie-a/football/')
 elif 'match.uefa.com' in u:kind='Official UEFA calendar/game report';purpose=path.strip('/')+'; '+str(p.get('fromDate') or p.get('seasonYear') or '')+' through '+str(p.get('toDate') or '')
 elif 'prices-history' in path:kind='Historical prices';purpose='Outcome '+str(p.get('token_id') or p.get('market'))
 elif 'candlesticks' in path:kind='Historical probability quotes';purpose=path.split('/markets/')[-1].replace('/candlesticks','')
 elif 'game_stats' in path:kind='Game play-by-play';purpose=path.split('/milestone/')[-1].replace('/game_stats','')
 elif '/live_data' in path:kind='Game scores';purpose=str(len(p.get('milestone_ids',[])))+' games' if p.get('milestone_ids') else path.rsplit('/',1)[-1]
 elif path.endswith('/milestones'):kind='Game discovery';purpose=str(p.get('competition') or p.get('related_event_ticker') or 'Sports games')
 elif path.endswith('/structured_targets'):kind='Team/player directory';purpose=str(p.get('competition') or '')+' '+str(p.get('type') or '')
 elif path.endswith('/cutoff'):kind='Historical cutoff';purpose='Current archive routing timestamps'
 elif path.endswith(('/events','/markets','/events/keyset','/markets/keyset')):kind='Market discovery';purpose=str(p.get('series_ticker') or p.get('tag_id') or p.get('event_ticker') or 'Event and market metadata')
 elif '/pdfs/' in path:kind='Official game report';purpose=path.rsplit('/',1)[-1]
 elif provider=='NBA' and path=='/games':kind='Official scores and game classification';purpose='Games on '+str(p.get('date'))
 elif '/htmlreports/' in path:kind='Official game report';purpose=path.split('/htmlreports/')[-1]
 elif 'mlb.com/scores/' in u:kind='Official scores and game classification';purpose=path.rsplit('/',1)[-1]
 elif '/players/' in path or '/staff/' in path or '/coaches/' in path:kind='Profile or staff-history source';purpose=path.rsplit('/',1)[-1]
 elif 'ghcnh' in path.lower() or 'noaa.gov' in u:kind='Weather';purpose=path.rsplit('/',1)[-1]
 else:kind='Source verification';purpose=path.rsplit('/',1)[-1]
 for a,b in [('start','end'),('start_ts','end_ts')]:
  if isinstance(p.get(a),int) and isinstance(p.get(b),int):
   purpose+='; '+dt.datetime.fromtimestamp(p[a],dt.UTC).strftime('%Y-%m-%d %H:%M UTC')+' to '+dt.datetime.fromtimestamp(p[b],dt.UTC).strftime('%Y-%m-%d %H:%M UTC');break
 if isinstance(p.get('as_of'),int):purpose+='; at or before '+dt.datetime.fromtimestamp(p['as_of'],dt.UTC).strftime('%Y-%m-%d %H:%M UTC')
 return r.get('method','GET')+' / '+kind,provider+': '+purpose,str(r.get('status')) if r.get('status') is not None else 'PENDING' if r.get('request_state')=='in_flight' else 'INTERRUPTED_STATUS_UNKNOWN' if r.get('request_state')=='interrupted_response_reacquired' else 'NETWORK_ERROR'
def save(db,r):
 typ,purpose,status=describe(r)
 db.execute('INSERT INTO _request_audit(request_id,request_type,requested_data,return_status,metadata_json) VALUES (?,?,?,?,?) ON CONFLICT(request_id) DO UPDATE SET request_type=excluded.request_type,requested_data=excluded.requested_data,return_status=excluded.return_status,metadata_json=excluded.metadata_json',(r['request_id'],typ,purpose,status,json.dumps(r)));db.commit()
def all_records(root):
 root=Path(root);seen=set();path=root/'data/result/sentinent_snake.sqlite'
 if path.exists():
  with sqlite3.connect(path) as db:
   if db.execute("SELECT 1 FROM sqlite_master WHERE name='_request_audit'").fetchone():
    for (s,) in db.execute('SELECT metadata_json FROM _request_audit ORDER BY request_number'):
     r=json.loads(s);seen.add(r['request_id']);yield r
 for log in [root/'data/raw/requests.jsonl',*sorted((root/'data/raw/request_logs').glob('*.jsonl'))]:
  if not log.exists():continue
  text=log.read_text(encoding='utf-8');lines=text.splitlines()
  if text and not text.endswith('\n'):lines=lines[:-1]
  for line in lines:
   if not line.strip():continue
   r=json.loads(line)
   if r['request_id'] not in seen:seen.add(r['request_id']);yield r
def consolidate(root):
 rs=sorted(all_records(root),key=lambda r:(r['requested_at_utc'],r['request_id']));db=connect(root)
 for n,r in enumerate(rs,1):
  typ,purpose,status=describe(r);db.execute('INSERT INTO _request_audit(request_id,request_type,requested_data,return_status,metadata_json) VALUES (?,?,?,?,?) ON CONFLICT(request_id) DO UPDATE SET request_type=excluded.request_type,requested_data=excluded.requested_data,return_status=excluded.return_status',(r['request_id'],typ,purpose,status,json.dumps(r)))
  if n%500==0:db.commit()
 db.commit();export_log(root,db);count=db.execute('SELECT count(*) FROM _request_audit').fetchone()[0];db.close();return count
def export_log(root,db):
 path=Path(root)/'data/raw/requests.csv';tmp=path.with_suffix('.csv.tmp')
 with tmp.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['request_number','request_type','requested_data','return_status']);w.writerows(db.execute('SELECT request_number,request_type,requested_data,return_status FROM _request_audit ORDER BY request_number'))
 tmp.replace(path)
if __name__=='__main__':
 from probe_history import ROOT
 print('Requests in compact log:',consolidate(ROOT))
