"""Document specific provider date errors against authoritative NBA records."""
import json,sqlite3
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from build_history_catalog import DB

def main():
    HOSTS.add('pr.nba.com');client=HistoryClient();url='https://pr.nba.com/heat-bulls-schedule-adjustments/'
    body,release=client.get(url,document=True);text=BeautifulSoup(body,'html.parser').get_text(' ',strip=True)
    for term in ['Jan. 8','Jan. 29','Jan. 30','Jan. 31']:assert term in text
    db=sqlite3.connect(DB,timeout=60);cards=[json.loads(b) for (b,) in db.execute('SELECT body FROM _official_nba_schedule')]
    dates={'NBA_20251217_LAC_OKC':'2025-12-18','NBA_20251217_WAS_SAS':'2025-12-18','NBA_20260108_MIA_CHI':'2026-01-29','NBA_20260130_CHI_MIA':'2026-01-31'};rows=[]
    for gid,date in dates.items():
        g=json.loads(db.execute('SELECT body FROM _history_games WHERE id=?',(gid,)).fetchone()[0]);codes=gid.split('_')[2:4]
        matches=[c for c in cards if c['date']==date and c['team_tricodes']==codes];assert len(matches)==1
        c=matches[0];winner=g['teams'][int(c['scores'][1]>c['scores'][0])]
        assert winner==g['winner'],'Provider winner differs from official result; cannot resolve date identity'
        documented='NBA rescheduling announcement' if gid.startswith('NBA_202601') else 'Official NBA dated final report; provider date is one day earlier'
        rows.append(dict(source_game_id=gid,official_game_id=c['official_game_id'],official_date=date,official_request_id=c['request_id'],official_source_url=c['source_url'],provider_start_utc=g['start'],official_start_utc=c['start_utc'],reason=documented,rescheduling_request_id=release['request_id'] if gid.startswith('NBA_202601') else None,rescheduling_url=url if gid.startswith('NBA_202601') else None,official_scores=c['scores'],official_winner=winner,status='RESOLVED_USING_OFFICIAL_NBA_RECORDS'))
    db.execute('CREATE TABLE IF NOT EXISTS _nba_official_date_corrections (source_game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _nba_official_date_corrections VALUES (?,?)',[(r['source_game_id'],json.dumps(r)) for r in rows]);db.commit();db.close()
    (ROOT/'reports/nba_official_date_corrections.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print('Verified official date corrections:',len(rows),'new requests:',client.requests)

if __name__=='__main__':main()
