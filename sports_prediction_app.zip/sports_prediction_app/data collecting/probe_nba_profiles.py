import json,sqlite3
from build_history_catalog import DB
from collect_nba_profiles import next_data
from history_client import HistoryClient
from probe_history import ROOT

def main():
    c=HistoryClient();results=[]
    for pid,slug in [('101108','chris-paul'),('1642267','bub-carrington'),('27839','lawson-lovering')]:
        url=f'https://www.nba.com/player/{pid}/{slug}'
        try:
            b,r=c.get(url,document=True);p=next_data(b)
            player=p.get('player') or {}
            x=dict(requested_id=pid,url=url,request_id=r['request_id'],keys=list(p),player_keys=list(player),info=player.get('info'),career=player.get('careerStats'))
            print(json.dumps(x)[:12500],flush=True);results.append(x)
        except Exception as e:
            x=dict(requested_id=pid,url=url,error=str(e));results.append(x);print(json.dumps(x),flush=True)
    (ROOT/'reports/nba_profile_schema_probe.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    db=sqlite3.connect(DB)
    for t,where in [('_history_appearances',"json_extract(body,'$.league')='NBA'"),('_official_nba_page_players',"json_extract(body,'$.player_name') LIKE '%Carrington%'"),('_history_players',"json_extract(body,'$.league')='NBA'")]:
        r=db.execute('SELECT body FROM '+t+' WHERE '+where+' LIMIT 1').fetchone();print(t,r[0] if r else None)

if __name__=='__main__':main()
