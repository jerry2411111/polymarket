"""Small public Serie A route probes after reading current official client URL construction."""
import datetime as dt,json
from urllib.parse import quote
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

BASE='https://seriea-api.prd.sdp.deltatre.digital/v1/serie-a/football'
def main():
 HOSTS.add('seriea-api.prd.sdp.deltatre.digital');c=HistoryClient();rows=[];sid='serie-a::Football_Season::ed7fdc2a3e7b408b942ec177b7b956b5';cid='serie-a::Football_Competition::82f03c1de2e74034beedcf0bab51a20d'
 for path in ['/competitions','/competitions/'+quote(cid,safe='')+'/seasons','/seasons/'+quote(sid,safe='')+'/header']:
  url=BASE+path
  try:
   d,r=c.get(url);row=dict(url=url,request_id=r['request_id'],status=r['status'],response_type=type(d).__name__,data=d);print(json.dumps({**row,'data':str(d)[:4000]},ensure_ascii=False),flush=True)
  except Exception as e:row=dict(url=url,error=str(e));print(json.dumps(row),flush=True)
  rows.append(row)
 (ROOT/'reports/seriea_api_pilot.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),client_request_ids=['0797403e005f45618e3ca03ae884cd57','25928899439c43848de5a1d0c8b6e9fd'],public_config_request_id='059621d82b5d4be09902efd8fe55a54a',probes=rows,new_requests=c.requests),indent=2),encoding='utf-8')

if __name__=='__main__':main()
