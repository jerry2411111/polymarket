"""Resolve duplicated UEFA coach IDs against dated official Barcelona evidence."""
import datetime as dt,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS

HOSTS.add('www.fcbarcelona.com');c=HistoryClient();sources=[]
urls=[('profile','https://www.fcbarcelona.com/en/football/first-team/staff/4030694/hansi-flick'),('appointment','https://www.fcbarcelona.com/en/football/first-team/news/4029878/hansi-flick-is-the-new-fc-barcelona-coach'),('renewal_2025','https://www.fcbarcelona.com/en/football/first-team/news/4270507/agreement-for-hansi-flick-contract-extension-to-2027'),('renewal_2026','https://www.fcbarcelona.com/en/football/first-team/news/4505340/hansi-flick-extends-contract-until-2028')]
texts={}
for kind,url in urls:
 raw,r,redirects=get(c,url);soup=BeautifulSoup(raw,'html.parser');text=' '.join(soup.stripped_strings);assert 'Hansi Flick' in text;texts[kind]=text;sources.append(dict(kind=kind,url=url,request_id=r['request_id'],redirects=redirects));print('BARCELONA SOURCE',kind,r['status'],r['request_id'],flush=True)
assert '24/02/1965' in texts['profile'];assert '29 May 24' in texts['appointment'] and '30 June 2026' in texts['appointment'];assert '21 May 25' in texts['renewal_2025'] and '30 June 2027' in texts['renewal_2025'];assert '18 May 26' in texts['renewal_2026'] and '30 June 2028' in texts['renewal_2026']
ids=['EU_LAL_COACH:man52340','EU_UCL_COACH:1123','EU_UCL_COACH:250200261'];db=sqlite3.connect(DB,timeout=60);roles=[]
for pid in ids:
 rs=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_source_manager_game_facts WHERE manager_id=?',(pid,))];assert rs and all(p['manager_name']=='Hansi Flick' and p['team_name']=='FC Barcelona' and p['game_date']>='2024-05-29' for p in rs);roles.extend(dict(source_person_id=pid,game_id=p['game_id'],date=p['game_date'],request_id=p['request_id']) for p in [min(rs,key=lambda p:p['game_date']),max(rs,key=lambda p:p['game_date'])])
review=dict(source_person_ids=ids,person_name='Hansi Flick',birth_date='1965-02-24',team_name='FC Barcelona',sources=sources,dated_role_proofs=roles,reason='Two UEFA IDs have the same official full name and Barcelona head-coach role across consecutive seasons. Official club appointment, renewals and dated lineups establish one continuous person and job; profile supplies constant DOB.')
with db:
 db.execute('CREATE TABLE IF NOT EXISTS _eu_person_alias_reviews (review_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('INSERT OR REPLACE INTO _eu_person_alias_reviews VALUES (?,?)',('hansi_flick_uefa_duplicate_ids',json.dumps(review)))
 db.execute('CREATE TABLE IF NOT EXISTS _eu_manager_appointments (source_person_id TEXT,effective_from TEXT,body TEXT NOT NULL,PRIMARY KEY(source_person_id,effective_from)) STRICT')
 for kind,announced,end in [('appointment','2024-05-29','2026-07-01'),('renewal_2025','2025-05-21','2027-07-01'),('renewal_2026','2026-05-18','2028-07-01')]:
  s=next(s for s in sources if s['kind']==kind);body=dict(source_person_id=ids[1],person_name='Hansi Flick',team_name='FC Barcelona',appointment_date='2024-05-29',known_from=announced,documented_service_end_exclusive=end,request_id=s['request_id'],url=s['url'],reason='Official announcement provides service dates; optional further season excluded');db.execute('INSERT OR REPLACE INTO _eu_manager_appointments VALUES (?,?,?)',(ids[1],announced,json.dumps(body)))
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',review=review,new_requests=c.requests);(ROOT/'reports/flick_identity_history_review.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('FLICK IDENTITY AND DATED APPOINTMENT VERIFIED',len(ids),'source IDs');db.close()
