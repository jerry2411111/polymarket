"""Small public API calls using paths and competition ID read from the official client."""
import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def main():
    HOSTS.add('ma-api.ligue1.fr');client=HistoryClient();rows=[]
    for path in ['/championships-settings','/championship-calendar/1']:
        try:
            d,r=client.get('https://ma-api.ligue1.fr'+path);row=dict(endpoint=r['endpoint'],request_id=r['request_id'],type=type(d).__name__,keys=list(d) if isinstance(d,dict) else None,preview=json.dumps(d,ensure_ascii=False)[:3600]);print(json.dumps(row),flush=True)
        except Exception as e:row=dict(path=path,error=str(e));print(json.dumps(row),flush=True)
        rows.append(row)
    (ROOT/'reports/ligue1_calendar_probes.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=rows,new_requests=client.requests,client_path_request_id='af254f92e4e249d5aaec9ea64113a58d',client_competition_id_request_id='6be0d86a943e4f22b026645c78b5f2f8'),indent=2),encoding='utf-8')

if __name__=='__main__':main()
