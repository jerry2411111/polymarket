"""Preserve an interrupted response with unknown status and reacquire its request."""
import datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT
from request_audit import save

def main():
    db=sqlite3.connect(DB,timeout=60);rid='e364708c4a37404893504b1cd551dd14';old=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);path=ROOT/'data/raw/responses'/(rid+'.json');raw=path.read_bytes();body=json.loads(raw);assert body.get('ticker')=='KXMLBGAME-25JUL05CINPHI-PHI'
    c=HistoryClient();d,r=c.get(old['endpoint'],old['parameters'],refresh=True)
    old.update(request_state='interrupted_response_reacquired',status=None,raw_file=path.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),raw_file_last_modified_utc=dt.datetime.fromtimestamp(path.stat().st_mtime,dt.UTC).isoformat(),reacquired_request_id=r['request_id'],error='Original HTTP status and response headers were not committed because the profile rebuild held the SQLite write lock. The body is preserved; status is not inferred from valid JSON.',response_equal_to_reacquired=body==d)
    save(db,old);db.close();out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),original_request_id=rid,original_http_status=None,reacquired_request_id=r['request_id'],reacquired_http_status=r['status'],raw_equal=body==d,original_raw_preserved=True)
    (ROOT/'reports/mlb_interrupted_request_repair.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))

if __name__=='__main__':main()
