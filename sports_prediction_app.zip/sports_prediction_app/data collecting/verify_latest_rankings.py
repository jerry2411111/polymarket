"""Independently check every daily publisher selection and all cached rank facts."""
import bisect,collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from install_nba_rankings import NAMES
def main():
 db=sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
 start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone();days=[];day=dt.date.fromisoformat(start)
 while day.isoformat()<=end:days.append(day.isoformat());day+=dt.timedelta(days=1)
 excluded={r[0] for r in db.execute('SELECT list_id FROM _ranking_edition_audit WHERE use_for_flags=0')};names={v:k for k,v in NAMES.items()}
 editions=collections.defaultdict(list)
 for r in db.execute('SELECT * FROM ranking_list_versions'):
  if r['list_id'] not in excluded:editions[r['league'],names[r['publisher']]].append(dict(r))
 selections={(r['as_of_date'],r['league'],r['publisher_key']):dict(r) for r in db.execute('SELECT * FROM _ranking_asof_selection')}
 changes=[r[0] for r in db.execute('SELECT as_of_date FROM _ranking_snapshot_dates ORDER BY as_of_date')]
 checks=0;examples=[]
 for day in days:
  chosen_day=changes[bisect.bisect_right(changes,day)-1]
  for (league,pub),es in editions.items():
   eligible=[e for e in es if e['publication_date']<=day and e['version_verified_date']<=day]
   expected=max(eligible,key=lambda e:(e['publication_date'],e['version_verified_date'],e['list_id'])) if eligible else None
   got=selections.get((chosen_day,league,pub))
   assert (got['list_id'] if got else None)==(expected['list_id'] if expected else None),(day,league,pub,got,expected)
   checks+=1
   if expected and day==max(expected['publication_date'],expected['version_verified_date']):examples.append(dict(date=day,league=league,publisher=pub,list_id=expected['list_id'],applies_on_eligible_day=True))
 aliases={(r['source_player_id'],r['league']):r['player_id'] for r in db.execute('SELECT * FROM _player_identity_aliases')}
 facts={(r['list_id'],aliases.get((r['player_id'],r['league']),r['player_id'])):r['rank'] for r in db.execute('SELECT * FROM player_media_rankings')};flagchecks=0
 for r in db.execute('SELECT * FROM _ranking_canonical_cache'):
  for c in r.keys():
   if '_top_' not in c:continue
   pub,n=c.rsplit('_top_',1);s=selections.get((r['as_of_date'],r['league'],pub));rank=facts.get((s['list_id'],r['player_id'])) if s else None
   assert r[c]==(int(rank<=int(n)) if rank is not None else None),(r['as_of_date'],r['player_id'],c)
   flagchecks+=1
 assert not db.execute("SELECT 1 FROM sqlite_master WHERE name='player_rankings_quarterly'").fetchone()
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',daily_publisher_selections_checked=checks,raw_rank_to_cached_flag_checks=flagchecks,examples=examples,failures=0,
  policy='Most recently published eligible edition per publisher. Known revised versions must also be available by the date. Carry until superseded; no future backfill, no quarter delay.')
 (ROOT/'reports/latest_ranking_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='examples'}),flush=True);db.close()
if __name__=='__main__':main()
