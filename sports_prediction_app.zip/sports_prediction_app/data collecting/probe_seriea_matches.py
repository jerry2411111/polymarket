"""Resolve native Serie A season IDs and inspect one small season-calendar response."""
import datetime as dt,json
from urllib.parse import quote
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from probe_seriea_api import BASE

def main():
 HOSTS.add('seriea-api.prd.sdp.deltatre.digital');c=HistoryClient();d,cr=c.get(BASE+'/competitions');cs=[v for v in d['competitions'] if v['name']=='Serie A'];assert len(cs)==1;cid=cs[0]['competitionId'];d,sr=c.get(BASE+'/competitions/'+quote(cid,safe='')+'/seasons');seasons=[s for s in d['seasons'] if s['seasonName'] in ['2023/2024','2024/2025','2025/2026','2026/2027']];assert all(s['competitionId']==cid for s in seasons);print(json.dumps(dict(seasons=seasons),ensure_ascii=False),flush=True);source=next(s for s in seasons if s['seasonName']=='2023/2024');url=BASE+'/seasons/'+quote(source['seasonId'],safe='')+'/matches';out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),competition_request_id=cr['request_id'],seasons_request_id=sr['request_id'],competition=cs[0],seasons=seasons)
 try:
  d,r=c.get(url);out.update(request_id=r['request_id'],endpoint=url,data=d);print(json.dumps(dict(request_id=r['request_id'],keys=list(d) if isinstance(d,dict) else None,counts={k:len(v) for k,v in d.items() if isinstance(v,list)} if isinstance(d,dict) else len(d),example={k:(v[:1] if isinstance(v,list) else v) for k,v in d.items()} if isinstance(d,dict) else d[:1]),ensure_ascii=False),flush=True)
 except Exception as e:out.update(error=str(e));print(json.dumps(dict(error=str(e))),flush=True)
 out['new_requests']=c.requests;(ROOT/'reports/seriea_match_pilot.json').write_text(json.dumps(out,indent=2),encoding='utf-8')

if __name__=='__main__':main()
