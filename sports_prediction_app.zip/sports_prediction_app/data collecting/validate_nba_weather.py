"""Independently reread original NOAA rows and verify game/date/time alignment."""
import collections,datetime as dt,hashlib,io,json,sqlite3,time
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT

def stamp(value):
    if isinstance(value,dt.datetime):return value.replace(tzinfo=dt.UTC) if value.tzinfo is None else value
    s=str(value);d=dt.datetime.fromisoformat(s.replace('Z','+00:00'));return d.replace(tzinfo=dt.UTC) if d.tzinfo is None else d

def main():
    started=time.monotonic();db=sqlite3.connect(DB);db.row_factory=sqlite3.Row
    wanted={r[0] for r in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='NBA' UNION SELECT game_id FROM kalshi_pre_match WHERE league='NBA'")}
    games={gid:json.loads(body) for gid,body in db.execute('SELECT id,body FROM _nba_canonical_games') if gid in wanted}
    links={r['game_id']:dict(r) for r in db.execute("SELECT * FROM _game_weather_links WHERE game_id LIKE 'NBA_%'")};assert set(links)==wanted
    target={}
    for gid,g in games.items():
        l=links[gid];assert (l['city'],l['date'])==(g['city'],g['date'])
        key=l['city'],l['date'];target[key]=min(target.get(key,stamp(g['start'])),stamp(g['start']))
    weather={(r['city'],r['date']):dict(r) for r in db.execute('SELECT * FROM weather')}
    audit={(x['city'],x['date']):x for (b,) in db.execute('SELECT body FROM _weather_observation_audit') if (x:=json.loads(b)) and (x['city'],x['date']) in target}
    assert set(audit)==set(target) and set(target)<=set(weather)
    grouped=collections.defaultdict(list);no_observation=[];examples=[];numeric_checks=0;raw_checks=0
    for key,x in audit.items():
        if x.get('raw'):grouped[x['request_id']].append((key,x))
        else:
            assert all(weather[key][k] is None for k in ['humidity_pct','weather_type','temperature_c','wind_direction'])
            no_observation.append(dict(city=key[0],date=key[1],reason=x.get('reason')))
    for rid,items in grouped.items():
        row=db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone();assert row
        r=json.loads(row[0]);body=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(body).hexdigest()==r['sha256']
        cols=sorted(set(k for _,x in items for k in x['raw']))
        table=pq.read_table(io.BytesIO(body),columns=cols)
        for key,x in items:
            raw=table.slice(x['row_index'],1).to_pylist()[0]
            for k,v in x['raw'].items():assert raw[k]==v,('Raw archive row differs from audit',key,k)
            assert raw['STATION']==x['station_id'],('Station mismatch',key)
            time_utc=stamp(raw['DATE']);assert time_utc==stamp(x['observation_timestamp_utc'])
            assert 0<=(target[key]-time_utc).total_seconds()<=5400,('Future or stale weather',key)
            out=weather[key];assert out==x['normalized']
            for output,source in [('temperature_c','temperature'),('humidity_pct','relative_humidity')]:
                v=out[output]
                if v is not None:assert v==float(raw[source]),('Unit/value mismatch',key,output);numeric_checks+=1
            if out['humidity_pct'] is not None:assert 0<=out['humidity_pct']<=100
            w=out['wind_direction']
            if w=='Variable':assert raw['wind_direction_Measurement_Code']=='V'
            elif w=='Calm':assert float(raw['wind_direction'])==0
            elif w is not None:assert int(w.split()[0])==float(raw['wind_direction']) and 0<=int(w.split()[0])<=360
            raw_checks+=1
            if key[0] in ['Toronto','Macao, China','Berlin','Boston'] and not any(e['city']==key[0] for e in examples):
                examples.append(dict(city=key[0],date=key[1],station_id=x['station_id'],source_url=r['endpoint'],request_id=rid,raw_row_index=x['row_index'],observation_timestamp_utc=time_utc.isoformat(),game_anchor_utc=target[key].isoformat(),raw_values={k:raw.get(k) for k in ['temperature','relative_humidity','wind_direction','sky_condition','sky_condition_Quality_Code']},normalized=out,match=True))
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',coverage='PARTIAL',nba_games=len(games),city_dates=len(target),verified_raw_rows=raw_checks,source_archives=len(grouped),numeric_checks=numeric_checks,no_qualifying_observation=no_observation,missing={k:dict(count=sum(weather[key][k] is None for key in target),total=len(target),percentage=round(100*sum(weather[key][k] is None for key in target)/len(target),4)) for k in ['temperature_c','humidity_pct','weather_type','wind_direction']},examples=examples,elapsed_seconds=round(time.monotonic()-started,2),scope='Outdoor station observations before the first NBA game in the city/date. Correct source and time alignment is distinct from completeness of all weather fields.')
    (ROOT/'reports/nba_weather_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));db.close()

if __name__=='__main__':main()
