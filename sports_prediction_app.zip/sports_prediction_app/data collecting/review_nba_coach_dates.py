import json,re,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
print('ROLES',sorted({json.loads(b)['role'] for (b,) in db.execute('SELECT body FROM _nba_coach_tenure_sources')}))
for (b,) in db.execute('SELECT body FROM _nba_coach_tenure_sources'):
    s=json.loads(b)
    if s['effective_to'] and s['effective_to']<'2024-01-01':continue
    name=s['coach_or_manager_name'];pieces=[]
    for url,page,text in db.execute('SELECT source_url,page_number,text FROM _nba_coach_document_pages WHERE text LIKE ?',('%'+name+'%',)):
        for m in re.finditer(re.escape(name),text,re.I):
            excerpt=re.sub(r'\s+',' ',text[max(0,m.start()-50):m.end()+380])
            if re.search(r'(named|hired|appointed|promoted).{0,100}(head coach|coach)',excerpt,re.I) and re.search(r'\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z.]* \d{1,2},? 20\d{2}',excerpt):
                pieces.append((url,page,excerpt))
    print('CANDIDATE',name,s['team_name'],s['role'],s['effective_from'],s['effective_to'])
    for x in pieces[:2]:print('EVIDENCE',*x)
db.close()
