"""Check every published player-day against cumulative, dated source observations."""
import bisect,collections,datetime as dt,itertools,json,math,sqlite3
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT

FIELDS=['games_played','overall_winrate','average_score_per_game','std_score_per_game','average_assists_per_game','std_assists_per_game','average_minutes_per_game','std_minutes_per_game','starter_percentage_overall']
def close(a,b):return a is None and b is None or a is not None and b is not None and math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-8)

def main():
 db=sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True,timeout=120);db.row_factory=sqlite3.Row
 start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone();expected={};observations=0;intervals=0
 query='SELECT * FROM _player_game_results WHERE game_date BETWEEN ? AND ? ORDER BY player_id,league,game_date,game_id'
 for (pid,league),games in itertools.groupby(db.execute(query,(start,end)),lambda r:(r['player_id'],r['league'])):
  days=[];states=[];n=w=0;moments={s:[0,0.0,0.0] for s in ['score','assists','minutes','starter']}
  for day,items in itertools.groupby(games,lambda r:r['game_date']):
   for g in items:
    n+=1;w+=g['win'];observations+=1
    for stat in moments:
     value=g[stat]
     if value is None:continue
     count,mean,m2=moments[stat];count+=1;delta=value-mean;mean+=delta/count;m2+=delta*(value-mean);moments[stat]=[count,mean,m2]
   state=[n,w/n]
   for stat in ['score','assists','minutes']:
    count,mean,m2=moments[stat];state.extend([mean if count else None,math.sqrt(max(0,m2/(count-1))) if count>1 else None])
   state.append(moments['starter'][1] if moments['starter'][0] else None);days.append(day);states.append(tuple(state));intervals+=1
  expected[pid,league]=(days,states)
 results=[];dates=set();zero_history=0
 for league,prefix in [('NBA','nba'),('MLB','mlb'),('NHL','nhl'),('EU soccer','eu_soccer')]:
  path=ROOT/'data/result'/prefix/'player_performance.parquet';pf=pq.ParquetFile(path);cols=['player_id','league','as_of_date']+FIELDS+['performance_status'];n=0;mark=10;zero_count=0;first_year_observed=0
  for batch in pf.iter_batches(batch_size=25000,columns=cols):
   for pid,lg,day,*values in zip(*(batch.column(i).to_pylist() for i in range(len(cols)))):
    status=values.pop();days,states=expected.get((pid,lg),([],[]));index=bisect.bisect_right(days,day)-1;want=states[index] if index>=0 else (0,)*len(FIELDS)
    assert status==('insufficient matches' if index<0 else 'observed matches'),(pid,day,status,index)
    assert all(close(v,e) for v,e in zip(values,want)),(pid,day,dict(zip(FIELDS,values)),dict(zip(FIELDS,want)))
    dates.add(day);zero_history+=index<0;zero_count+=index<0;first_year_observed+=index>=0 and day[:4]==start[:4];n+=1
   while n*100//pf.metadata.num_rows>=mark:print('DAILY CUMULATIVE CHECK',league,mark,'percent;',n,flush=True);mark+=10
  assert n==pf.metadata.num_rows;pf.close();results.append(dict(league=league,checked_player_dates=n,zero_appearance_dates=zero_count,observed_appearance_dates=n-zero_count,first_year_observed_dates=first_year_observed,status_values_verified=True))
 # Show the requested date against the full fixed collection start.
 target='2025-07-01';source_rows=db.execute('SELECT count(*) FROM _player_game_results WHERE game_date BETWEEN ? AND ?',(start,target)).fetchone()[0]
 prior_year_rows=db.execute("SELECT count(*) FROM _player_game_results WHERE game_date>=? AND game_date<'2025-01-01'",(start,)).fetchone()[0]
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),collection_start=start,collection_end=end,query_rule='Every day includes all collected completed observations from collection_start through that day; no calendar-year or season reset.',source_observations=observations,independent_cumulative_intervals=intervals,distinct_profile_dates=len(dates),checked_player_dates=sum(r['checked_player_dates'] for r in results),zero_observation_player_dates=zero_history,results=results,requested_example=dict(query_date=target,history_start=start,included_player_game_observations=source_rows,included_2024_observations=prior_year_rows),failures=0)
 (ROOT/'reports/daily_cumulative_performance_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
if __name__=='__main__':main()
