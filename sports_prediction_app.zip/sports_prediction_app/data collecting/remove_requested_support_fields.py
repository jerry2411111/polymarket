"""Remove specifically requested public fields; raw source evidence stays internal."""
import datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=120);removed=[]
    with db:
        for table,fields in [('player_profiles',['number_of_teams_served']),('team_history',['total_salary_yearly','salary_year','currency'])]:
            cols={r[1] for r in db.execute('PRAGMA table_info('+table+')')}
            for field in fields:
                if field in cols:db.execute('ALTER TABLE '+table+' DROP COLUMN '+field);removed.append(table+'.'+field)
        row=db.execute("SELECT sql FROM sqlite_master WHERE name='player_rankings_quarterly' AND type='view'").fetchone()
        if row:
            db.execute('DROP VIEW player_rankings_quarterly');removed.append('player_rankings_quarterly view')
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='_ranking_asof_policy'").fetchone():
            for name,kind in [('_player_ranking_flags_quarterly','VIEW'),('_ranking_flag_results','TABLE'),('_ranking_quarterly_results','TABLE')]:
                if db.execute('SELECT 1 FROM sqlite_master WHERE name=?',(name,)).fetchone():
                    db.execute('DROP '+kind+' '+name);removed.append(name+' obsolete quarterly derivation')
    db.close()
    report=ROOT/'reports/support_schema_removal.json'
    prior=json.loads(report.read_text()).get('removed',[]) if report.exists() else []
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),removed=sorted(set(prior+removed)),retained='Raw ranking editions and source audit remain internal. Player contract currency is unchanged.')
    (ROOT/'reports/support_schema_removal.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out),flush=True)
if __name__=='__main__':main()
