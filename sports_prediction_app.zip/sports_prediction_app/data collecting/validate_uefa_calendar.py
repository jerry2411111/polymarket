"""Independent raw, goal-phase, date-range and official season-total validation."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from probe_uefa_api import BASE

def main():
 db=sqlite3.connect(DB);cache={};checks=collections.Counter();games={mid:json.loads(b) for mid,b in db.execute('SELECT * FROM _official_uefa_calendar')};parts=[json.loads(b) for b, in db.execute('SELECT body FROM _official_uefa_calendar_months ORDER BY month')];assert len(parts)==33 and all(p['complete'] for p in parts);issues=[]
 def source(rid,html=False):
  if rid not in cache:
   r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert r['status']==200 and hashlib.sha256(b).hexdigest()==r['sha256'];cache[rid]=BeautifulSoup(b,'html.parser') if html else json.loads(b)
  return cache[rid]
 covered=set()
 for p in parts:
  ids=set()
  for page in p['pages']:
   raw=source(page['request_id']);assert len(raw)==page['rows'] and len(raw)<=50;params=page['parameters'];assert params['offset']==len(ids);assert len({m['id'] for m in raw})==len(raw) and not ids&{m['id'] for m in raw};ids.update(m['id'] for m in raw)
   for m in raw:
    assert params['fromDate']<=m['kickOffTime']['date']<=params['toDate'] and int(m['seasonYear'])==params['seasonYear'] and m['competition']['id']=='1'
    if m['status']=='FINISHED':covered.add(m['id'])
  assert len(source(p['pages'][-1]['request_id']))<50;checks['exhausted_month_pagination']+=1
 assert covered==set(games)
 for mid,g in games.items():
  m=source(g['request_id'])[int(g['pointer'][1:])];assert m==g['raw'] and mid==m['id']==g['official_match_id'];assert m['status']=='FINISHED' and m['competition']['id']=='1';checks['exact_raw_game']+=1;when=dt.datetime.fromisoformat(m['kickOffTime']['dateTime']);assert when.astimezone(dt.UTC).isoformat()==g['scheduled_start_utc'];assert when.astimezone(dt.timezone(dt.timedelta(hours=m['kickOffTime']['utcOffsetInHours']))).date().isoformat()==g['date']==m['kickOffTime']['date'];assert '2024-01-01'<=g['date']<='2026-09-14';checks['utc_local_date']+=1
  for s in ['away','home']:
   t=m[s+'Team'];assert g[s]==dict(id=t['id'],name=t['translations']['displayOfficialName']['EN'],abbr=t['teamCode'],country_code=t['countryCode']);checks['native_full_team_identity']+=1
  proof=g['score_proof'];expected=None
  if proof['complete_goal_timeline']:
   counts=collections.defaultdict(lambda:[0,0]);ids=[g[s]['id'] for s in ['away','home']];goals=m.get('playerEvents',{}).get('scorers',[]);assert len({v['id'] for v in goals})==len(goals)==len(proof['goals'])
   for goal,pf in zip(goals,proof['goals']):
    side=ids.index(goal['teamId'])^(goal['goalType']=='OWN');assert pf['credited_side']==side and pf['goal_id']==goal['id'] and pf['phase']==goal['phase'];counts[goal['phase']][side]+=1;checks['official_goal_phase_and_own_goal_credit']+=1
   assert [sum(v[i] for v in counts.values()) for i in [0,1]]==[m['score']['total'][s] for s in ['away','home']];expected=[counts['FIRST_HALF'][i]+counts['SECOND_HALF'][i] for i in [0,1]];assert g['halftime_scores']==counts['FIRST_HALF'];checks['total_score_reconciled_to_goal_timeline']+=1
  elif g['scores'] is not None:expected=[m['score']['regular'][s] for s in ['away','home']];assert g['score_basis']=='Explicit official regular score';checks['explicit_score_without_complete_goals']+=1
  assert expected==g['scores']
  if expected is not None:
   names=[g[s]['name'] for s in ['away','home']];assert g['winner']==('Draw' if expected[0]==expected[1] else names[int(expected[1]>expected[0])]);checks['regulation_score_and_winner']+=1
  else:assert g['winner'] is None and g['score_discrepancy'];checks['unresolved_scores_preserved_null']+=1
  if g['score_discrepancy']:issues.append(dict(match_id=mid,date=g['date'],match=g['away']['name']+' / '+g['home']['name'],request_id=g['request_id'],pointer=g['pointer'],**g['score_discrepancy']))
 pages=json.loads((ROOT/'reports/uefa_validation_pages.json').read_text())['sources'];seasons=[]
 for year in [2025,2026]:
  gs=[g for g in games.values() if g['season_year']==year];main=[g for g in gs if g['competition_phase']=='TOURNAMENT'];teams={g[s]['id'] for g in main for s in ['away','home']};allteams={g[s]['id'] for g in gs for s in ['away','home']};p=next(p for p in pages if '/'+str(year)+'/statistics/' in p['url']);text=' '.join(source(p['request_id'],True).get_text(' ',strip=True).split());tot=int(re.search(r'(\d+) Matches played',text)[1]);teamcount=int(re.search(r'(\d+) Teams in final tournament',text)[1]);allcount=int(re.search(r'(\d+) Including qualifying stage',text)[1]);assert len(main)==tot==189 and len(teams)==teamcount==36 and len(allteams)==allcount
  # Whole-season endpoint independently checks that date pagination omitted
  # no completed fixtures. Current API rows remain raw and do not replace
  # earlier retained source responses.
  HOSTS.add('match.uefa.com');c=HistoryClient();seen=set();offset=0;rids=[]
  while True:
   d,r=c.get(BASE+'/v5/matches',dict(competitionId='1',seasonYear=year,limit=50,offset=offset,order='ASC'));assert isinstance(d,list) and not seen&{m['id'] for m in d};seen.update(m['id'] for m in d if m['status']=='FINISHED');rids.append(r['request_id'])
   if len(d)<50:break
   offset+=len(d);assert offset<1000
  assert seen=={g['official_match_id'] for g in gs};checks['independent_complete_season_pagination']+=1;seasons.append(dict(season=f'{year-1}-{str(year)[-2:]}',games=len(gs),main_tournament=len(main),qualifying=len(gs)-len(main),teams=len(allteams),statistics_page=p,season_request_ids=rids))
 special=games['2041692'];assert special['scores']==[3,3] and special['score_proof']['raw_regular']==[4,3] and special['score_proof']['raw_total']==[4,3];p=next(p for p in pages if 'mff.se' in p['url']);text=' '.join(source(p['request_id'],True).get_text(' ',strip=True).split());assert 'PAOK FC – Malmö FF 3 – 4' in text and 'Nils Zetterström (90+5′)' in text and 'Anders Christiansen (99′)' in text;checks['extra_time_discrepancy_independent_club_report']+=1
 special=games['2041694'];assert special['scores']==[1,4] and special['halftime_scores']==[1,2] and special['score_proof']['raw_regular']==[1,3];p=next(p for p in pages if 'glimt.no' in p['url']);text=' '.join(source(p['request_id'],True).get_text(' ',strip=True).split());assert '13. august 2024' in text and 'Sluttresultat 4 - 1' in text and 'Pauseresultat 2 - 1' in text;checks['regular_score_discrepancy_independent_club_report']+=1
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING' if checks['unresolved_scores_preserved_null']==0 else 'PARTIALLY WORKING',scope='Official calendar and score normalization only; odds and subtables require separate validation',games=len(games),checks=dict(checks),source_hashes=len(cache),seasons=seasons,issues=issues,missing_regulation_scores=checks['unresolved_scores_preserved_null']);(ROOT/'reports/uefa_calendar_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='issues'}));print('Issues:',json.dumps(issues,ensure_ascii=False));db.close()

if __name__=='__main__':main()
