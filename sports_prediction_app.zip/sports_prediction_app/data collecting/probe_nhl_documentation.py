"""Read current NHL public documentation and its own published client references."""
import datetime as dt,json,re,sqlite3
from urllib.parse import urljoin,urlsplit
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def main():
 c=HistoryClient();out=[];scripts=[]
 for url in ['https://www.nhl.com/info/api','https://api-web.nhle.com/v1/swagger-ui/index.html','https://api.nhle.com/stats/rest/en','https://www.nhl.com/scores/2025-01-04','https://www.nhl.com/stats']:
  try:
   b,r=c.get(url,document=True);s=BeautifulSoup(b,'html.parser');title=s.find('title');row=dict(url=url,status=r['status'],request_id=r['request_id'],title=title.get_text(' ',strip=True) if title else None,content_type=r.get('content_type'))
   if 'www.nhl.com/' in url:
    for tag in s.find_all('script',src=True):
     src=urljoin(url,tag['src']);host=urlsplit(src).hostname
     if host and (host.endswith('.nhl.com') or host.endswith('.nhle.com')) and src not in scripts:scripts.append(src)
   else:row['text_excerpt']=b.decode('utf-8',errors='replace')[:800]
  except Exception as e:row=dict(url=url,status='unavailable',error=str(e))
  out.append(row);print(json.dumps(row),flush=True)
 refs=[]
 for url in scripts[:16]:
  HOSTS.add(urlsplit(url).hostname)
  try:
   b,r=c.get(url,document=True);txt=b.decode('utf-8',errors='replace');hits=[]
   for m in re.finditer(r'api-web\.nhle\.com|api\.nhle\.com|club-schedule-season|play-by-play|/schedule/|/score/|/boxscore',txt):hits.append(txt[max(0,m.start()-100):m.end()+180])
   ref=dict(url=url,request_id=r['request_id'],endpoint_references=hits[:30]);refs.append(ref);print(json.dumps(ref),flush=True)
  except Exception as e:refs.append(dict(url=url,error=str(e)))
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),documentation_attempts=out,official_client_scripts=refs,new_requests=c.requests,note='Public reference availability is recorded honestly. Official client references establish its own published endpoint syntax; no third-party documentation, credentials or hidden authenticated assets are used.')
 (ROOT/'reports/nhl_current_documentation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')

if __name__=='__main__':main()
