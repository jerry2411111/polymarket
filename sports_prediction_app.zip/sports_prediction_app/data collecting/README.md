# Retrieve data and query history

Run commands from the project root after `prepare_storage.ps1` and dependency
installation. Review the selected script's arguments and required SQL tables
before running a collection stage. Set request limits using the root
`.env.example`; use process environment variables for any credentials.

Use `probe_history.py --docs-only` to capture current official API documentation.
`discover_*.py` identifies games and markets; `collect_*.py` retrieves source
responses; `parse_*.py` and `build_*.py` produce dated research tables.
Later stages require the earlier stages' stored records; do not run scripts in
alphabetical order. `refresh_revision_outputs.py` refreshes published outputs
from acquired facts, and `generate_data_catalog.py` regenerates field documentation.

NBA/MLB game results and statistics use official league services. Polymarket
quotes use its official APIs; historical Kalshi work uses its official APIs.
Official documentation starts at https://docs.polymarket.com/,
https://docs.kalshi.com/ and https://docs.statsapi.mlb.com/.
Other official service hosts include https://cdn.nba.com/,
https://api-web.nhle.com/ and https://baseballsavant.mlb.com/.
Weather uses https://www.ncei.noaa.gov/ and documented SMHI observations.
Historical profile and ranking scripts identify their source URLs.

Keep source responses and request provenance so values can be traced. The public
request log records request number, request type, requested data and status.
Use the closest eligible earlier quote for pre-0/12/24/36/48-hour observations;
source bucket availability must precede the cutoff. Keep missing statistics null
and distinguish them from zero observed appearances.

Query a prepared performance table by date:

```powershell
& .\final_models\.venv\Scripts\python.exe 'data collecting/query_sql.py' --table player_performance --date 2025-07-01
```

Use `query_sql.py --help` for game, weather, team and player-to-team queries.
Past-date performance uses only observations available by that date. Updating
the dashboard's schedule does not rebuild its historical model inputs.
