"""Small unauthenticated probes of routes used by official match widgets."""
import datetime as dt,json,sqlite3
from urllib.parse import quote
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from probe_seriea_api import BASE
from probe_eu_official_reports import brief

def main():
 db=sqlite3.connect(DB);c=HistoryClient();HOSTS.add('seriea-api.prd.sdp.deltatre.digital');gs=sorted([json.loads(b) for b, in db.execute('SELECT body FROM _official_seriea_calendar')],key=lambda g:g['date']);rows=[]
 for g in [gs[0],next(g for g in gs if g['date']>='2025-08-01'),gs[-1]]:
  path=BASE+'/seasons/'+quote(g['season_id'],safe='')+'/matches/'+quote(g['official_match_id'],safe='')
  for kind in ['lineups','feed','summary','teamstats']:
   try:
    d,r=c.get(path+'/'+kind);row=dict(date=g['date'],match_id=g['official_match_id'],kind=kind,url=path+'/'+kind,request_id=r['request_id'],status=r['status'],response=brief(d));print(json.dumps(row),flush=True)
   except Exception as e:row=dict(date=g['date'],match_id=g['official_match_id'],kind=kind,error=type(e).__name__+': '+str(e));print(json.dumps(row),flush=True)
   rows.append(row)
 (ROOT/'reports/seriea_game_details_pilot.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),rows=rows,new_requests=c.requests,client_sources=['c273b09452734674b978d8fe5881d9da','b93e0e8d5e244521b5e4c3425c90d961','f5029bba3f244d45b092a4ae41bc1c25','dd74748ae6394df880a416bb1ca12e2a']),indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
