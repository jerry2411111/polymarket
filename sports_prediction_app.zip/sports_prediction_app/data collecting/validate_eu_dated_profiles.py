"""Independent combined EU historical profile, tenure, injury and t-1 validation."""
from team_history_cells import decode
import collections,datetime as dt,json,math,sqlite3,statistics
from build_history_catalog import DB
from epl_price_points import Sources,pointer
from probe_history import ROOT

def eq(a,b):return a is None and b is None or a is not None and b is not None and math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-8)
def mean(xs):return statistics.mean(xs) if xs and all(v is not None for v in xs) else None

def main():
 db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;src=Sources(db);checks=collections.Counter();bios={pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _eu_profile_biographies')};facts=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_player_game_facts')];coaches=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_manager_game_facts')];games={gid:json.loads(b) for gid,b in db.execute('SELECT * FROM _eu_game_facts')};members=collections.defaultdict(list);bygame={(p['player_id'],p['game_id']):p for p in facts}
 for b, in db.execute('SELECT body FROM _eu_player_memberships'):
  m=json.loads(b);members[m['player_id']].append(m);raw,_=src.get(m['request_id']);v=pointer(raw,m['pointer']);assert v['id']==m['native_membership_id'] and {k:x for k,x in v.items() if k!='stat'}==m['raw_fields'];checks['retained_career_membership_identity']+=1
 dates=['2024-01-01','2024-08-16','2024-12-31','2025-05-25','2025-09-01','2025-12-31','2026-05-31','2026-09-14'];examples=[]
 for day in dates:
  roster=collections.defaultdict(list);played=collections.defaultdict(list)
  for p in facts:
   if p['game_date']<=day:
    roster[p['player_id']].append(p)
    if p['did_play']:played[p['player_id']].append(p)
  means={pid:mean([p['score'] for p in ps]) for pid,ps in played.items()};vals=[v for v in means.values() if v is not None];mu=statistics.mean(vals) if vals else None;sigma=statistics.pstdev(vals) if vals else None;n=0
  for r in db.execute("SELECT * FROM player_profiles WHERE league='EU soccer' AND as_of_date=?",(day,)):
   p=dict(r);pid=p['player_id'];b=bios[pid];ps=played[pid];assert eq(p['overall_winrate'],mean([x['win'] for x in ps]));assert eq(p['starter_percentage_overall'],mean([x['starter'] for x in ps]));checks['prior_winrate_and_starters']+=2
   for field in ['score','assists','minutes']:
    values=[x[field] for x in ps];avg=mean(values);sd=statistics.stdev(values) if avg is not None and len(values)>1 else None;assert eq(p['average_'+field+'_per_game'],avg) and eq(p['std_'+field+'_per_game'],sd),(day,pid,field);checks['independent_profile_average_and_sample_SD']+=2
   avg=means.get(pid);assert eq(p['score_z_score'],(avg-mu)/sigma if avg is not None and sigma else None);assert eq(p['participation_rate_overall'],len(ps)/len(roster[pid]) if roster[pid] else None);checks['past_cohort_and_participation']+=2
   for field in ['height_cm','weight_kg']:assert p[field]==b[field];checks['authorized_physical_constant']+=1
   born=dt.date.fromisoformat(b['birth_date']) if b['birth_date'] else None;d=dt.date.fromisoformat(day);age=d.year-born.year-((d.month,d.day)<(born.month,born.day)) if born else None;assert p['age']==age;checks['date_specific_age']+=1
   experience=b.get('completed_season_evidence');assert p['years_played']==(sum(e['available_date']<=day for e in experience.values()) if experience is not None else None);checks['prior_completed_seasons_only']+=1
   if p['served_team_history']:
    prior={m['team_name'] for m in members[pid] if m['start_date'] and m['start_date']<=day}|{x['team_name'] for x in roster[pid]};assert all(t in prior for t in decode(p['served_team_history']));checks['no_future_team_history']+=1
   if p['months_serving_current_team'] is not None:
    active=[m for m in members[pid] if m['team_name']==p['team'] and m['start_date'] and m['start_date']<=day and (not m['end_date'] or day<m['end_date'])];assert active;starts={m['start_date'] for m in members[pid] if m['team_name']==p['team'] and m['start_date'] and m['start_date']<=day};expected={(d.year-s.year)*12+d.month-s.month-(d.day<s.day) for s in map(dt.date.fromisoformat,starts)};assert p['months_serving_current_team'] in expected;checks['documented_tenure_start']+=1
   assert p['number_of_teams_served'] is None;n+=1
  for r in db.execute("SELECT * FROM manager_profiles WHERE league='EU soccer' AND as_of_date=?",(day,)):
   ps=[c for c in coaches if c['manager_id']==r['manager_id'] and c['game_date']<=day];assert ps and eq(r['overall_winrate'],mean([p['win'] for p in ps]));assert all(t in {p['team_name'] for p in ps} for t in decode(r['served_team_history']));checks['manager_past_games_and_clubs']+=1
  examples.append(dict(query_date=day,player_profiles=n,players_with_past_games=sum(bool(ps) for ps in played.values())))
 linked=collections.defaultdict(set)
 for gid,pid,day in db.execute('SELECT * FROM game_player_profiles WHERE game_id IN (SELECT game_id FROM _eu_game_facts)'):
  assert day==(dt.date.fromisoformat(games[gid]['date'])-dt.timedelta(days=1)).isoformat();assert db.execute('SELECT 1 FROM player_profiles WHERE player_id=? AND as_of_date=?',(pid,day)).fetchone();linked[gid].add(pid);checks['player_t_minus_one_link']+=1
 for b, in db.execute('SELECT body FROM _eu_game_profile_link_audit'):
  a=json.loads(b);assert a['players']==len(linked[a['game_id']])
  for source in a['prior_roster_sources']:assert source['observed_date']<=a['as_of_date'] and source['game_id']!=a['game_id'];checks['prior_roster_source_date']+=1
 for gid,mid,day in db.execute('SELECT * FROM game_manager_profiles WHERE game_id IN (SELECT game_id FROM _eu_game_facts)'):
  assert day==(dt.date.fromisoformat(games[gid]['date'])-dt.timedelta(days=1)).isoformat();assert db.execute('SELECT 1 FROM manager_profiles WHERE manager_id=? AND as_of_date=?',(mid,day)).fetchone();assert any(c['manager_id']==mid and c['game_date']<=day and c['team_name'] in games[gid]['teams'] for c in coaches);checks['coach_t_minus_one_link']+=1
 for b, in db.execute('SELECT body FROM _eu_injury_observations'):
  a=json.loads(b);p=bygame[a['player_id'],a['game_id']]
  if 'source' in a:proof=a['source'];raw,_=src.get(proof['request_id']);assert pointer(raw,proof['pointer'])==proof['raw']
  else:assert p.get('injury_reported') or p.get('injured_departure')
  row=db.execute('SELECT currently_injured_till_as_of_date,injured_times_till_as_of_date FROM player_profiles WHERE player_id=? AND as_of_date=?',(p['player_id'],p['game_date'])).fetchone();assert tuple(row)==(1,None);checks['dated_reported_injury']+=1
 for col in ['overall_winrate','participation_rate_current_team','participation_rate_overall','starter_percentage_current_team','starter_percentage_overall']:assert db.execute('SELECT count(*) FROM player_profiles WHERE league=\'EU soccer\' AND ('+col+'<0 OR '+col+'>1)').fetchone()[0]==0;checks['full_profile_probability_range']+=1
 assert db.execute("SELECT count(*) FROM player_profiles WHERE league='EU soccer' AND months_serving_current_team<0").fetchone()[0]==0
 assert db.execute("SELECT count(*) FROM player_profiles p LEFT JOIN player_current_team c USING(player_id,as_of_date) WHERE p.league='EU soccer' AND (c.player_id IS NULL OR c.current_team IS NOT p.team)").fetchone()[0]==0
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',coverage_status='PARTIALLY WORKING',checks=dict(checks),examples=examples,source_hashes=len(src.cache),player_rows=db.execute("SELECT count(*) FROM player_profiles WHERE league='EU soccer'").fetchone()[0],manager_rows=db.execute("SELECT count(*) FROM manager_profiles WHERE league='EU soccer'").fetchone()[0],limits=['Unreported injury defaults false by user instruction; this does not verify health.','Full-career team and injury-episode completeness is not established.','Dated memberships are retrospective source facts, not proof of publication availability.','Missing personal constants and source statistics remain null.']);(ROOT/'reports/eu_profiles_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
