import json
from bs4 import BeautifulSoup
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT
c=HistoryClient();out=[]
urls=['https://docs.polymarket.com/api-reference/sports/list-teams.md','https://www.nhl.com/bluejackets/news/blue-jackets-kings-game-postponed-to-march-9','https://www.nhl.com/utah/news/utah-s-nhl-franchise-officially-named-the-utah-mammoth-release-5-7-25']
for url in urls:
 b,r,_=get(c,url);text=b.decode('utf-8',errors='replace')
 if not url.endswith('.md'):
  s=BeautifulSoup(b,'html.parser');article=s.find('article') or s;text=article.get_text(' ',strip=True)
 out.append(dict(url=url,request_id=r['request_id'],text=text));print(url,r['request_id'],text[:7500] if url.endswith('.md') else text[:650],flush=True)
(ROOT/'reports/nhl_identity_sources.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
