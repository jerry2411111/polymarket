"""Keep Toronto weather near the city instead of across Lake Ontario."""
import datetime as dt,json,sqlite3
from build_history_catalog import DB
from collect_history_weather import DOC
from history_client import HistoryClient
from prepare_mlb_weather_stations import distance
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);old=db.execute("SELECT station_id,body FROM _weather_city_stations WHERE city='Toronto' AND year='2025'").fetchone();assert old
    previous=json.loads(old[1]);station='CAN06158731';c=HistoryClient();b,r=c.get(DOC+'ghcnh-station-list.txt',document=True);line=next(x for x in b.decode().splitlines() if x.startswith(station));parts=line.split();km=distance(previous['coordinates'],[float(parts[1]),float(parts[2])]);assert km<50
    _,archive=c.get(f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/2025/parquet/GHCNh_{station}_2025.parquet',document=True)
    body=dict(previous,station=station,distance_km=km,station_directory_row=line,station_directory_request_id=r['request_id'],archive_request_id=archive['request_id'],previous_station=old[0],method='Canadian station within 50 km of Toronto venue. A farther station across Lake Ontario is not substituted merely to fill missing weather fields.')
    with db:db.execute("UPDATE _weather_city_stations SET station_id=?,body=? WHERE city='Toronto' AND year='2025'",(station,json.dumps(body)))
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),previous=previous,selected=body,new_requests=c.requests)
    (ROOT/'reports/toronto_weather_station_review.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(dict(station=station,distance_km=km,replaced=old[0])));db.close()

if __name__=='__main__':main()
