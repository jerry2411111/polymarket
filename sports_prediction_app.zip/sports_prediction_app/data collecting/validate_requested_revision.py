"""Independent source-observation and temporal checks for the requested revision."""
import collections,datetime as dt,json,math,sqlite3,statistics
from build_history_catalog import DB
from probe_history import ROOT
from temporal_queries import PUBLIC_PLAYER,FLAGS,PLAYER_SQL
from ranking_policy import active_flags

def same(a,b):return a is None and b is None or a is not None and b is not None and math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-9)

def main():
 db=sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True,timeout=120);db.row_factory=sqlite3.Row;checks=collections.Counter();examples=[]
 for table in ['main','in_game','kalshi_pre_match','polymarket_pre_match']:
  drawcols=[r['name'] for r in db.execute('PRAGMA table_info('+table+')') if r['name'].startswith('draw_')]
  assert not db.execute('SELECT 1 FROM '+table+" WHERE game_type<>'Soccer' AND ("+' OR '.join(c+' IS NOT NULL' for c in drawcols)+') LIMIT 1').fetchone();checks['no_artificial_draw_values']+=1
 families=collections.defaultdict(set);draws={}
 for table in ['_epl_market_candidates','_eu_validated_contracts']:
  for row in db.execute('SELECT body FROM '+table):
   r=json.loads(row[0]);key=(r['provider'],r['family_id'],r['game_id']);families[key].add(r['side'])
   if r['side']==2:
    assert not r.get('draw_half_payout_rule',False);draws[key]=r
 selected=set()
 for table in ['_epl_odds_selections','_eu_odds_selections']:
  for row in db.execute('SELECT body FROM '+table):
   r=json.loads(row[0])
   if r.get('selected_family'):selected.add((r['provider'],r['family_id'],r['game_id']))
 for provider in ['kalshi','polymarket']:
  for row in db.execute('SELECT game_id FROM '+'_source_'+provider+'_soccer_pre_match'):
   matches=[k for k in selected if k[0]==provider and k[2]==row[0]]
   assert len(matches)==1,(provider,row[0],matches);k=matches[0];assert families[k]=={0,1,2} and k in draws
   checks['published_soccer_draw_option_verified']+=1
 assert db.execute("SELECT count(*) FROM manager_profiles WHERE team IS NULL OR trim(team)=''").fetchone()[0]==0
 assert 'months_serving_current_team' not in [r['name'] for r in db.execute('PRAGMA table_info(manager_profiles)')]
 assert not db.execute("SELECT 1 FROM sqlite_master WHERE name='coach_contracts'").fetchone()
 assert not db.execute("PRAGMA foreign_key_check('game_manager_profiles')").fetchall();checks['manager_schema_and_links']=1
 # Recalculate from original normalized per-game observations, using statistics rather than the interval implementation.
 for league in ['NBA','MLB','NHL','EU soccer']:
  people=[r[0] for r in db.execute('SELECT player_id FROM _player_game_results WHERE league=? GROUP BY player_id ORDER BY player_id',(league,))]
  people=people[::max(1,len(people)//45)]
  for pid in people:
   games=[dict(r) for r in db.execute('SELECT * FROM _player_game_results WHERE player_id=? AND league=? ORDER BY game_date,game_id',(pid,league))]
   for idx in sorted({0,len(games)//2,len(games)-1}):
    day=games[idx]['game_date'];past=[g for g in games if g['game_date']<=day]
    p=db.execute('SELECT * FROM _player_performance_periods WHERE player_id=? AND league=? AND effective_from<=? AND effective_to>?',(pid,league,day,day)).fetchone();assert p
    assert p['games_played']==len(past);assert same(p['overall_winrate'],statistics.mean(g['win'] for g in past))
    for stat in ['score','assists','minutes']:
     values=[g[stat] for g in past if g[stat] is not None];mean=statistics.mean(values) if values else None;sd=statistics.stdev(values) if len(values)>1 else None
     assert same(mean,p['average_'+stat+'_per_game']),(pid,day,stat,mean,p['average_'+stat+'_per_game'])
     assert same(sd,p['std_'+stat+'_per_game']),(pid,day,stat,sd,p['std_'+stat+'_per_game'])
     counts=db.execute('SELECT '+stat+'_count FROM _player_performance_sample_counts WHERE player_id=? AND league=? AND effective_from=?',(pid,league,day)).fetchone();assert counts[0]==len(values)
     checks['independent_mean_sd_and_sample_counts']+=1
  print('SOURCE PERFORMANCE CHECKED',league,flush=True)
 # Compare parameterized SQL to stored dated views and publisher flag evidence.
 for day in ['2024-06-30','2025-06-30','2026-09-14']:
  rows=[dict(r) for r in db.execute(PLAYER_SQL,dict(collection_start='2024-01-01',query_date=day))]
  fixed={r['player_id']:dict(r) for r in db.execute('SELECT * FROM player_performance WHERE as_of_date=?',(day,))}
  assert len(rows)==len(fixed),(day,len(rows),len(fixed))
  for p in rows:
   q=fixed[p['player_id']]
   for c in PUBLIC_PLAYER:
    assert same(p[c],q[c]) if isinstance(p[c],(float,int)) or p[c] is None else p[c]==q[c],(day,p['player_id'],c,p[c],q[c])
   assert p['performance_status']==q['performance_status']==('insufficient matches' if p['games_played']==0 else 'observed matches')
   for c in active_flags(db,fallback=FLAGS):assert p[c]==q[c],(day,p['player_id'],c)
   if p['games_played']==0:
    assert all(p[c]==0 for c in PUBLIC_PLAYER[6:]);checks['zero_history_rows_verified']+=1
   checks['parameterized_and_cached_person_dates']+=1
  examples.append(dict(date=day,players=len(rows),no_observation_players=sum(p['games_played']==0 for p in rows)))
  print('AS-OF QUERY CHECKED',day,len(rows),flush=True)
 kept={league:active_flags(db,league,FLAGS) for league in ['NBA','MLB','NHL','EU soccer']}
 for league,flags in kept.items():
  assert all(db.execute('SELECT observed_values FROM _ranking_public_columns WHERE league=? AND column_name=?',(league,c)).fetchone()[0]>0 for c in flags)
 checks['league_flags_have_source_observations']=4
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),checks=dict(checks),as_of_examples=examples,ranking_columns_kept=kept,failures=0)
 (ROOT/'reports/requested_revision_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');db.close();print(json.dumps({k:v for k,v in out.items() if k!='ranking_columns_kept'}),flush=True)
if __name__=='__main__':main()
