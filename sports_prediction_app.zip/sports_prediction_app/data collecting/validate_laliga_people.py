"""Check source-native profile identity and constant attributes against raw HTML."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from collect_laliga_people import namekey

def main():
 db=sqlite3.connect(DB);counts=collections.Counter();missing=collections.Counter();native=collections.defaultdict(list)
 for key,b in db.execute('SELECT * FROM _official_laliga_people_sources'):
  row=json.loads(b);counts['requested']+=1
  if row['status']!='ok':counts['unavailable']+=1;continue
  r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(row['request_id'],)).fetchone()[0]);raw=(ROOT/r['raw_file']).read_bytes();assert r['status']==200 and hashlib.sha256(raw).hexdigest()==r['sha256'];script=re.search(rb'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',raw,re.S);d=json.loads(script[1])['props']['pageProps']['player'];assert d==row['data'] and str(d['id'])==row['person_id'];assert {namekey(d['name']),namekey(' '.join(filter(None,[d.get('firstname'),d.get('lastname')])))}&{namekey(n) for n in row['source_names']};assert len(row['source_lineup_ids'])==len(set(row['source_lineup_ids']));counts['exact_native_profile_and_source_name']+=1;native[row['person_id']].append(key)
  for field in ['date_of_birth','height','weight']:missing[field]+=d.get(field) is None or d.get(field)==0
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Constant player personal attributes; exact historical membership and performance use dated reports separately',counts=dict(counts),native_people=len(native),multiple_source_names_for_same_person={k:v for k,v in native.items() if len(v)>1},missing=dict(missing));(ROOT/'reports/laliga_people_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
