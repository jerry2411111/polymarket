﻿import json,sqlite3
from probe_history import ROOT
from build_history_catalog import DB
db=sqlite3.connect(DB);r=json.loads(db.execute("SELECT metadata_json FROM _request_audit WHERE json_extract(metadata_json,'$.endpoint')='https://data-api.polymarket.com/v2/openapi.json' ORDER BY request_number DESC LIMIT 1").fetchone()[0]);d=json.loads((ROOT/r['raw_file']).read_bytes());print('INFO',d.get('info'))
for p,x in d['paths'].items():
 if 'prices-history' in p:print('PATH',p,json.dumps(x)[:12500])
