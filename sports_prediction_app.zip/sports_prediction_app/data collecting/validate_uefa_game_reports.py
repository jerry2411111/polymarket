"""Validate retained official reports, event pagination, identities and game clocks."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources,pointer
from probe_history import ROOT
from core import utc

def main():
 db=sqlite3.connect(DB,timeout=60);src=Sources(db);checks=collections.Counter();issues=[];stats=collections.Counter();phase_scores={}
 for mid,b in db.execute('SELECT * FROM _official_uefa_game_reports'):
  report=json.loads(b)
  if report['status']!='ok':issues.append(dict(match_id=mid,reason='Acquisition error',error=report['error']));continue
  raw={}
  for kind in ['match','lineups']:
   s=report['sources'][kind];d,r=src.get(s['request_ids'][0]);assert d==s['data'];raw[kind]=d;assert r['endpoint']=='https://match.uefa.com/v5/matches/'+mid+('/lineups' if kind=='lineups' else '');checks['raw_detail_or_lineup_equality']+=1
  m,l=raw['match'],raw['lineups'];assert m['id']==l['matchId']==mid and m['status']=='FINISHED';g=json.loads(db.execute('SELECT body FROM _official_uefa_calendar WHERE match_id=?',(mid,)).fetchone()[0]);assert m['kickOffTime']['dateTime']==g['raw']['kickOffTime']['dateTime'];assert m['score']==g['raw']['score'];checks['official_calendar_score_and_date']+=1
  for s in ['awayTeam','homeTeam']:
   assert m[s]['id']==g['raw'][s]['id']
   if not l.get(s):stats['missing_lineup_sides']+=1;continue
   assert l[s]['team']['id']==m[s]['id'];people=[p for kind in ['field','bench'] for p in l[s].get(kind,[])];assert len({p['player']['id'] for p in people})==len(people);checks['native_roster_people']+=len(people)
   if len(l[s].get('field',[]))!=11:issues.append(dict(match_id=mid,reason='Starting lineup is not eleven players',side=s,count=len(l[s].get('field',[]))))
   for p in people:
    person=p['player'];stats['player_biographies']+=1;stats['embedded_current_club_differs_from_historical_team']+=person.get('clubId') not in [None,m[s]['id']]
   checks['dated_coach_entries']+=len(l[s].get('coaches',[]))
  es=report['sources']['events'];events=[]
  for page in es['page_ranges']:
   d,r=src.get(page['request_id']);assert r['parameters']==dict(filter='ALL',limit=500,offset=len(events),order='ASC');assert page['start_index']==len(events) and page['length']==len(d);events+=d
  assert len(d)<500 and events==es['data'];assert len({e['id'] for e in events})==len(events);assert all(e['matchId']==mid for e in events);checks['paginated_raw_events']+=len(events)
  stats['event_timestamp_missing']+=sum(not e.get('timestamp') for e in events)
  clock=report['derived']
  for field in ['actual_start_utc','halftime_start_utc','second_half_start_utc','regulation_end_utc']:
   for proof in clock['clock_proofs'][field]:assert pointer(events,proof['pointer'])==proof['value'];checks['raw_clock_values']+=1
   if clock[field] is not None:assert {p['value'] for p in clock['clock_proofs'][field]}=={clock[field]}
  if all(clock[k] for k in ['actual_start_utc','halftime_start_utc','second_half_start_utc','regulation_end_utc']):
   ts=[utc(clock[k]) for k in ['actual_start_utc','halftime_start_utc','second_half_start_utc','regulation_end_utc']];assert ts==sorted(ts);assert 180<=(ts[2]-ts[1]).total_seconds()<=3600;checks['ordered_official_phase_boundaries']+=1
  issues.extend(dict(match_id=mid,**i) for i in clock['issues'])
  # Some event.totalScore objects contain the final score even on the first
  # goal. Never use those fields for a historical checkpoint.
  scored=[0,0];byphase=collections.defaultdict(lambda:[0,0]);ids=[m[s]['id'] for s in ['awayTeam','homeTeam']];goals=[]
  for i,e in enumerate(events):
   if e['type']!='GOAL':continue
   side=ids.index(e['primaryActor']['team']['id'])^(e.get('subType')=='OWN');scored[side]+=1;byphase[e['phase']][side]+=1;goals.append(dict(event_id=e['id'],pointer='/'+str(i),side=side,phase=e['phase']))
   if e.get('totalScore') and [e['totalScore'][s] for s in ['away','home']]!=scored:stats['goal_event_score_is_not_running_score']+=1
  total=[m['score']['total'][s] for s in ['away','home']]
  if scored==total and (events or total==[0,0]):
   reg=[byphase['FIRST_HALF'][i]+byphase['SECOND_HALF'][i] for i in [0,1]]
   if reg==g['scores']:checks['timeline_goals_reconciled_to_final_and_regulation']+=1;phase_scores[mid]=dict(halftime_scores=byphase['FIRST_HALF'],scores=reg,goal_proofs=goals,events_request_ids=es['request_ids'])
   else:issues.append(dict(match_id=mid,reason='Event regulation goals disagree with verified official regulation score',goals=reg,official=g['scores']))
  else:issues.append(dict(match_id=mid,reason='Event goals do not reconcile to official total score',goals=scored,official=total))
  checks['games']+=1
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _uefa_verified_phase_scores (match_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
  db.executemany('INSERT OR REPLACE INTO _uefa_verified_phase_scores VALUES (?,?)',[(mid,json.dumps(v)) for mid,v in phase_scores.items()])
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING' if not issues else 'PARTIALLY WORKING',scope='Only reports acquired so far; missing clock/lineup/score components remain excluded',checks=dict(checks),diagnostics=dict(stats),verified_phase_score_games=len(phase_scores),source_hashes=len(src.cache),issues=issues);(ROOT/'reports/uefa_game_reports_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='issues'}),flush=True);print('Issues',len(issues),flush=True);db.close()

if __name__=='__main__':main()
