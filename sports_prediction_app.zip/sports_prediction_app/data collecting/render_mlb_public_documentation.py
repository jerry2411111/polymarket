﻿import datetime as dt,json,subprocess,tempfile,pathlib,hashlib
from bs4 import BeautifulSoup
from probe_history import ROOT
folder=pathlib.Path(tempfile.gettempdir())/'sentinent_mlb_docs_edge';folder.mkdir(exist_ok=True)
url='https://docs.statsapi.mlb.com/getting-started/request-basics'
r=subprocess.run([r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe','--headless=new','--disable-gpu','--no-first-run','--disable-extensions','--user-data-dir='+str(folder),'--dump-dom','--virtual-time-budget=12000',url],capture_output=True,timeout=40,creationflags=subprocess.CREATE_NO_WINDOW)
b=r.stdout;dest=ROOT/'data/raw/browser_documents';dest.mkdir(exist_ok=True);path=dest/'mlb_request_basics_dom.html';path.write_bytes(b)
s=BeautifulSoup(b,'html.parser');text=s.get_text(' ',strip=True);print('RENDERED_DOCUMENT',r.returncode,len(b),text[:5000]);report=dict(url=url,retrieved_at_utc=dt.datetime.now(dt.UTC).isoformat(),method='Normal unauthenticated browser navigation; no login, token extraction, or access-control bypass',return_code=r.returncode,dom_file=str(path.relative_to(ROOT)),sha256=hashlib.sha256(b).hexdigest(),rendered_text=text[:15000]);(ROOT/'reports/mlb_documentation_browser_check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
