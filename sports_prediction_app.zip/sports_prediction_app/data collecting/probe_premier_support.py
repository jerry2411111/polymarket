"""Small, real requests using routes read from the current official league client."""
import datetime as dt,json,sqlite3
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from build_history_catalog import DB
from collect_premier_pilot import BASE

def main():
    HOSTS.update({'sdp-prem-prod.premier-league-prod.pulselive.com','www.premierleague.com'});c=HistoryClient();rows=[]
    probes=[('player_matches','/v1/competitions/8/seasons/2023/players/118748/matches/all',{}),('player_bio','/v1/players/118748',{}),('player_career','/v1/players/118748/career',{}),('manager','/v1/managers/279',{}),('commentary_limit','/v2/matches/2367731/commentary',dict(lang='en',_limit=100))]
    for name,path,params in probes:
        try:
            data,r=c.get(BASE+path,params);row=dict(name=name,request_id=r['request_id'],endpoint=r['endpoint'],parameters=params,type=type(data).__name__,keys=list(data) if isinstance(data,dict) else None,rows=len(data.get('data',[])) if isinstance(data,dict) else len(data));print(json.dumps(row),flush=True)
        except Exception as e:row=dict(name=name,error=str(e));print(json.dumps(row),flush=True)
        rows.append(row)
    for article in ['4221175','4109077']:
        try:
            _,r=c.get('https://www.premierleague.com/en/news/'+article,document=True);rows.append(dict(name='matching_evidence',article=article,request_id=r['request_id']))
        except Exception as e:rows.append(dict(name='matching_evidence',article=article,error=str(e)))
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),new_requests=c.requests,sources=rows);(ROOT/'reports/epl_support_probes.json').write_text(json.dumps(out,indent=2),encoding='utf-8')

if __name__=='__main__':main()
