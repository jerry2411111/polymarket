import json,re
from probe_history import ROOT
d=json.loads((ROOT/'reports/nhl_official_employment_documents.json').read_text())
for source in d['documents']:
    print('SOURCE',source['url'],source['request_id'])
    for p in source['pages']:
        if source['url'].endswith('CBA.pdf'):print('CBA TIMING',p['page'],p['text'][p['text'].find('commencing the later'):][:500]);continue
        text=p['text'];lines=text.splitlines();selected=set()
        for n,line in enumerate(lines):
            if re.search(r'\b(?:hired|named|appointment|Date|May|June|July|August|September|October|November|December|January|February|March|April)\b',line,re.I):selected.update(range(max(0,n-1),min(len(lines),n+3)))
        print('PAGE',p['page'],'\n'.join(lines[n] for n in sorted(selected)))
