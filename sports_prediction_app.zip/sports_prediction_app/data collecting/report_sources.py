"""Compatibility entry point for the current source inventory."""
from report_current_sources import main

if __name__ == "__main__":
    main()
