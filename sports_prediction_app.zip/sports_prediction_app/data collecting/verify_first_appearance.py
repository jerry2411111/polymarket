"""Verify real first-year results and the zero-history boundary in both SQL paths."""
import datetime as dt
import json
import math
import sqlite3
import statistics

from build_history_catalog import DB
from probe_history import ROOT
from temporal_queries import PLAYER_SQL, PUBLIC_PLAYER


def equal(a, b):
    if a is None or b is None:
        return a is b
    return math.isclose(a, b, rel_tol=1e-8, abs_tol=1e-8)


def main():
    db = sqlite3.connect(DB.resolve().as_uri() + '?mode=ro', uri=True, timeout=120)
    db.row_factory = sqlite3.Row
    start, end = db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    examples = []
    query_cache = {}
    for league in ['NBA', 'MLB', 'NHL', 'EU soccer']:
        first = db.execute('''SELECT m.* FROM _player_performance_periods m
          WHERE m.league=? AND m.games_played=1 AND m.average_score_per_game>0
          AND EXISTS(SELECT 1 FROM player_profiles p WHERE p.player_id=m.player_id
                     AND p.league=m.league AND p.as_of_date=date(m.effective_from,'-1 day'))
          ORDER BY m.effective_from,m.player_id LIMIT 1''', (league,)).fetchone()
        assert first and first['effective_from'][:4] == start[:4], league
        pid, day = first['player_id'], first['effective_from']
        second = db.execute('''SELECT MIN(effective_from) FROM _player_performance_periods
            WHERE player_id=? AND league=? AND effective_from>?''', (pid, league, day)).fetchone()[0]
        before = (dt.date.fromisoformat(day) - dt.timedelta(days=1)).isoformat()
        for cutoff in [before, day, second]:
            assert cutoff and start <= cutoff <= end
            row = db.execute('SELECT * FROM player_performance WHERE player_id=? AND league=? AND as_of_date=?',
                             (pid, league, cutoff)).fetchone()
            assert row is not None, (pid, cutoff)
            if cutoff not in query_cache:
                query_cache[cutoff] = {(r['player_id'], r['league']): dict(r) for r in
                                      db.execute(PLAYER_SQL, dict(collection_start=start, query_date=cutoff))}
            calculated = query_cache[cutoff][pid, league]
            games = db.execute('''SELECT * FROM _player_game_results WHERE player_id=? AND league=?
                AND game_date BETWEEN ? AND ? ORDER BY game_date,game_id''', (pid, league, start, cutoff)).fetchall()
            assert row['games_played'] == len(games)
            want_status = 'observed matches' if games else 'insufficient matches'
            assert row['performance_status'] == calculated['performance_status'] == want_status
            for c in PUBLIC_PLAYER[6:]:
                assert equal(row[c], calculated[c]), (pid, cutoff, c)
            if not games:
                assert all(row[c] == 0 for c in PUBLIC_PLAYER[6:])
            else:
                assert equal(row['overall_winrate'], statistics.mean(g['win'] for g in games))
                for stat in ['score', 'assists', 'minutes']:
                    values = [g[stat] for g in games if g[stat] is not None]
                    mean = statistics.mean(values) if values else None
                    sd = statistics.stdev(values) if len(values) > 1 else None
                    assert equal(row['average_' + stat + '_per_game'], mean)
                    assert equal(row['std_' + stat + '_per_game'], sd)
            examples.append(dict(league=league, player_id=pid, player_name=row['player_name'], query_date=cutoff,
                                 first_collected_appearance=day, games_played=len(games),
                                 performance_status=want_status, average_score_per_game=row['average_score_per_game'],
                                 std_score_per_game=row['std_score_per_game'],
                                 average_minutes_per_game=row['average_minutes_per_game'],
                                 std_minutes_per_game=row['std_minutes_per_game'],
                                 source_game_ids=[g['game_id'] for g in games]))
        print('FIRST-YEAR SQL CHECKED', league, first['player_name'], day, flush=True)
    report = dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(), collection_start=start,
                  checked_examples=len(examples), sql_paths=['dated public view', 'parameterized cumulative query'],
                  source='_player_game_results: collected official or explicitly credited game reports',
                  examples=examples, failures=0)
    (ROOT / 'reports/first_appearance_validation.json').write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    render_summary(report)
    db.close()
    print(json.dumps(report, ensure_ascii=False))


def render_summary(report):
    assert report['failures'] == 0
    lines = ['# Player performance by query date', '',
             'Use all collected completed appearances from 2024-01-01 through the selected date, inclusively. There is no first-year exclusion or year/season reset.', '',
             '- Zero appearances: performance statistics are 0 and performance_status is insufficient matches.',
             '- One or more appearances: performance_status is observed matches. Each statistic uses its available recorded values immediately.',
             '- A missing source statistic remains NULL. Sample standard deviation requires two valid values; this does not suppress the other results.', '',
             'The following real first-year examples agree with the retained per-game observations, the dated SQL view and the parameterized cumulative SQL query.', '',
             '| League | Player | Query date | Games played | Status | Average score | Score SD |',
             '|---|---|---|---:|---|---:|---:|']
    for e in report['examples']:
        values = [e[c] for c in ['league', 'player_name', 'query_date', 'games_played', 'performance_status', 'average_score_per_game', 'std_score_per_game']]
        lines.append('| ' + ' | '.join('NULL' if v is None else format(v, '.6g') if isinstance(v, float) else str(v) for v in values) + ' |')
    lines += ['', 'Score means NBA points, MLB batting runs, NHL goals or soccer goals. These are collected-game statistics, not a claim of complete career coverage.', '',
              '```sql', 'SELECT player_name, league, as_of_date, games_played, performance_status,',
              '       average_score_per_game, average_assists_per_game, average_minutes_per_game',
              "FROM player_performance WHERE as_of_date = '2025-07-01';", '```', '',
              '[Source game IDs and machine-readable checks](first_appearance_validation.json)', '']
    (ROOT / 'reports/player_performance_rule.md').write_text('\n'.join(lines), encoding='utf-8')


if __name__ == '__main__':
    main()
