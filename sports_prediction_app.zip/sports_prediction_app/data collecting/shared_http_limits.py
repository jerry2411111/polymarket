"""A host-wide send limit and cooldown shared by every local collector process."""
import os,time

def initialize(db):
    db.execute('CREATE TABLE IF NOT EXISTS _http_rate_limits (host TEXT PRIMARY KEY,next_at REAL NOT NULL,min_interval REAL NOT NULL) STRICT');db.commit()

def interval(host):
    default=4 if 'kalshi.com' in host else 6
    return 1/min(float(os.getenv('HISTORY_REQUESTS_PER_SECOND',str(default))),default)

def acquire(db,host):
    # Wait outside the SQL transaction. Recheck at send time so a new 429
    # cooldown also blocks threads that were already waiting for a send slot.
    while True:
        db.execute('BEGIN IMMEDIATE')
        row=db.execute('SELECT next_at,min_interval FROM _http_rate_limits WHERE host=?',(host,)).fetchone();now=time.time();wait=max(0,row[0]-now) if row else 0
        if wait==0:
            width=max(interval(host),row[1] if row else 0)
            db.execute('INSERT INTO _http_rate_limits VALUES (?,?,?) ON CONFLICT(host) DO UPDATE SET next_at=excluded.next_at,min_interval=excluded.min_interval',(host,now+width,width));db.commit();return
        db.commit();time.sleep(min(wait,1.0))

def cooldown(db,host,seconds,rate_limited=False):
    with db:
        row=db.execute('SELECT next_at,min_interval FROM _http_rate_limits WHERE host=?',(host,)).fetchone();width=max(interval(host),row[1] if row else 0)
        if rate_limited:width=min(2.0,max(.5,width*1.5))
        db.execute('INSERT INTO _http_rate_limits VALUES (?,?,?) ON CONFLICT(host) DO UPDATE SET next_at=max(next_at,excluded.next_at),min_interval=max(min_interval,excluded.min_interval)',(host,time.time()+seconds,width))
