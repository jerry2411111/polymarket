import json,re
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
HOSTS.add('builds.mlbstatic.com');c=HistoryClient();out=[]
base='https://builds.mlbstatic.com/mlb.com/sections/roster/builds/9061ccd8e4d9428085d404f48e0f9ae36041794c_1788358343/scripts/'
for path in ['index.bundle.js','transactions.bundle.js']:
    b,r=c.get(base+path,document=True);s=b.decode('utf-8');hits=[]
    for word in ['/transactions','startDate','endDate','/coaches','personIds','/roster','hydrate']:
        hits.extend(s[max(0,m.start()-220):m.start()+650] for m in list(re.finditer(re.escape(word),s))[:6])
    out.append(dict(url=r['endpoint'],request_id=r['request_id'],hits=hits));print(json.dumps(out[-1]))
(ROOT/'reports/mlb_public_roster_routes.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
