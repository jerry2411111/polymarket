"""Independent official-club checks for corrected birth-date examples."""
import datetime as dt,json,re,sqlite3
from urllib.parse import urljoin,urlsplit
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

EXAMPLES=[('player:116535','https://www.liverpoolfc.com/team/mens/player/alisson-becker','2 October 1992','1992-10-02'),('player:611917','https://www.tottenhamhotspur.com/player/611917/luc-williams-barnett','1 Oct 2008','2008-10-01')]
def main():
 HOSTS.update({'www.liverpoolfc.com','www.tottenhamhotspur.com'});client=HistoryClient();db=sqlite3.connect(DB);checks=[]
 for key,url,literal,expected in EXAMPLES:
  original=url;redirects=[]
  try:
   for _ in range(4):
    try:raw,r=client.get(url,document=True);break
    except RuntimeError as e:
     found=re.search(r'HTTP failure (?:301|302|307|308); request ([0-9a-f]+)',str(e))
     if not found:raise
     rec=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(found[1],)).fetchone()[0]);redirects.append(rec['request_id']);url=urljoin(url,rec['location']);assert urlsplit(url).hostname in HOSTS and urlsplit(url).scheme=='https'
   else:raise ValueError('Too many official redirects')
   soup=BeautifulSoup(raw,'html.parser');text=soup.get_text(' ',strip=True);bio=json.loads(db.execute('SELECT body FROM _epl_people_biographies WHERE person_key=?',(key,)).fetchone()[0]);present=literal in text;matched=present and bio['birth_date']==expected;checks.append(dict(person_key=key,person_name=bio['person_name'],public_url=url,original_url=original,redirect_request_ids=redirects,request_id=r['request_id'],raw_value=literal if present else None,normalized_value=bio['birth_date'],matches=matched,discrepancy=None if matched else 'Current public page does not expose the expected birth-date text',biography_resolution=bio.get('birth_date_resolution')))
  except Exception as e:checks.append(dict(person_key=key,public_url=url,matches=False,error=str(e)))
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING' if all(x['matches'] for x in checks) else 'PARTIALLY WORKING',scope='Two independent club-page checks, not all biographies',examples=checks,new_requests=client.requests);(ROOT/'reports/epl_biography_public_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));db.close()

if __name__=='__main__':main()
