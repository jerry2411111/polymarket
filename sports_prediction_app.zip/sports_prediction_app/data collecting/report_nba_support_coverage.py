"""Inventory actual NBA result files and report every missing exported field."""
import collections, csv, datetime as dt, json, sqlite3
from urllib.parse import urlsplit
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT

def main():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    tables = []
    for path in sorted((ROOT / 'data/result/nba').glob('*.parquet')):
        pf = pq.ParquetFile(path)
        counts = collections.Counter()
        n = 0
        for batch in pf.iter_batches(batch_size=10000):
            n += batch.num_rows
            for name, col in zip(batch.schema.names, batch.columns):
                counts[name] += col.null_count
        assert n == pf.metadata.num_rows
        tables.append(dict(name=path.stem, rows=n, columns=len(pf.schema_arrow.names), parquet=str(path.relative_to(ROOT)), csv=str(path.with_suffix('.csv').relative_to(ROOT)), fields=[dict(column=c, type=str(pf.schema_arrow.field(c).type), missing=counts[c], total=n, missing_pct=round(100 * counts[c] / n, 4) if n else None) for c in pf.schema_arrow.names]))
    selected = {g for g, in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='NBA' UNION SELECT game_id FROM kalshi_pre_match WHERE league='NBA'")}
    result = dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(), status='PARTIALLY WORKING', collection_start='2024-01-01', collection_end='2026-09-14', selected_unique_nba_games=len(selected), tables=tables, critical_limitations=['All exported date rows are derived from the collected game sample, not every official NBA game.', 'Dated profile rows include roster-only players; performance rows require at least one actual played appearance.', '970 native IDs include temporary league identifiers and are not guaranteed to represent 970 distinct humans.', 'Career-wide team counts and complete historical injury episode counts remain unavailable; a source report is not necessarily a new injury episode.', 'Coach game attribution is missing for 146 of 5534 team-games, all in Summer League or All-Star programs.', 'Ten independent major-media lists per league and fresh quarterly publisher editions remain incomplete.', 'The original Desktop project still exists. Migration and obsolete-file removal wait for the complete verified replacement.'])
    for name in ['nba_coverage', 'nba_dated_profiles', 'nba_weather_validation', 'nba_rankings_validation', 'nba_main_validation']:
        p = ROOT / 'reports' / (name + '.json')
        result[name] = json.loads(p.read_text(encoding='utf-8'))
    domains = collections.Counter((urlsplit(json.loads(r['metadata_json'])['endpoint']).hostname for r in db.execute('SELECT metadata_json FROM _request_audit')))
    result['requests_logged_all_leagues'] = sum(domains.values())
    result['request_domains_all_leagues'] = dict(domains)
    result['api_credit_usage'] = 'Not exposed by these public response records; do not infer billing credits from request count.'
    (ROOT / 'reports/nba_support_coverage.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    with (ROOT / 'reports/nba_support_missing_fields.csv').open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['table', 'column', 'type', 'missing', 'total', 'missing_pct'])
        w.writeheader()
        for t in tables:
            for c in t['fields']:
                w.writerow(dict(table=t['name'], **c))
    lines = ['# NBA tables: verified structure and remaining coverage', '', f'As of this report, {len(selected):,} distinct NBA games have some provider odds. Coverage window: 2024-01-01 through 2026-09-14. **PARTIALLY WORKING** means the tested pipeline works but requested source coverage is incomplete.', '', '| Export | Rows | Columns | Meaning |', '|---|---:|---:|---|']
    meanings = {'player_profiles': 'One documented player profile for one date; roster-only players included.', 'player_current_team': 'Dated last documented team membership.', 'player_performance': 'One player with played appearances, cumulative through one date.', 'manager_profiles': 'One dated head-coach identity, history and tenure profile.', 'manager_performance': 'One coach with attributed games, cumulative through one date.', 'team_history': 'One team, cumulative collected game performance through one date.', 'player_rankings_quarterly': 'One player/publisher at a research cutoff; carried editions retain their source date.'}
    for t in tables:
        lines.append(f"| {t['name']} | {t['rows']:,} | {t['columns']} | {meanings.get(t['name'], 'Published nonfinancial research fields.')} |")
    lines += ['', '', '', '## Remaining limitations', ''] + ['- ' + s for s in result['critical_limitations']]
    lines += ['', '## Missing fields by export', '', '| Table | Field | Missing / rows | Missing % |', '|---|---|---:|---:|']
    for t in tables:
        for c in t['fields']:
            if c['missing']:
                lines.append(f"| {t['name']} | {c['column']} | {c['missing']:,} / {c['total']:,} | {c['missing_pct']} |")
    (ROOT / 'reports/nba_support_coverage.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    db.close()
    print(json.dumps(dict(status=result['status'], nba_games=len(selected), exports=[{k: t[k] for k in ['name', 'rows', 'columns']} for t in tables], requests_logged=result['requests_logged_all_leagues'])))
if __name__ == '__main__':
    main()
