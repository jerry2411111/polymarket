"""Date-bounded research SQL. No current statistics are backfilled into history."""

PUBLISHERS=['espn','cbs_sports','sports_illustrated','bleacher_report','sporting_news','the_ringer','the_athletic','nbc_sports','yahoo_sports','fox_sports','mlb_network','nhl_network','sportsnet','tsn','the_hockey_news','hoopshype','action_network','usa_today','goal','france_football']
FLAGS=[f'{p}_top_{n}' for p in PUBLISHERS for n in [5,10,20,50]]
PUBLIC_PLAYER=['player_id','player_name','game_type','league','team','as_of_date','games_played','overall_winrate','average_score_per_game','std_score_per_game','average_assists_per_game','std_assists_per_game','average_minutes_per_game','std_minutes_per_game','score_z_score','starter_percentage_overall']
PLAYER_OUTPUT=PUBLIC_PLAYER+['performance_status']
PLAYER_STATUS_SQL="CASE WHEN p.games_played=0 THEN 'insufficient matches' ELSE 'observed matches' END AS performance_status"

def moment(c):
    return f'''avg({c}) AS average_{c}_per_game,
    CASE WHEN count({c})>1 THEN sqrt(max(0.0,
    (sum({c}*{c})-sum({c})*sum({c})/count({c}))/(count({c})-1))) END AS std_{c}_per_game'''

PLAYER_BASE='''WITH bounded AS (
 SELECT * FROM _player_game_results WHERE game_date>=:collection_start AND game_date<=:query_date
), names AS (
 SELECT player_id,league,player_name,row_number() OVER
 (PARTITION BY player_id,league ORDER BY game_date DESC,game_id DESC) AS recency FROM bounded
), moments AS (
 SELECT player_id,game_type,league,count(*) AS games_played,avg(win) AS overall_winrate,
 '''+','.join(moment(c) for c in ['score','assists','minutes'])+''',
 avg(starter) AS starter_percentage_overall
 FROM bounded GROUP BY player_id,game_type,league
), cohort AS (
 SELECT league,avg(average_score_per_game) AS mu,
 sqrt(max(0.0,avg(average_score_per_game*average_score_per_game)-avg(average_score_per_game)*avg(average_score_per_game))) AS sigma
 FROM moments WHERE average_score_per_game IS NOT NULL GROUP BY league
)
SELECT m.player_id,n.player_name,m.game_type,m.league,
 (SELECT team_name FROM _player_affiliation_observations b WHERE b.player_id=m.player_id
   AND b.league=m.league AND b.is_temporary=0 AND b.observed_date<=:query_date
   ORDER BY b.observed_date DESC,b.observation_id DESC LIMIT 1) AS team,
 :query_date AS as_of_date,m.games_played,m.overall_winrate,
 m.average_score_per_game,m.std_score_per_game,m.average_assists_per_game,m.std_assists_per_game,
 m.average_minutes_per_game,m.std_minutes_per_game,
 CASE WHEN c.sigma>0 THEN (m.average_score_per_game-c.mu)/c.sigma END AS score_z_score,
 m.starter_percentage_overall
FROM moments m JOIN names n ON n.player_id=m.player_id AND n.league=m.league AND n.recency=1
LEFT JOIN cohort c ON c.league=m.league'''

def ranked(base,flags=None,use_policy=None):
    from ranking_policy import active_flags,policy_exists
    if flags is None:flags=active_flags(fallback=FLAGS)
    if use_policy is None:use_policy=policy_exists()
    quarter='(SELECT max(as_of_date) FROM _ranking_snapshot_dates WHERE as_of_date<=p.as_of_date)'
    expressions=['CASE WHEN rc.'+c+'=1 THEN COALESCE(r.'+c+',0) END AS '+c if use_policy else 'r.'+c for c in flags]
    sql='SELECT '+','.join(['p.'+c for c in PUBLIC_PLAYER]+[PLAYER_STATUS_SQL]+expressions)+' FROM ('+base+') p LEFT JOIN _player_ranking_flags_canonical r ON r.player_id=p.player_id AND r.league=p.league AND r.as_of_date='+quarter
    if use_policy:sql+=' LEFT JOIN _ranking_publisher_coverage rc ON rc.league=p.league AND rc.as_of_date='+quarter
    return sql

from no_observation_policy import include_unobserved_player
PLAYER_SQL=ranked(include_unobserved_player(PLAYER_BASE,parameterized=True))+' ORDER BY p.league,p.player_name'
TEAM_SQL='''WITH totals AS (
 SELECT CASE WHEN league='NHL' AND team_name IN ('Utah Hockey Club','Utah Mammoth')
 THEN CASE WHEN :query_date<'2025-05-07' THEN 'Utah Hockey Club' ELSE 'Utah Mammoth' END
 ELSE team_name END AS team_name,game_type,league,count(*) AS games_played,avg(win) AS winrate,
 sum(home_away='Home') AS home_times,sum(home_away='Away') AS away_times,
 avg(score_for-score_against) AS average_score_margin
 FROM _team_game_results WHERE game_date>=:collection_start AND game_date<=:query_date
 GROUP BY CASE WHEN league='NHL' AND team_name IN ('Utah Hockey Club','Utah Mammoth') THEN '_NHL_UTAH_' ELSE team_name END,game_type,league
), dated AS (
 SELECT *, :query_date AS as_of_date FROM totals
)
SELECT t.team_name,t.game_type,t.league,t.as_of_date,t.winrate,t.games_played,
 t.home_times,t.away_times,t.average_score_margin
FROM dated t
ORDER BY t.league,t.team_name'''

MANAGER_SQL='''SELECT manager_id,manager_name,game_type,league,:query_date AS as_of_date,
 count(*) AS games_played,avg(win) AS overall_winrate,
 sum(home_away='Home') AS home_times,sum(home_away='Away') AS away_times,
 avg(score_for-score_against) AS average_score_margin
FROM _manager_game_results WHERE game_date>=:collection_start AND game_date<=:query_date
GROUP BY manager_id,manager_name,game_type,league'''
MANAGER_SQL='''WITH observed AS ('''+MANAGER_SQL+''') SELECT p.manager_id,p.manager_name,p.game_type,p.league,p.as_of_date,
coalesce(m.games_played,0) AS games_played,coalesce(m.overall_winrate,0.0) AS overall_winrate,coalesce(m.home_times,0) AS home_times,coalesce(m.away_times,0) AS away_times,coalesce(m.average_score_margin,0.0) AS average_score_margin
FROM manager_profiles p LEFT JOIN observed m ON m.manager_id=p.manager_id AND m.league=p.league WHERE p.as_of_date=:query_date ORDER BY p.league,p.manager_name'''
QUERIES={'player_performance':PLAYER_SQL,'team_history':TEAM_SQL,'manager_performance':MANAGER_SQL}
