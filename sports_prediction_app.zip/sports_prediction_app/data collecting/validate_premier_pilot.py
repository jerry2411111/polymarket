"""Validate three league-authored match reports, raw values, participants and break clocks."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from zoneinfo import ZoneInfo
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB);checks=collections.Counter();cache={};examples=[]
    def raw(rid,document=False):
        if rid not in cache:
            r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert r['status']==200 and hashlib.sha256(b).hexdigest()==r['sha256'];cache[rid]=(b,r);checks['raw_source_hashes']+=1
        b,r=cache[rid];return (b if document else json.loads(b)),r
    for mid,body in db.execute("SELECT * FROM _official_epl_game_reports WHERE match_id IN ('2367731','2367736','2367742')"):
        g=json.loads(body);schedule=g['schedule'];match,mr=raw(g['sources']['match']['request_id']);assert match==g['sources']['match']['data'];assert mid==match['matchId']==schedule['matchId']
        for field in ['homeTeam','awayTeam','kickoff','kickoffTimezone','kickoffTimezoneString','ground','competitionId','period']:
            assert match[field]==schedule[field];checks['schedule_to_match_fields']+=1
        local=dt.datetime.fromisoformat(match['kickoff']).replace(tzinfo=ZoneInfo(match['kickoffTimezoneString']));assert local.tzname()==match['kickoffTimezone'];home,away=match['homeTeam'],match['awayTeam'];assert home['id']!=away['id']
        lineups,_=raw(g['sources']['lineups']['request_id']);allids=set()
        for key,team in [('home_team',home),('away_team',away)]:
            lineup=lineups[key];assert lineup['teamId']==team['id'];ids=[p['id'] for p in lineup['players']];assert len(ids)==len(set(ids)) and not allids.intersection(ids);allids.update(ids);starters=[pid for row in lineup['formation']['lineup'] for pid in row];assert len(starters)==11 and len(set(starters))==11 and set(starters)<=set(ids);assert all(p.get('firstName') or p.get('knownName') for p in lineup['players']);assert lineup['managers'] and all(p['id'] and p['firstName'] and p['lastName'] for p in lineup['managers']);checks['native_roster_and_starting_lineup']+=len(ids)
        commentary=[]
        for c in g['commentary_complete']['rows']:
            response,_=raw(c['request_id']);assert response['data'][int(c['pointer'].rsplit('/',1)[-1])]==c['raw'];commentary.append(c['raw']);checks['raw_commentary_value']+=1
        assert g['commentary_complete']['pagination_exhausted'];last,_=raw(g['commentary_complete']['request_ids'][-1]);assert not last['pagination'].get('_next')
        def one(text):
            vals=[c for c in commentary if c['comment'].startswith(text)];assert len(vals)==1,(mid,text,len(vals));return vals[0]
        start=one('First Half begins');half=one('First Half ends');resume=one('Second Half begins');finish=one('Second Half ends')
        scores=lambda a,b:home['name']+' '+str(a)+', '+away['name']+' '+str(b)
        assert scores(home['halfTimeScore'],away['halfTimeScore']) in half['comment'] and scores(home['halfTimeScore'],away['halfTimeScore']) in resume['comment'];assert scores(home['score'],away['score']) in finish['comment'];checks['independent_commentary_scores']+=3
        clocks=[dt.datetime.fromisoformat(c['timestamp']).replace(tzinfo=dt.UTC) for c in [start,half,resume,finish]];assert clocks==sorted(clocks) and 5*60<(clocks[2]-clocks[1]).total_seconds()<30*60 and abs((clocks[0]-local.astimezone(dt.UTC)).total_seconds())<10*60
        # Explicitly offset event clocks independently check the UTC interpretation
        # of commentary times; do not infer timezone from the host machine.
        events,_=raw(g['sources']['events']['request_id']);event_stamps=[]
        def walk(x):
            if isinstance(x,dict):
                if isinstance(x.get('timestamp'),str) and re.fullmatch(r'\d{8}T\d{6}[+-]\d{4}',x['timestamp']):event_stamps.append(dt.datetime.strptime(x['timestamp'],'%Y%m%dT%H%M%S%z').astimezone(dt.UTC))
                for value in x.values():walk(value)
            elif isinstance(x,list):
                for value in x:walk(value)
        walk(events);comment_stamps={dt.datetime.fromisoformat(c['timestamp']).replace(tzinfo=dt.UTC) for c in commentary};matches=sum(t in comment_stamps for t in event_stamps);assert matches>=1,(mid,'No independently offset clock match');checks['explicit_utc_event_clock_matches']+=matches
        page,pr=raw(g['public_page']['request_id'],True);soup=BeautifulSoup(page,'html.parser');title=soup.title.get_text();assert home['name'] in title and away['name'] in title;checks['official_public_page_identity']+=1
        article,ar=raw(g['independent_report']['request_id'],True);text=BeautifulSoup(article,'html.parser').get_text(' ',strip=True);text=text.replace('–','-').replace('−','-');assert local.strftime('%d %b %Y') in text
        if mid=='2367731':assert '4-2 win over Newcastle United' in text and 'All six goals at Anfield' in text
        elif mid=='2367736':assert 'goalless draw at London Stadium' in text
        elif mid=='2367742':assert 'drew 1-1 at Turf Moor' in text and 'first-half strike gave Burnley the lead' in text
        else:raise AssertionError('A new pilot example needs an independently reviewed article')
        checks['independent_league_article_result_and_date']+=1
        winner='Draw' if home['score']==away['score'] else home['name'] if home['score']>away['score'] else away['name'];examples.append(dict(provider='Official Premier League',endpoint=mr['endpoint'],parameters=mr['parameters'],retrieved_at_utc=mr['retrieved_at_utc'],match_id=mid,match=home['name']+' / '+away['name'],scheduled_start_utc=local.astimezone(dt.UTC).isoformat(),actual_opening_utc=clocks[0].isoformat(),halftime_start_utc=clocks[1].isoformat(),second_half_start_utc=clocks[2].isoformat(),regulation_end_utc=clocks[3].isoformat(),raw_final_score=[home['score'],away['score']],normalized_final_score=[home['score'],away['score']],halftime_score=[home['halfTimeScore'],away['halfTimeScore']],winner=winner,public_url=g['public_page']['url'],independent_report_url=g['independent_report']['url'],values_match=True))
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',checks=dict(checks),examples=examples,limitations=['These January 2024 matches validate the official game connector, not market/quote availability.','No historical player performance totals have been backfilled from present-day cumulative leaderboards.','Empty timeline arrays are preserved; paginated official commentary supplies break clocks.','The three pilot dates are in GMT; daylight-saving dates require an additional cross-check.']);(ROOT/'reports/epl_official_pilot_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
