"""Verify real break-window responses before expanding date batches."""
import collections,datetime as dt,json,math,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources
from eu_verified_details import details
from probe_history import ROOT
from core import utc,odd

db=sqlite3.connect(DB);db.execute('BEGIN');src=Sources(db);ds=details(db);contracts={(p,cid):json.loads(b) for p,cid,b in db.execute('SELECT provider,contract_id,body FROM _eu_validated_contracts')};counts=collections.Counter();examples=[]
for b, in db.execute("SELECT body FROM _eu_price_acquisition WHERE json_extract(body,'$.mode')='break'"):
 j=json.loads(b);c=contracts[j['provider'],j['contract_id']]
 if not c['game_id'].split('_')[1].startswith('202509'):continue
 assert j['status']=='ok';clock=ds[j['competition'],j['official_match_id']]['clock'];label=j['checkpoint'];lo=utc(clock[{'START':'actual_start_utc','HALFTIME':'halftime_start_utc','SECOND_HALF_START':'second_half_start_utc'}[label]]).timestamp();hi=utc(clock['second_half_start_utc']).timestamp() if label=='HALFTIME' else lo+120;eligible=[]
 for rid in j['request_ids']:
  raw,r=src.get(rid);params=r['parameters'];assert params.get('start_ts',params.get('start'))==j['start_ts'] and params.get('end_ts',params.get('end'))==j['end_ts']
  if j['provider']=='kalshi':
   assert raw['ticker']==c['contract_id'] and params['period_interval']==1
   field='close' if '/historical/' in r['endpoint'] else 'close_dollars'
   for i,v in enumerate(raw['candlesticks']):
    p=v.get('yes_bid',{}).get(field);ask=v.get('yes_ask',{}).get(field)
    if p is None:continue
    p=float(p);assert 0<=p<=1 and (ask is None or p<=float(ask));counts['real_candle_values']+=1
    if lo<=v['end_period_ts']<hi:eligible.append((v['end_period_ts'],p,rid,f'/candlesticks/{i}/yes_bid/{field}'))
  else:
   assert params['token_id']==c['contract_id']
   for i,v in enumerate(raw['data']):
    p=v['price'];assert 0<=p<=1;counts['real_polymarket_values']+=1;t=v['timestamp'];res=v['resolution_seconds']
    if res>0 and lo<=t<hi and t+res<=hi and t>=params['start'] and t+res<=params['end']:eligible.append((t+res,p,rid,f'/data/{i}/price'))
 counts[j['provider']+'_windows']+=1
 if eligible:
  x=min(eligible);counts[j['provider']+'_usable_windows']+=1;assert odd(x[1]) is None if x[1]==0 else math.isclose(odd(x[1]),1/x[1],rel_tol=1e-14)
  if len(examples)<15:examples.append(dict(game_id=j['game_id'],competition=j['competition'],provider=j['provider'],contract_id=j['contract_id'],outcome_side=c['side'],checkpoint=label,window_start_utc=utc(lo).isoformat(),window_end_utc=utc(hi).isoformat(),quote_time_utc=utc(x[0]).isoformat(),probability=x[1],decimal_odds=odd(x[1]),request_id=x[2],pointer=x[3]))
assert counts['kalshi_usable_windows']>=9 and len({e['game_id'] for e in examples})>=2
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Small actual-response pilot; successful validation does not imply historical completeness',checks=dict(counts),source_hashes=len(src.cache),examples=examples);(ROOT/'reports/eu_break_pilot_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='examples'}));db.close()
