﻿import json,re
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
HOSTS.add('baseballsavant.mlb.com');b,r=HistoryClient().get('https://baseballsavant.mlb.com/gamefeed',dict(date='4/16/2025',gamePk=778297,sportId=1),document=True);s=BeautifulSoup(b,'html.parser');print('SOURCE',r['request_id'],'BYTES',len(b),'TABLES',len(s.find_all('table')))
for i,t in enumerate(s.find_all('script')):
 text=t.string or t.get_text()
 if len(text)>100:print('SCRIPT',i,t.get('id'),len(text),text[:150])
print('SCRIPTLINKS',[t['src'] for t in s.find_all('script',src=True) if 'game' in t['src']])
