"""Follow official SMHI hypermedia links; inspect available Stockholm archives."""
import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def json_url(obj):
    return next(x['href'] for x in obj['link'] if x.get('type')=='application/json')

def main():
    HOSTS.update({'opendata-download-metobs.smhi.se','www.smhi.se'})
    c=HistoryClient();root=json.loads((ROOT/'reports/smhi_current_documentation.json').read_text())
    out=[]
    for resource in root['metadata']['resource']:
        if str(resource['key']) not in ['1','6','3','13']:continue
        d,r=c.get(json_url(resource));stations=[x for x in d.get('station',[]) if any(n in x.get('name','').casefold() for n in ['stockholm','bromma','arlanda'])]
        item=dict(parameter=resource['key'],title=resource['title'],summary=resource['summary'],unit=resource['unit'],parameter_request_id=r['request_id'],stations=stations)
        print(json.dumps(item,ensure_ascii=False),flush=True)
        item['station_metadata']=[]
        for station in stations:
            if not station.get('active'):continue
            v,vr=c.get(json_url(station));entry=dict(station_id=station['id'],request_id=vr['request_id'],metadata=v);item['station_metadata'].append(entry)
            print('PERIODS',resource['key'],station['name'],json.dumps(v.get('period',[]),ensure_ascii=False),flush=True)
        out.append(item)
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),parameters=out,new_requests=c.requests)
    (ROOT/'reports/smhi_station_metadata.json').write_text(json.dumps(report,indent=2),encoding='utf-8')

if __name__=='__main__':main()
