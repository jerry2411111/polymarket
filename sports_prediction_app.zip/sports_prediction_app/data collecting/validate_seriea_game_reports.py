"""Independently verify retained Serie A reports, source clocks and halftime scores."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources,pointer
from probe_history import ROOT
from core import utc

def main():
 db=sqlite3.connect(DB,timeout=60);db.execute('BEGIN');src=Sources(db);games={mid:json.loads(b) for mid,b in db.execute('SELECT * FROM _official_seriea_calendar')};checks=collections.Counter();missing=collections.Counter();issues=[];details=[]
 for mid,b in db.execute('SELECT * FROM _official_seriea_game_reports'):
  row=json.loads(b)
  if row['status']!='ok':issues.append(dict(match_id=mid,reason=row.get('error')));continue
  g=games[mid];ss=row['sources'];d=row['derived'];clock=d['clock']
  for kind,s in ss.items():
   raw,r=src.get(s['request_id']);assert raw==s['data'] and raw['matchId']==mid;assert r['endpoint'].endswith('/'+kind);checks['exact_raw_response']+=1
  events=ss['feed']['data']['events'];p=ss['feed']['data']['pagination'];assert p==dict(totalPages=1,currentPage=1,isLastPage=True);checks['complete_feed_pagination']+=1
  for side in ['away','home']:
   lineup=ss['lineups']['data'][side];assert lineup['teamId']==g[side]['id'];xs=lineup['fielded']+lineup['benched'];assert len(xs)==len({x['playerId'] for x in xs});assert 0<=len(lineup['fielded'])<=11,(mid,side,len(lineup['fielded']));checks['roster_people']+=len(xs);checks['head_coaches']+=sum(x['roleLabel']=='Head Coach' for x in lineup['staff'])
   if len(lineup['fielded'])!=11:missing['incomplete_starting_lineup_sides']+=1
  for field,ts in clock.items():
   if ts is None:missing[field]+=1;continue
   proof=d['clock_proofs'][field];raw=pointer(ss['feed']['data'],proof['pointer']);assert raw==proof['raw'] and utc(raw)==utc(ts);checks['exact_phase_clock']+=1
  if all(clock.values()):
   ts=[utc(clock[k]) for k in ['actual_start_utc','halftime_start_utc','second_half_start_utc','regulation_end_utc']];assert ts==sorted(ts) and abs((ts[0]-utc(g['scheduled_start_utc'])).total_seconds())<6*3600;checks['ordered_clock']+=1
  # providerHomeScore/providerAwayScore repeat the final result on older
  # events. ScorePush is the timestamp-specific score displayed by the feed.
  for e in events:
   if e['type'] in ['full-time','end-second-half']:
    score=[e[s+'ScorePush'] for s in ['away','home']]
    if score!=g['scores'] and d['final_score_verified']:
     goals=d['goal_reconciliation'];count=[0,0];second=[0,0]
     for proof in goals['goal_proofs']:
      event=pointer(ss['feed']['data'],proof['pointer']);assert event['eventId']==proof['event_id'] and event['type'] in ['goal','penalty-goal','own-goal'];count[proof['side']]+=1
      if proof['phase']=='SecondHalf':second[proof['side']]+=1
     assert count==g['scores'] and score==second;checks['resolved_period_only_score_fields']+=1
    if d['final_score_verified']:checks['official_final_score']+=1
    else:assert d['halftime_scores'] is None and d['issues'];checks['quarantined_event_score']+=1
   if e['type']=='first-half':
    if [e[s+'ScorePush'] for s in ['away','home']]==[0,0]:checks['official_start_score']+=1
    else:assert clock['actual_start_utc'] is None and d['issues'];checks['quarantined_opening_event_score']+=1
   if e['type']=='half-time-break' and d['halftime_scores'] is not None:assert [e[s+'ScorePush'] for s in ['away','home']]==d['halftime_scores'];checks['official_halftime_score']+=1
  if d['halftime_scores'] is None:missing['halftime_score']+=1
  issues.extend(dict(match_id=mid,**x) for x in d['issues'])
  details.append(('SEA',mid,json.dumps(dict(competition='SEA',official_match_id=mid,date=g['date'],clock=clock,clock_proofs=d['clock_proofs'],halftime_scores=d['halftime_scores'],scores=g['scores'],location=g['location'],city=g['city']))));checks['games']+=1
 db.commit()
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _eu_official_game_details (competition TEXT NOT NULL,match_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(competition,match_id)) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_official_game_details VALUES (?,?,?)',details)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING' if not issues else 'PARTIALLY WORKING',scope='Source equality, game identity, explicit final/halftime scores and phase clocks; player aggregate validation is separate',checks=dict(checks),missing=dict(missing),issues=issues,source_hashes=len(src.cache));(ROOT/'reports/seriea_game_reports_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='issues'}),flush=True);print('ISSUES',len(issues),'AFFECTED GAMES',len({i['match_id'] for i in issues}),flush=True);db.close()

if __name__=='__main__':main()
