"""Measured checkpoint coverage from the published selection audit."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

db=sqlite3.connect(DB);rows=[json.loads(b) for b, in db.execute("SELECT body FROM _history_selections WHERE json_extract(body,'$.game_id') LIKE 'MLB_%'")];out={}
for provider in ['polymarket','kalshi']:
    selected=[r for r in rows if r['provider']==provider];games=collections.defaultdict(list);checkpoints=[]
    for r in selected:
        if r['target'].startswith('ingame_'):games[r['game_id']].append(r)
    for n,label in enumerate(['Start','Inning3','Inning5','Inning7']):
        rs=[r for r in selected if r['target']=='ingame_'+str(n)];missing=sum(r['normalized_price'] is None for r in rs)
        checkpoints.append(dict(checkpoint=label,team_probability_values=len(rs),missing=missing,missing_percentage=round(missing*100/len(rs),4),present=len(rs)-missing,zero_probability_with_null_decimal_odds=sum(r['normalized_price']==0 for r in rs)))
    ages=sorted(r['source_age_seconds']/3600 for r in selected if r['target']=='pre_0' and r['normalized_price'] is not None)
    out[provider]=dict(games=len(games),games_with_all_four_checkpoints_both_teams=sum(len(rs)==8 and all(r['normalized_price'] is not None for r in rs) for rs in games.values()),games_with_any_in_game_value=sum(any(r['normalized_price'] is not None for r in rs) for rs in games.values()),checkpoint_coverage=checkpoints,pre_0_source_age_hours=dict(minimum=min(ages),median=ages[len(ages)//2],maximum=max(ages)))
report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',meaning='All planned MLB break requests completed and rebuilt values passed independent checks. Coverage percentages describe missing probability values, not request failures; one game has two team values per checkpoint.',providers=out)
(ROOT/'reports/mlb_checkpoint_coverage.json').write_text(json.dumps(report,indent=2),encoding='utf-8');lines=['# Published MLB checkpoint coverage','',report['meaning'],'','| Provider | Checkpoint | Values | Missing | Missing % |','|---|---|---:|---:|---:|']
for provider,p in out.items():
    for r in p['checkpoint_coverage']:lines.append(f"| {provider} | {r['checkpoint']} | {r['team_probability_values']} | {r['missing']} | {r['missing_percentage']} |")
(ROOT/'reports/mlb_checkpoint_coverage.md').write_text('\n'.join(lines)+'\n',encoding='utf-8');print(json.dumps(report));db.close()
