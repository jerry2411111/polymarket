"""Public publisher flags: dated observed membership; unlisted becomes false.

The original ranking facts/cache remain unchanged. A false public flag means
not recorded in that publisher's acquired eligible top-N evidence, following
the user's convention; it does not prove completeness of a media list.
"""
import sqlite3
from build_history_catalog import DB


def refresh_policy(db, flags):
    db.execute('CREATE TABLE IF NOT EXISTS _ranking_public_columns (league TEXT,column_name TEXT,observed_values INTEGER,PRIMARY KEY(league,column_name)) STRICT')
    db.execute('DELETE FROM _ranking_public_columns')
    names = ','.join('COUNT("'+c+'")' for c in flags)
    for row in db.execute('SELECT league,'+names+' FROM _ranking_canonical_cache GROUP BY league').fetchall():
        db.executemany('INSERT INTO _ranking_public_columns VALUES (?,?,?)',[(row[0],c,n) for c,n in zip(flags,row[1:])])
    db.execute('DROP TABLE IF EXISTS _ranking_publisher_coverage')
    db.execute('CREATE TABLE _ranking_publisher_coverage (as_of_date TEXT,league TEXT,'+','.join('"'+c+'" INTEGER NOT NULL' for c in flags)+',PRIMARY KEY(as_of_date,league)) STRICT')
    db.execute('INSERT INTO _ranking_publisher_coverage SELECT as_of_date,league,'+','.join('MAX("'+c+'" IS NOT NULL)' for c in flags)+' FROM _ranking_canonical_cache GROUP BY as_of_date,league')


def active_flags(db=None, league=None, fallback=()):
    own = db is None
    if own:
        db = sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True)
    try:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='_ranking_public_columns'").fetchone():
            return list(fallback)
        sql='SELECT DISTINCT column_name FROM _ranking_public_columns WHERE observed_values>0'
        args=[]
        if league:
            sql+=' AND league=?';args=[league]
        keep={r[0] for r in db.execute(sql,args)}
        return [c for c in fallback if c in keep]
    finally:
        if own:db.close()


def policy_exists():
    db=sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True)
    try:return bool(db.execute("SELECT 1 FROM sqlite_master WHERE name='_ranking_publisher_coverage'").fetchone())
    finally:db.close()
