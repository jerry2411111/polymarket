"""Test the unauthenticated official transaction route against MLB's dated page.

The public site uses a server-rendered transaction route, and partner reference
documentation is login gated. This is a small API probe, not a claim that the
private reference was accessible. Publication date and effective date remain
distinct to avoid projecting later injury announcements into earlier features.
"""
import datetime as dt,json
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT
c=HistoryClient();out=[]
for day in ['2024-07-30','2025-05-18','2026-07-31']:
    d,r=c.get('https://statsapi.mlb.com/api/v1/transactions',dict(date=day,sportId=1));assert isinstance(d.get('transactions'),list)
    b,pr=c.get('https://www.mlb.com/transactions/'+day.replace('-','/'),document=True);soup=BeautifulSoup(b,'html.parser');node=soup.find(id='transactions');assert node
    page=node.get_text(' ',strip=True);items=d['transactions'];matches=[]
    for i,x in enumerate(items):
        text=x.get('description')
        if text and text in page:matches.append(dict(transaction_id=x['id'],person=x.get('person'),date=x.get('date'),effective_date=x.get('effectiveDate'),type=x.get('typeCode'),description=text,pointer='/transactions/'+str(i)))
    assert matches,'No API transaction text matches official public date page'
    row=dict(date=day,status='WORKING',api_request_id=r['request_id'],public_request_id=pr['request_id'],api_rows=len(items),matched_public_examples=len(matches),examples=matches[:3],date_values=sorted({x.get('date','')[:10] for x in items}));out.append(row);print(json.dumps(row),flush=True)
report=dict(checked_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Three public API dates validated against official MLB dated transaction pages; API may include minor-league affiliates, so league filtering requires official team identity',documentation_limitation='Partner API reference is Okta-gated; public-site request/client investigation and direct returned schema recorded, without private documentation access',examples=out)
(ROOT/'reports/mlb_transactions_api_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
