import json,re
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
HOSTS.update({'baseballsavant.mlb.com','builds.mlbstatic.com','www.mlb.com'})
c=HistoryClient();out=[]
for url in ['https://baseballsavant.mlb.com/savant-player/aaron-judge-592450','https://www.mlb.com/transactions/2025/05/18']:
    b,r=c.get(url,document=True);s=b.decode('utf-8');soup=BeautifulSoup(b,'html.parser');scripts=[urljoin(url,x['src']) for x in soup.select('script[src]')]
    hits=[]
    for word in ['transactions','statsapi','hydrate','bootstrap']:
        hits.extend(s[max(0,m.start()-100):m.start()+450] for m in list(re.finditer(word,s,re.I))[:6])
    out.append(dict(url=url,request_id=r['request_id'],scripts=scripts,hits=hits));print(json.dumps(out[-1]))
(ROOT/'reports/mlb_player_public_client_probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
