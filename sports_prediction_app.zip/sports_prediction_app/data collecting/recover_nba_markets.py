"""Recover NBA winner markets using official league identity/result checks.

This revisits stored API metadata rejected when provider scores or duplicate
market families were the only matching evidence. All candidate native IDs stay
in the audit; the output selects one coherent family per game and provider.
"""
import collections,json,re,sqlite3
from history_index import index,records
from build_history_catalog import DB,clean,team_name,short
from probe_history import ROOT
from core import array,utc
from nba_identity import canonical_ids,special_teams

def main():
    data=index();rs={r['request_id']:r for r in records()};db=sqlite3.connect(DB,timeout=60)
    existing={i for (i,) in db.execute('SELECT id FROM _history_contracts')};gs={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _history_games')}
    cards=[json.loads(b) for (b,) in db.execute('SELECT body FROM _official_nba_schedule')];card_index=collections.defaultdict(list);aliases=collections.defaultdict(set);teams={}
    for tid,(t,_,_) in data['teams'].items():
        if t['details'].get('league')!='NBA':continue
        d=t['details'];code=short(t)
        if not code:continue
        teams[code]=(tid,team_name(t))
        for s in [t['name'],d.get('team_name'),d.get('short_name'),code,team_name(t),re.sub(r'^[A-Z]{2,3} ','',d.get('team_name',''))]:
            if s:aliases[clean(s)].add(code)
    aliases[clean('Twolves')].add('MIN');aliases[clean('PHO')].add('PHX')
    special=special_teams(db);canonical=canonical_ids(cards)
    for code,s in special.items():
        teams[code]=('NBA:'+s['official_team_id'],s['full_name'])
        for label in [s['full_name'],'Team '+s['full_name'],code]:aliases[clean(label)].add(code)
    for c in cards:
        if all(c['team_tricodes']):card_index[frozenset(c['team_tricodes'])].append(c)
    added=[];newgames={};audit=[]
    for eid,(e,rid,ptr) in data['polymarket_events'].items():
        if str(rs[rid]['parameters'].get('tag_id'))!='745':continue
        for mi,m in enumerate(e.get('markets',[])):
            if m.get('sportsMarketType')!='moneyline':continue
            labels=array(m.get('outcomes',[]));tokens=array(m.get('clobTokenIds',[]));values=array(m.get('outcomePrices',[]))
            if len(tokens)!=2 or len(labels)!=2 or sorted(map(float,values or []))!=[0.,1.] or set(tokens)<=existing:continue
            al=[aliases[clean(v)] for v in labels]
            if any(len(a)!=1 for a in al):continue
            codes=[next(iter(a)) for a in al];t=utc(m.get('gameStartTime') or e.get('startTime'))
            if t is None:continue
            matches=[c for c in card_index[frozenset(codes)] if c.get('start_utc') and abs((utc(c['start_utc'])-t).total_seconds())<=6*3600]
            if len(matches)>1:
                matches.sort(key=lambda c:abs((utc(c['start_utc'])-t).total_seconds()))
                distances=[abs((utc(c['start_utc'])-t).total_seconds()) for c in matches]
                # Repeated opponents require a close, distinct time match;
                # the final result must never be used to choose between games.
                if distances[0]<=1800 and distances[1]-distances[0]>=1800:matches=matches[:1]
            if len(matches)!=1:continue
            c=matches[0];winner=c['team_tricodes'][int(c['scores'][1]>c['scores'][0])]
            if codes[list(map(float,values)).index(1.)]!=winner:continue
            gid=canonical[c['official_game_id']];names=[teams[code][1] for code in c['team_tricodes']];tids=[teams[code][0] for code in c['team_tricodes']]
            if gid not in gs:
                g=dict(game_id=gid,league='NBA',game_type='Basketball',date=c['date'],start=c['start_utc'],start_basis='Official NBA scheduled start',team_ids=tids,teams=names,scores=c['scores'],home_away='Away;Home',location=None,city=None,milestone_id=None,kalshi_event=None,milestone_request_id=c['request_id'],milestone_pointer=None,result_request_id=c['request_id'],result_pointer=None,doubleheader_number=None,end=None,provider_sources=['polymarket'],winner=names[int(c['scores'][1]>c['scores'][0])],validation_status='OFFICIAL_NBA_CARD_ID_AND_RESULT_VERIFIED',official_game_id=c['official_game_id'])
                g['team_type']='temporary_all_star' if any(code in special for code in c['team_tricodes']) else 'franchise'
                gs[gid]=g;newgames[gid]=g
            g=gs[gid]
            for n,token in enumerate(tokens):
                if token in existing:continue
                # Canonical source game already uses away/home order, but use
                # actual team IDs to avoid relying on text order in outcomes.
                tid=teams[codes[n]][0];side=g['team_ids'].index(tid)
                added.append(dict(provider='polymarket',game_id=gid,side=side,contract_id=token,market_id=m['id'],event_id=eid,series=None,open=m.get('createdAt') or e.get('createdAt'),close=m.get('closedTime') or m.get('endDate'),settled=m.get('closedTime') or m.get('endDate'),request_id=rid,pointer=ptr+'/markets/'+str(mi),condition_id=m.get('conditionId'),outcome=labels[n],recovered_using_official_game_id=c['official_game_id']))
                existing.add(token)
            audit.append(dict(game_id=gid,official_game_id=c['official_game_id'],market_id=m['id'],request_id=rid,official_request_id=c['request_id'],question=m.get('question'),source_start_utc=t.isoformat(),official_start_utc=c['start_utc'],source_outcomes=labels,source_token_ids=tokens,official_winner=winner,selection_status='Candidate family; retain both outcome mappings'))
    db.executemany('INSERT INTO _history_games VALUES (?,?)',[(gid,json.dumps(g)) for gid,g in newgames.items()]);db.commit()
    db.executemany('INSERT INTO _history_contracts VALUES (?,?)',[(c['contract_id'],json.dumps(c)) for c in added]);db.commit()
    db.execute('CREATE TABLE IF NOT EXISTS _nba_recovered_checkpoints (game_id TEXT NOT NULL,body TEXT NOT NULL)')
    for gid in newgames:
        if not db.execute('SELECT 1 FROM _nba_recovered_checkpoints WHERE game_id=?',(gid,)).fetchone():
            for n,label in enumerate(['Start','Q1','Halftime','Q4']):
                cp=dict(game_id=gid,checkpoint=label,ordinal=n,timestamp=None,teamA_score=None,teamB_score=None,request_id=None,pointer=None,score_request_id=None)
                db.execute('INSERT INTO _nba_recovered_checkpoints VALUES (?,?)',(gid,json.dumps(cp)))
    db.execute('CREATE TABLE IF NOT EXISTS _nba_recovered_market_audit (market_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
    for a in audit:db.execute('INSERT OR REPLACE INTO _nba_recovered_market_audit VALUES (?,?)',(a['market_id'],json.dumps(a)))
    db.commit();db.close();report=dict(new_official_games=len(newgames),new_team_outcome_contracts=len(added),new_market_families=len(audit),new_game_ids=list(newgames));(ROOT/'reports/nba_recovered_markets.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='new_game_ids'}))

if __name__=='__main__':main()
