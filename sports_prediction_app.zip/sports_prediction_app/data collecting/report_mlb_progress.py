import datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from core import utc
db=sqlite3.connect(DB);games={g:json.loads(b) for g,b in db.execute('SELECT * FROM _mlb_canonical_games')};wanted={g['official_game_id'] for g in games.values()}
done={i for i, in db.execute('SELECT official_game_id FROM _official_mlb_feeds')} & wanted
report=dict(checked_at_utc=dt.datetime.now(dt.UTC).isoformat(),candidate_games=len(wanted),official_verified_game_reports=len(done),report_acquisition_percentage=round(len(done)*100/len(wanted),2),monthly_schedule_checks=33,collection_cutoff='2026-09-14',note='Report acquisition only; odds and all supporting tables require their own validation.')
for mode in ['pre','break']:
    report[mode+'_price_jobs']=[dict(status=s,jobs=n,returned_rows=r) for s,n,r in db.execute("SELECT json_extract(body,'$.status'),count(*),sum(json_extract(body,'$.rows')) FROM _mlb_price_acquisition WHERE json_extract(body,'$.mode')=? GROUP BY 1",(mode,))]
contracts=[json.loads(b) for b, in db.execute('SELECT body FROM _mlb_market_candidates')];feeds={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_mlb_feeds')};jobs={k:json.loads(b) for k,b in db.execute('SELECT * FROM _mlb_price_acquisition')};complete=0
for c in contracts:
    f=feeds[c['official_game_id']];g=games[c['game_id']];start=int(utc(f['actual_first_pitch_utc'] or g['start']).timestamp());key=f'pre:{c["provider"]}:{c["contract_id"]}:pre:{start-84*3600}:{start+6*3600}'
    complete+=jobs.get(key,{}).get('status')=='ok'
report['pre_contract_checks']=dict(completed=complete,total=len(contracts),percentage=round(100*complete/len(contracts),2))
break_total=0;break_complete=0;break_errors=0
for c in contracts:
    if c['provider']!='kalshi':continue
    f=feeds[c['official_game_id']]
    if not f['actual_first_pitch_utc']:continue
    anchor=int(utc(f['actual_first_pitch_utc']).timestamp())
    windows=[(0,anchor,anchor+120)]+[(n,int(utc(b['start_utc']).timestamp()),int(utc(b['end_utc']).timestamp())) for n,b in enumerate(f['breaks'],1) if b['start_utc'] and b['end_utc']]
    for n,lo,hi in windows:
        if hi-lo>7200:continue
        key=f'break:kalshi:{c["contract_id"]}:{n}:{lo-60}:{hi}';break_total+=1;status=jobs.get(key,{}).get('status');break_complete+=status=='ok';break_errors+=status=='error'
report['break_contract_checkpoint_checks']=dict(completed=break_complete,total=break_total,errors=break_errors,percentage=round(100*break_complete/break_total,2))
person_total=len({p['official_player_id'] for f in feeds.values() for p in f['players']})
person_done=db.execute("SELECT count(*) FROM _mlb_player_transaction_history WHERE json_extract(body,'$.status')='ok'").fetchone()[0]
report['player_history_checks']=dict(completed=person_done,total=person_total,percentage=round(100*person_done/person_total,2))
coach_report=json.loads((ROOT/'reports/mlb_coach_months.json').read_text())
coach_done=db.execute("SELECT count(*) FROM _official_mlb_coach_observations WHERE json_extract(body,'$.status')='ok'").fetchone()[0]
report['manager_date_checks']=dict(completed=coach_done,total=coach_report['total_team_date_checks'],percentage=round(100*coach_done/coach_report['total_team_date_checks'],2))
db.close();(ROOT/'reports/mlb_progress.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
