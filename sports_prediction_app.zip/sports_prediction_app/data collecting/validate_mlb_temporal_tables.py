"""Independent date-filtered SQL checks of MLB performance and profile links."""
import bisect,collections,datetime as dt,json,math,sqlite3,statistics
from build_history_catalog import DB
from probe_history import ROOT

def equal(a,b):return a is None and b is None or a is not None and b is not None and math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-10)

def main():
 db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone();wanted={r[0] for r in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='MLB' UNION SELECT game_id FROM kalshi_pre_match WHERE league='MLB'")};gs={i:json.loads(b) for i,b in db.execute('SELECT * FROM _mlb_canonical_games') if i in wanted};facts=collections.defaultdict(list)
 for r in db.execute("SELECT * FROM _player_game_results WHERE league='MLB' ORDER BY player_id,game_date,game_id"):facts[r['player_id']].append(dict(r))
 assert {p['game_id'] for ps in facts.values() for p in ps}==wanted
 for ps in facts.values():
  for p in ps:assert p['game_date']==gs[p['game_id']]['completion_local_date'] and start<=p['game_date']<=end
 checks=collections.Counter();examples=[]
 for day in ['2024-09-25','2024-10-31','2025-05-17','2025-05-18','2025-09-13','2026-03-15',end]:
  rows={r['player_id']:dict(r) for r in db.execute("SELECT * FROM _player_performance_periods WHERE league='MLB' AND effective_from<=? AND effective_to>?",(day,day))}
  for pid,ps in facts.items():
   bounded=[p for p in ps if start<=p['game_date']<=day]
   if not bounded:assert pid not in rows;checks['no_future_appearance']+=1;continue
   row=rows[pid];assert row['games_played']==len(bounded);assert equal(row['overall_winrate'],sum(p['win'] for p in bounded)/len(bounded));checks['date_bounded_player_games_and_wins']+=1
   for source in ['score','assists','minutes']:
    vs=[p[source] for p in bounded];complete=all(v is not None for v in vs);avg=statistics.mean(vs) if complete else None;sd=statistics.stdev(vs) if complete and len(vs)>1 else None
    assert equal(row['average_'+source+'_per_game'],avg),(day,pid,source,'average')
    assert equal(row['std_'+source+'_per_game'],sd),(day,pid,source,'sample standard deviation');checks['date_bounded_statistical_values']+=2
  for r in db.execute("SELECT * FROM team_history WHERE league='MLB' AND as_of_date=?",(day,)):
   actual=db.execute("SELECT count(*),avg(win),sum(home_away='Home'),sum(home_away='Away'),avg(score_for-score_against) FROM _team_game_results WHERE league='MLB' AND team_name=? AND game_date BETWEEN ? AND ?",(r['team_name'],start,day)).fetchone()
   assert tuple(actual[:4])==(r['games_played'],r['winrate'],r['home_times'],r['away_times']) and equal(actual[4],r['average_score_margin']);checks['date_bounded_team_history']+=1
  for r in db.execute("SELECT * FROM manager_profiles WHERE league='MLB' AND as_of_date=?",(day,)):
   n,win=db.execute("SELECT count(*),avg(win) FROM _manager_game_results WHERE manager_id=? AND game_date BETWEEN ? AND ?",(r['manager_id'],start,day)).fetchone();assert equal(r['overall_winrate'],win);checks['date_bounded_manager_winrate']+=1
  examples.append(dict(date=day,players_with_collected_appearances=len(rows)))
 for pid,gid,b in db.execute('SELECT * FROM _mlb_player_game_facts'):
  p=json.loads(b)
  if p['spans_multiple_local_dates']:
   assert p['affiliation_observation_safe'] is False
   assert not db.execute("SELECT 1 FROM _player_team_observations WHERE player_id=? AND league='MLB' AND game_id=?",(pid,gid)).fetchone();checks['suspended_game_not_used_for_roster_affiliation']+=1
 links=db.execute("SELECT l.game_id,l.player_id,l.as_of_date,p.as_of_date FROM game_player_profiles l LEFT JOIN player_profiles p ON p.player_id=l.player_id AND p.as_of_date=l.as_of_date WHERE l.game_id LIKE 'MLB_%'")
 for gid,pid,day,exists in links:
  assert gid in gs and exists==day and day==(dt.date.fromisoformat(gs[gid]['date'])-dt.timedelta(days=1)).isoformat();checks['player_t_minus_one_links']+=1
 for gid,mid,day in db.execute("SELECT * FROM game_manager_profiles WHERE game_id LIKE 'MLB_%'"):
  assert day==(dt.date.fromisoformat(gs[gid]['date'])-dt.timedelta(days=1)).isoformat()
  assert db.execute('SELECT 1 FROM manager_profiles WHERE manager_id=? AND as_of_date=?',(mid,day)).fetchone();checks['manager_t_minus_one_links']+=1
 for b, in db.execute('SELECT body FROM _mlb_game_profile_link_audit'):
  x=json.loads(b)
  for source in x['prior_roster_sources']:assert source['observed_date']<=x['as_of_date'];checks['prior_roster_dates']+=1
 for pid,b in db.execute('SELECT * FROM _mlb_player_bio_constants'):
  bio=json.loads(b);r=db.execute("SELECT * FROM player_profiles WHERE player_id=? AND as_of_date=?",(pid,end)).fetchone();assert r
  assert r['weight_kg']==bio['weight_kg'] and r['height_cm']==bio['height_cm'];checks['constant_biography_values']+=2
  if bio['birth_date']:
   dob=dt.date.fromisoformat(bio['birth_date']);d=dt.date.fromisoformat(end);assert r['age']==d.year-dob.year-((d.month,d.day)<(dob.month,dob.day));checks['age_as_of_date']+=1
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',coverage_status='PARTIALLY WORKING',checks=dict(checks),examples=examples,players=len(facts),collected_games=len(wanted),note='Performance uses only collected games completed by each query date; sample standard deviations checked independently with Python statistics. Complete career history, medical episodes and playing minutes remain separately missing.')
 (ROOT/'reports/mlb_temporal_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
