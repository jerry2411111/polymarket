"""Exact biography source checks plus independent retained UEFA corroboration."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources
from collect_laliga_people import namekey
from probe_history import ROOT
db=sqlite3.connect(DB);src=Sources(db);counts=collections.Counter();missing=collections.Counter();uefa=collections.defaultdict(list);examples=[];conflicts=[]
for b, in db.execute('SELECT body FROM _official_uefa_game_reports'):
 r=json.loads(b);s=r['sources']['lineups']
 for side in ['awayTeam','homeTeam']:
  for kind in ['field','bench']:
   for row in s['data'][side][kind]:
    p=row['player'];names={p.get('internationalName'),p.get('translations',{}).get('name',{}).get('EN')}-{None}
    for n in names:uefa[namekey(n)].append(dict(player_id=p['id'],birth_date=p.get('birthDate'),request_id=s['request_ids'][0]))
for pid,b in db.execute('SELECT * FROM _official_seriea_people_sources'):
 row=json.loads(b);counts['requested']+=1
 if row['status']!='ok':counts['unavailable']+=1;continue
 d,r=src.get(row['request_id']);assert d==row['data'] and d['playerId']==pid;name=' '.join(filter(None,[d.get('mediaFirstName'),d.get('mediaLastName')]));assert {namekey(name),namekey(d.get('shortName') or '')}&{namekey(n) for n in row['source_names']};counts['native_id_name_raw_value']+=1
 for k in ['dateOfBirth','height','weight']:missing[k]+=d.get(k) in [None,'',0,'0']
 proof={v['player_id']:v for n in [name,d.get('shortName')] if n for v in uefa[namekey(n)] if v['birth_date']==d.get('dateOfBirth') and v['birth_date']}
 if len(proof)==1:counts['independent_UEFA_name_and_birth_date']+=1
 if len(examples)<3:examples.append(dict(player_id=pid,name=name,birth_date=d.get('dateOfBirth'),height_raw=d.get('height'),weight_raw=d.get('weight'),request_id=row['request_id'],uefa_proof=list(proof.values()) if len(proof)==1 else []))
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Constant personal properties only; current team and status do not establish historical membership or injuries',counts=dict(counts),missing=dict(missing),source_hashes=len(src.cache),examples=examples);(ROOT/'reports/seriea_people_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
