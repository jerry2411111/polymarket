"""Remove retired lookback columns from published SQL/CSV/Parquet tables.

Only the 60- and 72-hour feature columns are removed. Before committing, compare
every retained value with the old SQL and both old exports. Raw source evidence
and previous audit runs remain available for reproducibility.
"""
import csv
import datetime as dt
import hashlib
import json
import pathlib
import re
import sqlite3

import pyarrow as pa
import pyarrow.parquet as pq

from build_history_catalog import DB
from eu_schema import EU_PRE_COLUMNS, refresh_main_views
from probe_history import ROOT
from schema import HOURS, PRE_COLUMNS


def digest(rows):
    value = hashlib.sha256()
    for row in rows:
        value.update((json.dumps(row, ensure_ascii=False, allow_nan=False, separators=(',', ':')) + '\n').encode())
    return value.hexdigest()


def main():
    assert HOURS == [0, 12, 24, 36, 48]
    db = sqlite3.connect(DB, timeout=60)
    db.execute('PRAGMA foreign_keys=ON')
    targets = [('polymarket_pre_match', 'polymarket/pre_match', PRE_COLUMNS),
        ('kalshi_pre_match', 'kalshi/pre_match', PRE_COLUMNS),
        ('_source_polymarket_soccer_pre_match', 'eu_soccer/polymarket/pre_match', EU_PRE_COLUMNS),
        ('_source_kalshi_soccer_pre_match', 'eu_soccer/kalshi/pre_match', EU_PRE_COLUMNS)]
    manifest = []
    for table, relative, columns in targets:
        old = [r[1] for r in db.execute('PRAGMA table_info(' + table + ')')]
        removed = [c for c in old if re.fullmatch(r'(teamA|teamB|draw)_pre_(60|72)_(p|odd)', c)]
        assert [c for c in old if c not in removed] == columns, table
        projection = ','.join('"' + c + '"' for c in columns)
        rows = db.execute('SELECT ' + projection + ' FROM ' + table + ' ORDER BY game_id').fetchall()
        expected = {row[-1]: row for row in rows}
        stem = ROOT / 'data/result' / relative
        source_parquet = pq.ParquetFile(stem.with_suffix('.parquet'))
        source_schema = pa.schema([source_parquet.schema_arrow.field(c) for c in columns])
        source_parquet.close()
        parquet_rows = [tuple(row[c] for c in columns) for row in pq.read_table(stem.with_suffix('.parquet'), columns=columns).to_pylist()]
        assert len(parquet_rows) == len(rows) and all(expected[row[-1]] == row for row in parquet_rows), (table, 'existing Parquet retained values')
        with stem.with_suffix('.csv').open(encoding='utf-8-sig', newline='') as handle:
            old_csv = list(csv.DictReader(handle))
        assert len(old_csv) == len(rows)
        for row in old_csv:
            sql_row = expected[row['game_id']]
            assert all(row[c] == ('' if v is None else str(v)) for c, v in zip(columns, sql_row)), (table, row['game_id'], 'existing CSV retained values')
        staged_pq, staged_csv = stem.with_suffix('.parquet.pending'), stem.with_suffix('.csv.pending')
        pq.write_table(pa.Table.from_pylist([dict(zip(columns, row)) for row in rows], schema=source_schema), staged_pq, compression='zstd')
        with staged_csv.open('w', encoding='utf-8-sig', newline='') as handle:
            writer = csv.writer(handle)
            writer.writerow(columns)
            writer.writerows(rows)
        staged_rows = [tuple(row[c] for c in columns) for row in pq.read_table(staged_pq).to_pylist()]
        assert digest(staged_rows) == digest(rows)
        with staged_csv.open(encoding='utf-8-sig', newline='') as handle:
            reader = csv.reader(handle)
            assert next(reader) == columns
            assert list(reader) == [['' if v is None else str(v) for v in row] for row in rows]
        manifest.append(dict(table=table, dataset='data/result/' + relative, rows=len(rows),
            previous_columns=len(old), columns=len(columns), removed_columns=removed,
            retired_columns=[f'{side}_pre_{hour}_{kind}' for hour in [60,72]
                for side in (['teamA','teamB','draw'] if 'soccer' in table else ['teamA','teamB']) for kind in ['odd','p']],
            retained_values_sha256=digest(rows), staged_parquet=str(staged_pq), staged_csv=str(staged_csv)))
        print('PREPARED', table, len(old), '->', len(columns), 'columns;', len(rows), 'rows fully compared', flush=True)
    original_count = db.execute('SELECT COUNT(DISTINCT game_id) FROM main').fetchone()[0]
    original_in_game = digest(db.execute('SELECT * FROM in_game ORDER BY provider,game_id').fetchall())
    with db:
        # Replace the view first so no active view references a retired column.
        refresh_main_views(db)
        for item, (_, _, columns) in zip(manifest, targets):
            for name in item['removed_columns']:
                db.execute('ALTER TABLE ' + item['table'] + ' DROP COLUMN "' + name + '"')
            assert [r[1] for r in db.execute('PRAGMA table_info(' + item['table'] + ')')] == columns
            rows = db.execute('SELECT * FROM ' + item['table'] + ' ORDER BY game_id').fetchall()
            assert digest(rows) == item['retained_values_sha256']
        assert db.execute('SELECT COUNT(DISTINCT game_id) FROM main').fetchone()[0] == original_count
        assert digest(db.execute('SELECT * FROM in_game ORDER BY provider,game_id').fetchall()) == original_in_game
        assert not any(re.search(r'_pre_(60|72)_', r[1]) for r in db.execute('PRAGMA table_info(main)'))
    for item in manifest:
        staged_pq, staged_csv = pathlib.Path(item.pop('staged_parquet')), pathlib.Path(item.pop('staged_csv'))
        staged_pq.replace(staged_pq.with_suffix(''))
        staged_csv.replace(staged_csv.with_suffix(''))
    report = dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(), status='WORKING',
        active_lookback_hours=HOURS, distinct_games=original_count, datasets=manifest,
        dropped_columns_in_this_execution=sum(len(item['removed_columns']) for item in manifest),
        retired_column_count=sum(len(item['retired_columns']) for item in manifest),
        in_game_values_unchanged_sha256=original_in_game,
        verification='All retained values exactly match the original SQL, CSV and Parquet data; game counts and in-game values are unchanged. Raw requests and historical audit versions were not rewritten.')
    (ROOT / 'reports/removed_lookbacks_validation.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    db.close()
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
