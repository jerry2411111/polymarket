"""Verify all game-weather links and original NOAA rows, including missing rows."""
import bisect,collections,csv,datetime as dt,hashlib,io,json,sqlite3,types
import pyarrow.parquet as pq
from build_history_catalog import DB
from core import utc
from probe_history import ROOT
from weather_values import value,weather_type,weather_codes,quality

def main():
 db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;wanted={r[0] for r in db.execute('SELECT game_id FROM polymarket_pre_match UNION SELECT game_id FROM kalshi_pre_match')};games={}
 for b, in db.execute('SELECT body FROM _official_game_facts'):
  g=json.loads(b)
  if g['game_id'] in wanted:games[g['game_id']]=g
 for table in ['_nba_canonical_games','_mlb_canonical_games']:
  for gid,b in db.execute('SELECT * FROM '+table):
   if gid in wanted:games[gid]=json.loads(b)
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_game_weather_locations'").fetchone():
  eu_ids={r[0] for r in db.execute('SELECT game_id FROM _source_polymarket_soccer_pre_match UNION SELECT game_id FROM _source_kalshi_soccer_pre_match')};wanted.update(eu_ids)
  for gid,b,location in db.execute('SELECT g.game_id,g.body,l.body FROM _eu_game_facts g JOIN _eu_game_weather_locations l USING(game_id)'):
   if gid in eu_ids:g=json.loads(b);g['city']=json.loads(location)['city'];games[gid]=g
 assert set(games)==wanted,'All selected games need official location facts'
 links={r['game_id']:dict(r) for r in db.execute('SELECT * FROM _game_weather_links') if r['game_id'] in wanted};missing_links=sorted(wanted-set(links))
 assert not [i for i in missing_links if games[i]['league'] in ['NBA','MLB','NHL','EU soccer']],('Expanded league missing game-weather links',missing_links)
 targets={};by_league=collections.defaultdict(set)
 for gid,g in games.items():
  if gid not in links:continue
  l=links[gid];assert l['city']==g['city'] and l['date']==g['date'];key=l['city'],l['date'];t=utc(g['start']).timestamp();targets[key]=min(targets.get(key,t),t);by_league[g['league']].add(key)
 rows={(r['city'],r['date']):dict(r) for r in db.execute('SELECT * FROM weather')};audit={(x['city'],x['date']):x for b, in db.execute('SELECT body FROM _weather_observation_audit') if (x:=json.loads(b))};assert set(targets)<=set(rows) and set(targets)<=set(audit)
 docs=[json.loads(b) for b, in db.execute("SELECT metadata_json FROM _request_audit WHERE json_extract(metadata_json,'$.endpoint') LIKE '%ghcnh%pdf'")]
 codes=weather_codes(types.SimpleNamespace(root=ROOT,records=docs));groups=collections.defaultdict(list);checks=collections.Counter();examples=[]
 smhi_raw={}
 def smhi_source(rid):
  if rid not in smhi_raw:
   rec=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/rec['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==rec['sha256'];smhi_raw[rid]=b;checks['smhi_raw_source_hashes']+=1
  return smhi_raw[rid]
 for key in targets:
  a=audit[key]
  if a.get('provider')=='SMHI':
   code_names={e['key']:e['value'] for e in json.loads(smhi_source(a['code_documentation_request_id']))['entry']};assert code_names[100]=='Inget signifikant väder observerat';assert rows[key]==a['normalized']
   for field,source in a['field_sources'].items():
    data=list(csv.reader(smhi_source(source['request_id']).decode('utf-8-sig').splitlines(),delimiter=';'));assert data[1][1]==str(source['station_id']);begin=utc(targets[key]-5400).date().isoformat();end=utc(targets[key]).date().isoformat();near=[]
    for n,x in enumerate(data):
     if len(x)>=4 and begin<=x[0]<=end and x[3]=='G' and x[2]:
      t=utc(x[0]+'T'+x[1]+'Z').timestamp()
      if targets[key]-5400<=t<=targets[key]:near.append((t,n,x))
    if not near:assert rows[key][field] is None;continue
    t,n,x=max(near);assert source['csv_row_index']==n and source['raw']==x and utc(source['observation_timestamp_utc']).timestamp()==t
    v=float(x[2]);expected='No significant weather observed' if field=='weather_type' and v==100 else code_names[int(v)] if field=='weather_type' else format(v,'g')+' degrees' if field=='wind_direction' else v
    assert rows[key][field]==expected;checks['smhi_nearest_prior_quality_approved_field']+=1
   continue
  if not a.get('request_id') and a.get('station_id') is None:
   assert a['reason']=='No reviewed station with a usable annual archive' and all(rows[key][c] is None for c in ['humidity_pct','weather_type','temperature_c','wind_direction']);job=db.execute('SELECT body FROM _eu_weather_station_jobs WHERE city=? AND year=?',(key[0],key[1][:4])).fetchone() if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_weather_station_jobs'").fetchone() else None
   if job:
    j=json.loads(job[0]);assert j['status']=='unavailable' and (j['candidate_count']==0 or j['alternatives']);meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(j['station_directory_request_id'],)).fetchone()[0]);assert hashlib.sha256((ROOT/meta['raw_file']).read_bytes()).hexdigest()==meta['sha256'];checks['EU_station_directory_and_failed_candidates']+=1
   else:
    report=json.loads((ROOT/'reports/epl_weather_station_mapping.json').read_text());assert any(x['city']==key[0] and x['year']==key[1][:4] and x['checked'] for x in report['issues'])
   assert not db.execute('SELECT 1 FROM _weather_city_stations WHERE city=? AND year=?',(key[0],key[1][:4])).fetchone();checks['explicit_unavailable_station_archive']+=1;continue
  assert a.get('request_id'),('Missing annual source for weather target',key);groups[a['request_id']].append(key)
 milestone=10
 for rid,keys in groups.items():
  rec=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/rec['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==rec['sha256'];checks['raw_archive_hashes']+=1;pf=pq.ParquetFile(io.BytesIO(b));cols=[k for k in pf.schema_arrow.names if k in ['DATE','STATION'] or k.startswith(('temperature','relative_humidity','wind_direction','wind_speed','sky_','pres_wx_'))];xs=pf.read(columns=cols).to_pylist();eligible=[]
  for n,x in enumerate(xs):
   if value(x,'temperature') is not None or value(x,'relative_humidity') is not None:
    stamp=str(x['DATE']);stamp=stamp if stamp.endswith('Z') or '+' in stamp else stamp+'Z';eligible.append((utc(stamp).timestamp(),n))
  eligible.sort();times=[t for t,n in eligible]
  for key in keys:
   a=audit[key];r=rows[key];idx=bisect.bisect_right(times,targets[key])-1;hit=eligible[idx] if idx>=0 and targets[key]-eligible[idx][0]<=5400 else None
   if hit is None:
    assert not a.get('raw') and all(r[c] is None for c in ['humidity_pct','weather_type','temperature_c','wind_direction']);checks['verified_absent_nearby_observation']+=1;continue
   t,n=hit;x=xs[n];assert a.get('row_index')==n and all(x[k]==v for k,v in a['raw'].items());assert x['STATION']==a['station_id'];assert utc(a['observation_timestamp_utc']).timestamp()==t;checks['nearest_prior_raw_row_and_timestamp']+=1
   assert r==a['normalized'] and r['temperature_c']==value(x,'temperature') and r['humidity_pct']==value(x,'relative_humidity') and r['weather_type']==weather_type(x,codes)
   wind=value(x,'wind_direction');expected='Variable' if quality(x,'wind_direction') and x.get('wind_direction_Measurement_Code')=='V' else 'Calm' if wind==0 else str(int(wind))+' degrees' if wind is not None else None;assert r['wind_direction']==expected;checks['normalized_field_values']+=4
   if len(examples)<3:examples.append(dict(city=key[0],date=key[1],source_url=rec['endpoint'],request_id=rid,observation_utc=utc(t).isoformat(),earliest_game_utc=utc(targets[key]).isoformat(),normalized=r,match=True))
  while checks['raw_archive_hashes']*100//len(groups)>=milestone:print('WEATHER VALIDATION',milestone,'percent;',checks['raw_archive_hashes'],'/',len(groups),flush=True);milestone+=10
 coverage={league:dict(city_dates=len(keys),missing={c:dict(count=sum(rows[k][c] is None for k in keys),total=len(keys),percentage=round(100*sum(rows[k][c] is None for k in keys)/len(keys),4)) for c in ['temperature_c','humidity_pct','weather_type','wind_direction']}) for league,keys in by_league.items()}
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',coverage_status='PARTIALLY WORKING',game_links=len(links),unexpanded_league_games_without_weather_links=missing_links,checks=dict(checks),leagues=coverage,examples=examples,note='Each city/date uses the latest qualifying observation within 90 minutes before the earliest collected linked game across all leagues. Outdoor station conditions, not indoor stadium conditions. Missing weather remains null.')
 (ROOT/'reports/weather_tables_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['unexpanded_league_games_without_weather_links','examples']}));print('Unexpanded league games without weather links',len(missing_links));db.close()

if __name__=='__main__':main()
