"""Verify official biography JSON, native identity and public profile markup."""
import collections,datetime as dt,hashlib,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT

def main():
 db=sqlite3.connect(DB);counts=collections.Counter();missing=collections.Counter();issues=[]
 for pid,b in db.execute('SELECT * FROM _official_bundesliga_people_sources'):
  row=json.loads(b);counts['requested']+=1
  if row['status']!='ok':counts['unavailable']+=1;continue
  r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(row['request_id'],)).fetchone()[0]);raw=(ROOT/r['raw_file']).read_bytes();assert r['status']==200 and hashlib.sha256(raw).hexdigest()==r['sha256'];soup=BeautifulSoup(raw,'html.parser');found=[];ld=[]
  for s in soup.find_all('script'):
   if s.get('type')=='application/json':
    data=json.loads(s.get_text());key=row['json_pointer'].split('/')[1]
    if key in data:found.append(data[key]['b'])
   elif s.get('type')=='application/ld+json':
    d=json.loads(s.get_text());ld.extend(d if isinstance(d,list) else [d])
  assert found==[row['data']] and row['data']['id']==pid;d=row['data'];person=[p for p in ld if p.get('@type')=='Person'];assert len(person)<=1;counts['native_id_exact_raw_JSON']+=1
  if person:assert person[0]['name']==d['names']['full'];assert person[0].get('birthDate')==d['birth']['date'];counts['public_person_markup_match']+=1
  else:missing['public_person_markup']+=1
  for field,value in [('birth_date',d.get('birth',{}).get('date')),('height',d.get('bio',{}).get('height',{}).get('height')),('weight',d.get('bio',{}).get('weight',{}).get('weight'))]:missing[field]+=value is None or value==0
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING' if not issues else 'PARTIALLY WORKING',counts=dict(counts),missing=dict(missing),issues=issues,scope='Constant personal attributes only; season memberships are raw evidence, not exact historical tenure or cumulative performance');(ROOT/'reports/bundesliga_people_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
