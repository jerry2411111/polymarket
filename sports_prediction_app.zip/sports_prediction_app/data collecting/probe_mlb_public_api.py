﻿import json
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
HOSTS.update({'baseballsavant.mlb.com','statsapi.mlb.com'});c=HistoryClient();out=[]
for u,p in [('https://baseballsavant.mlb.com/gf',{'game_pk':778297}),('https://statsapi.mlb.com/api/v1/schedule',{'sportId':1,'date':'2025-04-16','gamePk':778297,'useLatestGames':'true','hydrate':'team,probablePitcher,ruleSettings'})]:
 try:
  d,r=c.get(u,p);out.append(dict(endpoint=u,params=p,request_id=r['request_id'],keys=list(d),status='RECEIVED_REQUIRES_VALIDATION'));print(u,r['request_id'],'KEYS',list(d))
  if 'dates' in d:
   print('DATE',d.get('totalGames'),[(x['date'],len(x['games'])) for x in d['dates']]);print('GAME',d['dates'][0]['games'][0])
  else:
   for k,v in d.items():print(k,'DICTKEYS '+str(list(v)[:25]) if isinstance(v,dict) else 'LIST '+str(len(v)) if isinstance(v,list) else str(v)[:300])
 except Exception as e:out.append(dict(endpoint=u,error=str(e)));print(str(e))
(ROOT/'reports/mlb_public_api_probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
