"""Report exact retained publisher scopes without inventing league rankings."""
import datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_nba_ranking_facts import objects
from probe_history import ROOT
db=sqlite3.connect(DB);rows=[]
for b, in db.execute("SELECT body FROM _eu_editorial_sources WHERE json_extract(body,'$.kind') IN ('ranking','ranking_review')"):
 r=json.loads(b);out={k:r[k] for k in ['url','publisher','status']}
 if r['status']=='UNAVAILABLE':out['reason']=r['error'];rows.append(out);continue
 m=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(r['request_id'],)).fetchone()[0]);raw=(ROOT/m['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==m['sha256'];s=BeautifulSoup(raw,'html.parser');out.update(request_id=r['request_id'],title=r['metadata']['title'],headings=r['headings'][:12],dates=[{k:a.get(k) for k in ['datePublished','dateModified']} for a in objects(r['metadata']['structured']) if a.get('@type') in ['Article','NewsArticle']]);text=s.get_text(' ',strip=True)
 if r['publisher']=='goal':out.update(use='INSTALLED',reason='Overall European-season Top 50; 50 unique ranks retained per edition.')
 elif r['publisher']=='espn':out.update(use='NOT_EQUIVALENT',reason='FC 100 organizes players by position; no overall European ordinal is provided.')
 elif r['publisher']=='sky_sports':out.update(use='NOT_EQUIVALENT',reason='Premier League Top 25 only; not combined European overall ranking.')
 elif r['publisher']=='bbc':out.update(use='NOT_EQUIVALENT',reason='Reader vote among selected candidates; no independent ranked editorial list.')
 elif r['publisher']=='sports_illustrated':out.update(use='NOT_EQUIVALENT',reason='All-time Premier League list; not a dated ranking of current players.')
 elif r['publisher']=='france_football':out.update(use='INSTALLED_PARTIAL_TOP_TEN',reason='Both retained official award editions have all ten preceding ranks independently verified in the European population; original global scope is retained.')
 else:out.update(use='GLOBAL_SCOPE_REVIEW',reason='Worldwide overall list. Preserve original scope; no worldwide place is silently relabeled as European league place.')
 rows.append(out)
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',publishers_with_retained_documents=len({r['publisher'] for r in rows}),installed_european_overall_publishers=db.execute("SELECT count(DISTINCT v.publisher) FROM player_media_rankings r JOIN ranking_list_versions v ON v.list_id=r.list_id WHERE r.league='EU soccer'").fetchone()[0],target=10,reviewed_sources=rows,limits=['Successful HTTP retrieval does not establish ranking validity.','Distinct language editions, installments, authors, syndication and voter counts do not create independent publishers.','No evidence yet establishes ten comparable independently published lists per league or fresh quarterly editions.']);(ROOT/'reports/eu_media_feasibility.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='reviewed_sources'}));
for r in rows:print(r['publisher'],r.get('use'),r.get('dates'),r.get('headings',[])[:3])
db.close()
