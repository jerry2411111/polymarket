"""Check official report raw values and create audited game-clock/venue facts."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from epl_price_points import Sources,pointer
from eu_official_games import CONFIG,club_key
from core import utc
from probe_history import ROOT

def main():
 db=sqlite3.connect(DB,timeout=60);db.execute('BEGIN');src=Sources(db);checks=collections.Counter();issues=[];facts=[];html_hashes=set();bycomp=collections.defaultdict(collections.Counter);laliga_aliases=collections.defaultdict(list)
 for tid,label in db.execute("SELECT team_id,alias FROM _eu_club_alias_evidence WHERE competition='LAL'"):laliga_aliases[tid].append(label)
 def words(s):return {club_key(w) for w in re.split(r'\W+',s) if club_key(w) not in {'','fc','cf','ca','rc','rcd','ud','sad','club','de','del'}}
 def comment_side(label,m):
  exact=[]
  for side in ['home','away']:
   t=m[side+'_team'];names=[t[k] for k in ['nickname','boundname','name']]+laliga_aliases[str(t['id'])]
   if club_key(label) in {club_key(n) for n in names}:exact.append(side)
  if len(exact)==1:return exact
  found=[];wanted=words(label)
  for side in ['home','away']:
   t=m[side+'_team'];names=[t[k] for k in ['nickname','boundname','name']]+laliga_aliases[str(t['id'])]
   if any(wanted and (w:=words(n)) and max(map(len,w))>=4 and (wanted<=w or w<=wanted) for n in names):found.append(side)
  return found
 for code in ['BUN','LAL','FL1']:
  table=CONFIG[code][1]
  for mid,b in db.execute('SELECT * FROM _official_'+table+'_game_reports'):
   report=json.loads(b)
   if report['status']!='ok':issues.append(dict(competition=code,match_id=mid,reason='Acquisition error',error=report['error']));continue
   g=json.loads(db.execute('SELECT body FROM _official_'+table+'_calendar WHERE match_id=?',(mid,)).fetchone()[0]);ss=report['sources'];clock={k:None for k in ['actual_start_utc','halftime_start_utc','second_half_start_utc','regulation_end_utc']};proofs={};half=None;location=None;city=None;players=0;coaches=0
   if code=='LAL':
    s=ss['match_page'];r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(s['request_id'],)).fetchone()[0]);raw=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];html_hashes.add(s['request_id']);soup=BeautifulSoup(raw,'html.parser');d=json.loads(soup.find('script',id='__NEXT_DATA__').get_text());p=d['props']['pageProps'];assert p==s['data'];m=p['match'];assert str(m['id'])==mid and m['status']=='FullTime';assert [m['away_score'],m['home_score']]==g['scores'];assert [m[side+'_team']['id'] for side in ['away','home']]==[g[side]['id'] for side in ['away','home']];assert utc(m['date'])==utc(g['scheduled_start_utc']);location=m.get('venue',{}).get('name');period=m.get('period_started',{})
    for key,phase,field in [('actual_start_utc','FirstHalf','start'),('halftime_start_utc','FirstHalf','stop'),('second_half_start_utc','SecondHalf','start'),('regulation_end_utc','SecondHalf','stop')]:
     v=period.get(phase,{}).get(field);clock[key]=utc(v).isoformat() if v else None
     if v:proofs[key]=dict(request_id=s['request_id'],pointer='/props/pageProps/match/period_started/'+phase+'/'+field,raw_value=v)
    halves=[]
    for i,comment in enumerate(p['data'].get('comments',[])):
     match=re.fullmatch(r'First Half ends, (.+) (\d+), (.+) (\d+)\.',comment['content'])
     if not match:continue
     assert comment_side(match[1],m)==['home'] and comment_side(match[3],m)==['away'],(mid,comment['content']);halves.append([int(match[4]),int(match[2])]);proofs['halftime_scores']=dict(request_id=s['request_id'],pointer='/props/pageProps/data/comments/'+str(i)+'/content',raw_value=comment['content'])
    if halves and all(x==halves[0] for x in halves):half=halves[0]
    for side in ['away','home']:
     line=p['data']['lineups'].get(side,{})
     if len(line.get('starts',[]))!=11:issues.append(dict(competition=code,match_id=mid,reason='Starting lineup count differs from eleven',side=side,count=len(line.get('starts',[]))))
     players+=sum(len(line.get(k,[])) for k in ['starts','subs']);coaches+=len(line.get('manager',[]))
   elif code=='BUN':
    s=ss['match'];raw,r=src.get(s['request_id']);m=pointer(raw,s['pointer']);assert m==s['data'];line,r=src.get(ss['lineups']['request_id']);assert line==ss['lineups']['data'];assert m['matchId']==mid and m['matchStatus']=='FINAL_WHISTLE';assert m['score']==g['raw']['score'];assert [m['teams'][side]['dflDatalibraryClubId'] for side in ['away','home']]==[g[side]['dflDatalibraryClubId'] for side in ['away','home']];assert utc(m['plannedKickOff'])==utc(g['scheduled_start_utc']);clock['actual_start_utc']=utc(m['kickOff']).isoformat();proofs['actual_start_utc']=dict(request_id=s['request_id'],pointer=s['pointer']+'/kickOff',raw_value=m['kickOff']);half=[m['score'][side].get('halftime') for side in ['away','home']];location=m.get('stadiumName')
    for key,kind in [('halftime_start_utc','end_firstHalf'),('second_half_start_utc','start_secondHalf'),('regulation_end_utc','end_secondHalf')]:
     matches=[(k,e) for k,e in m.get('liveBlogEntries',{}).items() if e['entryType']==kind and e.get('entryDate')];values={utc(e['entryDate']).isoformat() for _,e in matches}
     if len(values)==1:clock[key]=next(iter(values));proofs[key]=dict(request_id=s['request_id'],pointer=s['pointer']+'/liveBlogEntries/'+matches[0][0]+'/entryDate',raw_value=matches[0][1]['entryDate'])
    if line:
     for side in ['away','home']:
      l=line.get(side,{})
      if len(l.get('startingEleven',{}).get('persons',[]))!=11:issues.append(dict(competition=code,match_id=mid,reason='Starting lineup count differs from eleven',side=side))
      players+=sum(len(l.get(k,{}).get('persons',[])) for k in ['startingEleven','bench']);coaches+=len(l.get('coaches',{}).get('persons',[]))
   else:
    s=ss['match'];m,r=src.get(s['request_id']);assert m==s['data'];assert m['id']==mid and m['period']=='fullTime';assert [m[side]['score'] for side in ['away','home']]==g['scores'];assert [m[side]['clubId'] for side in ['away','home']]==[g['raw'][side]['clubId'] for side in ['away','home']];assert utc(m['date'])==utc(g['scheduled_start_utc']);clock['actual_start_utc']=utc(m['startDate']).isoformat() if m.get('startDate') else None;clock['regulation_end_utc']=utc(m['endDate']).isoformat() if m.get('endDate') else None;location=m.get('stadium',{}).get('name');city=m.get('stadium',{}).get('address',{}).get('city')
    for field,source_field in [('actual_start_utc','startDate'),('regulation_end_utc','endDate')]:
     if m.get(source_field):proofs[field]=dict(request_id=s['request_id'],pointer='/'+source_field,raw_value=m[source_field])
    gs=[0,0];h=[0,0]
    for i,side in enumerate(['away','home']):
     line=m[side].get('players',{});players+=len(line);coaches+=bool(m[side].get('manager'));assert all(k==p['id'] for k,p in line.items())
     for p in line.values():
      for stat in ['minutesPlayed','goals','goalsAssists']:
       if p.get(stat) is not None:assert p[stat]>=0;checks['nonnegative_reported_player_stats']+=1
     for goal in m[side].get('goals',[]):
      assert goal['side']==side;gs[i]+=1;minute=re.match(r'(\d+)',goal['time']);assert minute
      if int(minute[1])<=45:h[i]+=1
    if gs==g['scores']:half=h;checks['official_goal_lists_reconcile']+=1
    else:issues.append(dict(competition=code,match_id=mid,reason='Goal lists do not reconcile',goals=gs,official=g['scores']))
   if half is not None and all(v is not None for v in half):assert all(0<=v<=g['scores'][i] for i,v in enumerate(half));checks['halftime_score']+=1
   else:half=None
   ordered=[clock[k] for k in ['actual_start_utc','halftime_start_utc','second_half_start_utc','regulation_end_utc']]
   if all(ordered):
    times=list(map(utc,ordered));lengths=[(times[1]-times[0]).total_seconds(),(times[2]-times[1]).total_seconds(),(times[3]-times[2]).total_seconds()]
    if not(2400<=lengths[0]<=6000 and 180<=lengths[1]<=3600 and 2400<=lengths[2]<=6000):issues.append(dict(competition=code,match_id=mid,reason='Implausible official phase durations',seconds=lengths));clock['halftime_start_utc']=clock['second_half_start_utc']=None
    else:checks['ordered_phase_boundaries']+=1
   for field,value in clock.items():bycomp[code][field+'_missing']+=value is None
   bycomp[code]['games']+=1;bycomp[code]['players']+=players;bycomp[code]['coaches']+=coaches;bycomp[code]['halftime_score_missing']+=half is None;checks['official_identity_score_and_date']+=1;facts.append((code,mid,json.dumps(dict(competition=code,official_match_id=mid,date=g['date'],clock=clock,clock_proofs=proofs,halftime_scores=half,scores=g['scores'],location=location,city=city))))
 # End the consistent read snapshot before the small audited facts write.
 db.commit()
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _eu_official_game_details (competition TEXT NOT NULL,match_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(competition,match_id)) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_official_game_details VALUES (?,?,?)',facts)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING' if not issues else 'PARTIALLY WORKING',scope='Retained official domestic reports, not published odds or player aggregates',competitions={k:dict(v) for k,v in bycomp.items()},checks=dict(checks),json_source_hashes=len(src.cache),html_source_hashes=len(html_hashes),issues=issues);(ROOT/'reports/eu_domestic_reports_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='issues'}),flush=True);print('ISSUES',len(issues),flush=True);db.close()

if __name__=='__main__':main()
