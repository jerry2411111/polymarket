"""Independent dated profile, source, affiliation and t-1 checks for EPL people."""
import collections,datetime as dt,json,math,sqlite3,statistics
from build_history_catalog import DB
from epl_price_points import Sources,pointer
from probe_history import ROOT

def eq(a,b):return a is None and b is None or a is not None and b is not None and math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-8)
def main():
 db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;src=Sources(db);checks=collections.Counter();bios={r[0]:json.loads(r[1]) for r in db.execute('SELECT * FROM _epl_people_biographies')};facts=[json.loads(r[0]) for r in db.execute('SELECT body FROM _epl_player_game_facts')];coaches=[json.loads(r[0]) for r in db.execute('SELECT body FROM _epl_manager_game_facts')];games={r[0]:json.loads(r[1]) for r in db.execute("SELECT * FROM _eu_game_facts WHERE json_extract(body,'$.competition')='Premier League'")};memberships=collections.defaultdict(list)
 for b, in db.execute('SELECT body FROM _epl_player_memberships'):
  m=json.loads(b);memberships[m['player_id']].append(m);raw,_=src.get(m['request_id']);v=pointer(raw,m['pointer']);assert v['id']==m['native_membership_id'] and {k:x for k,x in v.items() if k!='stat'}==m['raw_fields'];checks['career_membership_exact_raw']+=1
 for key,b in bios.items():
  raw,_=src.get(b['biography_request_id'])
  for field in ['birth_date','height_cm','weight_kg']:
   if b.get(field) is not None:assert pointer(raw,b['sources'][field])==b[field];checks['biography_exact_raw_field']+=1
  if b.get('birth_date_resolution'):
   a=b['birth_date_resolution'];raw,_=src.get(a['career_request_id']);assert pointer(raw,a['career_pointer'])==b['birth_date']==a['selected'];checks['birth_conflict_corroboration']+=1
 dates=['2024-01-01','2024-08-15','2024-08-16','2024-12-31','2025-05-25','2025-09-01','2025-12-31','2026-05-24','2026-09-14'];date_checks=[]
 numeric=['overall_winrate','average_score_per_game','std_score_per_game','average_assists_per_game','std_assists_per_game','average_minutes_per_game','std_minutes_per_game','starter_percentage_overall']
 for day in dates:
  grouped=collections.defaultdict(list);rosters=collections.defaultdict(list)
  for p in facts:
   if p['game_date']<=day:
    rosters[p['player_id']].append(p)
    if p['did_play']:grouped[p['player_id']].append(p)
  means={pid:statistics.mean(p['score'] for p in xs) for pid,xs in grouped.items() if all(p['score'] is not None for p in xs)};mu=statistics.mean(means.values()) if means else None;sigma=statistics.pstdev(means.values()) if means else None;n=0
  for row in db.execute("SELECT * FROM player_profiles WHERE league='EU soccer' AND player_id LIKE 'EU_PL:%' AND as_of_date=?",(day,)):
   p=dict(row);pid=p['player_id'];bio=bios.get('player:'+pid.split(':')[1],{});xs=grouped.get(pid,[]);expected=dict.fromkeys(numeric)
   if xs:
    expected['overall_winrate']=statistics.mean(x['win'] for x in xs);expected['starter_percentage_overall']=statistics.mean(x['starter'] for x in xs) if all(x['starter'] is not None for x in xs) else None
    for field in ['score','assists','minutes']:
     vals=[x[field] for x in xs]
     if all(x is not None for x in vals):expected['average_'+field+'_per_game']=statistics.mean(vals);expected['std_'+field+'_per_game']=statistics.stdev(vals) if len(vals)>1 else None
   for field,v in expected.items():assert eq(p[field],v),(day,pid,field,p[field],v);checks['independent_past_only_profile_metric']+=1
   z=(means[pid]-mu)/sigma if pid in means and sigma else None;assert eq(p['score_z_score'],z);checks['past_only_z_score']+=1
   assert eq(p['participation_rate_overall'],len(xs)/len(rosters[pid]) if rosters[pid] else None);checks['collected_roster_participation']+=1
   for field in ['height_cm','weight_kg']:assert p[field]==bio.get(field);checks['constant_physical_measurement']+=1
   born=dt.date.fromisoformat(bio['birth_date']) if bio.get('birth_date') else None;d=dt.date.fromisoformat(day);age=d.year-born.year-((d.month,d.day)<(born.month,born.day)) if born else None;assert p['age']==age;checks['date_specific_age']+=1
   if p['served_team_history']:
    prior_names={m['team_name'] for m in memberships[pid] if m['start_date'] and m['start_date']<=day}|{x['team_name'] for x in rosters[pid]};assert all(name in prior_names for name in p['served_team_history'].split(','));checks['history_uses_only_dated_prior_clubs']+=1
   if p['months_serving_current_team'] is not None:
    active=[m for m in memberships[pid] if m['team_name']==p['team'] and m['start_date'] and m['start_date']<=day and (not m['end_date'] or day<m['end_date'])];assert active;starts={m['start_date'] for m in memberships[pid] if m['team_name']==p['team'] and m['start_date'] and m['start_date']<=day};months={(d.year-s.year)*12+d.month-s.month-(d.day<s.day) for s in map(dt.date.fromisoformat,starts)};assert p['months_serving_current_team'] in months;checks['tenure_has_prior_documented_start']+=1
   assert p['number_of_teams_served'] is None;n+=1
  for row in db.execute("SELECT * FROM manager_profiles WHERE manager_id LIKE 'EU_PL_COACH:%' AND as_of_date=?",(day,)):
   xs=[c for c in coaches if c['manager_id']==row['manager_id'] and c['game_date']<=day];assert xs and eq(row['overall_winrate'],statistics.mean(c['win'] for c in xs));assert all(t in {c['team_name'] for c in xs} for t in row['served_team_history'].split(','));checks['manager_prior_games_and_clubs']+=1
  date_checks.append(dict(date=day,player_rows=n,played_people=len(grouped)))
 bygame=collections.defaultdict(set)
 for gid,pid,day in db.execute("SELECT * FROM game_player_profiles WHERE game_id LIKE 'EPL_%'"):
  assert day==(dt.date.fromisoformat(games[gid]['date'])-dt.timedelta(days=1)).isoformat();bygame[gid].add(pid);checks['player_link_t_minus_one']+=1
 assert db.execute("SELECT count(*) FROM game_player_profiles l LEFT JOIN player_profiles p ON p.player_id=l.player_id AND p.as_of_date=l.as_of_date WHERE l.game_id LIKE 'EPL_%' AND p.player_id IS NULL").fetchone()[0]==0
 for b, in db.execute('SELECT body FROM _epl_game_profile_link_audit'):
  a=json.loads(b);assert a['players']==len(bygame[a['game_id']])
  for s in a['prior_roster_sources']:assert s['observed_date']<=a['as_of_date'] and s['game_id']!=a['game_id'];checks['prior_roster_link_evidence']+=1
 for gid,mid,day in db.execute("SELECT * FROM game_manager_profiles WHERE game_id LIKE 'EPL_%'"):
  assert day==(dt.date.fromisoformat(games[gid]['date'])-dt.timedelta(days=1)).isoformat();assert db.execute('SELECT 1 FROM manager_profiles WHERE manager_id=? AND as_of_date=?',(mid,day)).fetchone();assert any(c['manager_id']==mid and c['game_date']<=day and c['team_name'] in games[gid]['teams'] for c in coaches);checks['manager_link_t_minus_one']+=1
 injury_days=collections.defaultdict(list)
 for b, in db.execute('SELECT body FROM _epl_injury_observations'):
  a=json.loads(b);v=a['source'];raw,_=src.get(v['request_id']);assert pointer(raw,v['pointer'])==v['raw'];pid=a['player_id'];gid=a['game_id'];p=next(p for p in facts if p['player_id']==pid and p['game_id']==gid);injury_days[pid].append(p['game_date']);row=db.execute('SELECT currently_injured_till_as_of_date,injured_times_till_as_of_date FROM player_profiles WHERE player_id=? AND as_of_date=?',(pid,p['game_date'])).fetchone();assert tuple(row)==(1,None);checks['dated_official_injury_evidence']+=1
 for col in ['overall_winrate','participation_rate_current_team','participation_rate_overall','starter_percentage_current_team','starter_percentage_overall']:
  assert db.execute('SELECT count(*) FROM player_profiles WHERE player_id LIKE \'EU_PL:%\' AND ('+col+'<0 OR '+col+'>1)').fetchone()[0]==0;checks['all_profile_probability_ranges']+=1
 assert db.execute("SELECT count(*) FROM player_profiles WHERE player_id LIKE 'EU_PL:%' AND months_serving_current_team<0").fetchone()[0]==0
 current=db.execute("SELECT count(*) FROM player_profiles p LEFT JOIN player_current_team c USING(player_id,as_of_date) WHERE p.player_id LIKE 'EU_PL:%' AND (c.player_id IS NULL OR c.current_team IS NOT p.team)").fetchone()[0];assert current==0
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',coverage_status='PARTIALLY WORKING',checks=dict(checks),dates=date_checks,source_hash_checks=len(src.cache),player_profile_rows=db.execute("SELECT count(*) FROM player_profiles WHERE player_id LIKE 'EU_PL:%'").fetchone()[0],manager_profile_rows=db.execute("SELECT count(*) FROM manager_profiles WHERE manager_id LIKE 'EU_PL_COACH:%'").fetchone()[0],limits=['Career membership completeness is not established; whole-career team counts remain null.','Injury false/zero is the user-requested no-report convention, not verified health.','Retrospective dated memberships are not evidence that an announcement was available to a trader on that date.','Only collected game facts enter performance; constant biometrics are authorized.']);(ROOT/'reports/epl_profiles_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));db.close()

if __name__=='__main__':main()
