"""Verify complete SQL/export equality, source values, clocks and provider-separated queries."""
import collections,csv,datetime as dt,json,math,sqlite3
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT
from core import utc
from epl_price_points import Sources,pointer,load
from eu_schema import EU_PRE_COLUMNS,EU_INGAME_COLUMNS
from schema import HOURS

def main():
    db=sqlite3.connect(DB);db.row_factory=sqlite3.Row;src=Sources(db);checks=collections.Counter();tables={};missing={};ages=collections.defaultdict(list);checkpoint_missing={}
    contracts={(c['provider'],c['contract_id']):c for row in db.execute('SELECT body FROM _epl_market_candidates') if (c:=json.loads(row[0]))};points,conflicts,_=load(db,contracts,src);assert not conflicts
    audits={}
    for row in db.execute('SELECT body FROM _epl_odds_selections'):
        a=json.loads(row[0])
        if not a.get('selected_family'):continue
        key=a['provider'],a['game_id'],a['side'],a['target'];assert key not in audits;audits[key]=a
    def verify_value(provider,gid,side,target,p,start):
        a=audits[provider,gid,side,target];assert a['price']==p;c=contracts[provider,a['contract_id']];assert not c.get('draw_half_payout_rule');assert c['game_id']==gid and c['side']==side;checks['outcome_mapping_and_rule']+=1
        lo=utc(a['target_timestamp_utc']).timestamp();opened=utc(c['open']).timestamp()
        if p is None:
            hi=utc(a['window_end_utc']).timestamp() if a['window_end_utc'] else None
            eligible=[v for v in points[provider,c['contract_id']] if v['timestamp']>=opened and (v['timestamp']<start and v['timestamp']+(v['resolution_seconds'] if provider=='polymarket' else 0)<=lo if target.startswith('pre_') else lo<=v['timestamp']<hi and v['timestamp']+(v['resolution_seconds'] if provider=='polymarket' else 0)<=hi)]
            assert not eligible,'Missing normalized observation despite a qualifying retained quote';checks['verified_missing_price']+=1;return
        assert math.isfinite(p) and 0<=p<=1;x=a['source'];raw,r=src.get(x['request_id']);assert float(pointer(raw,x['pointer']))==p;assert a['request_endpoint']==r['endpoint'] and a['request_parameters']==r['parameters'];checks['exact_raw_price_and_request']+=1
        ts=x['timestamp'];available=ts+(x['resolution_seconds'] if provider=='polymarket' else 0);lo=utc(a['target_timestamp_utc']).timestamp();opened=utc(c['open']).timestamp();assert ts>=opened
        if target.startswith('pre_'):
            assert ts<start and available<=lo
            eligible=[v for v in points[provider,c['contract_id']] if v['timestamp']>=opened and v['timestamp']<start and v['timestamp']+(v['resolution_seconds'] if provider=='polymarket' else 0)<=lo];assert eligible;latest=max(v['timestamp']+(v['resolution_seconds'] if provider=='polymarket' else 0) for v in eligible);assert available==latest,'A closer previous observation was omitted';ages[provider,target].append((lo-ts)/3600);checks['latest_previous_without_future_bucket']+=1
        else:
            hi=utc(a['window_end_utc']).timestamp();assert lo<=ts<hi and available<=hi;eligible=[v for v in points[provider,c['contract_id']] if v['timestamp']>=opened and lo<=v['timestamp']<hi and v['timestamp']+(v['resolution_seconds'] if provider=='polymarket' else 0)<=hi];assert available==min(v['timestamp']+(v['resolution_seconds'] if provider=='polymarket' else 0) for v in eligible);checks['first_quote_inside_official_window']+=1
    for provider in ['polymarket','kalshi']:
        for kind,columns in [('pre_match',EU_PRE_COLUMNS),('in_game',EU_INGAME_COLUMNS)]:
            table='_source_'+provider+'_soccer_'+kind;rows=[dict(r) for r in db.execute('SELECT * FROM '+table+' ORDER BY game_id')];assert [r[1] for r in db.execute('PRAGMA table_info('+table+')')]==columns;path=ROOT/'data/result/eu_soccer'/provider/kind
            for ext in ['csv','parquet']:
                if ext=='csv':
                    with path.with_suffix('.csv').open(encoding='utf-8-sig',newline='') as f:reader=csv.DictReader(f);assert reader.fieldnames==columns;other=list(reader)
                    for r in other:
                        for c,v in r.items():r[c]=None if v=='' else float(v) if '_pre_' in c else int(v) if c in ['teamA_final_score','teamB_final_score'] else v
                else:
                    data=pq.read_table(path.with_suffix('.parquet'));assert data.column_names==columns;other=data.to_pylist()
                other.sort(key=lambda r:r['game_id']);assert len(rows)==len(other)
                for expected,actual in zip(rows,other):
                    for c in columns:
                        x,y=expected[c],actual[c];assert math.isclose(x,y,rel_tol=1e-14,abs_tol=1e-14) if isinstance(x,(int,float)) and isinstance(y,(int,float)) else x==y,(table,ext,expected['game_id'],c,x,y)
                checks['complete_sql_export_equality']+=1
            # Exports contain every EU competition; this validator's source
            # checks and denominators remain specific to the Premier League.
            rows=[r for r in rows if r['competition']=='Premier League'];tables[table]=dict(rows=len(rows),columns=len(columns));missing[table]={c:dict(count=sum(r[c] is None for r in rows),total=len(rows),percentage=round(sum(r[c] is None for r in rows)*100/len(rows),4) if rows else None) for c in columns}
            for row in rows:
                g=json.loads(db.execute('SELECT body FROM _eu_game_facts WHERE game_id=?',(row['game_id'],)).fetchone()[0]);assert row['match']=='/'.join(g['teams']) and row['league']=='EU soccer' and row['competition']=='Premier League' and row['season']==g['season'];start=utc(g['start']).timestamp()
                if kind=='pre_match':
                    assert row['date']==g['date'] and row['timestamp']==g['start'];assert [row['teamA_final_score'],row['teamB_final_score']]==g['scores'] and row['final']==g['winner'];assert row['location']==g['location'] and row['home_away']==g['home_away'];checks['official_identity_score_and_winner']+=1
                    for side,name in enumerate(['teamA','teamB','draw']):
                        for h in HOURS:
                            p=row[f'{name}_pre_{h}_p'];odd=row[f'{name}_pre_{h}_odd'];assert odd is None if p is None or p==0 else math.isclose(odd,1/p,rel_tol=1e-14);verify_value(provider,g['game_id'],side,'pre_'+str(h),p,start)
                else:
                    assert row['checkpoint']=='START;HALFTIME;SECOND_HALF_START';assert all(len(row[c].split(';'))==3 for c in ['timestamp','checkpoint','teamA_ingame_odd','teamB_ingame_odd','draw_ingame_odd','teamA_ingame_p','teamB_ingame_p','draw_ingame_p','teamA_score','teamB_score']);f=json.loads(db.execute('SELECT body FROM _official_epl_game_reports WHERE match_id=?',(g['official_match_id'],)).fetchone()[0]);m=f['sources']['match']['data'];assert row['teamA_score']==';'.join(map(str,[0,m['awayTeam']['halfTimeScore'],m['awayTeam']['halfTimeScore']])) and row['teamB_score']==';'.join(map(str,[0,m['homeTeam']['halfTimeScore'],m['homeTeam']['halfTimeScore']]))
                    for side,name in enumerate(['teamA','teamB','draw']):
                        ps=[None if p=='null' else float(p) for p in row[name+'_ingame_p'].split(';')];odds=[None if p=='null' else float(p) for p in row[name+'_ingame_odd'].split(';')]
                        for n,(p,odd) in enumerate(zip(ps,odds)):
                            assert odd is None if p is None or p==0 else math.isclose(odd,1/p,rel_tol=1e-12)
                            if (provider,g['game_id'],side,'ingame_'+str(n)) in audits:verify_value(provider,g['game_id'],side,'ingame_'+str(n),p,start)
                            else:assert p is None
            if kind=='pre_match':
                days=collections.Counter(r['date'] for r in rows)
                for day,count in days.items():assert db.execute("SELECT count(*) FROM main WHERE date=? AND provider=? AND competition='Premier League'",(day,provider)).fetchone()[0]==count;checks['date_and_provider_sql_filter']+=1
            else:
                total=tables['_source_'+provider+'_soccer_pre_match']['rows'];checkpoint_missing[provider]=dict(games_with_any_checkpoint=len(rows),all_published_provider_games=total,games_without_any_checkpoint=dict(count=total-len(rows),total=total,percentage=round((total-len(rows))*100/total,4)),fields={})
                for side in ['teamA','teamB','draw']:
                    for n,label in enumerate(['START','HALFTIME','SECOND_HALF_START']):
                        absent=total-sum(r[side+'_ingame_p'].split(';')[n]!='null' for r in rows);checkpoint_missing[provider]['fields'][side+':'+label]=dict(count=absent,total=total,percentage=round(absent*100/total,4))
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Currently published EPL SQL tables and all exported values; missing observations are explicitly allowed and counted',tables=tables,checks=dict(checks),source_hash_checks=len(src.cache),raw_price_conflicts=conflicts,missing=missing,checkpoint_missing=checkpoint_missing,quote_age_hours={p+':'+t:dict(observations=len(xs),median=sorted(xs)[len(xs)//2],maximum=max(xs)) for (p,t),xs in sorted(ages.items())});(ROOT/'reports/epl_outputs_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['missing','quote_age_hours','checkpoint_missing']}));db.close()

if __name__=='__main__':main()
