"""Read exact archive links from Stockholm-Bromma's official station metadata."""
import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from read_smhi_station_metadata import json_url

HOSTS.add('opendata-download-metobs.smhi.se');c=HistoryClient();report=json.loads((ROOT/'reports/smhi_station_metadata.json').read_text());out=[]
for p in report['parameters']:
    station=next(s for s in p['station_metadata'] if s['station_id']==97200)
    period=next(x for x in station['metadata']['period'] if x['key']=='corrected-archive')
    d,r=c.get(json_url(period));entry=dict(parameter=p['parameter'],station_id=97200,request_id=r['request_id'],metadata=d);out.append(entry);print(json.dumps(entry,ensure_ascii=False),flush=True)
(ROOT/'reports/smhi_archive_metadata.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),archives=out,new_requests=c.requests),indent=2),encoding='utf-8')
