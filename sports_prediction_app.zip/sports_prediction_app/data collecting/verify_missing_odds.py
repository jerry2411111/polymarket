"""Reconcile every published pre-match probability with its stored selection audit.

This is an independent publication/selection check. Source requests are not
repeated, and absence in the acquired history is not claimed to prove that no
older data can ever be obtained from the provider.
"""
import collections
import csv
import datetime as dt
from decimal import Decimal
import json
import pathlib
import re
import sqlite3
import uuid

from build_history_catalog import DB
from probe_history import ROOT
from schema import HOURS


def stamp(value):
    if isinstance(value, (int, float)):
        return value
    return dt.datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()


def main():
    db = sqlite3.connect(pathlib.Path(DB).resolve().as_uri() + '?mode=ro', uri=True)
    db.row_factory = sqlite3.Row
    selections, duplicates = {}, []
    for table in ['_history_selections', '_epl_odds_selections', '_eu_odds_selections']:
        for row in db.execute('SELECT body FROM ' + table):
            record = json.loads(row[0])
            if record['target'] not in {'pre_' + str(h) for h in HOURS} or not record.get('selected_family', True):
                continue
            key = record['provider'], record['game_id'], record['side'], record['target']
            if key in selections and selections[key] != record:
                duplicates.append(dict(provider=key[0], game_id=key[1], side=key[2], target=key[3]))
            selections[key] = record
    counts = collections.defaultdict(collections.Counter)
    reasons = collections.Counter()
    errors, examples, game_coverage = [], [], []
    checked, zeros, present = 0, 0, 0
    for row in db.execute('SELECT * FROM main'):
        game = dict(row)
        start = stamp(game['timestamp'])
        sides = ['teamA', 'teamB', 'draw'] if game['league'] == 'EU soccer' else ['teamA', 'teamB']
        all_columns = [f'{side}_pre_{hour}_p' for hour in HOURS for side in sides]
        missing_columns = [c for c in all_columns if game[c] is None]
        zero_columns = [c[:-1] + 'odd' for c in all_columns if game[c] == 0]
        hour_groups = {'all_outcomes_available': [], 'some_outcomes_missing': [], 'all_outcomes_missing': []}
        for hour in HOURS:
            missing = sum(game[f'{side}_pre_{hour}_p'] is None for side in sides)
            category = 'all_outcomes_available' if missing == 0 else 'all_outcomes_missing' if missing == len(sides) else 'some_outcomes_missing'
            hour_groups[category].append(str(hour))
            counter = counts[game['provider'], game['league'], hour]
            counter['games'] += 1
            counter['games_' + category] += 1
            counter['games_any_outcome_missing'] += missing > 0
            counter['games_exactly_one_outcome_missing'] += missing == 1
        game_coverage.append(dict(provider=game['provider'], league=game['league'], game_id=game['game_id'], date=game['date'],
            expected_probability_values=len(all_columns), available_probability_values=len(all_columns)-len(missing_columns),
            missing_probability_values=len(missing_columns), missing_probability_pct=round(len(missing_columns)*100/len(all_columns), 4),
            pre_match_status='COMPLETE' if not missing_columns else 'ALL_MISSING' if len(missing_columns)==len(all_columns) else 'PARTIAL',
            hours_all_outcomes_available=';'.join(hour_groups['all_outcomes_available']),
            hours_some_outcomes_missing=';'.join(hour_groups['some_outcomes_missing']),
            hours_all_outcomes_missing=';'.join(hour_groups['all_outcomes_missing']),
            missing_probability_columns=';'.join(missing_columns),
            zero_probability_undefined_odds_columns=';'.join(zero_columns)))
        for column, probability in game.items():
            match = re.fullmatch(r'(teamA|teamB|draw)_pre_(\d+)_p', column)
            if not match or (match[1] == 'draw' and game['league'] != 'EU soccer'):
                continue
            side_name, hours = match[1], int(match[2])
            side = ['teamA', 'teamB', 'draw'].index(side_name)
            key = game['provider'], game['game_id'], side, 'pre_' + str(hours)
            record = selections.get(key)
            group = game['provider'], game['league'], hours
            counts[group]['probability_slots'] += 1
            checked += 1
            context = dict(provider=game['provider'], game_id=game['game_id'], column=column)
            if record is None:
                errors.append(dict(**context, problem='Published slot lacks its selection-audit record'))
                continue
            expected = record.get('normalized_price') if 'normalized_price' in record else record.get('price')
            if probability != expected:
                errors.append(dict(**context, problem='Published probability differs from selection audit', published=probability, audit=expected))
            price_odd = game[column[:-1] + 'odd']
            expected_odd = float(Decimal(1) / Decimal(str(probability))) if probability is not None and probability > 0 else None
            if price_odd != expected_odd:
                errors.append(dict(**context, problem='Published odds differ from reciprocal probability', published=price_odd, expected=expected_odd))
            if probability is None:
                counts[group]['missing_probability'] += 1
                reason = record.get('reason') or 'No explicit reason recorded'
                reasons[group + (reason,)] += 1
                if reason == 'No explicit reason recorded':
                    errors.append(dict(**context, problem=reason))
                if len(examples) < 24:
                    examples.append(dict(**context, reason=reason, target_timestamp_utc=record.get('target_timestamp_utc')))
                continue
            present += 1
            if probability == 0:
                zeros += 1
                counts[group]['zero_probability_undefined_odds'] += 1
            target = start - hours * 3600
            source = record.get('source')
            if source:
                observation = source['timestamp']
                available = observation + (source.get('resolution_seconds', 0) if source.get('kind') == 'v2' else 0)
                request_id, pointer = source.get('request_id'), source.get('pointer')
            else:
                observation = stamp(record['source_timestamp_utc'])
                available = (stamp(record['source_available_at_utc']) if record.get('source_available_at_utc')
                    else observation + (record.get('source_resolution_seconds', 0) if record.get('source_kind') == 'v2' else 0))
                request_id, pointer = record.get('request_id'), record.get('pointer')
            if observation >= start or available > target:
                errors.append(dict(**context, problem='Observation is not wholly available before its requested cutoff', observation=observation, available=available, target=target))
            if not request_id or not pointer:
                errors.append(dict(**context, problem='Selected observation lacks request ID or raw JSON pointer'))
    rows = []
    for (provider, league, hours), values in sorted(counts.items()):
        rows.append(dict(provider=provider, league=league, lookback_hours=hours,
            probability_slots=values['probability_slots'], missing_probability=values['missing_probability'],
            missing_probability_pct=round(values['missing_probability'] * 100 / values['probability_slots'], 4),
            zero_probability_undefined_odds=values['zero_probability_undefined_odds'],
            games=values['games'], games_all_outcomes_available=values['games_all_outcomes_available'],
            games_any_outcome_missing=values['games_any_outcome_missing'],
            games_any_outcome_missing_pct=round(values['games_any_outcome_missing']*100/values['games'],4),
            games_exactly_one_outcome_missing=values['games_exactly_one_outcome_missing'],
            games_exactly_one_outcome_missing_pct=round(values['games_exactly_one_outcome_missing']*100/values['games'],4),
            games_some_outcomes_missing=values['games_some_outcomes_missing'],
            games_some_outcomes_missing_pct=round(values['games_some_outcomes_missing']*100/values['games'],4),
            games_all_outcomes_missing=values['games_all_outcomes_missing'],
            games_all_outcomes_missing_pct=round(values['games_all_outcomes_missing']*100/values['games'],4)))
        assert values['games_all_outcomes_available'] + values['games_some_outcomes_missing'] + values['games_all_outcomes_missing'] == values['games']
    game_groups = collections.defaultdict(list)
    for game in game_coverage:
        game_groups[game['provider'], game['league']].append(game)
    game_summaries = []
    for (provider, league), games in sorted(game_groups.items()):
        categories = collections.Counter(g['pre_match_status'] for g in games)
        histogram = collections.Counter(g['missing_probability_values'] for g in games)
        game_summaries.append(dict(provider=provider, league=league, games=len(games),
            expected_probability_values_per_game=games[0]['expected_probability_values'],
            games_complete=categories['COMPLETE'], games_partially_missing=categories['PARTIAL'], games_all_missing=categories['ALL_MISSING'],
            complete_pct=round(categories['COMPLETE']*100/len(games),4),
            partially_missing_pct=round(categories['PARTIAL']*100/len(games),4),
            all_missing_pct=round(categories['ALL_MISSING']*100/len(games),4),
            games_by_number_of_missing_values=dict(sorted(histogram.items()))))
    report = dict(audit_id=uuid.uuid4().hex, generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),
        status='WORKING' if not errors and not duplicates else 'MATCHING PROBLEM',
        probability_slots_checked=checked, populated_probability_slots=present,
        missing_probability_slots=checked-present, zero_probability_undefined_odds=zeros,
        differences=errors, differing_duplicate_selection_keys=duplicates,
        coverage=rows, game_coverage_summary=game_summaries,
        active_lookback_hours=HOURS,
        game_coverage_definition=f'COMPLETE: all {len(HOURS)} configured lookbacks for every outcome; PARTIAL: at least one available and one missing probability; ALL_MISSING: no pre-match probability. US games have {2*len(HOURS)} slots (2 teams x {len(HOURS)} hours); soccer has {3*len(HOURS)} (including draw). Zero probability is available even when reciprocal odds are undefined.',
        missing_reasons=[dict(provider=k[0], league=k[1], lookback_hours=k[2], reason=k[3], slots=n)
            for k, n in sorted(reasons.items())], missing_examples=examples,
        scope='Published pre-match slots versus retained selection records; exact probability/reciprocal values and completed-source cutoff checked. No new API call or new assertion of complete upstream history.')
    path = ROOT / 'reports/missing_odds_verification.json'
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    with (ROOT / 'reports/missing_odds_by_lookback.csv').open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    db.close()
    with (ROOT / 'reports/pre_match_game_coverage.csv').open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(game_coverage[0]))
        writer.writeheader()
        writer.writerows(game_coverage)
    writable = sqlite3.connect(DB, timeout=60)
    writable.execute('PRAGMA foreign_keys=ON')
    with writable:
        writable.execute('''CREATE TABLE IF NOT EXISTS _pre_match_coverage_runs(
            audit_id TEXT PRIMARY KEY,generated_at_utc TEXT NOT NULL,status TEXT NOT NULL,body TEXT NOT NULL) STRICT''')
        columns = list(game_coverage[0])
        types = {c: 'INTEGER' if c.endswith('_values') else 'REAL' if c == 'missing_probability_pct' else 'TEXT' for c in columns}
        writable.execute('CREATE TABLE IF NOT EXISTS _pre_match_game_coverage('
            'audit_id TEXT NOT NULL REFERENCES _pre_match_coverage_runs(audit_id),'
            + ','.join('"'+c+'" '+types[c]+' NOT NULL' for c in columns)
            + ',PRIMARY KEY(audit_id,provider,game_id)) STRICT')
        writable.execute('INSERT INTO _pre_match_coverage_runs VALUES(?,?,?,?)',
            (report['audit_id'], report['generated_at_utc'], report['status'], json.dumps(report, ensure_ascii=False)))
        writable.executemany('INSERT INTO _pre_match_game_coverage VALUES ('+','.join('?' for _ in range(len(columns)+1))+')',
            [(report['audit_id'], *(game[c] for c in columns)) for game in game_coverage])
        writable.execute('''CREATE VIEW IF NOT EXISTS pre_match_coverage_latest AS
            SELECT g.* FROM _pre_match_game_coverage g WHERE audit_id=(SELECT audit_id FROM _pre_match_coverage_runs
            ORDER BY generated_at_utc DESC,audit_id DESC LIMIT 1)''')
        lookback_columns = list(rows[0])
        writable.execute('CREATE TABLE IF NOT EXISTS _pre_match_lookback_coverage('
            'audit_id TEXT NOT NULL REFERENCES _pre_match_coverage_runs(audit_id),'
            + ','.join('"'+c+'" '+('TEXT' if c in ['provider','league'] else 'REAL' if c.endswith('_pct') else 'INTEGER')+' NOT NULL' for c in lookback_columns)
            + ',PRIMARY KEY(audit_id,provider,league,lookback_hours)) STRICT')
        writable.executemany('INSERT INTO _pre_match_lookback_coverage VALUES ('+','.join('?' for _ in range(len(lookback_columns)+1))+')',
            [(report['audit_id'], *(row[c] for c in lookback_columns)) for row in rows])
        writable.execute('''CREATE VIEW IF NOT EXISTS pre_match_lookback_coverage_latest AS
            SELECT g.* FROM _pre_match_lookback_coverage g WHERE audit_id=(SELECT audit_id FROM _pre_match_coverage_runs
            ORDER BY generated_at_utc DESC,audit_id DESC LIMIT 1)''')
    writable.close()
    lines = ['# Pre-match coverage: partial versus entirely missing', '',
        'Generated: ' + report['generated_at_utc'], '', report['game_coverage_definition'], '',
        'The percentages in `missing_odds_by_lookback.csv` count individual outcome/hour probability slots, not whole games.',
        'These counts describe games already collected for that provider, not every scheduled game.', '',
        '| Provider | League | Games | All values available | Some values missing | All values missing |',
        '|---|---|---:|---:|---:|---:|']
    for row in game_summaries:
        lines.append('| ' + ' | '.join(str(row[k]) for k in ['provider','league','games','games_complete','games_partially_missing','games_all_missing']) + ' |')
    lines += ['', '## Missing percentage at each pre-match hour', '',
        'The CSV and SQL lookback summary cover every league. Probability-slot percentage uses all expected outcome values at that hour as denominator.',
        'Game percentage uses the provider\'s collected games as denominator. The following MLB table distinguishes exactly one team missing from both teams missing.', '',
        '| Hour | Kalshi missing values % | Kalshi one team missing % of games | Kalshi both missing % of games | Polymarket missing values % | Polymarket one team missing % of games | Polymarket both missing % of games |',
        '|---:|---:|---:|---:|---:|---:|---:|']
    mlb = {(row['provider'],row['lookback_hours']):row for row in rows if row['league']=='MLB'}
    for hour in HOURS:
        values = [str(hour)]
        for provider in ['kalshi','polymarket']:
            values += [f"{mlb[provider,hour][key]:.4f}" for key in ['missing_probability_pct','games_exactly_one_outcome_missing_pct','games_all_outcomes_missing_pct']]
        lines.append('| '+' | '.join(values)+' |')
    lines += ['', '[Each game and its missing hours/columns](pre_match_game_coverage.csv)', '',
        '[Exact lookback-slot counts and percentages](missing_odds_by_lookback.csv)', '',
        'An hour can be fully missing (all outcomes absent) or partly missing (only some outcomes absent).',
        'The CSV records both, along with the exact absent probability column names. A blank list means no hours/columns in that category.',
        'The JSON report records how many games have exactly 0, 1, 2, etc. missing values.', '',
        '```sql', 'SELECT provider, league, game_id, date, pre_match_status,',
        '       expected_probability_values, available_probability_values, missing_probability_values,',
        '       hours_all_outcomes_missing, hours_some_outcomes_missing, missing_probability_columns',
        'FROM pre_match_coverage_latest', "WHERE league='MLB' AND date='2025-07-04'", 'ORDER BY provider, game_id;', '```', '']
    lines += ['For percentages per hour across the full collected MLB sample:', '', '```sql',
        'SELECT provider, lookback_hours, games, missing_probability_pct,',
        '       games_exactly_one_outcome_missing_pct, games_all_outcomes_missing_pct,',
        '       games_any_outcome_missing_pct', 'FROM pre_match_lookback_coverage_latest',
        "WHERE league='MLB'", 'ORDER BY lookback_hours, provider;', '```', '',
        'For a date subset, filter `pre_match_coverage_latest` by game date and compute its denominator within that subset; the aggregate lookback view covers the entire collected sample.', '']
    (ROOT / 'reports/pre_match_game_coverage.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({k: report[k] for k in ['status', 'probability_slots_checked', 'populated_probability_slots', 'missing_probability_slots', 'zero_probability_undefined_odds']}, indent=2))
    print('Differences:', len(errors), 'Differing duplicate selection keys:', len(duplicates))
    print(json.dumps(game_summaries, indent=2))
    if errors:
        print(json.dumps(errors[:5], indent=2))
    return int(bool(errors or duplicates))


if __name__ == '__main__':
    raise SystemExit(main())
