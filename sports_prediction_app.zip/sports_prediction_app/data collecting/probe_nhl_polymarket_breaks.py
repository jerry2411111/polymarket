"""Bounded real checks of retained fine prices inside old official NHL breaks."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from core import utc
from history_client import HistoryClient
from probe_history import ROOT

db=sqlite3.connect(DB,timeout=60);games={g:json.loads(b) for g,b in db.execute('SELECT * FROM _nhl_canonical_games')};feeds={g:json.loads(b) for g,b in db.execute('SELECT * FROM _official_nhl_game_reports')};families=collections.defaultdict(list)
for b, in db.execute('SELECT body FROM _nhl_market_candidates'):
    c=json.loads(b)
    if c['provider']=='polymarket':families[c['game_id'],c['market_id']].append(c)
eligible=sorted((games[gid]['date'],gid,mid) for (gid,mid),cs in families.items() if collections.Counter(c['side'] for c in cs)=={0:1,1:1} and feeds[games[gid]['official_game_id']]['breaks'][0]['start_utc'])
targets=[eligible[0],next(x for x in eligible if x[0]>='2025-01-01'),eligible[-1]];client=HistoryClient();rows=[]
for day,gid,mid in targets:
    g=games[gid];window=feeds[g['official_game_id']]['breaks'][0];lo=int(utc(window['start_utc']).timestamp());hi=int(utc(window['end_utc']).timestamp())
    for c in families[gid,mid]:
        for grain in [60,None]:
            params=dict(token_id=c['contract_id'],start=lo,end=hi,limit=10000)
            if grain:params['bucket_seconds']=grain
            d,r=client.get('https://data-api.polymarket.com/v2/prices-history',params);assert not d.get('pagination',{}).get('next_cursor');usable=[x for x in d['data'] if x['resolution_seconds']>0 and lo<=x['timestamp'] and x['timestamp']+x['resolution_seconds']<=hi]
            rows.append(dict(game_id=gid,date=day,team=g['teams'][c['side']],market_id=mid,token_id=c['contract_id'],window_start_utc=window['start_utc'],window_end_utc=window['end_utc'],official_window_request_id=window['request_id'],parameters=params,request_id=r['request_id'],retrieved_at_utc=r['retrieved_at_utc'],returned_rows=len(d['data']),eligible_rows=len(usable),resolutions=sorted({x['resolution_seconds'] for x in d['data']})))
    print('NHL POLYMARKET BREAK PROBE',day,'checked',flush=True)
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),tested_games=len(targets),requests=client.requests,eligible_observations=sum(r['eligible_rows'] for r in rows),examples=rows,scope='Actual bounded fine/default-resolution requests inside three official breaks; not a claim that every historical market has identical retention')
(ROOT/'reports/nhl_polymarket_break_probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='examples'}));db.close()
