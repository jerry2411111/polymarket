"""Independently verify retained LaLiga and Bundesliga calendars and season counts."""
import argparse,collections,datetime as dt,hashlib,json,sqlite3
from zoneinfo import ZoneInfo
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--competition',choices=['LaLiga','Bundesliga','Ligue 1','Serie A']);a=ap.parse_args();db=sqlite3.connect(DB);cache={}
    def source(rid,html=False):
        if rid not in cache:
            r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);raw=(ROOT/r['raw_file']).read_bytes();assert r['status']==200 and hashlib.sha256(raw).hexdigest()==r['sha256'];cache[rid]=json.loads(BeautifulSoup(raw,'html.parser').find('script',id='__NEXT_DATA__').get_text()) if html else json.loads(raw)
        return cache[rid]
    for league,table,full,teams_per in [('LaLiga','_official_laliga_calendar',380,20),('Bundesliga','_official_bundesliga_calendar',306,18),('Ligue 1','_official_ligue1_calendar',306,18),('Serie A','_official_seriea_calendar',380,20)]:
        if a.competition and a.competition!=league:continue
        checks=collections.Counter();seasons=collections.defaultdict(list);revisions=[];before=set(cache)
        for mid,body in db.execute('SELECT * FROM '+table):
            g=json.loads(body);raw=source(g['request_id'],league=='LaLiga');m=raw
            for key in g['pointer'].strip('/').split('/'):m=m[int(key)] if isinstance(m,list) else m[key]
            assert m==g['raw'];assert g['official_match_id']==mid;assert g['competition']==league;checks['exact_raw_game']+=1
            if league=='LaLiga':
                assert str(m['id'])==mid and m['status']=='FullTime';assert m['subscription']['slug']=='laliga-easports-'+g['season'][:4];assert g['home']==m['home_team'] and g['away']==m['away_team'];assert g['location']==m.get('venue',{}).get('name');when=dt.datetime.fromisoformat(m['date']);zone='Atlantic/Canary' if m['home_team']['slug']=='ud-las-palmas' else 'Europe/Madrid';scores=[m['away_score'],m['home_score']];names=[m['away_team']['name'],m['home_team']['name']];ids=[str(m['away_team']['id']),str(m['home_team']['id'])]
            elif league=='Bundesliga':
                assert m['matchId']==mid and m['matchStatus']=='FINAL_WHISTLE';assert m['dflDatalibraryCompetitionId']==g['competition_id']=='DFL-COM-000001';assert m['dflDatalibrarySeasonId']==g['native_season_id'];assert g['home']==m['teams']['home'] and g['away']==m['teams']['away'];when=dt.datetime.fromisoformat(m['plannedKickOff']);zone='Europe/Berlin';assert dt.datetime.fromisoformat(m['kickOff']).astimezone(dt.UTC).isoformat()==g['actual_start_utc'];scores=[]
                for side,path in zip(['away','home'],g['score_fields']):
                    assert path.startswith('/score/'+side+'/');scores.append(m['score'][side][path.rsplit('/',1)[-1]])
                names=[m['teams'][s]['nameFull'] for s in ['away','home']];ids=[m['teams'][s]['dflDatalibraryClubId'] for s in ['away','home']];assert g['halftime_scores']==[m['score'][s].get('halftime') for s in ['away','home']]
                if 'result_revision' in g:
                    v=g['result_revision'];assert mid=='DFL-MAT-J0406K' and v['played_score']==[m['score'][s]['fulltime'] for s in ['away','home']]==[1,1] and v['awarded_score']==scores==[2,0] and v['award_effective_from']=='2025-01-09';meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(v['ruling_request_id'],)).fetchone()[0]);b=(ROOT/meta['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==meta['sha256'];text=BeautifulSoup(b,'html.parser').get_text(' ',strip=True);assert '09.01.2025' in text and '2:0' in text and 'Bochum' in text;revisions.append(dict(match_id=mid,**v));checks['dated_official_result_revision']+=1
            elif league=='Ligue 1':
                assert m['matchId']==mid and m['championshipId']==g['competition_id']==1 and m['period']=='fullTime' and not m['isLive'] and not m['unknownMatch'];assert g['home']==m['home']['clubIdentity'] and g['away']==m['away']['clubIdentity'];when=dt.datetime.fromisoformat(m['date']);zone='Europe/Paris';scores=[m[s]['score'] for s in ['away','home']];names=[m[s]['clubIdentity']['name'] for s in ['away','home']];ids=[m[s]['clubId'] for s in ['away','home']];cal=source(g['calendar_request_id']);assert mid in cal['gameWeeks'][str(m['gameWeekNumber'])]['matchesIds'];assert all(i.startswith('l1_championship_club_'+g['season'][:4]+'_') for i in ids)
            else:
                assert m['matchId']==mid and m['status']=='FINISHED' and m['phase']=='FULL_TIME' and not m['isUnknownKickOffTime'];assert m['seasonId']==g['season_id']==raw['competition']['seasonId'];assert g['competition_id']==raw['competition']['competitionId'];when=dt.datetime.fromisoformat(m['matchDateUtc']);zone='Europe/Rome';local=when.astimezone(ZoneInfo(zone));assert local.replace(tzinfo=None)==dt.datetime.fromisoformat(m['matchDateLocal']);scores=[m['providerAwayScore'],m['providerHomeScore']];assert scores==[m['awayScorePush'],m['homeScorePush']];names=[m[s]['officialName'] for s in ['away','home']];ids=[m[s]['teamId'] for s in ['away','home']]
                for s,score in zip(['away','home'],scores):assert g[s]==dict(id=m[s]['teamId'],provider_id=m[s]['providerId'],name=m[s]['officialName'],abbr=m[s]['acronymName'],score=score)
                assert g['location']==', '.join(filter(None,[m.get('stadiumName'),m.get('cityName')]));offset=local.strftime('%z');offset=offset[:3]+':'+offset[3:]
                if m['localTimeUtcOffset']!=offset:
                    assert g['time_offset_discrepancy']['raw']==m['localTimeUtcOffset'] and g['time_offset_discrepancy']['expected']==offset;checks['source_offset_discrepancy_resolved_by_utc_local_pair']+=1
                else:assert g['time_offset_discrepancy'] is None
                assert not m['winTeamId'] or m['winTeamId']==(None if scores[0]==scores[1] else ids[int(scores[1]>scores[0])])
            assert when.tzinfo and when.astimezone(dt.UTC).isoformat()==g['scheduled_start_utc'];assert when.astimezone(ZoneInfo(zone)).date().isoformat()==g['date'];assert '2024-01-01'<=g['date']<='2026-09-14';assert scores==g['scores'] and all(type(v)is int and v>=0 for v in scores);assert ids[0]!=ids[1];assert g['winner']==('Draw' if scores[0]==scores[1] else names[int(scores[1]>scores[0])]);checks['official_teams_score_winner_date']+=1;seasons[g['season']].append((ids,g['date']))
        summary=[]
        for season,gs in sorted(seasons.items()):
            away=collections.Counter(ids[0] for ids,_ in gs);home=collections.Counter(ids[1] for ids,_ in gs);assert len({tuple(ids) for ids,_ in gs})==len(gs);complete=season in ['2024-25','2025-26']
            if complete:assert len(gs)==full and len(home)==len(away)==teams_per and set(home)==set(away) and all(home[t]==away[t]==teams_per-1 for t in home);checks['full_season_counts']+=1
            summary.append(dict(season=season,games=len(gs),complete_season=complete,first=min(d for _,d in gs),last=max(d for _,d in gs)))
        assert checks['full_season_counts']==2
        out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Official calendar only; no assertion of available market prices or supporting tables',competition=league,games=sum(len(v) for v in seasons.values()),checks=dict(checks),source_hashes=len(set(cache)-before),seasons=summary,result_revisions=revisions)
        (ROOT/'reports'/(league.lower().replace(' ','')+'_calendar_validation.json')).write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out),flush=True)
    db.close()

if __name__=='__main__':main()
