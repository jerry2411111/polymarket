"""Independently recompute combined EU performance for bounded date queries."""
import collections,datetime as dt,json,math,sqlite3,statistics
from build_history_catalog import DB
from probe_history import ROOT
from temporal_queries import QUERIES

def eq(a,b):return a is None and b is None or a is not None and b is not None and math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-8)
def mean(v):return statistics.mean(v) if v and all(x is not None for x in v) else None

def main():
 db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;checks=collections.Counter();facts=collections.defaultdict(list);games={gid:json.loads(b) for gid,b in db.execute('SELECT * FROM _eu_game_facts')};scope=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
 for file in ['eu_source_player_facts_validation.json','eu_identity_validation.json','eu_performance_facts_install.json']:assert json.loads((ROOT/'reports'/file).read_text())['status']=='WORKING'
 for b, in db.execute('SELECT body FROM _eu_player_game_facts'):
  p=json.loads(b);assert p['game_id'] in games;g=games[p['game_id']];assert p['team_name']==g['teams'][p['side']] and p['win']==int(g['scores'][p['side']]>g['scores'][1-p['side']]);assert p['game_date']>=g['date'] or p.get('affiliation_observation_safe') is True
  table='_epl_player_game_facts' if p['source_person_id'].startswith('EU_PL:') else '_eu_source_player_game_facts';source=json.loads(db.execute('SELECT body FROM '+table+' WHERE player_id=? AND game_id=?',(p['source_person_id'],p['game_id'])).fetchone()[0])
  for field in ['game_date','did_play','score','assists','minutes','starter','win']:assert source[field]==p[field];checks['verified_source_fact_correspondence']+=1
  if p['did_play']:facts[p['player_id']].append(p)
 actual={(r['player_id'],r['game_id']):dict(r) for r in db.execute("SELECT * FROM _player_game_results WHERE league='EU soccer'")};assert len(actual)==sum(map(len,facts.values()))
 for pid,rows in facts.items():
  for p in rows:
   r=actual[pid,p['game_id']]
   for field in ['player_name','team_name','game_date','score','assists','minutes','starter','win']:assert r[field]==p[field];checks['exact_performance_SQL_fact']+=1
 windows=[(scope[0],d,False) for d in ['2024-01-01','2024-08-16','2024-12-31','2025-05-25','2025-09-01','2025-12-31','2026-05-31',scope[1]]]+[('2025-08-01','2025-12-31',True),('2026-01-01','2026-05-31',True)];examples=[]
 for lo,day,custom in windows:
  expected={pid:[p for p in ps if lo<=p['game_date']<=day] for pid,ps in facts.items()};expected={pid:ps for pid,ps in expected.items() if ps};query=QUERIES['player_performance'] if custom else "SELECT * FROM player_performance WHERE league='EU soccer' AND as_of_date=:query_date";rows=[dict(r) for r in db.execute(query,dict(collection_start=lo,query_date=day)) if r['league']=='EU soccer'];assert len(rows)==len({r['player_id'] for r in rows}) and {r['player_id'] for r in rows}==set(expected);means={pid:mean([p['score'] for p in ps]) for pid,ps in expected.items()};complete=[m for m in means.values() if m is not None];mu=statistics.mean(complete) if complete else None;sd=statistics.pstdev(complete) if complete else None
  for r in rows:
   ps=expected[r['player_id']];assert r['games_played']==len(ps) and eq(r['overall_winrate'],mean([p['win'] for p in ps]));checks['past_only_games_and_winrate']+=1
   for field in ['score','assists','minutes']:
    values=[p[field] for p in ps];avg=mean(values);std=statistics.stdev(values) if avg is not None and len(values)>1 else None;assert eq(r['average_'+field+'_per_game'],avg) and eq(r['std_'+field+'_per_game'],std),(day,r['player_id'],field);checks['independent_average_and_sample_SD']+=2
   assert eq(r['starter_percentage_overall'],mean([p['starter'] for p in ps]));avg=means[r['player_id']];assert eq(r['score_z_score'],(avg-mu)/sd if avg is not None and sd else None);checks['no_future_or_missing_value_z_cohort']+=1
  for name,key,win in [('team_history','team_name','winrate'),('manager_performance','manager_id','overall_winrate')]:
   base='_team_game_results' if name=='team_history' else '_manager_game_results';grouped=collections.defaultdict(list)
   for r in db.execute('SELECT * FROM '+base+" WHERE league='EU soccer' AND game_date BETWEEN ? AND ?",(lo,day)):grouped[r[key]].append(dict(r))
   query=QUERIES[name] if custom else 'SELECT * FROM '+name+" WHERE league='EU soccer' AND as_of_date=:query_date";out=[dict(r) for r in db.execute(query,dict(collection_start=lo,query_date=day)) if r['league']=='EU soccer'];assert {r[key] for r in out}==set(grouped) and len(out)==len(grouped)
   for r in out:
    ps=grouped[r[key]];assert r['games_played']==len(ps) and eq(r[win],mean([p['win'] for p in ps]));assert r['home_times']==sum(p['home_away']=='Home' for p in ps) and r['away_times']==sum(p['home_away']=='Away' for p in ps);assert eq(r['average_score_margin'],mean([p['score_for']-p['score_against'] for p in ps]));checks['past_only_'+name]+=1
  examples.append(dict(collection_start=lo,query_date=day,custom_lower_bound=custom,players=len(rows)))
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',games=len(games),players_with_appearances=len(facts),played_rows=len(actual),checks=dict(checks),examples=examples,limits='Only collected games with usable provider odds enter statistics. Missing source statistics propagate to averages and SD. Salary and profiles are validated separately.');(ROOT/'reports/eu_performance_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
