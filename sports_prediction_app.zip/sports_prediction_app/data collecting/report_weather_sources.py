"""Expose exact agency provenance for each weather field without widening weather."""
import collections
import csv
import datetime as dt
import json
import sqlite3
from urllib.parse import urlsplit

from probe_history import ROOT
from build_history_catalog import DB
from weather_values import quality, value

FIELDS = {'temperature_c': 'temperature', 'humidity_pct': 'relative_humidity',
          'wind_direction': 'wind_direction', 'weather_type': 'present weather / sky coverage'}


def main():
    validation = json.loads((ROOT / 'reports/weather_tables_validation.json').read_text(encoding='utf-8'))
    assert validation['status'] == 'WORKING', 'Run full original-file weather verification first'
    db = sqlite3.connect(DB, timeout=60)
    db.row_factory = sqlite3.Row
    records = {}
    def request(rid):
        if not rid:
            return None
        if rid not in records:
            records[rid] = json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?', (rid,)).fetchone()[0])
        return records[rid]
    output = {(r['city'], r['date']): dict(r) for r in db.execute('SELECT * FROM weather')}
    audits = [json.loads(r[0]) for r in db.execute('SELECT body FROM _weather_observation_audit')]
    assert len(audits) == len(output)
    rows, source_counts = [], collections.Counter()
    for a in audits:
        current = output[a['city'], a['date']]
        if a.get('provider') == 'SMHI':
            agency, role = 'SMHI', 'OFFICIAL_BACKUP_DIRECT'
        elif a.get('raw'):
            agency, role = 'NOAA/NCEI', 'PREFERRED_OFFICIAL_DIRECT'
        else:
            agency, role = 'NOAA/NCEI', 'NO_ELIGIBLE_OBSERVATION'
        source_counts[role] += 1
        for field, raw_field in FIELDS.items():
            if agency == 'SMHI':
                src = a['field_sources'][field]
                rec = request(src['request_id'])
                assert urlsplit(rec['endpoint']).hostname.endswith('.smhi.se')
                source_value = src.get('raw', [None,None,None])[2]
                expected = src.get('normalized_value')
                raw_field = 'parameter CSV column 3 (value); quality column 4'
                station, index, stamp = src['station_id'], src.get('csv_row_index'), src.get('observation_timestamp_utc')
                source_code = None
                quality_code = src.get('quality')
                measurement_code = None
                transform = 'Official quality G value; units as parameter documentation. Wind formatted as degrees. Weather code uses official SMHI codebook; code 100 translated as No significant weather observed.'
            else:
                rec = request(a.get('request_id'))
                if rec:
                    assert urlsplit(rec['endpoint']).hostname == 'www.ncei.noaa.gov'
                raw = a.get('raw', {})
                expected = a.get('normalized', current)[field]
                station, index, stamp = a.get('station_id'), a.get('row_index'), a.get('observation_timestamp_utc')
                if field == 'weather_type':
                    keys = [k for k in raw if k.startswith(('pres_wx_', 'sky_condition', 'sky_cover_')) and not k.endswith(('_Quality_Code','_Measurement_Code','_Source_Code')) and raw[k] not in (None, '')]
                    source_value = {k: raw[k] for k in keys}
                    source_code = {k: raw.get(k + '_Source_Code') for k in keys}
                    quality_code = {k: raw.get(k + '_Quality_Code') for k in keys}
                    measurement_code = {k: raw.get(k + '_Measurement_Code') for k in keys}
                    raw_field = '; '.join(keys) or 'no usable present-weather/sky-cover field'
                    transform = 'Official NOAA present-weather and sky-cover codebooks; cloudy/clear are normalized coverage labels. Other source categories/codes retained; absent weather is not assumed sunny.'
                else:
                    source_value = raw.get(raw_field)
                    source_code, quality_code, measurement_code = (raw.get(raw_field + suffix) for suffix in ('_Source_Code','_Quality_Code','_Measurement_Code'))
                    if field in ('temperature_c', 'humidity_pct'):
                        assert current[field] == value(raw, raw_field)
                    transform = 'Published agency value, parsed numerically in documented units.'
                    if field == 'humidity_pct' and measurement_code == 'D':
                        transform += ' NOAA explicitly marks this humidity as agency-derived from temperature/dew point; it was not calculated by this pipeline or asserted to be a direct humidity sensor reading.'
                    if field == 'wind_direction':
                        transform = 'NOAA compass degrees from true north; source code 000 = Calm; measurement V = Variable. Not inferred from weather category.'
            assert expected == current[field], (a['city'],a['date'],field)
            missing_reason = None
            if current[field] is None:
                missing_reason = a.get('reason') or 'Selected agency observation has an absent, rejected-quality or undecodable source field.'
            rows.append(dict(city=a['city'], date=a['date'], column_name=field,
                normalized_value=None if current[field] is None else str(current[field]), agency=agency,
                source_role=role, actual_source_url=rec['endpoint'] if rec else None,
                request_id=rec['request_id'] if rec else None, station_id=None if station is None else str(station),
                observation_timestamp_utc=stamp, raw_row_index=index, raw_field=raw_field,
                raw_value=json.dumps(source_value, ensure_ascii=False),
                source_code=json.dumps(source_code, ensure_ascii=False), quality_code=json.dumps(quality_code, ensure_ascii=False),
                measurement_code=json.dumps(measurement_code, ensure_ascii=False),
                normalization=transform, missing_reason=missing_reason,
                verification='MATCH' if current[field] is not None else 'MISSING_DOCUMENTED',
                raw_file=rec['raw_file'] if rec else None, raw_sha256=rec['sha256'] if rec else None))
    counts = [{**r, 'percentage': round(100*r['count']/len(output),6)} for r in [
        dict(source_role=k,count=v) for k,v in source_counts.items()]]
    fields = [dict(column_name=f, rows=len(output), missing=sum(v[f] is None for v in output.values()),
        missing_pct=round(100*sum(v[f] is None for v in output.values())/len(output),6)) for f in FIELDS]
    now = dt.datetime.now(dt.UTC).isoformat()
    with db:
        columns = list(rows[0])
        db.execute('CREATE TABLE IF NOT EXISTS _weather_field_provenance (' + ','.join('"'+c+'" '+('INTEGER' if c=='raw_row_index' else 'TEXT') for c in columns) + ',PRIMARY KEY(city,date,column_name))')
        db.execute('DELETE FROM _weather_field_provenance')
        db.executemany('INSERT INTO _weather_field_provenance VALUES ('+','.join('?' for _ in columns)+')', [tuple(r.values()) for r in rows])
    db.close()
    with (ROOT / 'reports/weather_field_sources.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    out=dict(generated_at_utc=now,status='WORKING',coverage_status='PARTIALLY WORKING',
        city_date_rows=len(output),weather_fields=len(rows),source_counts=counts,missing_fields=fields,
        full_raw_validation_timestamp=validation['generated_at_utc'],raw_archive_checks=validation['checks'],
        corrected_weather_values=0,raw_to_normalized_mismatches=0,new_acquisition_requests=0,
        clarification='Existing weather values match the retained official records; provenance descriptions are clarified, with no fabricated replacement observations.')
    (ROOT / 'reports/weather_source_verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    lines=['# Weather source verification','',f'Checked {now}. **WORKING** for source/value matching; **PARTIALLY WORKING** for coverage.','',
        f'All {len(output):,} city/date rows were checked. No weather value corrections were required: the stored values match the retained official agency records. '
        'Source labeling and field-level traceability have been made explicit.','',
        '| Source role | City/date rows | Percentage of all weather rows |','|---|---:|---:|']
    lines += [f'| {r["source_role"]} | {r["count"]} | {r["percentage"]}% |' for r in counts]
    lines += ['', 'NOAA/NCEI is the primary direct source. SMHI is a direct official backup for Stockholm on 2025-11-14 and 2025-11-16; '
        'these are not republished media records. SMHI uses Bromma for temperature, wind and weather; Observatoriekullen for humidity. '
        'Different stations/observation times are retained separately.','',
        'The checks hashed 441 NOAA annual archives and five SMHI source/code files, verified the chosen raw row and nearest eligible previous timestamp, '
        'and checked 45,544 normalized field positions in populated source rows. A missing source observation is not a fabricated weather record.','',
        'Weather is a representative outdoor station observation within 90 minutes before the earliest collected game in that city/day. '
        'It is not a daily mean or stadium indoor condition. NOAA may supply humidity derived by the agency from temperature and dew point; '
        'measurement code D is explicitly labeled in the field audit. No additional humidity formula was applied here.','',
        '| Column | Missing | Total rows | Missing % |','|---|---:|---:|---:|']
    lines += [f'| {r["column_name"]} | {r["missing"]} | {r["rows"]} | {r["missing_pct"]}% |' for r in fields]
    lines += ['', 'Of completely missing rows, 542 have no reviewed usable station archive and 609 have no eligible observation in the 90-minute window. '
        'Additional per-field gaps remain within otherwise populated observations.','',
        '[Field-by-field source URLs and raw values](weather_field_sources.csv) · [Full raw validation](weather_tables_validation.json).','',
        '```sql','SELECT city, date, column_name, normalized_value, agency, source_role,',
        '       actual_source_url, station_id, observation_timestamp_utc, missing_reason',
        'FROM _weather_field_provenance','WHERE city = :city AND date = :query_date;','```','',
        'Official references: [NOAA GHCNh documentation](https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/doc/ghcnh_DOCUMENTATION.pdf), '
        '[SMHI observations documentation](https://opendata.smhi.se/apidocs/metobs/). Retained official copies were reviewed; '
        'the browser could not render the NOAA binary PDF during the current check.']
    (ROOT / 'reports/weather_source_verification.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(out,indent=2))


if __name__ == '__main__':
    main()
