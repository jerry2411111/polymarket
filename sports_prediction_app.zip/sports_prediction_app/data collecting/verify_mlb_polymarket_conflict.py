import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT
c=HistoryClient()
doc,dr=c.get('https://docs.polymarket.com/api-reference/markets/get-market-by-id.md',document=True)
assert b'/markets/{id}' in doc
m,r=c.get('https://gamma-api.polymarket.com/markets/559108',refresh=True)
assert m['id']=='559108'
g,sr=c.get('https://statsapi.mlb.com/api/v1.1/game/777235/feed/live',refresh=True)
report=dict(checked_at_utc=dt.datetime.now(dt.UTC).isoformat(),market_id=m['id'],official_game_id='777235',market_request_id=r['request_id'],official_request_id=sr['request_id'],documentation_request_id=dr['request_id'],documentation_url=dr['endpoint'],outcomes=json.loads(m['outcomes']),outcome_prices=json.loads(m['outcomePrices']),market_start=m['gameStartTime'],market_status=m.get('umaResolutionStatus'),teams=[g['gameData']['teams'][s]['name'] for s in ['away','home']],official_score=[g['liveData']['linescore']['teams'][s]['runs'] for s in ['away','home']],official_start=g['gameData']['datetime']['dateTime'],official_url='https://www.mlb.com/gameday/777235/final/wrap',market_url='https://polymarket.com/event/'+m['slug'])
report['status']='MATCHING PROBLEM' if report['outcome_prices']==['0','1'] and report['official_score']==[18,1] else 'REQUIRES REVIEW'
report['handling']='Exclude this Polymarket contract family; keep official winner and other independently matched provider data. Do not swap outcome token identities to force agreement.'
(ROOT/'reports/mlb_polymarket_resolution_conflict.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
