"""Small real NHL API checks following the current official schedule client."""
import datetime as dt,json,sqlite3
from history_client import HistoryClient
from probe_history import ROOT

def main():
 c=HistoryClient();out=[]
 for day in ['2024-01-01','2025-01-04','2026-06-12']:
  url='https://api-web.nhle.com/v1/schedule/'+day
  try:
   d,r=c.get(url);weeks=d.get('gameWeek');assert isinstance(weeks,list) and weeks
   games=[g for w in weeks for g in w.get('games',[])];assert len({g['id'] for g in games})==len(games)
   row=dict(request_date=day,url=url,status='SCHEMA_CHECKED',request_id=r['request_id'],top_level_keys=list(d),covered_dates=[w['date'] for w in weeks],games=len(games),examples=games[:2])
  except Exception as e:row=dict(request_date=day,url=url,status='ERROR',error=str(e))
  out.append(row);print(json.dumps(row),flush=True)
 (ROOT/'reports/nhl_schedule_pilot.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),requests=out,note='Schema/pilot response only; independent final-score/identity validation precedes publication.'),indent=2),encoding='utf-8')

if __name__=='__main__':main()
