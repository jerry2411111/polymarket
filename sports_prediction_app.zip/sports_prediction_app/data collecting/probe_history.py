"""Read current official specifications and issue small logged coverage probes."""
import sys,json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
HOSTS={'external-api.kalshi.com','gamma-api.polymarket.com','clob.polymarket.com','data-api.polymarket.com',
       'docs.kalshi.com','docs.polymarket.com','www.ncei.noaa.gov','developer.sportradar.com',
       'statsdmz.nba.com','www.nba.com','www.nhl.com','www.mlb.com','official.nba.com',
       'www.salaryswish.com','polymarket.com','kalshi.com'}
HOSTS.update({'docs.statsapi.mlb.com','statsapi.mlb.com','stats.nba.com','cdn.nba.com','api-web.nhle.com','api.nhle.com'})

def Client(root=ROOT):
 """Compatibility entry point using the current shared-rate-limit SQL logger."""
 from history_client import HistoryClient
 return HistoryClient(root)

DOCS=[
 'https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps.md',
 'https://docs.kalshi.com/api-reference/historical/get-historical-markets.md',
 'https://docs.kalshi.com/api-reference/market/get-markets.md',
 'https://docs.kalshi.com/api-reference/milestone/get-milestones.md',
 'https://docs.kalshi.com/api-reference/structured-targets/get-structured-targets.md',
 'https://docs.kalshi.com/api-reference/live-data/get-live-data.md',
 'https://docs.kalshi.com/api-reference/historical/get-historical-market-candlesticks.md',
 'https://docs.polymarket.com/api-reference/events/list-events.md',
 'https://data-api.polymarket.com/v2/openapi.json',
 'https://docs.statsapi.mlb.com/',
]
def main():
 c=Client(ROOT);summaries=[]
 for url in DOCS:
  try:
   data,r=c.get(url,document=True);s=data.decode('utf-8',errors='replace')
   item=dict(url=url,request_id=r['request_id'],status=r['status'])
   if url.endswith('openapi.json'):
    d=json.loads(s);item['servers']=d.get('servers');item['paths']={k:v for k,v in d.get('paths',{}).items() if 'price' in k or 'event' in k}
   elif url.endswith('.md'):
    # Preserve full raw; present schema parameter descriptions for implementation.
    item['documentation']=s
   else:item['documentation']=s[:1800]
   summaries.append(item)
  except Exception as e:summaries.append(dict(url=url,error=str(e)))
 (ROOT/'reports').mkdir(exist_ok=True)
 (ROOT/'reports/current_documentation.json').write_text(json.dumps(summaries,indent=2),encoding='utf-8')
 print('Documentation captured',len(summaries),flush=True)
 if '--docs-only' in sys.argv:return
 for path,args in [('/historical/cutoff',{}),('/milestones',{'limit':5,'minimum_start_date':'2023-09-13T00:00:00Z','maximum_start_date':'2023-10-01T00:00:00Z','type':'basketball_game'})]:
  try:
   d,r=c.get('https://external-api.kalshi.com/trade-api/v2'+path,args)
   print(json.dumps({'endpoint':path,'data':d}),flush=True)
  except Exception as e:print('PROBE ERROR',path,str(e),flush=True)

if __name__=='__main__':main()
