"""Reconcile NBA provider dates/order against native official game identities.

Acquisition catalogs and raw responses remain unchanged. Canonical mappings are
applied at normalization, and keep every source game ID for provenance.
"""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from core import utc
from nba_identity import canonical_ids,special_teams,full_team_name
from quote_selection import available_at,inside_window

def main():
    db=sqlite3.connect(DB,timeout=60)
    originals={i:json.loads(b) for i,b in db.execute("SELECT id,body FROM _history_games WHERE json_extract(body,'$.league')='NBA'")}
    cards=[json.loads(b) for (b,) in db.execute('SELECT body FROM _official_nba_schedule')];index=collections.defaultdict(list)
    pages={}
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='_official_nba_page_games'").fetchone():pages={i:json.loads(b) for i,b in db.execute('SELECT official_game_id,body FROM _official_nba_page_games')}
    for r in cards:
        if all(r['team_tricodes']):index[frozenset(r['team_tricodes'])].append(r)
    aliases={'NY':'NYK','SA':'SAS','GS':'GSW','NO':'NOP'};mappings=[];issues=[];groups=collections.defaultdict(list)
    canonical_by_id=canonical_ids(cards);special=special_teams(db);date_corrections={}
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='_nba_official_date_corrections'").fetchone():date_corrections={i:json.loads(b) for i,b in db.execute('SELECT source_game_id,body FROM _nba_official_date_corrections')}
    for gid,g in originals.items():
        codes=[aliases.get(c,c) for c in gid.split('_')[2:4]];start=utc(g['start'])
        matches=[r for r in index[frozenset(codes)] if r.get('start_utc') and abs((utc(r['start_utc'])-start).total_seconds())<=6*3600]
        if g.get('official_game_id'):matches=[r for r in matches if r['official_game_id']==g['official_game_id']]
        if gid in date_corrections:
            native=date_corrections[gid]['official_game_id'];matches=[r for r in index[frozenset(codes)] if r['official_game_id']==native]
        if len(matches)!=1:
            issues.append(dict(source_game_id=gid,reason='Official NBA identity not uniquely matched within six hours of source start',candidate_count=len(matches)));continue
        r=matches[0];order=[r['team_tricodes'].index(c) for c in codes]
        canonical=canonical_by_id[r['official_game_id']]
        m=dict(source_game_id=gid,game_id=canonical,official_game_id=r['official_game_id'],source_to_canonical=order,source_start_utc=g['start'],official_scheduled_start_utc=r['start_utc'],offset_seconds=(start-utc(r['start_utc'])).total_seconds(),request_id=r['request_id'])
        if gid in date_corrections:m['documented_date_correction']=date_corrections[gid]
        mappings.append(m);groups[canonical].append((g,r,m))
    games=[];facts=[]
    for gid,entries in groups.items():
        # Prefer an existing scorer-verified identity and useful provider PBP;
        # every entry was independently matched to the same official game ID.
        assert len({r['official_game_id'] for _,r,_ in entries})==1
        g,r,m=max(entries,key=lambda e:(bool(e[0].get('official_score_request_id')),bool(e[0].get('milestone_id'))))
        g=dict(g);order=m['source_to_canonical'];inverse=[order.index(i) for i in range(2)]
        teams=[full_team_name(g['teams'][i]) for i in inverse];ids=[g['team_ids'][i] for i in inverse]
        teams=[special[code]['full_name'] if code in special else name for code,name in zip(r['team_tricodes'],teams)]
        source_scores=[g['scores'][i] for i in inverse]
        if all(v is not None for v in source_scores) and source_scores!=r['scores']:
            issues.append(dict(game_id=gid,reason='Official NBA final differs from catalog score',source_scores=source_scores,official_scores=r['scores'],resolution_status='RESOLVED_OFFICIAL_SCORER',request_id=r['request_id']))
        season=' '.join(str(r[k]) for k in ['season_year','competition_type'] if r.get(k))
        g.update(game_id=gid,date=r['date'],teams=teams,team_ids=ids,start=r['start_utc'],start_basis='Official NBA scheduled start; verified opening clock overrides at normalization',scores=r['scores'],winner=teams[int(r['scores'][1]>r['scores'][0])],provider_sources=sorted({p for x,_,_ in entries for p in x['provider_sources']}),validation_status='OFFICIAL_NBA_CARD_ID_AND_RESULT_VERIFIED',source_game_ids=[x['game_id'] for x,_,_ in entries],official_game_id=r['official_game_id'],season=season)
        home=g.get('home_away');home=';'.join(home.split(';')[i] for i in inverse) if home else None
        # The scorer report's physical/neutral venue evidence has precedence;
        # otherwise retain the official card's designated home/away order.
        g['home_away']=home or 'Away;Home'
        page=pages.get(r['official_game_id'])
        if page:
            assert page['scores']==r['scores'] and page['official_team_ids']==r['official_team_ids']
            g.update(location=page['location'],city=page['city'],home_away=page['home_away'],venue_request_id=page['request_id'])
        f=dict(game_id=gid,league='NBA',date=r['date'],teams=teams,scores=r['scores'],winner=g['winner'],home_away=g['home_away'],location=g.get('location'),city=g.get('city'),request_id=r['request_id'],source_url=r['source_url'],official_game_id=r['official_game_id'],official_team_ids=r['official_team_ids'],break_scores=r['break_scores'],season_year=r.get('season_year'),competition_type=r['competition_type'],season=season,is_training=r['is_training'],classification_request_id=r['request_id'],scheduled_start_utc=r['start_utc'])
        if page:f.update(venue_request_id=page['request_id'],is_neutral=page['is_neutral'])
        games.append(g);facts.append(f)
    for table,key,rows in [('_nba_canonical_map','source_game_id',mappings),('_nba_canonical_games','game_id',games)]:
        db.execute(f'CREATE TABLE IF NOT EXISTS {table} (id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute(f'DELETE FROM {table}');db.executemany(f'INSERT INTO {table} VALUES (?,?)',[(r[key],json.dumps(r)) for r in rows]);db.commit()
    db.execute("DELETE FROM _official_game_facts WHERE json_extract(body,'$.league')='NBA'");db.executemany('INSERT INTO _official_game_facts VALUES (?,?)',[(r['game_id'],json.dumps(r)) for r in facts]);db.commit()
    db.execute('CREATE TABLE IF NOT EXISTS _nba_canonical_audit (body TEXT NOT NULL)');db.execute('DELETE FROM _nba_canonical_audit');db.executemany('INSERT INTO _nba_canonical_audit VALUES (?)',[(json.dumps(x),) for x in issues]);db.commit();db.close()
    report=dict(original_entries=len(originals),canonical_games=len(games),matched_entries=len(mappings),unmatched_entries=len(originals)-len(mappings),duplicate_entries_removed=len(mappings)-len(games),changed_ids=sum(m['source_game_id']!=m['game_id'] for m in mappings),issues=issues)
    (ROOT/'reports/nba_canonical_matching.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='issues'}))

def apply(db,games,contracts,cps,clocks):
    """Apply the persisted canonical mapping to an in-memory normalizer input."""
    if not db.execute("SELECT 1 FROM sqlite_master WHERE name='_nba_canonical_map'").fetchone():return games,contracts,cps,clocks
    mapping={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _nba_canonical_map')}
    canon={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _nba_canonical_games')}
    output_games={k:v for k,v in games.items() if v['league']!='NBA'};output_games.update(canon)
    cs=[];groups=collections.defaultdict(list)
    for c in contracts:
        old=c['game_id']
        if games[old]['league']=='NBA':
            if old not in mapping:continue
            m=mapping[old];c=dict(c,source_game_id=old,game_id=m['game_id'],side=m['source_to_canonical'][c['side']])
        groups[c['game_id'],c['provider']].append(c)
    choices=[]
    for key,values in groups.items():
        by_source=collections.defaultdict(list)
        for c in values:by_source[c.get('source_game_id',c['game_id'])].append(c)
        if len(by_source)>1:
            target=dt.date.fromisoformat(output_games[key[0]]['date'])
            distances={sid:abs((dt.date.fromisoformat(games[sid]['date'])-target).days) for sid in by_source}
            best=min(distances.values());ids=[sid for sid,d in distances.items() if d==best]
            if len(ids)!=1:raise ValueError('Ambiguous duplicate NBA market family after official date match: '+str(key))
            chosen=ids[0];choices.append(dict(game_id=key[0],provider=key[1],selected_source_game_id=chosen,selected_contract_ids=[c['contract_id'] for c in by_source[chosen]],excluded_contract_ids=[c['contract_id'] for sid,cs0 in by_source.items() if sid!=chosen for c in cs0],reason='Prefer the source game date matching the official played date over an earlier postponed-game market'))
            values=by_source[chosen]
        # More than one native market family can refer to this same game.
        # A coherent family is selected after its real price history is read.
        cs.extend(values)
    new_cps=collections.defaultdict(list);new_clocks={k:v for k,v in clocks.items() if k not in mapping}
    for gid,rows in cps.items():
        if games[gid]['league']!='NBA':new_cps[gid]=rows
    for gid,g in canon.items():
        # Scores are always replaced by official-card period values later.
        entries=[(sid,rows) for sid,rows in cps.items() if sid in mapping and mapping[sid]['game_id']==gid]
        if not entries:raise ValueError('Canonical NBA game has no checkpoint structure')
        sid,rows=max(entries,key=lambda item:sum(r.get('timestamp') is not None for r in item[1]));new_cps[gid]=[dict(r,game_id=gid) for r in rows]
        candidates=[clocks[sid] for sid in g['source_game_ids'] if sid in clocks]
        if candidates:
            if len({x['official_start_utc'] for x in candidates})>1:raise ValueError('Conflicting official NBA clocks after reconciliation')
            new_clocks[gid]=candidates[0]
    db.execute('CREATE TABLE IF NOT EXISTS _nba_contract_choice_audit (body TEXT NOT NULL)');db.execute('DELETE FROM _nba_contract_choice_audit');db.executemany('INSERT INTO _nba_contract_choice_audit VALUES (?)',[(json.dumps(x),) for x in choices]);db.commit()
    return output_games,cs,new_cps,new_clocks

def select_families(db,games,contracts,points,clocks,cps):
    grouped=collections.defaultdict(list);out=[];audit=[]
    for c in contracts:
        if games[c['game_id']]['league']!='NBA':out.append(c)
        else:grouped[c['game_id'],c['provider']].append(c)
    for (gid,provider),cs in grouped.items():
        families=collections.defaultdict(list)
        for c in cs:families[c['market_id'] if provider=='polymarket' else c['event_id']].append(c)
        g=games[gid];clock=clocks.get(gid);start=int(utc(clock['official_start_utc'] if clock else g['start']).timestamp());windows=[]
        if clock:
            windows=[(start+60,start+120)]+[(int(utc(b['start_utc']).timestamp()),int(utc(b['end_utc']).timestamp())) for b in clock['breaks'] if b['start_utc'] and b['end_utc']]
        else:
            opening=next((x for x in cps[gid] if x['ordinal']==0 and x['timestamp']),None)
            if opening:
                t=int(utc(opening['timestamp']).timestamp());windows=[(t,t+120)]
        ranked=[]
        for fid,ms in families.items():
            if len(ms)!=2 or {c['side'] for c in ms}!={0,1}:raise ValueError('NBA market family lacks exactly one contract per team: '+str((gid,fid)))
            available=any((not c.get('open') or p['timestamp']>=int(utc(c['open']).timestamp())) and (available_at(p)<start or any(inside_window(p,lo,hi) for lo,hi in windows)) for c in ms for p in points[c['provider'],c['contract_id']])
            opened=min((utc(c['open']).timestamp() for c in ms if c.get('open')),default=float('inf'))
            ranked.append((not available,opened,str(fid),ms))
        ranked.sort(key=lambda x:x[:3]);chosen=ranked[0];out.extend(chosen[3])
        if len(ranked)>1:
            audit.append(dict(game_id=gid,provider=provider,selected_market_family=chosen[2],selected_contract_ids=[c['contract_id'] for c in chosen[3]],excluded_contract_ids=[c['contract_id'] for r in ranked[1:] for c in r[3]],candidate_families=[dict(market_family=r[2],has_qualifying_observation=not r[0],open_timestamp=r[1] if r[1]!=float('inf') else None) for r in ranked],rule='Among coherent two-team families with usable observations, choose earliest-opened market; keep both outcomes from that same family'))
    db.execute('CREATE TABLE IF NOT EXISTS _nba_market_family_choices (body TEXT NOT NULL)');db.execute('DELETE FROM _nba_market_family_choices');db.executemany('INSERT INTO _nba_market_family_choices VALUES (?)',[(json.dumps(x),) for x in audit]);db.commit()
    return out

if __name__=='__main__':main()
