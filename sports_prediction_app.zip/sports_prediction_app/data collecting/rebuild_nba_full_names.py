"""Propagate full NBA team names through derived tables and verify odds unchanged."""
import datetime as dt,hashlib,json,subprocess,sys,sqlite3
from pathlib import Path
from build_history_catalog import DB
from probe_history import ROOT

def fingerprint():
    db=sqlite3.connect(DB);out={}
    for table in ['polymarket_pre_match','kalshi_pre_match','polymarket_in_game','kalshi_in_game']:
        cols=[r[1] for r in db.execute('PRAGMA table_info('+table+')') if r[1] not in ['match','final']]
        rows=list(db.execute('SELECT '+','.join('"'+c+'"' for c in cols)+' FROM '+table+" WHERE league='NBA' ORDER BY game_id"));out[table]=dict(rows=len(rows),non_name_values_sha256=hashlib.sha256(json.dumps(rows).encode()).hexdigest())
    db.close();return out

def main():
    before=fingerprint();base=Path(__file__).resolve().parent
    steps=['build_history_odds.py','build_nba_performance.py','build_nba_personal_facts.py','install_temporal_performance.py','build_nba_dated_profiles.py','build_nba_manager_history.py','validate_nba_performance.py','validate_nba_profiles.py','validate_nba_managers.py','export_nba_support_tables.py','validate_nba_main.py']
    for step in steps:
        print('FULL NAME PROPAGATION',step,flush=True);subprocess.run([sys.executable,'-X','utf8',str(base/step)],check=True)
        if step=='build_history_odds.py':assert fingerprint()==before,'A non-name value changed during the display-name correction'
    after=fingerprint();assert after==before
    (ROOT/'reports/nba_full_team_names_validation.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',normalized_alias={'LA Clippers':'Los Angeles Clippers'},unchanged_non_name_values=after),indent=2),encoding='utf-8')
    print('FULL TEAM NAME CORRECTION VERIFIED; odds, timestamps, IDs and scores unchanged',flush=True)

if __name__=='__main__':main()
