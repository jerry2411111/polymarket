"""Independently check NHL native values, absolute clocks and player minutes."""
import collections,datetime as dt,hashlib,json,sqlite3
from bs4 import BeautifulSoup
from zoneinfo import ZoneInfo
from build_history_catalog import DB
from history_index import records
from probe_history import ROOT
from official_html import decode_html
db=sqlite3.connect(DB,timeout=60);rs={r['request_id']:r for r in records()};hashes=set();checks=collections.Counter();examples=[];issues=[]
def raw(rid,document=False):
 r=rs[rid];b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];hashes.add(rid);return b if document else json.loads(b)
for native,b in db.execute('SELECT * FROM _official_nhl_game_reports ORDER BY official_game_id'):
 f=json.loads(b);src=f['request_ids'];box=raw(src['boxscore']);pbp=raw(src['play-by-play']);landing=raw(src['landing']);rail=raw(src['right-rail'])
 for d in [box,pbp,landing]:assert str(d['id'])==native and [d[k]['score'] for k in ['awayTeam','homeTeam']]==f['scores'];checks['native_id_and_score']+=1
 byid={str(p['playerId']):p for p in pbp.get('rosterSpots',[])}
 for p in f['players']:
  d={'boxscore':box,'right-rail':rail}['boxscore' if p['request_id']==src['boxscore'] else 'right-rail']
  for k in p['pointer'].strip('/').split('/'):d=d[int(k)] if isinstance(d,list) else d[k]
  assert d==p['raw'];checks['original_player_object']+=1
  if 'toi' in d:
   m,s=d['toi'].split(':');assert p['minutes']==int(m)+int(s)/60;assert p['played']==(int(m)*60+int(s)>0);checks['playing_minutes_and_appearance']+=2
  for k,v in [('score','goals'),('assists','assists')]:
   if 'playerId' in d:assert p[k]==d.get(v);checks['player_score_or_assists']+=1
  if p.get('name_request_id'):
   n=byid[p['official_player_id']];assert p['player_name']==n['firstName']['default']+' '+n['lastName']['default'];checks['native_full_name']+=1
 goals=[x for x in pbp.get('plays',[]) if x['typeDescKey']=='goal'];scores=[]
 for period in [0,1,2]:
  eligible=[x for x in goals if x['periodDescriptor']['number']<=period];running=[sum(str(x['details']['eventOwnerTeamId'])==tid for x in eligible) for tid in f['official_team_ids']];scores.append(running)
 # A full detailed feed permits event-count validation. Limited national or
 # preseason feeds are explicitly reported instead of interpreting absence as 0.
 if pbp.get('plays') and all(any(x['typeDescKey']=='period-end' and x['periodDescriptor']['number']==p for x in pbp['plays']) for p in [1,2]):
  for a,c in zip(f['break_scores'],scores):
   if None not in a:assert a==c;checks['independent_period_goal_count']+=2
 if src.get('PL') and f.get('period_clock_events'):
  doc=BeautifulSoup(decode_html(raw(src['PL'],True)),'html.parser');rows=doc.find_all('tr');tz=ZoneInfo(box.get('venueTimezone') or json.loads(db.execute('SELECT body FROM _official_nhl_schedule WHERE official_game_id=?',(native,)).fetchone()[0])['raw']['venueTimezone'])
  for e in f['period_clock_events']:
   cells=[c.get_text(' ',strip=True) for c in rows[e['html_row']].find_all('td',recursive=False)];assert cells[5]==e['raw_description'];checks['original_period_description']+=1
   if e['timestamp_utc']:
    stamp=dt.datetime.fromisoformat(e['timestamp_utc']).astimezone(tz);clock=e['raw_description'].split('Local time:')[1].strip().split()[0];h,m=map(int,clock.split(':'));assert stamp.hour%12==h%12 and stamp.minute==m;checks['timezone_and_clock']+=1
  for window in f['breaks']:
   if window['start_utc']:
    a,z=map(dt.datetime.fromisoformat,[window['start_utc'],window['end_utc']]);assert (a-dt.datetime.fromisoformat(window['reported_end_utc'])).total_seconds()==60 and z==dt.datetime.fromisoformat(window['reported_next_start_utc']) and a<z;checks['conservative_intermission_window']+=1
 issues.extend(dict(official_game_id=native,**x) for x in f['issues'])
 if len(examples)<3:examples.append({k:f[k] for k in ['official_game_id','date','teams','scores','actual_start_utc','break_scores','breaks','coaches']})
 if checks['native_id_and_score']%150==0:print('NHL INDEPENDENT RAW VALIDATION',checks['native_id_and_score']//3,'games',len(hashes),'source hashes',flush=True)
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',checked_games=checks['native_id_and_score']//3,source_hash_checks=len(hashes),checks=dict(checks),source_issues=issues,examples=examples,scope='Incremental validation of acquired official reports, not completion of NHL price or supporting-table coverage.')
(ROOT/'reports/nhl_game_report_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['source_issues','examples']}));db.close()
