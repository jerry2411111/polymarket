"""Check generated catalog contents and SQL metadata, without claiming browser rendering."""
import csv
import datetime as dt
import hashlib
import json
import re
import sqlite3

from build_history_catalog import DB
from probe_history import ROOT


def main():
    reports = ROOT / 'reports'
    page = (reports / 'data_catalog.html').read_text(encoding='utf-8')
    payload = json.loads(re.search(r'<script type="application/json" id="payload">(.*?)</script>', page, re.S).group(1))
    title = re.search(r'<title>(.*?)</title>', page).group(1)
    assert 'PARTIALLY WORKING' not in title
    assert page.index('<section id="structure">') < page.index('<section id="fields">') < page.index('<section id="missing">')
    rows, objects = payload['rows'], payload['objects']
    assert all(r['meaning'] and r['unit'] and r['source_ids'] and r['table_description'] for r in rows)
    assert all(o['description'] for o in objects)
    exports = [o for o in objects if not o['object_type'].startswith('SQL')]
    assert f'All {len(exports)} CSV/Parquet exports' in page
    status = [r for r in rows if r['column_name'] == 'performance_status']
    assert len(status) == 5 and all(r['missing_count'] == 0 for r in status)
    assert all('insufficient matches' in r['derivation'] for r in status)
    assert not any(r['missing_pct'] == 100 and '_top_' in r['column_name'] for r in rows if r['object_type'] == 'export')
    assert not any(o['dataset'] == 'coach_contracts' for o in objects)
    assert not any('player_rankings_quarterly' in o['dataset'] for o in objects)
    assert not any('player_profiles' in r['dataset'] and r['column_name']=='number_of_teams_served' for r in rows)
    assert not any('team_history' in r['dataset'] and r['column_name'] in ('total_salary_yearly','salary_year','currency') for r in rows)
    assert not any(r['column_name'] == 'months_serving_current_team' and 'manager_profiles' in r['dataset'] for r in rows)
    assert all(r['missing_count'] == 0 for r in rows if 'manager_profiles' in r['dataset'] and r['column_name'] == 'team')
    with (reports / 'data_catalog_missing.csv').open(encoding='utf-8-sig', newline='') as f:
        missing = list(csv.DictReader(f))
    assert len(missing) == len(rows)
    db = sqlite3.connect(DB.resolve().as_uri() + '?mode=ro', uri=True)
    assert db.execute('SELECT COUNT(*) FROM data_catalog').fetchone()[0] == len(rows)
    assert db.execute("SELECT COUNT(*) FROM data_catalog WHERE column_name='performance_status' AND missing_count=0").fetchone()[0] == 5
    db.close()
    out = dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(), status='WORKING_FOR_STATIC_AND_SQL_CHECKS',
               dataset_descriptions=len(objects), field_descriptions=len(rows),
               checks=['Clean title; requested three-section order', 'Every public field has meaning, unit and source mapping',
                       'Player performance status documented in all four exports and SQL, missing 0%',
                       'No first-year exclusion; first-game results and zero-appearance status documented',
                       'No coach contracts or removed manager tenure field; manager teams populated',
                       'No fully missing top-N export column', 'SQL catalog matches generated field dictionary'],
               missing_report_sha256=hashlib.sha256((reports / 'data_catalog_missing.csv').read_bytes()).hexdigest(),
               browser_render_status='Static HTML/payload/SQL checks performed; browser rendering not rerun.')
    (reports / 'data_catalog_render_validation.json').write_text(json.dumps(out, indent=2), encoding='utf-8')
    print(json.dumps(out))


if __name__ == '__main__':
    main()
