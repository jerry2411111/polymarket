"""Map every published data family to its actual retained sources and limitations."""
import datetime as dt
import json
import sqlite3
from probe_history import ROOT
from build_history_catalog import DB

SOURCES = [
 ('Polymarket game/market identity and outcome-token mapping', 'Official Polymarket Gamma events, markets, sports metadata and CLOB identifiers', 'https://docs.polymarket.com/api-reference/events/list-events', 'Used for identity and probability mapping; official sports reports supply results.'),
 ('Polymarket probabilities and decimal odds', 'Official Data API v2 historical token prices; retained official CLOB pilot responses', 'https://data-api.polymarket.com/v2/openapi.json', 'Historical token prices, not verified historical bids. Buckets must be fully available by the pregame target or fit inside the break. Zero-duration terminal payouts with ambiguous chronology are excluded.'),
 ('Kalshi game/market identity and probability quotes', 'Official recent and historical markets/candlesticks; milestones and structured targets for matching', 'https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps', 'Actual cutoff responses determine routing. Probability uses the corresponding team YES bid close; price definition differs from Polymarket. Provider scores are comparison evidence only.'),
 ('NBA final scores, winners, checkpoints and player game statistics', 'Official NBA game pages, box scores and final scorer PDFs', 'https://www.nba.com/games', 'All published game results use official reports. Only collected played games contribute to player/team/coach performance; no-market training games are excluded.'),
 ('NBA people, physical attributes, affiliation, tenure and injuries', 'Official NBA/player/team pages, biographies, dated acquisition/appointment announcements and injury notes', 'https://www.nba.com/players', 'Dated appointments and complete career histories remain partial. Physical attributes may use a constant biography value; no-report injury=false is a requested convention, not verified health.'),
 ('MLB scores, winners, inning scores, player statistics and game timing', 'Official MLB Stats API schedule and game feeds, checked with MLB date scoreboards', 'https://statsapi.mlb.com/api/v1/schedule?sportId=1&date=2025-07-04', 'Doubleheader native IDs and resumption dates are preserved. Individual playing minutes are unavailable. A pitcher batting-stat omission remains null.'),
 ('MLB dated rosters, team moves, injuries and managers', 'Official Stats API transactions/coaching rosters and dated MLB/team announcements', 'https://docs.statsapi.mlb.com/', 'Restricted partner docs were not bypassed. Public route syntax came from official clients and returned links. Transaction announcement dates constrain availability; suspended-game affiliation and manager attribution have gaps.'),
 ('NHL final/period scores, winners, clocks and player statistics', 'Official NHL game-center/schedule/player APIs, scoring-summary and play-by-play reports', 'https://api-web.nhle.com/v1/schedule/2025-01-01', 'Official report values are independently reconciled; some period-break clocks and starter indicators remain missing.'),
 ('NHL people, physical biography, career seasons and coaches', 'Official NHL player pages/game logs, native NHL Records coach registry and dated club announcements', 'https://records.nhl.com/', 'Career/affiliation evidence is separate from collected-game performance. Exact service boundaries and complete injury history are incomplete.'),
 ('Premier League game results, lineups, goals, assists, minutes and membership', 'Official Premier League public calendar, matches, lineups, events, commentary, player and manager APIs', 'https://www.premierleague.com/en/matches', 'APIs were read from the current official client. The league-hosted global biography service also supports native-linked people in other EU competitions; it is identified as Premier League-hosted evidence.'),
 ('LaLiga results, lineups, period timing and biographies', 'Official LaLiga archived results and structured public match/player pages', 'https://www.laliga.com/en-GB/laliga-easports/results', 'Official website fallback because the public API required an unavailable subscription key. No embedded credential was used. Player minutes/assists and clock coverage are partial; 61 insufficient biography links are quarantined.'),
 ('Bundesliga results, lineups, people and awarded-result revisions', 'Official Bundesliga public Firebase/client pages and DFB disciplinary decisions', 'https://www.bundesliga.com/en/bundesliga', 'Official matchday-page equality checks verify public-client data. Dated awarded-result changes are not applied before their decision date. Assist coverage is limited.'),
 ('Serie A results, lineups, player statistics and period clocks', 'Official Lega Serie A public SDP header, lineup and paginated feed APIs; club reports for discrepancies', 'https://www.legaseriea.it/', 'Routes came from current official widgets. Some historical feed clocks reflect later editing and are withheld. The Torino-Genoa conflicting event score remains quarantined; official final score is retained.'),
 ('Ligue 1 results, lineups and biographies', 'Official Ligue 1 public API plus independent official club reports and native-linked biographies', 'https://ligue1.com/', 'Rescheduled game IDs are preserved. Monaco venue country was independently corrected using club and UEFA evidence.'),
 ('UEFA Champions League results, lineups, goal phases, player/coach IDs and venues', 'Official UEFA match API, paginated events, club/player profiles and official match articles', 'https://www.uefa.com/uefachampionsleague/', 'Qualifiers are included when odds exist. Current club/age fields are not backfilled as historical membership/age. Regulation scores are distinguished from extra-time and shootout results.'),
 ('Weather for all published game cities/dates', 'Official NOAA/NCEI GHCNh station observations and SMHI quality-approved station archives', 'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/doc/ghcnh_DOCUMENTATION.pdf', '13,000 games link to 12,537 city/date rows. Station proxies and distances are internal. Use the nearest eligible previous quality-approved observation; missing station, time or individual variable remains null.'),
 ('Stockholm weather fallback', 'Official SMHI open meteorological observations', 'https://opendata.smhi.se/apidocs/metobs/', 'Bromma temperature/wind/weather and Observatoriekullen humidity are separate, explicitly audited station observations.'),
 ('NBA media ranking flags', 'Facts attributed to ESPN, CBS Sports, Sports Illustrated, Bleacher Report, Sporting News, The Ringer, HoopsHype, USA Today and Action Network; direct and syndicated evidence pages', 'https://www.espn.com/nba/', 'Nine publisher series have verified facts; some evidence comes from Yahoo-hosted republication/consensus pages. The catalog distinguishes attributed publisher from actual source URL. This does not establish ten independent major-media lists or full coverage of every player.'),
 ('MLB media ranking flags', 'Original ESPN, MLB Network, CBS Sports, FOX Sports and Bleacher Report facts', 'https://www.mlb.com/network', 'Five publisher series. League-operated MLB Network is identified as such; not an independent external outlet.'),
 ('NHL media ranking flags', 'Original ESPN, CBS Sports, Bleacher Report, Sportsnet, NHL Network and The Hockey News facts', 'https://www.nhl.com/nhl-network', 'Six publisher series. League-operated NHL Network is identified as such; not an independent external outlet.'),
 ('EU soccer media ranking flags', 'GOAL European Top 50 and France Football Ballon d\u0027Or, published by official co-organizer UEFA', 'https://www.goal.com/en/lists/top-50-players-2024-25-european-season/blta1119bb143b33904', 'Two independent publishing groups, four dated editions and 120 facts. Ballon d\u0027Or top ten is used only after every preceding rank is verified in the European population. No separate publisher credit for UEFA/L\u0027Equipe syndication.'),
]


def main():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    now = dt.datetime.now(dt.UTC).isoformat()
    inventory = json.loads((ROOT / 'reports/all_outputs_inventory.json').read_text())
    lines = ['# Sources mapped to the current dataset', '', 'Generated ' + now + '.', '',
             'Current publication: **13,000 distinct games**, '+str(len(inventory['outputs']))+' logical CSV/Parquet datasets and one SQL database. '
             'Window: 2024-01-01 through 2026-09-14, with partial provider and field coverage. '
             'This report replaces the earlier pilot-only and league-in-progress source summaries. '
             'The [field-level catalog](data_catalog.html) documents each column and labels direct, backup and republished sources. '
             'The [weather source verification](weather_source_verification.md) links each field to its actual NOAA or SMHI record.', '',
             '| Data | Source | Actual use and limitation |', '|---|---|---|']
    lines += ['| ' + data + ' | [' + source + '](' + url + ') | ' + limitation + ' |' for data, source, url, limitation in SOURCES]
    lines += ['', '## Acquired odds by provider', '', '| League | Provider | Main games | With in-game quotes | Earliest | Latest |', '|---|---|---:|---:|---|---|']
    for row in inventory['provider_coverage']:
        lines.append('| ' + ' | '.join(str(row[k]) for k in ['league','provider','main_rows','games_with_in_game_quotes','earliest_game','latest_game']) + ' |')
    lines += ['', '## Source values and calculated values', '',
        '- Final results and checkpoint scores: official league/club reports only. Market settlement and provider widgets are comparison evidence.',
        '- Probability: corresponding Polymarket token price or Kalshi team YES bid close. Odds = 1/p when p > 0. No opponent or draw price is inferred from a complement.',
        '- Pregame hours: 0, 12, 24, 36 and 48. Closest available previous observation, with pre_0 strictly before kickoff and full bucket/candle availability respected.',
        '- In-game: first eligible observation inside the verified break. No qualifying quote means a missing slot; all-empty games are omitted from the in-game file and counted against main-game coverage.',
        '- Performance: only collected completed games between the selected start and cutoff, with sample SD based on available-observation n-1. No history is encoded as zero, identified by games_played=0. The scoring z-score uses only that past cohort. No current aggregate is projected into an earlier date.',
        '- Publisher ranking flags: most recent eligible dated edition on or before each query date, carried forward until superseded. Raw unlisted ordinal ranks remain null. Public top-N flags mark the other players false once that publisher has dated evidence; entirely absent publisher flags and public quarterly ranking tables are excluded.', '',
        'Every field denominator and percentage is in [all_columns_missing.csv](all_columns_missing.csv). '
        'Every in-game checkpoint-slot denominator is in [in_game_missing_slots.csv](in_game_missing_slots.csv). '
        'The [complete file inventory](current_data_inventory.md) includes all public columns and their meaning.', '',
        '## Request provenance and access', '',
        '- Logged requests: ' + str(db.execute('SELECT count(*) FROM _request_audit').fetchone()[0]) + '. '
        'The 723 earlier pilot responses were copied and hash-verified into the current project; their original IDs and retrieval dates are unchanged.',
        '- `data/raw/requests.csv` has only request number, request type, intended data and return status. SQL retains exact endpoint, parameters, timestamp, raw path and hash.',
        '- API billing credits were not returned by these public responses; no credit estimate is fabricated from request count.',
        '- Official API documentation URLs and official-client route evidence are retained in README.md and the original response audit. Official-site fallback is used only where the API is insufficient or unavailable.',
        '- No Kaggle, GitHub sports datasets, mock responses or trades are used in the replacement outputs. Public media/financial reporting follows the user-authorized exception.', '',
        'No acquisition-phase percentage is a claim that the full requested dataset or every supporting field is complete.']
    (ROOT / 'reports/data_sources.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('Updated current source map:', len(SOURCES), 'source/data families; requests', db.execute('SELECT count(*) FROM _request_audit').fetchone()[0])
    db.close()


if __name__ == '__main__':
    main()
