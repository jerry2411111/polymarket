"""Resolve stadium-city homonyms and Monaco country using official venue sources."""
import datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from urllib.parse import urlsplit
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from eu_official_games import games
from probe_history import ROOT,HOSTS

def main():
 db=sqlite3.connect(DB,timeout=60);c=HistoryClient();docs={};urls={'SEA':'https://www.legaseriea.it/team/fiorentina/stadium','FL1':'https://www.asmonaco.com/en/club/stade-louis-ii'}
 for code,url in urls.items():
  HOSTS.add(urlsplit(url).hostname);b,r,redirects=get(c,url);text=' '.join(BeautifulSoup(b,'html.parser').stripped_strings);docs[code]=dict(url=url,request_id=r['request_id'],redirects=redirects,text=text)
  with db:db.execute('INSERT OR REPLACE INTO _eu_location_documents VALUES (?,?)',(url,json.dumps({k:v for k,v in docs[code].items() if k!='text'})))
  print('VENUE DOCUMENT',code,'Firenze' in text,'Artemio Franchi' in text,'Monaco' in text,'Louis' in text,flush=True)
 corrections=[];official={g['game_id']:g for code in urls for g in games(db,code).values()};monaco={}
 for b, in db.execute('SELECT body FROM _official_uefa_calendar'):
  ug=json.loads(b);v=ug['raw']['stadium']
  if v['city']['translations']['name']['EN']=='Monaco' and 'louis' in v['translations']['name']['EN'].lower():
   assert v['countryCode'] in ['MCO','MON'];monaco[v['id']]=dict(request_id=ug['request_id'],pointer=ug['pointer']+'/stadium',raw=v)
 assert len(monaco)==1;monaco=next(iter(monaco.values()))
 for gid,b in db.execute('SELECT * FROM _eu_game_weather_locations'):
  row=json.loads(b);code=row.get('competition');r=docs.get(code)
  if code=='SEA' and row['raw_city']=='Siena':
   assert 'Fiorentina' in official[gid]['home']['name'] and 'Artemio Franchi' in row['venue'] and all(x in r['text'] for x in ['Firenze','Artemio Franchi']);city='Firenze';country='IT';reason='Official match header names Siena, but the official Fiorentina stadium page locates its Artemio Franchi in Firenze. Two Italian stadiums share this name.'
  elif code=='FL1' and row['raw_city']=='Monaco':
   assert 'louis' in row['venue'].lower() and all(x in r['text'] for x in ['Monaco','Louis']);city='Monaco';country='MC';reason='Monaco stadium country is Monaco; French league membership does not establish French geography.'
  else:continue
  correction=dict(game_id=gid,official_match_id=official[gid]['official_match_id'] if 'official_match_id' in official[gid] else official[gid]['match_id'],competition_code=code,raw_location=row,city=city,country=country,venue=row['venue'],location=row['venue']+', '+city,request_id=r['request_id'],url=r['url'],reason=reason,uefa_stadium_proof=monaco if code=='FL1' else None);corrections.append((gid,json.dumps(correction)))
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _eu_game_location_corrections (game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_game_location_corrections VALUES (?,?)',corrections)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',corrected_game_locations=len(corrections),by_competition={code:sum(json.loads(b)['competition_code']==code for _,b in corrections) for code in docs},new_requests=c.requests,reason='Corrected geography is retained separately from unmodified official match responses.');(ROOT/'reports/eu_location_conflicts_review.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
