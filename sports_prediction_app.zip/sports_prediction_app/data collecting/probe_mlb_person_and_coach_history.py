import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT
c=HistoryClient();out=[]
for params in [dict(date='2025-05-18',playerId=641933),dict(playerId=592450,startDate='2010-01-01',endDate='2026-09-14')]:
    d,r=c.get('https://statsapi.mlb.com/api/v1/transactions',params);xs=d['transactions'];ids={x.get('person',{}).get('id') for x in xs};row=dict(kind='player_transactions',parameters=params,request_id=r['request_id'],rows=len(xs),person_ids=sorted(ids,key=str),earliest=min((x['date'] for x in xs),default=None),latest=max((x['date'] for x in xs),default=None),examples=xs[:2]);out.append(row);print(json.dumps(row),flush=True)
for date in ['2024-07-30','2025-05-16','2025-05-18']:
    d,r=c.get('https://statsapi.mlb.com/api/v1/teams/110/coaches',dict(date=date));rows=d.get('roster',[]);row=dict(kind='dated_coach_probe',date=date,request_id=r['request_id'],response_keys=list(d),managers=[x for x in rows if 'manager' in x.get('job','').lower()],all_roster_count=len(rows));out.append(row);print(json.dumps(row),flush=True)
(ROOT/'reports/mlb_person_coach_history_probe.json').write_text(json.dumps(dict(checked_at_utc=dt.datetime.now(dt.UTC).isoformat(),examples=out),indent=2),encoding='utf-8')
