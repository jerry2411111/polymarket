"""Check native Serie A calendar data against three official club match reports."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from zoneinfo import ZoneInfo
from bs4 import BeautifulSoup
from build_history_catalog import DB
from epl_price_points import Sources
from probe_history import ROOT

def main():
 db=sqlite3.connect(DB);src=Sources(db);pilot=json.loads((ROOT/'reports/seriea_match_pilot.json').read_text());data,r=src.get(pilot['request_id']);public=json.loads((ROOT/'reports/seriea_public_pilot_sources.json').read_text())['sources'];checks=collections.Counter();texts={}
 for p in public:
  assert p['status']=='ACQUIRED_REQUIRES_VALIDATION';rec=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(p['request_id'],)).fetchone()[0]);raw=(ROOT/rec['raw_file']).read_bytes();assert rec['status']==200 and hashlib.sha256(raw).hexdigest()==rec['sha256'];text=' '.join(BeautifulSoup(raw,'html.parser').get_text(' ',strip=True).split());texts[p['url']]=(text,p['request_id'])
 ms=data['matches'];assert len(ms)==380==len({m['matchId'] for m in ms})
 for m in ms:
  assert m['seasonId']==data['competition']['seasonId'];assert m['status']=='FINISHED' and m['phase']=='FULL_TIME';assert m['home']['teamId']!=m['away']['teamId'];assert all(type(m[x]) is int and m[x]>=0 for x in ['providerHomeScore','providerAwayScore']);assert [m['homeScorePush'],m['awayScorePush']]==[m['providerHomeScore'],m['providerAwayScore']];stamp=dt.datetime.fromisoformat(m['matchDateUtc']);assert stamp.tzinfo and stamp.astimezone(ZoneInfo('Europe/Rome')).replace(tzinfo=None)==dt.datetime.fromisoformat(m['matchDateLocal']);checks['calendar_identity_score_and_timezone']+=1
 fixtures=[('2024-01-06','Inter','Verona',[2,1],'12:30',[0]),('2024-01-07','Empoli','Milan',[0,3],'12:30',[1,2]),('2024-01-07','Roma','Atalanta',[1,1],'20:45',[3,4])];examples=[]
 for day,home,away,score,localtime,indices in fixtures:
  candidates=[m for m in ms if m['matchDateUtc'][:10]==day and home.lower() in m['home']['officialName'].lower() and away.lower() in m['away']['officialName'].lower()];assert len(candidates)==1,(home,away);m=candidates[0];assert [m['providerHomeScore'],m['providerAwayScore']]==score;utc=dt.datetime.fromisoformat(day+'T'+localtime).replace(tzinfo=ZoneInfo('Europe/Rome')).astimezone(dt.UTC);assert dt.datetime.fromisoformat(m['matchDateUtc'])==utc
  if home=='Inter':
   text=texts[public[0]['url']][0];assert re.search(r'Risultato finale 6 Gennaio 2024 12:30 Inter.{0,100}2 - 1 Hellas Verona',text)
  elif home=='Empoli':
   preview=texts[public[1]['url']][0];result=texts[public[2]['url']][0];assert 'EMPOLI v AC MILAN' in preview and 'January 7th 2024' in preview and '12:30 CET' in preview;assert '3-0 A EMPOLI' in result and '7 gennaio 2024' in result
  else:
   result=texts[public[3]['url']][0];preview=texts[public[4]['url']][0];assert 'La gallery di Roma-Atalanta 1-1 7 gennaio, 2024' in result;assert 'domenica 7 gennaio' in preview and 'calcio d’inizio alle 20.45' in preview
  checks['independent_official_report_score_date_time']+=1;examples.append(dict(match_id=m['matchId'],source_request_id=r['request_id'],source_pointer='/matches/'+str(ms.index(m)),teams=[m['home']['officialName'],m['away']['officialName']],final_scores=score,source_utc=m['matchDateUtc'],normalized_start_utc=utc.isoformat(),official_local_date_time=day+' '+localtime,public_sources=[dict(url=public[i]['url'],request_id=public[i]['request_id']) for i in indices],matches=True))
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Official Serie A calendar connector only; no quote or performance coverage implied',checks=dict(checks),raw_hash_checks=len(src.cache)+len(texts),examples=examples,discrepancies=[dict(field='localTimeUtcOffset',raw='+00:00',reason='Offset disagrees with explicit UTC/local timestamp pair',handling='Use explicit matchDateUtc and verify matchDateLocal with Europe/Rome; do not apply the incorrect offset field')]);(ROOT/'reports/seriea_pilot_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
