import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
db=sqlite3.connect(DB)
for n,b in db.execute('SELECT * FROM _official_nhl_coach_registry'):
    r=json.loads(b)
    for field in ['briefDescription','description']:
        text=BeautifulSoup(r['raw'].get(field) or '','html.parser').get_text(' ',strip=True)
        if re.search(r'\b(?:hired|named|appointed)\b',text,re.I):print(json.dumps(dict(id=n,name=r['full_name'],field=field,request_id=r['request_id'],text=text[:650]),ensure_ascii=False))
db.close()
