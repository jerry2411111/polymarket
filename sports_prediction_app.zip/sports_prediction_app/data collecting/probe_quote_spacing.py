"""Measure actual spacing at multiple real market ages; do not infer a cutoff."""
import collections,datetime as dt,json,sqlite3
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT
from core import utc
def main():
 db=sqlite3.connect(DB);gs={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _history_games')};cs=[json.loads(r[0]) for r in db.execute('SELECT body FROM _history_contracts')];db.close();client=HistoryClient();out=[]
 for date in ['2024-04-20','2025-04-20','2026-04-01','2026-06-01','2026-07-01','2026-08-01','2026-09-01']:
  candidates=[c for c in cs if c['provider']=='polymarket' and c['side']==0];m=min(candidates,key=lambda c:abs((dt.date.fromisoformat(gs[c['game_id']]['date'])-dt.date.fromisoformat(date)).days));g=gs[m['game_id']];t=int(utc(g['start']).timestamp())
  for bucket in [3600,None]:
   params=dict(token_id=m['contract_id'],start=t-86400*3,end=t+21600,limit=10000)
   if bucket:params['bucket_seconds']=bucket
   try:
    d,r=client.get('https://data-api.polymarket.com/v2/prices-history',params);rows=d.get('data',[]);ts=sorted(set(x['timestamp'] for x in rows));gaps=[(b-a)/3600 for a,b in zip(ts,ts[1:])]
    out.append(dict(game_id=g['game_id'],date=g['date'],age_days=(dt.date(2026,9,13)-dt.date.fromisoformat(g['date'])).days,requested_bucket_seconds=bucket,request_id=r['request_id'],rows=len(rows),reported_resolution_seconds=sorted({x.get('resolution_seconds') for x in rows}),gap_hours_min=min(gaps) if gaps else None,gap_hours_max=max(gaps) if gaps else None,gap_counts=dict(collections.Counter(gaps)),pagination=d.get('pagination')))
   except Exception as e:out.append(dict(game_id=g['game_id'],requested_bucket_seconds=bucket,error=str(e)))
 (ROOT/'reports/quote_spacing_probes.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
