"""Read current official SMHI observation metadata before a Stockholm fallback."""
import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

HOSTS.update({'opendata-download-metobs.smhi.se','opendata.smhi.se'});c=HistoryClient();url='https://opendata-download-metobs.smhi.se/api/version/latest.json';d,r=c.get(url);print('SMHI VERSION',r['request_id'],list(d));resources=d.get('resource',[]);print(json.dumps(resources,ensure_ascii=False)[:15000]);out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),metadata_url=url,request_id=r['request_id'],metadata=d,new_requests=c.requests)
(ROOT/'reports/smhi_current_documentation.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
