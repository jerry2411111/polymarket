"""Read-only measured coverage answers, distinguishing acquisition from validation."""
import collections,datetime as dt,json,sqlite3
from history_index import records,payload
from probe_history import ROOT
from build_history_catalog import DB
from core import checkpoint_rows,utc
def main():
 db=sqlite3.connect(DB);gs={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _history_games')};db.close()
 rs={r['request_id']:r for r in records()};jobs={}
 p=ROOT/'reports/history_acquisition_jobs.jsonl'
 for line in p.read_text().splitlines():
  try:j=json.loads(line)
  except json.JSONDecodeError:continue
  jobs[j['kind'],j.get('contract_id') or j['game_id']]=j
 result={'as_of_date':'2026-09-13','pbp':{},'price_examples':[],'price_jobs':dict(collections.Counter((j.get('provider','unknown')+':'+j['status']) for j in jobs.values() if j['kind']=='price'))}
 for league in ['NBA','MLB','NHL']:
  js=sorted([j for j in jobs.values() if j['kind']=='pbp' and j['status']=='ok' and gs[j['game_id']]['league']==league],key=lambda j:gs[j['game_id']]['date'])
  missing=[j for j in js if not j['wall_clock']];timed=[j for j in js if j['wall_clock']];full=[]
  for j in timed:
   try:
    cps=checkpoint_rows(payload(rs[j['request_id']]),gs[j['game_id']]['game_type'].lower())
    if all(c['time'] is not None for c in cps):
     full.append(dict(game_id=j['game_id'],date=gs[j['game_id']]['date'],times=[c['time'].isoformat() for c in cps],request_id=j['request_id']))
     break
   except Exception:continue
  result['pbp'][league]=dict(acquired_games=len(js),zero_wall_clock_games=len(missing),earliest_without_wall_clock=gs[missing[0]['game_id']]['date'] if missing else None,latest_without_wall_clock=gs[missing[-1]['game_id']]['date'] if missing else None,earliest_all_checkpoint_times=full[0] if full else None)
 price_requests=[r for r in rs.values() if r['status']==200 and '/v2/prices-history' in r['endpoint']]
 examples={}
 for r in sorted(price_requests,key=lambda r:int(r['parameters'].get('start',r['parameters'].get('as_of',0)))):
  d=payload(r);rows=d.get('data',[])
  if len(rows)<2:continue
  year=utc(rows[0]['timestamp']).year;bucket=r['parameters'].get('bucket_seconds')
  key=(year,bucket)
  if key in examples:continue
  ts=sorted(set(x['timestamp'] for x in rows));gaps=[(b-a)/3600 for a,b in zip(ts,ts[1:])]
  examples[key]=dict(request_id=r['request_id'],token_id=r['parameters']['token_id'],requested_bucket_seconds=bucket,rows=len(rows),first=utc(ts[0]).isoformat(),last=utc(ts[-1]).isoformat(),reported_resolution_seconds=sorted(set(x.get('resolution_seconds') for x in rows)),gap_hours_min=min(gaps),gap_hours_max=max(gaps),gap_counts=dict(collections.Counter(gaps)),first_observations=rows[:4])
  if len(examples)>=8:break
 result['price_examples']=list(examples.values())
 (ROOT/'reports/current_problems_measured.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
