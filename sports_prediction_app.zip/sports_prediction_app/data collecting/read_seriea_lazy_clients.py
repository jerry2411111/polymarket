"""Inspect current official lazy-loaded football clients without using credentials."""
import argparse,hashlib,json,re,sqlite3
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--chunks',type=int,nargs='*',default=[]);a=ap.parse_args();db=sqlite3.connect(DB);c=HistoryClient();HOSTS.add('www.legaseriea.it')
 def raw(rid):
  r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];return b.decode()
 sdk=raw('1e2c7f8f5bee4200b46b61b2a6b49f32')
 for phrase in ['rD("match-lineup','rD("match-summary','rD("play-by-play']:
  i=sdk.find(phrase);print('SDK',i,sdk[max(0,i-30):i+100])
 page=BeautifulSoup(raw('81f68485cf8145c6b155426fdcce36b7'),'html.parser');urls=[urljoin('https://www.legaseriea.it',t['src']) for t in page.find_all('script',src=True) if '/webpack-' in t['src']];assert len(urls)==1;b,r=c.get(urls[0],document=True);s=b.decode();print('BOOTSTRAP',r['request_id'])
 # The official webpack URL function maps numeric chunk IDs to content hashes.
 i=s.index('.u=');print('URL FUNCTION',s[i:i+300])
 for cid in a.chunks:
  fn=s[i:s.index('.miniCssF=',i)];hits=list(re.finditer(r'(?<!\d)'+str(cid)+r':"([a-f0-9]{8,})"',fn));assert len(hits) in [1,2],(cid,len(hits));name=hits[0][1] if len(hits)==2 else str(cid);url='https://www.legaseriea.it/_next/static/chunks/'+name+'.'+hits[-1][1]+'.js';data,sr=c.get(url,document=True);text=data.decode();print('CHUNK',cid,sr['request_id'],len(data))
  for pattern in ['seasons/','/matches/','lineups','playbyplay','play-by-play','summary','baseUrl']:
   for hit in list(re.finditer(re.escape(pattern),text,re.I))[:2]:
    v=text[max(0,hit.start()-100):hit.end()+350];v=re.sub(r'(?i)([\w-]*(?:api[_-]?key|token|secret|password)[\w-]*["\x27]?\s*[:=]\s*["\x27])[^"\x27]+',r'\1[redacted]',v);print('ROUTE',hit.start(),v)
 db.close()

if __name__=='__main__':main()
