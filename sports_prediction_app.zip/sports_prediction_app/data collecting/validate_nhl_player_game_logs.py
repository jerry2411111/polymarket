"""Independently validate native dated logs and compare actual season coverage."""
import collections,datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);sources={r:json.loads(b) for r,b in db.execute('SELECT request_id,metadata_json FROM _request_audit')};hashes=set();checks=collections.Counter();results=[];issues=[];career={p:json.loads(b) for p,b in db.execute('SELECT * FROM _official_nhl_career_sources') if json.loads(b)['status']=='ok'}
    def raw(rid):
        r=sources[rid];b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];hashes.add(rid);return json.loads(b)
    for key,b in db.execute('SELECT * FROM _official_nhl_player_game_logs').fetchall():
        x=json.loads(b)
        if x['status']!='ok':issues.append(dict(job_key=key,status=x['status'],reason=x.get('reason') or x.get('error'),request_id=x['request_id']));continue
        pid=x['official_player_id'];d=raw(x['request_id']);assert sources[x['request_id']]['endpoint'].endswith(f"/player/{pid}/game-log/{x['season']}/{x['game_type_code']}")
        assert d['seasonId']==x['season'] and d['gameTypeId']==x['game_type_code'] and d['gameLog']==x['games'];checks['native_request_and_raw_array']+=1
        seen=set();clubs=collections.Counter()
        for r in x['games']:
            gid=str(r['id']);assert gid not in seen and gid[:4]==str(x['season'])[:4];seen.add(gid);dt.date.fromisoformat(r['gameDate']);assert r['homeRoadFlag'] in ['H','R'];own=r['homeTeam'] if r['homeRoadFlag']=='H' else r['awayTeam'];assert own['id'];clubs[str(own['id'])]+=1
            for k in ['goals','assists','homeScore','awayScore']:assert r.get(k) is None or isinstance(r[k],int) and r[k]>=0
            checks['dated_native_game_and_values']+=1
        c=career[pid];original=raw(c['request_id']);assert original['seasonTotals']==c['season_totals']
        rows=[r for r in c['season_totals'] if r.get('leagueAbbrev')=='NHL' and r['season']==x['season'] and r.get('gameTypeId')==x['game_type_code'] and (r.get('gamesPlayed') or 0)>0]
        # Preserve each source team row; a totals row cannot be added to its
        # constituent teams. Ambiguous totals are reported, never double counted.
        names=[r.get('teamName',{}).get('default') for r in rows]
        sequences=[r.get('sequence') for r in rows]
        distinct_stints=(len(rows)==1 or None not in sequences and len(sequences)==len(set(sequences)))
        expected=sum(r['gamesPlayed'] for r in rows) if distinct_stints and all(n and 'teams' not in n.lower() and n!='TOT' for n in names) else None
        complete=expected is not None and expected==len(x['games'])
        item=dict(job_key=key,player_id='NHL:'+pid,season=x['season'],game_type_code=x['game_type_code'],log_rows=len(x['games']),career_games_played=expected,complete=complete,source_team_rows=rows,request_id=x['request_id'],career_request_id=c['request_id'])
        results.append(item)
        if not complete:issues.append(dict(job_key=key,reason='Dated log count does not establish complete career-season coverage',log_rows=len(x['games']),career_games_played=expected,source_team_names=names))
        if len(results)%500==0:print('NHL DATED LOG VALIDATION',len(results),'checked;',len(issues),'coverage issues',flush=True)
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _nhl_game_log_validation (job_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _nhl_game_log_validation VALUES (?,?)',[(r['job_key'],json.dumps(r)) for r in results])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING' if issues else 'WORKING',validated_logs=len(results),complete_season_logs=sum(r['complete'] for r in results),source_hash_checks=len(hashes),checks=dict(checks),issues=issues,meaning='Only complete dated logs support complete career counts. Non-sample games never enter performance.')
    (ROOT/'reports/nhl_dated_log_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='issues'}),'issues',len(issues));db.close()

if __name__=='__main__':main()
