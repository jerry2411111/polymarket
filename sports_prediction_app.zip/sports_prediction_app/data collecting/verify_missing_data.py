"""Cross-check published missing counts against CSV, Parquet and current SQLite.

Read source tables without changing them. Record one immutable audit run and
field-level totals in internal SQL tables, plus reviewable reports. This checks
stored-data consistency; a missing cell is not proof that no external source exists.
"""
import collections
import argparse
import csv
import datetime as dt
import json
import pathlib
import re
import sqlite3
import time
import uuid

import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.csv as pacsv
import pyarrow.parquet as pq

from probe_history import ROOT
from build_history_catalog import DB
from report_all_outputs import measure_file, meaning


REPORT = ROOT / 'reports/missing_data_verification.json'
LEAGUES = {'nba': 'NBA', 'mlb': 'MLB', 'nhl': 'NHL', 'eu_soccer': 'EU soccer'}
SLOT_COLUMNS = ['timestamp', 'teamA_ingame_p', 'teamB_ingame_p', 'draw_ingame_p',
                'teamA_ingame_odd', 'teamB_ingame_odd', 'draw_ingame_odd',
                'teamA_score', 'teamB_score']
MISSING_SLOT = {'', 'none', 'null', 'nan'}


def quote(name):
    return '"' + name.replace('"', '""') + '"'


def utc():
    return dt.datetime.now(dt.UTC).isoformat()


def public_query(dataset, columns):
    parts = pathlib.PurePosixPath(dataset).parts[2:]
    projection = ','.join(quote(c) for c in columns)
    if parts[0] in ('kalshi', 'polymarket'):
        return f'SELECT {projection} FROM {parts[0]}_{parts[1]}', []
    if parts[0] == 'eu_soccer' and parts[1] in ('kalshi', 'polymarket'):
        return f'SELECT {projection} FROM {parts[1]}_eu_soccer_{parts[2]}', []
    if parts == ('weather',):
        return f'SELECT {projection} FROM weather', []
    league, table = LEAGUES[parts[0]], parts[1]
    if table == 'weather':
        scope = ('EXISTS(SELECT 1 FROM _eu_game_facts g WHERE g.game_id=l.game_id)'
                 if league == 'EU soccer' else "l.game_id LIKE '" + league + "_%'")
        return (f'SELECT {projection} FROM weather w WHERE EXISTS('
                'SELECT 1 FROM _game_weather_links l WHERE l.city=w.city AND l.date=w.date AND '
                + scope + ')'), []
    return f'SELECT {projection} FROM {quote(table)} WHERE league=?', [league]


def sum_true(values):
    return pc.sum(values).as_py() or 0


def slots_from_rows(rows):
    out = collections.defaultdict(lambda: [0, 0])
    for row in rows:
        checkpoints = row['checkpoint'].split(';')
        assert len(checkpoints) in (3, 4), row['game_id']
        for column in SLOT_COLUMNS:
            if column not in row:
                continue
            if column.startswith('draw_') and row.get('game_type')!='Soccer':
                continue
            values = row[column].split(';') if row[column] is not None else ['null'] * len(checkpoints)
            assert len(values) == len(checkpoints), (row['game_id'], column)
            for checkpoint, value in zip(checkpoints, values):
                key = row['league'], checkpoint, column
                out[key][0] += 1
                out[key][1] += value.strip().lower() in MISSING_SLOT
    return dict(out)


def csv_counts(path, schema):
    names = schema.names
    rows, counts, white = 0, collections.Counter(), collections.Counter()
    all_slots = collections.defaultdict(lambda: [0, 0])
    reader = pacsv.open_csv(path,
        read_options=pacsv.ReadOptions(block_size=8 * 1024 * 1024),
        convert_options=pacsv.ConvertOptions(
            column_types={name: pa.string() for name in names},
            null_values=[''], strings_can_be_null=True, quoted_strings_can_be_null=True))
    assert reader.schema.names == names, (str(path), 'CSV column names/order')
    for batch in reader:
        rows += batch.num_rows
        for field, col in zip(schema, batch.columns):
            counts[field.name] += col.null_count
            if pa.types.is_floating(field.type):
                counts[field.name] += sum_true(pc.is_in(pc.utf8_lower(col), value_set=pa.array(['nan', '+nan', '-nan'])))
            white[field.name] += sum_true(pc.and_(pc.equal(pc.utf8_trim_whitespace(col), ''), pc.not_equal(col, '')))
        if 'checkpoint' in names:
            for key, pair in slots_from_rows(batch.to_pylist()).items():
                all_slots[key][0] += pair[0]
                all_slots[key][1] += pair[1]
    return rows, counts, dict(all_slots), {k: v for k, v in white.items() if v}


def sql_counts(connection, sql, params, schema):
    expressions = ['COUNT(*)']
    for field in schema:
        name = quote(field.name)
        # SQLite stores NaN as NULL. Zero and false are valid values.
        condition = name + ' IS NULL'
        if pa.types.is_string(field.type) or pa.types.is_large_string(field.type):
            condition += ' OR ' + name + "=''"
        expressions.append('COALESCE(SUM(' + condition + '),0)')
    result = connection.execute('SELECT ' + ','.join(expressions) + ' FROM (' + sql + ')', params).fetchone()
    return result[0], dict(zip(schema.names, result[1:]))


def reason_basis(dataset, column):
    if '_pre_' in column:
        return ('No eligible previous observation in the acquired source history; see selection audit. '
                + ('A source probability of zero also leaves reciprocal odds undefined.' if column.endswith('_odd') else 'Not interpolated.'))
    if 'ingame_' in column or column in ('teamA_score', 'teamB_score', 'checkpoint'):
        return 'Inspect checkpoint slots: no qualifying acquired quote or verified official checkpoint fact; aggregate cell nullness alone is insufficient.'
    if column == 'performance_status':
        return 'Always derived from games_played: insufficient matches only for zero appearances; observed matches otherwise. No first-year exclusion.'
    if '/weather' in dataset:
        return 'No usable normalized field from the selected official station observation, or no eligible observation acquired. See weather source audit.'
    if '_top_' in column or '/player_rankings_quarterly' in dataset:
        return 'No eligible dated publisher evidence for this league/date. Once eligible evidence exists, recorded top-N membership is true and other players are false.'
    if column.startswith('std_'):
        return 'Played history exists but fewer than two valid observations of this statistic are available. No played history is zero and is not counted as missing.'
    if column.startswith('average_') or column in ('overall_winrate', 'score_z_score'):
        return 'Played history exists but this statistic has no valid source observations, or cohort standardization is undefined. No played history is zero and is not counted as missing.'
    if column == 'injured_times_till_as_of_date':
        return 'Distinct lifetime episodes are not established after a collected injury report. No-report zero follows the requested convention, not verified medical health.'
    if column == 'currently_injured_till_as_of_date':
        return 'Dated collected injury evidence; the requested no-report=false convention is not a verified medical negative.'
    if column in ('number_of_teams_served', 'months_serving_current_team', 'served_team_history', 'years_played'):
        return 'Required dated career/stint evidence is incomplete; observed teams are not asserted to be a complete career.'
    if column.startswith('starter_') or column.startswith('participation_'):
        return 'Required collected appearances, starts, roster opportunity denominator or current-stint evidence is missing or no qualifying appearances exist.'
    return 'Missing in the current published data; missing count alone does not establish external source unavailability.'


def verify_file(connection, item):
    started = time.monotonic()
    parquet, csv_path = ROOT / item['parquet'], ROOT / item['csv']
    before = [(p.stat().st_size, p.stat().st_mtime_ns) for p in (parquet, csv_path)]
    schema = pq.read_schema(parquet)
    current = measure_file(parquet)
    sql, params = public_query(item['dataset'], schema.names)
    csv_rows, csv_missing, csv_slots, whitespace = csv_counts(csv_path, schema)
    print('CHECK SQL', item['dataset'], flush=True)
    sql_rows, sql_missing = sql_counts(connection, sql, params, schema)
    counts_match = csv_rows == sql_rows == current['rows']
    fields = []
    for column in current['columns']:
        name = column['column']
        match = column['missing'] == csv_missing[name] == sql_missing[name] and counts_match
        fields.append(dict(column_name=name, rows=current['rows'], parquet_missing=column['missing'],
            csv_missing=csv_missing[name], sql_missing=sql_missing[name], missing_pct=column['missing_pct'],
            counts_match=match, reason_basis=reason_basis(item['dataset'], name), meaning=meaning(name)))
    slot_rows = []
    if 'checkpoint' in schema.names:
        cursor = connection.execute(sql, params)
        sql_slots = slots_from_rows(dict(zip(schema.names, r)) for r in cursor)
        parquet_slots = slots_from_rows(pq.read_table(parquet).to_pylist())
        for key in sorted(set(sql_slots) | set(csv_slots) | set(parquet_slots)):
            pp, cp, sp = parquet_slots.get(key), csv_slots.get(key), sql_slots.get(key)
            slot_rows.append(dict(league=key[0], checkpoint=key[1], column_name=key[2],
                total_slots=pp[0] if pp else None, parquet_missing=pp[1] if pp else None,
                csv_missing=cp[1] if cp else None, sql_missing=sp[1] if sp else None,
                missing_pct=round(pp[1] * 100 / pp[0], 4) if pp and pp[0] else None,
                counts_match=pp == cp == sp))
    after = [(p.stat().st_size, p.stat().st_mtime_ns) for p in (parquet, csv_path)]
    stable = before == after
    return dict(dataset=item['dataset'], physical_parquet=str(parquet.resolve()),
        physical_csv=str(csv_path.resolve()), rows=current['rows'], csv_rows=csv_rows, sql_rows=sql_rows,
        columns=len(schema), sql=sql, parameters=params, files_unchanged=stable,
        whitespace_only_cells=whitespace, fields=fields, checkpoint_slots=slot_rows,
        status='WORKING' if stable and counts_match and all(f['counts_match'] for f in fields)
               and all(s['counts_match'] for s in slot_rows) and not whitespace else 'SCHEMA PROBLEM',
        elapsed_seconds=round(time.monotonic() - started, 3))


def performance_missing_context(connection):
    """Use precomputed intervals, weighted by the actual published query dates.

    This separates pre-appearance profile dates from missing source statistics
    without treating millions of daily snapshots as millions of distinct people.
    """
    dates = [r[0] for r in connection.execute('SELECT as_of_date FROM _query_dates ORDER BY as_of_date')]
    import bisect
    grouped = collections.defaultdict(collections.Counter)
    fields = ['average_score_per_game', 'std_score_per_game', 'average_assists_per_game',
              'std_assists_per_game', 'average_minutes_per_game', 'std_minutes_per_game']
    query = 'SELECT league,effective_from,effective_to,games_played,' + ','.join(fields) + ' FROM _player_performance_periods'
    for league, start, end, games, *values in connection.execute(query):
        weight = bisect.bisect_left(dates, end) - bisect.bisect_left(dates, start)
        row = grouped[league]
        row['performance_snapshot_rows'] += weight
        for name, value in zip(fields, values):
            if value is None:
                category = 'fewer_than_two_games' if name.startswith('std_') and games < 2 else 'missing_required_source_statistic'
                row[name + ':' + category] += weight
    profiles = dict(connection.execute('SELECT league,COUNT(*) FROM player_profiles GROUP BY league'))
    first = 'SELECT player_id,league,MIN(effective_from) AS first_date FROM _player_performance_periods GROUP BY player_id,league'
    # Primary-key lookup by person and date range keeps this profile-level check bounded.
    for league, count in connection.execute('SELECT p.league,COUNT(*) FROM player_profiles p LEFT JOIN (' + first +
          ') f ON f.player_id=p.player_id AND f.league=p.league WHERE f.first_date IS NULL OR p.as_of_date<f.first_date GROUP BY p.league'):
        grouped[league]['profile_rows_before_any_collected_played_history'] = count
    for league, row in grouped.items():
        row['profile_rows'] = profiles.get(league, 0)
        row['before_history_pct_of_profiles'] = round(row['profile_rows_before_any_collected_played_history'] * 100 / profiles[league], 4)
    return {league: dict(row) for league, row in sorted(grouped.items())}


def in_game_coverage(connection):
    return [dict(zip(['provider', 'league', 'main_games', 'games_with_in_game_quotes', 'games_omitted', 'omitted_pct'], row))
        for row in connection.execute('''SELECT m.provider,m.league,COUNT(*),COUNT(i.game_id),
        COUNT(*)-COUNT(i.game_id),ROUND(100.0*(COUNT(*)-COUNT(i.game_id))/COUNT(*),4)
        FROM main m LEFT JOIN in_game i ON i.provider=m.provider AND i.game_id=m.game_id
        GROUP BY m.provider,m.league ORDER BY m.provider,m.league''')]


def save_csv(path, records):
    if not records:
        return
    with path.open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def persist_audit(report):
    fields, slots = [], []
    for item in report['datasets']:
        for field in item.get('fields', []):
            fields.append(dict(dataset=item['dataset'], **field))
        for slot in item.get('checkpoint_slots', []):
            slots.append(dict(dataset=item['dataset'], **slot))
    save_csv(ROOT / 'reports/missing_data_verified_columns.csv', fields)
    save_csv(ROOT / 'reports/missing_data_verified_checkpoints.csv', slots)
    connection = sqlite3.connect(DB, timeout=60)
    with connection:
        connection.execute('''CREATE TABLE IF NOT EXISTS _missing_data_audit_runs(
            audit_id TEXT PRIMARY KEY,generated_at_utc TEXT NOT NULL,status TEXT NOT NULL,body TEXT NOT NULL) STRICT''')
        connection.execute('''CREATE TABLE IF NOT EXISTS _missing_data_audit_fields(
            audit_id TEXT NOT NULL REFERENCES _missing_data_audit_runs(audit_id),dataset TEXT NOT NULL,
            column_name TEXT NOT NULL,rows INTEGER NOT NULL,missing_count INTEGER NOT NULL,missing_pct REAL,
            csv_missing INTEGER NOT NULL,sql_missing INTEGER NOT NULL,counts_match INTEGER NOT NULL,
            reason_basis TEXT NOT NULL,PRIMARY KEY(audit_id,dataset,column_name)) STRICT''')
        connection.execute('''CREATE TABLE IF NOT EXISTS _missing_data_audit_slots(
            audit_id TEXT NOT NULL REFERENCES _missing_data_audit_runs(audit_id),dataset TEXT NOT NULL,
            league TEXT NOT NULL,checkpoint TEXT NOT NULL,column_name TEXT NOT NULL,total_slots INTEGER,
            missing_count INTEGER,missing_pct REAL,csv_missing INTEGER,sql_missing INTEGER,counts_match INTEGER NOT NULL,
            PRIMARY KEY(audit_id,dataset,league,checkpoint,column_name)) STRICT''')
        connection.execute('INSERT INTO _missing_data_audit_runs VALUES(?,?,?,?)',
            (report['audit_id'], report['generated_at_utc'], report['status'], json.dumps(report, ensure_ascii=False)))
        connection.executemany('INSERT INTO _missing_data_audit_fields VALUES(?,?,?,?,?,?,?,?,?,?)',
            [(report['audit_id'], f['dataset'], f['column_name'], f['rows'], f['parquet_missing'],
              f['missing_pct'], f['csv_missing'], f['sql_missing'], int(f['counts_match']), f['reason_basis']) for f in fields])
        connection.executemany('INSERT INTO _missing_data_audit_slots VALUES(?,?,?,?,?,?,?,?,?,?,?)',
            [(report['audit_id'], s['dataset'], s['league'], s['checkpoint'], s['column_name'], s['total_slots'],
              s['parquet_missing'], s['missing_pct'], s['csv_missing'], s['sql_missing'], int(s['counts_match'])) for s in slots])
        connection.execute('''CREATE VIEW IF NOT EXISTS missing_data_latest AS SELECT f.*
            FROM _missing_data_audit_fields f WHERE audit_id=(SELECT audit_id FROM _missing_data_audit_runs
            ORDER BY generated_at_utc DESC,audit_id DESC LIMIT 1)''')
    connection.close()
    lines = ['# Verified missing data', '', 'Generated: ' + report['generated_at_utc'], '',
        'Audit: ' + report['status'] + '. Missing coverage is listed below as counts and percentages.', '',
        f"Checked {len(report['datasets'])} datasets, {len(fields)} columns and {len(slots)} checkpoint/field groups.",
        'The check compares current row counts and missing counts independently across CSV, Parquet and SQLite.',
        'It does not claim a new full-value source revalidation or complete external source coverage.', '',
        'Missing means NULL, numeric NaN or an empty cell. Zero and false remain valid values.',
        'In-game sequences are additionally checked slot by slot. Wholly empty in-game games are omitted from the published table.',
        'An undefined reciprocal at probability zero is not a missing probability.', '',
        '[Every column: counts, percentages and interpretation](missing_data_verified_columns.csv)', '',
        '[Every checkpoint field: counts and percentages](missing_data_verified_checkpoints.csv)', '',
        '## Omitted in-game coverage', '',
        '| Provider | League | Main games | In-game rows | Omitted | Omitted % |',
        '|---|---|---:|---:|---:|---:|']
    for row in report.get('in_game_coverage', []):
        lines.append('| ' + ' | '.join(str(v) for v in row.values()) + ' |')
    lines += ['', '## No earlier played history', '',
        'Before the first collected appearance, performance statistics are encoded as zero and player_performance.performance_status is insufficient matches. These zero-observation dates are not counted as missing statistics. Results begin with the first observed game, including the first collection year.', '',
        '| League | Profile snapshots | Before any played history | % |', '|---|---:|---:|---:|']
    for league, values in report.get('performance_context', {}).items():
        lines.append(f"| {league} | {values['profile_rows']} | {values['profile_rows_before_any_collected_played_history']} | {values['before_history_pct_of_profiles']} |")
    lines += ['', 'The JSON report separately counts undefined sample deviations with fewer than two games and missing required source statistics.',
        'These counts describe dated snapshots, not distinct players. Remaining missing fields are itemized below.', '',
        '## Query the latest recorded audit', '', '```sql',
        'SELECT dataset, column_name, rows, missing_count, missing_pct, reason_basis',
        'FROM missing_data_latest WHERE missing_count > 0 ORDER BY dataset, column_name;', '```', '',
        'Previous audit runs are retained internally with their UTC generation times. The audit time is separate from game dates and profile as-of dates.', '']
    if report.get('retained_previous_audit_id'):
        lines += ['## Verification scope', '',
                  'The revised '+report.get('rechecked_family','player_performance')+' exports were checked again against CSV, Parquet and SQL. Unchanged export checks are retained from audit ' + report['retained_previous_audit_id'] + '. Their file dates, row/column counts, current Parquet missing counts and SQL projections were reconfirmed; their full SQL/CSV scans were not repeated.', '']
    if report.get('errors'):
        lines += ['## Discrepancies', '', '```json', json.dumps(report['errors'], indent=2), '```', '']
    (ROOT / 'reports/missing_data_verification.md').write_text('\n'.join(lines), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--finalize-only', action='store_true', help='Finalize a completed retained 49-file check after an audit-report writer failure; never reruns or changes source acquisition.')
    parser.add_argument('--player-performance-only', action='store_true', help='After a player-performance-only revision, recheck those four exports and retain explicitly dated checks for all unchanged exports.')
    parser.add_argument('--team-history-only', action='store_true', help='Recheck changed team-history exports, retaining validated unchanged exports.')
    parser.add_argument('--odds-only', action='store_true', help='Recheck the four combined provider exports; retain unchanged supporting-table checks.')
    args = parser.parse_args()
    started = time.monotonic()
    inventory = json.loads((ROOT / 'reports/all_outputs_inventory.json').read_text(encoding='utf-8'))
    assert sum([args.player_performance_only,args.team_history_only,args.odds_only])<=1
    previous = json.loads(REPORT.read_text(encoding='utf-8')) if args.player_performance_only or args.team_history_only or args.odds_only else None
    if previous:
        current_datasets={x['dataset'] for x in inventory['outputs']}
        removed_only=(args.odds_only and all(e.get('dataset') not in current_datasets for e in previous['errors'])
            and all(x['status']=='WORKING' for x in previous['datasets'] if x['dataset'] in current_datasets))
        assert (previous['status'] == 'WORKING' and not previous['errors']) or removed_only
        previous_items = {x['dataset']: x for x in previous['datasets']}
        assert {x['dataset'] for x in inventory['outputs']} <= set(previous_items)
    if args.finalize_only:
        report = json.loads(REPORT.read_text(encoding='utf-8'))
        assert report['status'] == 'RUNNING' and not report['errors']
        assert [x['dataset'] for x in report['datasets']] == [x['dataset'] for x in inventory['outputs']]
        assert all(x['status'] == 'WORKING' for x in report['datasets'])
        cutoff = dt.datetime.fromisoformat(report['generated_at_utc']).timestamp()
        assert all((ROOT / x[key]).stat().st_mtime <= cutoff for x in inventory['outputs'] for key in ['csv','parquet']), 'An export changed after the saved check began'
        connection = sqlite3.connect(pathlib.Path(DB).resolve().as_uri() + '?mode=ro', uri=True, timeout=60)
        report['performance_context'] = performance_missing_context(connection)
        report['in_game_coverage'] = in_game_coverage(connection)
        connection.close()
        report['status'] = 'WORKING'
        report['finished_at_utc'] = utc()
        report['elapsed_seconds'] = round(dt.datetime.now(dt.UTC).timestamp() - cutoff, 3)
        report['finalization_note'] = 'Retained completed file checks finalized after fixing an audit SQL INSERT placeholder count; the failed transaction did not change source data. Export modification times predate the checks.'
        persist_audit(report)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps({k:report[k] for k in ['status','audit_id','elapsed_seconds','errors']}), flush=True)
        return 0
    report = dict(audit_id=uuid.uuid4().hex, generated_at_utc=utc(), status='RUNNING',
        collection_status='PARTIALLY WORKING', datasets=[], errors=[],
        definition='Compare missing and row counts, not full cell values; empty string, NULL and numeric NaN are missing, zero/false are valid.')
    if previous:
        report['retained_previous_audit_id'] = previous['audit_id']
        report['retained_previous_audit_timestamp'] = previous['generated_at_utc']
        report['rechecked_family'] = 'provider odds' if args.odds_only else 'team_history' if args.team_history_only else 'player_performance'
    connection = sqlite3.connect(pathlib.Path(DB).resolve().as_uri() + '?mode=ro', uri=True, timeout=60)
    connection.execute('BEGIN')
    threshold = 10
    for index, item in enumerate(inventory['outputs'], 1):
        print('CHECK FILE', index, '/', len(inventory['outputs']), item['dataset'], flush=True)
        try:
            changed = any(item['dataset'].startswith('data/result/'+p+'/') for p in ['polymarket','kalshi']) if args.odds_only else item['dataset'].endswith('/team_history') if args.team_history_only else item['dataset'].endswith('/player_performance')
            if previous and not changed:
                result = dict(previous_items[item['dataset']])
                assert result['status'] == 'WORKING'
                cutoff = dt.datetime.fromisoformat(previous['generated_at_utc']).timestamp()
                assert all((ROOT / item[k]).stat().st_mtime <= cutoff for k in ['parquet', 'csv']), ('Export changed outside requested audit scope', item['dataset'])
                assert result['rows'] == item['rows'] and result['columns'] == len(item['columns'])
                old_fields = {f['column_name']: f for f in result['fields']}
                for col in item['columns']:
                    assert old_fields[col['column']]['parquet_missing'] == col['missing'], (item['dataset'], col['column'])
                sql, params = public_query(item['dataset'], [c['column'] for c in item['columns']])
                assert sql == result['sql'] and params == result['parameters']
                assert [d[0] for d in connection.execute(sql + ' LIMIT 0', params).description] == list(old_fields)
                result['validation_mode'] = 'retained_previous_audit_for_unchanged_export'
                result['verified_at_utc'] = result.get('verified_at_utc', previous['generated_at_utc'])
                result['source_audit_id'] = result.get('source_audit_id', previous['audit_id'])
            else:
                result = verify_file(connection, item)
                result['validation_mode'] = 'current_csv_parquet_sql_check'
                result['verified_at_utc'] = report['generated_at_utc']
            report['datasets'].append(result)
            if result['status'] != 'WORKING':
                report['errors'].append(dict(dataset=item['dataset'], reason='Counts, column order, whitespace or file-stability discrepancy'))
        except Exception as exc:
            report['errors'].append(dict(dataset=item['dataset'], error=repr(exc)))
            report['datasets'].append(dict(dataset=item['dataset'], status='SCHEMA PROBLEM', error=repr(exc)))
            print('ERROR', item['dataset'], repr(exc), flush=True)
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        while threshold <= 100 and index * 100 >= threshold * len(inventory['outputs']):
            print('MISSING AUDIT', str(threshold) + '%', index, '/', len(inventory['outputs']),
                  'datasets checked; errors', len(report['errors']), flush=True)
            threshold += 10
    print('CHECK CONTEXT: performance and omitted in-game rows', flush=True)
    report['performance_context'] = previous['performance_context'] if args.odds_only else performance_missing_context(connection)
    report['in_game_coverage'] = in_game_coverage(connection)
    connection.close()
    report['status'] = 'SCHEMA PROBLEM' if report['errors'] else 'WORKING'
    report['finished_at_utc'] = utc()
    report['elapsed_seconds'] = round(time.monotonic() - started, 3)
    persist_audit(report)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: report[k] for k in ['status', 'audit_id', 'elapsed_seconds', 'errors']}, ensure_ascii=False), flush=True)
    return 1 if report['errors'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
