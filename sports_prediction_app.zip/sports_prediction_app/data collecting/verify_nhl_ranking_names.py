"""Resolve a published formal name using an official NHL identity and DOB."""
import datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT

c=HistoryClient();url='https://www.nhl.com/es/news/perfiles-de-las-estrellas-de-la-nhl-mitchell-marner-341262206';b,r,_=get(c,url);s=BeautifulSoup(b,'html.parser');text=s.get_text(' ',strip=True)
db=sqlite3.connect(DB,timeout=60);p=json.loads(db.execute("SELECT body FROM _official_nhl_player_bios WHERE official_player_id='8478483'").fetchone()[0]);assert p['player_name']=='Mitch Marner' and p['birth_date']=='1997-05-05'
assert 'Mitchell Marner' in text and '5 de mayo de 1997' in text
proof=dict(alias='Mitchell Marner',official_player_id='8478483',player_name=p['player_name'],request_id=r['request_id'],source_url=url,biography_request_id=p['request_id'],birth_date='1997-05-05',name_evidence='Mitchell Marner',date_evidence='5 de mayo de 1997')
db.execute('CREATE TABLE IF NOT EXISTS _nhl_verified_ranking_aliases (alias TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('INSERT OR REPLACE INTO _nhl_verified_ranking_aliases VALUES (?,?)',(proof['alias'],json.dumps(proof)));db.commit();db.close();print(json.dumps(proof));
