"""Independent source totals and bounded SQL statistics for the collected EPL sample."""
import collections,datetime as dt,json,math,sqlite3,statistics
from build_history_catalog import DB
from epl_price_points import Sources,pointer
from probe_history import ROOT
from temporal_queries import QUERIES

def same(a,b):return a is None and b is None or a is not None and b is not None and math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-8)

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;src=Sources(db);checks=collections.Counter();facts=collections.defaultdict(list);gamefacts=collections.defaultdict(list);games={r[0]:json.loads(r[1]) for r in db.execute("SELECT * FROM _eu_game_facts WHERE json_extract(body,'$.competition')='Premier League'")};start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    for r in db.execute('SELECT body FROM _epl_player_game_facts'):
        p=json.loads(r[0]);g=games[p['game_id']];assert p['team_name']==g['teams'][p['side']] and p['win']==int(g['winner']==p['team_name']);raw,_=src.get(p['roster_request_id']);side=['away_team','home_team'][p['side']];players=raw[side]['players'];found=[v for v in players if v['id']==p['official_player_id']];assert found==[p['raw_player']];starters={v for group in raw[side]['formation']['lineup'] for v in group};assert p['starter']==(p['official_player_id'] in starters);checks['raw_roster_identity_starter_and_official_winner']+=1
        gamefacts[p['game_id']].append(p)
        if p['did_play']:facts[p['player_id']].append(p)
        else:assert p['score'] is None and p['assists'] is None and p['minutes'] is None
    for gid,ps in gamefacts.items():
        events,_=src.get(ps[0]['events_request_id']);g=games[gid];cancelled=ps[0]['verified_cancelled_goals'];excluded={x['events_pointer'] for x in cancelled}
        for c in cancelled:
            assert pointer(events,c['events_pointer'])==c['raw'];proof=c['cancellation_source'];raw,_=src.get(proof['request_id']);assert pointer(raw,proof['pointer'])==proof['raw'] and proof['raw']['type']=='VAR cancelled goal';checks['raw_cancelled_goal_evidence']+=1
        for n,side in enumerate(['awayTeam','homeTeam']):
            active=[v for i,v in enumerate(events[side]['goals']) if '/'+side+'/goals/'+str(i) not in excluded];assert len(active)==g['scores'][n];counts=collections.Counter(v['playerId'] for v in active if v['goalType']!='Own');assists=collections.Counter(v['assistPlayerId'] for v in active if v.get('assistPlayerId'));assert sum(p['score'] for p in ps if p['side']==n and p['did_play'])==sum(v['goalType']!='Own' for v in active);checks['individual_goal_totals_against_official_result']+=1
            for p in ps:
                if p['side']!=n or not p['did_play']:continue
                assert p['score']==counts[p['official_player_id']]
                if all('assistPlayerId' in v for v in active):assert p['assists']==assists[p['official_player_id']]
                if p['minutes'] is not None:assert p['minutes']>=0
                checks['individual_goal_and_assist_values']+=1
    sqlfacts={r['player_id']+':'+r['game_id']:dict(r) for r in db.execute("SELECT * FROM _player_game_results WHERE player_id LIKE 'EU_PL:%'")};assert len(sqlfacts)==sum(map(len,facts.values()))
    for pid,ps in facts.items():
        for p in ps:
            r=sqlfacts[pid+':'+p['game_id']]
            for k in ['player_name','team_name','game_date','score','assists','minutes','starter','win']:assert r[k]==p[k]
            checks['source_fact_to_performance_sql']+=1
    examples=[];dates=['2024-01-01','2024-08-15','2024-08-16','2024-12-31','2025-05-03','2025-05-11','2025-12-31','2026-05-24',end]
    for day in dates:
        rows={r['player_id']:dict(r) for r in db.execute("SELECT * FROM player_performance WHERE league='EU soccer' AND as_of_date=?",(day,))};expected_ids={pid for pid,ps in facts.items() if any(start<=p['game_date']<=day for p in ps)};assert set(rows)==expected_ids;checks['no_future_players']+=len(facts)-len(rows);averages=[]
        for pid,row in rows.items():
            bounded=[p for p in facts[pid] if start<=p['game_date']<=day];assert row['games_played']==len(bounded) and same(row['overall_winrate'],statistics.mean(p['win'] for p in bounded));checks['bounded_player_count_and_winrate']+=1
            for k in ['score','assists','minutes']:
                vs=[p[k] for p in bounded];complete=all(v is not None for v in vs);avg=statistics.mean(vs) if complete else None;sd=statistics.stdev(vs) if complete and len(vs)>1 else None;assert same(row['average_'+k+'_per_game'],avg) and same(row['std_'+k+'_per_game'],sd),(day,pid,k);checks['independent_mean_and_sample_std']+=2
            assert same(row['starter_percentage_overall'],statistics.mean(p['starter'] for p in bounded));averages.append(row['average_score_per_game'])
        if averages:
            mu=statistics.mean(averages);sigma=statistics.pstdev(averages)
            for row in rows.values():assert same(row['score_z_score'],(row['average_score_per_game']-mu)/sigma if sigma else None);checks['past_only_z_score_cohort']+=1
        for table,key,winfield in [('team_history','team_name','winrate'),('manager_performance','manager_id','overall_winrate')]:
            base='_team_game_results' if table=='team_history' else '_manager_game_results';bounded=collections.defaultdict(list)
            for r in db.execute('SELECT * FROM '+base+" WHERE league='EU soccer' AND game_date BETWEEN ? AND ?",(start,day)):bounded[r[key]].append(dict(r))
            actual=[dict(r) for r in db.execute('SELECT * FROM '+table+" WHERE league='EU soccer' AND as_of_date=?",(day,))];assert {r[key] for r in actual}==set(bounded)
            for r in actual:
                xs=bounded[r[key]];assert r['games_played']==len(xs) and same(r[winfield],statistics.mean(v['win'] for v in xs));assert r['home_times']==sum(v['home_away']=='Home' for v in xs) and r['away_times']==sum(v['home_away']=='Away' for v in xs);assert same(r['average_score_margin'],statistics.mean(v['score_for']-v['score_against'] for v in xs));checks['bounded_'+table]+=1
        examples.append(dict(date=day,players=len(rows)))
    # The user's custom collection lower bound must also remove earlier games.
    lower='2025-08-01';day='2025-12-31';sql=QUERIES['player_performance'];actual=[dict(r) for r in db.execute(sql,dict(collection_start=lower,query_date=day)) if r['league']=='EU soccer'];assert len(actual)==len({r['player_id'] for r in actual}),'A name change split one native player into two query rows'
    expected={pid:[p for p in ps if lower<=p['game_date']<=day] for pid,ps in facts.items()};expected={pid:ps for pid,ps in expected.items() if ps};assert {r['player_id'] for r in actual}==set(expected)
    for r in actual:assert r['games_played']==len(expected[r['player_id']]) and same(r['average_score_per_game'],statistics.mean(p['score'] for p in expected[r['player_id']]));checks['custom_start_date_sql']+=1
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Published EPL game facts and performance SQL; biographies, contracts and profile expansion validated separately',games=len(games),players_with_appearances=len(facts),checks=dict(checks),source_hashes=len(src.cache),examples=examples);(ROOT/'reports/epl_performance_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
