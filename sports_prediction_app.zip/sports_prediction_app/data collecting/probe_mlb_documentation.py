"""Follow official documentation assets and official canonical game-page links."""
import json,re
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT

def main():
    c=HistoryClient();out=[]
    for url in ['https://docs.statsapi.mlb.com/assets/js/main.1902ab9b.js','https://www.mlb.com/gameday/braves-vs-blue-jays/2025/04/16/778297/final/box']:
        try:
            b,r=c.get(url,document=True);text=b.decode('utf-8',errors='replace');s=BeautifulSoup(b,'html.parser')
            paths=sorted(set(re.findall(r'["\']([^"\'\s]*(?:swagger|openapi|\.ya?ml|\.json|/docs/)[^"\'\s]*)["\']',text,re.I)))
            row=dict(url=url,request_id=r['request_id'],bytes=len(b),documentation_paths=[p for p in paths if len(p)<250][:60],game_data_scripts=[dict(id=t.get('id'),length=len(t.string or t.get_text()),prefix=(t.string or t.get_text())[:100]) for t in s.find_all('script') if any(w in (t.string or t.get_text()) for w in ['gamePk','boxscore','778297','__NEXT_DATA__'])])
            # Document code references are sufficient to locate documentation,
            # but are not permission to call authenticated internal endpoints.
            if 'docs.statsapi' in url:
                for term in ['spec-url','swagger','openapi','Login','Sign in','API Reference']:
                    i=text.find(term)
                    if i>=0:row.setdefault('documentation_navigation',[]).append(text[max(0,i-80):i+160])
        except Exception as e:row=dict(url=url,error=str(e))
        out.append(row);print(json.dumps(row),flush=True)
    (ROOT/'reports/mlb_documentation_probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8')

if __name__=='__main__':main()
