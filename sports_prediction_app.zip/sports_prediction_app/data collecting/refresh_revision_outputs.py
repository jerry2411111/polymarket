"""Rebuild requested public policies from retained facts, then update the catalog.

No provider downloads are triggered. Retained sports facts and raw evidence
are retained. This entry point prevents individual legacy builders from being
mistaken for a complete public release.
"""
import subprocess,sys
from pathlib import Path

def main():
 folder=Path(__file__).resolve().parent
 jobs=[('install_temporal_performance.py',[]),('apply_requested_revision.py',[]),
       ('apply_no_observation_policy.py',[]),('install_serving_manager_performance.py',[]),
       ('remove_requested_support_fields.py',[]),('install_latest_rankings.py',[]),
       ('validate_requested_revision.py',[]),('export_requested_revision.py',[]),
       ('export_requested_revision.py',['--manager-performance-only']),('verify_daily_cumulative_performance.py',[]),
       ('report_all_outputs.py',[]),('verify_missing_data.py',[]),
       ('record_supporting_gaps.py',[]),('report_current_sources.py',[]),
       ('generate_data_catalog.py',[]),('verify_catalog_structure.py',[]),('report_requested_revision.py',[])]
 for script,args in jobs:
  subprocess.run([sys.executable,'-X','utf8',str(folder/script),*args],check=True)
if __name__=='__main__':main()
