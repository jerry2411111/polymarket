import json,sqlite3
from build_history_catalog import DB

def dates(obj):
    if isinstance(obj,dict):
        for k,v in obj.items():
            if k in ['datePublished','dateModified']:yield k,v
            elif isinstance(v,(dict,list)):yield from dates(v)
    elif isinstance(obj,list):
        for v in obj:yield from dates(v)

if __name__=='__main__':
    db=sqlite3.connect(DB)
    for table in ['_nhl_coach_sources']:
        for url,b in db.execute('SELECT * FROM '+table):
            s=json.loads(b)
            if s['status']!='ACQUIRED_NOT_VERIFIED' or 'nhl-coaches-2023-24-season' in url:continue
            print(json.dumps(dict(url=url,request_id=s['request_id'],dates=list(dates(s['metadata'])),paragraphs=s['paragraphs'][:6]),ensure_ascii=False))
    db.close()
