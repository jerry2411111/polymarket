"""Validate real manager assignments, date-bounded performance and profiles."""
import collections,datetime as dt,json,math,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from temporal_queries import MANAGER_SQL

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    facts=[dict(r) for r in db.execute("SELECT * FROM _manager_game_results WHERE league='NBA'")];teams={(r['game_id'],r['team_name']):dict(r) for r in db.execute("SELECT * FROM _team_game_results WHERE league='NBA'")}
    for r in facts:
        source=teams[r['game_id'],r['team_name']]
        for col in ['game_date','home_away','score_for','score_against','win']:assert r[col]==source[col]
    assert len(facts)==len({(r['game_id'],r['team_name']) for r in facts})
    dates=['2024-06-01','2025-02-16','2026-01-15','2026-09-14'];checks=[]
    for day in dates:
        grouped=collections.defaultdict(list)
        for r in facts:
            if '2024-01-01'<=r['game_date']<=day:grouped[r['manager_id']].append(r)
        for p in db.execute("SELECT * FROM manager_profiles WHERE league='NBA' AND as_of_date=?",(day,)):
            rows=grouped.get(p['manager_id'],[]);value=sum(r['win'] for r in rows)/len(rows) if rows else None
            assert p['overall_winrate']==value,(day,p['manager_id'],p['overall_winrate'],value)
        checks.append(dict(as_of_date=day,managers_with_collected_games=len(grouped),games_used=sum(len(r) for r in grouped.values())))
        direct={r['manager_id']:dict(r) for r in db.execute(MANAGER_SQL,{'collection_start':'2024-01-01','query_date':day}) if r['league']=='NBA'}
        view={r['manager_id']:dict(r) for r in db.execute("SELECT * FROM manager_performance WHERE league='NBA' AND as_of_date=?",(day,))}
        assert direct==view,(day,'Manager SQL/view mismatch')
    # Specific official-change examples: NBA credited the acting Spurs coach;
    # both Denver and Memphis changed coach during the 2024-25 season.
    examples=[]
    for team,at,pid in [('San Antonio Spurs','2024-11-02','NBA_COACH:mitch-johnson'),('Denver Nuggets','2025-04-08','NBA_COACH:david-adelman'),('Memphis Grizzlies','2025-03-28','NBA_COACH:tuomas-iisalo'),('Sacramento Kings','2024-12-27','NBA_COACH:doug-christie')]:
        rs=sorted((r for r in facts if r['team_name']==team and r['game_date']>=at),key=lambda x:x['game_date']);r=rs[0];assert r['manager_id']==pid
        proof=json.loads(db.execute('SELECT body FROM _nba_manager_game_audit WHERE manager_id=? AND game_id=?',(pid,r['game_id'])).fetchone()[0]);s=proof['stint'];assert s['official_confirmation']
        examples.append(dict(game_id=r['game_id'],date=r['game_date'],team=team,manager_name=r['manager_name'],official_sources=s['official_confirmation'],result=[r['score_for'],r['score_against']],match=True))
    # Special programs must never inherit the franchise head coach automatically.
    for r in facts:
        g=json.loads(db.execute('SELECT body FROM _nba_canonical_games WHERE id=?',(r['game_id'],)).fetchone()[0]);assert 'Summer League' not in g['season'] and 'All-Star' not in g['season']
    report=json.loads((ROOT/'reports/nba_manager_history.json').read_text());missing=collections.Counter(x['reason'] for x in report['unattributed']);pending=[x for x in report['unattributed'] if 'Special-program' not in x['reason']]
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',coverage_status='PARTIAL',source_score_checks=len(facts)*5,date_checks=checks,change_examples=examples,unattributed_by_reason=dict(missing),unresolved_regular_program_assignments=pending,scope='Validates sourced interval application and collected-game results. SalarySwish-only appointment dates and unobserved brief absences remain limitations.')
    (ROOT/'reports/nba_manager_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['change_examples','unresolved_regular_program_assignments']}));db.close()

if __name__=='__main__':main()
