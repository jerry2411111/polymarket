"""Independent checks of every official MLB source used for matched games."""
import collections,datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from history_index import records
from core import utc,pointer
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);rs={r['request_id']:r for r in records()};games=[json.loads(b) for b, in db.execute('SELECT body FROM _mlb_canonical_games')];checks=0;missing=collections.Counter();years=collections.Counter();native=set();suspended=[];examples=[]
    for n,g in enumerate(sorted(games,key=lambda x:(x['date'],x['game_id'])),1):
        gid=g['official_game_id'];assert gid not in native;native.add(gid)
        f=json.loads(db.execute('SELECT body FROM _official_mlb_feeds WHERE official_game_id=?',(gid,)).fetchone()[0]);s=json.loads(db.execute('SELECT body FROM _official_mlb_schedule WHERE official_game_id=?',(gid,)).fetchone()[0]);raws=[]
        for rid in [f['request_id'],s['request_id']]:
            r=rs[rid];b=(ROOT/r['raw_file']).read_bytes();assert r['status']==200 and hashlib.sha256(b).hexdigest()==r['sha256'];raws.append(json.loads(b));checks+=1
        d,sd=raws;card=pointer(sd,s['pointer']);assert str(d['gamePk'])==str(card['gamePk'])==gid
        assert d['gameData']['status']['abstractGameState']=='Final' and card['status']['detailedState'] not in ['Cancelled','Postponed'];checks+=2
        assert [str(d['gameData']['teams'][side]['id']) for side in ['away','home']]==g['team_ids']==s['official_team_ids']
        assert [card['teams'][side]['score'] for side in ['away','home']]==[d['liveData']['linescore']['teams'][side]['runs'] for side in ['away','home']]==f['scores']==g['scores'];checks+=2
        assert card['officialDate']==g['date'];assert card['gameNumber']==g['doubleheader_number'];assert g['game_id'].endswith('_G'+str(card['gameNumber']));checks+=3
        winner=[card['teams'][side]['team']['name'] for side in ['away','home'] if card['teams'][side].get('isWinner')]
        assert len(winner)<=1 and (not winner or winner[0]==g['winner']);checks+=1
        innings={i['num']:i for i in d['liveData']['linescore']['innings']}
        for index,number in enumerate([3,5,7],1):
            expected=[]
            for side in ['away','home']:
                runs=[innings.get(i,{}).get(side,{}).get('runs') for i in range(1,number+1)];expected.append(sum(runs) if all(v is not None for v in runs) else None)
            assert expected==f['break_scores'][index];checks+=1
        plays=d['liveData']['plays']['allPlays'];pitches=[utc(e['startTime']) for p in plays for e in p.get('playEvents',[]) if e.get('isPitch') and e.get('startTime')]
        assert f['actual_first_pitch_utc']==(min(pitches).isoformat() if pitches else None);checks+=1
        for i,br in enumerate(f['breaks']):
            if br['start_utc'] is None:missing['break_interval']+=1;continue
            assert utc(br['start_utc'])<utc(br['end_utc']);play=next(p for p in plays if p['about']['atBatIndex']==br['source_play_index'])
            assert play['about']['inning']==[3,5,7][i] and play['about']['halfInning']=='bottom' and play['count']['outs']==3;assert utc(play['about']['endTime'])==utc(br['start_utc']);checks+=3
        for p in f['players']:
            raw=pointer(d,p['pointer']);assert str(raw['person']['id'])==p['official_player_id'];assert raw['person']['fullName']==p['player_name'];checks+=2
            for key,group,field in [('score','batting','runs'),('assists','fielding','assists')]:
                expected=raw.get('stats',{}).get(group,{}).get(field) if p['did_play'] else None;assert p[key]==expected;checks+=1
        years[g['date'][:4]]+=1
        if f['spans_multiple_local_dates']:suspended.append(dict(game_id=g['game_id'],first_pitch=f['actual_first_pitch_utc'],completion=f['last_play_utc'],performance_available_date=f['completion_local_date']))
        if not f['actual_first_pitch_utc']:missing['actual_first_pitch']+=1
        if len(examples)<3 or g['doubleheader_number']==2 and not any(x['game_id'].endswith('_G2') for x in examples):examples.append(dict(game_id=g['game_id'],official_game_id=gid,date=g['date'],teams=g['teams'],score=g['scores'],winner=g['winner'],source_url=f['source_url'],request_id=f['request_id'],official_url='https://www.mlb.com/gameday/'+gid))
        if n%500==0 or n==len(games):print('MLB RAW REPORT VALIDATION',n,'/',len(games),'checks',checks,flush=True)
    report=dict(checked_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',games=len(games),raw_checks=checks,years=dict(years),missing=dict(missing),multi_date_games=suspended,examples=examples,scope='Native IDs, official final results, scheduled dates, first pitch, inning scores/clocks and player values; odds eligibility is tested separately')
    (ROOT/'reports/mlb_official_reports_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['examples','multi_date_games']}));db.close()

if __name__=='__main__':main()
