"""Reviewed official stadium-city evidence, with source IDs and no inferred game venue."""
import datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT

LAL_CITIES={'14':'Madrid','9':'Getafe','21':'Vitoria','16':'San Sebastián','20':'Villarreal','18':'Valencia','162':'Cádiz','10':'Granada','6':'Vigo','33':'Palma de Mallorca','15':'Madrid','2':'Madrid','28':'Gerona','1':'Almería','13':'Pamplona','3':'Bilbao','17':'Sevilla','4':'Barcelona','31':'Las Palmas de Gran Canaria','54':'Leganés','8':'Cornellà de Llobregat','19':'Valladolid','157':'Oviedo','11':'Valencia','7':'Elche','49':'Santander','26':'A Coruña','12':'Málaga'}

def main():
 db=sqlite3.connect(DB,timeout=60);rows=[];checks=0
 for tid,b in db.execute('SELECT * FROM _official_laliga_club_location_sources'):
  r=json.loads(b)
  if r['status']!='ok' or tid not in LAL_CITIES:continue
  m=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(r['request_id'],)).fetchone()[0]);raw=(ROOT/m['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==m['sha256'];script=re.search(rb'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',raw,re.S);club=json.loads(script[1])['props']['pageProps']['club'];assert club==r['club'];city=LAL_CITIES[tid];assert city in club['address'];venue=club['venue'];checks+=1;body=dict(competition_code='LAL',venue_names=[venue['name']],city=city,country='ES',request_id=r['request_id'],pointer='/props/pageProps/club/address',venue_pointer='/props/pageProps/club/venue',raw_address=club['address'],latitude=None,longitude=None,method='Reviewed literal city in the official stadium postal address, paired with native venue record; current venue used only when dated game venue matches');rows.append(('LAL',str(venue['id']),json.dumps(body)))
 # Barcelona's current stadium and Betis' mailing address cannot establish
 # where their temporary venues were located; those require separate records.
 url='https://www.bundesliga.com/en/bundesliga/news/stadiums-germany-2025-26-allianz-arena-signal-iduna-park-32656';r=json.loads(db.execute('SELECT body FROM _eu_location_documents WHERE url=?',(url,)).fetchone()[0]);m=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(r['request_id'],)).fetchone()[0]);raw=(ROOT/m['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==m['sha256'];soup=BeautifulSoup(raw,'html.parser');text=' '.join(soup.stripped_strings);assert 'stadium in Sinsheim' in text;clubs=[]
 for script in soup.find_all('script',type='application/json'):
  state=json.loads(script.get_text())
  for key,value in state.items():
   b=value.get('b') if isinstance(value,dict) else None
   if isinstance(b,dict) and isinstance(b.get('bundesliga'),list):
    for division,items in b.items():
     if isinstance(items,list):
      for i,t in enumerate(items):
       if isinstance(t,dict) and isinstance(t.get('stadium'),dict):clubs.append((f'/{key}/b/{division}/{i}',t))
 for path,t in clubs:
  s=t['stadium'];name=s.get('name');city=t.get('contact',{}).get('city');icon=s.get('stadiumIconUrlBlack') or '';native=re.search(r'(DFL-STA-[A-Z0-9]+)_',icon)
  if not name or not city or not native:continue
  if city=='Zuzenhausen':city='Sinsheim';basis='Official stadium article explicitly places the Hoffenheim stadium in Sinsheim; club mailing city Zuzenhausen is not used'
  else:basis='Official league club/venue directory city and native stadium record, reviewed with the official stadium overview'
  link=s.get('mapsUrl','');coords=re.search(r'!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)',link) or re.search(r'@(-?\d+\.\d+),(-?\d+\.\d+)',link);body=dict(competition_code='BUN',venue_names=[name],city=city,country='DE',request_id=r['request_id'],pointer=path,raw_contact_city=t['contact']['city'],native_stadium_id=native[1],latitude=float(coords[1]) if coords else None,longitude=float(coords[2]) if coords else None,official_coordinate_link=link,method=basis);rows.append(('BUN',native[1],json.dumps(body)))
 unique={}
 for code,vid,body in rows:
  value=json.loads(body);key=(code,vid)
  if key in unique:
   old=json.loads(unique[key]);assert (old['city'],old['country'])==(value['city'],value['country']),(key,old['city'],value['city'])
  unique[key]=body
 rows=[(code,vid,body) for (code,vid),body in unique.items()]
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _eu_stadium_location_reviews (competition_code TEXT,venue_id TEXT,body TEXT NOT NULL,PRIMARY KEY(competition_code,venue_id)) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_stadium_location_reviews VALUES (?,?,?)',rows)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',laliga_postal_addresses_checked=checks,bundesliga_native_stadia=sum(c=='BUN' for c,_,_ in rows),new_requests=0,limits='Venue identity must agree with the dated official game. Club roster affiliation is not inferred. Official map-link coordinates are retained as supplied; Google Maps is not queried.');(ROOT/'reports/eu_stadium_location_reviews.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
