"""Select previous observations without leaking future aggregate-window values."""
import datetime as dt

def available_at(point):
    # Official Polymarket v2 PricePoint reports the aggregate's bucket START.
    # Kalshi end_period_ts is already the close time; do not shift it again.
    return point['timestamp']+(point.get('resolution_seconds',0) if point.get('kind')=='v2' else 0)

def inside_window(point,lo,hi):
    if lo is None or hi is None:return False
    return lo<=point['timestamp']<hi and available_at(point)<=hi

def nearest_pregame(points,target,start):
    if target is None:return None
    eligible=[p for p in points if p['timestamp']<start and available_at(p)<=target]
    def order(p):
        retrieved=p.get('retrieved_at_utc')
        retrieved=dt.datetime.fromisoformat(retrieved.replace('Z','+00:00')).timestamp() if retrieved else 0
        return (target-available_at(p),-p['timestamp'],p.get('resolution_seconds',86400),-retrieved,p.get('kind',''))
    return min(eligible,key=order) if eligible else None
