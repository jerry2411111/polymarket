"""Preserve official employment source documents and inspect dated statements."""
import datetime as dt,io,json,re
from pypdf import PdfReader
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

URLS=['https://media.nhl.com/site/asset/public/ext/2023-24/2023-24%20New%20Head%20Coaches%20and%20General%20Managers.pdf','https://media.nhl.com/site/asset/public/ext/nhl%20stats/2024-25%20Regular%20Season/2024-25%20New%20Head%20Coaches%20and%20GMs.pdf','https://media.nhl.com/site/asset/public/ext/CBA.pdf']
HOSTS.add('media.nhl.com');c=HistoryClient();out=[]
for url in URLS:
    b,r=c.get(url,document=True);pdf=PdfReader(io.BytesIO(b));pages=[]
    for n,page in enumerate(pdf.pages):
        text=page.extract_text() or ''
        if url.endswith('CBA.pdf'):
            if 'commencing the later of July 1' in text:pages.append(dict(page=n+1,text=text))
        elif 'coach' in text.lower():pages.append(dict(page=n+1,text=text))
    row=dict(url=url,request_id=r['request_id'],pages=pages);out.append(row)
    print('OFFICIAL DOCUMENT',url,r['request_id'],'selected pages',len(pages),flush=True)
    if not url.endswith('CBA.pdf'):
        for p in pages:print('PAGE',p['page'],p['text'][:1800],flush=True)
(ROOT/'reports/nhl_official_employment_documents.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),documents=out,new_requests=c.requests),indent=2),encoding='utf-8')
