"""Inspect the official current client match/detail and lineup routes on three games."""
import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def shape(v,depth=0):
 if depth>2:return type(v).__name__
 if isinstance(v,dict):return {k:shape(x,depth+1) for k,x in v.items()}
 if isinstance(v,list):return dict(length=len(v),first=shape(v[0],depth+1) if v else None)
 return v if not isinstance(v,str) or len(v)<200 else v[:200]

def main():
 HOSTS.add('match.uefa.com');c=HistoryClient();rows=[]
 for mid in ['2039914','2039915','2039916']:
  for suffix in ['/events']:
   url='https://match.uefa.com/v5/matches/'+mid+suffix
   try:
    d,r=c.get(url,dict(filter='ALL',limit=500,offset=0,order='ASC'));row=dict(match_id=mid,kind=suffix.strip('/'),endpoint=url,request_id=r['request_id'],status=r['status'],shape=shape(d));print(json.dumps(row),flush=True)
   except Exception as e:row=dict(match_id=mid,endpoint=url,error=str(e));print(json.dumps(row),flush=True)
   rows.append(row)
 (ROOT/'reports/uefa_events_pilot.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),client_request_id='706fcffca9c44bc7a677111ba214d978',rows=rows,new_requests=c.requests),indent=2),encoding='utf-8')

if __name__=='__main__':main()
