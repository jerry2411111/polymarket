"""Project existing verified exports onto requested SQL schemas; preserve retained values."""
import csv,datetime as dt,hashlib,json,sqlite3
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT

def digest(table):return hashlib.sha256(json.dumps(table.to_pydict(),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def main():
    db=sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True);out=[]
    result=(ROOT/'data/result').resolve()
    for folder in ['nba','mlb','nhl','eu_soccer']:
        for name in ['player_profiles','team_history']:
            cols=[r[1] for r in db.execute('PRAGMA table_info('+name+')')];path=ROOT/'data/result'/folder/(name+'.parquet');old=pq.ParquetFile(path)
            temp=path.with_suffix('.revised.parquet');csvtemp=path.with_suffix('.revised.csv');schema=old.schema_arrow
            expected=[];n=0
            with pq.ParquetWriter(temp,schema=schema.remove(schema.get_field_index('number_of_teams_served')) if name=='player_profiles' and 'number_of_teams_served' in schema.names else __import__('pyarrow').schema([schema.field(c) for c in cols]),compression='zstd') as writer,csvtemp.open('w',newline='',encoding='utf-8') as f:
                cw=csv.writer(f);cw.writerow(cols)
                for batch in old.iter_batches(batch_size=25000,columns=cols):
                    import pyarrow as pa
                    table=pa.Table.from_batches([batch]);writer.write_table(table,row_group_size=table.num_rows);cw.writerows(zip(*(table.column(c).to_pylist() for c in cols)));expected.append(digest(table));n+=table.num_rows
            check=pq.ParquetFile(temp);assert check.metadata.num_rows==old.metadata.num_rows==n
            for i,h in enumerate(expected):assert digest(check.read_row_group(i))==h
            check.close();old.close();temp.replace(path);csvtemp.replace(path.with_suffix('.csv'))
            out.append(dict(dataset=folder+'/'+name,rows=n,columns=len(cols),all_retained_values_equal=True));print('PROJECTED',out[-1],flush=True)
        for ext in ['csv','parquet']:
            path=(ROOT/'data/result'/folder/('player_rankings_quarterly.'+ext)).resolve()
            assert path.is_relative_to(result),path
            if path.exists():path.unlink()
    db.close();(ROOT/'reports/support_projection_validation.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),outputs=out,removed_quarterly_exports=True),indent=2),encoding='utf-8')
if __name__=='__main__':main()
