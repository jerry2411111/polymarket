﻿import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for clause in ["json_extract(body,'$.league')='MLB' AND json_extract(body,'$.date')<'2025'","game_id LIKE 'MLB_2025%G2'","game_id LIKE 'MLB_2026%' AND json_extract(body,'$.date')<'2026-03-27'"]:
 xs=db.execute('SELECT game_id,body FROM _official_game_facts WHERE '+clause+' ORDER BY game_id LIMIT 3').fetchall();print([(g,json.loads(b)['official_game_id'],json.loads(b)['teams'],json.loads(b)['scores']) for g,b in xs])
