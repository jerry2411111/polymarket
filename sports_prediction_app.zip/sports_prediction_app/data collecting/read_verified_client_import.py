"""Read one explicitly referenced same-site JS module without exposing configuration."""
import argparse,json,re,sqlite3
from urllib.parse import urljoin,urlsplit
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
ap=argparse.ArgumentParser();ap.add_argument('parent_request');ap.add_argument('filename');a=ap.parse_args();assert re.fullmatch(r'[A-Za-z0-9_.-]+\.js',a.filename);db=sqlite3.connect(DB);meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(a.parent_request,)).fetchone()[0]);text=(ROOT/meta['raw_file']).read_text(encoding='utf-8');assert re.search(r'["\x27](?:\./)?'+re.escape(a.filename)+r'["\x27]',text);url=urljoin(meta['endpoint'],a.filename);HOSTS.add(urlsplit(url).hostname);c=HistoryClient();b,r=c.get(url,document=True);assert not b.lstrip().lower().startswith(b'<!doctype html');s=b.decode();print('OFFICIAL MODULE',r['request_id'],url,'bytes',len(b));print('IMPORTS',sorted(set(re.findall(r'["\x27]\./([A-Za-z0-9_.-]+\.js)["\x27]',s))));print('NAMED LAZY ROUTES',re.findall(r'import\(["\x27]([^"\x27]+)["\x27]\).{0,45}',s)[:25]);db.close()
