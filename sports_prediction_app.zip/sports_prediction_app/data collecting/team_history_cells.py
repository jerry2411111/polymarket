"""Comma-separated team history; quote names containing commas using CSV rules."""
import csv,io
def encode(names):
 if not names:return None
 out=io.StringIO();csv.writer(out,lineterminator='').writerow(names);return out.getvalue()
def decode(value):return next(csv.reader([value])) if value else []
