"""Independent verification of new EU odds, dates, official results and all exports."""
import collections,csv,datetime as dt,json,math,sqlite3
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT
from core import utc
from epl_price_points import Sources,pointer,load
from eu_official_games import CONFIG,games
from eu_verified_details import details
from eu_schema import EU_PRE_COLUMNS,EU_INGAME_COLUMNS
from schema import HOURS,aligned

def main():
 db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;db.execute('BEGIN');src=Sources(db);cs={(r[0],r[1]):json.loads(r[2]) for r in db.execute('SELECT provider,contract_id,body FROM _eu_validated_contracts')};sources=['_eu_price_acquisition']
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_polymarket_asof'").fetchone():sources.append('_eu_polymarket_asof')
 points,conflicts,_=load(db,cs,src,sources);assert not conflicts;official={code:games(db,code) for code in CONFIG};byname={v[0]:k for k,v in CONFIG.items()};ds=details(db);checks=collections.Counter();missing={};ages=collections.defaultdict(list);audits={};examples=[];provider_game_counts={};checkpoint_missing={}
 for r in db.execute('SELECT body FROM _eu_odds_selections'):
  a=json.loads(r[0])
  if not a['selected_family']:continue
  key=a['provider'],a['game_id'],a['side'],a['target'];assert key not in audits;audits[key]=a
 def verify(p,gid,side,target,value,start,lo,hi=None):
  a=audits[p,gid,side,target];c=cs[p,a['contract_id']];assert c['game_id']==gid and c['side']==side;assert a['price']==value and utc(a['target_timestamp_utc']).timestamp()==lo;assert (utc(a['window_end_utc']).timestamp() if a['window_end_utc'] else None)==hi;opened=utc(c['open']).timestamp();eligible=[]
  for x in points[p,c['contract_id']]:
   ts=x['timestamp'];end=ts+(x['resolution_seconds'] if x['kind']=='v2' else 0)
   if ts<opened:continue
   if (ts<start and end<=lo) if hi is None else (lo<=ts<hi and end<=hi):eligible.append((end,x))
  if value is None:assert not eligible;checks['verified_missing_values']+=1;return
  assert 0<=value<=1 and math.isfinite(value);x=a['source'];raw,r=src.get(x['request_id']);assert float(pointer(raw,x['pointer']))==value;assert r['endpoint']==a['request_endpoint'] and r['parameters']==a['request_parameters'];available=x['timestamp']+(x['resolution_seconds'] if x['kind']=='v2' else 0);assert eligible
  if hi is None:assert available==max(t for t,_ in eligible);checks['latest_previous_quote']+=1;ages[p,target].append((lo-x['timestamp'])/3600)
  else:assert available==min(t for t,_ in eligible);checks['first_inside_break_window']+=1
  checks['exact_source_value_and_mapping']+=1
 for provider in ['polymarket','kalshi']:
  for kind,columns in [('pre_match',EU_PRE_COLUMNS),('in_game',EU_INGAME_COLUMNS)]:
   table='_source_'+provider+'_soccer_'+kind;allrows=[dict(r) for r in db.execute('SELECT * FROM '+table+' ORDER BY game_id')];assert [r[1] for r in db.execute('PRAGMA table_info('+table+')')]==columns;path=ROOT/'data/result/eu_soccer'/provider/kind
   for ext in ['csv','parquet']:
    if ext=='csv':
     with path.with_suffix('.csv').open(encoding='utf-8-sig',newline='') as f:reader=csv.DictReader(f);assert reader.fieldnames==columns;other=list(reader)
     for r in other:
      for c,v in r.items():r[c]=None if v=='' else float(v) if '_pre_' in c else int(v) if c in ['teamA_final_score','teamB_final_score'] else v
    else:t=pq.read_table(path.with_suffix('.parquet'));assert t.column_names==columns;other=t.to_pylist()
    other.sort(key=lambda r:r['game_id']);assert len(allrows)==len(other)
    for expected,actual in zip(allrows,other):
     for c in columns:
      x,y=expected[c],actual[c];assert math.isclose(x,y,rel_tol=1e-14,abs_tol=1e-14) if isinstance(x,(int,float)) and isinstance(y,(int,float)) else x==y,(table,ext,expected['game_id'],c)
    checks['all_provider_export_values_equal_SQL']+=1
   rows=[r for r in allrows if r['competition']!='Premier League'];missing[table]={c:dict(count=sum(r[c] is None for r in rows),total=len(rows),percentage=round(sum(r[c] is None for r in rows)*100/len(rows),4) if rows else None) for c in columns}
   for row in rows:
    f=json.loads(db.execute('SELECT body FROM _eu_game_facts WHERE game_id=?',(row['game_id'],)).fetchone()[0]);code=byname[row['competition']];g=official[code][f['official_match_id']];d=ds[code,g['official_match_id']];clock=d['clock'];stamp=clock['actual_start_utc'] or g['scheduled_start_utc'];start=utc(stamp).timestamp();names=[g[s]['name'] for s in ['away','home']];assert row['match']=='/'.join(names) and row['league']=='EU soccer' and row['season']==g['season'] and row['game_id']==g['game_id'];checks['official_identity']+=1
    if kind=='pre_match':
     venue=db.execute('SELECT body FROM _eu_venue_reviews WHERE competition=? AND match_id=?',(code,g['official_match_id'])).fetchone();assert row['home_away']==(json.loads(venue[0])['home_away'] if venue else 'Away;Home')
     assert row['date']==g['date'] and row['timestamp']==stamp and [row['teamA_final_score'],row['teamB_final_score']]==g['scores'];winner='Draw' if g['scores'][0]==g['scores'][1] else names[int(g['scores'][1]>g['scores'][0])];assert row['final']==winner;assert row['location']==(d.get('location') or g.get('location'));checks['official_final_result']+=1
     for side,name in enumerate(['teamA','teamB','draw']):
      for h in HOURS:
       p=row[f'{name}_pre_{h}_p'];odd=row[f'{name}_pre_{h}_odd'];assert odd is None if p is None or p==0 else math.isclose(odd,1/p,rel_tol=1e-14);verify(provider,g['game_id'],side,'pre_'+str(h),p,start,start-h*3600)
     if sum(x['provider']==provider and x['competition']==row['competition'] for x in examples)<3:examples.append(dict(provider=provider,competition=row['competition'],match=row['match'],date=row['date'],start=row['timestamp'],game_id=row['game_id'],score=g['scores'],winner=winner,pre_0={n:dict(probability=row[n+'_pre_0_p'],decimal_odds=row[n+'_pre_0_odd'],source=audits[provider,g['game_id'],side,'pre_0']['source']) for side,n in enumerate(['teamA','teamB','draw'])}))
    else:
     assert row['checkpoint']=='START;HALFTIME;SECOND_HALF_START';half=d.get('halftime_scores') or [None,None];assert row['teamA_score']==aligned([0,half[0],half[0]]) and row['teamB_score']==aligned([0,half[1],half[1]]);st=utc(clock['actual_start_utc']);hs=utc(clock['halftime_start_utc']);rs=utc(clock['second_half_start_utc']);windows=[(st.timestamp(),st.timestamp()+120) if st else (None,None),(hs.timestamp(),rs.timestamp()) if hs and rs else (None,None),(rs.timestamp(),rs.timestamp()+120) if rs else (None,None)];assert row['timestamp']==aligned([utc(lo).isoformat() if lo is not None else None for lo,hi in windows])
     for side,name in enumerate(['teamA','teamB','draw']):
      ps=[None if v=='null' else float(v) for v in row[name+'_ingame_p'].split(';')];odds=[None if v=='null' else float(v) for v in row[name+'_ingame_odd'].split(';')];assert len(ps)==len(odds)==3
      for n,(p,odd) in enumerate(zip(ps,odds)):
       assert odd is None if p is None or p==0 else math.isclose(odd,1/p,rel_tol=1e-12);lo,hi=windows[n]
       if lo is not None and hi is not None:verify(provider,g['game_id'],side,'ingame_'+str(n),p,start,lo,hi)
       else:assert p is None
   if kind=='pre_match':
    provider_game_counts[provider]=len(rows)
    for (date,comp),count in collections.Counter((r['date'],r['competition']) for r in rows).items():assert db.execute('SELECT count(*) FROM main WHERE date=? AND competition=? AND provider=?',(date,comp,provider)).fetchone()[0]==count;checks['SQL_date_competition_provider_filter']+=1
   else:
    total=provider_game_counts[provider];fields={}
    for side in ['teamA','teamB','draw']:
     for n,label in enumerate(['START','HALFTIME','SECOND_HALF_START']):
      count=total-sum(r[side+'_ingame_p'].split(';')[n]!='null' for r in rows);fields[side+':'+label]=dict(count=count,total=total,percentage=round(count*100/total,4) if total else None)
    checkpoint_missing[provider]=dict(games_with_any_checkpoint=len(rows),total_games=total,fields=fields)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Published non-EPL EU odds and complete provider CSV/Parquet equality; missing features are counted, not a completeness claim',checks=dict(checks),source_hashes=len(src.cache),source_conflicts=conflicts,missing=missing,checkpoint_missing=checkpoint_missing,quote_age_hours={p+':'+t:dict(observations=len(xs),median=sorted(xs)[len(xs)//2],maximum=max(xs)) for (p,t),xs in ages.items()},examples=examples);(ROOT/'reports/eu_odds_outputs_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['missing','quote_age_hours','examples','checkpoint_missing']}),flush=True);db.close()

if __name__=='__main__':main()
