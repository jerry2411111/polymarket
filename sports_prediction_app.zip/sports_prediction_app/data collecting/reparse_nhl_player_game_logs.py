"""Repair only completed parsing failures from intact original API responses."""
import datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

db=sqlite3.connect(DB,timeout=60);fixed=[];errors=[]
for key,b in db.execute("SELECT * FROM _official_nhl_player_game_logs WHERE json_extract(body,'$.status')='error'").fetchall():
    old=json.loads(b)
    if old.get('error') not in ["KeyError: 'gameId'",'AssertionError: Expected dated gameLog array']:errors.append(old);continue
    r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(old['request_id'],)).fetchone()[0]);raw=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];d=json.loads(raw);games=d.get('gameLog')
    assert d['seasonId']==old['season'] and d['gameTypeId']==old['game_type_code']
    if games is None:
        row=dict(old,status='unavailable',games=None,reason='Official API returned season metadata but omitted gameLog; absence is not zero games');db.execute('UPDATE _official_nhl_player_game_logs SET body=? WHERE job_key=?',(json.dumps(row),key));db.commit();errors.append(row);continue
    assert isinstance(games,list)
    assert len({g['id'] for g in games})==len(games)
    assert all(dt.date.fromisoformat(g['gameDate']) and str(g['id'])[:4]==str(old['season'])[:4] and g['homeRoadFlag'] in ['H','R'] and g.get('homeTeam',{}).get('id') and g.get('awayTeam',{}).get('id') for g in games)
    row=dict(old,status='ok',games=games,parser_repair=dict(previous_error=old['error'],correct_native_id_key='id',original_request_id=old['request_id'],reparsed_at_utc=dt.datetime.now(dt.UTC).isoformat()),meaning='Dated career affiliation evidence only; not imported into sample performance')
    row.pop('error');db.execute('UPDATE _official_nhl_player_game_logs SET body=? WHERE job_key=?',(json.dumps(row),key));db.commit();fixed.append(key)
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),reparsed_records=len(fixed),new_requests=0,other_errors=errors,remaining_errors=db.execute("SELECT count(*) FROM _official_nhl_player_game_logs WHERE json_extract(body,'$.status')='error'").fetchone()[0]);(ROOT/'reports/nhl_game_log_parser_repair.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
