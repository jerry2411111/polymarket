"""Refresh manifests and the shared weather export from already validated SQL values."""
import csv,datetime as dt,json,sqlite3
import pyarrow as pa
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT
from export_mlb_support_tables import TABLES

def main():
    now=dt.datetime.now(dt.UTC).isoformat();db=sqlite3.connect(DB)
    for league in ['mlb','nhl']:
        outputs=[json.loads(p.read_text()) for name in TABLES if (p:=ROOT/'reports'/(league+'_'+name+'_export.json')).exists()]
        (ROOT/'reports'/(league+'_support_exports.json')).write_text(json.dumps(dict(generated_at_utc=now,outputs=outputs),indent=2),encoding='utf-8');print('MANIFEST',league,len(outputs))
    assert json.loads((ROOT/'reports/weather_tables_validation.json').read_text())['status']=='WORKING';cur=db.execute('SELECT * FROM weather ORDER BY date,city');cols=[c[0] for c in cur.description];rows=cur.fetchall();schema=pa.schema([(c,pa.float64() if c in {'humidity_pct','temperature_c'} else pa.string()) for c in cols]);dest=ROOT/'data/result'
    with (dest/'weather.csv').open('w',newline='',encoding='utf-8') as f:w=csv.writer(f);w.writerow(cols);w.writerows(rows)
    pq.write_table(pa.Table.from_pylist([dict(zip(cols,r)) for r in rows],schema=schema),dest/'weather.parquet',compression='zstd');assert [tuple(r[c] for c in cols) for r in pq.read_table(dest/'weather.parquet').to_pylist()]==rows
    with (dest/'weather.csv').open(newline='',encoding='utf-8') as f:r=csv.reader(f);assert next(r)==cols;assert list(r)==[['' if v is None else str(v) for v in row] for row in rows]
    report=dict(generated_at_utc=now,status='WORKING',rows=len(rows),columns=cols,csv='data/result/weather.csv',parquet='data/result/weather.parquet',validation='Every exported CSV and Parquet value compared with SQL; source verification in weather_tables_validation.json')
    (ROOT/'reports/weather_export.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
    db.close()

if __name__=='__main__':main()
