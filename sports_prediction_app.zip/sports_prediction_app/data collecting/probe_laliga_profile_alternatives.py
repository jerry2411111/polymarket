"""Test official PL person records for explicitly retained numeric player asset IDs."""
import datetime as dt,json,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from collect_laliga_people import namekey
from probe_history import ROOT,HOSTS
BASE='https://sdp-prem-prod.premier-league-prod.pulselive.com/api';HOSTS.add('sdp-prem-prod.premier-league-prod.pulselive.com');db=sqlite3.connect(DB,timeout=60);wanted=[json.loads(b) for b, in db.execute("SELECT body FROM _official_laliga_native_profile_revisions WHERE json_extract(body,'$.status')<>'ok'")];c=HistoryClient();rows=[]
for old in wanted:
 pid=old['source_person_id'];native=pid.split(':p')[1];row=dict(source_person_id=pid,requested_native_id=native)
 try:
  data,r=c.get(BASE+'/v1/players/'+native);assert isinstance(data,list) and data and all(str(v['id']['playerId'])==native for v in data);names={namekey(n) for n in old['source_names']};matched=[v for v in data if namekey(v['name']['display']) in names];assert matched,'Returned official person name differs';row.update(status='ok',request_id=r['request_id'],data=data,identity_basis='Same numeric ID in official LaLiga player asset and official PL person response, with exact official displayed name; no current affiliation used');print('OFFICIAL ALTERNATIVE',pid,'MATCHED',[(v['id'].get('seasonId'),v.get('dates',{}).get('birth')) for v in matched[:3]],flush=True)
 except Exception as e:row.update(status='unavailable',error=type(e).__name__+': '+str(e));print('OFFICIAL ALTERNATIVE',pid,'unavailable',flush=True)
 rows.append(row)
with db:
 db.execute('CREATE TABLE IF NOT EXISTS _eu_person_alternative_biographies (source_person_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_person_alternative_biographies VALUES (?,?)',[(r['source_person_id'],json.dumps(r)) for r in rows])
(ROOT/'reports/laliga_alternative_biographies.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),requested=len(rows),matched=sum(r['status']=='ok' for r in rows),new_requests=c.requests,results=[{k:v for k,v in r.items() if k!='data'} for r in rows]),indent=2),encoding='utf-8');db.close()
