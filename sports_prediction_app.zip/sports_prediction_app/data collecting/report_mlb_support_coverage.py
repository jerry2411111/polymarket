"""Report every final MLB supporting field's measured missing count/percentage."""
import collections, csv, datetime as dt, json, sqlite3
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT
MEANINGS = {'player_profiles': 'One historically observed person at one date; includes roster-only people. Performance uses only collected appearances through that date.', 'player_current_team': 'One person/date and the last documented MLB affiliation. Not proof of an active 26-man roster slot.', 'player_performance': 'One person/date after at least one played appearance; cumulative sample performance and separate dated publisher flags.', 'manager_profiles': 'One known manager/date, current recorded team, documented history and tenure. Former managers can have a null current team.', 'manager_performance': 'Cumulative performance through the date, from games credited to this manager in the collected sample.', 'team_history': 'Cumulative collected team results, including average signed score margin; official results only.', 'player_rankings_quarterly': 'One person/publisher/quarterly research cutoff; actual eligible published edition retained with its date.', 'weather': 'One linked game city/date, using the latest qualifying official station observation before the earliest linked game.'}

def main():
    db = sqlite3.connect(DB, timeout=60)
    tables = []
    for path in sorted((ROOT / 'data/result/mlb').glob('*.parquet')):
        pf = pq.ParquetFile(path)
        counts = collections.Counter()
        n = 0
        for batch in pf.iter_batches(batch_size=20000):
            n += batch.num_rows
            for c, v in zip(batch.schema.names, batch.columns):
                counts[c] += v.null_count
        assert n == pf.metadata.num_rows
        tables.append(dict(name=path.stem, rows=n, columns=len(pf.schema_arrow.names), meaning=MEANINGS.get(path.stem, 'Published nonfinancial research fields.'), parquet=path.relative_to(ROOT).as_posix(), fields=[dict(column=c, type=str(pf.schema_arrow.field(c).type), missing=counts[c], total=n, missing_pct=round(counts[c] * 100 / n, 4) if n else None) for c in pf.schema_arrow.names]))
    selected = db.execute("SELECT count(*) FROM (SELECT game_id FROM polymarket_pre_match WHERE league='MLB' UNION SELECT game_id FROM kalshi_pre_match WHERE league='MLB')").fetchone()[0]
    out = dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(), status='PARTIALLY WORKING', collection_start='2024-01-01', collection_end='2026-09-14', unique_games_with_odds=selected, tables=tables, limitations=['Official calendar availability is broader than quote availability. Published MLB odds start October 2024 for Polymarket and April 2025 for Kalshi.', 'Individual baseball playing minutes are not supplied. Missing batting statistics for pitchers are not replaced with zero.', 'Career-wide seasons played and fully verified career team counts remain unknown. Served-team history lists documented native franchises, not a claimed complete career.', 'No injury report defaults to not injured as instructed. A positive report is not proof of a new lifetime injury episode, so complete episode counts are unavailable.', 'Pre-game profile links use only information known by t-1. 27 selected games lack a usable previously observed roster.', '36 of 9930 manager/team-game attributions remain unavailable for games completed across multiple dates.', 'Five independent media publishers are verified for MLB; the requested ten has not been reached. Unlisted player rankings remain unknown.', 'Kalshi in-game collection is ongoing. Missing final-export quote percentages will change after the next validated rebuild.', 'The original Desktop project still provides required dependencies and has not been deleted.'])
    for name in ['mlb_temporal_validation', 'mlb_rankings_validation', 'mlb_outputs_validation']:
        out[name] = json.loads((ROOT / 'reports' / (name + '.json')).read_text())
    (ROOT / 'reports/mlb_support_coverage.json').write_text(json.dumps(out, indent=2), encoding='utf-8')
    with (ROOT / 'reports/mlb_support_missing_fields.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['table', 'column', 'type', 'missing', 'total', 'missing_pct'])
        w.writeheader()
        for t in tables:
            for c in t['fields']:
                w.writerow(dict(table=t['name'], **c))
    lines = ['# MLB supporting tables: actual coverage', '', f'{selected:,} unique games with some provider odds. Requested window: 2024-01-01 through 2026-09-14. Status: **PARTIALLY WORKING**.', '', '| Table | Rows | Columns | Meaning |', '|---|---:|---:|---|']
    lines += [f"| {t['name']} | {t['rows']:,} | {t['columns']} | {t['meaning']} |" for t in tables]
    lines += ['', '', '## Remaining gaps', ''] + ['- ' + s for s in out['limitations']]
    lines += ['', '## Missing fields', '', '| Table | Column | Missing / total | Missing % |', '|---|---|---:|---:|']
    for t in tables:
        for c in t['fields']:
            if c['missing']:
                lines.append(f"| {t['name']} | {c['column']} | {c['missing']:,} / {c['total']:,} | {c['missing_pct']} |")
    (ROOT / 'reports/mlb_support_coverage.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps(dict(status=out['status'], games=selected, tables=[{k: t[k] for k in ['name', 'rows', 'columns']} for t in tables])))
    db.close()
if __name__ == '__main__':
    main()
