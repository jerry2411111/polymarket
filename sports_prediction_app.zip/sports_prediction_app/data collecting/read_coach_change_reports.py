import sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for url,text in db.execute("SELECT source_url,text FROM _nba_coach_document_pages WHERE page_number=1 AND (source_url LIKE '%2026-coaching-tracker' OR source_url LIKE '%hire-tiago%' OR source_url LIKE '%hire-micah%' OR source_url LIKE '%name-taylor%' OR source_url LIKE '%hire-sean%' OR source_url LIKE '%hire-dusty%' OR source_url LIKE '%hire-jamahl%' OR source_url LIKE '%part-ways-jason%')"):
    print(url,text[:2200])
db.close()
