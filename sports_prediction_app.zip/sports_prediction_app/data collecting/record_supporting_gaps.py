"""Record remaining gaps with explicit denominators and source-audit checks.

No acquisition or imputation occurs here. Dated-profile missing percentages,
played-game statistic gaps and unobserved rankings describe different populations.
"""
import collections
import csv
import datetime as dt
import json
import pathlib
import sqlite3
import uuid

from build_history_catalog import DB
from probe_history import ROOT


def output_csv(name, rows):
    if not rows:
        return
    with (ROOT / 'reports' / name).open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def metrics(db, table, fields, scope, params, denominator, audit_date):
    expr = ','.join('SUM("' + name + '" IS NULL OR "' + name + '"=\'\')' for name in fields)
    rows = db.execute('SELECT league,COUNT(*),' + expr + ' FROM ' + table + scope + ' GROUP BY league', params)
    result = []
    for league, total, *counts in rows:
        for field, missing in zip(fields, counts):
            result.append(dict(dataset=table, league=league, as_of_date=audit_date, column_name=field,
                denominator=denominator, expected=total, missing=missing, missing_pct=round(100*missing/total,4)))
    return result


def in_game(db):
    main = collections.defaultdict(list)
    for r in db.execute('SELECT provider,league,game_id FROM main'):
        main[r[0],r[1]].append(r[2])
    rows = {(r['provider'],r['game_id']):dict(r) for r in db.execute('SELECT * FROM in_game')}
    labels = {'NBA':['Start','Q1','Halftime','Q4'], 'MLB':['Start','Inning3','Inning5','Inning7'],
        'NHL':['Start','P1','P2'], 'EU soccer':['START','HALFTIME','SECOND_HALF_START']}
    from league_odds import SOCCER_LEAGUES
    labels.update({league:labels['EU soccer'] for league in SOCCER_LEAGUES})
    absent = lambda value: value is None or str(value).strip().lower() in ('','null','none','nan')
    summary = []
    for (provider,league), ids in sorted(main.items()):
        sides = ['teamA','teamB','draw'] if league in SOCCER_LEAGUES else ['teamA','teamB']
        for ordinal,label in enumerate(labels[league]):
            out = collections.Counter()
            for gid in ids:
                row=rows.get((provider,gid))
                values=[None]*len(sides)
                if row:
                    actual=row['checkpoint'].split(';')
                    assert len(actual)==len(labels[league]),(gid,actual)
                    values=[row[side+'_ingame_p'].split(';')[ordinal] for side in sides]
                    if absent(row['timestamp'].split(';')[ordinal]):out['games_missing_checkpoint_timestamp']+=1
                    for side in ['teamA','teamB']:
                        out['missing_score_values_in_published_rows']+=absent(row[side+'_score'].split(';')[ordinal])
                else:
                    out['games_without_in_game_row']+=1
                missing=sum(absent(value) for value in values)
                out['missing_probability_values']+=missing
                out['games_all_outcomes_missing']+=missing==len(sides)
                out['games_some_outcomes_missing']+=0<missing<len(sides)
                out['games_all_outcomes_available']+=missing==0
            total=len(ids)*len(sides)
            published=len(ids)-out['games_without_in_game_row']
            summary.append(dict(provider=provider,league=league,checkpoint=label,main_games=len(ids),
                expected_probability_values=total,missing_probability_values=out['missing_probability_values'],
                missing_probability_pct=round(out['missing_probability_values']*100/total,4),
                games_all_outcomes_available=out['games_all_outcomes_available'],
                games_some_outcomes_missing=out['games_some_outcomes_missing'],
                games_all_outcomes_missing=out['games_all_outcomes_missing'],
                games_without_in_game_row=out['games_without_in_game_row'],
                published_in_game_rows=published,missing_score_values_in_published_rows=out['missing_score_values_in_published_rows'],
                expected_score_values_in_published_rows=published*2,
                missing_score_pct_in_published_rows=round(out['missing_score_values_in_published_rows']*100/(published*2),4) if published else None,
                games_missing_checkpoint_timestamp_in_published_rows=out['games_missing_checkpoint_timestamp']))
    return summary


def weather_check(db):
    fields=['humidity_pct','weather_type','temperature_c','wind_direction']
    public={(r['city'],r['date']):dict(r) for r in db.execute('SELECT * FROM weather')}
    seen=set();errors=[];reasons=collections.Counter();audit_rows=[]
    for r in db.execute('SELECT body FROM _weather_observation_audit'):
        a=json.loads(r[0]);key=a['city'],a['date']
        if key in seen:errors.append(dict(city=key[0],date=key[1],problem='Duplicate weather audit'))
        seen.add(key);p=public.get(key)
        if p is None:errors.append(dict(city=key[0],date=key[1],problem='Weather audit without public row'));continue
        expected=a.get('normalized',{})
        for field in fields:
            if p[field]!=expected.get(field):errors.append(dict(city=key[0],date=key[1],field=field,problem='Weather differs from retained normalized source observation',public=p[field],audit=expected.get(field)))
            if p[field] is None:
                reason=a.get('reason') or 'Selected source observation has no usable normalized field after source quality rules'
                reasons[field,reason]+=1
                audit_rows.append(dict(city=key[0],date=key[1],field=field,reason=reason,
                    provider=a.get('provider','NOAA/NCEI'),source_request_id=a.get('request_id'),station_id=a.get('station_id')))
    for city,date in set(public)-seen:errors.append(dict(city=city,date=date,problem='Public weather row lacks source observation audit'))
    return dict(weather_rows=len(public),source_audit_rows=len(seen),source_value_comparisons=len(public)*len(fields),
        errors=errors,missing_reasons=[dict(field=key[0],reason=key[1],missing=count) for key,count in sorted(reasons.items())]),audit_rows


def main():
    db=sqlite3.connect(pathlib.Path(DB).resolve().as_uri()+'?mode=ro',uri=True,timeout=60)
    db.row_factory=sqlite3.Row
    start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    report=dict(audit_id=uuid.uuid4().hex,generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),
        collection_start=start,as_of_date=end,status='RUNNING',collection_status='PARTIALLY WORKING')
    print('SUPPORT GAPS: checking played-game source statistics',flush=True)
    report['played_game_statistics']=metrics(db,'_player_game_results',['score','assists','minutes','starter'],
        ' WHERE game_date>=? AND game_date<=?',(start,end),'Actual collected played player/game appearances',end)
    for row in report['played_game_statistics']:
        row['source_statistic'] = ({'NBA':'Points','MLB':'Batting runs scored; an absent batting statistic is not replaced by pitching runs allowed or zero','NHL':'Goals','EU soccer':'Goals'}[row['league']]
            if row['column_name']=='score' else 'Fielding assists' if row['column_name']=='assists' and row['league']=='MLB'
            else 'Official scoring assists' if row['column_name']=='assists' else 'Actual individual playing minutes' if row['column_name']=='minutes'
            else 'Official starter designation')
    print('SUPPORT GAPS: checking current dated player and coach fields',flush=True)
    report['current_profiles']=metrics(db,'player_profiles',['age','weight_kg','height_cm','years_played',
        'served_team_history','months_serving_current_team','overall_winrate',
        'average_score_per_game','average_assists_per_game','average_minutes_per_game','std_score_per_game',
        'std_assists_per_game','std_minutes_per_game','participation_rate_current_team','participation_rate_overall',
        'starter_percentage_current_team','starter_percentage_overall','injured_times_till_as_of_date',
        'currently_injured_till_as_of_date'],' WHERE as_of_date=?',(end,),'Player profile rows on the specified as-of date',end)
    report['current_profiles']+=metrics(db,'manager_profiles',['number_of_teams_served','served_team_history',
        'overall_winrate'],' WHERE as_of_date=?',(end,),
        'Head coach/manager profile rows on the specified as-of date',end)
    print('SUPPORT GAPS: checking every in-game checkpoint, including omitted games',flush=True)
    report['in_game_checkpoints']=in_game(db)
    print('SUPPORT GAPS: reconciling all weather values and absences with source audit',flush=True)
    report['weather_source_check'],weather_rows=weather_check(db)
    report['ranking_policy']='Latest eligible publisher edition on or before each query date; carry forward until superseded. Public quarterly ranking tables removed.'
    report['ranking_edition_selections']=[dict(league=r[0],publisher_key=r[1],selected_change_dates=r[2]) for r in db.execute('SELECT league,publisher_key,COUNT(*) FROM _ranking_asof_selection GROUP BY league,publisher_key')]
    report['status']='SCHEMA PROBLEM' if report['weather_source_check']['errors'] else 'WORKING'
    report['limitations']=[
        'This checks the acquired dataset and retained source audit; it is not a new source search or proof that unavailable fields cannot be obtained elsewhere.',
        'The in-game probability denominator includes all main games, including omitted in-game rows. Nonexistent breaks in short-format games are included as absent slots under the fixed schema and are not asserted to be provider failures.',
        'Missing published break scores are measured only among retained in-game rows; an omitted odds row does not establish that an official score is unavailable.',
        'Current profiles and historical daily profiles have different denominators. Before a first collected appearance, performance is encoded as zero meaning no observations. After appearances exist, sample SD requires two valid observations of that statistic.',
        'No-report injury=false/zero follows the user convention and is not evidence of verified health or complete injury surveillance.',
        'Raw ordinal ranks preserve their coverage states. Public top-N flags mark acquired membership true and the other same-league players false once dated publisher evidence exists, by user convention.',
    ]
    db.close()
    output_csv('support_missing_current_profiles.csv',report['current_profiles'])
    output_csv('support_missing_played_game_statistics.csv',report['played_game_statistics'])
    output_csv('in_game_checkpoint_coverage_all_games.csv',report['in_game_checkpoints'])
    output_csv('weather_missing_source_reasons.csv',weather_rows)
    output_csv('ranking_edition_selections.csv',report['ranking_edition_selections'])
    dest=ROOT/'reports/supporting_missing_verification.json'
    dest.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    writable=sqlite3.connect(DB,timeout=60)
    with writable:
        writable.execute('CREATE TABLE IF NOT EXISTS _support_missing_audit_runs(audit_id TEXT PRIMARY KEY,generated_at_utc TEXT NOT NULL,as_of_date TEXT NOT NULL,status TEXT NOT NULL,body TEXT NOT NULL) STRICT')
        writable.execute('INSERT INTO _support_missing_audit_runs VALUES(?,?,?,?,?)',(report['audit_id'],report['generated_at_utc'],end,report['status'],json.dumps(report,ensure_ascii=False)))
        writable.execute('''CREATE VIEW IF NOT EXISTS support_missing_latest AS SELECT r.audit_id,r.as_of_date,
            json_extract(j.value,'$.dataset') AS dataset,json_extract(j.value,'$.league') AS league,
            json_extract(j.value,'$.column_name') AS column_name,json_extract(j.value,'$.denominator') AS denominator,
            json_extract(j.value,'$.expected') AS expected,json_extract(j.value,'$.missing') AS missing,
            json_extract(j.value,'$.missing_pct') AS missing_pct
            FROM _support_missing_audit_runs r,json_each(r.body,'$.current_profiles') j
            WHERE r.audit_id=(SELECT audit_id FROM _support_missing_audit_runs ORDER BY generated_at_utc DESC,audit_id DESC LIMIT 1)''')
    writable.close()
    lines=['# Supporting-table missing data', '',
        'Current profile date: '+end+'. Source statistics use collected completed appearances from '+start+' through '+end+'.', '',
        '## Played-game statistics', '', '| League | Statistic | Source meaning | Missing / appearances | Missing % |', '|---|---|---|---:|---:|']
    for row in report['played_game_statistics']:
        lines.append(f"| {row['league']} | {row['column_name']} | {row['source_statistic']} | {row['missing']} / {row['expected']} | {row['missing_pct']} |")
    lines+=['','## Detailed records','','- [Current player and coach profiles](support_missing_current_profiles.csv)',
        '- [All main games: missing in-game probabilities at each checkpoint](in_game_checkpoint_coverage_all_games.csv)',
        '- [Weather missing fields and source-audit reasons](weather_missing_source_reasons.csv)',
        '- [Latest eligible publisher editions](ranking_edition_selections.csv)',
        '- [Every historical dataset column](all_columns_missing.csv)', '',
        f"Weather: {report['weather_source_check']['source_value_comparisons']} field values/absences checked against retained source-observation audit; {len(report['weather_source_check']['errors'])} discrepancies.", '',
        '## Interpretation', '']+['- '+note for note in report['limitations']]
    lines+=['','```sql','SELECT * FROM support_missing_latest WHERE missing > 0 ORDER BY league,dataset,column_name;','```','']
    (ROOT/'reports/supporting_missing_verification.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps(dict(status=report['status'],played_stat_groups=len(report['played_game_statistics']),
        current_profile_field_groups=len(report['current_profiles']),checkpoint_groups=len(report['in_game_checkpoints']),
        weather=report['weather_source_check']),indent=2),flush=True)
    return int(report['status']!='WORKING')


if __name__=='__main__':
    raise SystemExit(main())
