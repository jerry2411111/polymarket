"""NOAA station observations at or immediately before the game's start (at most 90 minutes old)."""
import io,json,math,re
from pypdf import PdfReader
import pyarrow.parquet as pq
from core import utc,num,iso

STATIONS={'Sunrise':'USW00012849','Edmonton':'CAN03012216','Chicago':'USW00014819',
          'Cleveland':'USW00014820','West Sacramento':'USW00023232','San Antonio':'USW00012921','New York':'USW00094728'}
def quality(row,key):
    q=str(row.get(key+'_Quality_Code') or '')
    # NOAA sky-cover documentation: the first quality component belongs to
    # total coverage; a second component belongs to lowest-cloud coverage.
    if key=='sky_condition':q=q.split(';')[0]
    source=str(row.get(key+'_Source_Code') or '')
    if any(ch.islower() for ch in q):return False
    if source in {'220','221','222','223','347','348','413'}:return q in {'','0','1','4'}
    if source=='345':return q in {'','0'}
    return q in {'','0','1','4','5','9','A','U','P','I','M','R'}
def value(r,k):
    if not quality(r,k):return None
    v=r.get(k)
    if v is None or v=='' or str(v) in {'999','9999','-9999'}:return None
    return num(v)
def weather_codes(store):
    """Read the official codebook already retained as an original response."""
    rr=next(x for x in store.records if x['status']==200 and x['endpoint'].endswith('/ghcnh-present-weather-elements.pdf'))
    text=' '.join(re.sub(r'\s+',' ',p.extract_text()) for p in PdfReader(io.BytesIO((store.root/rr['raw_file']).read_bytes())).pages)
    maps={}
    for group,start,end in [('MW','Table 5(a)','Table 5(b)'),('AW','Table 5(b)','Table 5(c)')]:
        section=text[text.index(start):text.index(end)]
        matches=list(re.finditer(r'(?<!\S)(?:[A-Z+]+:)?(\d{2})-(?=[A-Za-z])',section))
        for i,m in enumerate(matches):
            desc=section[m.end():matches[i+1].start() if i+1<len(matches) else len(section)].strip()
            maps[group,m[1]]=re.sub(r'\s+',' ',desc.replace('-',' ')).strip()
    return maps

def weather_type(r,codes=None):
    labels=[]
    for group in ['AW','MW','AU']:
        for n in [1,2,3]:
            k=f'pres_wx_{group}{n}'
            if not quality(r,k):continue
            v=r.get(k)
            if v is None:continue
            raw=str(v).strip()
            if not raw or raw in {'999','9999','-9999'}:continue
            token=raw.split(';')[0].split(':')[-1]
            # There is no restricted weather-label vocabulary. Retain an
            # undecoded source code rather than silently throwing it away.
            key=f'{int(token):02d}' if token.isdigit() else token
            labels.append((codes or {}).get((group,key),f'{group} weather code: {raw}'))
    # Cloud coverage is separate from precipitation; absence of a weather code never means sunny.
    cloud=r.get('sky_condition')
    if cloud and quality(r,'sky_condition'):
        code=str(cloud).split(';')[0]
        if code=='00':labels.append('Clear')
        elif code in {'01','02','03','04','05','11','12','13'}:labels.append('Partly cloudy')
        elif code in {'06','07','08','14','15','16','17','18','19'}:labels.append('Cloudy')
        elif code=='09':labels.append('Sky obscured')
        elif code=='10':labels.append('Partial obscuration')
        elif code:labels.append('Sky condition code: '+str(cloud))
    if not cloud or not quality(r,'sky_condition') or not str(cloud).split(';')[0]:
        for i in [4,3,2,1]:
            key=f'sky_cover_summation_{i}';v=r.get(key)
            if not v or not quality(r,key):continue
            code=str(v).split(';')[0].split(':')[0]
            if not code and ';' in str(v):code=str(v).split(';')[1]
            if code in {'CLR','SKC','00'}:labels.append('Clear')
            elif code in {'FEW','SCT','01','02','03','04','05','11','12','13'}:labels.append('Partly cloudy')
            elif code in {'BKN','OVC','06','07','08','14','15','16','17','18','19'}:labels.append('Cloudy')
            elif code=='VV':labels.append('Sky obscured')
            elif code=='X':labels.append('Partial obscuration')
            else:labels.append('Sky cover code: '+str(v))
            break
    return ';'.join(dict.fromkeys(labels)) or None
def build_weather(store,gs):
    rows=[];proof=[];loaded={};codes=weather_codes(store)
    for g in gs:
        station=STATIONS[g['city']];year=g['date'][:4]
        url=f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/parquet/GHCNh_{station}_{year}.parquet'
        if url not in loaded:
            rec=next((r for r in reversed(store.records) if r['endpoint']==url and r['status']==200),None)
            keys=['STATION','DATE','temperature','relative_humidity','wind_direction','wind_speed','sky_condition']+[f'pres_wx_{grp}{n}' for grp in ['AW','MW','AU'] for n in [1,2,3]]+[f'sky_cover_{grp}_{n}' for grp in ['layer','summation'] for n in [1,2,3,4]]
            cols=['STATION','DATE']+[k+suffix for k in keys[2:] for suffix in ['','_Quality_Code','_Source_Code','_Measurement_Code']]
            loaded[url]=(pq.read_table(io.BytesIO((store.root/rec['raw_file']).read_bytes()),columns=cols).to_pylist(),rec) if rec else ([],None)
        data,r=loaded[url];hits=[(i,x,utc(x['DATE']+'Z')) for i,x in enumerate(data) if 0<=(g['anchor']-utc(x['DATE']+'Z')).total_seconds()<=5400]
        # Subhourly precipitation-only reports do not replace the latest full meteorological report.
        hits=[x for x in hits if value(x[1],'temperature') is not None or value(x[1],'relative_humidity') is not None]
        selected=max(hits,key=lambda x:(x[2],value(x[1],'temperature') is not None,value(x[1],'relative_humidity') is not None)) if hits else None
        row=dict(city=g['city'],date=g['date'],humidity_pct=None,weather_type=None,temperature_c=None,wind_direction=None)
        if selected:
            i,v,t=selected;rh=value(v,'relative_humidity');temp=value(v,'temperature');wind=value(v,'wind_direction')
            if rh is not None and not 0<=rh<=100:raise ValueError('Invalid RH')
            row.update(humidity_pct=rh,temperature_c=temp,weather_type=weather_type(v,codes))
            if quality(v,'wind_direction') and v.get('wind_direction_Measurement_Code')=='V':row['wind_direction']='Variable'
            elif wind is not None:
                if not 0<=wind<=360:raise ValueError('Invalid direction')
                row['wind_direction']='Calm' if wind==0 else str(int(wind))+' degrees'
            proof.append(dict(game_id=g['game_id'],station_id=station,request_id=r['request_id'],row_index=i,timestamp=iso(t),raw=v,normalized=row))
        else:proof.append(dict(game_id=g['game_id'],station_id=station,request_id=r['request_id'] if r else None,discrepancy='No station observation within 90 minutes before game start; archive has a publication delay or station gap.'))
        rows.append(row)
    return rows,proof
