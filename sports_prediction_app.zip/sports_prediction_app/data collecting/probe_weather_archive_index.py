import json,re
from bs4 import BeautifulSoup
from collect_history_weather import DOC
from history_client import HistoryClient
from probe_history import ROOT
c=HistoryClient();b,r=c.get(DOC+'ghcnh-station-list.txt',document=True)
rows=b.decode().splitlines();groups={term:{line[:11]:line for line in rows if term in line.upper()} for term in ['TORONTO','VANCOUVER','MACAU','MACAO','BERLIN','SCHONEFELD']}
out=[]
for year in ['2024','2025','2026']:
    url=f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/parquet/'
    try:
        b,r=c.get(url,document=True);files={a.get('href','') for a in BeautifulSoup(b,'html.parser').find_all('a')}
        available={m[1] for f in files if (m:=re.search(r'GHCNh_(.{11})_'+year+r'\.parquet$',f))}
        result=dict(year=year,request_id=r['request_id'],archive_count=len(available),available_candidates={term:[line for station,line in stations.items() if station in available] for term,stations in groups.items()})
        print(json.dumps(result),flush=True);out.append(result)
    except Exception as e:print(year,str(e),flush=True)
(ROOT/'reports/weather_archive_station_candidates.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
