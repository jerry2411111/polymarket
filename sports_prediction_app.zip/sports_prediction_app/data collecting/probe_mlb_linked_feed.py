﻿import json
from history_client import HistoryClient
from probe_history import ROOT
c=HistoryClient();d,r=c.get('https://statsapi.mlb.com/api/v1.1/game/778297/feed/live');print('FEED',r['request_id'],'keys',list(d));print('GAMEKEYS',list(d['gameData']));print('LIVEKEYS',list(d['liveData']));print('DATETIME',d['gameData']['datetime']);print('VENUE',d['gameData']['venue']);print('PLAY',d['liveData']['plays']['allPlays'][0]['about']);print('BOXAWAYKEYS',list(d['liveData']['boxscore']['teams']['away']));print('PERSON',next(iter(d['liveData']['boxscore']['teams']['away']['players'].values())));print('PLAYERBIO',next(iter(d['gameData']['players'].values())))
(ROOT/'reports/mlb_linked_feed_probe.json').write_text(json.dumps(dict(url=r['endpoint'],request_id=r['request_id'],official_link_source_request_id='ed501a53ca67459e8303a02035d6a1d3',game_pk=d['gamePk'],status=d['gameData']['status']),indent=2),encoding='utf-8')
