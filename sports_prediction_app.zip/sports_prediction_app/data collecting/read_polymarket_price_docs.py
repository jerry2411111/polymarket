"""Read the current official OpenAPI price-history contract."""
import json
from history_client import HistoryClient
from probe_history import ROOT

c=HistoryClient();d,r=c.get('https://data-api.polymarket.com/v2/openapi.json',refresh=True)
paths={k:v for k,v in d['paths'].items() if 'prices-history' in k}
components={k:v for k,v in d.get('components',{}).get('schemas',{}).items() if any(s in k.lower() for s in ['pricepoint','pricehistory','priceshistory','resolution'])}
out=dict(request_id=r['request_id'],url=r['endpoint'],retrieved_at_utc=r['retrieved_at_utc'],paths=paths,schemas=components)
(ROOT/'reports/polymarket_current_price_schema.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
