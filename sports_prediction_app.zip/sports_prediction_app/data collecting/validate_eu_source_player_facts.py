"""Independently check raw lineups, event credits and each playing interval."""
import collections,datetime as dt,hashlib,json,math,re,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources,pointer
from eu_official_games import CONFIG,games
from eu_verified_details import details
from probe_history import ROOT
from core import utc

def main():
 db=sqlite3.connect(DB,timeout=60);db.execute('BEGIN');src=Sources(db);official={c:games(db,c) for c in CONFIG};ds=details(db);checks=collections.Counter();counts=collections.defaultdict(collections.Counter);missing=collections.defaultdict(collections.Counter);issues=[];hashes=set();examples=[]
 for gid,body in db.execute('SELECT * FROM _eu_player_event_audit ORDER BY game_id'):
  audit=json.loads(body);code=audit['competition'];ps=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_source_player_game_facts WHERE game_id=?',(gid,))];assert ps;g=official[code][ps[0]['official_match_id']];r=json.loads(db.execute('SELECT body FROM _official_'+CONFIG[code][1]+'_game_reports WHERE match_id=?',(g['official_match_id'],)).fetchone()[0]);sources=r['sources'];issues.extend(dict(competition=code,game_id=gid,**e) for e in audit['issues']);rosters=[]
  if code=='LAL':
   s=sources['match_page'];meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(s['request_id'],)).fetchone()[0]);raw=(ROOT/meta['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==meta['sha256'];match=re.search(rb'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',raw,re.S);page=json.loads(match[1]);assert page['props']['pageProps']==s['data'];hashes.add(s['request_id']);sraw=page['props']['pageProps']['data']['lineups']
   for side in ['away','home']:rosters.append([(v,True) for v in sraw[side]['starts']]+[(v,False) for v in sraw[side]['subs']])
  elif code=='UCL':
   s=sources['lineups'];raw,_=src.get(s['request_ids'][0]);assert raw==s['data']
   for side in ['awayTeam','homeTeam']:rosters.append([(v,True) for v in raw[side]['field']]+[(v,False) for v in raw[side]['bench']])
  elif code=='BUN':
   s=sources['lineups'];raw,_=src.get(s['request_id']);assert raw==s['data']
   for side in ['away','home']:rosters.append([(v,True) for v in raw[side]['startingEleven']['persons']]+[(v,False) for v in raw[side]['bench']['persons']])
  elif code=='SEA':
   s=sources['lineups'];raw,_=src.get(s['request_id']);assert raw==s['data']
   for side in ['away','home']:rosters.append([(v,True) for v in raw[side]['fielded']]+[(v,False) for v in raw[side]['benched']])
  else:
   s=sources['match'];raw,_=src.get(s['request_id']);assert raw==s['data']
   for side in ['away','home']:rosters.append([(v,v['startedMatch']) for v in raw[side]['players'].values()])
  assert len(ps)==sum(map(len,rosters));assert len({p['official_player_id'] for p in ps})==len(ps);byid={p['official_player_id']:p for p in ps};counts[code]['games']+=1;counts[code]['roster_rows']+=len(ps);event_cache={}
  def evidence(proof):
   if proof.get('request_id'):
    if code=='LAL':v=pointer(page,proof['pointer'])
    else:raw,_=src.get(proof['request_id']);v=pointer(raw,proof['pointer'])
   else:
    if not event_cache:
     for rid in proof['request_ids']:
      raw,_=src.get(rid)
      for e in raw:assert e['id'] not in event_cache;event_cache[e['id']]=e
    v=event_cache[proof['event_id']]
   return v
  gc=collections.Counter();ac=collections.Counter();team_goals=[0,0]
  for item in audit.get('goal_proofs',[]):
   raw=evidence(item['source']);pid=item['player_id'];assert pid in byid;gc[pid]+=not item['own_goal'];team_goals[item['credited_side']]+=1
   if code=='UCL':assert raw['player']['id']==pid and (raw['goalType']=='OWN')==item['own_goal']
   elif code=='BUN':assert raw['detail']['scorer']['dflDatalibraryObjectId']==pid and (raw['entryType']=='ownGoal')==item['own_goal']
   elif code=='LAL':assert raw['lineup']['person']['name']==byid[pid]['player_name'] and (raw['match_event_kind']['name']=='Own')==item['own_goal']
   elif code=='SEA':v=raw.get('away') or raw.get('home');assert v['player']['playerId']==pid and (raw['type']=='own-goal')==item['own_goal']
   checks['goal_source_identity']+=1
  for item in audit.get('assist_proofs',[]):
   raw=evidence(item['source']);pid=item['player_id'];assert pid in byid;ac[pid]+=1
   if code=='UCL':assert raw['type']=='ASSIST' and raw['primaryActor']['person']['id']==pid
   elif code=='BUN':assert raw['detail']['assist']['dflDatalibraryObjectId']==pid
   elif code=='LAL':assert raw['assist']['person']['name']==byid[pid]['player_name']
   elif code=='SEA':assert (raw.get('away') or raw.get('home'))['player']['assistPlayerId']==pid
   checks['assist_source_identity']+=1
  if audit.get('goal_counts_reconciled'):assert team_goals==g['scores'];checks['official_regulation_score_reconciliation']+=1
  for event in audit.get('timeline',[]):
   raw=evidence(event['proof']);off=event['off'];on=event['on'];assert off in byid
   if on is not None:assert on in byid and byid[on]['side']==byid[off]['side']
   if event['proof'].get('correction'):
    correction=event['proof']['correction'];assert on==correction['new_player_id'] and off==correction['player_off_id'] and event['timestamp'] is None;checks['documented_substitution_corrections']+=1
   checks['timeline_roster_identity']+=1
  times=[utc(ds[code,g['official_match_id']]['clock'].get(k)) for k in ['actual_start_utc','halftime_start_utc','second_half_start_utc','regulation_end_utc']]
  for p in ps:
   side=p['side'];found=[starter for raw,starter in rosters[side] if raw==p['raw_player']];assert len(found)==1 and found[0]==p['starter'];assert p['official_team_id']==g[['away','home'][side]]['id'];assert p['win']==int(g['scores'][side]>g['scores'][1-side]);assert p['original_game_date']==g['date'] and p['game_date']>=g['date'];checks['raw_lineup_exact_equality']+=1
   raw=p['raw_player'];pid=p['official_player_id']
   if code=='UCL':assert raw['player']['id']==pid
   elif code=='BUN':assert raw['dflDatalibraryObjectId']==pid
   elif code=='SEA':assert raw['playerId']==pid
   elif code=='LAL':
    ids=set(re.findall(r'/p(\d+)/',str(raw.get('photos',{}))))
    if p['source_identity_stable']:assert len(ids)==1 and pid=='p'+next(iter(ids))
    else:assert pid=='lineup:'+gid+':'+str(raw['id'])
   else:assert pid==str(raw['playerIdentity'].get('shortOptaId') or raw['playerIdentity']['id'])
   if p['did_play'] is None:counts[code]['unknown_appearance_rows']+=1;assert all(p[k] is None for k in ['score','assists','minutes']);continue
   if not p['did_play']:assert all(p[k] is None for k in ['score','assists','minutes']);continue
   counts[code]['played_rows']+=1
   for k in ['score','assists','minutes','starter']:
    missing[code][k]+=p[k] is None
    if p[k] is not None:assert 0<=p[k] and math.isfinite(p[k])
   if code=='FL1':
    for dest,source in [('score','goals'),('assists','goalsAssists'),('minutes','minutesPlayed')]:assert p[dest]==raw[source]
    assert p['did_play']==raw['playedMatch'];checks['direct_official_player_statistics']+=1
   else:
    if p['score'] is not None:assert audit['goal_counts_reconciled'] and p['score']==gc[pid];checks['normalized_player_goal_credits']+=1
    if p['assists'] is not None:assert audit['assist_fields_complete'] and p['assists']==ac[pid];checks['normalized_player_assist_credits']+=1
    if p['minutes'] is not None:
     assert all(times);start,hs,rs,end=[t.timestamp() for t in times];ons=[v for v in audit['timeline'] if v['kind']=='sub' and v['on']==pid];assert len(ons)==(0 if p['starter'] else 1);lo=start if p['starter'] else utc(ons[0]['timestamp']).timestamp();offs=[v for v in audit['timeline'] if v['off']==pid and v['timestamp'] and lo<=utc(v['timestamp']).timestamp()<=end];hi=min([utc(v['timestamp']).timestamp() for v in offs]+[end]);expected=((hi-lo)-max(0,min(hi,rs)-max(lo,hs)))/60;assert math.isclose(p['minutes'],expected,abs_tol=1e-8);checks['independent_player_playing_interval']+=1
   if sum(e['competition']==code for e in examples)<3 and p['score'] and p['minutes'] is not None:examples.append(dict(competition=code,game_id=gid,player_id=p['player_id'],player_name=p['player_name'],goals=p['score'],assists=p['assists'],minutes=p['minutes'],request_id=p['roster_request_id']))
  hashes.update(src.cache);src.cache.clear()
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Independent normalization validation, not a statement of complete source coverage. Facts are still source-native and require published-odds filtering before performance installation.',counts={k:dict(v) for k,v in counts.items()},checks=dict(checks),source_hashes=len(hashes),source_coverage_issues=issues,missing={c:{k:dict(count=v,total=counts[c]['played_rows'],percentage=round(v*100/counts[c]['played_rows'],4)) for k,v in fs.items()} for c,fs in missing.items()},examples=examples);(ROOT/'reports/eu_source_player_facts_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['source_coverage_issues','examples','missing']}));print('SOURCE COVERAGE ISSUES',len(issues));db.close()

if __name__=='__main__':main()
