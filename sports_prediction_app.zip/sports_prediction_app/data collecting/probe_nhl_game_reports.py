"""Verify three real NHL API games against league-authored scorer reports."""
import collections,datetime as dt,hashlib,json,re
from history_client import HistoryClient
from probe_history import ROOT
from collect_official_results import nhl_summary

def norm(s):return re.sub('[^a-z0-9]','',s.lower())
def team(t):return t['placeName']['default']+' '+t['commonName']['default']

def main():
 c=HistoryClient();pilot=json.loads((ROOT/'reports/nhl_schedule_pilot.json').read_text());results=[]
 for p in pilot['requests']:
  g=p['examples'][0];gid=str(g['id']);season=str(g['season']);sources={};data={}
  for kind in ['boxscore','landing','play-by-play','right-rail']:
   d,r=c.get('https://api-web.nhle.com/v1/gamecenter/'+gid+'/'+kind);data[kind]=d;sources[kind]=r
  url='https://www.nhl.com/scores/htmlreports/'+season+'/GS'+gid[4:]+'.HTM';b,r=c.get(url,document=True);official=nhl_summary(b,season,gid[4:],r['request_id']);assert official
  checks=[]
  for kind in ['boxscore','landing','play-by-play']:
   d=data[kind];assert str(d['id'])==gid;assert [d[s]['id'] for s in ['awayTeam','homeTeam']]==[g[s]['id'] for s in ['awayTeam','homeTeam']];assert [d[s]['score'] for s in ['awayTeam','homeTeam']]==official['scores'];assert [norm(team(g[s])) for s in ['awayTeam','homeTeam']]==[norm(n) for n in official['teams']];checks.append(kind)
  box=data['boxscore'];pbp=data['play-by-play'];rail=data['right-rail'];players=box.get('playerByGameStats',{});playkeys=collections.Counter(k for e in pbp.get('plays',[]) for k in e);detailkeys=collections.Counter(k for e in pbp.get('plays',[]) for k in e.get('details',{}))
  row=dict(official_game_id=gid,season=season,date=official['date'],teams=[team(g[s]) for s in ['awayTeam','homeTeam']],scores=official['scores'],official_public_report_url=url,official_report_request_id=r['request_id'],scheduled_start=g['startTimeUTC'],actual_start_clock=official['start_clock'],actual_start_zone=official['start_zone'],raw_to_raw_matches=checks,api_request_ids={k:r['request_id'] for k,r in sources.items()},top_level_keys={k:list(d) for k,d in data.items()},player_groups={s:{k:len(v) for k,v in groups.items()} for s,groups in players.items()},play_fields=dict(playkeys),play_detail_fields=dict(detailkeys),period_end_examples=[e for e in pbp.get('plays',[]) if e.get('typeDescKey') in ['period-start','period-end','game-end']][:5],right_rail_game_info=rail.get('gameInfo'),landing_summary=data['landing'].get('summary'))
  results.append(row);print(json.dumps(row),flush=True)
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',games_tested=len(results),new_requests=c.requests,examples=results,note='Three actual historical dates; all identity and final-score checks match independent official scorer reports. Price histories and absolute break timestamp coverage require separate tests.')
 (ROOT/'reports/nhl_public_api_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')

if __name__=='__main__':main()
