"""Independently check source tokens, result sides, dated fixtures and duration rules."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from eu_official_games import CONFIG,games
from epl_price_points import Sources,pointer
from build_premier_market_candidates import array,utc

def main():
 db=sqlite3.connect(DB,timeout=60);src=Sources(db);checks=collections.Counter();summaries={};issues=[];eligible=[];official_by_code={}
 for code in CONFIG:
  official=games(db,code);official_by_code[code]=official;groups=collections.defaultdict(list)
  for b, in db.execute('SELECT body FROM _eu_market_candidates WHERE competition=?',(code,)):
   c=json.loads(b);groups[c['provider'],c['family_id']].append(c)
  counts=collections.Counter()
  for (provider,fid),cs in groups.items():
   assert len(cs)==3 and sorted(c['side'] for c in cs)==[0,1,2];assert len({c['contract_id'] for c in cs})==3 and len({c['official_match_id'] for c in cs})==1
   g=official[cs[0]['official_match_id']];assert not g.get('result_revision');assert g['scores'] is not None;winner=2 if g['scores'][0]==g['scores'][1] else int(g['scores'][1]>g['scores'][0]);duration_issues=[]
   for c in cs:
    assert c['competition']==code and c['date']==g['date'] and c['game_id']==g['game_id'];assert c['official_schedule_request_id']==g['request_id'];assert c['official_away_team_id']==g['away']['id'] and c['official_home_team_id']==g['home']['id']
    assert c['native_team_id']==(g[['away','home'][c['side']]]['id'] if c['side']<2 else None);assert c['settlement_yes']==int(c['side']==winner);checks['official_date_native_ids_and_result']+=1
    raw,r=src.get(c['request_id']);m=pointer(raw,c['pointer']);assert str(m.get('id') if provider=='polymarket' else m['ticker'])==c['market_id'];assert utc(r['retrieved_at_utc'])
    review=c.get('fixture_date_review')
    if review:
     assert review['official_match_id']==g['official_match_id'] and review['official_request_id']==g['request_id'];assert review['official_team_ids']==[g['away']['id'],g['home']['id']];assert c['request_id'] in review['source_request_ids']
     if review.get('required_description_fragments'):assert all(t in m['description'] for t in review['required_description_fragments'])
     else:assert len(review['settled_timestamps'])==3 and all(0<(utc(t)-utc(g['scheduled_start_utc'])).total_seconds()<=172800 for t in review['settled_timestamps'])
     checks['reviewed_fixture_date_correction']+=1
    if provider=='polymarket':
     outs=array(m['outcomes']);tokens=array(m['clobTokenIds']);values=array(m['outcomePrices']);assert outs[c['outcome_index']].lower()=='yes' and tokens[c['outcome_index']]==c['contract_id'];assert float(values[c['outcome_index']])==c['settlement_yes'] and m['closed'];checks['raw_yes_token_index_and_resolution']+=1
     q=m['question'].strip();desc=m.get('description','');assert bool(re.search(r'\b(draw|tie)\b',q,re.I))==(c['side']==2)
     if c['side']<2:assert re.match(r'Will (.+?) (?:win|beat|defeat)\b',q,re.I)[1]==c['team_question']
     explicit=bool(re.search(r'90 minutes.{0,80}stoppage time',desc,re.I))
     # Domestic league matches and first legs cannot add extra time. Other
     # UEFA knockout contracts require explicit regulation-only wording.
     no_extra=code!='UCL' or g['raw']['type'] in ['FIRST_LEG','GROUP_STAGE'] or g['raw']['round']['mode']=='GROUP'
     if not explicit and not no_extra:duration_issues.append(c['market_id'])
    else:
     assert c['contract_id']==m['ticker'] and c['event_id']==m['event_ticker'] and c['series']==CONFIG[code][2];assert c['settlement_yes']==int(m['result']=='yes');assert c['team_question']==m['yes_sub_title'];assert re.sub(r'^Reg Time:\s*','',m['yes_sub_title'],flags=re.I)==c['mapping_label'];assert '90 minutes plus stoppage time' in m['rules_primary'] and 'does not include extra time or penalties' in m['rules_primary'];checks['raw_kalshi_yes_contract_and_duration']+=1
   if duration_issues:issues.append(dict(competition=code,provider=provider,family_id=fid,reason='No explicit regulation-only rule in a UEFA match permitting extra time',markets=duration_issues));continue
   counts[provider]+=1;eligible.extend(cs);checks['independent_three_outcome_family']+=1
  summaries[code]=dict(families=dict(counts),unique_games=len({c['game_id'] for c in eligible if c['competition']==code}))
 # Current authoritative full names for two different Paris clubs must never
 # collapse to one native identity; inspect every retained Paris assignment.
 for c in eligible:
  if c['competition']=='FL1' and c['native_team_id'] in ['13','90']:
   g=official_by_code['FL1'][c['official_match_id']];name=g[['away','home'][c['side']]]['name'];assert ('Saint-Germain' in name)==(c['native_team_id']=='13');checks['distinct_paris_club_assignments']+=1
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_club_alias_evidence'").fetchone():
  seen=set()
  for b, in db.execute('SELECT body FROM _eu_club_alias_evidence'):
   e=json.loads(b)
   if e['request_id'] in seen:continue
   r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(e['request_id'],)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==e['sha256']==r['sha256'];seen.add(e['request_id']);checks['official_alias_document_hash']+=1
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _eu_validated_contracts (competition TEXT NOT NULL,provider TEXT NOT NULL,contract_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(competition,provider,contract_id)) STRICT');db.execute('DELETE FROM _eu_validated_contracts');db.executemany('INSERT INTO _eu_validated_contracts VALUES (?,?,?,?)',[(c['competition'],c['provider'],c['contract_id'],json.dumps(c)) for c in eligible])
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Eligible source metadata only. This does not validate or publish any historical odds.',competitions=summaries,contracts=len(eligible),checks=dict(checks),source_hashes=len(src.cache),excluded_rule_families=issues);(ROOT/'reports/eu_market_candidates_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='excluded_rule_families'}),flush=True);print('Excluded duration families',len(issues),flush=True);db.close()

if __name__=='__main__':main()
