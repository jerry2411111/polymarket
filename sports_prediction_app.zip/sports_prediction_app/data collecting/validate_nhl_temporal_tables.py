"""Independent bounded statistics, profile values, cohort and t-1 link checks."""
import collections,datetime as dt,json,math,sqlite3,statistics
from build_history_catalog import DB
from probe_history import ROOT
from validate_mlb_temporal_tables import equal
from build_nhl_temporal_events import franchise

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    wanted={r[0] for r in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='NHL' UNION SELECT game_id FROM kalshi_pre_match WHERE league='NHL'")};gs={i:json.loads(b) for i,b in db.execute('SELECT * FROM _nhl_canonical_games') if i in wanted};facts=collections.defaultdict(list)
    for r in db.execute("SELECT * FROM _player_game_results WHERE league='NHL' ORDER BY player_id,game_date,game_id"):facts[r['player_id']].append(dict(r))
    assert {p['game_id'] for ps in facts.values() for p in ps}==wanted
    for ps in facts.values():
        for p in ps:assert p['game_date']==gs[p['game_id']]['completion_local_date'] and start<=p['game_date']<=end
    checks=collections.Counter();examples=[]
    for day in ['2024-01-01','2024-06-07','2024-06-08','2024-12-31','2025-05-06','2025-05-07','2025-11-16','2026-06-14',end]:
        rows={r['player_id']:dict(r) for r in db.execute("SELECT * FROM _player_performance_periods WHERE league='NHL' AND effective_from<=? AND effective_to>?",(day,day))};profiles={r['player_id']:dict(r) for r in db.execute("SELECT * FROM player_profiles WHERE league='NHL' AND as_of_date=?",(day,))};averages=[]
        for pid,ps in facts.items():
            bounded=[p for p in ps if start<=p['game_date']<=day]
            if not bounded:
                assert pid not in rows
                if pid in profiles:assert profiles[pid]['overall_winrate'] is None and profiles[pid]['average_score_per_game'] is None
                checks['no_future_player_performance']+=1;continue
            row=rows[pid];profile=profiles[pid];assert row['games_played']==len(bounded) and equal(row['overall_winrate'],statistics.mean(p['win'] for p in bounded));assert equal(row['overall_winrate'],profile['overall_winrate']);checks['bounded_player_game_and_win_counts']+=1
            for source in ['score','assists','minutes']:
                values=[p[source] for p in bounded];complete=all(v is not None for v in values);avg=statistics.mean(values) if complete else None;sd=statistics.stdev(values) if complete and len(values)>1 else None
                for prefix,expected in [('average_',avg),('std_',sd)]:
                    field=prefix+source+'_per_game';assert equal(row[field],expected),(day,pid,field);assert equal(profile[field],expected),(day,pid,'profile '+field);checks['independent_mean_and_sample_std']+=2
            if row['average_score_per_game'] is not None:averages.append(row['average_score_per_game'])
        if averages:
            cohort=db.execute("SELECT mu,sigma FROM _player_score_cohorts WHERE league='NHL' AND as_of_date=?",(day,)).fetchone();mu=statistics.mean(averages);sigma=statistics.pstdev(averages);assert equal(cohort[0],mu) and equal(cohort[1],sigma)
            for pid,row in rows.items():
                avg=row['average_score_per_game'];expected=(avg-mu)/sigma if avg is not None and sigma else None;assert equal(profiles[pid]['score_z_score'],expected);checks['date_bounded_z_score_cohort']+=1
        teamfacts=collections.defaultdict(list)
        for r in db.execute("SELECT * FROM _team_game_results WHERE league='NHL' AND game_date BETWEEN ? AND ?",(start,day)):teamfacts[franchise(r['team_name'])].append(dict(r))
        teamrows=list(db.execute("SELECT * FROM team_history WHERE league='NHL' AND as_of_date=?",(day,)));assert len(teamrows)==len(teamfacts)
        for r in teamrows:
            actual=teamfacts[franchise(r['team_name'])];assert r['games_played']==len(actual) and equal(r['winrate'],statistics.mean(p['win'] for p in actual));assert r['home_times']==sum(p['home_away']=='Home' for p in actual) and r['away_times']==sum(p['home_away']=='Away' for p in actual);assert equal(r['average_score_margin'],statistics.mean(p['score_for']-p['score_against'] for p in actual))
            if franchise(r['team_name'])=='utah_nhl':assert r['team_name']==('Utah Hockey Club' if day<'2025-05-07' else 'Utah Mammoth')
            checks['bounded_team_history_and_franchise_continuity']+=1
        for r in db.execute("SELECT * FROM manager_profiles WHERE league='NHL' AND as_of_date=?",(day,)):
            win=db.execute("SELECT avg(win) FROM _manager_game_results WHERE league='NHL' AND manager_id=? AND game_date BETWEEN ? AND ?",(r['manager_id'],start,day)).fetchone()[0];assert equal(r['overall_winrate'],win);checks['bounded_coach_winrate']+=1
        examples.append(dict(date=day,players_with_sample_statistics=len(rows),teams_with_sample_statistics=len(teamrows)))
    for gid,pid,day,exists in db.execute("SELECT l.game_id,l.player_id,l.as_of_date,p.as_of_date FROM game_player_profiles l LEFT JOIN player_profiles p ON p.player_id=l.player_id AND p.as_of_date=l.as_of_date WHERE l.game_id LIKE 'NHL_%'"):
        assert gid in gs and exists==day and day==(dt.date.fromisoformat(gs[gid]['date'])-dt.timedelta(days=1)).isoformat();checks['t_minus_one_player_links']+=1
    for gid,mid,day in db.execute("SELECT * FROM game_manager_profiles WHERE game_id LIKE 'NHL_%'"):
        assert gid in gs and day==(dt.date.fromisoformat(gs[gid]['date'])-dt.timedelta(days=1)).isoformat();assert db.execute('SELECT 1 FROM manager_profiles WHERE manager_id=? AND as_of_date=?',(mid,day)).fetchone();checks['t_minus_one_coach_links']+=1
    for b, in db.execute('SELECT body FROM _nhl_game_profile_link_audit'):
        a=json.loads(b)
        for source in a['prior_roster_sources']:assert source['observed_date']<=a['as_of_date'];checks['prior_roster_source_dates']+=1
    for pid,b in db.execute('SELECT * FROM _official_nhl_player_bios'):
        bio=json.loads(b);r=db.execute("SELECT * FROM player_profiles WHERE player_id=? AND as_of_date=?",('NHL:'+pid,end)).fetchone();assert r and r['weight_kg']==bio['weight_kg'] and r['height_cm']==bio['height_cm'];checks['physical_constants']+=2
        if bio['birth_date']:
            dob=dt.date.fromisoformat(bio['birth_date']);d=dt.date.fromisoformat(end);assert r['age']==d.year-dob.year-((d.month,d.day)<(dob.month,dob.day));checks['date_specific_age']+=1
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',coverage_status='PARTIALLY WORKING',collected_games=len(wanted),players_with_appearances=len(facts),checks=dict(checks),examples=examples,meaning='Statistics use only collected completed games from collection start through each date. Biographical career logs supply past affiliation/history only. Missing source statistics remain missing; sample standard deviation and date-specific league z-score cohort checked independently.')
    (ROOT/'reports/nhl_temporal_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));db.close()

if __name__=='__main__':main()
