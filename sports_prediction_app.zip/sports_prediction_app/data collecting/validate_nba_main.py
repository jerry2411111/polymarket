"""Validate real NBA output against raw odds, native game IDs and schedules."""
import argparse,bisect,collections,datetime as dt,functools,hashlib,json,math,re,sqlite3
from pathlib import Path
from build_history_catalog import DB,ORIGINAL
from probe_history import ROOT
from history_index import records
from core import utc,pointer,array
from schema import HOURS,PRE_COLUMNS
from nba_identity import full_team_name

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--facts-only',action='store_true');args=ap.parse_args()
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    source={}
    for root in [ORIGINAL,ROOT]:
        for r in records(root):source[r['request_id']]=(root,r)
    @functools.lru_cache(maxsize=512)
    def raw(rid):
        root,r=source[rid];b=(root/r['raw_file']).read_bytes()
        assert hashlib.sha256(b).hexdigest()==r['sha256'],'Changed raw response'
        assert r['status']==200,'Failed source used'
        return json.loads(b)
    original_games={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _history_games')}
    games={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _nba_canonical_games')}
    mappings={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _nba_canonical_map')}
    facts={r[0]:json.loads(r[1]) for r in db.execute("SELECT game_id,body FROM _official_game_facts WHERE json_extract(body,'$.league')='NBA'")}
    cards={r[0]:json.loads(r[1]) for r in db.execute('SELECT official_game_id,body FROM _official_nba_schedule')}
    # Recheck league facts directly in retained official responses, independently
    # of the normalized schedule table used by the odds builder.
    card_sources=collections.defaultdict(list)
    for card in cards.values():card_sources[card['request_id']].append(card)
    official_raw_checks=0
    for rid,group in card_sources.items():
        root,r=source[rid];body=(root/r['raw_file']).read_bytes()
        assert r['status']==200 and hashlib.sha256(body).hexdigest()==r['sha256'],'Official raw response changed'
        script=re.search(rb'<script\b[^>]*\bid="__NEXT_DATA__"[^>]*>(.*?)</script>',body,re.S)
        assert script,'Official structured game evidence absent'
        page=json.loads(script[1])['props']['pageProps']
        if 'gameCardFeed' in page:
            native={x['cardData']['gameId']:x['cardData'] for m in page['gameCardFeed']['modules'] for x in m.get('cards',[]) if x.get('cardData',{}).get('gameId')}
        else:native={page['game']['gameId']:page['game']}
        for card in group:
            raw_game=native[card['official_game_id']];teams=[raw_game['awayTeam'],raw_game['homeTeam']]
            assert raw_game['gameStatus']==3
            assert [str(t['teamId']) for t in teams]==card['official_team_ids']
            assert [int(t['score']) for t in teams]==card['scores']
            assert raw_game.get('gameTimeUtc',raw_game.get('gameTimeUTC'))==card['start_utc']
            if 'selectedDate' in page:assert page['selectedDate']==card['date']
            else:assert raw_game['gameCode'].split('/')[0]==card['date'].replace('-','')
            periods=[{int(q['period']):int(q['score']) for q in t.get('periods',[])} for t in teams]
            short_format=card['competition_type']=='All-Star' and all(len(q)<4 for q in periods)
            expected=[[0,0]]+[[sum(q[n] for n in range(1,i+1)) if all(n in q for n in range(1,i+1)) else None for q in periods] for i in [1,2,3]]
            if short_format:expected=[[0,0]]+[[None,None] for _ in range(3)]
            assert expected==card['break_scores'],('Official raw period score mismatch',card['official_game_id'],rid,expected,card['break_scores'])
            official_raw_checks+=1
    print('NBA official raw game checks',official_raw_checks,flush=True)
    if args.facts_only:return
    contracts={};chosen=set()
    for (body,) in db.execute('SELECT body FROM _nba_contract_choice_audit'):
        chosen.update(json.loads(body)['excluded_contract_ids'])
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='_nba_market_family_choices'").fetchone():
        for (body,) in db.execute('SELECT body FROM _nba_market_family_choices'):chosen.update(json.loads(body)['excluded_contract_ids'])
    for (body,) in db.execute('SELECT body FROM _history_contracts'):
        c=json.loads(body);old=c['game_id']
        if old not in mappings or c['contract_id'] in chosen:continue
        m=mappings[old];side=m['source_to_canonical'][c['side']]
        assert full_team_name(original_games[old]['teams'][c['side']])==games[m['game_id']]['teams'][side],'Team order changed incorrectly'
        market=pointer(raw(c['request_id']),c['pointer'])
        if c['provider']=='polymarket':
            tokens=array(market['clobTokenIds']);outcomes=array(market['outcomes']);assert outcomes[tokens.index(c['contract_id'])]==c['outcome'],'Token/outcome mapping mismatch'
        else:assert market['custom_strike']['basketball_team']==original_games[old]['team_ids'][c['side']],'Kalshi team contract mismatch'
        contracts[c['provider'],c['contract_id']]=dict(c,game_id=m['game_id'],side=side)
    outputs={};ing={}
    for provider in ['polymarket','kalshi']:
        for r in db.execute(f"SELECT * FROM {provider}_pre_match WHERE league='NBA'"):outputs[provider,r['game_id']]=dict(r)
        for r in db.execute(f"SELECT * FROM {provider}_in_game WHERE league='NBA'"):ing[provider,r['game_id']]=dict(r)
    assert outputs.keys()==ing.keys(),'Missing game linkage'
    by_source={};times=collections.defaultdict(list);point_windows=collections.defaultdict(list)
    for (body,) in db.execute('SELECT body FROM _history_price_points'):
        p=json.loads(body);key=p['provider'],p['contract_id']
        if key not in contracts:continue
        by_source[p['request_id'],p['pointer']]=p
        end=p['timestamp']+(p['resolution_seconds'] if p['kind']=='v2' else 0)
        times[key].append(end);point_windows[key].append((p['timestamp'],end))
    for v in times.values():v.sort()
    checks=collections.Counter(official_raw_game_records=official_raw_checks);month_checks=collections.Counter();snapshots=0
    for (provider,gid),row in outputs.items():
        f=facts[gid];card=cards[f['official_game_id']]
        assert row['match']=='/'.join(f['teams'])
        assert row['date']==card['date']
        assert [row['teamA_final_score'],row['teamB_final_score']]==card['scores']
        assert row['final']==f['teams'][int(card['scores'][1]>card['scores'][0])]
        assert row['season']==' '.join(str(card[k]) for k in ['season_year','competition_type'] if card.get(k))
        assert utc(row['timestamp']).utcoffset()==dt.timedelta(0)
        assert any(row[f'team{s}_pre_{h}_p'] is not None for s in 'AB' for h in HOURS) or any(v!='null' for s in 'AB' for v in ing[provider,gid][f'team{s}_ingame_p'].split(';'))
        for s in 'AB':
            vals=[None if x=='null' else int(x) for x in ing[provider,gid][f'team{s}_score'].split(';')]
            assert vals==[x['AB'.index(s)] for x in card['break_scores']]
        checks['official_game_identity_final_and_break_scores']+=1
    for (body,) in db.execute('SELECT body FROM _history_selections'):
        a=json.loads(body);key=a['provider'],a['game_id']
        if key not in outputs:continue
        row=outputs[key];side='AB'[a['side']]
        if a['target'].startswith('pre_'):
            expected=row[f'team{side}_{a["target"]}_p'];h=int(a['target'][4:]);target=int(utc(row['timestamp']).timestamp())-h*3600-(h==0)
            assert int(utc(a['target_timestamp_utc']).timestamp())==target,'Wrong hour target'
        else:
            n=int(a['target'][7:]);v=ing[key][f'team{side}_ingame_p'].split(';')[n];expected=None if v=='null' else float(v)
        assert expected==a['normalized_price'],'Output and source audit differ'
        if expected is None:continue
        p=by_source[a['request_id'],a['pointer']];c=contracts[p['provider'],p['contract_id']]
        assert (c['game_id'],c['side'])==(a['game_id'],a['side']),'Quote attached to wrong game/team'
        assert float(pointer(raw(a['request_id']),a['pointer']))==expected,'Raw price differs'
        assert 0<=expected<=1
        if a['target'].startswith('pre_'):
            t=int(utc(a['source_timestamp_utc']).timestamp());start=int(utc(row['timestamp']).timestamp());end=t+(p['resolution_seconds'] if p['kind']=='v2' else 0)
            assert end<=target and t<start,'Future aggregate-window or tick leakage'
            assert int(utc(a['source_available_at_utc']).timestamp())==end
            xs=times[p['provider'],p['contract_id']];at=bisect.bisect_right(xs,target)-1
            assert at>=0 and xs[at]==end,'Closer completed observation window was skipped'
            odd=row[f'team{side}_{a["target"]}_odd']
            assert (odd is None if expected==0 else math.isclose(odd,1/expected,rel_tol=1e-14))
        else:
            lo=int(utc(a['target_timestamp_utc']).timestamp());hi=int(utc(a['window_end_utc']).timestamp());t=int(utc(a['source_timestamp_utc']).timestamp());end=t+(p['resolution_seconds'] if p['kind']=='v2' else 0)
            assert lo<=t<hi and end<=hi,'In-game observation window outside break'
            eligible=[(b,e) for b,e in point_windows[p['provider'],p['contract_id']] if lo<=b<hi and e<=hi]
            assert end==min(e for b,e in eligible),'Skipped earlier completed observation within break'
            odd_text=ing[key][f'team{side}_ingame_odd'].split(';')[n]
            assert (odd_text=='null' if expected==0 else math.isclose(float(odd_text),1/expected,rel_tol=1e-14))
            snapshots+=1
        checks['raw_odds_value_team_mapping_and_timestamp']+=1;month_checks[row['date'][:7]]+=1
    schedule=collections.defaultdict(list)
    for c in cards.values():schedule[c.get('season_year'),c['competition_type']].append(c)
    coverage=[];team_rows=[]
    for (season,kind),cs in sorted(schedule.items()):
        ids={c['official_game_id'] for c in cs};item=dict(season=season,competition=kind,official_games_in_date_window=len(ids),expected_full_regular_season=1230 if kind=='Regular Season' else None)
        if kind=='Regular Season':
            ct=collections.Counter();names={}
            for c in cs:
                for side,tid in enumerate(c['official_team_ids']):ct[tid,side]+=1;names[tid]=c['team_names'][side]
            for tid,name in names.items():team_rows.append(dict(season=season,official_team_id=tid,team=name,games=ct[tid,0]+ct[tid,1],designated_home=ct[tid,1],designated_away=ct[tid,0]))
            if season in ['2024-25','2025-26']:
                assert len(ids)==1230 and len(names)==30
                assert all(ct[tid,0]+ct[tid,1]==82 for tid in names)
        for provider in ['polymarket','kalshi']:
            obtained={facts[gid]['official_game_id'] for p,gid in outputs if p==provider and facts[gid]['official_game_id'] in ids}
            item[provider+'_games_with_odds']=len(obtained);item[provider+'_coverage_pct']=round(100*len(obtained)/len(ids),2) if ids else None
            item[provider+'_status']='COMPLETE' if len(obtained)==len(ids) else 'PARTIAL'
        coverage.append(item)
    # Source proof is embedded in the captured official date-page JSON, not an
    # invented season total. The 2023-24 schedule is truncated at Jan 1, 2024.
    result=dict(status='WORKING',verified_at_utc=dt.datetime.now(dt.UTC).isoformat(),timestamp_rule='Polymarket aggregate bucket must be complete before target, or wholly inside break; Kalshi candle timestamp is already its close time',dataset_coverage='PARTIAL; collection ongoing',checks=dict(checks),nba_game_provider_rows=len(outputs),unique_nba_games=len({g for p,g in outputs}),validated_in_game_quotes=snapshots,coverage=coverage,team_schedule_checks=team_rows)
    (ROOT/'reports/nba_main_validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    lines=['# NBA main-table validation','',f'Validated {len(outputs)} provider/game rows, {checks["raw_odds_value_team_mapping_and_timestamp"]} raw quote mappings and timestamps. Coverage is PARTIAL while acquisition continues.','',
      'All competitions share each provider table. `season` combines the source season year and competition. Games without usable acquired odds are excluded from results; they are not assumed unavailable permanently.','',
      '| Season | Competition | Official games in window | Polymarket with odds | Kalshi with odds |','|---|---|---:|---:|---:|']
    for r in coverage:lines.append(f'| {r["season"]} | {r["competition"]} | {r["official_games_in_date_window"]} | {r["polymarket_games_with_odds"]} ({r["polymarket_coverage_pct"]}%) | {r["kalshi_games_with_odds"]} ({r["kalshi_coverage_pct"]}%) |')
    lines+=['','The 2023-24 regular-season count covers January 1, 2024 onward. Both full regular seasons have exactly 1,230 distinct official games and 82 appearances for each of 30 teams. Official game-card home/away designations are 40/42 for some teams; these are reported without forcing 41/41. NBA Cup scheduling and neutral venues need separate physical-venue handling.','',
      'Sources: official date-specific NBA game cards at https://www.nba.com/games?date=YYYY-MM-DD, and the saved official provider API responses identified in the SQL request audit. Public league schedule releases: https://pr.nba.com/2024-25-nba-regular-season-schedule/ and https://pr.nba.com/2025-26-nba-regular-season-schedule/.','',
      '```sql',"SELECT * FROM polymarket_pre_match WHERE league='NBA' AND season='2024-25 Playoffs';", "SELECT * FROM kalshi_pre_match WHERE league='NBA' AND date='2025-12-25';",'```']
    (ROOT/'reports/nba_main_validation.md').write_text('\n'.join(lines)+'\n',encoding='utf-8');db.close();print(json.dumps({k:v for k,v in result.items() if k not in ['coverage','team_schedule_checks']}))

if __name__=='__main__':main()
