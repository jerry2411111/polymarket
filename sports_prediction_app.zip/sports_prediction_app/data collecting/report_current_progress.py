"""Summarize the current verified exports and remaining gaps without stale counts."""
import datetime as dt
import json
from probe_history import ROOT
from schema import HOURS


def main():
    reports=ROOT/'reports'
    load=lambda name:json.loads((reports/name).read_text(encoding='utf-8'))
    inventory=load('all_outputs_inventory.json')
    missing=load('missing_data_verification.json')
    odds=load('missing_odds_verification.json')
    support=load('supporting_missing_verification.json')
    removal=load('removed_lookbacks_validation.json')
    assert all(r['status']=='WORKING' for r in [inventory,missing,odds,support,removal])
    assert odds['active_lookback_hours']==HOURS==removal['active_lookback_hours']
    fields=sum(len(row['fields']) for row in missing['datasets'])
    assert fields==sum(row['column_count'] for row in inventory['outputs'])
    now=dt.datetime.now(dt.UTC).isoformat()
    lines=['# Collection progress', '', 'Updated: '+now, '',
        '**Collection: PARTIALLY WORKING. Current stored-data validation: WORKING.**', '',
        f"The sample contains {inventory['distinct_games']:,} distinct games in {len(inventory['outputs'])} logical CSV/Parquet datasets and one SQL database.",
        'Collection window: '+inventory['scope']['collection_start']+' through '+inventory['scope']['collection_end']+'. Coverage within that window is partial.', '',
        '## Current schema and verification', '',
        '- Active pre-match hours: '+', '.join(map(str,HOURS))+'. Retired 60- and 72-hour columns are absent from both providers\' main SQL tables, exports and the combined main view.',
        '- US main tables have 32 columns; EU soccer main tables have 43, including draw. Remaining values were compared exactly across the original and revised SQL/CSV/Parquet projections.',
        f"- The completed cross-format audit checked all {len(missing['datasets'])} datasets, {fields} columns and {sum(len(x['checkpoint_slots']) for x in missing['datasets'])} checkpoint/field groups with no discrepancies.",
        f"- {odds['probability_slots_checked']:,} retained pre-match probability slots were reconciled with their stored selection records. {odds['missing_probability_slots']:,} ({odds['missing_probability_slots']*100/odds['probability_slots_checked']:.2f}%) are missing; {odds['zero_probability_undefined_odds']} additional decimal odds are undefined because the recorded probability is zero.",
        '- Complete, partial and entirely missing pre-match games are classified separately. Every active hour has both outcome-value and game-level missing percentages.',
        f"- All {support['weather_source_check']['source_value_comparisons']:,} weather values/absences match the retained normalized source-observation audit. Missing weather reasons distinguish station archives, the permitted time window, and individual fields.",
        '- Eight existing quote-timing, temporal and shared-rate-limit tests pass.', '',
        '## Provider coverage', '',
        '| Provider | League | Games | Complete pre-match probabilities | Partially missing | All pre-match missing |',
        '|---|---|---:|---:|---:|---:|']
    for row in odds['game_coverage_summary']:
        lines.append('| '+' | '.join(str(row[k]) for k in ['provider','league','games','games_complete','games_partially_missing','games_all_missing'])+' |')
    lines+=['','## Remaining gaps','','| Data | Measured limitation |','|---|---|',
        '| In-game probabilities | Polymarket has usable checkpoint rows for 92 MLB and 65 EU games, and none for NBA/NHL. Counts against all main games are in the checkpoint coverage report. |',
        '| Player game statistics | MLB minutes are missing for every collected appearance. EU soccer assists are missing in 20.27% of appearances and minutes in 12.53%. Missing batting runs are distinct from pitcher runs allowed. |',
        '| Career history and tenure | Many full-career counts and dated stint starts remain unknown. Current-profile percentages are separated from daily historical snapshots. |',
        '| Injury status | No-report=false/zero follows the requested convention; it does not establish complete injury records. |',
        '| Rankings | Publisher series: NBA 9, MLB 5, NHL 6, EU 2. Ten independent major-media lists and fresh quarterly editions remain unfulfilled; unlisted players remain unknown. |', '',
    ]
    lines+=['','## Files and SQL records','',
        'All collected data is under `collected data/raw` and `collected data/result`. Scripts and reports are separate. The `data` and Desktop project junctions open these same files.', '',
        '- [Every column, definition and missing percentage](all_columns_missing.csv)',
        '- [Independent SQL/CSV/Parquet verification](missing_data_verification.md)',
        '- [Pre-match game classification and each-hour percentages](pre_match_game_coverage.md)',
        '- [Supporting-table gaps and source checks](supporting_missing_verification.md)',
        '- [Date-specific SQL queries](sql_queries.md)',
        '- [Source-to-data map](data_sources.md)',
        '- [Retired lookback validation](removed_lookbacks_validation.json)', '',
        'SQL audit views: `missing_data_latest`, `pre_match_coverage_latest`, `pre_match_lookback_coverage_latest` and `support_missing_latest`. Prior audit versions remain retained internally. Passing validation does not mean missing source data have been acquired.', '']
    (reports/'collection_progress.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Updated current progress:',len(missing['datasets']),'datasets;',fields,'columns;',HOURS,flush=True)


if __name__=='__main__':
    main()
