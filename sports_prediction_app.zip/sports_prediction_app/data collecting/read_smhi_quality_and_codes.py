"""Current SMHI code definitions plus a quality-checked city humidity source."""
import datetime as dt,json
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from read_smhi_station_metadata import json_url

HOSTS.update({'www.smhi.se','opendata-download-metobs.smhi.se'});c=HistoryClient()
url='https://www.smhi.se/data/hitta-data-for-en-plats/ladda-ner-vaderobservationer/presentWeather'
b,r=c.get(url,document=True);s=BeautifulSoup(b,'html.parser');text=s.get_text(' ',strip=True)
print('CODE DOC',r['request_id'],'literal code meaning present', 'Inget signifikant' in text,flush=True)
root=json.loads((ROOT/'reports/smhi_current_documentation.json').read_text());resource=next(p for p in root['metadata']['resource'] if str(p['key'])=='13');parameter,pm=c.get(json_url(resource));code_url=next(l['href'] for l in parameter['link'] if l['rel']=='codes' and l['type']=='application/json');codes,cr=c.get(code_url);print('NATIVE CODE DOCUMENTATION',cr['request_id'],json.dumps(codes,ensure_ascii=False)[:1200],flush=True)
p=next(p for p in json.loads((ROOT/'reports/smhi_station_metadata.json').read_text())['parameters'] if str(p['parameter'])=='6');station=next(s for s in p['station_metadata'] if s['station_id']==98230);period=next(x for x in station['metadata']['period'] if x['key']=='corrected-archive');d,pr=c.get(json_url(period));archive_url=next(l['href'] for item in d['data'] for l in item['link'] if l['type']=='text/plain');data,ar=c.get(archive_url,document=True)
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),code_documentation=dict(url=code_url,request_id=cr['request_id'],raw=codes,public_page_url=url,public_page_request_id=r['request_id'],definition='100: Inget signifikant väder observerat',english='No significant weather observed'),humidity_source=dict(parameter='6',station_id=98230,url=archive_url,request_id=ar['request_id'],metadata_request_id=pr['request_id'],bytes=len(data)),new_requests=c.requests)
(ROOT/'reports/smhi_quality_and_codes.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('Source documentation saved; new requests',c.requests);print('CITY HUMIDITY', [x for x in data.decode('utf-8-sig').splitlines() if x.startswith(('2025-11-14;19:','2025-11-16;14:'))])
