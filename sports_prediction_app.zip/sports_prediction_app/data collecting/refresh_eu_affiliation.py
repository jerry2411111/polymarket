"""Use combined EU dated affiliation changes without rebuilding game statistics."""
import sqlite3
from build_history_catalog import DB

def refresh(db):
 assert db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_affiliation_daily'").fetchone();name='_player_affiliation_observations';sql=db.execute('SELECT sql FROM sqlite_master WHERE name=?',(name,)).fetchone()[0]
 if '_epl_affiliation_daily' in sql:
  assert sql.count('_epl_affiliation_daily')==1;sql=sql.replace('_epl_affiliation_daily','_eu_affiliation_daily');db.execute('DROP VIEW '+name);db.execute(sql)
 assert '_eu_affiliation_daily' in db.execute('SELECT sql FROM sqlite_master WHERE name=?',(name,)).fetchone()[0]

if __name__=='__main__':
 db=sqlite3.connect(DB,timeout=60)
 with db:refresh(db)
 print('Combined EU dated affiliations now used by performance SQL');db.close()
