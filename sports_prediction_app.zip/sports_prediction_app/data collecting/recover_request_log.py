"""One-time recovery: preserve the damaged original; exclude incomplete records.

No request metadata is invented. Missing requests are reacquired by normal cache
replay. Run only with all old shared-log writers stopped.
"""
import datetime as dt,hashlib,json
from probe_history import ROOT
def main():
 path=ROOT/'data/raw/requests.jsonl';body=path.read_bytes();backup=ROOT/'data/raw/request_log_recovery'/('original_'+hashlib.sha256(body).hexdigest()+'.bin');backup.parent.mkdir(exist_ok=True)
 if not backup.exists():backup.write_bytes(body)
 records=[];excluded=[]
 for n,line in enumerate(body.splitlines(),1):
  if not line.strip():continue
  try:
   r=json.loads(line)
   if r.get('raw_file') and hashlib.sha256((ROOT/r['raw_file']).read_bytes()).hexdigest()!=r['sha256']:raise ValueError('Response hash mismatch')
   records.append(r)
  except Exception as e:excluded.append(dict(line=n,error=str(e),bytes=len(line)))
 path.write_text(''.join(json.dumps(r)+'\n' for r in records),encoding='utf-8')
 known={r.get('raw_file') for r in records};orphans=[p.relative_to(ROOT).as_posix() for p in (ROOT/'data/raw/responses').iterdir() if p.relative_to(ROOT).as_posix() not in known]
 report=dict(original_log=backup.relative_to(ROOT).as_posix(),original_sha256=hashlib.sha256(body).hexdigest(),valid_records=len(records),excluded=excluded,unlinked_raw_responses=orphans,recovery='Unlinked responses are excluded; normal acquisition replay obtains new complete request records. Original bytes retained without alteration.')
 (ROOT/'reports/request_log_recovery.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
if __name__=='__main__':main()
