"""Test official season routing and small completed match rounds before expansion."""
import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

BASE='https://ma-api.ligue1.fr'
def main():
    HOSTS.add('ma-api.ligue1.fr');client=HistoryClient();rows=[]
    for year in [2023,2024,2025]:
        d,r=client.get(BASE+'/championship-calendar/1',dict(season=year));weeks=d['gameWeeks'];candidates=[w for w in weeks.values() if '2024-01-01'<=w['startDate'][:10]<='2026-09-14'];assert candidates;w=min(candidates,key=lambda w:w['startDate']);week=w['gameWeekNumber'];data,mr=client.get(BASE+f'/championship-matches/championship/1/game-week/{week}',dict(season=year));ms=data['matches'];row=dict(season=year,calendar_request_id=r['request_id'],game_weeks=len(weeks),week=week,expected_native_ids=w['matchesIds'],matches_request_id=mr['request_id'],response_type=type(ms).__name__,response_keys=list(data),preview=json.dumps(ms,ensure_ascii=False)[:3000]);rows.append(row);print(json.dumps(row),flush=True)
    (ROOT/'reports/ligue1_historical_pilot_sources.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=rows,new_requests=client.requests,client_match_endpoint_request_id='df1290367ad448008392780ce82601aa'),indent=2),encoding='utf-8')

if __name__=='__main__':main()
