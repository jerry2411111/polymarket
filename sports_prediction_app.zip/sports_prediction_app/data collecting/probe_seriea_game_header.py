"""Inspect official Serie A match-header route from the current league client."""
import datetime as dt,json,sqlite3
from urllib.parse import quote
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from probe_seriea_api import BASE
from probe_uefa_game_reports import shape

def main():
 db=sqlite3.connect(DB);c=HistoryClient();HOSTS.add('seriea-api.prd.sdp.deltatre.digital');rows=[]
 gs=sorted([json.loads(b) for b, in db.execute('SELECT body FROM _official_seriea_calendar')],key=lambda g:g['date'])[:3]
 for g in gs:
  m=g['raw'];print('CALENDAR FIELDS',list(g),list(m),flush=True);sid=m['seasonId'];mid=g['official_match_id'];url=BASE+'/seasons/'+quote(sid,safe='')+'/matches/'+quote(mid,safe='')+'/header'
  try:
   d,r=c.get(url);row=dict(match_id=mid,url=url,request_id=r['request_id'],status=r['status'],shape=shape(d));print(json.dumps(row),flush=True)
  except Exception as e:row=dict(match_id=mid,url=url,error=str(e));print(json.dumps(row),flush=True)
  rows.append(row)
 (ROOT/'reports/seriea_game_header_pilot.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),rows=rows,new_requests=c.requests),indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
