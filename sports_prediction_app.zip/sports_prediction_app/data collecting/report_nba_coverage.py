"""Report NBA coverage and missing values without confusing requests with games."""
import collections,datetime as dt,json,sqlite3,statistics
from build_history_catalog import DB
from probe_history import ROOT
from schema import HOURS

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    result=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),scope='NBA only; 2024-01-01 through 2026-09-14; all competitions',providers={})
    selected=collections.defaultdict(list)
    for (b,) in db.execute("SELECT body FROM _history_selections WHERE json_extract(body,'$.game_id') LIKE 'NBA_%'"):
        a=json.loads(b)
        if a['target'].startswith('pre_') and a['normalized_price'] is not None:selected[a['provider'],a['target']].append(a['source_age_seconds']/3600)
    unique=set()
    for provider in ['polymarket','kalshi']:
        rows=[dict(r) for r in db.execute(f"SELECT * FROM {provider}_pre_match WHERE league='NBA' ORDER BY date,game_id")]
        ing=[dict(r) for r in db.execute(f"SELECT * FROM {provider}_in_game WHERE league='NBA' ORDER BY game_id")]
        ids={r['game_id'] for r in rows};unique.update(ids);n=len(rows)
        report=dict(games_with_any_usable_odds=n,first_game_date=min((r['date'] for r in rows),default=None),last_game_date=max((r['date'] for r in rows),default=None),by_season=dict(sorted(collections.Counter(r['season'] for r in rows).items())),lookbacks={},missing_columns={})
        for h in HOURS:
            count=sum(r[f'team{s}_pre_{h}_p'] is not None for r in rows for s in 'AB');ages=sorted(selected[provider,'pre_'+str(h)])
            report['lookbacks'][str(h)]=dict(team_values_present=count,team_values_expected=2*n,missing_pct=round(100*(2*n-count)/(2*n),2) if n else None,median_quote_age_before_target_hours=statistics.median(ages) if ages else None,p95_quote_age_before_target_hours=ages[min(len(ages)-1,int(.95*len(ages)))] if ages else None,max_quote_age_before_target_hours=max(ages,default=None))
        report['games_with_all_requested_lookbacks_for_both_teams']=sum(all(r[f'team{s}_pre_{h}_p'] is not None for s in 'AB' for h in HOURS) for r in rows)
        for col in rows[0] if rows else []:
            missing=sum(r[col] is None for r in rows)
            if missing:report['missing_columns'][col]=dict(missing=missing,total=n,missing_pct=round(100*missing/n,2))
        report['in_game']={}
        for i,label in enumerate(['Start','Q1','Halftime','Q4']):
            available=sum(r[f'team{s}_ingame_p'].split(';')[i]!='null' for r in ing for s in 'AB')
            report['in_game'][label]=dict(team_values_present=available,team_values_expected=2*n,missing_pct=round(100*(2*n-available)/(2*n),2) if n else None)
        result['providers'][provider]=report
    result['distinct_games_across_providers']=len(unique)
    result['meaning']='A game with some odds is not a game with complete lookbacks. Missing odds are never filled from settlement values. Quote age is measured from the raw timestamp to each target, not to tip-off. For Polymarket aggregates, this is the maximum possible age because the raw timestamp is the bucket start; the whole bucket is required to finish before the target. Exact observation times inside those buckets are unavailable.'
    result['all_star_note']='Short-format All-Star games retain the four-slot schema, but nonexistent quarter breaks are null; temporary All-Star teams are not franchise transfers.'
    db.close();(ROOT/'reports/nba_coverage.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    lines=['# NBA coverage and missing values','',result['scope'],result['meaning'],'','| Provider | Games with some odds | All configured lookbacks, both teams | First game | Last game |','|---|---:|---:|---|---|']
    for p,r in result['providers'].items():lines.append(f'| {p} | {r["games_with_any_usable_odds"]} | {r["games_with_all_requested_lookbacks_for_both_teams"]} | {r["first_game_date"]} | {r["last_game_date"]} |')
    lines+=['','| Provider | Hours before start | Missing team probabilities | Median quote age before target (hours) | 95th percentile age |','|---|---:|---:|---:|---:|']
    for p,r in result['providers'].items():
        for h,v in r['lookbacks'].items():lines.append(f'| {p} | {h} | {v["missing_pct"]}% | {v["median_quote_age_before_target_hours"]} | {v["p95_quote_age_before_target_hours"]} |')
    lines+=['',result['all_star_note'],'','Detailed counts for every missing output column, checkpoint and season are in `nba_coverage.json`.']
    (ROOT/'reports/nba_coverage.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({p:{k:v for k,v in r.items() if k in ['games_with_any_usable_odds','games_with_all_requested_lookbacks_for_both_teams','first_game_date','last_game_date']} for p,r in result['providers'].items()}))

if __name__=='__main__':main()
