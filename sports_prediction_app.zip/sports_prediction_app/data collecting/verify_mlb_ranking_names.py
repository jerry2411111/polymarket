"""Verify exceptional ranking names with official MLB identity pages."""
import datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT
from official_redirects import get

PAGES=[('MLB:622491','https://www.mlb.com/player/luis-castillo-622491','Luis Castillo'),('MLB:621242','https://www.mlb.com/player/edwin-diaz-621242','Edwin'),('MLB:687263','https://www.mlb.com/angels/player/zach-neto-687263','Zachary Adam Neto'),('MLB:682829','https://www.mlb.com/player/elly-de-la-cruz-682829/','Elly De La Cruz')]
def main():
 c=HistoryClient();rows=[];db=sqlite3.connect(DB,timeout=60)
 for pid,url,needle in PAGES:
  b,r,redirects=get(c,url);s=BeautifulSoup(b,'html.parser');t=s.get_text(' ',strip=True);assert needle in t and pid.split(':')[1] in url
  aliases=['Zachary Neto'] if pid=='MLB:687263' else ['Elly Da La Cruz'] if pid=='MLB:682829' else ['Luis Castillo'] if pid=='MLB:622491' else ['Edwin Diaz']
  for alias in aliases:
   row=dict(alias=alias,player_id=pid,source_url=url,request_id=r['request_id'],official_name_evidence=needle,required_ranking_context='Mariners' if pid=='MLB:622491' else 'Mets' if pid=='MLB:621242' else None,note='FOX misspelling corrected only in this Reds ranking entry' if pid=='MLB:682829' else 'Official full-name/native-ID evidence; ambiguous duplicate names additionally require the published club context')
   row['redirects']=redirects;rows.append(row)
 db.execute('CREATE TABLE IF NOT EXISTS _mlb_verified_ranking_aliases (alias TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _mlb_verified_ranking_aliases VALUES (?,?)',[(r['alias'],json.dumps(r)) for r in rows]);db.commit();db.close()
 (ROOT/'reports/mlb_ranking_identity_verification.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),rows=rows),indent=2),encoding='utf-8');print('Verified official ranking identity sources',len(rows))

if __name__=='__main__':main()
