"""Refresh both Kalshi storage tiers and retain duplicate-route diagnostics."""
import argparse,datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT

BASE='https://external-api.kalshi.com/trade-api/v2'
DOCS=['https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps.md','https://docs.kalshi.com/api-reference/historical/get-historical-markets.md','https://docs.kalshi.com/api-reference/market/get-markets.md','https://docs.kalshi.com/api-reference/milestone/get-milestones.md']

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--league',required=True,choices=['MLB','NHL']);a=ap.parse_args();c=HistoryClient();docs=[]
    for url in DOCS:
        b,r=c.get(url,document=True);assert b'GET' in b or b'get:' in b;docs.append(dict(url=url,request_id=r['request_id']))
    cutoff,r=c.get(BASE+'/historical/cutoff',refresh=True);assert all(k in cutoff for k in ['market_settled_ts','trades_created_ts']);out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),league=a.league,cutoff=cutoff,cutoff_request_id=r['request_id'],documentation=docs,routes=[]);market_sets=[]
    jobs=[('/historical/markets',dict(series_ticker='KX'+a.league+'GAME',limit=1000),'markets'),('/markets',dict(series_ticker='KX'+a.league+'GAME',limit=1000),'markets'),('/milestones',dict(competition=a.league,minimum_start_date='2024-01-01T00:00:00Z',limit=500),'milestones')]
    for path,params,key in jobs:
        seen=set();cursors=set();requests=[];error=None;oldest=None;newest=None
        try:
            for page in range(1000):
                d,r=c.get(BASE+path,params,refresh=True);requests.append(r['request_id'])
                for x in d[key]:
                    native=x.get('ticker') or x['id'];assert native not in seen,'Repeated native ID across pages';seen.add(native)
                    day=x.get('start_date') or x.get('occurrence_datetime') or x.get('close_time')
                    if day:oldest=min(oldest or day,day);newest=max(newest or day,day)
                cursor=d.get('cursor')
                if not cursor:break
                assert cursor not in cursors,'Repeated pagination cursor';cursors.add(cursor);params['cursor']=cursor
            else:raise ValueError('Pagination safety bound exceeded')
        except Exception as e:error=str(e)
        if key=='markets':market_sets.append(seen)
        out['routes'].append(dict(endpoint=BASE+path,rows=len(seen),pagination_exhausted=error is None,error=error,earliest_source_datetime=oldest,latest_source_datetime=newest,request_ids=requests))
        print('KALSHI METADATA',a.league,path,'rows',len(seen),'pages',len(requests),'status',error or 'exhausted',flush=True)
    out['markets_in_both_routes']=sorted(market_sets[0]&market_sets[1]);out['new_requests']=c.requests
    (ROOT/'reports'/(a.league.lower()+'_kalshi_metadata_refresh.json')).write_text(json.dumps(out,indent=2),encoding='utf-8');print('KALSHI CUTOFF',json.dumps(cutoff),'duplicate route IDs',len(out['markets_in_both_routes']),flush=True)

if __name__=='__main__':main()
