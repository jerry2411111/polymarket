"""Publish only games with an observed in-game probability; retain coverage audit."""
import collections,csv,datetime as dt,hashlib,json,sqlite3
import pyarrow as pa
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT
def has_quotes(row):return any(present(row.get(side+'_ingame_p')) for side in ['teamA','teamB','draw'])

def present(value):return value is not None and any(v.strip().lower() not in ['','none','nan','null'] for v in value.split(';'))
db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;outputs=[];now=dt.datetime.now(dt.UTC).isoformat()
for report in ['nba_main_validation.json','mlb_outputs_validation.json','nhl_outputs_validation.json']:assert json.loads((ROOT/'reports'/report).read_text())['status']=='WORKING'
with db:db.execute('CREATE TABLE IF NOT EXISTS _empty_in_game_exclusions (provider TEXT,game_id TEXT,reason TEXT,recorded_at_utc TEXT,PRIMARY KEY(provider,game_id)) STRICT')
for provider in ['polymarket','kalshi']:
 table=provider+'_in_game';dest=ROOT/'data/result'/provider;rows=[dict(r) for r in db.execute('SELECT * FROM '+table)];cols=list(rows[0]);existing=pq.read_table(dest/'in_game.parquet');old=existing.to_pylist();assert {r['game_id']:r for r in rows}=={r['game_id']:r for r in old},'Existing SQL and validated Parquet disagree';kept=[r for r in old if has_quotes(r)];removed=[r for r in old if not(has_quotes(r))]
 with db:
  db.executemany('INSERT OR IGNORE INTO _empty_in_game_exclusions VALUES (?,?,?,?)',[(provider,r['game_id'],'No observed probability at any official in-game checkpoint',now) for r in removed]);db.executemany('DELETE FROM '+table+' WHERE game_id=?',[(r['game_id'],) for r in removed])
 assert {r['game_id']:dict(r) for r in db.execute('SELECT * FROM '+table)}=={r['game_id']:r for r in kept}
 with (dest/'in_game.csv').open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(kept)
 pq.write_table(pa.Table.from_pylist(kept,schema=existing.schema),dest/'in_game.parquet',compression='zstd');assert pq.read_table(dest/'in_game.parquet').to_pylist()==kept
 with (dest/'in_game.csv').open(newline='',encoding='utf-8') as f:assert list(csv.DictReader(f))==[{k:'' if v is None else str(v) for k,v in r.items()} for r in kept]
 output=dict(provider=provider,before=len(old),removed_empty_rows=len(removed),retained=len(kept),removed_by_league=dict(collections.Counter(r['league'] for r in removed)),retained_by_league=dict(collections.Counter(r['league'] for r in kept)),unchanged_retained_values_sha256=hashlib.sha256(json.dumps(kept,sort_keys=True,separators=(',',':')).encode()).hexdigest());outputs.append(output);print(json.dumps(output),flush=True)
out=dict(generated_at_utc=now,status='WORKING',outputs=outputs,scope='Only empty in-game result rows removed. Main-game rows, usable checkpoint values and raw evidence unchanged. All missing-game coverage remains measurable against provider main tables and the internal exclusion audit.');(ROOT/'reports/in_game_publication_cleanup.json').write_text(json.dumps(out,indent=2),encoding='utf-8');db.close()
