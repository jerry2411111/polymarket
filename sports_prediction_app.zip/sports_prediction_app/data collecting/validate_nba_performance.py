"""Real-data source and temporal checks, independently recomputed from facts."""
import collections,datetime as dt,hashlib,json,math,re,sqlite3,statistics,time
from build_history_catalog import DB
from build_nba_performance import identity_keys
from enrich_history_games import parse_book
from probe_history import ROOT
from temporal_queries import PLAYER_SQL,TEAM_SQL

def equivalent(a,b):
    if a is None or b is None:return a is b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):return math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-8)
    return a==b

def main():
    begun=time.monotonic();db=sqlite3.connect(DB);db.row_factory=sqlite3.Row
    games={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_games')}
    facts=[json.loads(b) for (b,) in db.execute('SELECT body FROM _nba_player_game_facts')]
    names=collections.defaultdict(set)
    for p in facts:names[p['player_id']].add(p['player_name'])
    assert all(len(v)==1 for v in names.values()),'A native player ID has multiple display names'
    played=[p for p in facts if p['did_play']]
    totals=collections.defaultdict(float)
    for p in played:totals[p['game_id'],p['side']]+=p['score']
    for (gid,side),n in totals.items():assert n==games[gid]['scores'][side],('Official team score mismatch',gid,side)
    checks=[]
    for day in ['2024-06-01','2025-02-16','2026-01-15','2026-09-14']:
        start='2024-01-01';params=dict(query_date=day,collection_start=start)
        direct=[dict(r) for r in db.execute(PLAYER_SQL,params)]
        view=[dict(r) for r in db.execute('SELECT * FROM player_performance WHERE as_of_date=?',(day,))]
        assert len(direct)==len(view)
        groups=collections.defaultdict(list)
        for b in view:groups[b['league'],b['player_name']].append(b)
        for a in direct:
            candidates=groups[a['league'],a['player_name']]
            hits=[i for i,b in enumerate(candidates) if a.keys()==b.keys() and all(equivalent(a[k],b[k]) for k in a)]
            assert hits,('Date view differs from bounded query',day,a,candidates)
            candidates.pop(hits[0])
        bounded=[p for p in played if start<=p['game_date']<=day]
        assert sum(r['games_played'] for r in direct if r['league']=='NBA')==len(bounded),'Future game or duplicate person entered past aggregate'
        assert not any(r['team'] in {'Team World','USA Stars','USA Stripes',"Kenny's Young Stars","Chuck's Global Stars","Shaq's OGs","Candace's Rising Stars"} for r in direct if r['league']=='NBA')
        team=[dict(r) for r in db.execute(TEAM_SQL,params)]
        stored=[dict(r) for r in db.execute('SELECT * FROM team_history WHERE as_of_date=? ORDER BY league,team_name',(day,))]
        assert len(team)==len(stored)
        for a,b in zip(team,stored):
            for k in a:assert equivalent(a[k],b[k]),('Team snapshot differs from past-only query',day,k)
        ps=[p for p in bounded if p['player_id']=='NBA:1630552']
        if ps:
            native=db.execute('SELECT * FROM _player_performance_periods WHERE player_id=? AND effective_from<=? AND effective_to>?',('NBA:1630552',day,day)).fetchone()
            for source,label in [('score','score'),('assists','assists'),('minutes','minutes')]:
                values=[p[source] for p in ps]
                assert all(v is not None for v in values)
                assert equivalent(native['average_'+label+'_per_game'],statistics.mean(values))
                assert equivalent(native['std_'+label+'_per_game'],statistics.stdev(values) if len(values)>1 else None)
        checks.append(dict(query_date=day,player_rows=len(direct),nba_appearances_through_date=len(bounded),team_rows=len(team),sql_view_equals_direct_bounded_query=True))
    selected=[next(p for p in played if p['game_id']=='NBA_20251006_ATL_HOU' and p['player_id']=='NBA:1630552'),next(p for p in played if p['game_id']=='NBA_20250718_DAL_ORL' and p['player_id']=='NBA:1642888'),next(p for p in played if p['temporary_team'])]
    source_checks=[]
    for p in selected:
        r=db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(p['request_id'],)).fetchone();assert r
        r=json.loads(r[0]);body=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(body).hexdigest()==r['sha256']
        if body.startswith(b'%PDF'):
            raw=parse_book(body,games[p['game_id']])
            ns=identity_keys(p['player_name'])|identity_keys(p['source_player_name'])
            hits=[x for x in raw['players'] if x['side']==p['side'] and identity_keys(x['name'])&ns]
            assert len(hits)==1,('Ambiguous independent scorer identity',p['game_id'],p['player_name'])
            raw=hits[0]
            vals={k:raw[k] for k in ['score','assists','minutes','starter']}
        else:
            script=re.search(rb'<script\b[^>]*\bid="__NEXT_DATA__"[^>]*>(.*?)</script>',body,re.S);raw=json.loads(script[1])
            for key in p['pointer'].strip('/').split('/'):raw=raw[int(key)] if isinstance(raw,list) else raw[key]
            assert str(raw['personId'])==p['official_player_id']
            st=raw['statistics'];vals=dict(score=st['points'],assists=st['assists'])
        for k,v in vals.items():assert equivalent(v,p[k]),('Raw player statistic differs',p['game_id'],k)
        source_checks.append(dict(game_id=p['game_id'],player_id=p['player_id'],player_name=p['player_name'],source_url=r['endpoint'],request_id=r['request_id'],raw_values=vals,normalized_values={k:p[k] for k in vals},match=True))
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='NBA player game statistics and cumulative player/team performance. Does not certify biographies, contracts, injury history, coach history, rankings or weather.',nba_roster_rows=len(facts),nba_played_appearances=len(played),team_score_sum_checks=len(totals),temporal_examples=checks,raw_player_examples=source_checks,elapsed_seconds=round(time.monotonic()-begun,2))
    (ROOT/'reports/nba_performance_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));db.close()

if __name__=='__main__':main()
