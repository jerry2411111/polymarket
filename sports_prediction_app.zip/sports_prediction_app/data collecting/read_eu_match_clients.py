"""Read official match pages and their own scripts to discover current public routes."""
import argparse,datetime as dt,json,re,sqlite3
from urllib.parse import urljoin,urlsplit,quote
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS

def main():
 ap=argparse.ArgumentParser();ap.add_argument('competition',choices=['BUN','LAL','FL1','SEA']);a=ap.parse_args();db=sqlite3.connect(DB);table={'BUN':'bundesliga','LAL':'laliga','FL1':'ligue1','SEA':'seriea'}[a.competition];g=json.loads(db.execute('SELECT body FROM _official_'+table+'_calendar LIMIT 1').fetchone()[0]);m=g['raw']
 if a.competition=='BUN':url='https://www.bundesliga.com/en/bundesliga/matchday/'+g['season'][:4]+'-'+str(int(g['season'][:4])+1)+'/'+str(m['matchday'])+'/'+m['slugs']['slugLong']+'/liveticker'
 elif a.competition=='LAL':url='https://www.laliga.com/en-GB/match/'+m['slug']
 elif a.competition=='FL1':url='https://ligue1.com/match-sheet/'+g['official_match_id']
 else:url='https://www.legaseriea.it/serie-a/match/'+quote(g['official_match_id'],safe='')+'/'+g['home']['name'].lower().replace(' ','-')+'-vs-'+g['away']['name'].lower().replace(' ','-')
 HOSTS.add(urlsplit(url).hostname);c=HistoryClient();b,r,redirects=get(c,url);soup=BeautifulSoup(b,'html.parser');print('PAGE',r['request_id'],url,'TITLE',soup.title.get_text() if soup.title else None,flush=True);rows=[]
 for script in soup.find_all('script',type='application/json'):
  try:
   d=json.loads(script.get_text());print('HYDRATION KEYS',list(d)[:30],flush=True)
  except Exception:pass
 base=soup.find('base',href=True);base_url=urljoin(url,base['href']) if base else url
 urls=[urljoin(base_url,t['src']) for t in soup.find_all('script',src=True)]
 urls += [urljoin(base_url,t['href']) for t in soup.find_all('link',href=True) if t['href'].endswith('.js') and 'modulepreload' in t.get('rel',[])]
 # Next's streamed module references also name client chunks that have no
 # script src element in the server HTML. Read only explicit same-site files.
 if a.competition=='SEA':urls += [urljoin(url,'/_next/'+p) for p in re.findall(r'static/chunks/[A-Za-z0-9_./%\[\]-]+\.js',b.decode('utf-8'))]
 for u in dict.fromkeys(urls):
  if urlsplit(u).hostname!=urlsplit(url).hostname:continue
  if any(x in u for x in ['polyfills','webpack','framework','gtag']):continue
  try:
   b,sr=c.get(u,document=True);s=b.decode();assert not s.lstrip().lower().startswith('<!doctype html'),'The script URL returned HTML';row=dict(url=u,request_id=sr['request_id'],bytes=len(b));rows.append(row)
   for h in list(re.finditer(r'championship-match[s]?/|/lineups|/timeline|/events|/matches/|matchDetail|match-details|firebaseio|firebasedatabase',s))[:5]:
    context=s[max(0,h.start()-80):h.end()+250].replace('\\"','"');context=re.sub(r'(?i)((?:api[_-]?key|key|token|secret|password)[\w-]*["\x27]?\s*[:=]\s*["\x27])[^"\x27]+',r'\1[redacted]',context);print('CLIENT',sr['request_id'],h.start(),context,flush=True)
  except Exception as e:print('CLIENT ERROR',u,str(e),flush=True)
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),competition=a.competition,page_url=url,page_request_id=r['request_id'],redirects=redirects,scripts=rows,new_requests=c.requests);(ROOT/'reports'/(table+'_match_client.json')).write_text(json.dumps(report,indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
