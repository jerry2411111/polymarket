"""Small unauthenticated probes of routes in UEFA's current official match client."""
import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

BASE='https://match.uefa.com'
def main():
 HOSTS.add('match.uefa.com');c=HistoryClient();out=[]
 for params in [dict(competitionId='1',seasonYear=2024,limit=3,offset=0,order='ASC',fromDate='2024-01-01',toDate='2024-06-30')]:
  url=BASE+'/v5/matches'
  try:
   d,r=c.get(url,params);item=dict(endpoint=url,parameters=params,request_id=r['request_id'],status=r['status'],response_type=type(d).__name__,items=len(d),data=d);print(json.dumps({**item,'data':[{k:m.get(k) for k in ['id','kickOffTime','score','status','type','seasonYear','fullTimeAt']}|{'away':m['awayTeam']['translations']['displayOfficialName']['EN'],'home':m['homeTeam']['translations']['displayOfficialName']['EN']} for m in d]},ensure_ascii=False),flush=True)
  except Exception as e:item=dict(endpoint=url,parameters=params,error=str(e));print(json.dumps(item),flush=True)
  out.append(item)
 (ROOT/'reports/uefa_api_pilot.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),client_request_ids=['c0fead904907420cb10e7a60ab34098f','5200e0ff021a48ee990e39150d3c6320'],probes=out,new_requests=c.requests),indent=2),encoding='utf-8')

if __name__=='__main__':main()
