"""Report measured field gaps and source quote ages in the published NHL tables."""
import collections,csv,datetime as dt,json,sqlite3,statistics
from build_history_catalog import DB
from probe_history import ROOT
from export_mlb_support_tables import TABLES
from schema import HOURS

def main():
    db=sqlite3.connect(DB);fields=[];outputs=[]
    for table in TABLES:
        report=json.loads((ROOT/'reports'/('nhl_'+table+'_export.json')).read_text());outputs.append(dict(table=table,rows=report['rows'],columns=report['columns']))
        fields.extend(dict(table=table,column=c,missing=v['count'],total=v['total'],missing_percentage=v['percentage']) for c,v in report['missing'].items())
    for provider in ['polymarket','kalshi']:
        table=provider+'_pre_match';cols=[r[1] for r in db.execute('PRAGMA table_info('+table+')')];row=db.execute('SELECT count(*),'+','.join('sum("'+c+'" IS NULL)' for c in cols)+' FROM '+table+" WHERE league='NHL'").fetchone();n=row[0];outputs.append(dict(table=table,rows=n,columns=len(cols)))
        fields.extend(dict(table=table,column=c,missing=k,total=n,missing_percentage=round(k*100/n,4)) for c,k in zip(cols,row[1:]))
    selections=[json.loads(b) for b, in db.execute("SELECT body FROM _history_selections WHERE json_extract(body,'$.game_id') LIKE 'NHL_%'")];providers={}
    for provider in ['polymarket','kalshi']:
        rs=[r for r in selections if r['provider']==provider];games=collections.defaultdict(list);points=[];ages={}
        for r in rs:
            if r['target'].startswith('ingame_'):games[r['game_id']].append(r)
        for i,label in enumerate(['Start','P1','P2']):
            part=[r for r in rs if r['target']=='ingame_'+str(i)];missing=sum(r['normalized_price'] is None for r in part);points.append(dict(checkpoint=label,values=len(part),missing=missing,missing_percentage=round(missing*100/len(part),4) if part else None,zero_probability=sum(r['normalized_price']==0 for r in part)))
        for h in HOURS:
            values=[r['source_age_seconds']/3600 for r in rs if r['target']=='pre_'+str(h) and r['normalized_price'] is not None];ages['pre_'+str(h)]=dict(values=len(values),minimum_hours=min(values) if values else None,median_hours=statistics.median(values) if values else None,maximum_hours=max(values) if values else None)
        providers[provider]=dict(games=len(games),all_three_checkpoints_both_teams=sum(len(v)==6 and all(r['normalized_price'] is not None for r in v) for v in games.values()),any_in_game_value=sum(any(r['normalized_price'] is not None for r in v) for v in games.values()),checkpoints=points,quote_age_from_target=ages)
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',tables=outputs,fields=fields,provider_quote_coverage=providers,limitations=['NHL dated injury collection remains incomplete. Unreported injury=false/zero is the user-selected default, not verified health.','Media rankings have six independent publishers; ten remains unmet.','Some career, current-team tenure and prior-day roster/coach links remain unknown.','Older Polymarket observations can be hours or days before their target. Source ages are retained, never hidden by relabeling a bucket.','NHL uses three sport-specific checkpoints: opening and the first two intermissions.'])
    (ROOT/'reports/nhl_coverage.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    with (ROOT/'reports/nhl_missing_fields.csv').open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=['table','column','missing','total','missing_percentage']);w.writeheader();w.writerows(fields)
    lines=['# Published NHL coverage and remaining gaps','','Status: **PARTIALLY WORKING**. Values have been independently validated; history and field coverage remain incomplete.','','| Table | Column | Missing / total | Missing % |','|---|---|---:|---:|']+[f"| {r['table']} | {r['column']} | {r['missing']:,} / {r['total']:,} | {r['missing_percentage']} |" for r in fields if r['missing']]
    lines+=['','## In-game probability coverage','','| Provider | Checkpoint | Missing / values | Missing % |','|---|---|---:|---:|']
    for p,v in providers.items():lines += [f"| {p} | {r['checkpoint']} | {r['missing']} / {r['values']} | {r['missing_percentage']} |" for r in v['checkpoints']]
    lines+=['','## Limitations','']+['- '+x for x in report['limitations']];(ROOT/'reports/nhl_coverage.md').write_text('\n'.join(lines)+'\n',encoding='utf-8');print(json.dumps(dict(status=report['status'],provider_quote_coverage=providers)));db.close()

if __name__=='__main__':main()
