"""A historical display-name change must never split a native person's statistics."""
import collections,datetime as dt,json,math,sqlite3,statistics
from build_history_catalog import DB
from temporal_queries import QUERIES
from probe_history import ROOT

def main():
 db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;allfacts=[dict(r) for r in db.execute("SELECT * FROM _player_game_results WHERE league='EU soccer' ORDER BY game_date,game_id")];checks=collections.Counter();examples=[]
 for start,end in [('2024-01-01','2025-12-31'),('2024-01-01','2026-09-14'),('2025-07-01','2026-09-14')]:
  groups=collections.defaultdict(list)
  for r in allfacts:
   if start<=r['game_date']<=end:groups[r['player_id']].append(r)
  rows=[dict(r) for r in db.execute('SELECT * FROM ('+QUERIES['player_performance']+") WHERE league='EU soccer'",dict(collection_start=start,query_date=end))];assert len(rows)==len(groups)==len({r['player_id'] for r in rows});means={pid:statistics.mean(x['score'] for x in xs) for pid,xs in groups.items() if all(x['score'] is not None for x in xs)};mu=statistics.mean(means.values());sigma=statistics.pstdev(means.values())
  for r in rows:
   xs=groups[r['player_id']];assert r['player_name']==xs[-1]['player_name'] and r['games_played']==len(xs);assert math.isclose(r['overall_winrate'],statistics.mean(x['win'] for x in xs),rel_tol=1e-12);checks['native_identity_latest_name_and_count']+=1
   if r['player_id'] in means:assert math.isclose(r['score_z_score'],(means[r['player_id']]-mu)/sigma,rel_tol=1e-9,abs_tol=1e-9);checks['unsplit_player_cohort_z_score']+=1
   names={x['player_name'] for x in xs}
   if len(names)>1:checks['real_name_change_regressions']+=1;examples.append(dict(player_id=r['player_id'],query_start=start,query_date=end,source_names=sorted(names),selected_name=r['player_name'],single_person_games=r['games_played']))
  print('PLAYER QUERY NAME VALIDATION',start,end,len(rows),'people',flush=True)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',checks=dict(checks),examples=examples);(ROOT/'reports/player_query_name_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='examples'}));db.close()

if __name__=='__main__':main()
