"""Recheck every reviewed location correction against retained official evidence."""
import collections,datetime as dt,hashlib,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from epl_price_points import Sources,pointer
from eu_official_games import games
from probe_history import ROOT

db=sqlite3.connect(DB);src=Sources(db);checks=collections.Counter();cache={};official={g['game_id']:g for c in ['SEA','FL1'] for g in games(db,c).values()}
for gid,b in db.execute('SELECT * FROM _eu_game_location_corrections'):
 r=json.loads(b);rid=r['request_id']
 if rid not in cache:
  meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);raw=(ROOT/meta['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==meta['sha256'] and meta['status']==200 and meta['endpoint']==r['url'];cache[rid]=' '.join(BeautifulSoup(raw,'html.parser').stripped_strings)
 text=cache[rid];g=official[gid];assert (g.get('official_match_id') or g.get('match_id'))==r['official_match_id']
 if r['competition_code']=='SEA':assert 'Fiorentina' in g['home']['name'] and 'Artemio Franchi' in r['venue'] and 'Artemio Franchi' in text and 'Firenze' in text and (r['city'],r['country'])==('Firenze','IT')
 else:
  p=r['uefa_stadium_proof'];raw,_=src.get(p['request_id']);assert pointer(raw,p['pointer'])==p['raw'];v=p['raw'];assert v['countryCode']=='MCO' and v['city']['translations']['name']['EN']=='Monaco' and 'louis' in r['venue'].lower() and (r['city'],r['country'])==('Monaco','MC') and 'Monaco' in text;checks['independent_UEFA_stadium_country']+=1
 current=json.loads(db.execute('SELECT body FROM _eu_game_weather_locations WHERE game_id=?',(gid,)).fetchone()[0]);assert current['country']==r['country'] and current['raw_city']==r['city'];checks['reviewed_location_used_in_weather_binding']+=1
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',checks=dict(checks),official_document_hashes=len(cache),official_API_hashes=len(src.cache),scope='The 38 reviewed corrections only; no odds or score values are changed.');(ROOT/'reports/eu_location_corrections_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
