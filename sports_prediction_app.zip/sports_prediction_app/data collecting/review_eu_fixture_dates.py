"""Retain bounded official-fixture corrections with original provider dates intact.

Nearby-date inference requires both native clubs, one unique fixture within
two days, and every contract settling within 48 hours after that fixture.
Explicit provider event start corrections may cover a longer postponement.
"""
import collections,datetime as dt,json,re,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from eu_official_games import CONFIG,games
from core import utc

def main():
 db=sqlite3.connect(DB,timeout=60);official={code:games(db,code) for code in CONFIG};reviews=[];pending=[]
 for code,b in db.execute('SELECT competition,body FROM _eu_matching_issues'):
  issue=json.loads(b)
  if not any(t in issue['reason'] for t in ['date','six hours']):continue
  provider=issue['provider'];fid=issue['family_id'];cs=[];source_ids=[];event_start=None
  if provider=='polymarket':
   rid,ptr,b=db.execute('SELECT request_id,pointer,body FROM _eu_pm_events WHERE event_id=?',(fid,)).fetchone();e=json.loads(b);source_ids=[rid];cs=[m for m in e['markets'] if m.get('sportsMarketType') in [None,'moneyline'] and re.match(r'Will ',m.get('question','').strip())];settled=[utc(m.get('closedTime')) for m in cs];event_start=utc(e.get('startTime'))
  else:
   records=db.execute("SELECT request_id,pointer,body FROM _eu_kalshi_markets WHERE competition=? AND json_extract(body,'$.event_ticker')=?",(code,fid)).fetchall();cs=[json.loads(r[2]) for r in records];source_ids=list(dict.fromkeys(r[0] for r in records));settled=[utc(m.get('settlement_ts') or m.get('settlement_time') or m.get('close_time')) for m in cs]
  if len(cs)!=3:pending.append(issue);continue
  original=issue.get('date');tids=set(issue.get('team_ids',[]));found=[];basis=None
  if issue.get('official_match_id'):found=[official[code][issue['official_match_id']]];basis='Exact provider date and both clubs; official kickoff supersedes provider time-of-day'
  elif event_start and tids:
   found=[g for g in official[code].values() if g['date']==event_start.date().isoformat() and {g['away']['id'],g['home']['id']}==tids]
   if len(found)==1:basis='Provider event start was updated while child-contract start dates stayed old; exact corrected date and both official clubs'
  if len(found)!=1 and original and tids:
   found=[g for g in official[code].values() if abs((dt.date.fromisoformat(g['date'])-dt.date.fromisoformat(original)).days)<=2 and {g['away']['id'],g['home']['id']}==tids];basis='Unique same-club fixture within two days, corroborated by all three contract settlement times'
  if len(found)!=1 or not all(settled):pending.append(issue);continue
  g=found[0];start=utc(g['scheduled_start_utc'])
  if not all(0<(s-start).total_seconds()<=48*3600 for s in settled):pending.append(issue);continue
  reviews.append(dict(competition=code,provider=provider,family_id=fid,official_match_id=g['official_match_id'],original_issue=issue,source_request_ids=source_ids,official_request_id=g['request_id'],official_pointer=g['pointer'],official_date=g['date'],official_start_utc=g['scheduled_start_utc'],official_team_ids=[g['away']['id'],g['home']['id']],settled_timestamps=[s.isoformat() for s in settled],basis=basis))
 # This 2024 event's description explicitly names May 1 and the first leg;
 # endDate was later changed to May 7, which is the reverse fixture.
 rid,ptr,b=db.execute("SELECT request_id,pointer,body FROM _eu_pm_events WHERE event_id='10513'").fetchone();e=json.loads(b);ms=e['markets'];assert len(ms)==3 and all('1st leg' in m['description'] and 'May 1' in m['description'] for m in ms);gs=[g for g in official['UCL'].values() if g['date']=='2024-05-01' and {g['away']['id'],g['home']['id']}=={'52747','52758'}];assert len(gs)==1;g=gs[0];assert g['raw']['type']=='FIRST_LEG';reviews.append(dict(competition='UCL',provider='polymarket',family_id='10513',official_match_id=g['official_match_id'],source_request_ids=[rid],official_request_id=g['request_id'],official_pointer=g['pointer'],official_date=g['date'],official_start_utc=g['scheduled_start_utc'],official_team_ids=[g['away']['id'],g['home']['id']],required_description_fragments=['1st leg','May 1'],basis='All three written contract rules explicitly identify May 1 first leg; changed endDate May 7 belongs to the reverse fixture'))
 # Barcelona-Atlético has one erroneous child date; all three written rules
 # identify the same dated game, corroborated by the official native fixture.
 rid,ptr,b=db.execute("SELECT request_id,pointer,body FROM _eu_pm_events WHERE event_id='15632'").fetchone();e=json.loads(b);assert len(e['markets'])==3 and all('December 21, 2024' in m['description'] for m in e['markets']);gs=[g for g in official['LAL'].values() if g['date']=='2024-12-21' and {g['away']['id'],g['home']['id']}=={'2','4'}];assert len(gs)==1;g=gs[0];reviews.append(dict(competition='LAL',provider='polymarket',family_id='15632',official_match_id=g['official_match_id'],source_request_ids=[rid],official_request_id=g['request_id'],official_pointer=g['pointer'],official_date=g['date'],official_start_utc=g['scheduled_start_utc'],official_team_ids=[g['away']['id'],g['home']['id']],required_description_fragments=['December 21, 2024'],basis='All three written rules agree on December 21; one child gameStartTime incorrectly says December 20'))
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _eu_fixture_date_reviews (competition TEXT NOT NULL,provider TEXT NOT NULL,family_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(competition,provider,family_id)) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_fixture_date_reviews VALUES (?,?,?,?)',[(r['competition'],r['provider'],r['family_id'],json.dumps(r)) for r in reviews])
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),reviews=reviews,pending=pending,status='REQUIRES_MATCHER_REBUILD_AND_INDEPENDENT_VALIDATION');(ROOT/'reports/eu_fixture_date_reviews.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('REVIEWED',len(reviews),'PENDING',len(pending),dict(collections.Counter((r['competition'],r['provider']) for r in reviews)),flush=True);db.close()

if __name__=='__main__':main()
