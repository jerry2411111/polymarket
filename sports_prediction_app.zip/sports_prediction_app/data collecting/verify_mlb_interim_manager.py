"""Verify formal/acting-manager distinctions against dated MLB reporting."""
import datetime as dt,json
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT

c=HistoryClient();pages=[]
urls=[
'https://www.mlb.com/news/ron-washington-not-managing-angels-health-issue',
'https://www.mlb.com/press-release/ron-washington-to-remain-on-medical-leave-through-end-of-the-season',
'https://www.mlb.com/news/ryan-goins-serves-as-angels-manager-for-two-games',
]
for url in urls:
    b,r=c.get(url,document=True);s=BeautifulSoup(b,'html.parser');article=s.find('article') or s;txt=article.get_text(' ',strip=True);assert 'Montgomery' in txt
    pages.append(dict(url=url,request_id=r['request_id'],metadata=[json.loads(x.string) for x in s.find_all('script',type='application/ld+json') if x.string],text=txt))
dates=[]
for day in ['2025-06-19','2025-06-20','2025-06-26','2025-06-27','2025-09-13','2025-09-14']:
    d,r=c.get('https://statsapi.mlb.com/api/v1/teams/108/coaches',dict(date=day));xs=[dict(x,pointer='/roster/'+str(n)) for n,x in enumerate(d['roster']) if x.get('jobId') in ['MNGR','NTRM'] or x.get('person',{}).get('fullName') in ['Ray Montgomery','Ryan Goins']];dates.append(dict(date=day,request_id=r['request_id'],coaches=xs))
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),source_pages=pages,dated_examples=dates,new_requests=c.requests)
(ROOT/'reports/mlb_interim_manager_verification.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(dict(dated_examples=dates,new_requests=c.requests)))
