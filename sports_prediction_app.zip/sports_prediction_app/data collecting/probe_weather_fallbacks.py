import concurrent.futures,io,json
import pyarrow.parquet as pq
from history_client import HistoryClient
from probe_history import ROOT

c=HistoryClient()
jobs=[(s,y) for s in ['CAN06158731','CAA00712654','CAN06158666','CAU60-00150'] for y in ['2024','2025','2026']]+[(s,'2025') for s in ['CAN01108395','CAN01108446','CAU071892-1','MCI0000VMMC','MCU74-00016']]+[(s,'2026') for s in ['GMI0000EDDB','GMM00009385']]
def task(key):
    s,y=key;url=f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{y}/parquet/GHCNh_{s}_{y}.parquet'
    try:
        b,r=c.get(url,document=True);p=pq.ParquetFile(io.BytesIO(b));dates=p.read(columns=['DATE']).column('DATE').to_pylist()
        return dict(station=s,year=y,status='ok',rows=len(dates),first=min(map(str,dates)),last=max(map(str,dates)),request_id=r['request_id'])
    except Exception as e:return dict(station=s,year=y,status='unavailable',error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    out=[]
    for x in pool.map(task,jobs):out.append(x);print(json.dumps(x),flush=True)
(ROOT/'reports/weather_station_fallbacks.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
