"""Validate three genuine UEFA API games against independent official articles."""
import datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from history_client import HistoryClient
from build_history_catalog import DB
from official_redirects import get
from probe_history import ROOT,HOSTS
from probe_uefa_api import BASE

PILOTS=[('2039914','Leipzig','Real Madrid','2024-02-13',[1,0],
 '028a-1a2cac0ebcfd-8d059c940a51-1000--report-real-madrid-edge-leipzig/',
 '028a-1a1fe68b6ad7-901e10f2fd4e-1000--leipzig-vs-real-madrid-champions-league-round-of-16-firs/'),
 ('2039915','Copenhagen','Man City','2024-02-13',[3,1],
 '028a-1a2cae4d1cf0-09a8cfbf704e-1000--highlights-report-de-bruyne-puts-holders-in-control/',
 '028a-1a1fe19bc12f-5ea15101fa1b-1000--copenhagen-vs-man-city-preview/'),
 ('2039916','Lazio','Bayern','2024-02-14',[0,1],
 '028a-1a2eb1651636-24b5548c646c-1000--highlights-report-lazio-edge-bayern/',
 '028a-1a1fee2675d7-840caf646617-1000--lazio-vs-bayern-champions-league-round-of-16-first-leg-prev/')]

def main():
 HOSTS.update({'www.uefa.com','match.uefa.com'});c=HistoryClient();db=sqlite3.connect(DB);probe=json.loads((ROOT/'reports/uefa_api_pilot.json').read_text())['probes'][0];r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(probe['request_id'],)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];raw=json.loads(b);assert raw==probe['data'];byid={m['id']:m for m in raw};rows=[];hashes={r['request_id']}
 for mid,home,away,date,scores,report,preview in PILOTS:
  m=byid[mid];assert m['status']=='FINISHED' and m['competition']['id']=='1' and m['seasonYear']=='2024';assert scores==[m['score']['regular'][s] for s in ['away','home']];assert m['kickOffTime']['dateTime']==date+'T20:00:00Z';assert m['winner']['match']['team']['id']==m['awayTeam' if scores[0]>scores[1] else 'homeTeam']['id'];sources=[]
  for kind,slug in [('result',report),('kickoff',preview)]:
   url='https://www.uefa.com/uefachampionsleague/news/'+slug;body,rr,red=get(c,url);assert hashlib.sha256(body).hexdigest()==rr['sha256'];hashes.add(rr['request_id']);soup=BeautifulSoup(body,'html.parser');title=soup.title.get_text();text=' '.join(soup.get_text(' ',strip=True).split());assert home in title and away in title
   if kind=='result':assert f'{home} {scores[1]}-{scores[0]} {away}' in title
   else:assert f'{int(date[-2:])} February' in text and '21:00 CET' in text
   assert '2024' in text;sources.append(dict(kind=kind,url=url,request_id=rr['request_id'],checks='teams, date, '+('final score/winner' if kind=='result' else 'kickoff time')))
  rows.append(dict(match_id=mid,api_request_id=r['request_id'],pointer='/'+str(raw.index(m)),match=m['awayTeam']['translations']['displayOfficialName']['EN']+' / '+m['homeTeam']['translations']['displayOfficialName']['EN'],timestamp_utc=m['kickOffTime']['dateTime'],scores=scores,values_match=True,sources=sources))
 params=dict(probe['parameters'],offset=3);page,pr=c.get(BASE+'/v5/matches',params);assert len(page)==3 and not set(byid)&{m['id'] for m in page};assert all('2024-01-01'<=m['kickOffTime']['date']<='2024-06-30' for m in page);assert min(m['kickOffTime']['dateTime'] for m in page)>=max(m['kickOffTime']['dateTime'] for m in raw)
 empty,er=c.get(BASE+'/v5/matches',dict(probe['parameters'],fromDate='2024-01-01',toDate='2024-01-31'));assert empty==[]
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Three calendar examples; no assertion of odds or person-data completeness',raw_source_hashes=len(hashes),public_examples=rows,pagination_check=dict(request_id=pr['request_id'],nonoverlapping_ids=[m['id'] for m in page]),empty_date_partition_check=dict(request_id=er['request_id'],rows=0),new_requests=c.requests);(ROOT/'reports/uefa_pilot_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,ensure_ascii=False));db.close()

if __name__=='__main__':main()
