"""Distinguish UEFA regulation, extra-time and aggregate scores with raw proofs."""

def score(m):
 sides=['away','home'];ids=[m[s+'Team']['id'] for s in sides];source=m.get('score',{});regular=[source['regular'][s] for s in sides] if 'regular' in source else None;total=[source['total'][s] for s in sides] if 'total' in source else None;goals=m.get('playerEvents',{}).get('scorers');all_goals=[0,0];reg_goals=[0,0];half=[0,0];proof=[];seen=set();valid=isinstance(goals,list);extra=False
 for i,g in enumerate(goals or []):
  phase=g.get('phase');extra|=str(phase).startswith('EXTRA_TIME')
  if g.get('id') in seen or g.get('teamId') not in ids or g.get('goalType') not in ['SCORED','PENALTY','OWN'] or phase not in ['FIRST_HALF','SECOND_HALF','EXTRA_TIME_FIRST_HALF','EXTRA_TIME_SECOND_HALF']:valid=False;continue
  seen.add(g['id']);side=ids.index(g['teamId']);side=1-side if g['goalType']=='OWN' else side;all_goals[side]+=1
  if phase in ['FIRST_HALF','SECOND_HALF']:reg_goals[side]+=1
  if phase=='FIRST_HALF':half[side]+=1
  proof.append(dict(pointer='/playerEvents/scorers/'+str(i),goal_id=g['id'],phase=phase,credited_side=side,own_goal=g['goalType']=='OWN'))
 complete=valid and total is not None and all_goals==total;issue=None
 if complete:
  chosen=reg_goals;basis='Official goal timeline by phase, reconciled to total score'
  if regular is not None and regular!=chosen:issue=dict(reason='Raw regular score disagrees with complete official regulation goal timeline',raw_regular=regular,normalized_regulation=chosen,raw_total=total,handling=basis)
 else:
  # An explicit regular score remains usable unless the retained evidence
  # makes its phase ambiguous. Missing goal events never imply zero goals.
  # The aggregate winner may describe a later second leg. It cannot establish
  # extra time in this game or any information known on the first-leg date.
  reason=m.get('winner',{}).get('match',{}).get('reason','');extra|='penalty' in source or 'EXTRA' in reason or 'PENALT' in reason
  if extra and (regular is None or regular==total) and regular!=[0,0]:chosen=None;basis='Unresolved regulation score; incomplete extra-time goal evidence';issue=dict(reason=basis,raw_regular=regular,raw_total=total)
  else:chosen=regular;basis='Explicit official regular score';issue=dict(reason='Goal timeline incomplete; explicit score retained',raw_regular=regular,raw_total=total,goals_counted=all_goals) if goals is not None and not complete else None
 if chosen is not None:assert all(type(x)is int and x>=0 for x in chosen)
 return dict(scores=chosen,halftime_scores=half if complete else None,score_basis=basis,score_discrepancy=issue,score_proof=dict(raw_regular=regular,raw_total=total,complete_goal_timeline=complete,goals=proof))
