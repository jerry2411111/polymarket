"""Find official same-name profiles by exact retained player asset ID."""
import concurrent.futures,datetime as dt,json,re,sqlite3
from build_history_catalog import DB
from collect_laliga_people import slug,namekey
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS
db=sqlite3.connect(DB,timeout=60);audit=json.loads((ROOT/'reports/laliga_profile_full_name_audit.json').read_text());targets=audit['profile_asset_mismatches'];c=HistoryClient();HOSTS.add('www.laliga.com');extra={'EU_LAL:p589984':['david-lopez-4'],'EU_LAL:p561245':['alvaro-rodriguez-3'],'EU_LAL:p93721':['gerard'],'EU_LAL:p224465':['s-lozano']};rows=[]
def fetch(t):
 pid=t['player_id'];asset=pid.split(':')[1];base=slug(t['names'][0]);slugs=list(dict.fromkeys(extra.get(pid,[])+[base+'-'+str(n) for n in range(1,11)]));out=dict(source_person_id=pid,expected_asset=asset,source_names=t['names'],attempts=[])
 for candidate in slugs:
  url='https://www.laliga.com/en-GB/player/'+candidate;attempt=dict(url=url);out['attempts'].append(attempt)
  try:
   raw,r,red=get(c,url);attempt['request_id']=r['request_id'];m=re.search(rb'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',raw,re.S);d=json.loads(m[1])['props']['pageProps'].get('player');assert d and d.get('id');assets=set(re.findall(r'/(p\d+)/',str(d.get('squads',[]))));attempt['profile_id']=str(d['id']);attempt['assets']=sorted(assets)
   if asset in assets:
    assert namekey(d['name']) in {namekey(n) for n in t['names']};out.update(status='ok',person_id=str(d['id']),request_id=r['request_id'],url=url,json_pointer='/props/pageProps/player',data=d,identity_basis='Exact official player asset ID in dated lineup and profile, plus official name');return out
  except Exception as e:attempt['error']=type(e).__name__+': '+str(e)
 out['status']='unavailable';return out
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for row in pool.map(fetch,targets):rows.append(row);print('NATIVE PROFILE REPAIR',row['source_person_id'],row['status'],row.get('person_id'),flush=True)
with db:
 db.execute('CREATE TABLE IF NOT EXISTS _official_laliga_native_profile_revisions (source_person_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _official_laliga_native_profile_revisions VALUES (?,?)',[(r['source_person_id'],json.dumps(r)) for r in rows])
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),requested=len(rows),matched=sum(r['status']=='ok' for r in rows),new_requests=c.requests,results=[{k:v for k,v in r.items() if k not in ['data','attempts']} for r in rows]);(ROOT/'reports/laliga_homonym_profile_repairs.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
