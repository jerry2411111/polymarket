"""Test the current official player client endpoints before population scale."""
import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT
c=HistoryClient();out=[]
for pid in ['8471214','8478402','8480012']:
 row=dict(player_id=pid,sources={})
 for route in ['bio','player-stats','game-log/20242025/2']:
  try:
   d,r=c.get('https://api-web.nhle.com/v2/player/'+pid+'/'+route);row['sources'][route]=dict(request_id=r['request_id'],keys=list(d),example=d if route=='bio' else {k:v[:2] if isinstance(v,list) else v for k,v in d.items()});print('PLAYER',pid,route,json.dumps(row['sources'][route])[:3500],flush=True)
  except Exception as e:row['sources'][route]=dict(error=str(e));print('PLAYER ERROR',pid,route,str(e),flush=True)
 out.append(row)
(ROOT/'reports/nhl_player_api_pilot.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),players=out,new_requests=c.requests),indent=2),encoding='utf-8')
