"""Verify three-outcome identity, previous-quote selection and real official break windows."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from collect_premier_game_reports import PILOT
from epl_price_points import Sources,pointer,load
from quote_selection import available_at,nearest_pregame,inside_window
from core import utc,odd
from schema import HOURS

def main():
    db=sqlite3.connect(DB);src=Sources(db);cs={(c['provider'],c['contract_id']):c for b, in db.execute('SELECT body FROM _epl_market_candidates') if (c:=json.loads(b))['official_match_id'] in PILOT};points,conflicts,excluded=load(db,cs,src);rows=[];checks=collections.Counter();examples=[]
    for mid in PILOT:
        game=json.loads(db.execute('SELECT body FROM _official_epl_calendar WHERE match_id=?',(mid,)).fetchone()[0]);f=json.loads(db.execute('SELECT body FROM _official_epl_game_reports WHERE match_id=?',(mid,)).fetchone()[0]);d=f['derived'];assert not d['issues'];start=utc(d['actual_start_utc']).timestamp();teams=[game['away']['name'],game['home']['name'],'Draw'];score=[game['away']['score'],game['home']['score']];winner=2 if score[0]==score[1] else int(score[1]>score[0]);checks['official_completed_result']+=1
        original,mr=src.get(f['sources']['match']['request_id']);assert original==f['sources']['match']['data'];assert original['awayTeam']['score']==score[0] and original['homeTeam']['score']==score[1]
        for c in [c for c in cs.values() if c['official_match_id']==mid]:
            raw,r=src.get(c['request_id']);m=pointer(raw,c['pointer']);assert c['settlement_yes']==int(c['side']==winner)
            if c['provider']=='polymarket':
                arr=lambda x:json.loads(x) if isinstance(x,str) else x;tokens=arr(m['clobTokenIds']);labels=arr(m['outcomes']);assert tokens[c['outcome_index']]==c['contract_id'] and labels[c['outcome_index']]=='Yes';assert m['question'].startswith('Will ')
            else:assert m['ticker']==c['contract_id'] and m['yes_sub_title']==c['team_question']
            checks['native_outcome_mapping']+=1;xs=points[c['provider'],c['contract_id']]
            for h in HOURS:
                target=start-h*3600;x=nearest_pregame(xs,target,start);row=dict(provider=c['provider'],game_id=c['game_id'],outcome=teams[c['side']],lookback_hours=h,target_timestamp_utc=utc(target).isoformat(),price=None,decimal_odds=None)
                if x:
                    raw,r=src.get(x['request_id']);assert float(pointer(raw,x['pointer']))==x['price'];assert x['timestamp']<start and available_at(x)<=target;assert not any(y['timestamp']<start and available_at(x)<available_at(y)<=target for y in xs);checks['previous_raw_price_values']+=1
                    row.update(price=x['price'],decimal_odds=odd(x['price']),source_timestamp_utc=utc(x['timestamp']).isoformat(),source_available_at_utc=utc(available_at(x)).isoformat(),source_age_hours=(target-x['timestamp'])/3600,resolution_seconds=x['resolution_seconds'],request_id=x['request_id'],pointer=x['pointer'],endpoint=r['endpoint'],parameters=r['parameters'],retrieved_at_utc=r['retrieved_at_utc'],values_match=True)
                rows.append(row)
            windows=[(start,start+120),(utc(d['halftime_start_utc']).timestamp(),utc(d['second_half_start_utc']).timestamp()),(utc(d['second_half_start_utc']).timestamp(),utc(d['second_half_start_utc']).timestamp()+120)]
            for name,(lo,hi) in zip(['START','HALFTIME','SECOND_HALF_START'],windows):
                eligible=[x for x in xs if inside_window(x,lo,hi)];x=min(eligible,key=lambda x:(available_at(x),x['timestamp'],x['resolution_seconds']),default=None)
                rows.append(dict(provider=c['provider'],game_id=c['game_id'],outcome=teams[c['side']],checkpoint=name,window_start_utc=utc(lo).isoformat(),window_end_utc=utc(hi).isoformat(),price=x['price'] if x else None,decimal_odds=odd(x['price']) if x else None,source=x))
                if x:
                    raw,r=src.get(x['request_id']);assert float(pointer(raw,x['pointer']))==x['price'] and lo<=x['timestamp']<hi and available_at(x)<=hi;checks['break_raw_price_values']+=1
        examples.append(dict(official_match_id=mid,teams=teams[:2],date=game['date'],score=score,winner=teams[winner],actual_start_utc=d['actual_start_utc'],official_endpoint=mr['endpoint'],official_public_url='https://www.premierleague.com/en/match/'+mid,clock_matches=d['explicit_event_clock_matches']))
    for p in ['polymarket','kalshi']:
        checks[p+'_nonmissing_pre']=sum(r['provider']==p and 'lookback_hours'in r and r['price'] is not None for r in rows);checks[p+'_possible_pre']=sum(r['provider']==p and 'lookback_hours'in r for r in rows);checks[p+'_nonmissing_in_game']=sum(r['provider']==p and 'checkpoint'in r and r['price'] is not None for r in rows)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING' if not conflicts else 'PARTIALLY WORKING',scope='Four-game real connector validation, not full historical coverage',checks=dict(checks),raw_hashes=len(src.cache),source_conflicts=conflicts,excluded=excluded,examples=examples,observations=rows)
    (ROOT/'reports/epl_price_pilot_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');lines=['# EPL historical odds pilot','','Separate independent team-win and draw contracts. Decimal odds = 1 / probability; zero probability retains null decimal odds.','Polymarket prices and Kalshi YES bid closes retain their distinct source meanings. No complementary probabilities or forced sum-to-one normalization.','','| Provider | Game | Outcome | Hours before | Probability | Decimal odds | Source UTC |','|---|---|---|---:|---:|---:|---|']
    for r in rows:
        if 'lookback_hours' in r:lines.append('| '+' | '.join(str(r.get(k)) for k in ['provider','game_id','outcome','lookback_hours','price','decimal_odds','source_timestamp_utc'])+' |')
    lines+=['','See the companion JSON for exact endpoints, parameters, raw pointers, retrieval times, source intervals and missing checkpoints.'];(ROOT/'reports/epl_price_pilot_validation.md').write_text('\n'.join(lines),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['examples','observations']}));db.close()

if __name__=='__main__':main()
