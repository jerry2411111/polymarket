import json,re,sqlite3
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from build_history_catalog import DB
HOSTS.add('builds.mlbstatic.com');c=HistoryClient();pages=json.loads((ROOT/'reports/mlb_player_public_client_probe.json').read_text());out=[]
for page in pages:
    db=sqlite3.connect(DB);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(page['request_id'],)).fetchone()[0]);db.close();s=(ROOT/r['raw_file']).read_text(encoding='utf-8')
    print('PAGE inline modules',page['url'],re.findall(r'.{0,100}(?:patternScripts|siteScripts|transactions\.js|transactions/|transactions:|transactions\").{0,200}',s)[-12:])
    for url in page['scripts']:
        if 'builds.mlbstatic.com' not in url or not ('player-update' in url or 'site-core.min' in url):continue
        b,r=c.get(url,document=True);s=b.decode('utf-8');hits=[]
        for word in ['transactions','/people/','/coaches','hydrate']:
            hits.extend(s[max(0,m.start()-220):m.start()+450] for m in list(re.finditer(re.escape(word),s,re.I))[:10])
        out.append(dict(url=url,request_id=r['request_id'],hits=hits));print(json.dumps(out[-1]))
(ROOT/'reports/mlb_player_client_routes.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
