"""Check the complete date coverage, source values and full-season counts."""
import collections,datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from history_index import records,payload
from nhl_official import full_team_name
from probe_history import ROOT
db=sqlite3.connect(DB,timeout=60);rs={r['request_id']:r for r in records()};cached={};counts=collections.Counter();teams=collections.defaultdict(collections.Counter);updates=[];checks=0
for native,body in db.execute('SELECT * FROM _official_nhl_schedule'):
 g=json.loads(body);rid=g['request_id']
 if rid not in cached:
  raw=(ROOT/rs[rid]['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==rs[rid]['sha256'];cached[rid]=json.loads(raw)
 d=cached[rid]
 for k in g['pointer'].strip('/').split('/'):d=d[int(k)] if isinstance(d,list) else d[k]
 assert d==g['raw'] and str(d['id'])==native
 assert g['scores']==[d[s]['score'] for s in ['awayTeam','homeTeam']]
 assert g['official_team_ids']==[str(d[s]['id']) for s in ['awayTeam','homeTeam']]
 names=[full_team_name(d[s]) for s in ['awayTeam','homeTeam']]
 if names!=g['teams']:g['teams']=names;g['winner']=names[int(g['scores'][1]>g['scores'][0])];updates.append((json.dumps(g),native))
 counts[g['season'],g['game_type_code']]+=1
 if g['game_type_code']==2:
  for tid in g['official_team_ids']:teams[g['season']][tid]+=1
 checks+=5
expected={str(dt.date(2024,1,1)+dt.timedelta(days=n)) for n in range(988)}
assert {d for d, in db.execute('SELECT date FROM _nhl_schedule_dates')}==expected
for season in ['20242025','20252026']:
 assert counts[season,2]==1312 and len(teams[season])==32 and set(teams[season].values())=={82}
with db:db.executemany('UPDATE _official_nhl_schedule SET body=? WHERE official_game_id=?',updates)
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',dates_checked=len(expected),source_field_checks=checks,source_hash_checks=len(cached),official_games=sum(counts.values()),team_name_whitespace_or_duplicate_components_corrected=len(updates),seasons=[dict(season=s,game_type=t,games=n) for (s,t),n in sorted(counts.items())],full_regular_seasons={s:dict(games=counts[s,2],teams=len(teams[s]),games_per_team=sorted(set(teams[s].values()))) for s in ['20242025','20252026']},scope='Official calendar including games without odds. 2023-24 is a partial season starting January 1, 2024.')
(ROOT/'reports/nhl_calendar_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
