"""Verify the apparent Polymarket coverage gap in the final requested week."""
import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT
c=HistoryClient();out=[]
for params in [dict(tag_id=100381,end_date_min='2026-09-08T00:00:00Z',end_date_max='2026-09-16T00:00:00Z',limit=100,offset=0),dict(tag_id=100381,start_date_min='2026-09-08T00:00:00Z',start_date_max='2026-09-16T00:00:00Z',limit=100,offset=0)]:
    d,r=c.get('https://gamma-api.polymarket.com/events',params,refresh=True)
    out.append(dict(request_id=r['request_id'],parameters=params,event_count=len(d),events=[dict(event_id=e['id'],title=e.get('title'),slug=e.get('slug'),start=e.get('startTime'),end=e.get('endDate'),markets=[dict(market_id=m['id'],question=m.get('question'),game_start=m.get('gameStartTime'),market_type=m.get('sportsMarketType'),outcomes=m.get('outcomes')) for m in e.get('markets',[])]) for e in d]))
(ROOT/'reports/mlb_latest_polymarket_probe.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),examples=out),indent=2),encoding='utf-8')
print(json.dumps([dict(request_id=x['request_id'],parameters=x['parameters'],event_count=x['event_count'],full_game_markets=sum(m['market_type']=='moneyline' for e in x['events'] for m in e['markets'])) for x in out]))
