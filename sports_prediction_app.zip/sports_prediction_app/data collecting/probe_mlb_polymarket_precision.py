"""Real dated probes of the documented Polymarket price-history operation."""
import datetime as dt,json,sqlite3
from build_history_catalog import DB
from core import utc
from history_client import HistoryClient
from probe_history import ROOT
from schema import HOURS

def main():
    db=sqlite3.connect(DB,timeout=60);gs={i:json.loads(b) for i,b in db.execute('SELECT * FROM _mlb_canonical_games')};cs=[json.loads(b) for b, in db.execute("SELECT body FROM _mlb_market_candidates WHERE json_extract(body,'$.provider')='polymarket'")];feeds={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_mlb_feeds')};bygame={x['game_id']:x for x in cs if x['side']==0};chosen=[]
    for prefix in ['2024','2025','2026-03','2026-06','2026-07','2026-08','2026-09-01','2026-09-13']:
        ids=sorted((i for i in bygame if gs[i]['date'].startswith(prefix)),key=lambda i:gs[i]['date'])
        if ids:chosen.append(ids[0])
    c=HistoryClient();results=[]
    for gid in chosen:
        g=gs[gid];m=bygame[gid];f=feeds[g['official_game_id']];start=utc(f['actual_first_pitch_utc']).timestamp()
        for hour in [HOURS[0],HOURS[1],HOURS[-1]]:
            target=int(start-hour*3600)-(1 if start==int(start) and hour==0 else 0);ask=target;ids=[];x=None
            for _ in range(4):
                d,r=c.get('https://data-api.polymarket.com/v2/prices-history',dict(token_id=m['contract_id'],as_of=ask));ids.append(r['request_id']);assert len(d['data'])<=1 and not d.get('pagination',{}).get('next_cursor')
                x=d['data'][0] if d['data'] else None
                if not x:break
                assert x['timestamp']<=ask and 0<=x['price']<=1
                if x['resolution_seconds']>0 and x['timestamp']+x['resolution_seconds']<=target:break
                ask=x['timestamp']-1
            valid=bool(x and x['resolution_seconds']>0 and x['timestamp']+x['resolution_seconds']<=target)
            results.append(dict(game_id=gid,date=g['date'],contract_id=m['contract_id'],kind='pre_'+str(hour),request_ids=ids,point=x,valid=valid))
        b=next((b for b in f['breaks'] if b['start_utc'] and b['end_utc']),None)
        if b:
            lo=utc(b['start_utc']).timestamp();hi=utc(b['end_utc']).timestamp()
            for grain in [60,None]:
                params=dict(token_id=m['contract_id'],start=int(lo),end=int(hi)+1)
                if grain:params['bucket_seconds']=grain
                d,r=c.get('https://data-api.polymarket.com/v2/prices-history',params);assert not d.get('pagination',{}).get('next_cursor')
                usable=[x for x in d['data'] if x['resolution_seconds']>0 and lo<=x['timestamp'] and x['timestamp']+x['resolution_seconds']<=hi]
                results.append(dict(game_id=gid,date=g['date'],contract_id=m['contract_id'],kind='break',requested_grain=grain,request_ids=[r['request_id']],returned_points=len(d['data']),resolutions=sorted({x['resolution_seconds'] for x in d['data']}),usable_points=len(usable),first_usable=usable[0] if usable else None))
        print('MLB POLYMARKET PRECISION',g['date'],'completed',flush=True)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),documentation_request_id=json.loads((ROOT/'reports/polymarket_current_price_schema.json').read_text())['request_id'],new_requests=c.requests,examples=results,note='Zero-duration points are excluded because resolved-market terminal payouts can be clamped to the requested window. No retention horizon is inferred from an empty individual market.')
    (ROOT/'reports/mlb_polymarket_precision_probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
