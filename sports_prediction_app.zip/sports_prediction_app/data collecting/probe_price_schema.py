import json,datetime as dt
from probe_history import Client,ROOT
from history_index import index

def main():
 c=Client(ROOT)
 for url in ['https://docs.kalshi.com/getting_started/rate_limits.md','https://docs.kalshi.com/api-reference/market/get-market-candlesticks.md']:
  b,r=c.get(url,document=True); print('DOC',url,b.decode()[:3000])
 d=index();ms=sorted([x[0] for x in d['kalshi_markets'].values() if x[0]['event_ticker'].startswith('KXNBAGAME')],key=lambda m:m['close_time']);m=ms[0]
 end=int(dt.datetime.fromisoformat(m['close_time'].replace('Z','+00:00')).timestamp())
 for path,params in [('/markets/candlesticks',dict(market_tickers=m['ticker'],start_ts=end-86400*4,end_ts=end,period_interval=60)),('/historical/markets/'+m['ticker']+'/candlesticks',dict(start_ts=end-86400*4,end_ts=end,period_interval=60))]:
  try:
   v,r=c.get('https://external-api.kalshi.com/trade-api/v2'+path,params);print('K',path,json.dumps(v)[:1800])
  except Exception as e:print('K ERROR',str(e))
 for event in sorted([x[0] for x in d['polymarket_events'].values()],key=lambda e:int(e['id'])):
  found=False
  for m in event['markets']:
   if m.get('sportsMarketType')!='moneyline' or not m.get('gameStartTime'):continue
   t=int(dt.datetime.fromisoformat(m['gameStartTime']).timestamp());token=json.loads(m['clobTokenIds'])[0]
   v,r=c.get('https://data-api.polymarket.com/v2/prices-history',dict(token_id=token,start=t-86400*4,end=t+21600,limit=10000))
   print('P',event['title'],m['question'],m['gameStartTime'],'keys',list(v),'metadata',json.dumps({k:x for k,x in v.items() if k!='data'}),'count',len(v.get('data',[])),'rows',v.get('data',[])[:3]);found=True;break
  if found:break

if __name__=='__main__':main()
