﻿import re,json
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
HOSTS.add('builds.mlbstatic.com');u='https://builds.mlbstatic.com/baseballsavant.mlb.com/v1/sections/gamefeed/builds/c74ed6663954a3d64ce083505f5db324100b9aee/scripts/build/gamefeed-all.js';b,r=HistoryClient().get(u,document=True);s=b.decode('utf-8',errors='replace');print('PUBLIC SCRIPT',r['request_id'],len(b))
for term in ['/gf','game_pk=','gamePk=','feed/live','boxscore','gamefeed','schedule']:
 hits=list(re.finditer(re.escape(term),s));print('TERM',term,'COUNT',len(hits))
 for m in hits[:4]:print(s[max(0,m.start()-100):m.start()+180])
(ROOT/'reports/mlb_savant_public_client.json').write_text(json.dumps(dict(source_url=u,request_id=r['request_id'],basis='Public script referenced by the official public gamefeed page; endpoint and field usage reviewed before calling.'),indent=2),encoding='utf-8')
