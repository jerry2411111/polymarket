"""Remove redundant JSONL request logs only after exact SQL provenance checks."""
import csv
import datetime as dt
import hashlib
import json
import sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from request_audit import export_log

db = sqlite3.connect(DB, timeout=60)
paths = [p for p in [ROOT/'data/raw/requests.jsonl', *sorted((ROOT/'data/raw/request_logs').glob('*.jsonl'))] if p.exists()]
manifest = []
for path in paths:
    assert path.resolve().is_relative_to((ROOT/'data/raw').resolve())
    raw = path.read_bytes()
    assert not raw or raw.endswith(b'\n'), 'Incomplete trailing request must be reconciled before deletion'
    rows = []
    for line in raw.decode('utf-8').splitlines():
        if not line.strip():
            continue
        record = json.loads(line)
        saved = db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?', (record['request_id'],)).fetchone()
        assert saved is not None, record['request_id']
        metadata = json.loads(saved[0])
        assert all(metadata.get(k) == value for k, value in record.items()), record['request_id']
        rows.append(record['request_id'])
    manifest.append(dict(path=path.relative_to(ROOT).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),entries=len(rows)))
assert not db.execute("SELECT 1 FROM _request_audit WHERE return_status='PENDING' LIMIT 1").fetchone()
export_log(ROOT, db)
with (ROOT/'data/raw/requests.csv').open(encoding='utf-8-sig', newline='') as handle:
    reader = csv.reader(handle)
    assert next(reader) == ['request_number','request_type','requested_data','return_status']
    assert sum(1 for _ in reader) == db.execute('SELECT count(*) FROM _request_audit').fetchone()[0]
for path in paths:
    path.unlink()
report = dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',removed_redundant_logs=manifest,
              log_entries_preserved_in_sql=sum(r['entries'] for r in manifest),
              total_logged_requests=db.execute('SELECT count(*) FROM _request_audit').fetchone()[0],
              raw_responses_removed=0,public_log='data/raw/requests.csv',
              meaning='All original JSONL metadata fields were verified against SQL before removing duplicate log files. Raw source responses and full SQL provenance remain unchanged.')
(ROOT/'reports/request_log_cleanup.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='removed_redundant_logs'}),flush=True)
db.close()
