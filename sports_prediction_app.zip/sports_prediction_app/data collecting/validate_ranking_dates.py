"""Independently verify edition selection, publisher isolation and date cutoffs."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from install_nba_rankings import NAMES
from temporal_queries import FLAGS

def main():
    db=sqlite3.connect(DB);db.row_factory=sqlite3.Row
    aliases={(r['source_player_id'],r['league']):r['player_id'] for r in db.execute('SELECT * FROM _player_identity_aliases')}
    skip={r['list_id'] for r in db.execute('SELECT * FROM _ranking_edition_audit WHERE use_for_flags=0')}
    es=[dict(r) for r in db.execute('SELECT * FROM ranking_list_versions') if r['list_id'] not in skip]
    facts={(r['list_id'],aliases.get((r['player_id'],r['league']),r['player_id'])):r['rank'] for r in db.execute('SELECT * FROM player_media_rankings')}
    rows=[dict(r) for r in db.execute('SELECT * FROM player_rankings_quarterly')];flags={(r['as_of_date'],r['player_id'],r['league']):dict(r) for r in db.execute('SELECT * FROM _ranking_flag_results')}
    checks=0;observed=0
    for r in rows:
        eligible=[e for e in es if e['league']==r['league'] and e['publisher']==r['publisher'] and max(e['publication_date'],e['version_verified_date'])<=r['as_of_date']]
        e=max(eligible,key=lambda e:(e['version_verified_date'],e['publication_date'],e['list_id'])) if eligible else None
        rank=facts.get((e['list_id'],r['player_id'])) if e else None
        assert r['rank']==rank
        if rank is not None:observed+=1;assert e['version_verified_date']<=r['as_of_date']
        pub=next(k for k,v in NAMES.items() if v==r['publisher'])
        for n in [5,10,20,50]:
            v=flags[r['as_of_date'],r['player_id'],r['league']][pub+'_top_'+str(n)]
            assert v==(int(rank<=n) if rank is not None else None);checks+=1
    examples=[]
    for day in ['2024-10-01','2025-01-01','2026-07-01','2026-09-14']:
        for r in rows:
            if r['as_of_date']==day and r['league']=='NBA' and r['publisher'] in ['ESPN','The Ringer','Bleacher Report'] and r['player_id']=='NBA:203999':examples.append(r)
    # Both same-name players retain native identities; rank flags may never
    # multiply dated performance rows or silently merge different human IDs.
    for day in ['2024-06-01','2025-02-16','2026-01-15','2026-09-14']:
        vals=list(db.execute('SELECT player_id,league FROM player_performance WHERE as_of_date=?',(day,)));assert len(vals)==len(set(tuple(v) for v in vals))
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',quarterly_row_checks=len(rows),publisher_flag_checks=checks,observed_rank_rows=observed,dated_player_row_duplicate_checks=4,no_future_edition_used=True,examples=examples)
    (ROOT/'reports/ranking_temporal_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='examples'}));db.close()

if __name__=='__main__':main()
