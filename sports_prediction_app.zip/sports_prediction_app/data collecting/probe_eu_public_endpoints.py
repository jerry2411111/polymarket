"""Small real probes using endpoint syntax read from current official documentation/clients."""
import argparse,datetime as dt,json
from urllib.parse import urlsplit
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def main():
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['tags','premier','premier_matches','premier_dates','bundesliga','laliga']);a=ap.parse_args();client=HistoryClient();out=[]
    jobs=[('https://gamma-api.polymarket.com/tags/'+str(n),{}) for n in [780,102070,1494,101962,100618,82,306,100977,1234]] if a.stage=='tags' else [('https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v2/competitions/8/details',{}),('https://sdp-prem-prod.premier-league-prod.pulselive.com/api/vX/competitions/8/seasons/2023/matches',{})]
    if a.stage=='premier_matches':jobs=[('https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v2/matches',dict(competition='8',season='2023',kickoffDateFrom='2024-01-01',kickoffDateTo='2024-02-01',_limit=100))]
    if a.stage=='premier_dates':jobs=[('https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v2/matches?kickoff>2024-01-01&kickoff<2024-02-01',dict(competition='8',season='2023',_limit=100))]
    if a.stage=='bundesliga':
        HOSTS.add('firebase.google.com');b,dr=client.get('https://firebase.google.com/docs/database/rest/retrieve-data',document=True);assert b'orderBy' in b and b'equalTo' in b
        jobs=[('https://bundesliga-web-prod.europe-west1.firebasedatabase.app/all/DFL-COM-000001/seasons/DFL-SEA-0001KA/matches.json',dict(orderBy='"matchday"',equalTo=3))]
    if a.stage=='laliga':
        import sqlite3
        from bs4 import BeautifulSoup
        from build_history_catalog import DB
        with sqlite3.connect(DB) as db:r=json.loads(db.execute("SELECT metadata_json FROM _request_audit WHERE request_id='23cb1b565e4f479cad63ef0c9b10e1c5'").fetchone()[0])
        d=json.loads(BeautifulSoup((ROOT/r['raw_file']).read_text(encoding='utf-8'),'html.parser').find('script',id='__NEXT_DATA__').get_text());props=d['props']['pageProps'];jobs=[(d['runtimeConfig']['backendUrl']+'/api/v1/matches',dict(subscriptionSlug=props['subscriptionSlug'],seasonYear=props['season'],week=props['gameweek']['week'] if isinstance(props['gameweek'],dict) else props['gameweek'],limit=100,orderField='date',orderType='asc'))]
    for url,params in jobs:
        HOSTS.add(urlsplit(url).hostname)
        try:
            d,r=client.get(url,params);item=dict(url=url,parameters=params,request_id=r['request_id'],status=r['status'],keys=list(d) if isinstance(d,dict) else None,rows=len(d) if isinstance(d,list) else None)
            if a.stage=='premier_dates':
                assert all('2024-01-01'<=x['kickoff'][:10]<'2024-02-01' and x['competitionId']=='8' for x in d['data']);item['verified_date_filter']=True;item['rows']=len(d['data']);item['pagination']=d['pagination']
            print(json.dumps(item),'EXAMPLE',json.dumps(d,ensure_ascii=False)[:2600] if a.stage!='tags' else json.dumps(d),flush=True);out.append(item)
        except Exception as e:out.append(dict(url=url,error=str(e)));print('ERROR',url,str(e),flush=True)
    (ROOT/'reports'/('eu_soccer_'+a.stage+'_probes.json')).write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=out,new_requests=client.requests),indent=2),encoding='utf-8')

if __name__=='__main__':main()
