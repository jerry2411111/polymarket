﻿import json,re
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
HOSTS.add('baseballsavant.mlb.com');c=HistoryClient();out=[]
for u in ['https://baseballsavant.mlb.com/csv-docs','https://baseballsavant.mlb.com/gamefeed?gamePk=778297']:
 try:
  b,r=c.get(u,document=True);s=BeautifulSoup(b,'html.parser');scripts=[]
  for i,t in enumerate(s.find_all('script')):
   txt=t.string or t.get_text()
   if any(w in txt for w in ['778297','boxscore','gameData','game_data','home_score','away_score']):scripts.append(dict(index=i,id=t.get('id'),length=len(txt),prefix=txt[:160],keys=[w for w in ['gameData','game_data','boxscore','allPlays','gameType','inning','startTime','venue','fullName'] if w in txt]))
  x=dict(url=u,status=r['status'],request_id=r['request_id'],bytes=len(b),title=s.title.get_text(' ',strip=True) if s.title else None,data_scripts=scripts,tables=len(s.find_all('table')));out.append(x);print(json.dumps(x))
 except Exception as e:out.append(dict(url=u,error=str(e)));print(str(e))
(ROOT/'reports/mlb_savant_probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
