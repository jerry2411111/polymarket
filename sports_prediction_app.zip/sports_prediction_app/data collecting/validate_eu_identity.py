"""Validate crosswalk evidence, native club pointers and identity graph connectivity."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from collect_laliga_people import namekey
from epl_price_points import Sources,pointer
from probe_history import ROOT

def main():
 db=sqlite3.connect(DB,timeout=60);db.execute('BEGIN');src=Sources(db);checks=collections.Counter();cross={pid:json.loads(b) for pid,_,b in db.execute('SELECT * FROM _eu_person_crosswalk')};registry={pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _eu_people_registry')};clubs={(code,tid):json.loads(b) for code,tid,b in db.execute('SELECT * FROM _eu_team_identity')};edges=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_person_identity_edges')];graph=collections.defaultdict(set);hashes=set()
 def raw(rid):
  m=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/m['raw_file']).read_bytes();assert m['status']==200 and hashlib.sha256(b).hexdigest()==m['sha256'];hashes.add(rid)
  if b.lstrip().startswith((b'{',b'[')):return json.loads(b)
  hit=re.search(rb'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',b,re.S)
  return json.loads(hit[1]) if hit else None
 extras={};lalprofiles={}
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_documented_player_aliases'").fetchone():
  for b, in db.execute('SELECT body FROM _eu_documented_player_aliases'):
   a=json.loads(b);meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(a['request_id'],)).fetchone()[0]);document=(ROOT/meta['raw_file']).read_bytes();assert hashlib.sha256(document).hexdigest()==meta['sha256'];hashes.add(a['request_id']);text=BeautifulSoup(document,'html.parser').get_text(' ',strip=True);assert all(namekey(v) in namekey(text) or namekey(v) in namekey(document.decode('utf-8')) for v in a['evidence']);assert a['alias'] in cross[a['source_person_id']]['names'] and cross[a['source_person_id']]['birth_date']==a['birth_date'];checks['documented_official_playing_alias']+=1
 for b, in db.execute('SELECT body FROM _eu_opta_biographies'):
  v=json.loads(b);document,_=src.get(v['biography_request_id'])
  for field in ['birth_date','height_cm','weight_kg']:
   if v[field] is not None:assert pointer(document,v['sources'][field])==v[field];checks['global_biography_exact_raw_field']+=1
  for pid in v['source_person_ids']:extras[pid]=v
 for table in ['_official_laliga_people_sources','_official_laliga_native_profile_revisions']:
  for b, in db.execute('SELECT body FROM '+table):
   r=json.loads(b)
   if r['status']=='ok':lalprofiles[r['person_id']]=r
 for pid,p in cross.items():
  if not pid.startswith('EU_LAL:p'):continue
  for profile_id in p['source_native_profile_ids']:
   r=lalprofiles[profile_id];d=pointer(raw(r['request_id']),r['json_pointer']);assert d==r['data'];assets=set(re.findall(r'/(p\d+)/',str(d.get('squads',[]))))
   if assets:assert pid.split(':')[1] in assets;checks['LaLiga_native_photo_identity']+=1
   else:assert pid in extras and extras[pid]['birth_date']==str(d['date_of_birth'])[:10];checks['LaLiga_profile_corroborated_by_native_global_DOB']+=1
 for key,c in clubs.items():
  proof=c.get('uefa_proof')
  if proof:
   v=pointer(raw(proof['request_id']),proof['pointer']);assert str(v['id'])==str(c['uefa_id']);checks['UEFA_native_club_source']+=1
  if c.get('domestic_request_id'):
   v=pointer(raw(c['domestic_request_id']),c['domestic_pointer']);code,tid=key
   if code=='BUN':assert v['dflDatalibraryClubId']==tid
   elif code=='FL1':assert re.fullmatch(r'l1_championship_club_\d{4}_'+re.escape(tid),v['id'])
   else:assert str(v['id'] if code!='SEA' else v.get('teamId') or v.get('id'))==tid,(code,tid,list(v))
   checks['domestic_native_club_source']+=1
 for edge in edges:
  a,b=edge['source_a'],edge['source_b'];assert a in cross and b in cross and cross[a]['person_id']==cross[b]['person_id'];ca,cb=cross[a],cross[b];names_a={namekey(n) for n in ca['names']};names_b={namekey(n) for n in cb['names']};proof=edge['proof']
  if 'birth_date' in proof and not proof.get('role'):assert ca['birth_date']==cb['birth_date']==proof['birth_date'] and proof['normalized_name'] in names_a&names_b;checks['full_name_and_DOB_links']+=1
  elif 'profile_id' in proof:assert proof['profile_id'] in ca['source_native_profile_ids'] and proof['profile_id'] in cb['source_native_profile_ids'];checks['same_verified_profile_links']+=1
  else:
   role=proof.get('role','manager')
   if role=='player':assert ca['birth_date']==cb['birth_date']==proof['birth_date']
   assert proof['normalized_name'] in names_a&names_b;oa,ob=proof['observation_a'],proof['observation_b'];assert abs((dt.date.fromisoformat(oa['date'])-dt.date.fromisoformat(ob['date'])).days)<=14
   for pid,o in [(a,oa),(b,ob)]:
    table=('_epl_'+role+'_game_facts') if pid.startswith(('EU_PL:','EU_PL_COACH:')) else ('_eu_source_'+role+'_game_facts');v=json.loads(db.execute('SELECT body FROM '+table+' WHERE '+role+'_id=? AND game_id=?',(pid,o['game_id'])).fetchone()[0]);assert (v.get('roster_request_id') or v['request_id'])==o['request_id'] and v['game_date']==o['date'] and v['team_name']==o['team_name'];raw(o['request_id']);code=v.get('competition_code','PL');found=[c for (cc,_),c in clubs.items() if cc==code and (c['official_team_id']==str(v.get('official_team_id')) or c['team_name']==v['team_name'])];assert len(found)==1 and found[0]['team_id']==proof['canonical_team_id']
   checks['dated_'+role+'_same_club_links']+=1
  graph[a].add(b);graph[b].add(a)
 for cid,p in registry.items():
  ids=set(p['source_person_ids']);assert cid in ids and all(cross[i]['person_id']==cid for i in ids);seen={cid};pending=[cid]
  while pending:
   for n in graph[pending.pop()]-seen:seen.add(n);pending.append(n)
  assert seen==ids;assert p['kind'] in ['player','manager'];checks['connected_identity_groups']+=1
  for field in ['height_cm','weight_kg']:
   if p[field] is not None:assert any(b[field]==p[field] for b in p['biography_sources']) and p[field]>0
  if p['birth_date']:assert any(b['birth_date']==p['birth_date'] for b in p['biography_sources'])
  checks['biography_value_has_exact_source']+=1
 for table in ['_epl_player_game_facts','_eu_source_player_game_facts']:
  seen=set()
  for pid,gid in db.execute('SELECT player_id,game_id FROM '+table):
   key=cross[pid]['person_id'],gid;assert key not in seen,'Identity merge duplicates a participant within one game';seen.add(key);checks['unique_player_per_game_after_linking']+=1
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',checks=dict(checks),source_hashes=len(hashes)+len(src.cache),source_people=len(cross),canonical_people=len(registry),native_clubs=len(clubs),scope='Conservative identity mapping and exact value provenance. Unlinked people remain separate, with native IDs preserved.');(ROOT/'reports/eu_identity_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
