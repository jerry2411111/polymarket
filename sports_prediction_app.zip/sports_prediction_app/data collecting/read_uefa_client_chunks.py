"""Read selected current UEFA client assets; never copy or use embedded credentials."""
import argparse,datetime as dt,hashlib,json,re,sqlite3
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT,HOSTS

def main():
 p=argparse.ArgumentParser();p.add_argument('--bootstrap',action='store_true');p.add_argument('--chunks',nargs='*',type=int,default=[]);a=p.parse_args();db=sqlite3.connect(DB);rid='1996f8721a8842d4b853596d04981367';r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];base=b.decode();mapping={}
 for m in re.finditer(r'if\((\d+)===r\)return"js/(?:"\+r\+"([^\"]+)|([^\"]+))"',base):mapping[int(m[1])]='https://www.uefa.com/CompiledAssets/UefaCom/js/'+(m[1]+m[2] if m[2] else m[3])
 ids=a.chunks
 if a.bootstrap:
  end=base.index('then(t.bind(t,81805))');start=base.rfind('Promise.all([',0,end);assert start>=0;ids+=list(map(int,re.findall(r't\.e\((\d+)\)',base[start:end])))
 HOSTS.add('www.uefa.com');c=HistoryClient();rows=[]
 for cid in dict.fromkeys(ids):
  url=mapping[cid]
  if '/npm-' in url:continue
  try:
   data,r=c.get(url,document=True);s=data.decode();row=dict(chunk=cid,url=url,request_id=r['request_id'],bytes=len(data));contexts=[]
   for hit in list(re.finditer(r'matches-calendar|/matches|seasonYear|matchApiUrl',s))[:8]:
    context=s[max(0,hit.start()-100):hit.end()+550];context=re.sub(r'(?i)((?:api[_-]?key|token|secret|password)[\w-]*["\x27]?\s*[:=]\s*["\x27])[^"\x27]+',r'\1[redacted]',context);contexts.append(dict(offset=hit.start(),text=context))
   row['contexts']=contexts;print(json.dumps(row),flush=True);rows.append(row)
  except Exception as e:print(json.dumps(dict(chunk=cid,error=str(e))),flush=True)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),base_request_id=rid,assets=rows,new_requests=c.requests);(ROOT/'reports/uefa_client_latest.json').write_text(json.dumps(out,indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
