import collections,datetime as dt,json,shutil,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from core import utc
db=sqlite3.connect(DB,timeout=60);games={json.loads(b)['official_game_id'] for b, in db.execute('SELECT body FROM _nhl_canonical_games')};rows=[json.loads(b) for n,b in db.execute('SELECT * FROM _official_nhl_game_reports') if n in games];count=len(rows)
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),matched_games=len(games),official_reports=dict(completed=count,total=len(games),percentage=round(count*100/len(games),2)),break_windows=dict(verified=sum(bool(b['start_utc']) for r in rows for b in r['breaks']),possible=count*2),source_issues=dict(collections.Counter(x['component']+': '+x['error'] for r in rows for x in r['issues'])),player_game_or_scratch_rows=sum(len(r['players']) for r in rows),native_players=len({p['official_player_id'] for r in rows for p in r['players']}),bio_requests_completed=db.execute("SELECT count(*) FROM _official_nhl_player_bios WHERE json_extract(body,'$.status')='ok'").fetchone()[0],free_disk_gb=round(shutil.disk_usage(ROOT).free/1024**3,2))
gs={gid:json.loads(b) for gid,b in db.execute('SELECT * FROM _nhl_canonical_games')};fs={r['official_game_id']:r for r in rows};plans=collections.defaultdict(set)
for b, in db.execute('SELECT body FROM _nhl_market_candidates'):
    c=json.loads(b);g=gs[c['game_id']];f=fs.get(g['official_game_id'])
    if not f:continue
    start=int(utc(f['actual_start_utc'] or g['start']).timestamp());plans['pre'].add(f"pre:{c['provider']}:{c['contract_id']}:pre:{start-84*3600}:{start+6*3600}")
    if c['provider']=='kalshi' and f['actual_start_utc']:
        windows=[(0,start+60,start+120)]+[(n,int(utc(b['start_utc']).timestamp()),int(utc(b['end_utc']).timestamp())) for n,b in enumerate(f['breaks'],1) if b['start_utc'] and b['end_utc']]
        for n,lo,hi in windows:
            if hi-lo<=7200:plans['break'].add(f"break:kalshi:{c['contract_id']}:{n}:{lo-60}:{hi}")
jobs={k:json.loads(b) for k,b in db.execute('SELECT * FROM _nhl_price_acquisition')};out['price_request_phases']={}
for phase,keys in plans.items():
    done=[jobs[k] for k in keys if k in jobs and jobs[k]['status']=='ok'];out['price_request_phases'][phase]=dict(completed=len(done),total=len(keys),percentage=round(len(done)*100/len(keys),2),empty_responses=sum(r.get('rows')==0 for r in done),meaning='Completed real request checks; normalized quote availability is a separate measure')
(ROOT/'reports/nhl_progress.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
