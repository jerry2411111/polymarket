"""Normal signed-out browser rendering of three official pages for manual validation."""
import datetime as dt,hashlib,json,pathlib,subprocess,tempfile,uuid
from bs4 import BeautifulSoup
from probe_history import ROOT
from request_audit import connect,save

def main():
    profile=pathlib.Path(tempfile.gettempdir())/'sentinent_ligue1_validation_edge';profile.mkdir(exist_ok=True);db=connect(ROOT);rows=[]
    for mid in ['l1_championship_match_71794','l1_championship_match_72418','l1_championship_match_73125']:
        url='https://ligue1.com/en/match-sheet/'+mid;rid=uuid.uuid4().hex;now=dt.datetime.now(dt.UTC).isoformat();r=dict(request_id=rid,method='BROWSER_VALIDATE',endpoint=url,parameters=dict(signed_out=True,virtual_time_budget_ms=15000),requested_at_utc=now,cache_key=hashlib.sha256(('browser:'+url).encode()).hexdigest(),status=None,request_state='in_flight');save(db,r)
        try:
            result=subprocess.run([r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe','--headless=new','--disable-gpu','--no-first-run','--disable-extensions','--user-data-dir='+str(profile),'--dump-dom','--virtual-time-budget=15000',url],capture_output=True,timeout=50,creationflags=subprocess.CREATE_NO_WINDOW);b=result.stdout;path=ROOT/'data/raw/responses'/(rid+'.bin');path.write_bytes(b);r.update(status='DOM_CAPTURED' if result.returncode==0 and b else 'DOM_RENDER_FAILED',request_state='complete',retrieved_at_utc=dt.datetime.now(dt.UTC).isoformat(),raw_file=path.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),browser_exit_code=result.returncode,meaning='Manual browser navigation, not an HTTP status or a count of browser subresource requests');save(db,r);s=BeautifulSoup(b,'html.parser');row=dict(match_id=mid,url=url,request_id=rid,status=r['status'],title=s.title.get_text() if s.title else None,public_text=s.get_text(' ',strip=True));print(json.dumps({**row,'public_text':row['public_text'][:6000]}),flush=True)
        except Exception as e:r.update(status='DOM_RENDER_FAILED',error=str(e),request_state='complete',retrieved_at_utc=dt.datetime.now(dt.UTC).isoformat());save(db,r);row=dict(match_id=mid,url=url,request_id=rid,error=str(e));print(json.dumps(row),flush=True)
        rows.append(row)
    (ROOT/'reports/ligue1_rendered_validation_sources.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=rows),indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
