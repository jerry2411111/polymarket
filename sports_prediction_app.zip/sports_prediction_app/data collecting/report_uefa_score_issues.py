"""Show exact retained calendar score gaps and contradictions for review."""
import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for mid,b in db.execute('SELECT * FROM _official_uefa_calendar'):
 g=json.loads(b)
 if not g.get('score_discrepancy'):continue
 m=g['raw'];print(json.dumps(dict(match_id=mid,date=g['date'],away=g['away']['name'],home=g['home']['name'],away_id=g['away']['id'],home_id=g['home']['id'],raw_score=m['score'],normalized=g['scores'],issue=g['score_discrepancy'],winner={k:dict(reason=v.get('reason'),team_id=v.get('team',{}).get('id')) for k,v in m.get('winner',{}).items()},goal_count=len(m.get('playerEvents',{}).get('scorers',[])),request_id=g['request_id'],pointer=g['pointer']),ensure_ascii=False))
db.close()
