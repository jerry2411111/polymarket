"""Inspect official documentation and page-provided baseball data structures."""
import json,re,sqlite3
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT

def main():
    c=HistoryClient();out=[]
    for url in ['https://docs.statsapi.mlb.com/','https://www.mlb.com/gameday/778297/final/box','https://www.mlb.com/scores/2025-04-16']:
        try:
            body,r=c.get(url,document=True);s=BeautifulSoup(body,'html.parser');scripts=[]
            for i,tag in enumerate(s.find_all('script')):
                text=tag.string or tag.get_text()
                if len(text)>100 and any(k in text for k in ['APOLLO','gamePk','778297','__NEXT_DATA__','REACT_QUERY']):
                    scripts.append(dict(index=i,id=tag.get('id'),type=tag.get('type'),length=len(text),prefix=text[:170],matched_keys=[k for k in ['APOLLO','gamePk','778297','__NEXT_DATA__','REACT_QUERY','boxscore','firstPitch','gameType','officialDate'] if k in text]))
            row=dict(url=url,status=r['status'],request_id=r['request_id'],bytes=len(body),title=s.title.get_text(' ',strip=True) if s.title else None,data_scripts=scripts)
        except Exception as e:row=dict(url=url,error=str(e))
        out.append(row);print(json.dumps(row),flush=True)
    (ROOT/'reports/mlb_official_page_probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8')

if __name__=='__main__':main()
