"""Add one source-backed season column without splitting provider tables."""
import json,sqlite3
from build_history_catalog import DB
from build_history_odds import export
from schema import PRE_COLUMNS,INGAME_COLUMNS
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    nba={r[0]:json.loads(r[1]) for r in db.execute('SELECT official_game_id,body FROM _official_nba_schedule')}
    labels={};facts=[]
    for gid,body in db.execute('SELECT game_id,body FROM _official_game_facts'):
        f=json.loads(body)
        if f['league']=='NBA' and f.get('official_game_id') in nba:
            n=nba[f['official_game_id']];f.update(season_year=n.get('season_year'),competition_type=n['competition_type'],classification_request_id=n['request_id'])
        elif f['league']=='NHL' and f.get('official_game_id'):
            native=f['official_game_id'];y=int(native[:4]);f.update(season_year=f'{y}-{(y+1)%100:02d}',competition_type={'01':'Preseason','02':'Regular Season','03':'Playoffs'}.get(native[4:6]))
        elif f['league']=='MLB':f['season_year']=f['date'][:4]
        f['season']=' '.join(str(f[k]) for k in ['season_year','competition_type'] if f.get(k)) or None
        labels[gid]=f['season'];facts.append((json.dumps(f),gid))
    db.executemany('UPDATE _official_game_facts SET body=? WHERE game_id=?',facts);db.commit()
    outputs=[]
    for provider in ['polymarket','kalshi']:
        for kind,columns in [('pre_match',PRE_COLUMNS),('in_game',INGAME_COLUMNS)]:
            name='_source_'+provider+'_us_'+kind;rows=[dict(r) for r in db.execute(f'SELECT * FROM {name}')]
            for r in rows:r['season']=labels.get(r['game_id'])
            if 'season' not in [r[1] for r in db.execute(f'PRAGMA table_info({name})')]:db.execute(f'ALTER TABLE {name} ADD COLUMN season TEXT')
            db.executemany(f'UPDATE {name} SET season=? WHERE game_id=?',[(r['season'],r['game_id']) for r in rows]);db.commit()
            export(provider+'/'+kind,rows,columns,db=db);outputs.append(dict(table=name,rows=len(rows),season_present=sum(r['season'] is not None for r in rows)))
    # Explicit ordering makes SQL and file schemas identical, even when adding
    # a column to an already-built table appended its physical storage column.
    from eu_schema import refresh_main_views
    refresh_main_views(db)
    db.commit();db.close();(ROOT/'reports/season_columns.json').write_text(json.dumps(outputs,indent=2),encoding='utf-8');print(json.dumps(outputs))

if __name__=='__main__':main()
