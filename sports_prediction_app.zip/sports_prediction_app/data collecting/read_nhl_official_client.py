"""Read endpoint syntax from publicly referenced NHL score/schedule modules."""
import datetime as dt,hashlib,json,re,sqlite3
from urllib.parse import urljoin
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from build_history_catalog import DB

def main():
 doc=json.loads((ROOT/'reports/nhl_current_documentation.json').read_text());source=next(r for r in doc['official_client_scripts'] if '/main.bundle.js' in r['url']);db=sqlite3.connect(DB,timeout=60)
 r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(source['request_id'],)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];text=b.decode();m=re.search(r'i\.u=e=>"js/"\+\(\{(.*?)\}\[e\]\|\|e\)\+"\."\+\{(.*?)\}\[e\]\+"\.bundle\.js"',text)
 if not m:
  m=re.search(r'i\.u=e=>"js/"\+\(\{(.*?)\}\[e\]\|\|e\)\+"\."\+\{(.*?)\}\[e\]\+"\.js"',text)
 assert m,'Current official module filename syntax changed'
 names=dict(re.findall(r'(\d+):"([^"]+)"',m[1]));hashes=dict(re.findall(r'(\d+):"([^"]+)"',m[2]));suffix='.bundle.js' if '.bundle.js' in m[0] else '.js';c=HistoryClient();HOSTS.add('wsr.nhle.com');out=[]
 for num in ['710','2228','8990','7366','9728','2230','9937','7773','1616','1977','968','6872','273','7580','4509','6131']:
  assert num in hashes;url=urljoin(source['url'],'../js/'+names.get(num,num)+'.'+hashes[num]+suffix)
  b,r=c.get(url,document=True);t=b.decode('utf-8',errors='replace');snippets=[]
  for hit in re.finditer(r'/gamecenter|club-schedule|play-by-play|/schedule|/score|/boxscore|/roster|/player/|/landing|webAPIBaseURL',t):snippets.append(t[max(0,hit.start()-60):hit.end()+170])
  row=dict(url=url,request_id=r['request_id'],endpoint_references=snippets[:35]);out.append(row);print(json.dumps(row),flush=True)
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),official_parent_script=source['url'],official_parent_request_id=source['request_id'],module_filename_rule=m[0],modules=out,new_requests=c.requests,note='Only public modules linked by the official client were read; no script execution, private assets, credentials or third-party API references used.')
 (ROOT/'reports/nhl_official_client_endpoints.json').write_text(json.dumps(report,indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
