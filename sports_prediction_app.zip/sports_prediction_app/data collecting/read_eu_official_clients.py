"""Inspect official client scripts for public result API syntax, without using site credentials."""
import argparse,datetime as dt,json,re,sqlite3
from urllib.parse import urlsplit
from bs4 import BeautifulSoup
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT,HOSTS

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--collect',action='store_true');ap.add_argument('--contains');a=ap.parse_args();db=sqlite3.connect(DB);sources=json.loads((ROOT/'reports/eu_soccer_pages_sources.json').read_text())['sources'];out=[];client=HistoryClient() if a.collect else None
    for source in sources:
        if 'request_id' not in source:continue
        url=source['url'];host=urlsplit(url).hostname
        if a.contains and a.contains not in url:continue
        path=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(source['request_id'],)).fetchone()[0])['raw_file'];s=(ROOT/path).read_text(encoding='utf-8');soup=BeautifulSoup(s,'html.parser')
        urls=[u for u in source['scripts'] if urlsplit(u).hostname==host and not any(t in u for t in ['ruxitagent','polyfills','framework','turbopack','Manifest'])]
        if host=='www.premierleague.com':urls+=['https://www.premierleague.com'+u for u in re.findall(r'import\("([^\"]+\.js)"',s)]
        print('PAGE',url,'official client assets',len(urls),flush=True)
        if not a.collect:
            for tag in soup.find_all('script',type='application/json'):
                data=json.loads(tag.get_text());print('EMBEDDED',tag.get('id'),'keys',list(data)[:25]);
                if tag.get('id')=='__NEXT_DATA__':print(json.dumps(data)[:2500])
            continue
        HOSTS.add(host)
        for u in dict.fromkeys(urls):
            try:
                b,r=client.get(u,document=True);text=b.decode('utf-8',errors='replace');matches=[]
                for m in re.finditer(r'https?:[^\s\"\x27<>\\`]{5,160}|(?:matches|fixtures|footballapi|matchday|match\.uefa|SDP_API|apiBaseUrl|baseURL)',text,re.I):
                    hit=text[max(0,m.start()-100):min(len(text),m.end()+180)]
                    if re.search(r'api|match|fixture|season|competition',hit,re.I) and not re.search(r'apiKey|apikey|access_token|authorization',hit,re.I):matches.append(hit)
                item=dict(url=u,request_id=r['request_id'],bytes=len(b),endpoint_context=list(dict.fromkeys(matches))[:150]);out.append(item);print('CLIENT',u,r['request_id'],len(b),'contexts',len(matches),flush=True)
            except Exception as e:out.append(dict(url=u,error=str(e)));print('CLIENT ERROR',u,str(e),flush=True)
    if a.collect:(ROOT/'reports'/('eu_soccer_client_syntax'+('_'+a.contains.replace('.','_') if a.contains else '')+'.json')).write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=out),indent=2),encoding='utf-8')
    db.close()

if __name__=='__main__':main()
