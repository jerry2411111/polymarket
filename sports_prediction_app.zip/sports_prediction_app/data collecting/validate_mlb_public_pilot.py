"""Real official API examples checked against independently retained MLB pages."""
import datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from collect_official_results import mlb_scoreboard
from mlb_official_api import schedule,feed
from probe_history import ROOT

def main():
    client=HistoryClient();db=sqlite3.connect(DB,timeout=60);examples=[]
    for day,native in [('2024-09-26','746088'),('2025-04-16','778297'),('2025-05-23','777815'),('2026-03-03','831817')]:
        items,r=schedule(client,day);matches=[s for s in items if s['official_game_id']==native];assert len(matches)==1,(day,native)
        s=matches[0];f=feed(client,s);body,page=client.get('https://www.mlb.com/scores/'+day,document=True);reported=[x for x in mlb_scoreboard(body,day,page['request_id']) if x['official_game_id']==native];assert len(reported)==1
        official=reported[0];assert official['teams']==f['teams'] and official['scores']==f['scores'],'API differs from official public scoreboard'
        for rid in [r['request_id'],f['request_id'],page['request_id']]:
            raw=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);assert hashlib.sha256((ROOT/raw['raw_file']).read_bytes()).hexdigest()==raw['sha256']
        examples.append(dict(date=day,official_game_id=native,teams=f['teams'],scores=f['scores'],game_number=s['game_number'],double_header=s['double_header'],competition_type=s['competition_type'],actual_first_pitch_utc=f['actual_first_pitch_utc'],break_scores=f['break_scores'],breaks=f['breaks'],roster_players=len(f['players']),played_players=sum(p['did_play'] for p in f['players']),source_schedule_request_id=r['request_id'],source_feed_request_id=f['request_id'],public_verification_url='https://www.mlb.com/scores/'+day,public_request_id=page['request_id'],raw_to_normalized=True,official_source_agreement=True))
        db.execute('CREATE TABLE IF NOT EXISTS _official_mlb_schedule (official_game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _official_mlb_schedule VALUES (?,?)',[(x['official_game_id'],json.dumps(x)) for x in items]);db.execute('CREATE TABLE IF NOT EXISTS _official_mlb_feeds (official_game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('INSERT OR REPLACE INTO _official_mlb_feeds VALUES (?,?)',(native,json.dumps(f)));db.commit();print('OFFICIAL MLB PILOT VERIFIED',day,native,f['teams'],f['scores'],flush=True)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Four real games, official schedule/feed versus official public scoreboards. This does not establish full historical endpoint stability or complete collection.',examples=examples,documentation_limitation='Partner API prose reference requires Okta. Schedule syntax is traced to the current official public Baseball Savant client, and game feeds are linked by the official schedule. No access control was bypassed.');(ROOT/'reports/mlb_public_api_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(dict(status=out['status'],examples=len(examples),requests=client.requests)));db.close()

if __name__=='__main__':main()
