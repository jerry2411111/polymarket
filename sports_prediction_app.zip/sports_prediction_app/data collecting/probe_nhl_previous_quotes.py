"""Compare real as-of observations with already retained broad-window history."""
import datetime as dt,json,sqlite3
from build_history_catalog import DB
from build_nhl_odds import load_points
from core import utc
from history_client import HistoryClient
from probe_history import ROOT
from schema import HOURS
from quote_selection import available_at,nearest_pregame

def main():
    db=sqlite3.connect(DB,timeout=60)
    pilot=json.loads((ROOT/'reports/nhl_price_pilot_validation.json').read_text())
    ids={x['game_id'] for x in pilot['examples']}
    cs={(x['provider'],x['contract_id']):x for b, in db.execute('SELECT body FROM _nhl_market_candidates') if (x:=json.loads(b))['game_id'] in ids}
    points,_,_,_=load_points(db,cs)
    client=HistoryClient();rows=[]
    for example in pilot['examples']:
        start=utc(example['actual_opening_minute']).timestamp()
        for contract in cs.values():
            if contract['game_id']!=example['game_id'] or contract['provider']!='polymarket':continue
            opened=utc(contract['open']);xs=[x for x in points if x['provider']=='polymarket' and x['contract_id']==contract['contract_id'] and x['resolution_seconds']>0 and (not opened or x['timestamp']>=opened.timestamp())]
            for hour in [HOURS[0],HOURS[1],HOURS[-1]]:
                target=int(start-hour*3600)-(1 if hour==0 else 0);ask=target;requests=[];returned=[];chosen=None
                old=nearest_pregame(xs,target,start)
                for attempt in range(8):
                    data,record=client.get('https://data-api.polymarket.com/v2/prices-history',{'token_id':contract['contract_id'],'as_of':ask})
                    requests.append(record['request_id']);assert len(data['data'])<=1 and not data.get('pagination',{}).get('next_cursor')
                    if not data['data']:break
                    point=data['data'][0];returned.append(point);assert point['timestamp']<=ask and 0<=point['price']<=1
                    if point['resolution_seconds']>0 and point['timestamp']+point['resolution_seconds']<=target:
                        if not opened or point['timestamp']>=opened.timestamp():chosen=point
                        break
                    ask=point['timestamp']-1
                row=dict(game_id=example['game_id'],date=example['date'],team=example['teams'][contract['side']],token_id=contract['contract_id'],lookback_hours=hour,target_utc=utc(target).isoformat(),broad_window_point=old,as_of_point=chosen,returned_points=returned,request_ids=requests,improvement_seconds=(chosen['timestamp']+chosen['resolution_seconds']-available_at(old)) if chosen and old else None,filled_missing=bool(chosen and not old))
                rows.append(row)
        print('NHL PREVIOUS QUOTE PROBE',example['date'],'complete',flush=True)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),documentation='https://data-api.polymarket.com/v2/openapi.json',new_requests=client.requests,tested_targets=len(rows),closer_as_of_values=sum((x['improvement_seconds'] or 0)>0 for x in rows),missing_values_recovered=sum(x['filled_missing'] for x in rows),examples=rows)
    (ROOT/'reports/nhl_previous_quote_probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in out.items() if k!='examples'}));db.close()

if __name__=='__main__':main()
