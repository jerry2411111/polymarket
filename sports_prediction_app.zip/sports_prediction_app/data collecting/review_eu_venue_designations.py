"""Retain official corroboration for reviewed physical-away and final venues."""
import datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from eu_official_games import games
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS

def main():
 db=sqlite3.connect(DB,timeout=60);c=HistoryClient();HOSTS.update({'www.uefa.com','shakhtar.com'});sources={}
 for name,url,terms in [
  ('shakhtar','https://shakhtar.com/en/news/2024/july/2_news/2_veltinsarena/',['Gelsenkirchen','Schalke','2024/25']),
  ('final2026','https://www.uefa.com/uefachampionsleague/news/029a-1df98e9a78ca-1acaca3c53b0-1000--2026-uefa-champions-league-final-where-is-it-who-is-involv/',['Budapest','Arsenal','Paris'])]:
  b,r,redirects=get(c,url);text=BeautifulSoup(b,'html.parser').get_text(' ',strip=True);assert all(t in text for t in terms);sources[name]=dict(url=url,request_id=r['request_id'],terms_verified=terms,redirects=redirects)
 rows=[]
 for mid,g in games(db,'UCL').items():
  raw=g['raw'];s=raw['stadium'];proof=None
  if mid=='2047742':
   assert g['round_type']=='FINAL' and s['id']=='250004078' and g['date']=='2026-05-30';proof=dict(basis='User physical venue convention: final at a third-country stadium, both teams away',corroboration=sources['final2026'])
  elif mid in ['2041947','2041984','2042011','2042047']:
   assert s['id']=='79089' and raw['homeTeam']['countryCode']=='UKR' and 'Shakhtar' in g['home']['name'];proof=dict(basis='User physical venue convention: Shakhtar relocated to Schalke stadium; neither participant is Schalke',corroboration=sources['shakhtar'])
  elif mid in ['2048736','2049104','2049212']:
   assert raw['homeTeam']['id']=='59340' and s['countryCode'] in ['HUN','ROU'] and raw['awayTeam']['countryCode'] not in ['HUN','ROU'];proof=dict(basis='User physical venue convention: the official fixture places the Israeli club and its foreign opponent in a third country',corroboration=None)
  if proof:rows.append(dict(competition='UCL',official_match_id=mid,game_id=g['game_id'],date=g['date'],teams=[g[x]['name'] for x in ['away','home']],home_away='Away;Away',location=g['location'],official_request_id=g['request_id'],official_pointer=g['pointer'],stadium_id=s['id'],official_designation='Away;Home',**proof))
 assert len(rows)==8
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _eu_venue_reviews (competition TEXT,match_id TEXT,body TEXT NOT NULL,PRIMARY KEY(competition,match_id)) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_venue_reviews VALUES (?,?,?)',[(r['competition'],r['official_match_id'],json.dumps(r)) for r in rows])
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',reviewed=rows,notes='Country is not a universal home/away rule: AS Monaco is a French-association club at its own stadium in Monaco. Default formal designation remains for unreviewed venues.');(ROOT/'reports/eu_venue_reviews.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('VERIFIED VENUE OVERRIDES',len(rows),'NEW REQUESTS',c.requests);db.close()

if __name__=='__main__':main()
