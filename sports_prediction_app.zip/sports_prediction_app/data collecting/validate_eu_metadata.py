"""Validate retained provider metadata against raw responses and count native-ID overlaps."""
import collections,datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);cache={};checks=collections.Counter();pm=collections.defaultdict(set);km=collections.defaultdict(set)
    def load(rid):
        if rid not in cache:
            r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert r['status']==200 and hashlib.sha256(b).hexdigest()==r['sha256'];cache[rid]=json.loads(b);checks['raw_sha256']+=1
        return cache[rid]
    for comp,eid,rid,ptr,b in db.execute('SELECT * FROM _eu_pm_event_sources'):
        data=load(rid);e=json.loads(b);assert data['events'][int(ptr.rsplit('/',1)[-1])]==e and str(e['id'])==eid;pm[eid].add(comp);checks['polymarket_raw_event_equal']+=1
    for comp,ticker,route,rid,ptr,b in db.execute('SELECT * FROM _eu_kalshi_market_sources'):
        data=load(rid);m=json.loads(b);assert data['markets'][int(ptr.rsplit('/',1)[-1])]==m and m['ticker']==ticker;km[ticker].add(route);checks['kalshi_raw_market_equal']+=1
    with db:
        db.execute('CREATE VIEW IF NOT EXISTS _eu_pm_events AS SELECT competition,event_id,request_id,pointer,body FROM (SELECT s.*,row_number() OVER (PARTITION BY event_id ORDER BY a.request_number DESC,competition) AS version_order FROM _eu_pm_event_sources s JOIN _request_audit a USING(request_id)) WHERE version_order=1')
        db.execute('CREATE VIEW IF NOT EXISTS _eu_kalshi_markets AS SELECT competition,ticker,route,request_id,pointer,body FROM (SELECT s.*,row_number() OVER (PARTITION BY ticker ORDER BY a.request_number DESC,route) AS version_order FROM _eu_kalshi_market_sources s JOIN _request_audit a USING(request_id)) WHERE version_order=1')
    assert db.execute('SELECT count(*) FROM _eu_pm_events').fetchone()[0]==len(pm) and db.execute('SELECT count(*) FROM _eu_kalshi_markets').fetchone()[0]==len(km)
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',coverage_status='METADATA_ONLY',checks=dict(checks),polymarket_unique_native_events=len(pm),polymarket_competition_event_combinations=sum(map(len,pm.values())),polymarket_multi_competition_tag_events={eid:sorted(c) for eid,c in pm.items() if len(c)>1},kalshi_unique_native_markets=len(km),kalshi_markets_in_both_routes=[t for t,rs in km.items() if len(rs)>1],limitations=['A tag is discovery evidence, not verified league membership. Native event IDs are deduplicated across competition tags.','Distinct event counts include spreads, totals, season propositions, future games and other records until official fixture/rule classification.','Successful metadata calls do not prove historical quote availability.'])
    (ROOT/'reports/eu_soccer_metadata_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['polymarket_multi_competition_tag_events','kalshi_markets_in_both_routes']}),'multi_competition',len(report['polymarket_multi_competition_tag_events']),'duplicate_route',len(report['kalshi_markets_in_both_routes']),flush=True);db.close()

if __name__=='__main__':main()
