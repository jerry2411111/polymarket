"""Reviewed club/league evidence for two documented football playing-name aliases."""
import datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from collect_laliga_people import namekey
from probe_history import ROOT
db=sqlite3.connect(DB);reviews=[]
sources={r['url']:r for b, in db.execute('SELECT body FROM _eu_editorial_sources') for r in [json.loads(b)]}
specs=[('EU_UCL:250121533','Vini Jr.','https://www.realmadrid.com/fr-FR/football/equipe-premiere/effectif/vinicius-paixao-de-oliveira-junior','2000-07-12',['Vini Jr.','Vinicius Paixao de Oliveira Junior']),('EU_UCL:250101284','Fede Valverde','https://www.laliga.com/en-GB/player/valverde-1','1998-07-22',['Federico Valverde','Fede Valverde'])]
for pid,alias,url,dob,evidence in specs:
 r=sources[url];meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(r['request_id'],)).fetchone()[0]);raw=(ROOT/meta['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==meta['sha256'];s=BeautifulSoup(raw,'html.parser');text=s.get_text(' ',strip=True);full=raw.decode('utf-8');p=json.loads(db.execute('SELECT body FROM _eu_people_registry WHERE person_id=?',(pid,)).fetchone()[0]);assert p['birth_date']==dob
 for phrase in evidence:assert namekey(phrase) in namekey(text) or namekey(phrase) in namekey(full),(pid,phrase)
 # The immutable official lineup native ID, club and DOB remain the second
 # and third matching checks in the registry; this review adds only the alias.
 row=dict(source_person_id=pid,alias=alias,request_id=r['request_id'],url=url,evidence=evidence,birth_date=dob,source_name=p['person_name'],review='Official club or responsible-league page explicitly uses both short/expanded name forms; native DOB and dated same-club matching are separately required before merging.');reviews.append(row)
with db:
 db.execute('CREATE TABLE IF NOT EXISTS _eu_documented_player_aliases (source_person_id TEXT,alias TEXT,body TEXT NOT NULL,PRIMARY KEY(source_person_id,alias)) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_documented_player_aliases VALUES (?,?,?)',[(r['source_person_id'],r['alias'],json.dumps(r)) for r in reviews])
print(json.dumps(dict(status='WORKING',reviews=len(reviews))));db.close()
