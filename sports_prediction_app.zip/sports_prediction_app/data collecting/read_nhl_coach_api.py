"""Inspect the official records client before implementing coach-history access."""
import datetime as dt,json,re
from urllib.parse import urljoin,urlsplit
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

HOSTS.add('records.nhl.com');c=HistoryClient();url='https://records.nhl.com/registry/head-coach-regular-season';b,r=c.get(url,document=True);s=BeautifulSoup(b,'html.parser');out=[]
for script in s.find_all('script',src=True):
    u=urljoin(url,script['src'])
    if urlsplit(u).hostname!='records.nhl.com':continue
    b,sr=c.get(u,document=True);t=b.decode('utf-8',errors='replace');snippets=[]
    for m in re.finditer(r'coach|head-coach|api/|apiBase|baseURL',t,re.I):
        v=t[max(0,m.start()-90):m.end()+160]
        if '/api/' in v or 'coach' in v.lower():snippets.append(v)
    out.append(dict(url=u,request_id=sr['request_id'],snippets=snippets[:100]));print(u,sr['request_id'],flush=True)
    match=re.search(r'i\.u=e=>"js/"\+\(\{(.*?)\}\[e\]\|\|e\)\+"\."\+\{(.*?)\}\[e\]\+"(\.[^"]+)"',t)
    if match:
        names=dict(re.findall(r'(\d+):"([^"]+)"',match[1]));hashes=dict(re.findall(r'(\d+):"([^"]+)"',match[2]))
        for num in ['2537','1547','4453','1030','8754','3732']:
            if num not in hashes:continue
            module=urljoin(u,'../js/'+names.get(num,num)+'.'+hashes[num]+match[3]);mb,mr=c.get(module,document=True);mt=mb.decode();ms=[]
            for hit in re.finditer(r'/site/api/|coachId|coach-id|coachSeason|coach-season',mt):ms.append(mt[max(0,hit.start()-110):hit.end()+250])
            out.append(dict(url=module,request_id=mr['request_id'],snippets=ms));print('MODULE',module,json.dumps(ms[:20]),flush=True)
    else:print('MODULE RULE',[(m.start(),t[max(0,m.start()-20):m.start()+120]) for m in re.finditer(r'\.u=',t)][:3])
report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),official_page=url,page_request_id=r['request_id'],public_client_scripts=out,new_requests=c.requests)
(ROOT/'reports/nhl_coach_api_documentation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
