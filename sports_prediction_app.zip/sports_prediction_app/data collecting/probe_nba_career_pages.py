import json
from collect_nba_profiles import next_data
from history_client import HistoryClient
from probe_history import ROOT

c=HistoryClient();rows=[]
for pid in ['1626158','1630231','1643092']:
    url=f'https://www.nba.com/stats/player/{pid}/career'
    try:
        b,r=c.get(url,document=True);p=next_data(b)
        row=dict(id=pid,source_url=url,request_id=r['request_id'],page=p);rows.append(row)
        print(json.dumps(dict(id=pid,request_id=r['request_id'],keys=list(p),player_keys=list(p.get('player',{})),info=p.get('player',{}).get('info'),stats=p.get('player',{}).get('stats')))[:12000],flush=True)
    except Exception as e:print(pid,str(e),flush=True)
(ROOT/'reports/nba_career_page_probe.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
