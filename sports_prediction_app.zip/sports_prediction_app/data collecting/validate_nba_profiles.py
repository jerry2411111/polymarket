"""Independently check real dated profiles and t-1 evidence boundaries."""
import collections,datetime as dt,hashlib,json,math,sqlite3,statistics,time
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT

def equal(a,b):
    return a is None and b is None or a is not None and b is not None and math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-8)

def main():
    began=time.monotonic();db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    raw=[dict(r) for r in db.execute("SELECT * FROM _player_game_results WHERE league='NBA' ORDER BY game_date,game_id")]
    dates=['2024-06-01','2025-02-16','2026-01-15','2026-09-14'];checks=[]
    numeric=['overall_winrate','average_score_per_game','std_score_per_game','average_assists_per_game','std_assists_per_game','average_minutes_per_game','std_minutes_per_game','starter_percentage_overall']
    for day in dates:
        grouped=collections.defaultdict(list)
        for r in raw:
            if '2024-01-01'<=r['game_date']<=day:grouped[r['player_id']].append(r)
        means={pid:statistics.mean(x['score'] for x in rs) for pid,rs in grouped.items() if all(x['score'] is not None for x in rs)}
        mu=statistics.mean(means.values());sigma=statistics.pstdev(means.values());n=0
        for p in db.execute("SELECT * FROM player_profiles WHERE league='NBA' AND as_of_date=?",(day,)):
            rs=grouped.get(p['player_id'],[]);expected={k:None for k in numeric}
            if rs:
                expected['overall_winrate']=statistics.mean(x['win'] for x in rs)
                for source,mean_col,std_col in [('score','average_score_per_game','std_score_per_game'),('assists','average_assists_per_game','std_assists_per_game'),('minutes','average_minutes_per_game','std_minutes_per_game')]:
                    xs=[x[source] for x in rs]
                    if all(x is not None for x in xs):
                        expected[mean_col]=statistics.mean(xs);expected[std_col]=statistics.stdev(xs) if len(xs)>1 else None
                if all(x['starter'] is not None for x in rs):expected['starter_percentage_overall']=statistics.mean(x['starter'] for x in rs)
            for k,v in expected.items():assert equal(p[k],v),(day,p['player_id'],k,p[k],v)
            z=(means[p['player_id']]-mu)/sigma if p['player_id'] in means and sigma else None
            assert equal(p['score_z_score'],z),(day,p['player_id'],'z');n+=1
        checks.append(dict(as_of_date=day,profile_rows_checked=n,played_players=len(grouped),metric_checks=n*(len(numeric)+1)))
    # Every profile attached to a game must already exist at t-1. Audit sources
    # cannot be the target game, a later game, or another competition program.
    games={r['id']:json.loads(r['body']) for r in db.execute('SELECT * FROM _nba_canonical_games')}
    links=list(db.execute("SELECT * FROM game_player_profiles WHERE game_id LIKE 'NBA_%'"));bygame=collections.defaultdict(set)
    for r in links:
        expected=(dt.date.fromisoformat(games[r['game_id']]['date'])-dt.timedelta(days=1)).isoformat()
        assert r['as_of_date']==expected;bygame[r['game_id']].add(r['player_id'])
    missing=db.execute("SELECT COUNT(*) FROM game_player_profiles l LEFT JOIN player_profiles p ON p.player_id=l.player_id AND p.as_of_date=l.as_of_date WHERE l.game_id LIKE 'NBA_%' AND p.player_id IS NULL").fetchone()[0];assert missing==0
    source_checks=0
    for r in db.execute('SELECT body FROM _nba_game_profile_link_audit'):
        a=json.loads(r[0]);assert a['profile_links']==len(bygame[a['game_id']])
        for s in a['prior_roster_sources']:
            assert s['observed_date']<=a['as_of_date']
            for src in s['roster_sources']:
                assert src['observed_date']<=a['as_of_date'] and src['game_id']!=a['game_id']
                g=games[src['game_id']];program='Summer League' if 'Summer League' in g['season'] else 'All-Star' if 'All-Star' in g['season'] else 'NBA'
                assert program==a['program'];source_checks+=1
    # Numeric range and missing-value checks over every generated NBA row.
    assert db.execute("SELECT COUNT(*) FROM player_current_team WHERE league='NBA'").fetchone()[0]==db.execute("SELECT COUNT(*) FROM player_profiles WHERE league='NBA'").fetchone()[0]
    assert db.execute("SELECT COUNT(*) FROM player_current_team m JOIN player_profiles p USING(player_id,as_of_date) WHERE m.league='NBA' AND m.current_team IS NOT p.team").fetchone()[0]==0
    for col in ['overall_winrate','participation_rate_current_team','participation_rate_overall','starter_percentage_current_team','starter_percentage_overall']:
        assert db.execute('SELECT COUNT(*) FROM player_profiles WHERE league=\'NBA\' AND ('+col+'<0 OR '+col+'>1)').fetchone()[0]==0,col
    assert db.execute("SELECT COUNT(*) FROM player_profiles WHERE league='NBA' AND months_serving_current_team<0").fetchone()[0]==0
    assert db.execute("SELECT COUNT(*) FROM player_profiles p WHERE league='NBA' AND injured_times_till_as_of_date IS NOT NULL AND EXISTS (SELECT 1 FROM _nba_injury_observations i WHERE i.player_id=p.player_id AND i.reported_injured=1 AND i.observation_date<=p.as_of_date)").fetchone()[0]==0
    # Real official individual pages: DOB, height and weight conversion.
    bio_checks=[]
    for pid in ['NBA:1629029','NBA:203897','NBA:1628370']:
        b=db.execute('SELECT * FROM _nba_player_bio_constants WHERE player_id=?',(pid,)).fetchone();audit=json.loads(b['audit_json'])
        rid=audit['field_source_request_ids']['height'];r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);payload=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(payload).hexdigest()==r['sha256']
        node=BeautifulSoup(payload,'html.parser').find('script',id='__NEXT_DATA__');info=json.loads(node.string)['props']['pageProps']['player']['info']
        height=info['HEIGHT'];weight=info['WEIGHT'];feet,inches=map(int,height.split('-'))
        assert equal(b['height_cm'],(feet*12+inches)*2.54) and equal(b['weight_kg'],float(weight)*0.45359237)
        dob=info['BIRTHDATE'][:10];assert b['birth_date']==dob
        for day in dates:
            p=db.execute('SELECT age FROM player_profiles WHERE player_id=? AND as_of_date=?',(pid,day)).fetchone()
            if p:
                d=dt.date.fromisoformat(day);born=dt.date.fromisoformat(dob);assert p[0]==d.year-born.year-((d.month,d.day)<(born.month,born.day))
        bio_checks.append(dict(player_id=pid,player_name=b['player_name'],source_url=r['endpoint'],request_id=rid,raw_height=height,height_cm=b['height_cm'],raw_weight=weight,weight_kg=b['weight_kg'],birth_date=dob,match=True))
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',coverage_status='PARTIAL',nba_profile_rows=db.execute("SELECT COUNT(*) FROM player_profiles WHERE league='NBA'").fetchone()[0],date_checks=checks,game_to_t_minus_one_links=len(links),prior_roster_source_checks=source_checks,biography_examples=bio_checks,limitations=['Observed affiliations are not a complete transaction archive.','Participation denominators are collected roster observations.','Distinct injury counts and complete career team counts remain unavailable.','Summer League and All-Star prior-roster gaps are explicit.'],elapsed_seconds=round(time.monotonic()-began,2))
    (ROOT/'reports/nba_profiles_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));db.close()

if __name__=='__main__':main()
