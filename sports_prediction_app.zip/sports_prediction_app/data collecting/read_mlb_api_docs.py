﻿import json,sqlite3,re
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT
c=HistoryClient();out=[]
for path in ['getting-started/authentication-authorization','getting-started/request-basics','getting-started/rate-limiting','game-data/gumbo','reference']:
 u='https://docs.statsapi.mlb.com/'+path
 try:
  b,r=c.get(u,document=True);s=BeautifulSoup(b,'html.parser');t=s.get_text(' ',strip=True);out.append(dict(url=u,status=r['status'],request_id=r['request_id'],text=t[:7000],size=len(b)));print(path,'BYTES',len(b),'TEXT',t[:1200])
 except Exception as e:out.append(dict(url=u,error=str(e)));print(path,str(e))
(ROOT/'reports/mlb_api_documentation_access.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
