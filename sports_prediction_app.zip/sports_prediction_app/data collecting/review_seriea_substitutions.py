"""Correct four participant IDs only where an independent official report proves them."""
import datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
from collect_laliga_people import namekey
RULES=[
 ('SEA_20250420_ATA_MIL','613_612_serie-a::opta::Football_Match::cxqx0t7pg5jnjlxi35fsyh89g','Riccardo Sottil',"Pulisic (30'st Sottil)",75),
 ('SEA_20250423_JUV_PAR','564_563_serie-a::opta::Football_Match::cyiekzg8onyaa09dnyc080owk','Dennis Man',"Pellegrino (29' st Man)",74),
 ('SEA_20250518_LAZ_INT','788_789_serie-a::opta::Football_Match::dctrzv3ak36neqpo7qw1cbcwk','Samuel Gigot',"Gila (2 Gigot 97')",97),
 ('SEA_20250518_MIL_ROM','757_756_serie-a::opta::Football_Match::derxdfe27i2wmo9fu1p88ksno','Riccardo Sottil',"Gabbia (84' Sottil)",84)]
db=sqlite3.connect(DB,timeout=60);out=[]
for gid,eid,name,phrase,minute in RULES:
 source=json.loads(db.execute('SELECT body FROM _seriea_official_correction_sources WHERE game_id=?',(gid,)).fetchone()[0]);assert source['status']=='ok';meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(source['request_id'],)).fetchone()[0]);raw=(ROOT/meta['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==meta['sha256'];text=BeautifulSoup(raw,'html.parser').get_text(' ',strip=True);assert phrase in text
 players=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_source_player_game_facts WHERE game_id=?',(gid,))];byid={p['official_player_id']:p for p in players};report=json.loads(db.execute('SELECT body FROM _official_seriea_game_reports WHERE match_id=?',(players[0]['official_match_id'],)).fetchone()[0]);es=report['sources']['feed']['data']['events'];matches=[(i,e) for i,e in enumerate(es) if e['eventId']==eid];assert len(matches)==1;i,e=matches[0];side=next(s for s in ['away','home'] if e.get(s));p=e[side]['player'];off=p['relatedPlayerId'];bad=p['playerId'];assert byid[off]['side']!=byid[bad]['side'];found=[q for q in players if byid[off]['side']==q['side'] and namekey(name) in {namekey(n) for n in [q['player_name'],q['raw_player'].get('shortName'),*q.get('aliases',[])] if n}];assert len(found)==1,(gid,name,[q['player_name'] for q in players]);new=found[0];assert not new['starter'];record=dict(game_id=gid,event_id=eid,field='substitution_player_on',old_player_id=bad,new_player_id=new['official_player_id'],player_off_id=off,official_club_report=source,verified_phrase=phrase,reported_game_minute=minute,raw_league_request_id=report['sources']['feed']['request_id'],raw_pointer='/events/'+str(i)+'/'+side+'/player/playerId',clock_policy='Correct the participant only. Absolute substitution timestamp remains unverified and is not used for playing minutes.');out.append(record)
with db:
 db.execute('CREATE TABLE IF NOT EXISTS _eu_source_event_corrections (game_id TEXT,event_id TEXT,body TEXT NOT NULL,PRIMARY KEY(game_id,event_id)) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_source_event_corrections VALUES (?,?,?)',[(r['game_id'],r['event_id'],json.dumps(r)) for r in out])
(ROOT/'reports/seriea_substitution_corrections.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',corrections=out),indent=2),encoding='utf-8');print('OFFICIAL SUBSTITUTION CORRECTIONS',len(out));db.close()
