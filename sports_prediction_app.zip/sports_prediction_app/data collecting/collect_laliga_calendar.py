"""Date-batched official results-page fallback after the public API returned 401."""
import argparse,calendar,collections,datetime as dt,hashlib,json,math,sqlite3
from zoneinfo import ZoneInfo
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def props(raw):return json.loads(BeautifulSoup(raw,'html.parser').find('script',id='__NEXT_DATA__').get_text())['props']['pageProps']

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100;HOSTS.add('www.laliga.com');client=HistoryClient();db=sqlite3.connect(DB,timeout=60)
    for table,key in [('_official_laliga_calendar','match_id'),('_official_laliga_rounds','round_key')]:db.execute('CREATE TABLE IF NOT EXISTS '+table+' ('+key+' TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
    db.commit();seeds=[s for s in json.loads((ROOT/'reports/eu_soccer_archive_pages.json').read_text())['sources'] if 'laliga.com' in s['url']];seeds.append(dict(request_id='23cb1b565e4f479cad63ef0c9b10e1c5'));rounds=collections.defaultdict(list)
    for s in seeds:
        r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(s['request_id'],)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];p=props(b);year=str(p['season'])
        for w in p['gameweekList']:
            if w['date'][:10]>'2026-09-14':continue
            # Earlier rounds in the boundary season are checked once to catch
            # games postponed across New Year, then excluded by actual game date.
            month=max(w['date'][:7],'2024-01');rounds[month].append((year,w['week']))
    parts=[];day=dt.date(2024,1,1);new=0
    while day<=dt.date(2026,9,14) and len(parts)<math.ceil(33*a.through_percent/100):
        month=day.strftime('%Y-%m');errors=[];before_requests=client.requests
        for year,week in rounds[month]:
            key=year+':'+str(week)
            if db.execute('SELECT 1 FROM _official_laliga_rounds WHERE round_key=?',(key,)).fetchone():continue
            url=f'https://www.laliga.com/en-GB/laliga-easports/results/{year}-{str(int(year)+1)[2:]}/gameweek-{week}'
            try:
                b,r=client.get(url,document=True);p=props(b);assert str(p['season'])==year and p['gameweek']['week']==week;matches=p['matches'];assert len(matches)==10;ids=set();rows=[]
                for i,m in enumerate(matches):
                    mid=str(m['id']);assert mid not in ids;ids.add(mid);assert m['subscription']['slug']=='laliga-easports-'+year;when=dt.datetime.fromisoformat(m['date']);assert when.tzinfo
                    local=when.astimezone(ZoneInfo('Atlantic/Canary' if m['home_team']['slug']=='ud-las-palmas' else 'Europe/Madrid'));date=local.date().isoformat()
                    if not '2024-01-01'<=date<='2026-09-14' or m['status']!='FullTime':continue
                    scores=[m['away_score'],m['home_score']];assert all(type(s)is int and s>=0 for s in scores);assert m['away_team']['id']!=m['home_team']['id'];teams=[m['away_team'],m['home_team']]
                    row=dict(official_match_id=mid,competition='LaLiga',season=year+'-'+str(int(year)+1)[2:],date=date,scheduled_start_utc=when.astimezone(dt.UTC).isoformat(),away=m['away_team'],home=m['home_team'],scores=scores,winner='Draw' if scores[0]==scores[1] else teams[int(scores[1]>scores[0])]['name'],location=m.get('venue',{}).get('name'),status=m['status'],request_id=r['request_id'],pointer='/props/pageProps/matches/'+str(i),raw=m)
                    old=db.execute('SELECT body FROM _official_laliga_calendar WHERE match_id=?',(mid,)).fetchone();assert not old or json.loads(old[0])['raw']==m,'Changed same native match across rounds';rows.append((mid,json.dumps(row)))
                with db:
                    db.executemany('INSERT OR REPLACE INTO _official_laliga_calendar VALUES (?,?)',rows);db.execute('INSERT INTO _official_laliga_rounds VALUES (?,?)',(key,json.dumps(dict(season=year,week=week,request_id=r['request_id'],source_games=10,in_scope_completed=len(rows)))))
                new+=1
            except Exception as e:errors.append(dict(season=year,week=week,error=str(e)));print('LALIGA ROUND ERROR',errors[-1],flush=True);break
        parts.append(dict(month=month,expected_rounds=len(rounds[month]),errors=errors));total=db.execute('SELECT count(*) FROM _official_laliga_calendar').fetchone()[0];out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='ACQUIRED_REQUIRES_FULL_RAW_VALIDATION',total_months=33,months_processed=len(parts),rounds_acquired=db.execute('SELECT count(*) FROM _official_laliga_rounds').fetchone()[0],completed_games=total,new_requests=client.requests,months=parts,limits=['Official API key unavailable; only official result pages are parsed.','Round dates partition requests; actual game dates filter retained facts, including postponed games.','No market, break timing, performance or quote coverage is implied by calendar counts.']);(ROOT/'reports/laliga_calendar_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        if client.requests>before_requests or errors:print('LALIGA CALENDAR MONTH',month,'completed games',total,'months',len(parts),'/33','errors',len(errors),flush=True)
        if errors:break
        day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
    db.close()

if __name__=='__main__':main()
