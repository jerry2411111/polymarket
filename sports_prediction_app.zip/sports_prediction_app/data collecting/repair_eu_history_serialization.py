"""Repair one verified comma-containing club name without changing history facts."""
import datetime as dt,json,sqlite3
from pathlib import Path
from build_history_catalog import DB
from probe_history import ROOT
from team_history_cells import encode,decode
builder=Path(__file__).with_name('build_eu_dated_profiles.py');s=builder.read_text(encoding='utf-8')
if 'from team_history_cells import encode' not in s:s=s.replace('import ', 'from team_history_cells import encode\nimport ',1)
s=s.replace("served_team_history=','.join(p['history']) or None", "served_team_history=encode(p['history'])");builder.write_text(s,encoding='utf-8')
validator=Path(__file__).with_name('validate_eu_dated_profiles.py');s=validator.read_text(encoding='utf-8')
if 'from team_history_cells import decode' not in s:s=s.replace('import ', 'from team_history_cells import decode\nimport ',1)
s=s.replace("p['served_team_history'].split(',')", "decode(p['served_team_history'])").replace("r['served_team_history'].split(',')", "decode(r['served_team_history'])");validator.write_text(s,encoding='utf-8')
db=sqlite3.connect(DB,timeout=60);pid='EU_LAL:p244273';club='Club de Futbol Reus Deportiu, S.A.D.'
assert db.execute("SELECT count(*) FROM _eu_player_memberships WHERE json_extract(body,'$.player_id')=? AND json_extract(body,'$.team_name')=?",(pid,club)).fetchone()[0]>0
rows=db.execute('SELECT as_of_date,served_team_history FROM player_profiles WHERE player_id=?',(pid,)).fetchall();changed=0
with db:
 for day,text in rows:
  if club in decode(text):continue
  assert text.count(club)==1;parts=text.replace(club,'__VERIFIED_COMMA_CLUB__').split(',');names=[club if t=='__VERIFIED_COMMA_CLUB__' else t for t in parts];value=encode(names);assert decode(value)==names
  db.execute('UPDATE player_profiles SET served_team_history=? WHERE player_id=? AND as_of_date=?',(value,pid,day));changed+=1
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',player_id=pid,rows_corrected=changed,meaning='Serialization only: a comma inside an official club name must be CSV-quoted within the comma-separated history cell. No dates or team identities changed.');(ROOT/'reports/eu_history_serialization.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
