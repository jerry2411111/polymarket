"""Independent raw/source checks over every acquired Premier League game report."""
import collections,datetime as dt,json,sqlite3
from zoneinfo import ZoneInfo
from build_history_catalog import DB
from probe_history import ROOT
from epl_price_points import Sources,pointer

def main():
    db=sqlite3.connect(DB);src=Sources(db);rows=db.execute('SELECT * FROM _official_epl_game_reports').fetchall();checks=collections.Counter();issues=[];verified=[]
    for mid,b in rows:
        g=json.loads(b)
        if 'derived' not in g:continue
        m,mr=src.get(g['sources']['match']['request_id']);assert m==g['sources']['match']['data'] and m['matchId']==mid;calendar=json.loads(db.execute('SELECT body FROM _official_epl_calendar WHERE match_id=?',(mid,)).fetchone()[0]);raw,_=src.get(calendar['request_id']);assert pointer(raw,calendar['pointer'])==calendar['raw']
        for key in ['homeTeam','awayTeam','kickoff','kickoffTimezone','kickoffTimezoneString','ground','period','competitionId']:assert m[key]==calendar['raw'][key];checks['calendar_to_single_match_fields']+=1
        for name,s in g['sources'].items():
            if 'data' in s:raw,_=src.get(s['request_id']);assert raw==s['data'];checks['complete_raw_response_values']+=1
        c=g['commentary_complete'];allrows=[]
        for rid in c['request_ids']:
            raw,r=src.get(rid);assert '/matches/'+mid+'/commentary' in r['endpoint'];allrows+=raw['data']
        raw,_=src.get(c['request_ids'][-1]);assert not raw['pagination'].get('_next') and c['pagination_exhausted'];assert len(allrows)==len(c['rows'])+len(c.get('exact_duplicates',[]))
        for v in c['rows']:
            raw,_=src.get(v['request_id']);assert pointer(raw,v['pointer'])==v['raw'];checks['raw_commentary_rows']+=1
        for v in c.get('exact_duplicates',[]):
            a,_=src.get(v['duplicate']['request_id']);b,_=src.get(v['retained']['request_id']);assert pointer(a,v['duplicate']['pointer'])==pointer(b,v['retained']['pointer']);checks['verified_duplicate_commentary']+=1
        lineups=g['sources']['lineups']['data'];players=set()
        for side in ['home','away']:
            t=lineups[side+'_team'];assert t['teamId']==m[side+'Team']['id'];ids=[p['id'] for p in t['players']];assert len(ids)==len(set(ids)) and not players.intersection(ids);players.update(ids);starting=[p for group in t['formation']['lineup'] for p in group];assert len(starting)==11 and set(starting)<=set(ids);checks['roster_people']+=len(ids);checks['managers']+=len(t['managers'])
        d=g['derived'];local_zone=ZoneInfo(m['kickoffTimezoneString']);scheduled=dt.datetime.fromisoformat(m['kickoff']).replace(tzinfo=local_zone);assert scheduled.tzname()==m['kickoffTimezone'];assert scheduled.astimezone(dt.UTC).isoformat()==d['scheduled_start_utc']
        for field,point in d['checkpoint_sources'].items():
            if point and d[field]:
                expected=dt.datetime.fromisoformat(point['raw']['timestamp']).replace(tzinfo=local_zone).astimezone(dt.UTC).isoformat();assert expected==d[field];checks['normalized_checkpoint_clocks']+=1
        for prefix,key in [('First Half ends','halfTimeScore'),('Second Half begins','halfTimeScore'),('Second Half ends','score')]:
            expected=m['homeTeam']['name']+' '+str(m['homeTeam'][key])+', '+m['awayTeam']['name']+' '+str(m['awayTeam'][key])
            for v in c['rows']:
                if isinstance(v['raw'].get('comment'),str) and v['raw']['comment'].startswith(prefix):assert expected in v['raw']['comment'];checks['commentary_to_summary_scores']+=1
        if d['issues']:issues.append(dict(match_id=mid,date=calendar['date'],issues=d['issues']))
        verified.append(mid)
    wanted={r[0] for r in db.execute("SELECT DISTINCT json_extract(body,'$.official_match_id') FROM _epl_market_families")};missing=sorted(wanted-set(verified));out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING' if missing or issues else 'WORKING',scope='All acquired official EPL game reports; missing checkpoints are not imputed',verified_games=len(verified),candidate_games=len(wanted),missing_candidate_reports=len(missing),verified_match_ids=verified,checks=dict(checks),raw_hash_checks=len(src.cache),checkpoint_issues=issues);(ROOT/'reports/epl_full_report_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='verified_match_ids'}));db.close()

if __name__=='__main__':main()
