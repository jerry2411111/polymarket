"""Summarize the current public schema, without retired datasets."""
import datetime as dt,json
from probe_history import ROOT
def main():
    reports=ROOT/'reports'
    catalog=json.loads((reports/'data_catalog_validation.json').read_text(encoding='utf-8'))
    lines=['# Dataset revision','', 'Updated '+dt.datetime.now(dt.UTC).isoformat()+'.','',
      'Salary and employment-contract tables, exports, dedicated source files and query options have been removed by request. Team history omits salary_year.',
      'Game odds, official scores, player/manager profiles, daily cumulative performance, affiliations, rankings and weather remain available.',
      'Shared source responses used to verify biographies or team service remain as nonfinancial provenance.',
      '',f"The catalog describes {catalog['sql_interfaces']} SQL interfaces and {catalog['export_datasets']} exported datasets.",
      '', '[Structure, every field, units and sources](data_catalog.html). [Column missing percentages](data_catalog_missing.csv).']
    (reports/'revision_summary.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
if __name__=='__main__':main()
