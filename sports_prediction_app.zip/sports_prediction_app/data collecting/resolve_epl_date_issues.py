"""Review date mismatches using official fixture notices, calendars and completed reports."""
import datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_premier_market_candidates import clean,utc
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def main():
    db=sqlite3.connect(DB,timeout=60);c=HistoryClient();HOSTS.add('www.premierleague.com');games=[json.loads(b) for b, in db.execute('SELECT body FROM _official_epl_calendar')];out=[]
    for eid,day,home,away,article,required in [('12478','2024-09-14','91','8','4109077',['14 Sep 2024','1-0']),('15012','2025-02-12','11','14','4221175',['12 February 2025','7 December']),('23882','2025-05-16','7','6','4303800',['Friday 16 May','19:30 BST'])]:
        url='https://www.premierleague.com/en/news/'+article;b,r=c.get(url,document=True);text=BeautifulSoup(b,'html.parser').get_text(' ',strip=True).replace('–','-');assert all(v in text for v in required),(url,required);found=[g for g in games if g['date']==day and g['home']['id']==home and g['away']['id']==away];assert len(found)==1;g=found[0];e=json.loads(db.execute('SELECT body FROM _eu_pm_events WHERE event_id=?',(eid,)).fetchone()[0]);assert {clean(t) for t in [g['home']['name'],g['away']['name']]} # Actual native teams are rechecked in the matcher.
        out.append(dict(provider='polymarket',family_id=eid,official_match_id=g['official_match_id'],date=day,reason='Official fixture notice/report establishes corrected game date; original provider dates are preserved',provider_start_time=e.get('startTime'),provider_market_start_times=[m.get('gameStartTime') for m in e['markets']],official_schedule_request_id=g['request_id'],official_notice_url=url,official_notice_request_id=r['request_id']))
    for b, in db.execute("SELECT body FROM _epl_matching_issues WHERE json_extract(body,'$.provider')='kalshi'"):
        issue=json.loads(b);eid=issue['event_id'];ms=[json.loads(b) for b, in db.execute("SELECT body FROM _eu_kalshi_markets WHERE json_extract(body,'$.event_ticker')=?",(eid,))];labels=[m['yes_sub_title'] for m in ms if clean(m['yes_sub_title']) not in ['tie','draw']];assert len(labels)==2
        settled={utc(m['settlement_ts']).date().isoformat() for m in ms};closed={utc(m['close_time']).date().isoformat() for m in ms};assert len(settled)==1 and settled==closed;day=next(iter(settled));assert abs((dt.date.fromisoformat(day)-dt.date.fromisoformat(issue['date'])).days)<=7
        found=[g for g in games if g['date']==day and all(any(clean(g[s]['name']).startswith(clean(label)) for s in ['home','away']) for label in labels)];assert len(found)==1;g=found[0];assert all(90*60<(utc(m['settlement_ts'])-utc(g['scheduled_start_utc'])).total_seconds()<6*3600 for m in ms)
        f=db.execute('SELECT body FROM _official_epl_game_reports WHERE match_id=?',(g['official_match_id'],)).fetchone();assert f,'Acquire the official report before resolving an archive ticker date';f=json.loads(f[0]);end=utc(f['derived']['regulation_end_utc']);assert end and all(0<=(utc(m['settlement_ts'])-end).total_seconds()<3600 for m in ms)
        for m in ms:assert (m['result']=='yes')==(clean(m['yes_sub_title']) in ['tie','draw'] if g['winner']=='Draw' else clean(g['winner']).startswith(clean(m['yes_sub_title'])))
        out.append(dict(provider='kalshi',family_id=eid,official_match_id=g['official_match_id'],date=day,original_ticker_date=issue['date'],reason='Three native contracts close and settle on the same corrected fixture day, within one hour after the official final whistle; all results agree',official_schedule_request_id=g['request_id'],official_report_request_id=f['sources']['match']['request_id'],official_regulation_end_utc=end.isoformat(),settlement_times=[m['settlement_ts'] for m in ms]))
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _epl_date_resolutions (provider TEXT,family_id TEXT,body TEXT NOT NULL,PRIMARY KEY(provider,family_id)) STRICT');db.executemany('INSERT OR REPLACE INTO _epl_date_resolutions VALUES (?,?,?)',[(r['provider'],r['family_id'],json.dumps(r)) for r in out])
    (ROOT/'reports/epl_date_resolutions.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),resolutions=out,new_requests=c.requests),indent=2),encoding='utf-8');print('REVIEWED EPL DATE RESOLUTIONS',len(out));db.close()

if __name__=='__main__':main()
