"""Rebuild dependent EU result tables after newly verified person identity links."""
import subprocess,sys
from pathlib import Path
here=Path(__file__).resolve().parent
scripts=['build_eu_person_registry.py','validate_eu_identity.py','install_eu_performance_facts.py','install_temporal_performance.py','prepare_eu_profile_inputs.py','build_eu_dated_profiles.py','refresh_eu_affiliation.py','validate_eu_dated_profiles.py','validate_eu_performance.py','validate_temporal_player_names.py']
for name in scripts:
 print('EU VERIFIED IDENTITY REBUILD',name,flush=True);subprocess.run([sys.executable,'-X','utf8',str(here/name)],check=True)
print('EU VERIFIED IDENTITY REBUILD COMPLETE',flush=True)
