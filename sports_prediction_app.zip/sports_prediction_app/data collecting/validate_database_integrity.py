"""Read-only database integrity check; always preserve the actual returned findings."""
import datetime as dt
import json
import sqlite3
import time
from build_history_catalog import DB
from probe_history import ROOT

db=sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True,timeout=60)
start=time.monotonic()
foreign=db.execute('PRAGMA foreign_key_check').fetchall()
print('Foreign-key violations:',len(foreign),flush=True)
quick=db.execute('PRAGMA quick_check').fetchall()
result=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING' if quick==[('ok',)] and not foreign else 'SCHEMA PROBLEM',quick_check=quick,foreign_key_errors=foreign,elapsed_seconds=round(time.monotonic()-start,3))
(ROOT/'reports/database_integrity.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
db.close()
if result['status']!='WORKING':raise SystemExit(1)
