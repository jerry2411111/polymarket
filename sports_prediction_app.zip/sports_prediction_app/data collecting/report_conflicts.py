"""Report known discrepancy flags separately from missing or ambiguous data."""
import collections,csv,datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
CATEGORIES={
 'Provider score discrepancy':'Polymarket versus Kalshi final score',
 'Resolution disagrees with matched game':'Polymarket versus Kalshi winner',
 'Score and market resolution disagree':'Polymarket score versus its own resolution',
 'Market settlement disagrees with game final score':'Kalshi score versus its own settlement',
 'Start time discrepancy over one hour':'Provider start times differ by more than one hour',
 'Conflicting canonical identity':'Canonical game identifier collision'}
def main():
 db=sqlite3.connect(DB);flags=[];other=collections.Counter()
 for (s,) in db.execute('SELECT body FROM _history_matching_audit'):
  x=json.loads(s)
  if x['reason'] in CATEGORIES:flags.append(dict(category=CATEGORIES[x['reason']],provider=x['provider'],record_id=x['source_id'],unit='market record',source_request_id=None))
  else:other[x['reason']]+=1
 for (s,) in db.execute('SELECT body FROM _history_enrichment_audit'):
  x=json.loads(s)
  if x.get('error')=='Gamebook final differs from provider result':flags.append(dict(category='Official NBA scorer report versus provider score',provider='NBA official / market provider',record_id=x['game_id'],unit='game record',source_request_id=x['request_id']))
  else:other[x.get('error') or x.get('source','Unknown')]+=1
 counts=collections.Counter(x['category'] for x in flags);now=dt.datetime.now(dt.UTC).isoformat()
 result=dict(reported_at_utc=now,flag_count=len(flags),unit='Discrepancy flags, not a deduplicated count of unique games',categories=dict(counts),other_exclusions=dict(other),flags=flags,scope='Initial full metadata matching and the completed subset of official NBA scorer-document validation. Counts may change as validation progresses.')
 (ROOT/'reports/conflict_counts.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 with (ROOT/'reports/conflict_records.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['category','provider','record_id','unit','source_request_id']);w.writeheader();w.writerows(flags)
 lines=['# Recorded conflicts','',f'{len(flags)} discrepancy flags as of {now}. These are not a deduplicated count of games.','', '| Category | Flags |','|---|---:|']+[f'| {key} | {value} |' for key,value in counts.items()]
 lines+=['','Separate from conflicts: 201 game/provider groups have multiple possible moneyline listings; 145 market records have unmapped or ambiguous outcome teams; four scorer reports need a header-parser adjustment.','',result['scope']]
 (ROOT/'reports/conflict_counts.md').write_text('\n'.join(lines),encoding='utf-8');print(json.dumps(dict(flag_count=len(flags),categories=counts,other=other)))
if __name__=='__main__':main()
