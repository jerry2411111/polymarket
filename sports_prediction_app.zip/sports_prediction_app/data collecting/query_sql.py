"""Run one read-only SQL query against the local research database and print JSON rows."""
import argparse,datetime as dt,json,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--database',type=Path,default=ROOT/'data/result/sentinent_snake.sqlite')
    mode=p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--sql');mode.add_argument('--table',choices=['main','in_game','weather','team_history','player_profiles','player_current_team','manager_profiles','player_performance','manager_performance'])
    p.add_argument('--date',help='Selected local calendar date, YYYY-MM-DD')
    p.add_argument('--start-date',help='Performance lower bound; defaults to the collection start')
    p.add_argument('--provider',choices=['kalshi','polymarket'])
    p.add_argument('--params',default='{}',help='JSON object for named SQL parameters, e.g. {"date":"2026-06-09"}')
    args=p.parse_args();bindings=json.loads(args.params)
    if not isinstance(bindings,(dict,list)):p.error('--params must contain a JSON object or list')
    db=sqlite3.connect(args.database.resolve().as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row;db.execute('PRAGMA query_only=ON')
    try:
        sql=args.sql
        if args.table:
            if not args.date:p.error('--date is required with --table')
            for date in [args.date,args.start_date]:
                if date and (len(date)!=10 or dt.date.fromisoformat(date).isoformat()!=date):p.error('Use YYYY-MM-DD')
            start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
            if not start<=args.date<=end:p.error('Requested date is outside the verified collection window '+start+' through '+end)
            if args.start_date and args.start_date<start:p.error('Requested start predates this collection')
            if args.start_date and args.start_date>args.date:p.error('Requested start follows the query date')
            bindings={'query_date':args.date,'collection_start':args.start_date or start}
            if args.table in {'main','in_game','weather'}:
                sql='SELECT * FROM '+args.table+' WHERE date=:query_date'
                if args.provider:
                    if args.table=='weather':p.error('Weather has no odds provider')
                    sql+=' AND provider=:provider';bindings['provider']=args.provider
            elif args.table in {'player_profiles','player_current_team','manager_profiles'}:
                if args.provider:p.error('People profiles do not use an odds provider')
                if args.start_date:p.error('--start-date applies to performance queries; profiles use the stored collection start')
                sql='SELECT * FROM '+args.table+' WHERE as_of_date=:query_date'
            else:
                if args.provider:p.error('--provider applies only to main and in_game')
                from temporal_queries import QUERIES
                sql=QUERIES[args.table]
        result=[dict(r) for r in db.execute(sql,bindings)]
        print(json.dumps(result,indent=2,ensure_ascii=True))
    finally:db.close()

if __name__=='__main__':main()
