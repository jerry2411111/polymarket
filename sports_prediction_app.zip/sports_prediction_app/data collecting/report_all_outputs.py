"""Inventory every public data file and measure missing cells and checkpoint slots."""
import collections
import csv
import datetime as dt
import json
import re
import sqlite3

import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

from build_history_catalog import DB
from probe_history import ROOT

MEANINGS = {
    'match': 'Full Team A name / full Team B name. Join by game_id, not this text.',
    'date': 'Game local calendar date, or the weather city local date; YYYY-MM-DD.',
    'timestamp': 'Main: official game start used for lookbacks, UTC ISO timestamp. In-game: semicolon-separated UTC checkpoint reference times.',
    'game_type': 'Sport: Basketball, Baseball, Hockey or Soccer.',
    'league': 'Games: NBA, MLB, NHL, Premier League, La Liga, Bundesliga, Serie A, Ligue 1 or UEFA Champions League. Soccer performance/profile tables retain the combined EU soccer scope.',
    'competition': 'Actual soccer competition within EU soccer; absent from US provider files.',
    'season': 'Source season label, including the recorded season/game phase where provided; not restricted to regular-season games.',
    'location': 'Verified venue/location in one text field.',
    'home_away': 'Team A designation;Team B designation. Verified neutral games follow the requested Away;Away convention.',
    'final': 'Full winning team name, or draw, using official sports results; never inferred from market settlement.',
    'teamA_final_score': 'Official final Team A points/runs/goals. Soccer follows the matched regulation-time market definition.',
    'teamB_final_score': 'Official final Team B points/runs/goals. Soccer follows the matched regulation-time market definition.',
    'game_id': 'Canonical game key; doubleheaders have separate G1/G2 keys. Native provider and league IDs remain internal.',
    'checkpoint': 'Ordered semicolon-separated checkpoint names. NBA has 4, MLB 4, NHL 3 and soccer 3.',
    'teamA_score': 'Semicolon-separated official cumulative Team A scores at the corresponding checkpoints.',
    'teamB_score': 'Semicolon-separated official cumulative Team B scores at the corresponding checkpoints.',
    'player_id': 'Canonical person identifier, linked internally to original league IDs.',
    'manager_id': 'Canonical head coach/manager identifier.',
    'player_name': 'Full documented player name. Names are not unique identifiers.',
    'manager_name': 'Full documented head coach/manager name.',
    'coach_or_manager_name': 'Full documented head coach/manager name.',
    'team': 'Recorded team as of the selected date. Incomplete employment evidence can leave the last observed team.',
    'current_team': 'Recorded team as of as_of_date; no later affiliation is used.',
    'team_name': 'Full documented team name for that dated history or contract row.',
    'as_of_date': 'Inclusive local calendar cutoff, YYYY-MM-DD. Use the previous date for game t-1 features.',
    'games_played': 'Number of completed collected games in the selected inclusive date interval.',
    'performance_status': 'insufficient matches only when games_played=0; observed matches from the first collected played appearance onward. No first-year exclusion. Individual unavailable or mathematically undefined statistics remain null.',
    'overall_winrate': 'Wins / completed collected appearances or team games through the cutoff; fraction 0-1. A draw is not a win.',
    'winrate': 'Team wins / completed collected team games in the selected period; fraction 0-1.',
    'average_score_per_game': 'Mean player points (NBA), batting runs (MLB), or goals (NHL/soccer) over played collected games. Uses available earlier score observations; zero means no played history, while absent source scores after games remain null.',
    'std_score_per_game': 'Sample standard deviation of the same game scores, denominator n-1. Zero with no played history; otherwise null with fewer than two valid score observations.',
    'average_assists_per_game': 'Mean official scoring assists per played collected game for NBA/NHL/soccer; MLB uses fielding assists. A statistic absent from the source stays null.',
    'std_assists_per_game': 'Sample standard deviation of assists, valid-observation n-1; zero with no played history, otherwise null with fewer than two assist observations.',
    'average_minutes_per_game': 'Mean actual playing minutes per played collected game; MLB individual minutes are unavailable.',
    'std_minutes_per_game': 'Sample standard deviation of playing minutes, n-1. For 80 and 100 minutes this is about 14.1421.',
    'score_z_score': 'Player mean score minus same-league past-only player-cohort mean, divided by population SD of those player means. Null if not defined.',
    'age': 'Completed years on as_of_date calculated from documented birth date.',
    'weight_kg': 'Documented weight in kilograms; one fixed biography measurement is permitted, not a historical measurement series.',
    'height_cm': 'Documented height in centimetres; one fixed biography measurement is permitted.',
    'years_played': 'Count of evidenced completed playing seasons where supported; not elapsed years since birth or first debut. MLB is unavailable.',
    'injured_times_till_as_of_date': '0 when no collected injury report exists under the requested convention; null after a report if distinct lifetime episodes cannot be established. Not a complete medical count.',
    'currently_injured_till_as_of_date': 'Boolean 1/0 based on dated collected injury evidence. No report defaults to 0 by user instruction; this does not establish verified health.',
    'number_of_teams_served': 'Complete career club count only when established; partial observed history is not silently called complete.',
    'participation_rate_current_team': 'Played appearances / collected eligible roster opportunities in the current recorded stint; fraction 0-1, not all league scheduled games.',
    'participation_rate_overall': 'Played appearances / collected eligible roster opportunities through the cutoff; fraction 0-1.',
    'starter_percentage_current_team': 'Starts / played collected appearances in the current recorded stint; fraction 0-1, null when required starter evidence is missing.',
    'starter_percentage_overall': 'Starts / played collected appearances through the cutoff; fraction 0-1, null when required starter evidence is missing.',
    'served_team_history': 'Documented ordered club sequence, comma separated. EU values quote a club containing a comma using CSV escaping. This can be partial career history.',
    'months_serving_current_team': 'Completed calendar months from a documented start of the current stint to as_of_date; null if the start is unverified.',
    'home_times': 'Number of collected team games designated Home in the selected period.',
    'away_times': 'Number designated Away, including verified neutral-site Away;Away under the requested convention.',
    'average_score_margin': 'Average signed score difference: mean(team score minus opponent score) over collected completed games through the selected date. Losing by 2, winning by 3 and 5 gives (-2+3+5)/3 = 2.',
    'city': 'Verified game city/location label used to link city-date weather. Station identity and distance remain internal.',
    'humidity_pct': 'Official station relative humidity percentage, 0-100; nearest eligible previous quality-approved observation.',
    'weather_type': 'Official observed weather description/category; source categories beyond the user examples are retained.',
    'temperature_c': 'Official station air temperature in degrees Celsius.',
    'wind_direction': 'Direction reported by the official station, normalized in the weather acquisition audit; missing remains null.',
    'publisher': 'Original independent ranking publisher, with syndicated copies assigned to their originating publisher.',
    'ranking_date': 'Original list publication date. Source modification/availability date also constrains internal temporal selection.',
    'rank': 'Original ordinal in the stated ranking_type, 1 means first. Null for unlisted players or unavailable eligible lists.',
    'rating': 'A published numeric rating if provided; an ordinal is not converted into a made-up rating.',
    'ranking_type': 'Original scope of the ranking. Positional, all-time and global rankings are not silently relabeled.',
    'age_days': 'Days from the source ranking date to this quarterly snapshot.',
    'is_carried_forward': 'Stored convention: 1 if source age is at least 90 days, 0 if younger, null if no eligible list.',
    'coverage_status': 'Whether a rank was observed, the player is unlisted with unknown eligibility, or no dated list was acquired.',
    'source_url': 'Public originating ranking page; raw response and source-version details remain internal.',
}


def meaning(name):
    found = re.fullmatch(r'(teamA|teamB|draw)_pre_(\d+)_(odd|p)', name)
    if found:
        side, hour, kind = found.groups()
        measure = 'decimal odds 1/p (null if p=0)' if kind == 'odd' else 'market-implied probability on 0-1 scale'
        timing = 'strictly before game start' if hour == '0' else hour + ' hours before game start, using the closest available previous observation'
        return side + ' ' + measure + ', ' + timing + '. Exact source time, bucket/candle availability and age remain in SQL audit.'
    found = re.fullmatch(r'(teamA|teamB|draw)_ingame_(odd|p)', name)
    if found:
        return found[1] + (' decimal odds' if found[2] == 'odd' else ' implied probabilities') + ' as a semicolon sequence aligned with checkpoint. First eligible quote within the official break; missing slots remain explicit.'
    found = re.fullmatch(r'(.+)_top_(5|10|20|50)', name)
    if found:
        return found[1] + ' latest eligible publisher rank <= ' + found[2] + ': 1=true, 0=false for all other players once dated publisher evidence exists; null before any eligible edition. Publishers are not averaged.'
    if name not in MEANINGS:
        raise ValueError('Undocumented public column: ' + name)
    return MEANINGS[name]


def measure_file(path):
    f = pq.ParquetFile(path)
    schema = f.schema_arrow
    counts = collections.Counter()
    empty = collections.Counter()
    nan = collections.Counter()
    slots = collections.defaultdict(lambda: [0, 0])
    row_count = 0
    for batch in f.iter_batches(batch_size=65536):
        row_count += batch.num_rows
        for field, col in zip(schema, batch.columns):
            counts[field.name] += col.null_count
            if pa.types.is_floating(field.type):
                nan[field.name] += pc.sum(pc.is_nan(col)).as_py() or 0
            elif pa.types.is_string(field.type) or pa.types.is_large_string(field.type):
                empty[field.name] += pc.sum(pc.equal(col, '')).as_py() or 0
        if 'checkpoint' in schema.names:
            for row in batch.to_pylist():
                names = row['checkpoint'].split(';')
                assert len(names) in [3, 4]
                for column in ['timestamp', 'teamA_ingame_p', 'teamB_ingame_p', 'draw_ingame_p',
                               'teamA_ingame_odd', 'teamB_ingame_odd', 'draw_ingame_odd', 'teamA_score', 'teamB_score']:
                    if column not in row:
                        continue
                    if column.startswith('draw_') and row['game_type']!='Soccer':
                        continue
                    values = row[column].split(';') if row[column] is not None else ['null'] * len(names)
                    assert len(values) == len(names), (str(path), row['game_id'], column)
                    for checkpoint, value in zip(names, values):
                        key = (row['league'], checkpoint, column)
                        slots[key][1] += 1
                        slots[key][0] += value.strip().lower() in {'', 'none', 'null', 'nan'}
    assert row_count == f.metadata.num_rows
    rel = path.relative_to(ROOT).as_posix()
    columns = []
    for position, field in enumerate(schema):
        missing = counts[field.name] + empty[field.name] + nan[field.name]
        columns.append(dict(position=position, column=field.name, type=str(field.type), rows=row_count,
                            missing=missing, missing_pct=round(100 * missing / row_count, 6) if row_count else None,
                            nulls=counts[field.name], empty_strings=empty[field.name], nan=nan[field.name], meaning=meaning(field.name)))
    return dict(dataset=rel.removesuffix('.parquet'), rows=row_count, column_count=len(schema),
                parquet=rel, csv=path.with_suffix('.csv').relative_to(ROOT).as_posix(),
                parquet_bytes=path.stat().st_size, csv_bytes=path.with_suffix('.csv').stat().st_size,
                columns=columns, checkpoint_missing=[dict(league=k[0], checkpoint=k[1], column=k[2],
                    missing=v[0], slots=v[1], missing_pct=round(100*v[0]/v[1],6)) for k,v in sorted(slots.items())])


def main():
    files = sorted((ROOT / 'data/result').rglob('*.parquet'))
    outputs = []
    milestone = 10
    for n, path in enumerate(files, 1):
        outputs.append(measure_file(path))
        while milestone <= 100 and n * 100 >= milestone * len(files):
            print('ALL OUTPUT MISSING-DATA AUDIT', str(milestone) + '%', n, '/', len(files), flush=True)
            milestone += 10
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    scope = dict(db.execute('SELECT * FROM _collection_scope').fetchone())
    coverage = [dict(r) for r in db.execute('''SELECT m.provider,m.league,count(*) AS main_rows,
         count(i.game_id) AS games_with_in_game_quotes,min(m.date) AS earliest_game,max(m.date) AS latest_game
         FROM main m LEFT JOIN in_game i ON i.provider=m.provider AND i.game_id=m.game_id
         GROUP BY m.provider,m.league ORDER BY m.league,m.provider''')]
    unique = [dict(r) for r in db.execute('SELECT league,count(DISTINCT game_id) AS distinct_games FROM main GROUP BY league')]
    seasons = [dict(r) for r in db.execute('''SELECT provider,league,season,count(*) AS games,
         min(date) AS earliest_game,max(date) AS latest_game FROM main
         GROUP BY provider,league,season ORDER BY league,season,provider''')]
    publishers = [dict(r) for r in db.execute('''SELECT r.league,count(DISTINCT v.publisher) AS publishers,
         count(*) AS facts,count(DISTINCT r.player_id) AS ranked_people
         FROM player_media_rankings r JOIN ranking_list_versions v ON v.list_id=r.list_id GROUP BY r.league''')]
    report = dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(), status='WORKING',
                  collection_status='PARTIALLY WORKING', scope=scope, logical_file_datasets=len(outputs),
                  distinct_games=sum(r['distinct_games'] for r in unique), unique_by_league=unique,
                  provider_coverage=coverage, seasons=seasons, ranking_publishers=publishers, outputs=outputs)
    dest = ROOT / 'reports'
    (dest / 'all_outputs_inventory.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    with (dest / 'all_columns_missing.csv').open('w', newline='', encoding='utf-8') as handle:
        cols = ['dataset', 'position', 'column', 'type', 'rows', 'missing', 'missing_pct', 'nulls', 'empty_strings', 'nan', 'meaning']
        writer = csv.DictWriter(handle, fieldnames=cols)
        writer.writeheader()
        for output in outputs:
            for col in output['columns']:
                writer.writerow(dict(dataset=output['dataset'], **col))
    with (dest / 'in_game_missing_slots.csv').open('w', newline='', encoding='utf-8') as handle:
        cols = ['dataset', 'league', 'checkpoint', 'column', 'missing', 'slots', 'missing_pct']
        writer = csv.DictWriter(handle, fieldnames=cols)
        writer.writeheader()
        for output in outputs:
            for row in output['checkpoint_missing']:
                writer.writerow(dict(dataset=output['dataset'], **row))
    lines = ['# Current files, coverage and missing data', '', 'Generated ' + report['generated_at_utc'] + '.', '',
        str(report['distinct_games']) + ' distinct games have some acquired odds. '
        'The collection window is ' + scope['collection_start'] + ' through ' + scope['collection_end'] +
        '; this is less than three full years, and provider coverage inside it is partial.', '',
        'CSV and Parquet are two formats of the same logical table; they must not be added together as separate observations. '
        'Daily profile rows are dated snapshots, not distinct people or new games.', '',
        '| League | Provider | Main games | Games with any in-game quote | No usable in-game quote | Earliest game | Latest game |',
        '|---|---|---:|---:|---:|---|---|']
    for row in coverage:
        missing = row['main_rows'] - row['games_with_in_game_quotes']
        lines.append('| ' + ' | '.join(map(str, [row['league'], row['provider'], row['main_rows'], row['games_with_in_game_quotes'],
            str(missing) + ' (' + str(round(100*missing/row['main_rows'],2)) + '%)', row['earliest_game'], row['latest_game']])) + ' |')
    lines += ['', 'The main tables are separate for each provider. An in-game file omits a game when no checkpoint probability was acquired. '
        'Missing slots inside retained rows are counted separately in [in_game_missing_slots.csv](in_game_missing_slots.csv). '
        'Removing empty in-game rows does not remove the game from the main table or establish complete checkpoint coverage.', '',
        '## Every result file', '', '| Dataset (both .csv and .parquet) | Rows | Columns |', '|---|---:|---:|']
    for output in outputs:
        lines.append('| [' + output['dataset'].removeprefix('data/result/') + '](../' + output['parquet'] + ') | ' + str(output['rows']) + ' | ' + str(output['column_count']) + ' |')
    lines += ['', 'The SQL database is `data/result/sentinent_snake.sqlite`. Its date-queryable views include main, in_game, '
        'player_profiles, player_current_team, manager_profiles, player_performance, manager_performance, team_history, weather '
        '. Publisher ranking flags carry the latest eligible edition forward inside player_performance. '
        'See [sql_queries.md](sql_queries.md).', '',
        'The main SQL view adds provider. The league column identifies each game competition. Draw values apply only to explicit draw-option markets. '
        'Performance exports retain only publisher flags with dated evidence in that league. Zero performance with games_played=0 means no observations. '
        'They are compatible named-column projections, not positional schemas to concatenate blindly.', '',
        '## Every column: meaning and missing percentage', '',
        'The companion [all_columns_missing.csv](all_columns_missing.csv) contains every dataset/column, its zero-based position, '
        'type, row denominator, missing count and percentage, and meaning. Missing means null, NaN or an empty string; '
        '0 and false remain valid values. Sequence-slot percentages use their own explicit denominator. '
        'Profile percentages are weighted by dated rows, not by unique people.', '']
    for output in outputs:
        lines += ['### ' + output['dataset'].removeprefix('data/result/'), '', '| Position | Column | Type | Missing / rows | Missing % | Meaning |', '|---:|---|---|---:|---:|---|']
        for col in output['columns']:
            lines.append('| ' + ' | '.join(str(v).replace('|', '/') for v in [col['position'], col['column'], col['type'],
                str(col['missing']) + ' / ' + str(col['rows']), col['missing_pct'], col['meaning']]) + ' |')
        lines.append('')
    (dest / 'current_data_inventory.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k not in {'outputs', 'seasons'}}), flush=True)
    db.close()


if __name__ == '__main__':
    main()
