"""Small individual-profile route probes on the already verified official API host."""
import datetime as dt,json,sqlite3
from urllib.parse import quote
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from probe_seriea_api import BASE
db=sqlite3.connect(DB);row=json.loads(db.execute("SELECT body FROM _eu_source_player_game_facts WHERE json_extract(body,'$.competition_code')='SEA' LIMIT 1").fetchone()[0]);pid=row['official_player_id'];c=HistoryClient();HOSTS.add('seriea-api.prd.sdp.deltatre.digital');out=[]
for path in ['/players/'+quote(pid,safe=''),'/players/'+quote(pid,safe='')+'/header','/players/'+quote(pid,safe='')+'/profile']:
 url=BASE+path
 try:
  d,r=c.get(url);out.append(dict(url=url,request_id=r['request_id'],status=r['status'],data=d));print('PROFILE PROBE',r['status'],r['request_id'],list(d) if isinstance(d,dict) else type(d).__name__)
 except Exception as e:out.append(dict(url=url,error=str(e)));print('PROFILE PROBE',str(e))
report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),native_player_id=pid,probes=out,new_requests=c.requests,scope='Individual route discovery only; no inferred biography or career performance');(ROOT/'reports/seriea_person_api_pilot.json').write_text(json.dumps(report,indent=2),encoding='utf-8');db.close()
