"""Independent MLB SQL/output checks against official identities and quote times."""
import argparse,collections,csv,datetime as dt,json,math,sqlite3
import pyarrow.parquet as pq
from build_history_catalog import DB,ORIGINAL
from core import utc
from history_index import records,payload
from probe_history import ROOT
from schema import HOURS

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--league',choices=['MLB','NHL'],default='MLB');league=ap.parse_args().league;prefix=league.lower();checkpoints=['Start','Inning3','Inning5','Inning7'] if league=='MLB' else ['Start','P1','P2']
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;games={r['id']:json.loads(r['body']) for r in db.execute('SELECT * FROM _'+prefix+'_canonical_games')};contracts={(x['provider'],x['contract_id']):x for r in db.execute('SELECT body FROM _'+prefix+'_market_candidates') if (x:=json.loads(r[0]))}
    points=collections.defaultdict(list)
    for b, in db.execute('SELECT body FROM _history_price_points'):
        p=json.loads(b);key=p['provider'],p['contract_id']
        if key not in contracts or (p['kind']=='v2' and p['resolution_seconds']==0):continue
        if contracts[key]['open'] and p['timestamp']<utc(contracts[key]['open']).timestamp():continue
        available=p['timestamp']+(p['resolution_seconds'] if p['kind']=='v2' else 0);points[key].append((available,p['timestamp'],p))
    audit={}
    for b, in db.execute("SELECT body FROM _history_selections WHERE json_extract(body,'$.game_id') LIKE ?",(league+'_%',)):
        a=json.loads(b);audit[a['provider'],a['game_id'],a['side'],a['target']]=a
    checks=collections.Counter();summary={};unique=set();ages=collections.defaultdict(list);examples=[]
    for provider in ['polymarket','kalshi']:
        rows=[dict(r) for r in db.execute('SELECT * FROM '+provider+"_pre_match WHERE league=? ORDER BY date,game_id",(league,))];ing={r['game_id']:dict(r) for r in db.execute('SELECT * FROM '+provider+"_in_game WHERE league=?",(league,))};missing=collections.Counter();seasons=collections.Counter()
        assert len({r['game_id'] for r in rows})==len(rows)==len(ing)
        for row in rows:
            gid=row['game_id'];g=games[gid];unique.add(gid);seasons[g['season']]+=1;start=utc(g['start']).timestamp()
            assert row['match']=='/'.join(g['teams']) and row['final']==g['winner'] and [row['teamA_final_score'],row['teamB_final_score']]==g['scores'];checks['official_identity_and_final_score']+=1
            for side in range(2):
                for h in HOURS:
                    name=f'team{"AB"[side]}_pre_{h}_p';a=audit[provider,gid,side,'pre_'+str(h)];p=row[name];target=start-h*3600
                    contract=contracts[provider,a['contract_id']];assert contract['side']==side and contract['game_id']==gid
                    assert p==a['normalized_price'];choices=[q for q in points[provider,a['contract_id']] if q[0]<=target and q[1]<start]
                    if p is None:missing[name]+=1;assert not choices
                    else:
                        assert math.isfinite(p) and 0<=p<=1
                        assert utc(a['source_timestamp_utc']).timestamp()<start and utc(a['source_available_at_utc']).timestamp()<=target
                        assert max(q[0] for q in choices)==utc(a['source_available_at_utc']).timestamp(),'A later completed quote was available'
                        odd=row[name[:-1]+'odd'];assert odd is None if p==0 else math.isclose(odd,1/p,rel_tol=1e-14);ages[provider,h].append(target-utc(a['source_timestamp_utc']).timestamp())
                    checks['lookback_scale_and_closest_previous']+=1
            rr=ing[gid];assert rr['checkpoint']==';'.join(checkpoints)
            for side in range(2):
                ps=rr[f'team{"AB"[side]}_ingame_p'].split(';');odds=rr[f'team{"AB"[side]}_ingame_odd'].split(';');scores=rr[f'team{"AB"[side]}_score'].split(';');assert len(ps)==len(odds)==len(scores)==len(checkpoints)
                for n,(p,o,s) in enumerate(zip(ps,odds,scores)):
                    a=audit[provider,gid,side,'ingame_'+str(n)];value=None if p=='null' else float(p);assert value==a['normalized_price'];assert (None if s=='null' else int(s))==g['break_scores'][n][side]
                    if value is not None:
                        lo=utc(a['target_timestamp_utc']).timestamp();hi=utc(a['window_end_utc']).timestamp();ts=utc(a['source_timestamp_utc']).timestamp();av=utc(a['source_available_at_utc']).timestamp();assert lo<=ts<hi and av<=hi
                        candidates=[q for q in points[provider,a['contract_id']] if lo<=q[1]<hi and q[0]<=hi];assert min(q[0] for q in candidates)==av
                        assert o=='null' if value==0 else math.isclose(float(o),1/value,rel_tol=1e-14);checks['in_game_time_probability_score_alignment']+=1
        for name in ['pre_match','in_game']:
            p=ROOT/'data/result'/provider/name;pr=pq.read_table(p.with_suffix('.parquet')).to_pylist();sql=[dict(r) for r in db.execute('SELECT * FROM '+provider+'_'+name+' ORDER BY game_id')]
            assert sorted(pr,key=lambda r:r['game_id'])==sql;checks['parquet_matches_sql']+=1
            with p.with_suffix('.csv').open(encoding='utf-8-sig',newline='') as f:cr=list(csv.DictReader(f))
            assert len(cr)==len(sql) and {x['game_id'] for x in cr}=={x['game_id'] for x in sql};checks['csv_row_identity']+=1
        summary[provider]=dict(game_rows=len(rows),earliest=min(r['date'] for r in rows),latest=max(r['date'] for r in rows),seasons=dict(seasons),complete_all_requested_lookbacks_both_teams=sum(all(r[f'team{s}_pre_{h}_p'] is not None for s in ['A','B'] for h in HOURS) for r in rows),missing_probability_fields={k:dict(count=v,total=len(rows),percentage=round(v*100/len(rows),4)) for k,v in missing.items()})
        for r in rows[:3]:examples.append(dict(provider=provider,game_id=r['game_id'],match=r['match'],date=r['date'],official_game_url=('https://www.mlb.com/gameday/' if league=='MLB' else 'https://www.nhl.com/gamecenter/')+games[r['game_id']]['official_game_id'],pre_0=[r['teamA_pre_0_p'],r['teamB_pre_0_p']],final=r['final'],final_score=[r['teamA_final_score'],r['teamB_final_score']]))
    stats=[]
    for (provider,h),vs in ages.items():
        vs.sort();stats.append(dict(provider=provider,lookback_hours=h,nonmissing=len(vs),median_quote_age_minutes=vs[len(vs)//2]/60,p95_quote_age_minutes=vs[int((len(vs)-1)*.95)]/60,maximum_quote_age_minutes=max(vs)/60))
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Current published '+league+' main/in-game snapshot; supporting acquisitions have separate coverage',unique_games=len(unique),checks=dict(checks),providers=summary,quote_ages=stats,examples=examples,limitations=['Requested date window begins January 2024; usable price coverage begins later','A completed request is not complete lookback or in-game coverage','The raw-to-normalized build report separately verifies selected source hashes and values'])
    (ROOT/('reports/'+prefix+'_outputs_validation.json')).write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['quote_ages','examples']}));db.close()

if __name__=='__main__':main()
