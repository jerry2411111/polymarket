"""Raw identity checks and three separate official club reports, including CET/CEST conversion."""
import collections,datetime as dt,json,re,sqlite3
from zoneinfo import ZoneInfo
from bs4 import BeautifulSoup
from build_history_catalog import DB
from epl_price_points import Sources
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

EXAMPLES=[
    (2023,'2024-01-13','OGC Nice',2,0,'21h00','https://www.staderennais.com/actualites/equipe-pro/les-rouge-et-noir-soffrent-les-aiglons','13 janvier 2024'),
    (2024,'2024-08-18','Olympique Lyonnais',3,0,'20h45','https://www.staderennais.com/actualites/ligue-1-mcdonalds/depart-canon','18 août 2024'),
    (2025,'2025-08-15','Olympique de Marseille',1,0,'20h45','https://www.staderennais.com/actualites/ligue-1-uber-eats/le-resume-de-la-victoire-face-a-lom','15 août 2025')]

def main():
    HOSTS.add('www.staderennais.com');client=HistoryClient();db=sqlite3.connect(DB);src=Sources(db);sources=json.loads((ROOT/'reports/ligue1_historical_pilot_sources.json').read_text())['sources'];byseason={};checks=collections.Counter();examples=[]
    for s in sources:
        calendar,r=src.get(s['calendar_request_id']);data,mr=src.get(s['matches_request_id']);ms=data['matches'];w=calendar['gameWeeks'][str(s['week'])];assert len(ms)==9 and {m['matchId'] for m in ms}==set(w['matchesIds']);assert mr['parameters']['season']==r['parameters']['season']==s['season'];byseason[s['season']]=ms
        for m in ms:
            assert m['championshipId']==1 and m['gameWeekNumber']==s['week'] and m['period']=='fullTime' and not m['isLive'] and not m['unknownMatch'];assert m['home']['clubId']!=m['away']['clubId']
            for side in ['home','away']:assert m[side]['clubId']==m[side]['clubIdentity']['id'] and m[side]['clubId'].startswith('l1_championship_club_'+str(s['season'])+'_') and type(m[side]['score']) is int and m[side]['score']>=0
            assert dt.datetime.fromisoformat(m['date']).tzinfo;checks['native_identity_season_final_score']+=1
    for year,day,away,hs,aws,time,url,date_text in EXAMPLES:
        matches=[m for m in byseason[year] if m['date'][:10]==day and m['away']['clubIdentity']['name']==away and m['home']['clubIdentity']['name']=='Stade Rennais FC'];assert len(matches)==1;m=matches[0];assert [m['home']['score'],m['away']['score']]==[hs,aws];b,r=client.get(url,document=True);soup=BeautifulSoup(b,'html.parser');text=' '.join(soup.get_text(' ',strip=True).split());assert 'Stade Rennais F.C. / '+away+' : '+str(hs)+'-'+str(aws) in text;assert date_text in text and time in text and 'Roazhon Park' in text;local=dt.datetime.fromisoformat(day+'T'+time.replace('h',':')).replace(tzinfo=ZoneInfo('Europe/Paris'));assert local.astimezone(dt.UTC)==dt.datetime.fromisoformat(m['date']);checks['independent_official_report_identity_score_date_time']+=1;examples.append(dict(match_id=m['matchId'],home=m['home']['clubIdentity']['name'],away=away,api_home_score=hs,api_away_score=aws,api_start_utc=m['date'],official_local_date_time=local.isoformat(),public_url=url,public_request_id=r['request_id'],matches=True))
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='27 official API games and three independent official club-report comparisons; historical calendar connector only',checks=dict(checks),api_hash_checks=len(src.cache),examples=examples,new_requests=client.requests,limits=['Ligue 1 public match pages returned client-rendered shells; the local browser renderer failed before loading content. Neither is counted as validation.','Official dated club match reports supply the independent public comparisons.','No quote, player, weather or contract coverage is implied.']);(ROOT/'reports/ligue1_pilot_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
