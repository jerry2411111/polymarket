"""Verify real hourly-lookback selections, IDs and source values for three games."""
import collections,datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB,ORIGINAL
from build_nhl_odds import load_points
from history_index import records
from core import utc,odd
from quote_selection import available_at,nearest_pregame
from schema import HOURS
from probe_history import ROOT
db=sqlite3.connect(DB,timeout=60);games={i:json.loads(b) for i,b in db.execute('SELECT * FROM _nhl_canonical_games')};feeds={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_nhl_game_reports')};contracts=[json.loads(b) for b, in db.execute('SELECT body FROM _nhl_market_candidates')]
chosen=[]
for day in ['2024-06-08','2024-12-15','2025-02-03']:
 xs=sorted([g for g in games.values() if g['date']==day and g['official_game_id'] in feeds],key=lambda g:g['game_id']);assert xs;chosen.append(xs[0])
selected={g['game_id'] for g in chosen};cs={(c['provider'],c['contract_id']):c for c in contracts if c['game_id'] in selected};points,parsed,conflicts,reused=load_points(db,cs);grouped=collections.defaultdict(list);terminal=0
for x in points:
 if x['kind']=='v2' and x['resolution_seconds']==0:terminal+=1;continue
 opened=utc(cs[x['provider'],x['contract_id']]['open'])
 if opened and x['timestamp']<opened.timestamp():continue
 grouped[x['provider'],x['contract_id']].append(x)
sources={r['request_id']:(r,root) for root in [ORIGINAL,ROOT] for r in records(root)};cache={};examples=[];rawchecks=0
def raw(rid):
 if rid not in cache:
  r,root=sources[rid];b=(root/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];cache[rid]=json.loads(b)
 return cache[rid]
for g in chosen:
 f=feeds[g['official_game_id']];assert f['actual_start_utc'];start=utc(f['actual_start_utc']).timestamp();members=[c for c in cs.values() if c['game_id']==g['game_id'] and c['provider']=='polymarket'];families=collections.defaultdict(list)
 for c in members:families[c['market_id']].append(c)
 pairs=[v for v in families.values() if sorted(c['side'] for c in v)==[0,1]];assert pairs;members=min(pairs,key=lambda v:(max(c['open'] for c in v),v[0]['market_id']));rows=[]
 for c in members:
  market=raw(c['request_id'])
  for k in c['pointer'].strip('/').split('/'):market=market[int(k)] if isinstance(market,list) else market[k]
  tokens=json.loads(market['clobTokenIds']) if isinstance(market['clobTokenIds'],str) else market['clobTokenIds'];labels=json.loads(market['outcomes']) if isinstance(market['outcomes'],str) else market['outcomes'];assert labels[tokens.index(c['contract_id'])]==c['outcome']
  for hour in HOURS:
   target=start-hour*3600;xs=grouped[c['provider'],c['contract_id']];x=nearest_pregame(xs,target,start)
   row=dict(team=g['teams'][c['side']],lookback_hours=hour,target_timestamp_utc=utc(target).isoformat(),market_id=c['market_id'],token_id=c['contract_id'],raw_outcome_label=c['outcome'],probability=None,decimal_odds=None)
   if x:
    d=raw(x['request_id'])
    for k in x['pointer'].strip('/').split('/'):d=d[int(k)] if isinstance(d,list) else d[k]
    assert float(d)==x['price'] and x['timestamp']<start and available_at(x)<=target
    assert not any(y['timestamp']<start and available_at(x)<available_at(y)<=target for y in xs)
    row.update(probability=x['price'],decimal_odds=odd(x['price']),source_timestamp_utc=utc(x['timestamp']).isoformat(),bucket_completed_at_utc=utc(available_at(x)).isoformat(),resolution_seconds=x['resolution_seconds'],completed_observation_age_hours=(target-available_at(x))/3600,request_id=x['request_id'],raw_pointer=x['pointer'],matches=True);rawchecks+=1
   rows.append(row)
  
 examples.append(dict(game_id=g['game_id'],official_game_id=g['official_game_id'],date=g['date'],teams=g['teams'],official_scores=g['scores'],official_winner=g['winner'],official_public_report='https://www.nhl.com/scores/htmlreports/'+g['official_game_id'][:4]+str(int(g['official_game_id'][:4])+1)+'/GS'+g['official_game_id'][4:]+'.HTM',actual_opening_minute=f['actual_start_utc'],observations=rows))
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING' if rawchecks else 'PARTIALLY WORKING',tested_games=len(examples),verified_nonmissing_values=rawchecks,possible_values=len(examples)*2*len(HOURS),source_hash_checks=len(cache),ambiguous_zero_width_points_excluded=terminal,source_price_conflicts=conflicts,examples=examples,meaning='Latest completed previous Polymarket observation for the configured lookback hours; raw bucket start is not mistaken for its completion time. No interpolation or use of terminal resolution-only points.')
(ROOT/'reports/nhl_price_pilot_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');lines=['# NHL historical price pilot','',out['meaning'],'']
for e in examples:
 lines+=['## '+e['date']+' '+ ' / '.join(e['teams']),'','Official score: '+':'.join(map(str,e['official_scores']))+'. Winner: '+e['official_winner']+'.','', '[Official game report]('+e['official_public_report']+')','','| Team | Hours before start | Probability | Decimal odds | Source UTC | Bucket complete UTC | Age (hours) |','|---|---:|---:|---:|---|---|---:|']
 for r in e['observations']:lines.append('| '+' | '.join(str(r.get(k)) for k in ['team','lookback_hours','probability','decimal_odds','source_timestamp_utc','bucket_completed_at_utc','completed_observation_age_hours'])+' |')
 lines+=['']
(ROOT/'reports/nhl_price_pilot_validation.md').write_text('\n'.join(lines),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['examples','source_price_conflicts']}));db.close()
