import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT
c=HistoryClient();doc,dr=c.get('https://docs.polymarket.com/api-reference/markets/get-resolution-state.md',document=True);assert b'/v2/resolutions' in doc
m,mr=c.get('https://gamma-api.polymarket.com/markets/559108');d,r=c.get('https://data-api.polymarket.com/v2/resolutions',dict(condition=m['conditionId']))
result=dict(checked_at_utc=dt.datetime.now(dt.UTC).isoformat(),market_id=m['id'],condition_id=m['conditionId'],outcomes=json.loads(m['outcomes']),gamma_prices=json.loads(m['outcomePrices']),resolution_response=d,request_id=r['request_id'],documentation_request_id=dr['request_id'],documentation_url=dr['endpoint']);(ROOT/'reports/mlb_polymarket_resolution_state.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
