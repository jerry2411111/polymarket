"""Exact raw native-ID, name and career identity checks before profile reuse."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources
from collect_laliga_people import namekey
from probe_history import ROOT
db=sqlite3.connect(DB);src=Sources(db);counts=collections.Counter();issues=[]
for pid,b in db.execute('SELECT * FROM _official_eu_opta_people_sources'):
 p=json.loads(b);counts['requested']+=1
 if not p.get('biography_identity_verified'):counts['unavailable_biography']+=1;continue
 source=p['sources']['biography'];raw,meta=src.get(source['request_id']);assert raw==source['raw'] and meta['endpoint'].endswith('/v1/players/'+pid);assert all(str(v['id']['playerId'])==pid for v in raw);assert {namekey(v['name']['display']) for v in raw}&{namekey(n) for n in p['names']};counts['raw_native_ID_and_official_name']+=1
 births={v.get('dates',{}).get('birth') for v in raw}-{None}
 if p['birth_dates']:assert births&set(p['birth_dates']);counts['independent_Ligue_1_DOB_match']+=1
 for native in p['source_person_ids']:
  example=json.loads(db.execute('SELECT body FROM _eu_source_player_game_facts WHERE player_id=? LIMIT 1',(native,)).fetchone()[0])
  if example['competition_code']=='LAL':assert example['official_player_id']=='p'+pid
  else:assert str(example['external_ids']['shortOptaId'])==pid
  counts['source_native_identity_correspondence']+=1
 if p['status']=='ok':
  s=p['sources']['career'];raw,meta=src.get(s['request_id']);assert raw==s['raw'] and len(raw['person'])==1 and str(raw['person'][0]['opId'])==pid;counts['raw_career_native_identity']+=1
 else:counts['unavailable_career']+=1
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',counts=dict(counts),source_hashes=len(src.cache),scope='Only source identity validated; dated membership and biography normalization remain separate from performance');(ROOT/'reports/eu_opta_people_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
