"""The user's compact replacement schemas, without diagnostic export columns."""
HOURS=[0,12,24,36,48]
PRE_COLUMNS=['match','date','timestamp','game_type','league','season']+[
    f'team{team}_pre_{n}_{kind}' for n in HOURS for team in ['A','B'] for kind in ['odd','p']
]+['location','home_away','final','teamA_final_score','teamB_final_score','game_id']
INGAME_COLUMNS=['match','game_type','league','season','timestamp','checkpoint',
                'teamA_ingame_odd','teamB_ingame_odd','teamA_ingame_p','teamB_ingame_p',
                'teamA_score','teamB_score','game_id']
PLAYER_COLUMNS=['player_name','game_type','league','team','overall_winrate','average_score_per_game',
                'average_assists_per_game','std_score_per_game','std_assists_per_game','age','weight_kg','height_cm',
                'years_played','score_z_score','injured_times_till_2026_9_13','currently_injured_till_2026_9_13',
                'number_of_teams_served','participation_rate_current_team','participation_rate_overall',
                'starter_percentage_current_team','starter_percentage_overall']
PLAYER_COLUMNS+=['average_minutes_per_game','std_minutes_per_game','served_team_history','months_serving_current_team','as_of_date']
PLAYER_ASOF_COLUMNS=[c.replace('injured_times_till_2026_9_13','injured_times_till_as_of_date').replace('currently_injured_till_2026_9_13','currently_injured_till_as_of_date') for c in PLAYER_COLUMNS]
MANAGER_COLUMNS=['manager_name','game_type','league','team','number_of_teams_served','served_team_history','months_serving_current_team','overall_winrate','as_of_date']
PLAYER_TEAM_COLUMNS=['player_name','game_type','league','current_team']
WEATHER_COLUMNS=['city','date','humidity_pct','weather_type','temperature_c','wind_direction']

CHECKPOINTS={'Basketball':['Start','Q1','Halftime','Q4'],
             'Baseball':['Start','Inning3','Inning5','Inning7'],
             'Hockey':['Start','P1','P2']}

def aligned(values):
    return ';'.join('null' if v is None else str(v) for v in values)
