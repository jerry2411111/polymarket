# Use the reference model

Use `../runtime/market_reference.py` with prepared historical features for model comparisons. Keep it separate from the app predictor: the active MLB model uses baseball inputs without market-price features.
