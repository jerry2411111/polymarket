# Prepare dated model history

NBA uses `nba_games.parquet`, `nba_players.parquet`, `nba_team_stats.parquet`
and `nba_all_features.parquet`. MLB uses `mlb_games.parquet`,
`mlb_players.parquet`, `mlb_team_stats.parquet`, `mlb_contact_games.parquet`
and its model feature table. Keep official game and team IDs consistent between
these tables and the fixtures. Update availability times with each observation;
past forecasts may use only earlier known data. Keep historical model caches
and prediction records aligned with the same feature definitions.
