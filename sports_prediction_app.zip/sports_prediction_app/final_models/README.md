# Prepare and use the prediction models

NBA uses the rolling logistic model with interactions. MLB uses the daily
baseball-only logistic/CatBoost ensemble. `deployment.json` defines their active
identifiers and MLB purchase rules. See the NBA and MLB READMEs for model-specific
instructions and the main README for bet sizing.

Prepare dated inputs in `history/`, then the selected model's feature tables.
NBA reads `history/nba_all_features.parquet` and uses `nba/template.pkl`; run
`nba/create_template.py` to initialize the unfitted estimator recipe when needed.
Its historical fitted cache is `history/nba_models.sqlite`. MLB fitting reads
`mlb/features.parquet`, uses the `announcement` mode and caches daily fits in
`mlb/deployed_models.sqlite`. Earlier prediction records are used for the displayed
reliability estimate. Raw input order is defined in each model's `columns.json`.

Use `runtime/build_features.py` and `runtime/mlb_features.py` to construct inputs
from prepared histories, and `runtime/daily_model.py` for MLB fitting. Preserve
source availability timestamps: labels used in training/calibration must be known
before the forecast. Preparing these inputs is a prerequisite to app predictions.

Run `sports_app/verify_final_models.py` from the project root after preparing
historical artifacts. It checks feature replay, unseen fixture IDs, calibrated
probabilities and the MLB entry rule. Keep the market-aware model as a reference;
the app's MLB forecast uses no market-price input.
