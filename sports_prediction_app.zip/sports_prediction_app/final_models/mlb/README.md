# Use the MLB model

Prepare the 53 features named in `columns.json`, then use
`../runtime/daily_model.py` to fit the daily logistic/CatBoost ensemble.
The two calibrated classifiers are averaged equally. Market prices are not
predictive features. The last 300 eligible earlier games form the calibration
sample; fitting and preprocessing use earlier known observations.

The live forecast waits for both official starting pitchers and nine batters on
each team during the fixed 12-hour game window. The model uses team history,
pitcher and batter performance, recent form, contact quality and bullpen form.

Buy the predicted winner only at or below `probability - 0.05`, with a normal
stake of 1% of account equity and total open purchase cost capped at 20%.
Buy once per game and hold to the result. Use the app's maximum-price and
minimum-odds display, refresh stale quotes, and record purchases manually.
The app's rule does not automatically buy the other team.
