# Compare allocation rules

With historical predictions, paired quote records and official result times
prepared, run `../probability_split_test.py` to compare the selected winner rule
with cash splits between both teams. The comparison preserves the model and
separately tracks available cash, unsettled positions, match counts and returns.
Read win rate and account return separately: an accurate predicted winner can
still be unprofitable at the prices paid. The active app rule remains the MLB
winner purchase rule described in the main README.
