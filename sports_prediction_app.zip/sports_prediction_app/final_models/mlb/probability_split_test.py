"""Fixed MLB probability-split comparison; uses the final model, no refitting/search."""
from pathlib import Path
from collections import defaultdict
import hashlib,html,json,math,sqlite3
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'mlb/probability_split_test'
OUT.mkdir(exist_ok=True)

def inputs():
    p=pd.read_parquet(ROOT/'mlb/predictions.parquet')
    q=pd.read_parquet(ROOT/'reference_market/features.parquet')
    # Reuse only source quote metadata, never the reference model probabilities.
    cols=['game_id','teamA','teamB','allocation_cycle_utc','cycle_utc','cycle_end_utc']
    cols += [k+str(i) for i in [0,1] for k in ['price','source_utc','available_utc','age_hours','request_id','pointer','contract_id','eligible']]
    f=p.merge(q[cols],on='game_id',how='inner',validate='one_to_one')
    f['entry']=pd.to_datetime(f.prediction_timestamp_utc,utc=True,format='mixed')
    f['exit']=pd.to_datetime(f.label_available_at_utc,utc=True,format='mixed')
    f['start']=pd.to_datetime(f.timestamp,utc=True,format='mixed')
    f['cycle']=pd.to_datetime(f.allocation_cycle_utc,utc=True,format='mixed')
    assert f.eligible0.all() and f.eligible1.all()
    assert (f['cycle']<=f.entry).all() and (f.entry<f.start).all() and (f.start<=f['cycle']+pd.Timedelta(hours=12)).all()
    assert (f.start<f.exit).all() and np.allclose(f.p0+f.p1,1)
    for i in [0,1]:
        assert f['price'+str(i)].between(0,1,inclusive='neither').all()
        assert (pd.to_datetime(f['available_utc'+str(i)],utc=True,format='mixed')<=f.entry).all()
        assert f['age_hours'+str(i)].le(24).all()
    f['pick']=np.where(f.p0>=f.p1,0,1)
    f['pick_p']=np.where(f.pick.eq(0),f.p0,f.p1)
    f['pick_price']=np.where(f.pick.eq(0),f.price0,f.price1)
    f['selected']=f.pick_p-f.pick_price>=.05
    g=pd.read_parquet(ROOT/'history/mlb_games.parquet')
    g=g[g.history_group.eq('senior')&g.target.notna()&g.label_available_at_utc.notna()].copy()
    g['start']=pd.to_datetime(g.timestamp,utc=True,format='mixed')
    g['cycle']=g.start.dt.floor('12h');g.loc[g.cycle.eq(g.start),'cycle']-=pd.Timedelta(hours=12)
    assert not g.game_id.duplicated().any()
    assert set(f.game_id).issubset(set(g.game_id))
    assert (f.cycle.to_numpy()==f.game_id.map(g.set_index('game_id').cycle).to_numpy()).all()
    missing=p[~p.game_id.isin(f.game_id)][['game_id','date','prediction_timestamp_utc']].copy()
    missing['reason']='Paired historical quote row not retained in the reference quote input; excluded, no invented price'
    missing.to_csv(OUT/'missing_quote_rows.csv',index=False)
    f.drop(columns=['entry','exit','start','cycle']).to_parquet(OUT/'candidates.parquet',index=False)
    return f,g,missing

def simulate(frame,schedule,year,strategy):
    start=pd.Timestamp(f'{year}-01-01',tz='UTC')
    end=pd.Timestamp('2026-09-29' if year==2026 else f'{year}-12-31',tz='UTC')
    end_exclusive=end+pd.Timedelta(days=1)
    f=frame[frame.entry.ge(start)&frame.entry.lt(end_exclusive)].copy()
    full_cycle=strategy=='both_all_cycle_cash'
    both=strategy!='winner_selected_one_percent'
    if strategy in ['winner_selected_one_percent','both_selected_one_percent']:f=f[f.selected]
    # Cycle budgets use all collected completed senior fixtures in the window,
    # including games that will lack prices/lineups. Future eligibility is never
    # used to increase other games' allocations; an unused reservation stays cash.
    sched=schedule[schedule.cycle.ge(start)&schedule.cycle.lt(end_exclusive)]
    counts=sched.groupby('cycle').size().to_dict()
    events=defaultdict(lambda:dict(entries=[],exits=[],cycle=False))
    for t in pd.date_range(start,end_exclusive,freq='12h',inclusive='left'):events[t]['cycle']=True
    for r in f.to_dict('records'):
        events[r['entry']]['entries'].append(r);events[r['exit']]['exits'].append(r['game_id'])
    cash=10000.;opened={};budgets={};positions=[];ledger=[];peak=cash;drawdown=0.;unfunded=0;max_open=0.
    for at,e in sorted(events.items()):
        payout=0.
        for gid in e['exits']:
            if gid not in opened:continue
            row=opened.pop(gid);cash+=row['payout'];payout+=row['payout'];positions.append(row)
        committed=math.fsum(r['stake'] for r in opened.values());equity=cash+committed
        if full_cycle and e['cycle']:budgets[at]=cash/counts[at] if counts.get(at) else 0.
        entries=sorted(e['entries'],key=lambda x:x['game_id'])
        proposals=[budgets.get(r['cycle'],0.) if full_cycle else .01*equity for r in entries]
        room=cash if full_cycle else max(0.,min(cash,.2*equity-committed))
        total=math.fsum(proposals);scale=min(1.,room/total) if total>0 else 0.;spent=0.
        if full_cycle:assert scale>=1-1e-10 or total<1e-8,'Reserved budgets should not borrow cash'
        for r,proposal in zip(entries,proposals):
            stake=proposal*scale
            if stake<=1e-12:unfunded+=1;continue
            assert r['game_id'] not in opened
            fraction0=float(r['p0']) if both else float(r['pick']==0)
            fraction1=float(r['p1']) if both else float(r['pick']==1)
            stake0=stake*fraction0;stake1=stake*fraction1
            received=stake0/r['price0'] if r['target']==0 else stake1/r['price1']
            row={k:v for k,v in r.items() if k not in ['entry','exit','start','cycle']}
            row.update(stake=stake,stakeA=stake0,stakeB=stake1,entry_utc=at.isoformat(),exit_utc=r['exit'].isoformat(),payout=received,
                       profit=received-stake,return_per_match=received/stake-1,entry_equity=equity,allocation_fraction=stake/equity,
                       model_pick_correct=int(r['pick']==r['target']),both_sides=both)
            opened[r['game_id']]=row;spent+=stake
        cash-=spent;committed=math.fsum(r['stake'] for r in opened.values())
        assert cash>=-1e-7 and np.isclose(equity,cash+committed)
        if not full_cycle and spent:assert committed<=.2*equity+1e-7
        max_open=max(max_open,committed/equity if equity else 0.)
        peak=max(peak,equity);drawdown=max(drawdown,1-equity/peak)
        ledger.append(dict(timestamp_utc=at.isoformat(),cash=cash,open_cost=committed,equity=equity,new_stake=spent,settlement_payout=payout))
    assert not opened
    positions=pd.DataFrame(positions);ledger=pd.DataFrame(ledger)
    assert np.isclose(cash,10000+math.fsum(positions.profit))
    ledger['day']=pd.to_datetime(ledger.timestamp_utc,utc=True,format='mixed').dt.floor('D')
    daily=ledger.groupby('day').equity.last().reindex(pd.date_range(start,end,freq='D')).ffill().fillna(10000.)
    previous=daily.shift(1);previous.iloc[0]=10000.;returns=daily/previous-1
    assert np.isclose(daily.iloc[-1],cash),'Settlement beyond report end must be disclosed, not pulled backward'
    assert np.isclose(10000*np.prod(1+returns),cash)
    daily=pd.DataFrame(dict(day=daily.index.astype(str),equity=daily.values,daily_return=returns.values))
    metrics=dict(strategy=strategy,year=year,games=len(positions),positions=len(positions)*(2 if both else 1),unfunded_games=unfunded,
                 model_pick_win_pct=100*positions.model_pick_correct.mean(),profitable_matches_pct=100*positions.profit.gt(1e-8).mean(),
                 account_return_pct=100*(cash/10000-1),daily_sharpe=math.sqrt(365.25)*returns.mean()/returns.std(ddof=1),
                 maximum_drawdown_pct=100*drawdown,average_match_return_pct=100*positions.return_per_match.mean(),
                 maximum_open_cost_pct=100*max_open,calendar_days=len(daily),final_balance=cash)
    return metrics,positions,ledger.drop(columns='day'),daily

def replay(positions,ledger):
    events=defaultdict(lambda:[0.,0.])
    for r in positions.itertuples():
        assert np.isclose(r.stakeA+r.stakeB,r.stake)
        payout=r.stakeA/r.price0 if r.target==0 else r.stakeB/r.price1
        assert np.isclose(payout,r.payout)
        assert pd.Timestamp(r.available_utc0)<=pd.Timestamp(r.entry_utc)<pd.Timestamp(r.timestamp)
        assert pd.Timestamp(r.available_utc1)<=pd.Timestamp(r.entry_utc)
        events[r.entry_utc][0]+=r.stake;events[r.exit_utc][1]+=r.payout
    cash=10000.
    for row in ledger.itertuples():
        spent,payout=events[row.timestamp_utc];cash+=payout-spent
        assert np.isclose(cash,row.cash)

def main():
    f,g,missing=inputs();summary=[];tables=defaultdict(list)
    strategies=['winner_selected_one_percent','both_selected_one_percent','both_all_one_percent','both_all_cycle_cash']
    for year in [2025,2026]:
        for strategy in strategies:
            m,p,l,d=simulate(f,g,year,strategy);replay(p,l);summary.append(m)
            for name,frame in [('positions',p),('equity_ledger',l),('daily_equity',d)]:tables[name].append(frame.assign(strategy=strategy,year=year))
            print('SPLIT_TEST',json.dumps(m),flush=True)
    summary=pd.DataFrame(summary)
    with sqlite3.connect(ROOT/'mlb/backtest.sqlite') as c:baseline=pd.read_sql_query('select * from summary',c)
    for r in baseline.itertuples():
        v=summary[summary.year.eq(r.year)&summary.strategy.eq('winner_selected_one_percent')].iloc[0]
        assert v.games==r.funded_games
        for a,b in [('account_return_pct','portfolio_return_pct'),('daily_sharpe','daily_sharpe'),('maximum_drawdown_pct','max_drawdown_pct')]:assert np.isclose(v[a],getattr(r,b),rtol=0,atol=1e-8),(r.year,a,v[a],getattr(r,b))
    with sqlite3.connect(OUT/'comparison.sqlite') as c:
        summary.to_sql('summary',c,if_exists='replace',index=False)
        for name,frames in tables.items():pd.concat(frames,ignore_index=True).to_sql(name,c,if_exists='replace',index=False)
    summary.to_csv(OUT/'summary.csv',index=False)
    report=dict(status='PASS',baseline_reproduced=True,no_model_refit=True,market_aware_predictions_used=False,
                quote_availability_checked=True,future_eligibility_not_used_for_cycle_budget=True,ledger_replays=8,
                input_forecasts=len(f)+len(missing),paired_quote_games=len(f),missing_quote_rows=len(missing),
                limitations=['Historical reference prices, not verified executable asks','Open positions valued at purchase cost','Cash released at official result availability, not exchange redemption','Cycle allocation uses the collected completed-fixture schedule; historical schedule revisions and canceled games cannot be fully reconstructed','No fees/spread/slippage; 2026 has already been examined'])
    (OUT/'validation.json').write_text(json.dumps(report,indent=2))
    table=summary[['year','strategy','games','model_pick_win_pct','profitable_matches_pct','account_return_pct','daily_sharpe','maximum_drawdown_pct','average_match_return_pct']].to_html(index=False,float_format=lambda x:f'{x:.4f}')
    page='''<!doctype html><meta charset="utf-8"><title>MLB probability split test</title><style>body{font:15px/1.6 system-ui;margin:35px;color:#182a3a}table{border-collapse:collapse}td,th{border:1px solid #ccd;padding:8px;text-align:right}th{background:#eef}p{max-width:1050px}</style><h1>MLB probability split test</h1><p>Final daily baseball model, with no market inputs, unchanged. The current app strategy remains unchanged. No parameter search or refitting.</p><p><b>winner_selected_one_percent:</b> current rule: predicted winner with at least five percentage points above its price; 1% equity per match, 20% total open-cost limit. <b>both_selected_one_percent:</b> identical games and same match stake, split between teams by model probability. <b>both_all_one_percent:</b> every usable game, 1% match stake split by probability; 20% open-cost limit. <b>both_all_cycle_cash:</b> at 00:00/12:00 UTC, divide available cash equally across all collected senior fixtures in the next window; reserve each game's budget until its lineup/quote decision, and split it by model probability. Missing-data reservations stay cash. No 1/8 cap or 20% cap for this final variant. Cash already committed to unresolved games is unavailable.</p><p>Each two-sided match's net return is model probability assigned to the actual winner divided by its purchase price, minus one. "Profitable matches" measures positive combined profit; winning one of the two individual legs is not itself a profitable match. Model-pick win rate remains the accuracy of the higher-probability team.</p>'''+table+'<p>2025 covers the calendar year; 2026 ends September 29. Calendar Sharpe uses actual daily returns and sqrt(365.25) annualization. Account returns are not annualized.</p><p>'+html.escape('; '.join(report['limitations']))+'</p><p>17 saved forecasts lack a retained paired-price row and are excluded; see missing_quote_rows.csv. All current baseline trades are covered. Quotes were already available by each entry time; no future price or future eligibility is used to increase cycle budgets.</p>'
    (OUT/'REPORT.html').write_text(page,encoding='utf-8')
    print('SPLIT_TEST_VALIDATED',flush=True)

if __name__=='__main__':main()
