"""Recreate the final unfitted NBA estimator recipe; no training data is bundled."""
from pathlib import Path
import pickle, sys
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'runtime'))
from complete_model import ObservedScale, StableInteractions
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression

def build_template():
    return Pipeline([
    ('observed_scale', ObservedScale(clip=5.0, min_observations=30)),
    ('interactions', StableInteractions(clip=5.0, pairs=((0, 3),
 (0, 5),
 (1, 3),
 (1, 5),
 (2, 4),
 (2, 5),
 (11, 14),
 (6, 7),
 (9, 10),
 (12, 2)))),
    ('logistic', LogisticRegression(C=0.1, class_weight=None, dual=False, fit_intercept=True, intercept_scaling=1, l1_ratio=0.0, max_iter=10000, n_jobs=None, penalty='deprecated', random_state=None, solver='lbfgs', tol=1e-06, verbose=0, warm_start=False)),
    ])

if __name__ == '__main__':
    dest = ROOT / 'template.pkl'
    if dest.exists():
        raise SystemExit('template.pkl already exists; it was not overwritten.')
    dest.write_bytes(pickle.dumps(build_template(), protocol=5))
    print('Created unfitted NBA template only. Historical input data is still required.')
