# Use the NBA model

Run `create_template.py` to create the configured estimator if `template.pkl`
does not already exist. It preserves 27 input columns, ten interactions and
logistic regression settings. Prepare historical features before fitting.
The forecast uses the established pre-12-hour cutoff and earlier training data.

In the app, choose a match budget and split its cash between the two teams using
the displayed probabilities. A 40%/60% prediction allocates $40/$60 of a $100
match budget. Divide each amount by its purchase price to obtain the share count.
The displayed percentages refer to that match budget, not the entire account.
Record the total spent using the game's purchase checkbox and amount field.
