"""Direct lagged-value-weighted returns of the observed invested macro book."""
from __future__ import annotations

import bisect
from array import array
import collections
import dataclasses
import json
import math
import os
import sqlite3
import statistics
import zlib

import rolling_copy_backtest as b
from macro_universe_data import ROOT, OUT, BACKUP_START, TEST_START, TEST_END,load_markets

Z95=1.6448536269514722


class MarketMarks:
    def __init__(self):
        compact=OUT/'macro_markets_for_returns.json'
        self.markets=json.loads(compact.read_text(encoding='utf-8')) if compact.exists() else load_markets()
        self.by_condition={m['conditionId']:m for m in self.markets}
        self.condition_tokens={c:json.loads(m.get('clobTokenIds') or '[]') for c,m in self.by_condition.items()}
        self.token_condition={t:c for c,ts in self.condition_tokens.items() for t in ts}
        self.event_slugs={event.get('slug') for m in self.markets for event in m.get('events',[]) if event.get('slug')}
        self.values=collections.OrderedDict()
        self.extended=set()
        self.early={}
        self.resolved={}
        db=sqlite3.connect(f'file:{(OUT/"market_prices.sqlite").as_posix()}?mode=ro',uri=True)
        self.price_db=db
        for condition,body in db.execute('SELECT condition,body FROM resolutions'):
            r=json.loads(body)
            if r and r.get('status')=='resolved':
                time_value=r.get('resolved_at') or r.get('last_update_timestamp')
                if not time_value:continue
                at=int(time_value) if str(time_value).isdigit() else b.stamp(time_value)
                payouts=r.get('payouts')
                if payouts is not None:
                    payouts=[float(x)/1_000_000 for x in payouts]
                elif r.get('price') is not None:
                    yes=float(r['price'])
                    if yes>1:yes/=1e18
                    if not 0<=yes<=1:continue
                    payouts=[yes,1-yes]
                else:continue
                if at<=TEST_END:
                    for token,payout in zip(self.condition_tokens.get(condition,[]),payouts):
                        self.resolved[token]=(at,payout)

    def price_series(self,token):
        if token in self.values:
            self.values.move_to_end(token)
            return self.values[token]
        hit=self.price_db.execute('SELECT body FROM prices WHERE token=?',(token,)).fetchone()
        pairs=json.loads(zlib.decompress(hit[0])) if hit else []
        if token in self.early:
            merged=dict(self.early[token]);merged.update(pairs);pairs=sorted(merged.items())
        pairs=[(t,p) for t,p in pairs if math.isfinite(p) and 0<=p<=1]
        self.values[token]=(array('q',(p[0] for p in pairs)),array('d',(p[1] for p in pairs)))
        return self.values[token]

    def mark(self,token,at,last_trade=None):
        resolved=self.resolved.get(token)
        if resolved and resolved[0]<=at:
            return resolved[1]
        times,values=self.price_series(token)
        i=bisect.bisect_right(times,at)-1
        if (last_trade and math.isfinite(last_trade[1]) and 0<=last_trade[1]<=1
                and last_trade[0]<=at and (i<0 or last_trade[0]>times[i])):
            return last_trade[1]
        if i>=0:return values[i]
        condition=self.token_condition.get(token)
        if condition and condition not in self.extended:
            self.extend_early_quotes(condition)
            return self.mark(token,at,last_trade)
        raise b.DataError(f'Historical mark unavailable for {token} at {b.iso(at)}')

    def extend_early_quotes(self,condition):
        """Use already-collected actual market trades before API price coverage."""
        self.extended.add(condition)
        directory=OUT/'early_market_quotes'
        directory.mkdir(exist_ok=True)
        path=directory/(condition+'.json.zlib')
        if path.exists():early=json.loads(zlib.decompress(path.read_bytes()))
        else:
            tokens=self.condition_tokens[condition]
            cutoff=max((self.price_series(t)[0][0] if self.price_series(t)[0] else TEST_END) for t in tokens)
            # Only the last actual quote on a calendar day is needed at daily
            # boundaries. Preserve its real timestamp; never backfill it earlier.
            latest={}
            for file in (ROOT/'rolling_discovery.sqlite',OUT/'older_macro_trades.sqlite',OUT/'expanded_market_trades.sqlite'):
                if not file.exists():continue
                db=sqlite3.connect(f'file:{file.as_posix()}?mode=ro',uri=True)
                for token,ts,price in db.execute('SELECT token,ts,price FROM trades WHERE condition=? AND ts<?',(condition,cutoff)):
                    key=(token,ts//b.DAY)
                    old=latest.get(key)
                    if old is None or ts>old[0]:latest[key]=(ts,price)
                db.close()
            early={t:sorted([p for (token,day),p in latest.items() if token==t]) for t in tokens}
            temporary=path.with_suffix(f'.{os.getpid()}.tmp')
            temporary.write_bytes(zlib.compress(json.dumps(early).encode()))
            try:temporary.replace(path)
            except PermissionError:
                # Another worker may have published the same deterministic
                # quotes while Windows still holds that file open for reading.
                if not path.exists():raise
                early=json.loads(zlib.decompress(path.read_bytes()))
                temporary.unlink(missing_ok=True)
        for token,pairs in early.items():
            self.early[token]=pairs
            times,prices=self.price_series(token)
            combined=dict(pairs)
            combined.update(zip(times,prices))
            points=sorted((t,p) for t,p in combined.items() if math.isfinite(p) and 0<=p<=1)
            self.values[token]=(array('q',(x[0] for x in points)),array('d',(x[1] for x in points)))


def events_from_rows(rows,actions,marks,transfer_movements=None):
    transfers_by_tx=collections.defaultdict(dict)
    if transfer_movements is not None:
        for at,tx,token,qty in transfer_movements:transfers_by_tx[tx][token]=qty
    def observed_deltas(tx,wallet,tokens):
        if transfer_movements is not None:
            return {t:q for t,q in transfers_by_tx.get(tx,{}).items() if t in tokens}
        from polymarket_receipts import token_deltas
        return token_deltas(tx,wallet,tokens)
    events=[b.Event(ts,w,t,c,'TRADE',side,size,price,cash,title,tx,False,outcome,oi)
            for w,ts,t,side,tx,c,size,price,cash,title,outcome,oi in rows]
    # Resolve redemption outcome identifiers from catalog metadata, independent
    # of whether the account happened to have a prior BUY in the discovery feed.
    receipts_done=set()
    conversion_receipts={}
    for raw in actions:
        e=b.Event.parse(raw)
        if e.kind=='CONVERSION' and (e.condition in marks.by_condition or raw.get('event_slug') in marks.event_slugs):
            key=(e.tx,'CONVERSION')
            if key in receipts_done:continue
            receipts_done.add(key)
            conversion_receipts[e.tx]=(e,observed_deltas(e.tx,e.wallet,marks.token_condition))
            continue
        if e.condition not in marks.by_condition:
            continue
        if e.kind in ('SPLIT','MERGE','REDEEM','CONVERSION'):
            tokens=marks.condition_tokens[e.condition]
            if e.kind=='REDEEM' and not e.token:
                oi=e.outcome_index
                if oi not in range(len(tokens)) and e.outcome:
                    labels=json.loads(marks.by_condition[e.condition].get('outcomes') or '[]')
                    oi=next((i for i,label in enumerate(labels) if label.lower()==e.outcome.lower()),-1)
                if oi in range(len(tokens)):
                    e=dataclasses.replace(e,token=tokens[oi])
                else:
                    key=(e.tx,e.condition)
                    if key in receipts_done:continue
                    receipts_done.add(key)
                    deltas=observed_deltas(e.tx,e.wallet,set(tokens))
                    if not deltas:raise b.DataError('No redemption burns in receipt: '+e.tx)
                    for token,delta in deltas.items():
                        if delta<0:events.append(dataclasses.replace(e,token=token,size=-delta))
                    continue
            if e.kind=='REDEEM' and e.token and e.size>0:
                payout=marks.resolved.get(e.token)
                if payout and 0<payout[1]<1 and abs(e.cash-e.size)<1e-6:
                    e=dataclasses.replace(e,size=e.cash/payout[1])
            events.append(e)
    # A conversion receipt covers the entire transaction. Other activity rows
    # (such as a MERGE in that same transaction) already account for some of
    # its token movements; add only the residual, never the net movement twice.
    by_transaction=collections.defaultdict(list)
    for event in events:by_transaction[event.tx].append(event)
    for tx,(reference,actual) in conversion_receipts.items():
        represented=collections.defaultdict(float)
        for e in by_transaction.get(tx,[]):
            if e.kind=='TRADE':represented[e.token]+=e.size if e.side=='BUY' else -e.size
            elif e.kind=='REDEEM':represented[e.token]-=e.size
            elif e.kind in ('SPLIT','MERGE'):
                for token in marks.condition_tokens[e.condition]:
                    represented[token]+=e.size if e.kind=='SPLIT' else -e.size
        for token in set(actual)|set(represented):
            delta=actual.get(token,0)-represented.get(token,0)
            if abs(delta)>1e-8:
                events.append(dataclasses.replace(reference,kind='INVENTORY_DELTA',token=token,size=abs(delta),
                    side='BUY' if delta>0 else 'SELL',condition=marks.token_condition[token]))
    return sorted(events,key=lambda e:(e.ts,0 if e.kind=='SPLIT' else 1,
        0 if e.kind=='TRADE' and e.side=='BUY' else 1,e.tx,e.token))


def confidence(values):
    n=len(values)
    if n<2 or any(v is None or not math.isfinite(v) for v in values):return None
    mean=statistics.fmean(values)
    sd=statistics.stdev(values)
    if sd<=1e-15:return None
    centered=[r-mean for r in values]
    m2=statistics.fmean(v*v for v in centered)
    skew=statistics.fmean(v**3 for v in centered)/m2**1.5
    kurt=statistics.fmean(v**4 for v in centered)/m2**2
    s=mean/sd
    factor=1-skew*s+(kurt-1)*s*s/4
    if factor < -1e-10:return None
    se=math.sqrt(365*max(0,factor)/(n-1))
    return dict(raw_sharpe=math.sqrt(365)*s,effective_sharpe=math.sqrt(365)*s-Z95*se,
                sharpe_standard_error=se,return_skewness=skew,return_pearson_kurtosis=kurt,
                historical_observations=n,volatility=sd)


class MacroAccount:
    def __init__(self,source,economics,marks,reconcile_transfers=False,end_override=None):
        self.wallet=source['wallet']
        self.name=economics.get('name') or self.wallet
        # The longest requested reset interval is 75 days. Nothing after the
        # last activity-eligible reset plus that interval can affect a screen
        # or a followed interval for this account. This is a work bound, not
        # an eligibility condition and not a history-length restriction.
        self.end=min(TEST_END,max(source.get('dates') or [TEST_END])+75*b.DAY)
        # Descriptive account-history views may request the entire recorded
        # interval. Screening and strategy callers retain the original bound.
        if end_override is not None:
            self.end=min(TEST_END,int(end_override))
        rows=[r for r in source['rows'] if r[1]<self.end]
        actions=[r for r in economics['actions'] if int(r['timestamp'])<self.end]
        movements=None
        if reconcile_transfers:
            from polymarket_transfer_history import history
            movements=history(self.wallet,marks.token_condition)
        self.events=events_from_rows(rows,actions,marks,movements)
        if reconcile_transfers:
            from polymarket_transfer_history import reconcile_events
            self.events=reconcile_events(self.events,self.wallet,marks,movements)
        self.times=[e.ts for e in self.events]
        self.marks=marks
        self.values={}
        self.daily={}
        self.closed=[]
        self.inventory_issues=[]
        self.unpriced_days=set()
        self.unpriced_tokens={}
        self._build()

    def _build(self):
        held=collections.defaultdict(float)
        lots=collections.defaultdict(collections.deque)
        last_marks={}
        pointer=0
        previous_book={}
        previous_value=0.0

        def change(token,qty,e):
            if qty>0:
                held[token]+=qty
                lots[token].append([e.ts,qty])
            else:
                remove=-qty
                held[token]-=remove
                while remove>1e-8 and lots[token]:
                    start,amount=lots[token][0]
                    q=min(remove,amount)
                    self.closed.append((e.ts,(e.ts-start)/b.DAY,q))
                    lots[token][0][1]-=q
                    remove-=q
                    if lots[token][0][1]<1e-8:lots[token].popleft()
                if abs(held[token])<1e-7:held.pop(token,None)

        def value(book,at):
            contributions={}
            priced={}
            unknown=[]
            for token,q in book.items():
                if q<=1e-8:continue
                try:price=self.marks.mark(token,at,last_marks.get(token))
                except b.DataError:
                    unknown.append(token)
                    continue
                if not math.isfinite(price) or not 0<=price<=1:
                    raise b.DataError(f'Invalid observed price {price} for {token} at {at}')
                contributions[token]=q*price
                if price>0:priced[token]=q
            return math.fsum(contributions.values()),priced,unknown

        for at in range(BACKUP_START,self.end+1,b.DAY):
            while pointer<len(self.events) and self.events[pointer].ts<at:
                e=self.events[pointer]
                if e.kind=='TRADE':last_marks[e.token]=(e.ts,e.price)
                if e.kind=='TRADE':
                    change(e.token,e.size if e.side=='BUY' else -e.size,e)
                elif e.kind=='REDEEM':
                    change(e.token,-e.size,e)
                elif e.kind in ('SPLIT','MERGE'):
                    sign=1 if e.kind=='SPLIT' else -1
                    for token in self.marks.condition_tokens[e.condition]:change(token,sign*e.size,e)
                elif e.kind=='CONVERSION':
                    raise b.DataError('Macro conversion needs token-delta reconciliation: '+e.tx)
                elif e.kind=='INVENTORY_DELTA':
                    change(e.token,e.size if e.side=='BUY' else -e.size,e)
                pointer+=1
            for token,q in held.items():
                if q < -1e-5:
                    self.inventory_issues.append(dict(timestamp=at-1,token=token,observed_holding=q))
            # Hold yesterday's quantities fixed for this return calculation.
            # Today's observed position changes only set tomorrow's weights.
            marked_previous,_,missing_previous=value(previous_book,at-1)
            if missing_previous:
                raise b.DataError('Previously observed historical marks disappeared')
            gross,priced_book,unknown=value(held,at-1)
            if unknown:self.unpriced_tokens[at]=sorted(unknown)
            self.values[at]=gross
            if at>BACKUP_START:
                self.daily[at]=(marked_previous/previous_value-1
                    if previous_value>1e-8 else None)
            # Only positions actually priced at this boundary enter next day's
            # weights. A first quote must never appear as a profit on an
            # unpriced position; neither absolute-size changes nor future
            # resolution outcomes are backfilled into prior returns.
            previous_book=priced_book
            previous_value=gross

    def metrics(self,at):
        first_macro=min(e.ts for e in self.events if e.kind=='TRADE')//b.DAY*b.DAY
        # A macro book can start with an observed SPLIT or token conversion before
        # its first BUY/SELL. Include those available position returns too; the
        # trade-frequency denominator still starts with the first observed trade.
        first_book=min(e.ts for e in self.events)//b.DAY*b.DAY
        left=max(at-365*b.DAY,BACKUP_START,first_book)
        returns=[self.daily[t] for t in range(left+b.DAY,at+1,b.DAY) if self.daily.get(t) is not None]
        moments=confidence(returns)
        if moments is None:return None,'daily_returns_unavailable_or_zero_variance'
        if any(x['timestamp']<at for x in self.inventory_issues):
            return None,'opening_inventory_needs_reconciliation'
        recent=[e for e in self.events if e.kind=='TRADE' and at-365*b.DAY<=e.ts<at]
        active=len({e.ts//b.DAY for e in recent if e.ts>=at-40*b.DAY})
        observed=max(1,(at-max(at-365*b.DAY,first_macro))/b.DAY)
        average=len(recent)/observed
        closed=[(d,q) for t,d,q in self.closed if at-365*b.DAY<=t<at]
        qty=math.fsum(q for d,q in closed)
        fast=math.fsum(q for d,q in closed if d<1/24)/qty if qty>0 else 0.0
        sides=collections.defaultdict(set)
        outcomes=collections.defaultdict(set)
        for e in recent:
            sides[e.token,e.ts//3600].add(e.side)
            outcomes[e.condition,e.ts//3600].add(e.token)
        two=sum(len(v)>1 for v in sides.values())/len(sides) if sides else 0.0
        both=sum(len(v)>1 for v in outcomes.values())/len(outcomes) if outcomes else 0.0
        reasons=[]
        if active<30:reasons.append('fewer_than_30_active_days_in_40')
        if average>=50:reasons.append('average_50_or_more_trades_per_day')
        if fast>.10:reasons.append('closed_shares_under_one_hour_above_10_percent')
        if two>.20:reasons.append('two_sided_token_hours_above_20_percent')
        if both>.20:reasons.append('both_outcome_market_hours_above_20_percent')
        exposure=[self.values[t] for t in range(left,at,b.DAY) if self.values[t] is not None]
        result=dict(moments,history_start_utc=b.iso(left),history_end_utc=b.iso(at),
            active_days_last_40=active,average_trades_per_day=average,
            fast_close_fraction=fast,two_sided_fraction=two,both_outcomes_fraction=both,
            average_macro_position_value=statistics.fmean(exposure),
            qualifies_style_and_activity=not reasons,
            rejection_reasons=reasons,volatility_windows={})
        # Exactly the existing shift(1): omit the return ending at the reset.
        lagged=[self.daily[t] for t in range(left+b.DAY,at,b.DAY) if self.daily.get(t) is not None]
        result['volatility_available_history']=statistics.stdev(lagged) if len(lagged)>=2 else None
        for n in (15,30,45,60,75):
            window=[self.daily[t] for t in range(max(left+b.DAY,at-n*b.DAY),at,b.DAY)
                    if self.daily.get(t) is not None]
            result['volatility_windows'][str(n)]=statistics.stdev(window) if len(window)>=2 else None
        return result,None
