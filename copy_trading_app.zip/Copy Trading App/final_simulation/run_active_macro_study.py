"""Run all requested combinations on prior-weighted active macro-book returns.

No ranking, total-account cash reconstruction, or simulated account Sharpe.
Run screen_macro_performance.py first. Outputs include every selected wallet,
account name, allocation, historical screen metric, and strategy daily NAV.
"""
from __future__ import annotations

import argparse
import collections
import csv
import gzip
import json
import math
import pickle
import sqlite3
import statistics
import time
import zlib

import rolling_copy_backtest as b
from macro_universe_data import OUT,TEST_START,TEST_END,dump


def cases():
    result=[]
    raw_filters=[('range',a,c) for a,c in [(1.5,2),(2,3),(3,4),(4,5)]]+[
        ('cutoff',a,None) for a in (1.5,2,3,4,5)]
    effective_filters=[('range',a,c) for a,c in [(1.5,2),(2,3),(3,4),(4,5),(5,6)]]+[
        ('cutoff',a,None) for a in (1.5,2,3,4,5,6)]
    def add(report,metric,kind,lower,upper,reset,vol):
        key=f'{report}_{metric}_{kind}_{lower:g}'
        if upper is not None:key+=f'_{upper:g}'
        key+=f'_reset{reset}_vol{vol}'
        result.append(dict(case_id=key,report=report,screen_metric=metric,filter_kind=kind,
            lower=lower,upper=upper,reset_days=reset,volatility_days=vol))
    for vol in (15,30,45,60,75):
        for reset in (5,10,15,20,30):
            for kind,lower,upper in raw_filters:add('allocation','raw',kind,lower,upper,reset,vol)
    for metric in ('raw','effective'):
        for lower in (1.5,2,3,4,5,6):add('daily',metric,'cutoff',lower,None,1,365)
    for reset in (15,30,45,60,75):
        for kind,lower,upper in effective_filters:add('effective','effective',kind,lower,upper,reset,365)
    assert len(result)==292
    return result


def strategy_statistics(equity):
    returns=[equity[i][1]/equity[i-1][1]-1 if equity[i-1][1]>0 else 0
             for i in range(1,len(equity))]
    sd=statistics.stdev(returns)
    sharpe=math.sqrt(365)*statistics.fmean(returns)/sd if sd>1e-15 else None
    peak=equity[0][1]
    worst=0.0
    for _,value in equity:
        peak=max(peak,value)
        if peak:worst=min(worst,value/peak-1)
    return dict(strategy_sharpe=sharpe,total_return=equity[-1][1]/equity[0][1]-1,
        starting_equity=equity[0][1],ending_equity=equity[-1][1],max_drawdown=worst,
        daily_observations=len(returns))


def simulate(case,by_date,models,directory):
    holdings={}
    cash=10000.0
    equity=[(TEST_START,cash)]
    resets=list(range(TEST_START,TEST_END,case['reset_days']*b.DAY))
    next_reset={at:(resets[i+1] if i+1<len(resets) else TEST_END) for i,at in enumerate(resets)}
    unique=set()
    days_selected=days_invested=0
    observations=[]
    selection_path=directory/(case['case_id']+'_accounts.csv.gz')
    curve_path=directory/(case['case_id']+'_daily.csv')
    period_path=directory/(case['case_id']+'_periods.csv')
    period_start=period_equity=None
    period_count=0
    period_rows=[]
    with gzip.open(selection_path,'wt',newline='',encoding='utf-8') as f:
        writer=csv.writer(f)
        writer.writerow(['period_start_utc','period_end_exclusive_utc','wallet','account_name',
            'portfolio_weight','allocated_capital_at_reset','raw_sharpe','effective_sharpe',
            'history_observations','active_days_last_40','mean_trades_per_calendar_day',
            'return_volatility_for_weight','history_start_utc','history_end_utc'])
        for at in range(TEST_START,TEST_END,b.DAY):
            if at in next_reset:
                nav=cash+math.fsum(holdings.values())
                if period_start is not None:
                    period_rows.append([b.iso(period_start),b.iso(at),period_count,period_equity,nav,
                        nav/period_equity-1 if period_equity else None])
                period_start,period_equity=at,nav
                selected=[]
                for wallet,metric in by_date.get(at,[]):
                    s=metric[case['screen_metric']+'_sharpe']
                    if s<=case['lower'] or (case['upper'] is not None and s>case['upper']):continue
                    sigma=(metric['volatility_available_history'] if case['volatility_days']==365 else
                        metric['volatility_windows'].get(str(case['volatility_days'])))
                    if sigma is None or not math.isfinite(sigma) or sigma<=0:continue
                    selected.append((wallet,metric,sigma))
                scale=math.fsum(1/sigma for _,_,sigma in selected)
                holdings={}
                cash=0.0 if selected else nav
                period_count=len(selected)
                for wallet,metric,sigma in selected:
                    weight=(1/sigma)/scale
                    holdings[wallet]=nav*weight
                    unique.add(wallet)
                    observations.append(metric['historical_observations'])
                    writer.writerow([b.iso(at),b.iso(next_reset[at]),wallet,models[wallet]['name'],
                        weight,nav*weight,metric['raw_sharpe'],metric['effective_sharpe'],
                        metric['historical_observations'],metric['active_days_last_40'],
                        metric['average_trades_per_day'],sigma,metric['history_start_utc'],metric['history_end_utc']])
                if selected and abs(math.fsum(holdings.values())-nav)>max(1e-6,abs(nav)*1e-10):
                    raise b.DataError('Allocation does not sum to available strategy NAV')
            if holdings:days_selected+=1
            invested=False
            for wallet,capital in list(holdings.items()):
                model=models[wallet]
                ending=at+b.DAY
                if ending in model.get('unpriced_days',[]):
                    raise b.DataError(f'{case["case_id"]}: no observed mark for the source macro book of {wallet} at {b.iso(ending)}')
                if model.get('unreconciled_from') is not None and ending>=model['unreconciled_from']:
                    raise b.DataError(f'{case["case_id"]}: unresolved source shares for {wallet} at {b.iso(ending)}')
                r=model['daily'][ending]
                if r is None:continue  # No positively valued, historically priced book: this slice is cash.
                if not math.isfinite(r) or r<-1-1e-8:
                    raise b.DataError(f'Invalid macro-book return {r} for {wallet} at {b.iso(ending)}')
                holdings[wallet]=capital*(1+max(-1,r))
                invested=True
            if invested:days_invested+=1
            equity.append((at+b.DAY,cash+math.fsum(holdings.values())))
    nav=equity[-1][1]
    period_rows.append([b.iso(period_start),b.iso(TEST_END),period_count,period_equity,nav,
        nav/period_equity-1 if period_equity else None])
    with curve_path.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['timestamp_utc','equity','daily_return'])
        for i,(at,value) in enumerate(equity):
            r=(value/equity[i-1][1]-1 if equity[i-1][1] else 0) if i else None
            w.writerow([b.iso(at),value,r])
    with period_path.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['period_start_utc','period_end_exclusive_utc','selected_accounts',
            'starting_equity','ending_equity','period_return']);w.writerows(period_rows)
    return dict(case,**strategy_statistics(equity),unique_accounts=len(unique),
        days_with_selected_accounts=days_selected,days_with_invested_accounts=days_invested,
        history_observations_min=min(observations) if observations else None,
        history_observations_median=statistics.median(observations) if observations else None,
        history_observations_max=max(observations) if observations else None,
        accounts_dataset=selection_path.name,daily_dataset=curve_path.name,period_dataset=period_path.name)


def run(allow_incomplete=False):
    db=sqlite3.connect(f'file:{(OUT/"active_book_screened_accounts.sqlite").as_posix()}?mode=ro',uri=True)
    count=db.execute('SELECT count(*) FROM processed').fetchone()[0]
    expected=json.loads((OUT/'activity_screen_summary.json').read_text())[
        'accounts_passing_activity_and_frequency_at_any_reset']
    if count!=expected and not allow_incomplete:raise b.DataError(f'Account calculations unfinished: {count}/{expected}')
    issues=db.execute("SELECT count(*) FROM processed WHERE status='DATA_ISSUE'").fetchone()[0]
    if issues and not allow_incomplete:raise b.DataError(f'{issues} account calculations still need resolution')
    models={w:pickle.loads(zlib.decompress(blob)) for w,blob in db.execute('SELECT wallet,body FROM models')}
    if any(m.get('return_basis')!='observed_historical_prices_only' for m in models.values()):
        raise b.DataError('Source models must all use the approved actual-historical-price basis')
    by_date=collections.defaultdict(list)
    for at,w,body in db.execute('SELECT at,wallet,body FROM metrics WHERE eligible=1 AND raw_sharpe>1.5 ORDER BY at,wallet'):
        if w in models:by_date[at].append((w,json.loads(body)))
    b.log(f'Loaded {len(models):,} account return histories; running 292 combinations')
    directory=OUT/'simulations'
    directory.mkdir(exist_ok=True)
    result=[]
    for i,case in enumerate(cases(),1):
        result.append(simulate(case,by_date,models,directory))
        if i%10==0 or i==292:
            dump('simulation_progress.json',dict(status='RUNNING' if i<292 else 'COMPLETE',completed_cases=i,total_cases=292))
            b.log(f'Simulation {i}/292')
    dump('strategy_results.json',dict(status='COMPLETE' if not allow_incomplete else 'PREVIEW',
        simulation_start=b.iso(TEST_START),simulation_end_exclusive=b.iso(TEST_END),
        source_accounts_processed=count,source_accounts_with_unresolved_records=issues,
        return_basis='Prior closing observed-price macro/geopolitical position-value weights times following-day position returns; unquoted positions omitted until priced.',
        cases=result))
    with (OUT/'strategy_results.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(result[0]));writer.writeheader();writer.writerows(result)
    (directory/'STATUS.json').write_text(json.dumps(dict(
        status='PREVIEW' if allow_incomplete else 'COMPLETE',completed_cases=len(result),
        return_basis='observed_historical_prices_only'),indent=2),encoding='utf-8')
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--allow-incomplete-preview',action='store_true')
    args=p.parse_args()
    run(args.allow_incomplete_preview)
