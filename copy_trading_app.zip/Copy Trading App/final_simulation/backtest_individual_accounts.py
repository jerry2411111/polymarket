"""Attribute completed macro-book backtests to each followed account.

Reuses saved point-in-time selections, allocations and observed-price returns.
Writes account/period CSVs and an offline, searchable HTML explorer. No discovery,
screening or trading rules are changed. Run with --scope daily or --scope all.
"""
from __future__ import annotations

import argparse
import collections
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import pickle
import sqlite3
import statistics
import time
import zlib

import rolling_copy_backtest as b
from macro_universe_data import ROOT, OUT, TEST_START, TEST_END

DAYS=(TEST_END-TEST_START)//b.DAY
ACCOUNT_FIELDS=['wallet','account_name','selected_periods','selected_days','invested_days',
    'first_selected_day','last_selected_end_day','standalone_return','standalone_sharpe',
    'standalone_max_drawdown','portfolio_pnl','portfolio_return_contribution_pp',
    'average_weight_at_reset','maximum_weight_at_reset','winning_periods','losing_periods','flat_periods']
PERIOD_FIELDS=['start_day','end_day','portfolio_weight','allocated_capital','ending_capital',
    'portfolio_pnl','period_return','historical_raw_sharpe','historical_effective_sharpe',
    'historical_volatility','historical_observations','invested_days','period_realized_sharpe']
SUMMARY_CSV_FIELDS=['case_id','report','screen_metric','filter_kind','lower','upper','reset_days',
    'volatility_days','wallet','account_name','selected_periods','selected_days','invested_days',
    'first_selected_utc','last_selected_end_exclusive_utc','standalone_total_return',
    'standalone_sharpe_full_test','standalone_max_drawdown','portfolio_pnl_dollars',
    'portfolio_return_contribution_percentage_points','average_weight_at_reset','maximum_weight_at_reset',
    'winning_periods','losing_periods','flat_periods']
PERIOD_CSV_FIELDS=['case_id','wallet','account_name','period_start_utc','period_end_exclusive_utc',
    'portfolio_weight','allocated_capital','ending_capital','portfolio_pnl_dollars','period_return',
    'historical_raw_sharpe','historical_effective_sharpe','historical_volatility',
    'historical_observations','invested_days','period_realized_sharpe']


def write_json(path,payload):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(payload,ensure_ascii=False,allow_nan=False,indent=2),encoding='utf-8')
    temporary.replace(path)


def write_script(path,callback,payload):
    # Account display names are data, never executable source or HTML.
    encoded=json.dumps(payload,ensure_ascii=True,allow_nan=False,separators=(',',':'))
    path.write_text(f'window.{callback}({encoded});\n',encoding='utf-8')


def realized_sharpe(values):
    if len(values)<2:return None
    sd=statistics.stdev(values)
    return math.sqrt(365)*statistics.fmean(values)/sd if sd>1e-15 else None


def account_summary(wallet,name,periods,daily,initial_portfolio):
    """Single-account strategy invests only on its saved selected dates.

    Cash days, including gaps before/after selection, enter its Sharpe as zeros.
    A fully lost standalone NAV stays zero even if the account is selected again.
    Actual portfolio allocations can differ and are separately attributed.
    """
    nav=peak=1.0
    drawdown=0.0
    returns=[]
    selected_days=invested_days=0
    previous_end=-1
    for p in periods:
        start,end=p[:2]
        if not 0<=start<end<=DAYS or start<previous_end:
            raise ValueError(f'Overlapping or invalid selection periods for {wallet}')
        previous_end=end
        selected_days+=end-start
        invested_days+=p[11]
        for day in range(start,end):
            r=daily[day]
            if r is None:r=0.0
            if not math.isfinite(r) or r<-1-1e-8:raise ValueError('Invalid source return')
            r=max(-1,r) if nav>0 else 0.0
            returns.append(r)
            nav*=1+r
            peak=max(peak,nav)
            drawdown=min(drawdown,nav/peak-1)
    total=math.fsum(returns)
    mean=total/DAYS
    variance=(math.fsum((r-mean)**2 for r in returns)+(DAYS-len(returns))*mean*mean)/(DAYS-1)
    sd=math.sqrt(variance)
    sharpe=math.sqrt(365)*(total/DAYS)/sd if sd>1e-15 else None
    pnl=math.fsum(p[5] for p in periods)
    weights=[p[2] for p in periods]
    return [wallet,name,len(periods),selected_days,invested_days,periods[0][0],periods[-1][1],
        nav-1,sharpe,drawdown,pnl,pnl/initial_portfolio*100,
        math.fsum(weights)/len(weights),max(weights),
        sum(p[6]>1e-12 for p in periods),sum(p[6]<-1e-12 for p in periods),
        sum(abs(p[6])<=1e-12 for p in periods)]


def run_case(case,models,daily_returns,directory,all_summary_writer):
    case_id=case['case_id']
    periods=collections.defaultdict(list)
    daily_pnl=[0.0]*DAYS
    sim=OUT/'simulations'
    with (sim/case['daily_dataset']).open(newline='',encoding='utf-8') as f:
        original=list(csv.DictReader(f))
    equity=[float(r['equity']) for r in original]
    if len(equity)!=DAYS+1:raise ValueError('Incomplete saved strategy curve')
    dates=[b.iso(TEST_START+i*b.DAY) for i in range(DAYS+1)]
    if [r['timestamp_utc'] for r in original]!=dates:raise ValueError('Saved curve dates differ')
    path=directory/'csv'/(case_id+'_periods.csv')
    with gzip.open(sim/case['accounts_dataset'],'rt',newline='',encoding='utf-8') as f, \
            path.open('w',newline='',encoding='utf-8') as out:
        writer=csv.writer(out);writer.writerow(PERIOD_CSV_FIELDS)
        for row in csv.DictReader(f):
            wallet=row['wallet'];model=models[wallet];series=daily_returns[wallet]
            start=(b.stamp(row['period_start_utc'])-TEST_START)//b.DAY
            end=(b.stamp(row['period_end_exclusive_utc'])-TEST_START)//b.DAY
            if not 0<=start<end<=DAYS:raise ValueError('Saved selection outside test')
            allocated=float(row['allocated_capital_at_reset']);capital=allocated
            factor=1.0;invested=0;realized_returns=[]
            weight=float(row['portfolio_weight'])
            if not math.isclose(allocated,equity[start]*weight,rel_tol=1e-10,abs_tol=1e-7):
                raise ValueError('Saved allocation does not match original strategy NAV')
            for day in range(start,end):
                at=TEST_START+(day+1)*b.DAY
                if at not in model['daily']:raise ValueError(f'Missing followed return for {wallet}')
                if at in model.get('unpriced_days',[]):raise ValueError('Unresolved source valuation')
                if model.get('unreconciled_from') is not None and at>=model['unreconciled_from']:
                    raise ValueError('Unreconciled source inventory')
                r=series[day]
                realized_returns.append(max(-1,r or 0) if factor>0 else 0.)
                if r is None:continue
                if not math.isfinite(r) or r<-1-1e-8:raise ValueError('Invalid source return')
                r=max(-1,r);following=capital*(1+r)
                daily_pnl[day]+=following-capital
                capital=following;factor*=1+r;invested+=1
            p=[start,end,weight,allocated,capital,capital-allocated,factor-1,
                float(row['raw_sharpe']),float(row['effective_sharpe']),
                float(row['return_volatility_for_weight']),int(row['history_observations']),invested,
                realized_sharpe(realized_returns)]
            periods[wallet].append(p)
            writer.writerow([case_id,wallet,model['name'],dates[start],dates[end],*p[2:]])
    accounts=[]
    maximum_daily_error=0.0
    for day,pnl in enumerate(daily_pnl):
        expected=equity[day+1]-equity[day]
        maximum_daily_error=max(maximum_daily_error,abs(pnl-expected))
        if not math.isclose(pnl,expected,rel_tol=1e-9,abs_tol=1e-6):
            raise ValueError(f'Account attribution fails on {case_id}, day {day}: {pnl} vs {expected}')
    metadata=[case[k] for k in SUMMARY_CSV_FIELDS[:8]]
    with (directory/'csv'/(case_id+'_accounts.csv')).open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(SUMMARY_CSV_FIELDS)
        for wallet,ps in sorted(periods.items()):
            record=account_summary(wallet,models[wallet]['name'],ps,daily_returns[wallet],equity[0])
            accounts.append(record)
            csv_row=metadata+record[:5]+[dates[record[5]],dates[record[6]]]+record[7:]
            writer.writerow(csv_row);all_summary_writer.writerow(csv_row)
    total_pnl=math.fsum(row[10] for row in accounts)
    expected_pnl=equity[-1]-equity[0]
    if len(accounts)!=case['unique_accounts'] or not math.isclose(total_pnl,expected_pnl,rel_tol=1e-9,abs_tol=1e-6):
        raise ValueError(f'Total account attribution does not reconcile: {case_id}')
    payload=dict(case=case,account_fields=ACCOUNT_FIELDS,period_fields=PERIOD_FIELDS,
        accounts=accounts,periods=dict(periods),portfolio_equity=equity,
        validation=dict(daily_pnl_max_error=maximum_daily_error,account_pnl_sum=total_pnl,
                        original_portfolio_pnl=expected_pnl))
    write_script(directory/'data'/'cases'/(case_id+'.js'),'registerAccountCase',payload)
    return dict(case_id=case_id,accounts=len(accounts),selected_periods=sum(map(len,periods.values())),
        daily_pnl_max_error=maximum_daily_error,account_pnl_sum=total_pnl,original_portfolio_pnl=expected_pnl)


def main(scope='all',case_id=None):
    source=OUT/'strategy_results.json'
    result=json.loads(source.read_text())
    if result['status']!='COMPLETE':raise ValueError('Completed original backtests required')
    selected=[c for c in result['cases'] if (scope=='all' or c['report']=='daily') and
              (case_id is None or c['case_id']==case_id)]
    if not selected:raise ValueError('No matching completed backtest')
    directory=OUT/('account_backtests' if scope=='all' and case_id is None else
        'account_backtests_'+('single' if case_id else scope))
    for sub in ('data/cases','data/accounts','csv'):(directory/sub).mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(f'file:{(OUT/"active_book_screened_accounts.sqlite").as_posix()}?mode=ro',uri=True)
    models={w:pickle.loads(zlib.decompress(blob)) for w,blob in db.execute('SELECT wallet,body FROM models')}
    db.close()
    if any(m.get('return_basis')!='observed_historical_prices_only' for m in models.values()):
        raise ValueError('Account return models use an unexpected valuation basis')
    daily={w:[m['daily'].get(TEST_START+(d+1)*b.DAY) for d in range(DAYS)] for w,m in models.items()}
    for w,m in models.items():
        write_script(directory/'data'/'accounts'/(w+'.js'),'registerAccountReturns',
            dict(wallet=w,account_name=m['name'],returns=daily[w]))
    validations=[];start=time.monotonic();last=start
    with (directory/'all_account_results.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(SUMMARY_CSV_FIELDS)
        for i,case in enumerate(selected,1):
            validations.append(run_case(case,models,daily,directory,writer))
            if i%10==0 or i==len(selected) or time.monotonic()-last>20:
                progress=dict(status='RUNNING' if i<len(selected) else 'CALCULATED',
                    completed_cases=i,total_cases=len(selected),
                    account_configuration_pairs=sum(v['accounts'] for v in validations))
                write_json(directory/'progress.json',progress);print(json.dumps(progress),flush=True)
                last=time.monotonic()
    index=dict(cases=selected,dates=[b.iso(TEST_START+i*b.DAY)[:10] for i in range(DAYS+1)],
        source_start=b.iso(TEST_START),source_end_exclusive=b.iso(TEST_END),
        source_results_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        standalone_definition='Invest in this account only on its saved selected dates; otherwise hold cash. '
            'All 365 test days enter standalone Sharpe. Values measure the priced macro book, not the owner whole account.',
        contribution_definition='Actual allocated-capital P&L. Account dollar contributions sum to the original strategy P&L. '
            'Return contribution is P&L divided by original strategy starting NAV, in percentage points.')
    template=(ROOT/'account_backtest_explorer.html').read_text(encoding='utf-8')
    encoded=json.dumps(index,ensure_ascii=True,allow_nan=False,separators=(',',':')).replace('<','\\u003c')
    (directory/'account_backtests.html').write_text(template.replace('__BACKTEST_INDEX__',encoded),encoding='utf-8')
    write_json(directory/'validation.json',dict(status='COMPLETE',scope=scope,cases=len(selected),
        unique_accounts=len(models),
        account_configuration_pairs=sum(v['accounts'] for v in validations),
        max_daily_attribution_error=max(v['daily_pnl_max_error'] for v in validations),
        elapsed_seconds=time.monotonic()-start,source_results_sha256=index['source_results_sha256'],
        per_case=validations))
    write_json(directory/'progress.json',dict(status='COMPLETE',completed_cases=len(selected),
        total_cases=len(selected),account_configuration_pairs=sum(v['accounts'] for v in validations)))
    (directory/'README.md').write_text('''# Account-level backtests

Open `account_backtests.html` in a browser. Everything loads locally; no server or external assets are needed.
Choose a saved configuration, search by wallet or name, and select an account for its charts and periods.

Standalone results follow only this account during the dates when the original strategy selected it, with cash
on other days. The example equity chart starts at $10,000; this is a reporting scale for the isolated backtest,
not the basis used to screen the source account. Source Sharpe screening and inverse-volatility allocations
are unchanged. Performance measures only the historically priced macro/geopolitical book.

Account P&L contributions use the original strategy allocations, including their drift and resets. Summing
account P&L reproduces the combined strategy's dollar P&L on every test day. Contribution percentage points
are account P&L / original strategy starting equity * 100, and sum to the strategy's total percentage return.
Adding allocations across resets would double-count reused capital and is not used as a return denominator.

The explorer includes every selected account. Sorting the table only changes the display order; it does not
rank accounts for selection. No full-year return outside an account's selected periods is inferred.

`all_account_results.csv` includes all account/configuration summaries. `csv/` contains a summary and
selection-period ledger for each configuration. Fractional returns in CSV multiply by 100 to give percentages;
contribution fields ending in percentage_points are already expressed in percentage points.
`validation.json` records the attribution reconciliation for every configuration.

Rebuild: `python3.14 backtest_individual_accounts.py --scope all`
Daily-only: `python3.14 backtest_individual_accounts.py --scope daily`
''',encoding='utf-8')
    print('COMPLETE '+str(directory/'account_backtests.html'),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scope',choices=('all','daily'),default='all')
    parser.add_argument('--case-id',help='Optionally inspect one existing case ID')
    args=parser.parse_args();main(args.scope,args.case_id)
