"""Extend descriptive account charts from cached observations, without rescreening."""
from __future__ import annotations

import concurrent.futures
import json
import math
import pickle
import sqlite3
import statistics
import time
import zlib

import rolling_copy_backtest as b
from macro_universe_data import OUT, TEST_END
from macro_account_model import MarketMarks, MacroAccount
from backtest_individual_accounts import write_script, write_json

_marks=_inputs=_economics=None


def initialize():
    global _marks,_inputs,_economics
    _marks=MarketMarks()
    _inputs=sqlite3.connect(f'file:{(OUT/"candidate_inputs.sqlite").as_posix()}?mode=ro',uri=True)
    _economics=sqlite3.connect(f'file:{(OUT/"account_economics.sqlite").as_posix()}?mode=ro',uri=True)
    # This job is a local presentation update, not another collection job.
    # Existing receipt/transfer caches remain readable; never initiate HTTP.
    import urllib.request
    import socket
    def offline(*args,**kwargs):
        raise RuntimeError('Additional observation is not present in the local cache')
    urllib.request.urlopen=offline
    socket.create_connection=offline


def extend(item):
    wallet,original=item
    try:
        _marks.values.clear()
        source=json.loads(zlib.decompress(_inputs.execute('SELECT body FROM candidates WHERE wallet=?',(wallet,)).fetchone()[0]))
        economics=json.loads(zlib.decompress(_economics.execute('SELECT body FROM accounts WHERE wallet=?',(wallet,)).fetchone()[0]))
        recovered=(OUT/'polymarket_transfer_histories'/(wallet+'.json.zlib')).exists()
        model=MacroAccount(source,economics,_marks,reconcile_transfers=recovered,end_override=TEST_END)
        if model.inventory_issues and not recovered:
            # Reuse the same historical responses that reconciled the original
            # account, if they are cached. No inferred opening holdings.
            from macro_universe_data import LayeredAPI
            from screen_macro_performance import reconcile
            source,economics=reconcile(source,economics,_marks,LayeredAPI(1),model.inventory_issues,TEST_END)
            model=MacroAccount(source,economics,_marks,end_override=TEST_END)
        if model.inventory_issues:
            first=min(x['timestamp']+1 for x in model.inventory_issues)
            raise ValueError('Observed inventory could not be reconciled from '+b.iso(first))
        # Changes in reconstruction must not revise the historical performance
        # already used by the strategy, even in an unselected part of its prefix.
        for at,value in original['daily'].items():
            newer=model.daily[at]
            if (value is None)!=(newer is None) or (value is not None and not math.isclose(value,newer,rel_tol=1e-9,abs_tol=1e-10)):
                raise ValueError('Extended reconstruction differs from the verified prefix')
        return wallet,model.daily,None
    except Exception as exc:
        return wallet,original['daily'],str(exc)


def payload(wallet,model,daily,error=None):
    observed=[t for t,v in daily.items() if v is not None]
    start=min(observed)-b.DAY if observed else min(daily)-b.DAY
    end=max(daily)
    dates=list(range(start,end+b.DAY,b.DAY))
    values=[daily[t] for t in dates[1:]]
    invested=[v for v in values if v is not None]
    nav=peak=1.;drawdown=0.
    for value in values:
        nav*=1+max(-1,value or 0.)
        peak=max(peak,nav);drawdown=min(drawdown,nav/peak-1)
    sd=statistics.stdev(invested) if len(invested)>1 else 0.
    sharpe=math.sqrt(365)*statistics.fmean(invested)/sd if sd>1e-15 else None
    return dict(wallet=wallet,account_name=model['name'],dates=[b.iso(t)[:10] for t in dates],
        returns=values,total_return=nav-1,raw_sharpe=sharpe,max_drawdown=drawdown,
        invested_days=len(invested),calendar_days=len(values),coverage_end=b.iso(end),
        reaches_test_end=end==TEST_END,coverage_note=error,
        definition='Available recorded macro/geopolitical book history; normalized performance, not whole-account cash P&L. '
            'Raw Sharpe uses observed invested-day returns. No priced exposure leaves the normalized curve unchanged.')


def main():
    directory=OUT/'account_backtests'/'data'/'lifetimes';directory.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(f'file:{(OUT/"active_book_screened_accounts.sqlite").as_posix()}?mode=ro',uri=True)
    models={w:pickle.loads(zlib.decompress(body)) for w,body in db.execute('SELECT wallet,body FROM models')};db.close()
    pending=[];complete=0;limited=[];reused=0
    for wallet,model in models.items():
        path=directory/(wallet+'.js')
        if path.exists():
            old=json.loads(path.read_text(encoding='utf-8').split('(',1)[1].rsplit(')',1)[0])
            complete+=1
            if not old['reaches_test_end']:limited.append(dict(wallet=wallet,error=old['coverage_note']))
        elif max(model['daily'])==TEST_END:
            write_script(path,'registerAccountLifetime',payload(wallet,model,model['daily']));complete+=1;reused+=1
        else:pending.append((wallet,model))
    def progress(status):
        record=dict(status=status,accounts_completed=complete,total_accounts=len(models),
            histories_through_test_end=complete-len(limited),limited_histories=limited,reused_complete_histories=reused)
        write_json(OUT/'account_backtests'/'lifetime_progress.json',record)
        print(json.dumps({k:v for k,v in record.items() if k!='limited_histories'},allow_nan=False),flush=True)
    progress('RUNNING');last=time.monotonic()
    with concurrent.futures.ProcessPoolExecutor(max_workers=8,initializer=initialize) as pool:
        futures={pool.submit(extend,item):item[0] for item in pending}
        for future in concurrent.futures.as_completed(futures):
            wallet,daily,error=future.result()
            write_script(directory/(wallet+'.js'),'registerAccountLifetime',payload(wallet,models[wallet],daily,error))
            complete+=1
            if max(daily)<TEST_END:limited.append(dict(wallet=wallet,error=error))
            if time.monotonic()-last>=15:progress('RUNNING');last=time.monotonic()
    progress('COMPLETE')


if __name__=='__main__':main()
