# Copy Trading App — Result Notes

The existing completed study covers **14 September 2025 to 14 September 2026**
(exclusive end), with warm-up history from 14 September 2024. Its final saved
summary records 1,691,425 discovered accounts, 15,980 accounts requiring
performance reconstruction after the activity/frequency prefilter, and zero
unresolved records in the completed performance summary.

Discovery stopped on user instruction below its three-million-account limit:
40,931 additional market feeds were complete and 166 were partial. Candidate
histories were completed separately where needed. This is observed discovery
coverage, not a claim to have found every possible Polymarket account.

| Final study | Cases | Mean strategy Sharpe | Minimum / maximum Sharpe | Minimum / maximum compounded return |
| --- | ---: | ---: | ---: | ---: |
| Raw allocation-window/reset grid | 225 | 1.927 | 0.105 / 3.778 | -0.38% / +70.41% |
| Daily Raw/Effective cutoff grid | 12 | 1.357 | 0.255 / 2.515 | -11.77% / +35.35% |
| Effective range/cutoff reset grid | 55 | 1.503 | -0.811 / 6.524 | -98.76% / +1,259.81% |

Means are arithmetic averages across parameter cases, not the performance of an
ensemble portfolio. The wide spread, including severe losses, matters when
interpreting parameter sensitivity.

The app's current default, **Effective Sharpe (3,4], 75-day reset, 365-day maximum
lagged volatility history**, recorded a strategy Sharpe of **4.245**, compounded
return **+181.09%**, $10,000 to **$28,109.36**, and maximum drawdown **12.28%** in
that saved historical study. The highest saved strategy Sharpe was **6.524** for
Effective `(5,6]`, 75-day reset and 365-day volatility history, with **+111.26%**
return. That is an ex-post parameter-grid observation, not independent validation
of selecting the best configuration.

These figures were read from the completed research summary on 30 September 2026;
they were not recalculated by a new market-data download for this packaging task.
The final runner is `run_active_macro_study.py`. It compounds daily active-book
returns with zero fees, slippage, spread or financing costs. It does not simulate
intraday midpoint-limit queue fills. Current sandbox/live results therefore must
be measured separately, and fresh public data may not reproduce the same coverage
or exact values. Strategy Sharpe uses all simulation calendar days, including cash
days; account-screening moments use available invested-book observations.
