"""Compute rolling Sharpe from direct value-weighted active macro-book returns."""
from __future__ import annotations

import argparse
import collections
import concurrent.futures
import csv
import dataclasses
import json
import pickle
import sqlite3
import time
import zlib

import rolling_copy_backtest as b
from macro_universe_data import ROOT,OUT,TEST_START,TEST_END,LayeredAPI,dump
from macro_account_model import MarketMarks,MacroAccount


def reconcile(source,economics,marks,api,issues,required_end=TEST_END):
    """Recover actual older scoped activity, rather than infer opening shares."""
    conditions=sorted({marks.token_condition[x['token']] for x in issues})
    rows=[r for r in source['rows'] if r[5] not in conditions]
    actions=[r for r in economics['actions'] if r.get('condition_id') not in conditions or r['type']=='CONVERSION']
    for i in range(0,len(conditions),5):
        group=conditions[i:i+5]
        params=dict(user=source['wallet'],condition=','.join(group),start=1,end=required_end-1,
            sort_direction='ASC',limit=1000,exclude_deposits_withdrawals='true')
        for page in api.pages('/v2/activity',params):
            for raw in page:
                e=b.Event.parse(raw)
                if e.condition not in marks.by_condition:continue
                if e.kind=='TRADE':
                    rows.append((e.wallet,e.ts,e.token,e.side,e.tx,e.condition,e.size,e.price,
                                 e.cash,e.title,e.outcome,e.outcome_index))
                elif e.kind!='CONVERSION':actions.append(raw)
    # Restore the existing transaction/token/side grouping on recovered fills.
    grouped={}
    for r in rows:
        key=tuple(r[:5])
        if key not in grouped:grouped[key]=r
        else:
            old=grouped[key]
            size=old[6]+r[6]
            grouped[key]=(*old[:6],size,(old[6]*old[7]+r[6]*r[7])/size,old[8]+r[8],*old[9:])
    source=dict(source,rows=sorted(grouped.values(),key=lambda r:r[1]))
    economics=dict(economics,actions=sorted(actions,key=lambda r:r['timestamp']))
    return source,economics


_marks=_api=_inputs=_economics=None


def initialize_worker():
    global _marks,_api,_inputs,_economics
    _marks=MarketMarks()
    _api=LayeredAPI(2)
    _inputs=sqlite3.connect(f'file:{(OUT/"candidate_inputs.sqlite").as_posix()}?mode=ro',uri=True)
    _economics=sqlite3.connect(f'file:{(OUT/"account_economics.sqlite").as_posix()}?mode=ro',uri=True)


def one_account(wallet):
    try:
        # Keep the current account's complete quote set in compact arrays.
        # A small LRU repeatedly decompressed quotes for large books.
        _marks.values.clear()
        hit=_economics.execute('SELECT body FROM accounts WHERE wallet=?',(wallet,)).fetchone()
        if not hit:return wallet,'PENDING',[],None,'Inventory actions not yet collected'
        blob=_inputs.execute('SELECT body FROM candidates WHERE wallet=?',(wallet,)).fetchone()[0]
        source=json.loads(zlib.decompress(blob))
        economics=json.loads(zlib.decompress(hit[0]))
        recovered=(OUT/'polymarket_transfer_histories'/(wallet+'.json.zlib')).exists()
        model=MacroAccount(source,economics,_marks,reconcile_transfers=recovered)
        if model.inventory_issues and not recovered:
            source,economics=reconcile(source,economics,_marks,_api,model.inventory_issues,model.end)
            model=MacroAccount(source,economics,_marks)
        if model.inventory_issues:
            model=MacroAccount(source,economics,_marks,reconcile_transfers=True)
        records=[]
        issues=collections.Counter()
        has_eligible=False
        for at in source['dates']:
            metric,error=model.metrics(at)
            if error:
                issues[error]+=1
                continue
            eligible=metric['qualifies_style_and_activity']
            records.append((at,wallet,metric['raw_sharpe'],metric['effective_sharpe'],int(eligible),json.dumps(metric)))
            if eligible and metric['raw_sharpe']>1.5:has_eligible=True
        packed=None
        if has_eligible:
            if model.name==wallet:
                # Identity label only; never a performance or discovery input.
                try:
                    payload=_api.get(b.DATA,'/v2/activity',dict(user=wallet,type='TRADE',start=1,
                        end=TEST_END-1,sort_direction='DESC',limit=1,exclude_deposits_withdrawals='true'))
                    if payload.get('data'):
                        last=payload['data'][0]
                        model.name=last.get('name') or last.get('pseudonym') or wallet
                except b.DataError:pass
            packed=zlib.compress(pickle.dumps(dict(wallet=wallet,name=model.name,daily=model.daily,
                return_basis='observed_historical_prices_only',
                boundaries_with_unquoted_positions=len(model.unpriced_tokens),
                omitted_unquoted_tokens=sorted({t for ts in model.unpriced_tokens.values() for t in ts}),
                unpriced_days=sorted(model.unpriced_days),
                unreconciled_from=min((x['timestamp']+1 for x in model.inventory_issues),default=None)),
                protocol=pickle.HIGHEST_PROTOCOL),3)
        status='DATA_ISSUE' if issues['opening_inventory_needs_reconciliation'] else 'COMPLETE'
        details=dict(issues)
        details['boundaries_with_unquoted_positions']=len(model.unpriced_tokens)
        details['distinct_unquoted_tokens']=len({t for ts in model.unpriced_tokens.values() for t in ts})
        if model.inventory_issues:details['first_inventory_issues']=model.inventory_issues[:3]
        return wallet,status,records,packed,json.dumps(details)
    except Exception as exc:
        return wallet,'DATA_ISSUE',[],None,str(exc)


def main(follow=False,workers=4,retry_issues=False,retry_data_only=False):
    while not (OUT/'market_price_summary.json').exists():
        if not follow:raise b.DataError('Market prices are still being prepared')
        time.sleep(2)
    status=json.loads((OUT/'market_price_summary.json').read_text())
    if status['status']!='COMPLETE':raise b.DataError('Market price preparation is incomplete')
    b.log('Loading complete macro market marks; preparing actual account performance')
    inputs=sqlite3.connect(f'file:{(OUT/"candidate_inputs.sqlite").as_posix()}?mode=ro',uri=True)
    output=sqlite3.connect(OUT/'active_book_screened_accounts.sqlite')
    output.execute('PRAGMA journal_mode=WAL')
    output.execute('PRAGMA synchronous=NORMAL')
    output.execute('CREATE TABLE IF NOT EXISTS processed(wallet TEXT PRIMARY KEY,status TEXT,error TEXT) WITHOUT ROWID')
    output.execute('CREATE TABLE IF NOT EXISTS models(wallet TEXT PRIMARY KEY,body BLOB) WITHOUT ROWID')
    output.execute('''CREATE TABLE IF NOT EXISTS metrics(
        at INTEGER,wallet TEXT,raw_sharpe REAL,effective_sharpe REAL,eligible INTEGER,body TEXT,
        PRIMARY KEY(at,wallet)) WITHOUT ROWID''')
    output.execute('CREATE INDEX IF NOT EXISTS metrics_wallet ON metrics(wallet)')
    output.commit()
    if retry_issues:
        from recover_polymarket_inventory import recover
        affected=[w for w,e in output.execute('SELECT wallet,error FROM processed') if 'first_inventory_issues' in e]
        recover(affected)
        valuation_path=OUT/'basket_valuation_recompute_accounts.json'
        if valuation_path.exists() and not retry_data_only:
            affected=list(set(affected)|set(json.loads(valuation_path.read_text())))
        output.executemany('DELETE FROM processed WHERE wallet=?',[(w,) for w in affected])
        output.execute("DELETE FROM processed WHERE status='DATA_ISSUE'")
        output.commit()
    done={r[0] for r in output.execute('SELECT wallet FROM processed')}
    count=len(done)
    selected=output.execute('SELECT count(*) FROM models').fetchone()[0]
    last=time.monotonic()
    with concurrent.futures.ProcessPoolExecutor(max_workers=workers,initializer=initialize_worker) as pool:
        while True:
            pending=iter([w for w, in inputs.execute('SELECT wallet FROM candidates') if w not in done])
            futures=set()
            exhausted=False
            progress=0
            while futures or not exhausted:
                while len(futures)<workers*3 and not exhausted:
                    wallet=next(pending,None)
                    if wallet is None:exhausted=True
                    else:futures.add(pool.submit(one_account,wallet))
                if not futures:break
                ready,futures=concurrent.futures.wait(futures,timeout=1,
                    return_when=concurrent.futures.FIRST_COMPLETED)
                for future in ready:
                    wallet,state,records,packed,error=future.result()
                    if state=='PENDING':continue
                    output.execute('DELETE FROM metrics WHERE wallet=?',(wallet,))
                    output.executemany('INSERT OR REPLACE INTO metrics VALUES(?,?,?,?,?,?)',records)
                    if packed:
                        output.execute('INSERT OR REPLACE INTO models VALUES(?,?)',(wallet,packed))
                    else:output.execute('DELETE FROM models WHERE wallet=?',(wallet,))
                    output.execute('INSERT OR REPLACE INTO processed VALUES(?,?,?)',(wallet,state,error))
                    done.add(wallet)
                    count+=1
                    progress+=1
                if time.monotonic()-last>=15:
                    output.commit()
                    selected=output.execute('SELECT count(*) FROM models').fetchone()[0]
                    status=dict(status='SCREENING',processed_accounts=count,accounts_eligible_for_a_case=selected,
                        candidate_accounts=inputs.execute('SELECT count(*) FROM candidates').fetchone()[0],
                        data_issues=output.execute("SELECT count(*) FROM processed WHERE status='DATA_ISSUE'").fetchone()[0])
                    dump('performance_screen_progress.json',status)
                    b.log(json.dumps(status))
                    last=time.monotonic()
            output.commit()
            finished=(OUT/'activity_screen_summary.json').exists()
            candidate_count=inputs.execute('SELECT count(*) FROM candidates').fetchone()[0]
            if finished and count==candidate_count:break
            if not follow:break
            if not progress:time.sleep(2)
    issues=output.execute("SELECT count(*) FROM processed WHERE status='DATA_ISSUE'").fetchone()[0]
    selected=output.execute('SELECT count(*) FROM models').fetchone()[0]
    result=dict(status='COMPLETE' if finished and count==candidate_count and not issues else 'INCOMPLETE',
        processed_accounts=count,candidate_accounts=candidate_count,accounts_eligible_for_a_case=selected,
        data_issues=issues)
    dump('performance_screen_summary.json',result)
    counts={}
    activity_path=OUT/'reset_activity_counts.csv'
    if activity_path.exists():
        with activity_path.open(newline='',encoding='utf-8') as f:
            counts={r['reset_utc']:int(r['accounts_passing_activity_and_frequency']) for r in csv.DictReader(f)}
    thresholds=(1.5,2,3,4,5,6)
    with (OUT/'screening_counts_by_date.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f)
        writer.writerow(['reset_utc','passes_activity_frequency','computable_return_metrics','passes_style']+
            [f'raw_above_{x:g}' for x in thresholds]+[f'effective_above_{x:g}' for x in thresholds])
        for at in range(TEST_START,TEST_END,b.DAY):
            rows=output.execute('SELECT raw_sharpe,effective_sharpe,eligible FROM metrics WHERE at=?',(at,)).fetchall()
            usable=[r for r in rows if r[2]]
            writer.writerow([b.iso(at),counts.get(b.iso(at)),len(rows),len(usable)]+
                [sum(r[0]>x for r in usable) for x in thresholds]+[sum(r[1]>x for r in usable) for x in thresholds])
    b.log(json.dumps(result))
    output.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--follow',action='store_true')
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--retry-issues',action='store_true')
    parser.add_argument('--retry-data-only',action='store_true',help='Retry unresolved records without repeating the completed basket-valuation update')
    args=parser.parse_args()
    main(args.follow,args.workers,args.retry_issues,args.retry_data_only)
