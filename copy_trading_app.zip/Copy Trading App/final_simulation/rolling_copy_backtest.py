"""One-year Polymarket backtest: annual account filters, 10-day rolling copying.

Each rebalance T: filter AND rank on [T-365 days,T), then copy new trades
during [T,T+10 days). Repeat for a one-year backtest. No trading costs.
Optionally copy then-open positions at the start of a new following episode.
"""
from __future__ import annotations

import argparse
import bisect
import collections
import concurrent.futures
import csv
import dataclasses
import datetime as dt
import functools
import itertools
import json
import math
from pathlib import Path
import re
import sqlite3
import statistics
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib

DAY = 86400
UTC = dt.timezone.utc
DATA = 'https://data-api.polymarket.com'
GAMMA = 'https://gamma-api.polymarket.com'
CLOB = 'https://clob.polymarket.com'


def stamp(value):
    if isinstance(value, (int, float)):
        return int(value)
    parsed = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return int(parsed.timestamp())


def iso(value):
    return dt.datetime.fromtimestamp(value, UTC).isoformat().replace('+00:00', 'Z')


def log(message):
    print(f'[{dt.datetime.now(UTC):%H:%M:%S}] {message}', flush=True)


def annual_sharpe(returns):
    if len(returns) < 2:
        return None
    sd = statistics.stdev(returns)
    return statistics.mean(returns) / sd * math.sqrt(365) if sd > 1e-12 else None


def product_return(returns):
    return math.prod(1 + r for r in returns) - 1


def write_csv(path, rows, columns):
    with Path(path).open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


class DataError(RuntimeError):
    pass


class API:
    """Persistent response cache, bounded retries, cursor validation."""
    def __init__(self, path, workers=6):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=NORMAL')
        self.db.execute('PRAGMA cache_size=-65536')
        self.db.execute('CREATE TABLE IF NOT EXISTS responses (url TEXT PRIMARY KEY, body BLOB)')
        self.lock = threading.Lock()
        self.gate = threading.Semaphore(workers)
        self.requests = 0

    def get(self, base, route, params=None):
        query = urllib.parse.urlencode(sorted((params or {}).items()))
        url = base + route + ('?' + query if query else '')
        with self.lock:
            hit = self.db.execute('SELECT body FROM responses WHERE url=?', (url,)).fetchone()
        if hit:
            return json.loads(zlib.decompress(hit[0]))
        error = None
        for attempt in range(5):
            try:
                request = urllib.request.Request(url, headers={
                    'User-Agent': 'polymarket-copy-backtest/1.0', 'Accept': 'application/json'})
                with self.gate, urllib.request.urlopen(request, timeout=30) as response:
                    raw = response.read()
                result = json.loads(raw)
                compressed = zlib.compress(raw)
                with self.lock:
                    self.db.execute('INSERT OR REPLACE INTO responses VALUES (?,?)',
                                    (url, compressed))
                    self.db.commit()
                    self.requests += 1
                return result
            except urllib.error.HTTPError as exc:
                error = f'HTTP {exc.code}: {exc.read().decode(errors="replace")[:180]}'
                if exc.code not in (429, 500, 502, 503, 504):
                    break
            except (OSError, ValueError) as exc:
                error = str(exc)
            time.sleep(min(2 ** attempt, 8))
        raise DataError(f'{url}: {error}')

    def pages(self, route, params, max_pages=10000):
        cursor = None
        seen = set()
        for _ in range(max_pages):
            query = dict(params)
            if cursor:
                query['cursor'] = cursor
            payload = self.get(DATA, route, query)
            if not isinstance(payload, dict) or not isinstance(payload.get('data'), list):
                raise DataError(f'Unexpected response for {route}')
            yield payload['data']
            pagination = payload.get('pagination', {})
            cursor = pagination.get('next_cursor')
            if not cursor:
                if pagination.get('has_more'):
                    raise DataError('has_more without a next_cursor')
                return
            if cursor in seen or not payload['data']:
                raise DataError('Repeated cursor or empty nonterminal page')
            seen.add(cursor)
        raise DataError(f'{route}: page limit reached; history is incomplete')


@dataclasses.dataclass(frozen=True)
class Event:
    ts: int
    wallet: str
    token: str
    condition: str
    kind: str
    side: str
    size: float
    price: float
    cash: float
    title: str
    tx: str
    combo: bool = False
    outcome: str = ''
    outcome_index: int = -1

    @classmethod
    def parse(cls, row):
        def field(a, b, default=''):
            return row.get(a, row.get(b, default))
        size = float(row.get('size', 0) or 0)
        price = float(row.get('price', 0) or 0)
        if not math.isfinite(size) or not math.isfinite(price) or size < 0:
            raise DataError('Invalid activity size/price')
        return cls(int(row['timestamp']), str(field('proxy_wallet', 'proxyWallet')).lower(),
                   str(field('token_id', 'asset')), str(field('condition_id', 'conditionId')),
                   str(row.get('type', 'TRADE')).upper(), str(row.get('side', '')).upper(),
                   size, price, float(field('usdc_size', 'usdcSize', size * price) or 0),
                   str(row.get('title', '')), str(field('transaction_hash', 'transactionHash')),
                   bool(field('is_combo', 'isCombo', False)), str(row.get('outcome', '')),
                   int(field('outcome_index', 'outcomeIndex', -1)))


MACRO = re.compile(r'\b(inflation|recession|gdp|cpi|pce|unemployment|nonfarm|payrolls?|'
                   r'federal reserve|fed |fomc|interest rate|rate cut|rate hike|tariffs?|'
                   r'trade deal|trade war|debt ceiling|government shutdown|treasury|'
                   r'central bank|bank of japan|bank of england|ecb|dollariz\w*|'
                   r'ceasefire|peace deal|peace agreement|invad\w*|invas\w*|war|nato|nuclear|'
                   r'sanctions?|missile|military|airstrike|iran|israel|ukraine|russia|'
                   r'china|taiwan|gaza|hamas|hezbollah|houthi|north korea|khamenei|'
                   r'xi jinping|putin|netanyahu|zelensky\w*|regime|coup|annex\w*)\b', re.I)
EXCLUDED = re.compile(r'\b(nba|nfl|nhl|mlb|fifa|soccer|tennis|cricket|champions league|'
                      r'ufc|mma|boxing|fiba|esports?|counter.strike|dota|league of legends|'
                      r'bitcoin|ethereum|solana|btc|eth|xrp|up or down|tweet|mentions?|say|speech|address|'
                      r'box office|gta|oscar|grammy|nuclear option|nobel|peace prize|'
                      r'mayoral|mayor|municipal|city council|photographed|selfie|ioc)\b', re.I)
GEO_TOPICS = re.compile(
    r'\b(strik\w*|attack\w*|bomb\w*|nuke\w*|warship\w*|troops?|'
    r'custody|detain\w*|arrest\w*|released from|seen in public|extradit\w*|'
    r'meet\w*|talk\w*|visit\w*|summit\w*|diplomat\w*|embass\w*|'
    r'presiden\w*|prime minister|chancellor|foreign minister|secretary.general|'
    r'parliament\w*|knesset|leader\w*|resign\w*|oust\w*|head of state|'
    r'blockad\w*|transits?|shipping|ships?|hormuz|canal|tolls?|border\w*|'
    r'captur\w*|control|territor\w*|sovereign\w*|sece\w*|independen\w*|'
    r'venezuela\w*|maduro|greenland|cuba\w*|gas|gasoline|oil|brent|wti)\b', re.I)
GEO_TITLES = set()


@functools.lru_cache(maxsize=100000)
def in_scope(title):
    return (title in GEO_TITLES or bool(MACRO.search(title))) and not EXCLUDED.search(title)


@dataclasses.dataclass
class Config:
    start: int
    end: int
    holding_days: int = 10
    filter_days: int = 365
    sharpe_days: int = 365
    minimum_sharpe_days: int = 2
    sharpe_threshold: float = 3.0
    maximum_trades: int = 100
    minimum_closed_lots: int = 2
    minimum_hold_days: float = 2
    maximum_hold_days: float = 5
    maximum_fast_close_fraction: float = 0.10
    maximum_two_sided_fraction: float = 0.20
    minimum_macro_fraction: float = 0.80
    initial_capital: float = 10000
    ticket_fraction: float = 0.10
    slippage_bps: float = 0
    fee_bps: float = 0
    price_bucket_seconds: int = 10800
    workers: int = 6
    copy_existing_positions: bool = False


def grouped_trades(events):
    """Consolidate partial fills from one transaction/token/side into one decision."""
    groups = {}
    for e in events:
        if e.kind != 'TRADE':
            continue
        key = (e.ts, e.tx, e.token, e.side)
        if key not in groups:
            groups[key] = e
        else:
            old = groups[key]
            size = old.size + e.size
            groups[key] = dataclasses.replace(old, size=size, cash=old.cash + e.cash,
                                             price=(old.price * old.size + e.price * e.size) / size)
    return sorted(groups.values(), key=lambda e: (e.ts, e.tx, e.token, e.side))


def polymarket_ledger(events):
    """Keep Polymarket trades and link settlements using preceding market/outcome rows.

    An account address is an identifier only. Deposits, transfers and other wallet
    activity do not enter either screening or return calculations.
    """
    known = {}
    ledger = []
    for e in sorted(events, key=lambda x: (x.ts, x.tx, x.token)):
        if e.kind == 'TRADE' and e.side in ('BUY', 'SELL'):
            if e.outcome:
                known[(e.condition, e.outcome.lower())] = e
            if e.outcome_index >= 0:
                known[(e.condition, e.outcome_index)] = e
            ledger.append(e)
        elif e.kind == 'REDEEM':
            prior = known.get((e.condition, e.outcome.lower())) if e.outcome else None
            prior = prior or known.get((e.condition, e.outcome_index))
            token = e.token or (prior.token if prior else '')
            if token and e.size > 0:
                ledger.append(dataclasses.replace(e, token=token, price=e.cash / e.size,
                    outcome=e.outcome or (prior.outcome if prior else ''),
                    title=e.title or (prior.title if prior else '')))
    return ledger


def behavior(events, rebalance, config, diagnostics=None):
    """ALL account characteristics are measured on the year preceding this rebalance."""
    past = polymarket_ledger(e for e in events if e.ts < rebalance)
    trades = grouped_trades(past)
    if not trades:
        return False, 'no_history'
    left = rebalance - config.filter_days * DAY
    recent = [e for e in trades if e.ts >= left]
    observed_start = max(left, min(e.ts for e in past if e.kind == 'TRADE'))
    observed_days = max(1, (rebalance - observed_start) / DAY)
    trades_per_10_days = len(recent) * 10 / observed_days
    if diagnostics is not None:
        diagnostics.update(trades_in_window=len(recent), observed_days=observed_days,
                           trades_per_10_days=trades_per_10_days)
    if trades_per_10_days >= config.maximum_trades:
        return False, 'frequency'
    amount = sum(e.cash for e in recent)
    macro_fraction = sum(e.cash for e in recent if in_scope(e.title)) / amount if amount > 0 else 0.0
    if diagnostics is not None:
        diagnostics['macro_notional_fraction'] = macro_fraction
    if amount <= 0 or macro_fraction < config.minimum_macro_fraction:
        return False, 'outside_macro'
    sides = collections.defaultdict(set)
    outcomes = collections.defaultdict(set)
    for e in recent:
        sides[(e.token, e.ts // 3600)].add(e.side)
        outcomes[(e.condition, e.ts // 3600)].add(e.token)
    two_sided = sum(len(s) > 1 for s in sides.values()) / len(sides)
    both_outcomes = sum(len(s) > 1 for s in outcomes.values()) / len(outcomes)
    if diagnostics is not None:
        diagnostics.update(two_sided_fraction=two_sided, both_outcomes_fraction=both_outcomes)
    if two_sided > config.maximum_two_sided_fraction:
        return False, 'two_sided'
    if both_outcomes > config.maximum_two_sided_fraction:
        return False, 'both_outcomes'
    lots = collections.defaultdict(collections.deque)
    durations = []
    weights = []
    closings = grouped_trades(past) + [dataclasses.replace(e, side='SELL') for e in past
                                      if e.kind == 'REDEEM' and e.token and e.size > 0]
    closings.sort(key=lambda e: (e.ts, e.tx, e.token))
    for e in closings:
        if not in_scope(e.title):
            continue
        if e.side == 'BUY':
            lots[e.token].append([e.ts, e.size])
        elif e.side == 'SELL':
            remaining = e.size
            while remaining > 1e-8 and lots[e.token]:
                lot = lots[e.token][0]
                matched = min(remaining, lot[1])
                if e.ts >= left:
                    durations.append((e.ts - lot[0]) / DAY)
                    weights.append(matched)
                remaining -= matched
                lot[1] -= matched
                if lot[1] < 1e-8:
                    lots[e.token].popleft()
    if diagnostics is not None:
        diagnostics['completed_lot_matches'] = len(durations)
    if len(durations) < config.minimum_closed_lots:
        return False, 'insufficient_completed_holds'
    order = sorted(zip(durations, weights))
    halfway = sum(weights) / 2
    cumulative = 0
    median = 0
    for duration, weight in order:
        cumulative += weight
        if cumulative >= halfway:
            median = duration
            break
    fast = sum(w for d, w in order if d < 1 / 24) / sum(weights)
    if diagnostics is not None:
        diagnostics.update(median_hold_days=median, fast_close_fraction=fast)
    if not config.minimum_hold_days <= median <= config.maximum_hold_days:
        return False, 'holding_duration'
    if fast > config.maximum_fast_close_fraction:
        return False, 'fast_closes'
    return True, {'median_hold_days': median, 'trades_in_filter_window': len(recent),
                  'trades_per_10_days': trades_per_10_days, 'filter_start_utc': iso(observed_start),
                  'filter_end_utc': iso(rebalance), 'filter_history_days': observed_days}


class Prices:
    def __init__(self, api, config):
        self.api, self.config = api, config
        self.values = {}
        self.failures = {}
        self.closed_at = {}
        self.full_history_attempted = set()

    def load(self, token, start, end):
        if token in self.values:
            return
        points = {}
        # V2's coarse series is permanent. Legacy CLOB fine-grain history expires.
        for rows in self.api.pages('/v2/prices-history', {
                'token_id': token, 'interval': 'max',
                'bucket_seconds': self.config.price_bucket_seconds, 'limit': 10000}):
            for p in rows:
                # Treat a bucket as available only at its END, conservatively
                # preventing any within-bucket observation from leaking backward.
                ts = int(p['timestamp']) + int(p['resolution_seconds'])
                price = float(p['price'])
                if ts <= end and math.isfinite(price) and 0 <= price <= 1:
                    points[ts] = price
        times = sorted(points)
        self.values[token] = (times, [points[t] for t in times])

    def add_transactions(self, accounts):
        # Actual trade prices are point-in-time observations too. A settlement
        # becomes usable at its recorded time, never at an earlier market date.
        extra = collections.defaultdict(dict)
        for events in accounts.values():
            for e in events:
                if e.token and in_scope(e.title) and e.kind in ('TRADE', 'REDEEM'):
                    if math.isfinite(e.price) and 0 <= e.price <= 1:
                        extra[e.token][e.ts] = e.price
        for token, observations in extra.items():
            times, values = self.values.get(token, ([], []))
            observations = dict(zip(times, values)) | observations
            times = sorted(observations)
            self.values[token] = (times, [observations[t] for t in times])

    def mark(self, token, at):
        times, prices = self.values.get(token, ([], []))
        index = bisect.bisect_right(times, at) - 1
        if index < 0 and token not in self.full_history_attempted:
            # A SPLIT can introduce a position before the first collected trade.
            # Use earlier observed API prices, retaining transaction-mark priority.
            self.full_history_attempted.add(token)
            existing = dict(zip(times, prices))
            self.values.pop(token, None)
            self.load(token, 0, self.config.end)
            loaded_times, loaded_prices = self.values[token]
            points = dict(zip(loaded_times, loaded_prices)) | existing
            times = sorted(points)
            prices = [points[t] for t in times]
            self.values[token] = times, prices
            index = bisect.bisect_right(times, at) - 1
        if index < 0:
            raise DataError(f'No observed trade or market price for {token} before {iso(at)}')
        return prices[index]


def account_score(events, prices, at, config):
    okay, details = behavior(events, at, config)
    if not okay:
        return None, details
    first_day = min(e.ts for e in events if e.kind == 'TRADE' and in_scope(e.title)) // DAY * DAY
    left = max(at - config.sharpe_days * DAY, first_day)
    days = (at - left) // DAY
    if days < config.minimum_sharpe_days:
        return None, 'insufficient_return_observations'
    # Standardized capital and sizing make accounts comparable without inferring
    # the account owner's wallet balance. Only events strictly before at enter.
    curve, _, _ = copy_sleeve(events, prices, left, at, config.initial_capital,
                              config, liquidate=False)
    previous = config.initial_capital
    returns = []
    for _, nav in sorted(curve.items()):
        returns.append(nav / previous - 1 if previous > 1e-12 else 0.0)
        previous = nav
    sharpe = annual_sharpe(returns)
    if sharpe is None or sharpe <= config.sharpe_threshold:
        return None, 'sharpe'
    return dict(details, sharpe=sharpe, sharpe_observations=len(returns),
                return_1y=previous / config.initial_capital - 1,
                sharpe_start=iso(left)), None


def catalog(api, config):
    markets = {}
    tags_by_condition = collections.defaultdict(set)
    GEO_TITLES.clear()
    last_log = time.monotonic()
    # Include closed markets; never filter on current volume, PnL or winning outcome.
    for tag in (225, 100265, 2):
        for closed in ('true', 'false'):
            seen = set()
            cursor = None
            for _ in range(10000):
                query = {'tag_id': tag, 'closed': closed, 'limit': 100,
                         'order': 'id', 'ascending': 'true',
                         'end_date_min': iso(config.start - config.filter_days * DAY),
                         'start_date_max': iso(config.end)}
                if cursor:
                    query['after_cursor'] = cursor
                payload = api.get(GAMMA, '/markets/keyset', query)
                rows = payload.get('markets')
                if not isinstance(rows, list):
                    raise DataError('Invalid market catalog')
                for m in rows:
                    if not m.get('conditionId') or not m.get('createdAt'):
                        continue
                    if stamp(m['createdAt']) >= config.end:
                        continue
                    markets[m['conditionId']] = m
                    tags_by_condition[m['conditionId']].add(tag)
                    if tag == 100265 and GEO_TOPICS.search(m.get('question', '')):
                        GEO_TITLES.add(m['question'])
                cursor = payload.get('next_cursor')
                if not cursor:
                    break
                if cursor in seen:
                    raise DataError('Gamma repeated a market cursor')
                seen.add(cursor)
                if time.monotonic() - last_log >= 15:
                    log(f'Market discovery catalog: {len(markets):,} entries loaded')
                    last_log = time.monotonic()
            else:
                raise DataError('Market catalog pagination exhausted')
    in_scope.cache_clear()
    return [dict(m, discovery_tag_ids=sorted(tags_by_condition[condition]))
            for condition, m in markets.items() if in_scope(m.get('question', ''))]


def discover(api, config):
    """Discover accounts from all matching markets, with trades sliced at each T.

    The disk index avoids holding the entire expanding market feed in memory.
    Completed market downloads are reusable; no market-count sample is taken.
    """
    markets = sorted(catalog(api, config), key=lambda m: (stamp(m['createdAt']), m['conditionId']))
    earliest = config.start - config.filter_days * DAY
    legacy = json.loads(Path(__file__).with_name('legacy_2025_markets.json').read_text(encoding='utf-8'))
    legacy_conditions = {market['conditionId'] for market in legacy}
    dates = list(range(config.start, config.end, config.holding_days * DAY))
    expanded_dates = [at for at in dates if at >= stamp('2026-01-01')]
    expanded_left = min(expanded_dates) - config.filter_days * DAY if expanded_dates else config.end
    store_path = Path(__file__).with_name('rolling_discovery.sqlite')
    db = sqlite3.connect(store_path, check_same_thread=False)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA synchronous=NORMAL')
    db.execute('PRAGMA cache_size=-524288')
    db.execute('PRAGMA wal_autocheckpoint=10000')
    db.execute('CREATE TABLE IF NOT EXISTS completed (condition TEXT PRIMARY KEY, left_ts INTEGER, right_ts INTEGER)')
    db.execute("""CREATE TABLE IF NOT EXISTS trades (
        wallet TEXT, ts INTEGER, token TEXT, side TEXT, tx TEXT, condition TEXT,
        size REAL, price REAL, cash REAL, title TEXT, outcome TEXT, outcome_index INTEGER,
        PRIMARY KEY(wallet, ts, token, side, tx)) WITHOUT ROWID""")
    db.execute('CREATE INDEX IF NOT EXISTS trades_condition ON trades(condition)')
    db.commit()
    lock = threading.Lock()
    pending_rows = 0
    log(f'Rolling discovery: collecting all {len(markets):,} matching markets, including new 2026 markets')
    insert = """INSERT INTO trades VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(wallet,ts,token,side,tx) DO UPDATE SET
        price=(trades.price*trades.size+excluded.price*excluded.size)/(trades.size+excluded.size),
        size=trades.size+excluded.size, cash=trades.cash+excluded.cash"""

    def one(market):
        nonlocal pending_rows
        condition = market['conditionId']
        market_left = earliest if condition in legacy_conditions else max(earliest, expanded_left)
        with lock:
            done = db.execute('SELECT left_ts,right_ts FROM completed WHERE condition=?', (condition,)).fetchone()
            if done == (market_left, config.end):
                return condition
            # An interrupted market is rebuilt from its cached pages, preventing duplicates.
            db.execute('DELETE FROM trades WHERE condition=?', (condition,))
            db.execute('DELETE FROM completed WHERE condition=?', (condition,))
            db.commit()
            pending_rows = 0
        for rows in api.pages('/v2/trades', {'condition': condition, 'limit': 1000, 'taker_only': 'false'}):
            batch = [Event.parse(row) for row in rows]
            records = [(e.wallet, e.ts, e.token, e.side, e.tx, e.condition, e.size, e.price,
                        e.cash, e.title, e.outcome, e.outcome_index)
                       for e in batch if market_left <= e.ts < config.end and e.size > 0]
            if records:
                with lock:
                    db.executemany(insert, records)
                    pending_rows += len(records)
                    if pending_rows >= 10000:
                        db.commit()
                        pending_rows = 0
            if batch and min(e.ts for e in batch) < market_left:
                break
        with lock:
            db.execute('INSERT OR REPLACE INTO completed VALUES (?,?,?)', (condition, market_left, config.end))
            db.commit()
            pending_rows = 0
        return condition

    with concurrent.futures.ThreadPoolExecutor(config.workers) as pool:
        futures = [pool.submit(one, market) for market in markets]
        last_log = 0
        for i, future in enumerate(concurrent.futures.as_completed(futures), 1):
            future.result()
            if time.monotonic() - last_log >= 15 or i == len(markets):
                log(f'Market trade histories {i:,}/{len(markets):,} completed')
                last_log = time.monotonic()
    # Remove cached markets that no longer pass the same category classifier.
    valid_conditions = {m['conditionId'] for m in markets}
    for condition, in db.execute('SELECT condition FROM completed').fetchall():
        if condition not in valid_conditions:
            db.execute('DELETE FROM trades WHERE condition=?', (condition,))
            db.execute('DELETE FROM completed WHERE condition=?', (condition,))
    db.commit()
    candidates = {at: [] for at in dates}
    counts = {at: {'rebalance_utc': iso(at), 'observed_accounts': 0, 'new_accounts_since_previous': 0,
                   'markets_with_preceding_year_trades': 0, 'macro_behavior_candidates': 0} for at in dates}
    market_days = collections.defaultdict(set)

    def possible_holding_dates(events, relevant_dates):
        # Exactly the existing FIFO holding rule, calculated once per account.
        # This avoids repeating it for wallets with no completed multi-day holds.
        if not relevant_dates:
            return set()
        lots = collections.defaultdict(collections.deque)
        closed = []
        for e in events:
            if not in_scope(e.title):
                continue
            if e.side == 'BUY':
                lots[e.token].append([e.ts, e.size])
            elif e.side == 'SELL':
                remaining = e.size
                while remaining > 1e-8 and lots[e.token]:
                    lot = lots[e.token][0]
                    quantity = min(remaining, lot[1])
                    closed.append((e.ts, (e.ts - lot[0]) / DAY, quantity))
                    remaining -= quantity
                    lot[1] -= quantity
                    if lot[1] < 1e-8:
                        lots[e.token].popleft()
        close_times = [row[0] for row in closed]
        possible = set()
        for at in relevant_dates:
            left = bisect.bisect_left(close_times, at - config.filter_days*DAY)
            right = bisect.bisect_left(close_times, at)
            if right - left < config.minimum_closed_lots:
                continue
            matches = sorted((duration, size) for _, duration, size in closed[left:right])
            total = sum(size for _, size in matches)
            accumulated = 0
            for median, quantity in matches:
                accumulated += quantity
                if accumulated >= total / 2:
                    break
            if config.minimum_hold_days <= median <= config.maximum_hold_days:
                possible.add(at)
        return possible

    log('Evaluating rolling account candidates from the completed trade index')
    last_log = time.monotonic()
    trade_count = 0
    i = 0
    # The primary key already orders rows by wallet and time. One streaming
    # pass supplies both account records and exact market/day coverage.
    stream = db.execute('SELECT * FROM trades ORDER BY wallet,ts')
    for i, (wallet, rows) in enumerate(itertools.groupby(stream, key=lambda row: row[0]), 1):
        events = [Event(ts, wallet, sys.intern(token), sys.intern(condition), 'TRADE',
                        sys.intern(side), size, price, cash, sys.intern(title), tx,
                        False, sys.intern(outcome), outcome_index)
                  for w, ts, token, side, tx, condition, size, price, cash, title, outcome, outcome_index in rows]
        trade_count += len(events)
        for e in events:
            market_days[e.condition].add(e.ts // DAY * DAY)
        events.sort(key=lambda e: (e.ts, e.tx, e.token))
        times = [e.ts for e in events]
        first = times[0]
        legacy_events = [e for e in events if e.condition in legacy_conditions]
        legacy_times = [e.ts for e in legacy_events]
        # Apply the same necessary frequency bound before expensive lot matching.
        def feasible(times, period_dates):
            return [at for at in period_dates if 0 < bisect.bisect_left(times, at)
                    - bisect.bisect_left(times, at - config.filter_days*DAY)
                    < config.maximum_trades * config.filter_days / 10]
        possible_dates = possible_holding_dates(legacy_events,
            feasible(legacy_times, [at for at in dates if at < stamp('2026-01-01')]))
        possible_dates.update(possible_holding_dates(events, feasible(times, expanded_dates)))
        for at in dates:
            selected_events = legacy_events if at < stamp('2026-01-01') else events
            selected_times = legacy_times if at < stamp('2026-01-01') else times
            right = bisect.bisect_left(selected_times, at)
            left = bisect.bisect_left(selected_times, at - config.filter_days*DAY)
            if not right:
                continue
            first = selected_times[0]
            counts[at]['observed_accounts'] += 1
            if at - config.holding_days*DAY <= first < at or (at == config.start and first < at):
                counts[at]['new_accounts_since_previous'] += 1
            # Necessary frequency bound from complete collected macro trade decisions.
            if right - left >= config.maximum_trades * config.filter_days / 10:
                continue
            if at not in possible_dates:
                continue
            if behavior(selected_events[:right], at, config)[0]:
                candidates[at].append(wallet)
                counts[at]['macro_behavior_candidates'] += 1
        if time.monotonic() - last_log >= 15:
            log(f'Rolling trade-account discovery: {i:,} accounts processed; '
                f'{sum(map(len, candidates.values())):,} account-period candidates')
            last_log = time.monotonic()
    for condition, days in market_days.items():
        times = sorted(days)
        for at in dates:
            if at < stamp('2026-01-01') and condition not in legacy_conditions:
                continue
            if bisect.bisect_left(times, at) > bisect.bisect_left(times, at - config.filter_days*DAY):
                counts[at]['markets_with_preceding_year_trades'] += 1
    log(f'Rolling trade-account discovery complete: {i:,} accounts; '
        f'{sum(map(len, candidates.values())):,} account-period candidates')
    api.discovery_periods = list(counts.values())
    api.discovery_market_count = len(markets)
    api.discovery_trade_count = trade_count
    db.close()
    union = sorted({wallet for group in candidates.values() for wallet in group})
    return markets, candidates, union, i


def collect_accounts(api, wallets, config, retain_cashflows=False):
    result, failures = {}, {}

    def one(wallet):
        events = []
        try:
            for rows in api.pages('/v2/activity', {'user': wallet, 'start': 1,
                'end': config.end - 1, 'sort_direction': 'ASC', 'limit': 1000,
                'exclude_deposits_withdrawals': 'false'}):
                batch = [Event.parse(r) for r in rows]
                if any(e.wallet != wallet or e.ts >= config.end for e in batch):
                    raise DataError('Activity endpoint ignored wallet or end boundary')
                events.extend(batch)
            events.sort(key=lambda e: e.ts)
            return wallet, events, None
        except DataError as exc:
            return wallet, None, str(exc)

    with concurrent.futures.ThreadPoolExecutor(config.workers) as pool:
        for i, (wallet, events, error) in enumerate(pool.map(one, wallets), 1):
            if error:
                failures[wallet] = error
            else:
                result[wallet] = events if retain_cashflows else polymarket_ledger(events)
            if i % 10 == 0 or i == len(wallets):
                log(f'Account histories {i}/{len(wallets)}; failed {len(failures)}')
    return result, failures


def screen_account_windows(api, candidates, config):
    """Screen the complete preceding YEAR of Polymarket activity for each rebalance."""
    jobs = [(at, wallet) for at, wallets in candidates.items() for wallet in wallets]
    screened = {at: [] for at in candidates}
    counts = collections.Counter()

    def one(job, frequency_evidence=None):
        at, wallet = job
        events = []
        try:
            for rows in api.pages('/v2/activity', {'user': wallet,
                'start': at - config.filter_days * DAY, 'end': at - 1,
                'sort_direction': 'DESC', 'limit': 1000}, max_pages=100):
                batch = [Event.parse(r) for r in rows]
                if any(e.ts >= at or e.ts < at - config.filter_days * DAY for e in batch):
                    raise DataError('Activity endpoint ignored the historical window')
                events.extend(batch)
                if frequency_evidence is not None:
                    frequency_evidence.update((e.ts, e.tx, e.token, e.side)
                                              for e in batch if e.kind == 'TRADE')
                if len(grouped_trades(events)) >= config.maximum_trades * config.filter_days / 10:
                    return at, wallet, 'frequency'
            okay, reason = behavior(events, at, config)
            # These require opening inventory from earlier history; defer them.
            if okay or reason in ('insufficient_completed_holds', 'holding_duration', 'fast_closes'):
                return at, wallet, None
            return at, wallet, reason
        except DataError:
            return at, wallet, 'unavailable_window'

    log(f'Applying ANNUAL account filters to {len(jobs):,} rebalance/account windows')
    by_wallet = collections.defaultdict(list)
    for at, wallet in jobs:
        by_wallet[wallet].append(at)

    def wallet_windows(item):
        wallet, dates = item
        dates.sort()
        left, right = dates[0] - config.filter_days * DAY, dates[-1]
        events = []
        complete = False
        try:
            # A short history can serve every rolling window for this wallet.
            # Each decision below still slices strictly before its own rebalance.
            for rows in api.pages('/v2/activity', {'user': wallet, 'start': left,
                'end': right - 1, 'sort_direction': 'ASC', 'limit': 1000}, max_pages=4):
                batch = [Event.parse(r) for r in rows]
                if any(e.wallet != wallet or not left <= e.ts < right for e in batch):
                    raise DataError('Activity endpoint ignored the historical window')
                events.extend(batch)
            complete = True
        except DataError:
            pass
        if not complete:
            # Reuse observed trade counts when overlapping annual windows
            # already contain enough distinct decisions to exceed the limit.
            # Every proof is sliced to the specific rebalance, without future rows.
            evidence = {(e.ts, e.tx, e.token, e.side) for e in events if e.kind == 'TRADE'}
            answer = []
            for at in dates:
                known_count = sum(at - config.filter_days * DAY <= key[0] < at for key in evidence)
                if known_count >= config.maximum_trades * config.filter_days / 10:
                    answer.append((at, wallet, 'frequency'))
                else:
                    answer.append(one((at, wallet), evidence))
            return answer
        answer = []
        for at in dates:
            window = [e for e in events if at - config.filter_days * DAY <= e.ts < at]
            okay, reason = behavior(window, at, config)
            if okay or reason in ('insufficient_completed_holds', 'holding_duration', 'fast_closes'):
                reason = None
            answer.append((at, wallet, reason))
        return answer

    with concurrent.futures.ThreadPoolExecutor(config.workers) as pool:
        futures = [pool.submit(wallet_windows, item) for item in by_wallet.items()]
        completed, next_report = 0, 200
        for future in concurrent.futures.as_completed(futures):
            rows = future.result()
            for at, wallet, reason in rows:
                if reason:
                    counts[reason] += 1
                else:
                    screened[at].append(wallet)
            completed += len(rows)
            if completed >= next_report or completed == len(jobs):
                log(f'Annual account screen {completed}/{len(jobs)}; {sum(map(len, screened.values()))} windows retained')
                next_report = completed + 200
    return screened, dict(counts)


def collect_prices(api, accounts, config):
    ranges = {}
    for events in accounts.values():
        for e in events:
            if e.token and in_scope(e.title) and e.kind in ('TRADE', 'REDEEM'):
                ranges[e.token] = min(ranges.get(e.token, e.ts), e.ts)
    prices = Prices(api, config)

    def one(item):
        token, left = item
        try:
            prices.load(token, left, config.end)
        except DataError as exc:
            prices.failures[token] = str(exc)
            prices.values[token] = ([], [])
        return token

    log(f'Loading historical marks for {len(ranges):,} traded outcome tokens')
    with concurrent.futures.ThreadPoolExecutor(config.workers) as pool:
        for i, _ in enumerate(pool.map(one, ranges.items()), 1):
            if i % 250 == 0 or i == len(ranges):
                log(f'Price histories {i}/{len(ranges)}; transaction-price fallback {len(prices.failures)}')
    prices.add_transactions(accounts)
    return prices


@dataclasses.dataclass
class Sleeve:
    account: str
    copy_start: int
    cash: float = 0.0
    source: dict = dataclasses.field(default_factory=lambda: collections.defaultdict(float))
    holdings: dict = dataclasses.field(default_factory=lambda: collections.defaultdict(float))
    metadata: dict = dataclasses.field(default_factory=dict)


def source_positions(events, at, closed_at=None):
    """Open eligible shares from Polymarket trades/settlements strictly before at."""
    balances = collections.defaultdict(float)
    metadata = {}
    for e in sorted((e for e in events if e.ts < at), key=lambda e: (e.ts, e.tx, e.token)):
        if not e.token or not in_scope(e.title):
            continue
        if e.kind == 'TRADE' and e.side == 'BUY':
            balances[e.token] += e.size
        elif (e.kind == 'TRADE' and e.side == 'SELL') or e.kind == 'REDEEM':
            balances[e.token] = max(0.0, balances[e.token] - e.size)
        else:
            continue
        metadata[e.token] = e
    closed_at = closed_at or {}
    positions = {token: quantity for token, quantity in balances.items()
                 if quantity > 1e-8 and closed_at.get(metadata[token].condition, at + 1) > at}
    return positions, {token: metadata[token] for token in positions}


def initialize_positions(state, events, prices, at, trade_log=None, portfolio=''):
    """Buy the selected account's existing positions at pre-selection marks.

    Normalize eligible open position market values to the sleeve's available cash.
    Historical source costs and profits are not inherited. Source quantities seed
    subsequent proportional SELLs. Call only when a new following episode starts.
    """
    positions, metadata = source_positions(events, at, prices.closed_at)
    marks = {token: prices.mark(token, at - 1) for token in positions}
    total_value = sum(quantity * marks[token] for token, quantity in positions.items())
    state.source.update(positions)
    state.metadata.update(metadata)
    if total_value <= 1e-8 or state.cash <= 1e-8:
        return 0, 0.0
    capital = state.cash
    scale = capital / total_value
    count = 0
    invested = 0.0
    for token, source_quantity in positions.items():
        if marks[token] <= 0:
            continue
        quantity = source_quantity * scale
        state.holdings[token] = quantity
        invested += quantity * marks[token]
        count += 1
        if trade_log is not None:
            # This is our synthetic entry, not a source trade at this timestamp.
            event = dataclasses.replace(metadata[token], tx='')
            trade_log.append(execution_row(event, 'OPENING_BUY', quantity, marks[token],
                                           at, portfolio, state.copy_start))
    state.cash = max(0.0, capital - invested)
    return count, invested


def position_value(state, prices, at):
    return sum(q * prices.mark(token, at) for token, q in state.holdings.items() if q > 1e-8)


def execution_row(e, side, quantity, price, at, portfolio, copy_start):
    return {'portfolio': portfolio, 'account': e.wallet, 'copy_start_utc': iso(copy_start),
        'time_utc': iso(at), 'market': e.title, 'condition_id': e.condition,
        'token_id': e.token, 'outcome': e.outcome, 'side': side, 'price': price,
        'size': quantity, 'notional': quantity * price, 'transaction_hash': e.tx}


def flatten(state, prices, at, trade_log=None, portfolio='', reason='ACCOUNT_REMOVED'):
    count = 0
    for token, quantity in list(state.holdings.items()):
        if quantity <= 1e-8:
            continue
        price = prices.mark(token, at - 1)
        state.cash += quantity * price
        state.holdings[token] = 0.0
        count += 1
        if trade_log is not None:
            trade_log.append(execution_row(state.metadata[token], reason, quantity,
                price, at, portfolio, state.copy_start))
    return count


def run_sleeve(state, events, prices, start, end, target_capital, config,
               trade_log=None, portfolio=''):
    # Apply new transactions to the current copied book, including any positions
    # initialized once at the start of this account's following episode.
    transactions = grouped_trades(e for e in events if start <= e.ts < end)
    transactions += [e for e in events if start <= e.ts < end and e.kind == 'REDEEM']
    transactions.sort(key=lambda e: (e.ts, e.tx, e.token))
    pointer = executions = skipped = 0
    curve = {}
    for boundary in range(start + DAY, end + 1, DAY):
        while pointer < len(transactions) and transactions[pointer].ts < boundary:
            e = transactions[pointer]
            pointer += 1
            if not in_scope(e.title):
                continue
            state.metadata[e.token] = e
            quantity = 0.0
            action = e.side
            if e.kind == 'TRADE' and e.side == 'BUY':
                state.source[e.token] += e.size
                if not 0 < e.price <= 1:
                    skipped += 1
                    continue
                spend = min(state.cash, target_capital * config.ticket_fraction)
                if spend > 1e-8:
                    quantity = spend / e.price
                    state.holdings[e.token] += quantity
                    state.cash -= spend
            elif e.side == 'SELL' or e.kind == 'REDEEM':
                observed = state.source[e.token]
                fraction = min(1.0, e.size / observed) if observed > 1e-8 else 0.0
                state.source[e.token] = max(0.0, observed - e.size)
                quantity = state.holdings[e.token] * fraction
                if quantity > 1e-8:
                    state.cash += quantity * e.price
                    state.holdings[e.token] -= quantity
                action = 'SETTLE' if e.kind == 'REDEEM' else 'SELL'
            if quantity > 1e-8:
                executions += 1
                if trade_log is not None:
                    trade_log.append(execution_row(e, action, quantity, e.price,
                        e.ts, portfolio, state.copy_start))
        curve[boundary] = state.cash + position_value(state, prices, boundary - 1)
    return curve, executions, skipped


def copy_sleeve(events, prices, start, end, capital, config, liquidate=True, trade_log=None):
    # Independent historical scoring portfolio, starting from cash at lookback start.
    state = Sleeve(events[0].wallet if events else '', start, capital)
    curve, executions, skipped = run_sleeve(state, events, prices, start, end,
                                           capital, config, trade_log)
    if liquidate:
        executions += flatten(state, prices, end, trade_log, reason='TEST_END_CLOSE')
        curve[end] = state.cash
    return curve, executions, skipped


def backtest(accounts, candidates, prices, config):
    portfolios = {n: {'states': {}, 'reserve': config.initial_capital} for n in (1,)}
    curves = {n: [(config.start, config.initial_capital)] for n in portfolios}
    followed, copied = [], []
    rejections = collections.Counter()
    executions = collections.Counter()
    skipped = collections.Counter()
    selected_periods = collections.Counter()
    min_history, max_history = None, None
    log('Ranking historical Polymarket trade returns independently at each rebalance')
    for at in range(config.start, config.end, config.holding_days * DAY):
        end = min(at + config.holding_days * DAY, config.end)
        ranked = []
        incomplete = False
        for wallet in candidates.get(at, []):
            if wallet not in accounts:
                rejections['unavailable_polymarket_transactions'] += 1
                incomplete = True
                continue
            score, reason = account_score(accounts[wallet], prices, at, config)
            if score:
                ranked.append((wallet, score))
            else:
                rejections[reason] += 1
        ranked.sort(key=lambda item: (-item[1]['return_1y'], -item[1]['sharpe'], item[0]))
        for n, book in portfolios.items():
            name = f'top_{n}'
            chosen = ranked[:n]
            chosen_wallets = {wallet for wallet, _ in chosen}
            states = book['states']
            retained = set(states) & chosen_wallets
            base = book['reserve'] + sum(state.cash + position_value(state, prices, at - 1)
                                         for state in states.values())
            target = base / n
            for wallet in list(states):
                if wallet not in chosen_wallets:
                    state = states.pop(wallet)
                    executions[n] += flatten(state, prices, at, copied, name, 'ACCOUNT_REMOVED')
                    book['reserve'] += state.cash
            # Preserve all units for retained accounts. Redistribute only cash.
            for state in states.values():
                book['reserve'] += state.cash
                state.cash = 0.0
            for wallet in chosen_wallets - set(states):
                states[wallet] = Sleeve(wallet, at)
            needs = {wallet: max(0.0, target - position_value(states[wallet], prices, at - 1))
                     for wallet in chosen_wallets}
            total_need = sum(needs.values())
            factor = min(1.0, max(0.0, book['reserve']) / total_need) if total_need > 1e-8 else 0.0
            for wallet, need in needs.items():
                states[wallet].cash = need * factor
                book['reserve'] -= need * factor
            aggregate = {t: book['reserve'] for t in range(at + DAY, end + 1, DAY)}
            if chosen:
                selected_periods[n] += 1
            for rank in range(1, n + 1):
                row = {'portfolio': name, 'rebalance_utc': iso(at), 'holding_end_utc': iso(end),
                       'slot': rank, 'weight': 1 / n, 'wallet': '',
                       'qualified_accounts_in_period': len(ranked),
                       'status': 'CASH_UNVERIFIED_CANDIDATES' if incomplete else 'CASH_NO_ELIGIBLE_ACCOUNT',
                       'carried_positions': 0, 'copied_executions_in_period': 0,
                       'opening_positions': 0, 'opening_position_notional': 0.0}
                if rank <= len(chosen):
                    wallet, score = chosen[rank - 1]
                    state = states[wallet]
                    carried = sum(q > 1e-8 for q in state.holdings.values())
                    actual_value = state.cash + position_value(state, prices, at - 1)
                    row.update(wallet=wallet, status='CONTINUE' if wallet in retained else 'START',
                        copy_start_utc=iso(state.copy_start), carried_positions=carried,
                        actual_start_weight=actual_value / base if base > 0 else 0.0, **score)
                    count = score['sharpe_observations']
                    min_history = count if min_history is None else min(min_history, count)
                    max_history = count if max_history is None else max(max_history, count)
                    opening_count = 0
                    if config.copy_existing_positions and wallet not in retained:
                        opening_count, opening_notional = initialize_positions(
                            state, accounts[wallet], prices, at, copied, name)
                        executions[n] += opening_count
                        row.update(opening_positions=opening_count,
                                   opening_position_notional=opening_notional)
                    sleeve, trades, missed = run_sleeve(state, accounts[wallet], prices, at, end,
                                                        target, config, copied, name)
                    executions[n] += trades
                    skipped[n] += missed
                    row['copied_executions_in_period'] = trades + opening_count
                    for t, value in sleeve.items():
                        aggregate[t] += value
                followed.append(row)
            if end == config.end:
                for state in states.values():
                    executions[n] += flatten(state, prices, end, copied, name, 'TEST_END_CLOSE')
                aggregate[end] = book['reserve'] + sum(state.cash for state in states.values())
            curves[n].extend(sorted(aggregate.items()))
        log(f'{iso(at)[:10]}: {len(ranked)} eligible; ' + ', '.join(
            f'top {n} ${curves[n][-1][1]:,.2f}' for n in portfolios))
    summary = {}
    for n, curve in curves.items():
        returns = [b[1] / a[1] - 1 if a[1] else 0 for a, b in zip(curve, curve[1:])]
        peak = curve[0][1]
        drawdown = 0
        for _, value in curve:
            peak = max(peak, value)
            drawdown = min(drawdown, value / peak - 1 if peak else 0)
        sides = collections.Counter(row['side'] for row in copied if row['portfolio'] == f'top_{n}')
        summary[f'top_{n}'] = {'initial_capital': config.initial_capital, 'ending_equity': curve[-1][1],
            'total_return': curve[-1][1] / config.initial_capital - 1,
            'annualized_sharpe': annual_sharpe(returns), 'maximum_drawdown': drawdown,
            'executions_including_liquidations': executions[n], 'missed_signals': skipped[n],
            'periods_with_accounts': selected_periods[n], 'execution_types': dict(sides),
            'periods_carrying_positions': len({row['rebalance_utc'] for row in followed
                if row['portfolio'] == f'top_{n}' and row['carried_positions'] > 0})}
    return summary, curves, followed, dict(rejections), [min_history, max_history], copied


def save_report(output, manifest):
    if manifest['config'].get('copy_existing_positions'):
        copying = ('At each newly selected account, initialize its then-open macro/geopolitical '
            'positions from Polymarket trades and linked settlements strictly before selection. '
            'Omit markets whose recorded closure time is at or before selection. Invest available '
            'capital in proportion to position market values using the latest pre-selection marks; '
            'do not inherit historical entry costs or replicate source cash. Record these entries '
            'as OPENING_BUY. Thereafter copy new BUYs with the existing 10% ticket/cash cap and '
            'proportional SELLs including initialized holdings. Keep positions without reseeding '
            'when the same account remains selected; otherwise flatten and initialize the replacement. '
            'Close remaining positions at test end. Zero costs. Selection scoring remains the '
            'original standardized trade portfolio so the account ranking is unchanged.')
    else:
        copying = ('Copy only transactions from the selection date forward, at the recorded trade '
            'price with zero costs. New selections start with no copied positions. Keep positions '
            'when the same account remains selected; close them when it drops out. Close remaining '
            'positions at final test end. Top 1 allocates 100% to the selected account. Retained '
            'share quantities are preserved across consecutive selections.')
    lines = ['# Polymarket rolling copy results', '',
        f'UTC interval: {manifest["requested_start"]} to {manifest["requested_end_exclusive"]} (end exclusive).',
        f'Status: {manifest["status"]}.', '',
        f'Discovery: {manifest.get("observed_wallets", 0):,} accounts observed in '
        f'{manifest.get("discovery_market_count", 0)} matching markets with rolling trade discovery. '
        f'{manifest.get("candidate_wallets", 0)} accounts reached final evaluation.', '',
        '| Portfolio | Ending equity | Return | Sharpe | Max drawdown | Executions |',
        '|---|---:|---:|---:|---:|---:|']
    for name, row in manifest.get('portfolios', {}).items():
        sharpe = 'undefined' if row['annualized_sharpe'] is None else f'{row["annualized_sharpe"]:.3f}'
        lines.append(f'| {name} | ${row["ending_equity"]:,.2f} | {row["total_return"]:.2%} | '
            f'{sharpe} | {row["maximum_drawdown"]:.2%} | {row["executions_including_liquidations"]} |')
    lines += ['', manifest.get('interpretation', ''), '',
        'Every 10 days, filter the preceding 365 days of Polymarket trades: annualized daily '
        'Sharpe >3; average <100 trades per 10 observed days; >=80% macro/geopolitical notional; '
        'share-weighted FIFO median holding time 2-5 days. No minimum frequency or daily count cap. '
        'Trade-based style proxies: at least two completed FIFO lot matches, <=10% of closed shares '
        'held under one hour, <=20% of active token/hour buckets containing buys and sells, and '
        '<=20% of active market/hour buckets trading both outcomes.', '',
        'Rank by return of a standardized $10,000 portfolio replaying the preceding year of macro '
        'trades; break ties by Sharpe, then address. Each source BUY uses 10% of starting allocation, '
        'capped by available cash. SELLs proportionally reduce the shares bought since following began. '
        'Annual Sharpe = sqrt(365) * mean(daily returns) / sample standard deviation. '
        'Use available shorter history where necessary and record its length; two daily returns '
        'are the mathematical minimum. No wallet cash, transfers or external holdings enter this calculation.', '',
        copying, '',
        'Daily marks and account-removal closes use the last price known at that time, including '
        'recorded transactions and settlements. No price-age exclusion and no future backfill. '
        'Settlements are linked by market and outcome at their recorded timestamp. '
        'This is an idealized recorded-price simulation; carried-forward marks can be stale. '
        'Discovery includes new markets throughout the test; tag/title coverage and retrospective metadata remain limitations.', '',
        'Files: ' + manifest.get('source_transactions_file', 'polymarket_transactions.csv') +
        ' (source trade ledger), copied_trades.csv (executions), '
        'followed_accounts.csv (selections and carried positions), period_summary.csv, equity.csv.', '',
        'Aggregate rejection counts:', '', '```json', json.dumps({
            'preliminary': manifest.get('preliminary_rejection_counts'),
            'final': manifest.get('rejection_counts')}, indent=2), '```', '']
    (output / 'REPORT.md').write_text('\n'.join(lines), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    today = dt.datetime.now(UTC).replace(hour=0, minute=0, second=0, microsecond=0)
    parser.add_argument('--start', default=(today - dt.timedelta(days=365)).date().isoformat())
    parser.add_argument('--end', default=today.date().isoformat(), help='Exclusive UTC date')
    parser.add_argument('--output', default='results')
    parser.add_argument('--workers', type=int, default=6)
    parser.add_argument('--collect-only', action='store_true')
    parser.add_argument('--wallets', help='Optional file, one wallet per line (predefined research universe)')
    parser.add_argument('--minimum-sharpe-days', type=int, default=2)
    parser.add_argument('--copy-existing-positions', action='store_true',
                        help='Initialize newly selected accounts from their then-open macro positions')
    parser.add_argument('--reuse-collection-from',
                        help='Reuse the catalog and annual candidate windows from a completed results folder')
    args = parser.parse_args()
    config = Config(stamp(args.start), stamp(args.end), workers=args.workers,
                    minimum_sharpe_days=args.minimum_sharpe_days,
                    copy_existing_positions=args.copy_existing_positions)
    if config.start >= config.end or config.start % DAY or config.end % DAY:
        parser.error('start/end must be increasing UTC midnight dates')
    if config.workers < 1 or config.minimum_sharpe_days < 2:
        parser.error('Invalid collection/history settings')
    if args.wallets and args.reuse_collection_from:
        parser.error('Choose either supplied wallets or reuse of an existing collection')
    output = Path(args.output)
    if args.reuse_collection_from and Path(args.reuse_collection_from).resolve() == output.resolve():
        parser.error('Use a separate output folder when reusing a completed collection')
    output.mkdir(parents=True, exist_ok=True)
    api = API(Path(__file__).with_name('polymarket_data.sqlite'), config.workers)
    manifest = {'status': 'RUNNING', 'config': dataclasses.asdict(config),
                'requested_start': iso(config.start), 'requested_end_exclusive': iso(config.end)}
    (output / 'run_summary.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    try:
        if args.reuse_collection_from:
            previous = Path(args.reuse_collection_from)
            if previous.resolve() == output.resolve():
                raise DataError('Use a separate output folder when reusing a completed collection')
            prior = json.loads((previous / 'run_summary.json').read_text(encoding='utf-8'))
            if prior.get('status') not in ('COMPLETE', 'COMPLETE_WITH_DATA_GAPS'):
                raise DataError('The reused collection must have a completed backtest')
            for key, value in dataclasses.asdict(config).items():
                if key not in ('workers', 'copy_existing_positions') and prior['config'].get(key) != value:
                    raise DataError(f'Reused collection has a different {key} setting')
            saved = json.loads((previous / 'collection.json').read_text(encoding='utf-8'))
            markets, wallets, observed = saved['markets'], saved['wallets'], saved['observed_wallets']
            candidates = {int(at): group for at, group in saved['candidates'].items()}
            preliminary_rejections = prior.get('preliminary_rejection_counts', {})
            GEO_TITLES.clear()
            GEO_TITLES.update(m['question'] for m in markets
                if 100265 in m.get('discovery_tag_ids', []) and GEO_TOPICS.search(m['question']))
            in_scope.cache_clear()
            manifest['reused_collection_from'] = str(previous.resolve())
            log(f'Reusing completed discovery and annual screening: {len(wallets):,} accounts')
        elif args.wallets:
            wallets = sorted({w.strip().lower() for w in Path(args.wallets).read_text().splitlines()
                              if w.strip() and not w.startswith('#')})
            if any(not re.fullmatch(r'0x[0-9a-f]{40}', w) for w in wallets):
                raise DataError('Wallet file contains an invalid address')
            candidates = {at: wallets for at in range(config.start, config.end, config.holding_days * DAY)}
            markets, observed = catalog(api, config), len(wallets)
        else:
            markets, candidates, wallets, observed = discover(api, config)
        (output / 'rolling_market_catalog.json').write_text(json.dumps(markets), encoding='utf-8')
        if getattr(api, 'discovery_periods', None):
            write_csv(output / 'discovery_periods.csv', api.discovery_periods,
                ['rebalance_utc', 'observed_accounts', 'new_accounts_since_previous',
                 'markets_with_preceding_year_trades', 'macro_behavior_candidates'])
        if not args.reuse_collection_from:
            candidates, preliminary_rejections = screen_account_windows(api, candidates, config)
        wallets = sorted({w for group in candidates.values() for w in group})
        (output / 'collection.json').write_text(json.dumps({'markets': markets, 'candidates': candidates,
            'wallets': wallets, 'observed_wallets': observed}), encoding='utf-8')
        manifest.update(discovery_market_count=len(markets), observed_wallets=observed, candidate_wallets=len(wallets),
                        preliminary_rejection_counts=preliminary_rejections,
                        universe='supplied_wallets' if args.wallets else 'fixed_2025_then_rolling_all_matching_markets_2026')
        accounts, errors = collect_accounts(api, wallets, config)
        source_rows = ({'account': wallet, 'time_utc': iso(e.ts), 'market': e.title,
            'condition_id': e.condition, 'token_id': e.token, 'outcome': e.outcome,
            'side': e.side, 'price': e.price, 'size': e.size, 'notional': e.cash,
            'transaction_hash': e.tx} for wallet, events in sorted(accounts.items()) for e in events
            if e.kind == 'TRADE' and config.start - config.filter_days * DAY <= e.ts < config.end)
        if not args.reuse_collection_from:
            write_csv(output / 'polymarket_transactions.csv', source_rows,
                ['account', 'time_utc', 'market', 'condition_id', 'token_id', 'outcome',
                 'side', 'price', 'size', 'notional', 'transaction_hash'])
        else:
            manifest['source_transactions_file'] = str((previous / 'polymarket_transactions.csv').resolve())
        # Addresses identify Polymarket accounts; only trades and settlements are retained.
        manifest.update(complete_account_histories=len(accounts), failed_account_histories=len(errors))
        if args.collect_only:
            manifest['status'] = 'COLLECTED'
            return
        prices = collect_prices(api, accounts, config)
        # Historical closure timestamps prevent buying already-closed markets.
        # A market's current closed flag is never used for earlier rebalances.
        prices.closed_at = {m['conditionId']: stamp(m['closedTime']) for m in markets if m.get('closedTime')}
        (output / 'price_errors.json').write_text(json.dumps(prices.failures, indent=2), encoding='utf-8')
        summary, curves, followed, rejected, history, copied = backtest(accounts, candidates, prices, config)
        manifest.update(status='COMPLETE', portfolios=summary, rejection_counts=rejected,
                        selected_sharpe_history_days=history, failed_price_histories=len(prices.failures),
                        empty_price_histories=sum(not v[0] for v in prices.values.values()),
                        limitation='Rolling discovery across all matching catalog markets; title/tag coverage limits; standardized trade-portfolio Sharpe; same-price zero-cost copying; last-observed marks without an age cutoff; shorter available history can substitute for a year.')
        unverifiable = rejected.get('unavailable_polymarket_transactions', 0)
        if unverifiable or errors:
            manifest['status'] = 'COMPLETE_WITH_DATA_GAPS'
        traded = any(row['executions_including_liquidations'] for row in summary.values())
        manifest['interpretation'] = ('Conditional simulation on the documented candidate universe and execution assumptions.'
            if traded else 'No copied trades. The cash-only path is not evidence of strategy profitability or of no skilled traders existing.')
        if unverifiable:
            manifest['interpretation'] += ' Some accounts had unavailable Polymarket transaction responses.'
        columns = ['portfolio', 'rebalance_utc', 'holding_end_utc', 'slot', 'weight', 'wallet', 'status',
                   'qualified_accounts_in_period', 'copy_start_utc', 'actual_start_weight',
                   'carried_positions', 'copied_executions_in_period',
                   'opening_positions', 'opening_position_notional',
                   'return_1y', 'sharpe', 'sharpe_start', 'sharpe_observations', 'median_hold_days',
                   'filter_start_utc', 'filter_end_utc', 'filter_history_days',
                   'trades_in_filter_window', 'trades_per_10_days']
        write_csv(output / 'followed_accounts.csv', followed, columns)
        write_csv(output / 'copied_trades.csv', copied,
            ['portfolio', 'account', 'copy_start_utc', 'time_utc', 'market', 'condition_id',
             'token_id', 'outcome', 'side', 'price', 'size', 'notional', 'transaction_hash'])
        period_rows = [{'rebalance_utc': row['rebalance_utc'],
                        'annual_filter_start_utc': iso(stamp(row['rebalance_utc']) - config.filter_days * DAY),
                        'holding_end_utc': row['holding_end_utc'],
                        'qualified_accounts': row['qualified_accounts_in_period']}
                       for row in followed if row['portfolio'] == 'top_1']
        write_csv(output / 'period_summary.csv', period_rows,
                  ['rebalance_utc', 'annual_filter_start_utc', 'holding_end_utc', 'qualified_accounts'])
        write_csv(output / 'equity.csv', [{'portfolio': f'top_{n}', 'timestamp_utc': iso(t), 'equity': v}
                                        for n, curve in curves.items() for t, v in curve],
                  ['portfolio', 'timestamp_utc', 'equity'])
        save_report(output, manifest)
        print(json.dumps(summary, indent=2), flush=True)
    except (DataError, OSError, ValueError) as exc:
        manifest.update(status='FAILED', error=str(exc))
        log(f'FAILED: {exc}')
        return 1
    finally:
        manifest['completed_utc'] = iso(int(time.time()))
        manifest['uncached_http_requests'] = api.requests
        (output / 'run_summary.json').write_text(json.dumps(manifest, indent=2, allow_nan=False), encoding='utf-8')
    return 0


if __name__ == '__main__':
    sys.exit(main())
