"""Point-in-time macro account screening over the unfiltered trade universe."""
from __future__ import annotations

import bisect
import collections
import csv
import heapq
import itertools
import json
import sqlite3
import time
import zlib

import rolling_copy_backtest as b
from macro_universe_data import ROOT, OUT, BACKUP_START, TEST_START, TEST_END, dump


def candidate_dates(rows):
    """Only necessary user-requested activity/frequency tests; no lot shortcut."""
    return dates_from_daily(collections.Counter(r[1]//b.DAY for r in rows))


def dates_from_daily(daily):
    """Daily counts are exact sufficient inputs for UTC-midnight reset screens."""
    days=sorted(daily)
    if sum(BACKUP_START//b.DAY<=d<TEST_END//b.DAY for d in days)<30:
        return []
    cumulative=[0]
    for day in days:cumulative.append(cumulative[-1]+daily[day])
    valid = []
    for at in range(TEST_START,TEST_END,b.DAY):
        day = at//b.DAY
        right=bisect.bisect_left(days,day)
        active = right-bisect.bisect_left(days,day-40)
        if active < 30:
            continue
        count=cumulative[right]-cumulative[bisect.bisect_left(days,day-365)]
        observed=max(1,day-max(day-365,days[0]))
        if count/observed < 50:
            valid.append(at)
    return valid


def preselect():
    """Scan every wallet; retain source input only if eligibility is possible."""
    backfill=json.loads((OUT/'backfill_summary.json').read_text())
    if backfill['status']!='COMPLETE':
        raise b.DataError('Older market backfill is incomplete')
    files=[ROOT/'rolling_discovery.sqlite',OUT/'older_macro_trades.sqlite']
    if (OUT/'expanded_market_trades.sqlite').exists():
        status=json.loads((OUT/'expanded_collection_summary.json').read_text())
        if status['status'] not in ('COMPLETE','CAPPED','STOPPED_BY_USER'):raise b.DataError('Expanded market collection is incomplete')
        files.append(OUT/'expanded_market_trades.sqlite')
    connections = [sqlite3.connect(f'file:{path.as_posix()}?mode=ro',uri=True) for path in files]
    for db in connections:
        db.execute('PRAGMA cache_size=-32768')
    # Activity/frequency need only identity and time. Avoid decoding every price,
    # title and token in the million-account universe before these checks pass.
    streams=[db.execute('SELECT wallet,ts FROM trades ORDER BY wallet,ts') for db in connections]
    merged=heapq.merge(*streams,key=lambda r:(r[0],r[1]))
    output=sqlite3.connect(OUT/'candidate_inputs.sqlite')
    output.execute('PRAGMA journal_mode=WAL')
    output.execute('PRAGMA synchronous=NORMAL')
    output.execute('CREATE TABLE IF NOT EXISTS candidates(wallet TEXT PRIMARY KEY,body BLOB) WITHOUT ROWID')
    output.execute('DELETE FROM candidates')
    output.commit()
    total=kept=trades=windows=0
    counts_by_date=collections.Counter()
    last=time.monotonic()
    with (OUT/'all_account_activity_screen.csv').open('w',newline='',encoding='utf-8') as f, \
         (OUT/'priority_accounts.txt').open('w',encoding='utf-8',buffering=1) as priority:
        writer=csv.writer(f)
        writer.writerow(['wallet','macro_trades','active_days_in_two_years','candidate_reset_dates',
                         'screen_status'])
        for wallet,group in itertools.groupby(merged,key=lambda r:r[0]):
            # Do not materialize millions of full per-trade tuples for a busy
            # wallet before the cheap checks. A few calendar-day counters suffice.
            daily=collections.Counter(ts//b.DAY for _,ts in group)
            period_days=[d for d in daily if BACKUP_START//b.DAY<=d<TEST_END//b.DAY]
            count=sum(daily[d] for d in period_days)
            total+=1
            trades+=count
            dates=dates_from_daily(daily)
            active=len(period_days)
            writer.writerow([wallet,count,active,len(dates),
                'NEEDS_PERFORMANCE_AND_STYLE_SCREEN' if dates else 'NO_DATE_PASSES_30_OF_40_AND_AVERAGE_BELOW_50'])
            if dates:
                required_end=min(TEST_END,max(dates)+75*b.DAY)
                complete_rows=[]
                for connection in connections:
                    complete_rows.extend(connection.execute('SELECT * FROM trades WHERE wallet=? AND ts<? ORDER BY ts',
                        (wallet,required_end)))
                complete_rows.sort(key=lambda r:(r[1],r[2],r[3],r[4]))
                payload=json.dumps(dict(wallet=wallet,rows=complete_rows,dates=dates),separators=(',',':')).encode()
                output.execute('INSERT OR REPLACE INTO candidates VALUES(?,?)',(wallet,zlib.compress(payload,3)))
                priority.write(wallet+'\n')
                kept+=1
                windows+=len(dates)
                counts_by_date.update(dates)
            if time.monotonic()-last>=15:
                output.commit()
                f.flush()
                status=dict(status='SCANNING',accounts_examined=total,macro_trade_decisions=trades,
                            accounts_passing_activity_and_frequency_at_any_reset=kept,
                            qualifying_account_dates=windows)
                dump('activity_screen_progress.json',status)
                b.log(json.dumps(status))
                last=time.monotonic()
    output.commit()
    output.close()
    for db in connections:db.close()
    result=dict(status='COMPLETE',accounts_examined=total,macro_trade_decisions=trades,
                accounts_passing_activity_and_frequency_at_any_reset=kept,qualifying_account_dates=windows,
                policy='30 active macro trading days in previous 40; average fewer than 50 macro trades/calendar day in available preceding year.')
    dump('activity_screen_summary.json',result)
    with (OUT/'reset_activity_counts.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['reset_utc','accounts_passing_activity_and_frequency'])
        writer.writerows((b.iso(at),counts_by_date[at]) for at in range(TEST_START,TEST_END,b.DAY))
    b.log(json.dumps(result))


if __name__=='__main__':
    preselect()
