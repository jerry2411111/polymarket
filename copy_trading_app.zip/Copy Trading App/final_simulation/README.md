# Copy Trading App — Final Simulation

Complete [data preparation](../data_retrieval/README.md) first. The model source is
assembled beside its collector dependencies under `data_storage/runtime`.
`macro_account_model.py` reconstructs source books and return moments;
`screen_macro_performance.py` calculates metrics at eligible historical resets;
`run_active_macro_study.py` runs the final parameter grid. `rolling_copy_backtest.py`
is a required shared API/event/price utility dependency; its older standalone
top-account CLI is not the final workflow described here.

## Return model and point-in-time screening

At a UTC daily boundary, known source trades and inventory actions determine
holdings. Prior positively priced macro-position quantities remain fixed while
their next-day price change is measured. Relative marked values weight the book
return; today's observed position changes set the following day's weights.
Absolute changes in book size do not produce returns. Cash assignment is not
inferred, and source returns are conditional on having a priced, invested macro
book. Unknown positions are omitted until observed prices become available.

Historical price buckets become available at their timestamp plus reported
resolution; observed earlier trade prices can extend coverage. Resolved payouts
enter only when historically available. Missing opening inventory requires
reconciliation. Available preceding history is capped at 365 calendar days;
the model does not require exactly 365 return observations.

For the available invested daily returns `r`, let `n` be their actual count,
`mu` their mean, `sd` their sample standard deviation, and `s = mu / sd`:

```text
Raw Sharpe S = sqrt(365) * s
gamma3 = mean((r - mu)^3) / mean((r - mu)^2)^(3/2)
gamma4 = mean((r - mu)^4) / mean((r - mu)^2)^2     # Pearson, not excess
SE(S) = sqrt(365 * [1 - gamma3*s + (gamma4 - 1)*s^2/4] / (n - 1))
Effective Sharpe = S - 1.6448536269514722 * SE(S)
```

The 365 factor annualizes daily units; it is not the sample size. Moments require
at least two finite observations and nonzero variance. Materially invalid
variance estimates do not qualify. No risk-free-rate deduction is implemented.
The Effective Sharpe adjustment is the implemented approximate one-sided 95%
lower-bound calculation; it is not a guarantee against serial dependence or
selection bias.

For each reset, apply the activity/frequency and fast-trading rules in the
[main README](../README.md), then the selected Raw/Effective filter. All qualifying
accounts with usable positive lagged volatility receive weights:

```text
w_i = (1 / sigma_i) / sum_j(1 / sigma_j)
```

Volatility uses the same available active-book daily returns but excludes the
return ending at the reset (`shift(1)` behavior). The short windows are calendar
windows; absent invested observations are not filled with invented returns.
There is no P&L scoring/ranking, top-N, exposure-ratio weighting, holding-time band,
macro concentration requirement or minimum selected-account quota in this final
study. FIFO closed-share durations are used only for the retained under-one-hour
style check; the other checks group activity by token/hour and market/hour.

## Final parameter grid

| Study | Account filter | Reselection | Allocation-volatility window | Cases |
| --- | --- | --- | --- | ---: |
| Allocation | Raw ranges `(1.5,2]`, `(2,3]`, `(3,4]`, `(4,5]`; cutoffs `>1.5, >2, >3, >4, >5` | 5, 10, 15, 20, 30 days | 15, 30, 45, 60, 75 days | 225 |
| Daily | Raw and Effective cutoffs `>1.5, >2, >3, >4, >5, >6` | 1 day | Available preceding history, max 365 days | 12 |
| Effective | Ranges `(1.5,2]` through `(5,6]`; cutoffs `>1.5` through `>6` at the listed thresholds | 15, 30, 45, 60, 75 days | Available preceding history, max 365 days | 55 |

Total: **292 cases**. Range lower bounds are strict and upper bounds inclusive.
Cutoffs are strict. Default app case: `effective_effective_range_3_4_reset75_vol365`.
The final historical interval ends at the fixed exclusive test-end date even
when it is shorter than the normal reset period.

Every case starts with $10,000. At resets, current NAV is split by the inverse
volatility weights. Between resets, each selected slice compounds its modeled
daily macro-book return; a day without an invested book leaves that slice
unchanged as cash. No selected accounts means all cash. The research applies
zero fees, spread, slippage or financing deductions. It does not replay individual
intraday limit orders or test whether they would fill. The app's immediate sandbox
midpoint fills and real minute-refreshed limit execution are different mechanisms.

## Generate results and reports

After all required candidate calculations are complete and data issues resolved:

```powershell
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py simulate
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py reports --performance sharpe
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py reports --performance return
& .\.venv\Scripts\python.exe prepare_project.py --check-ready
```

The run writes `strategy_results.json` and per-case daily NAV, selection and period
files under `data_storage/runtime/results_all_accounts_macro`. PDFs are written
under that directory's `reports/` and `reports_returns/`. Report generation uses
Windows Arial fonts and the prepared coverage summaries. The runner rejects
unfinished/unresolved inputs by default; preview flags are not a substitute for
final data preparation.

Optional individual-account analyses use `backtest_individual_accounts.py` and
`prepare_account_lifetimes.py` from the generated runtime, after the final research
inputs exist. Run their `--help` where supported and inspect their output paths.
They are not prerequisites for core portfolio execution; account lifetime views
display the available separately prepared history.

## Verification

Syntax and synthetic ledger tests can run without market histories. Full screening,
292-case replay, PDF generation and app startup require the prepared datasets.
Numerical comparison with original research needs the same observed inputs and
coverage; a current API download can legitimately differ. Read
[Result notes](RESULTS.md) and [Validation](../VALIDATION.md) before interpreting
historical performance as executable performance.
