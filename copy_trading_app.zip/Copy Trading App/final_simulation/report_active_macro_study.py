"""Reproduce the three requested PDFs from the active macro-book study."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'.report_deps'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,white
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

from macro_universe_data import OUT,load_markets

WIDTH,HEIGHT=612,792
LEFT=40
INK=HexColor('#142636');BLUE=HexColor('#1d5b79');PALE=HexColor('#eef4f7');GREY=HexColor('#546474')
FONT='Arial';BOLD='ArialBold'
pdfmetrics.registerFont(TTFont(FONT,'C:/Windows/Fonts/arial.ttf'))
pdfmetrics.registerFont(TTFont(BOLD,'C:/Windows/Fonts/arialbd.ttf'))
STYLE=ParagraphStyle('body',fontName=FONT,fontSize=9.2,leading=13,textColor=INK)
SMALL=ParagraphStyle('small',parent=STYLE,fontSize=8,leading=11)


def paragraph(c,text,y,small=False):
    p=Paragraph(text,SMALL if small else STYLE)
    _,height=p.wrap(WIDTH-2*LEFT,HEIGHT)
    p.drawOn(c,LEFT,y-height)
    return y-height-10


def title(c,name,subtitle,page,total):
    c.setFillColor(BLUE);c.rect(0,HEIGHT-31,WIDTH,31,fill=1,stroke=0)
    c.setFont(BOLD,8);c.setFillColor(white)
    c.drawString(LEFT,HEIGHT-20,'POLYMARKET | ACTIVE MACRO/GEO BOOK | ALL QUALIFYING ACCOUNTS | NO RANKING')
    c.setFillColor(INK);c.setFont(BOLD,21);c.drawString(LEFT,HEIGHT-67,name)
    y=paragraph(c,subtitle,HEIGHT-83,True)
    c.setFont(FONT,8);c.setFillColor(GREY);c.drawRightString(WIDTH-LEFT,20,f'{page} / {total}')
    return y-6


def heading(c,text,y):
    c.setFont(BOLD,12);c.setFillColor(BLUE);c.drawString(LEFT,y-12,text)
    return y-23


def table(c,rows,y,widths=None,size=9):
    if widths is None:widths=[(WIDTH-2*LEFT)/len(rows[0])]*len(rows[0])
    t=Table(rows,colWidths=widths,hAlign='LEFT')
    t.setStyle(TableStyle([
        ('FONTNAME',(0,0),(-1,-1),FONT),('FONTNAME',(0,0),(-1,0),BOLD),
        ('FONTSIZE',(0,0),(-1,-1),size),('LEADING',(0,0),(-1,-1),size+3),
        ('TEXTCOLOR',(0,0),(-1,0),white),('BACKGROUND',(0,0),(-1,0),BLUE),
        ('TEXTCOLOR',(0,1),(-1,-1),INK),('ROWBACKGROUNDS',(0,1),(-1,-1),[white,PALE]),
        ('ALIGN',(1,0),(-1,-1),'CENTER'),('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),
        ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
        ('LINEBELOW',(0,-1),(-1,-1),.5,HexColor('#d2dce2'))]))
    _,height=t.wrap(WIDTH-2*LEFT,HEIGHT);t.drawOn(c,LEFT,y-height)
    return y-height-17


def value(x,performance='sharpe'):
    if x is None:return 'N/A'
    return f'{x*100:+,.2f}%' if performance=='return' else f'{x:.3f}'


def result_key(performance):return 'total_return' if performance=='return' else 'strategy_sharpe'
def result_label(performance):return 'strategy return (%)' if performance=='return' else 'strategy Sharpe'
def report_path(directory,stem,performance):
    return directory/(stem+('_Returns' if performance=='return' else '')+'.pdf')
def label(lower,upper):return f'>{lower:g}' if upper is None else f'({lower:g}, {upper:g}]'


def lookup(cases,report,metric,lower,upper,reset,vol):
    return next(r for r in cases if r['report']==report and r['screen_metric']==metric and
        r['lower']==lower and r['upper']==upper and r['reset_days']==reset and r['volatility_days']==vol)


def grid(c,cases,report,metric,filters,resets,vol,y,performance='sharpe'):
    rows=[['Sharpe filter']+[f'{n} days' for n in resets]]
    for lower,upper in filters:
        rows.append([label(lower,upper)]+[value(lookup(cases,report,metric,lower,upper,n,vol)[result_key(performance)],performance) for n in resets])
    return table(c,rows,y,[122]+[82]*5)


INTERPRETATION=("Returns measure the historically priced active macro/geopolitical book, not the whole account. "
    "Use only observed prices available at each timestamp; settlement payouts enter after recorded resolution. "
    "Unquoted positions are omitted until priced. Changes in book size and first-quote appearances are not returns.")
RULES=('At each reset use only the preceding available history, capped at 365 calendar days. Require at least 30 active '
    'macro/geo trading days in the preceding 40 days and fewer than 50 macro/geo trades per calendar day on average. '
    'Allow at most 10% of closed shares held under one hour, 20% two-sided token/hour groups and 20% both-outcome '
    'market/hour groups. No participation-rate, median-holding-time, completed-market or P&amp;L-ranking filter applies.')
WEIGHTS=('All accounts that pass the selected Sharpe filter and the activity/style rules receive inverse-volatility weights; '
    'there is no ranking or top-N limit. Volatility uses the same macro-book daily return series, with a one-day lag. '
    'Its sample standard deviation must be positive and computable. Account weights reset on the scheduled dates and '
    'then drift with their book returns until the next reset.')
MOMENTS=('Let s = mean(r) / SD<sub>sample</sub>(r). Raw Sharpe S = √365 × s. '
    'Effective Sharpe S<sub>eff</sub> = S − 1.644853627 × SE(S), where '
    'SE(S) = √{365 × [1 − γ<sub>3</sub>s + (γ<sub>4</sub> − 1)s²/4] / (n − 1)}. '
    'n is the actual number of available invested daily return observations. γ<sub>3</sub> is skewness and '
    'γ<sub>4</sub> is Pearson kurtosis; both use central moments with divisor n. The 365 factor annualizes daily units; '
    'it does not replace n or assume a full year of observations.')
STRATEGY=('Every result cell is ordinary annualized strategy Sharpe: √365 × mean(R) / SD<sub>sample</sub>(R), '
    'including all test calendar days and days in cash. N/A means that strategy Sharpe is undefined, such as an all-cash run. '
    'No fees, slippage, funding gains or other cost deductions are applied.')
RETURN_STRATEGY=('Every result cell shows total compounded strategy return over the test period, expressed as a '
    'percentage of starting equity. Cash days are included; an all-cash run returns 0%. '
    'No fees, slippage, funding gains or other cost deductions are applied.')


def strategy_note(performance):return RETURN_STRATEGY if performance=='return' else STRATEGY


DATES='14 September 2025 – 14 September 2026 | Prior-year backup from 14 September 2024 | Zero costs'


def collection_note():
    path=OUT/'expanded_collection_summary.json'
    if not path.exists():return 'Expanded collection has not finished; these are not final expanded-universe results.'
    source=json.loads(path.read_text())
    count=source.get('total_unique_accounts')
    label=f'{count:,}' if count is not None else 'Recorded'
    text=f'Discovery: {label} distinct accounts across completed and expanded downloads, with duplicate wallets counted once. '
    if source['status'] in ('CAPPED','STOPPED_BY_USER'):
        reason=('Collection stopped at the requested unique-account limit. ' if source['status']=='CAPPED'
            else 'Discovery stopped on user instruction; screening uses the accounts collected by that point. ')
        text+=(reason+
            f'{source["completed_markets"]:,} additional market feeds completed; '
            f'{len(source.get("partial_market_feeds",[])):,} partial and '
            f'{source.get("untouched_market_feeds",0):,} unvisited. ')
    else:
        text+=f'All {source["total_new_markets"]:,} additional catalog-market feeds were visited. '
    return text+'Screening and returns use the observed history available in this collection.'


def allocation(cases,directory,performance='sharpe'):
    path=report_path(directory,'Polymarket_Allocation_rawsharpe',performance)
    c=canvas.Canvas(str(path),pagesize=(WIDTH,HEIGHT));c.setTitle('Polymarket | Raw Sharpe | '+result_label(performance))
    y=title(c,'Macro-book returns and allocation',DATES,1,6)
    y=paragraph(c,INTERPRETATION,y)
    y=heading(c,'Observed position values → next-day returns',y)
    y=paragraph(c,'v<sub>k,t</sub> = q<sub>k,t</sub>p<sub>k,t</sub>; '
        'a<sub>k,t</sub> = v<sub>k,t</sub> / Σ<sub>j</sub>v<sub>j,t</sub><br/>'
        'r<sub>book,t+1</sub> = Σ<sub>k</sub>a<sub>k,t</sub>(p<sub>k,t+1</sub>/p<sub>k,t</sub> − 1)',y)
    y=table(c,[['Closing book','Next price returns','Book return'],
        ['Iran $20,000; Fed $5,000','+10%; −10%','6%'],
        ['Iran $40,000; Fed $10,000','+5%; −5%','3%'],
        ['Iran $10,000; Fed $10,000','+5%; −5%','0%']],y,[250,172,110])
    y=paragraph(c,'Each row uses its closing allocation for the following day. Changing absolute dollars does not enter '
        'the return calculation. Source trades update the next day’s relative macro weights.',y,True)
    y=heading(c,'Inverse-volatility allocation across accounts',y)
    y=paragraph(c,'w<sub>i</sub> = (1 / σ<sub>i</sub>) / Σ<sub>j</sub>(1 / σ<sub>j</sub>)',y)
    y=table(c,[['Account','Daily macro-book volatility','Allocation'],['A','3%','25%'],['B','1%','75%']],y,[160,250,122])
    y=paragraph(c,'Inverse-volatility ratio 1 : 3 gives A 25% and B 75%. Volatility lookbacks of 15, 30, 45, 60 and '
        '75 calendar days are tested separately from reset intervals of 5, 10, 15, 20 and 30 days. Use available invested '
        'observations inside the chosen window, excluding the return ending at the reset.',y,True)
    y=paragraph(c,WEIGHTS,y,True)
    y=paragraph(c,RULES,y,True)
    if y<35:raise RuntimeError('Allocation formula page overflow')
    c.showPage()
    for page,vol in enumerate((15,30,45,60,75),2):
        y=title(c,f'Volatility lookback: {vol} days',DATES,page,6)
        y=paragraph(c,f'45 combinations on this page. Account screening uses available preceding history capped at 365 days; '
            f'{vol} days controls the lagged volatility weight input. Column headings specify account/weight reset intervals.',y)
        y=heading(c,'Raw Sharpe ranges — resulting '+result_label(performance),y)
        y=grid(c,cases,'allocation','raw',[(1.5,2),(2,3),(3,4),(4,5)],(5,10,15,20,30),vol,y,performance)
        y=heading(c,'Raw Sharpe greater than — resulting '+result_label(performance),y)
        y=grid(c,cases,'allocation','raw',[(x,None) for x in (1.5,2,3,4,5)],(5,10,15,20,30),vol,y,performance)
        y=paragraph(c,strategy_note(performance),y,True)
        y=paragraph(c,'Ranges mean lower &lt; S ≤ upper; cutoffs mean S &gt; threshold. Days without priced exposure are excluded from '
            'account return moments. A selected account’s strategy allocation earns zero on days its priced book is empty.',y,True)
        y=paragraph(c,RULES,y,True)
        y=paragraph(c,collection_note(),y,True)
        c.showPage()
    c.save();return path


def daily(cases,directory,performance='sharpe'):
    path=report_path(directory,'Polymarket_Daily_updated',performance)
    c=canvas.Canvas(str(path),pagesize=(WIDTH,HEIGHT));c.setTitle('Polymarket | Daily Raw and Effective | '+result_label(performance))
    y=title(c,'Daily selection | '+('Return' if performance=='return' else 'Sharpe')+' comparison',DATES,1,3)
    y=paragraph(c,'12 cases: Raw or Effective Sharpe × thresholds 1.5, 2, 3, 4, 5 and 6. Reselect all qualifying accounts '
        'and recalculate inverse-volatility weights daily. Selection and volatility use the available preceding history, '
        'capped at 365 calendar days; one day is the reset frequency.',y)
    y=paragraph(c,INTERPRETATION,y)
    y=heading(c,'Raw and Effective Sharpe formulas',y)
    y=paragraph(c,MOMENTS,y)
    y=paragraph(c,'γ<sub>3</sub> = mean[(r − mean(r))³] / mean[(r − mean(r))²]<super>3/2</super><br/>'
        'γ<sub>4</sub> = mean[(r − mean(r))⁴] / mean[(r − mean(r))²]²<br/>'
        'Effective Sharpe’s deduction accounts for statistical uncertainty only.',y,True)
    y=heading(c,'Resulting '+result_label(performance),y)
    thresholds=(1.5,2,3,4,5,6)
    rows=[['Selection']+[f'>{x:g}' for x in thresholds]]
    for metric in ('raw','effective'):
        rows.append([metric.title()]+[value(lookup(cases,'daily',metric,x,None,1,365)[result_key(performance)],performance) for x in thresholds])
    y=table(c,rows,y,[112]+[70]*6)
    y=paragraph(c,strategy_note(performance),y,True)
    y=paragraph(c,WEIGHTS,y,True)
    y=paragraph(c,RULES,y,True)
    if y<35:raise RuntimeError('Daily formulas page overflow')
    c.showPage()
    y=title(c,'Threshold versus '+result_label(performance),DATES,2,3)
    fig,ax=plt.subplots(figsize=(8.1,5.3))
    for metric,color in [('raw','#1d5b79'),('effective','#cc7645')]:
        values=[lookup(cases,'daily',metric,x,None,1,365)[result_key(performance)] for x in thresholds]
        ax.plot(thresholds,[float('nan') if x is None else x for x in values],marker='o',lw=2.3,label=metric.title()+' Sharpe filter',color=color)
    ax.axhline(0,color='#83919d',lw=.8);ax.set_xticks(thresholds)
    ax.set_xlabel('Account Sharpe threshold (strictly greater than)');ax.set_ylabel('Resulting '+result_label(performance))
    if performance=='return':ax.yaxis.set_major_formatter(PercentFormatter(xmax=1))
    ax.grid(alpha=.2);ax.legend(frameon=False);fig.tight_layout()
    plot=directory/f'daily_threshold_strategy_{performance}.png';fig.savefig(plot,dpi=170);plt.close(fig)
    c.drawImage(str(plot),LEFT,y-360,width=WIDTH-2*LEFT,height=350,mask='auto')
    y-=380
    comparison=('total compounded strategy return (%)' if performance=='return' else 'ordinary strategy Sharpe')
    y=paragraph(c,'The y-axis uses the same '+comparison+' for both screening methods. Only the account-level '
        'screen changes between Raw and Effective Sharpe. Every passing account receives capital; there is no rank.',y)
    y=paragraph(c,INTERPRETATION,y)
    c.showPage()
    y=title(c,'Selection and available history',DATES,3,3)
    rows=[['Selection','Threshold','Unique\naccounts','Days selected\n/ 365','History observations\nmin / median / max']]
    for metric in ('raw','effective'):
        for x in thresholds:
            r=lookup(cases,'daily',metric,x,None,1,365)
            obs=[r['history_observations_min'],r['history_observations_median'],r['history_observations_max']]
            history=' / '.join('—' if v is None else f'{v:g}' for v in obs)
            rows.append([metric.title(),f'>{x:g}',str(r['unique_accounts']),str(r['days_with_selected_accounts']),history])
    y=table(c,rows,y,[76,62,80,110,204],8.5)
    y=paragraph(c,'History observations counts valid invested macro-book daily returns used at selection dates, not trades '
        'or the number of calendar days on which a trade occurred. The separate activity gate requires 30 trading days in '
        'the preceding 40. Days selected counts strategy dates with at least one assigned account.',y)
    inventory=json.loads((OUT/'activity_screen_summary.json').read_text())
    y=paragraph(c,f'Universe: {inventory["accounts_examined"]:,} observed accounts; expanded catalog: {len(load_markets()):,} markets. '
        f'{inventory["accounts_passing_activity_and_frequency_at_any_reset"]:,} accounts could pass the activity/frequency '
        'rules at one or more historical resets and therefore required the performance/style calculations.',y)
    y=paragraph(c,collection_note(),y,True)
    c.showPage();c.save();return path


def effective(cases,directory,performance='sharpe'):
    path=report_path(directory,'Polymarket_Effective',performance)
    c=canvas.Canvas(str(path),pagesize=(WIDTH,HEIGHT));c.setTitle('Polymarket | Effective Sharpe | '+result_label(performance))
    y=title(c,'Effective Sharpe | Reset periods',DATES,1,1)
    y=paragraph(c,'55 cases: five reset periods × (five Effective Sharpe ranges + six greater-than cutoffs). '
        'All qualifying accounts receive inverse-volatility allocations; there is no ranking.',y)
    y=paragraph(c,MOMENTS,y,True)
    y=heading(c,'Inverse-volatility allocation — resulting '+result_label(performance),y)
    filters=[(1.5,2),(2,3),(3,4),(4,5),(5,6)]+[(x,None) for x in (1.5,2,3,4,5,6)]
    y=grid(c,cases,'effective','effective',filters,(15,30,45,60,75),365,y,performance)
    y=paragraph(c,'Ranges mean lower &lt; S<sub>eff</sub> ≤ upper; cutoffs mean S<sub>eff</sub> &gt; threshold. '
        'Columns specify reset intervals. Both screening and volatility use available history within the preceding '
        '365 calendar days; volatility excludes the return ending at the reset. The final interval ends at the fixed test end.',y,True)
    y=paragraph(c,strategy_note(performance),y,True)
    y=paragraph(c,RULES,y,True)
    y=paragraph(c,INTERPRETATION,y,True)
    y=paragraph(c,collection_note(),y,True)
    if y<35:raise RuntimeError(f'Effective page overflow: {y}')
    c.showPage();c.save();return path


def main(performance='sharpe'):
    result=json.loads((OUT/'strategy_results.json').read_text())
    if result['status']!='COMPLETE':raise RuntimeError('Final strategy results are not complete')
    directory=OUT/('reports_returns' if performance=='return' else 'reports');directory.mkdir(exist_ok=True)
    paths=[allocation(result['cases'],directory,performance),daily(result['cases'],directory,performance),effective(result['cases'],directory,performance)]
    for path in paths:print(path)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--performance',choices=('sharpe','return'),default='sharpe')
    main(parser.parse_args().performance)
