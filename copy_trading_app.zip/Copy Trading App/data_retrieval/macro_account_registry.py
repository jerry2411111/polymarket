"""Persistent, exact wallet counting shared by resumed market collection runs."""
from __future__ import annotations

import csv
import json
import sqlite3
import time

import rolling_copy_backtest as b
from macro_universe_data import OUT, dump


class AccountRegistry:
    def __init__(self, db):
        self.db = db
        db.execute('''CREATE TABLE IF NOT EXISTS discovery_accounts(
            wallet TEXT PRIMARY KEY, baseline INTEGER NOT NULL,
            expanded INTEGER NOT NULL) WITHOUT ROWID''')
        db.execute('CREATE TABLE IF NOT EXISTS discovery_account_meta(key TEXT PRIMARY KEY,value TEXT)')
        db.commit()
        ready = db.execute("SELECT value FROM discovery_account_meta WHERE key='ready'").fetchone()
        if not ready:
            self.bootstrap()
        self.known = dict(db.execute('SELECT wallet,expanded FROM discovery_accounts'))
        self.baseline, self.expanded = db.execute(
            'SELECT COALESCE(sum(baseline),0),COALESCE(sum(expanded),0) FROM discovery_accounts'
        ).fetchone()

    def bootstrap(self):
        # This one-time migration indexes the already collected wallets. Subsequent
        # runs reuse it, and new entries commit atomically with their trade pages.
        self.db.execute('DELETE FROM discovery_accounts')
        self.db.commit()
        frozen = OUT / 'previous_9411_market_universe/all_account_activity_screen.csv'
        baseline_file = frozen if frozen.exists() else OUT / 'all_account_activity_screen.csv'
        if not baseline_file.exists():
            raise RuntimeError('The completed-collection wallet list is missing')
        baseline_count = 0
        batch = []
        with baseline_file.open(newline='', encoding='utf-8-sig') as handle:
            for row in csv.DictReader(handle):
                batch.append((row['wallet'].lower(),))
                if len(batch) >= 20000:
                    self.db.executemany('INSERT OR IGNORE INTO discovery_accounts VALUES(?,1,0)', batch)
                    self.db.commit(); baseline_count += len(batch); batch.clear()
        if batch:
            self.db.executemany('INSERT OR IGNORE INTO discovery_accounts VALUES(?,1,0)', batch)
            self.db.commit(); baseline_count += len(batch)
        b.log(f'Indexed {baseline_count:,} previously completed accounts; merging expanded accounts')
        # Skip directly between wallet keys in the trade primary index. This avoids
        # reading every trade belonging to an already encountered wallet.
        reader = sqlite3.connect(f'file:{(OUT / "expanded_market_trades.sqlite").as_posix()}?mode=ro', uri=True)
        wallet_rows = reader.execute('''WITH RECURSIVE accounts(wallet) AS (
            SELECT min(wallet) FROM trades
            UNION ALL
            SELECT (SELECT min(wallet) FROM trades WHERE wallet>accounts.wallet)
            FROM accounts WHERE wallet IS NOT NULL
        ) SELECT wallet FROM accounts WHERE wallet IS NOT NULL''')
        statement = '''INSERT INTO discovery_accounts VALUES(?,0,1)
            ON CONFLICT(wallet) DO UPDATE SET expanded=1'''
        batch = []
        expanded_count = 0
        last = time.monotonic()
        for wallet, in wallet_rows:
            batch.append((wallet.lower(),))
            if len(batch) < 20000:
                continue
            self.db.executemany(statement, batch)
            self.db.commit(); expanded_count += len(batch); batch.clear()
            if time.monotonic() - last >= 15:
                total = self.db.execute('SELECT count(*) FROM discovery_accounts').fetchone()[0]
                progress = dict(status='INDEXING_EXISTING_ACCOUNTS', total_unique_accounts=total,
                    account_limit=3000000, count_is_partial=True)
                dump('expanded_collection_progress.json', progress)
                b.log(json.dumps(progress)); last = time.monotonic()
        if batch:
            self.db.executemany(statement, batch)
        reader.close()
        self.db.execute("INSERT OR REPLACE INTO discovery_account_meta VALUES('ready','1')")
        self.db.commit()

    def trim_at_limit(self, rows, limit):
        """Keep a feed prefix ending exactly when the final new wallet is found."""
        if limit is None:
            return rows
        remaining = limit - len(self.known)
        if remaining <= 0:
            return []
        new = set()
        for i, row in enumerate(rows):
            wallet = row[0]
            if wallet not in self.known:
                new.add(wallet)
                if len(new) >= remaining:
                    return rows[:i + 1]
        return rows

    def stage(self, rows):
        """Called inside the same transaction as the corresponding trade insert."""
        wallets = {row[0] for row in rows if not self.known.get(row[0],0)}
        self.db.executemany('''INSERT INTO discovery_accounts VALUES(?,0,1)
            ON CONFLICT(wallet) DO UPDATE SET expanded=1 WHERE expanded=0''',
            ((wallet,) for wallet in wallets))
        return wallets

    def committed(self, new_wallets):
        self.expanded += len(new_wallets)
        self.known.update((wallet,1) for wallet in new_wallets)

    def snapshot(self, status, limit):
        # Both counts are maintained incrementally, without rescanning histories.
        expanded = self.expanded
        return dict(status=status, total_unique_accounts=len(self.known),
            baseline_accounts=self.baseline, accounts_in_expanded_downloads=expanded,
            new_accounts_not_in_baseline=len(self.known)-self.baseline,
            account_limit=limit, stop_metric='unique_accounts',
            counted_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
