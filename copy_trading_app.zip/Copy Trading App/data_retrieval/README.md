# Copy Trading App — Data Retrieval

Run commands from the project root using the installed virtual environment.
First complete installation and runtime assembly in the [main README](../README.md).
The source collectors are deployed unchanged under `data_storage/runtime`, where
their original relative imports, SQLite locations and result paths work together.

## Prepare a fresh research history

The retained final research defines backup history from **14 September 2024**,
simulation start **14 September 2025**, and exclusive end **14 September 2026** in
`macro_universe_data.py`. The fresh setup preserves these dates. Older observations
may be downloaded to reconstruct opening positions; selection moments remain
limited to the preceding available year.

Execute these stages sequentially, checking each stage's completion output:

```powershell
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py init
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py catalog --workers 8
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py collect --workers 8 --max-accounts 3000000
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py prefilter
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py histories --workers 8
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py actions --workers 8
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py prices --workers 8
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py screen --workers 8
```

`init` creates empty schemas, an empty legacy seed catalog, and an empty baseline
wallet header. Its completed empty-baseline marker means **zero legacy seed
markets require a supplemental backfill**; it does not claim that the expanded
market feeds have been collected. The actual universe comes from category
discovery and collection. Initialization preserves existing stored observations.

The collector paginates macro/geopolitical market feeds and counts unique wallet
addresses once. Its default three-million-account collection limit controls
discovery volume, not selection. It does not require a minimum number of selected
accounts. Retaining a cap can leave some market feeds partial/unvisited, which is
reported in the collection summary. Candidate-history completion fills partial
discovery feeds for candidates that pass the cheap gates; it does not manufacture
unseen accounts from unvisited markets.

`prefilter` finds reset dates passing 30 active macro trading days in 40 and average
frequency below 50 per calendar day over available preceding history, up to 365
days. `histories` completes candidate trade histories when collection was capped
or stopped; complete feeds are reused. `actions` collects macro inventory actions
such as splits, merges, conversions and redemptions. `prices` collects historical
market observations and timestamped resolutions. The model does not infer a
macro cash balance, count added exposure as profit, or backdate final outcomes.

## Sources and classification

The source code uses Gamma `/events/keyset` and `/markets`, public Data API v2
`/trades`, `/activity`, `/positions`, `/prices-history`, and `/resolutions`, plus
the international CLOB market WebSocket and book endpoint in the app.
`expand_macro_universe.py` contains the exact category/text classifier. It admits
macro/economic, geopolitical and national-government/election subjects and rejects
explicit sports, crypto, entertainment, mention-market and other unrelated terms;
local-government subjects have specific macro/military exceptions.

No API credential is required for public collection. Some inventory reconciliation
uses public Polygon transaction receipts and token movements. Those observations
repair inventory only; they are not returns or source cash flows. Network outages,
rate limits, changing APIs and inaccessible historical observations can prevent
completion. Do not turn failed retrievals into zero returns.

## Resolve actual data issues before simulation

Inspect the progress and summary files generated under
`data_storage/runtime/results_all_accounts_macro`. A `DATA_ISSUE` can require
retrying unavailable data or reconstructing token transfers. Only when the
recorded issue concerns missing inventory movements, run the existing recovery
stage and then retry screening:

```powershell
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py recover
& .\.venv\Scripts\python.exe data_retrieval\prepare_history.py retry-screen --workers 8
```

Recovery can be expensive and requires historical Polygon RPC coverage. It is
not a general repair for missing quotes or an API outage. Confirm the screening
summary reports completion without unresolved data before moving to simulation.
Then follow [Final simulation](../final_simulation/README.md).

Collectors save checkpoints. Resume an interrupted stage with the same command
after addressing the error. Do not launch duplicate collectors against the same
SQLite files. Preparation is separate from the app's current-date screening:
once started, the app refreshes its catalog and appends newer account observations
at its own scheduled resets.
