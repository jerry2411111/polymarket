"""Fresh-install orchestration around the unchanged collectors and final model.

An empty baseline lets expanded category discovery supply the entire universe.
It does not stand in for missing trader histories or simulated results.
"""
from pathlib import Path
import argparse
import json
import sqlite3
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
RUNTIME=ROOT/'data_storage'/'runtime'
OUT=RUNTIME/'results_all_accounts_macro'
TRADES='''CREATE TABLE IF NOT EXISTS trades(
    wallet TEXT,ts INTEGER,token TEXT,side TEXT,tx TEXT,condition TEXT,
    size REAL,price REAL,cash REAL,title TEXT,outcome TEXT,outcome_index INTEGER,
    PRIMARY KEY(wallet,ts,token,side,tx)) WITHOUT ROWID;
    CREATE INDEX IF NOT EXISTS trades_condition ON trades(condition);'''


def initialize():
    if not (RUNTIME/'macro_universe_data.py').is_file():
        raise RuntimeError('Run prepare_project.py first.')
    OUT.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(RUNTIME/'polymarket_data.sqlite') as db:
        db.execute('CREATE TABLE IF NOT EXISTS responses(url TEXT PRIMARY KEY,body BLOB)')
    for path,completion in [(RUNTIME/'rolling_discovery.sqlite',
                            'CREATE TABLE IF NOT EXISTS completed(condition TEXT PRIMARY KEY,left_ts INTEGER,right_ts INTEGER)'),
                           (OUT/'older_macro_trades.sqlite',
                            'CREATE TABLE IF NOT EXISTS completed(condition TEXT PRIMARY KEY,rows INTEGER,earliest INTEGER)')]:
        with sqlite3.connect(path) as db:
            db.executescript(TRADES);db.execute(completion)
    tables=[('complete_candidate_histories.sqlite','histories(wallet TEXT PRIMARY KEY,scope TEXT,end INTEGER,body BLOB)'),
            ('account_economics.sqlite','accounts(wallet TEXT PRIMARY KEY,body BLOB)')]
    for filename,schema in tables:
        with sqlite3.connect(OUT/filename) as db:db.execute('CREATE TABLE IF NOT EXISTS '+schema+' WITHOUT ROWID')
    empty_baseline=RUNTIME/'results'/'rolling_market_catalog.json'
    if not empty_baseline.exists():empty_baseline.write_text('[]\n',encoding='utf-8')
    if json.loads(empty_baseline.read_text(encoding='utf-8')):
        raise RuntimeError('Nonempty legacy baseline detected; use its original completed collection instead of fresh initialization.')
    # No seed market requires a supplemental backfill; all fresh markets will
    # be collected by expand_macro_universe, including their older observations.
    path=OUT/'backfill_summary.json'
    if not path.exists():path.write_text(json.dumps(dict(status='COMPLETE',markets=0,
        scope='Empty legacy seed baseline; expanded collection supplies actual history.'))+'\n',encoding='utf-8')
    path=OUT/'all_account_activity_screen.csv'
    if not path.exists():path.write_text('wallet\n',encoding='utf-8')
    print('Initialized empty cache schemas and an empty legacy baseline. No accounts or results were invented.')


def run(args):
    stages={
        'catalog':['expand_macro_universe.py','catalog','--workers',str(args.workers)],
        'collect':['expand_macro_universe.py','collect','--workers',str(args.workers),'--max-accounts',str(args.max_accounts)],
        'prefilter':['all_macro_prepare.py'],
        'histories':['complete_candidate_macro_histories.py','--workers',str(args.workers)],
        'actions':['all_accounts_economics.py','--workers',str(args.workers),'--candidates-only','--macro-only'],
        'prices':['macro_universe_data.py','prices','--workers',str(args.workers),'--candidates-only'],
        'screen':['screen_macro_performance.py','--workers',str(args.workers)],
        'recover':['recover_polymarket_inventory.py'],
        'retry-screen':['screen_macro_performance.py','--workers',str(args.workers),'--retry-issues'],
        'simulate':['run_active_macro_study.py'],
        'reports':['report_active_macro_study.py','--performance',args.performance],
    }
    if args.stage=='init':return initialize()
    script=RUNTIME/stages[args.stage][0]
    if not script.is_file():raise RuntimeError('Run prepare_project.py first.')
    subprocess.run([sys.executable,*stages[args.stage]],cwd=RUNTIME,check=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('init','catalog','collect','prefilter','histories','actions','prices',
        'screen','recover','retry-screen','simulate','reports'))
    parser.add_argument('--workers',type=int,default=8)
    parser.add_argument('--max-accounts',type=int,default=3000000)
    parser.add_argument('--performance',choices=('sharpe','return'),default='sharpe')
    args=parser.parse_args()
    if args.workers<1 or args.max_accounts<1:parser.error('workers and max-accounts must be positive')
    try:run(args)
    except (OSError,RuntimeError,subprocess.CalledProcessError) as exc:parser.exit(1,str(exc)+'\n')
