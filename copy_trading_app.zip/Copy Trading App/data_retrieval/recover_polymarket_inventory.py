"""Batch historical Polymarket token transfers for accounts with inventory gaps."""
from __future__ import annotations
import collections
import concurrent.futures
import hashlib
import json
import os
import sqlite3
import threading
import time
import urllib.request
import urllib.error
import zlib

import rolling_copy_backtest as b
from macro_universe_data import OUT,TEST_END,dump
from macro_account_model import MarketMarks
from polymarket_receipts import SINGLE,BATCH

URL='https://tenderly.rpc.polygon.community'
CONTRACT='0x4d97dcd97ec945f40cf65f87097ace5ea0476045'
_lock=threading.Lock()
_next=0.0


def rpc(method,params):
    global _next
    failure='No response'
    for attempt in range(7):
        with _lock:
            wait=max(0,_next-time.monotonic())
            _next=max(_next,time.monotonic())+.08
        if wait:time.sleep(wait)
        try:
            request=urllib.request.Request(URL,data=json.dumps(dict(jsonrpc='2.0',id=1,method=method,params=params)).encode(),
                headers={'Content-Type':'application/json','User-Agent':'polymarket-macro-research/1.0','Accept-Encoding':'gzip'})
            with urllib.request.urlopen(request,timeout=40) as response:
                raw=response.read()
                if response.getheader('Content-Encoding')=='gzip':
                    import gzip
                    raw=gzip.decompress(raw)
                body=json.loads(raw)
            if body.get('error'):raise b.DataError(str(body['error']))
            return body['result']
        except urllib.error.HTTPError as exc:
            failure=f'HTTP {exc.code}: '+exc.read().decode(errors='replace')[:400]
            if exc.code not in (429,500,502,503,504):raise b.DataError(failure)
            delay=max(float(exc.headers.get('Retry-After','0') or 0),min(2**attempt,20))
            with _lock:_next=max(_next,time.monotonic()+delay)
        except (OSError,ValueError,b.DataError) as exc:
            failure=str(exc);time.sleep(min(2**attempt,15))
    raise b.DataError(failure)


def end_block():
    path=OUT/'polymarket_test_end_block.json'
    if path.exists():return json.loads(path.read_text())['block']
    lo=0;hi=int(rpc('eth_blockNumber',[]),16)
    while lo+1<hi:
        mid=(lo+hi)//2
        at=int(rpc('eth_getBlockByNumber',[hex(mid),False])['timestamp'],16)
        if at<TEST_END:lo=mid
        else:hi=mid
    dump(path.name,dict(end=TEST_END,block=lo))
    return lo


def recover(wallets,workers=12):
    guard=OUT/'inventory_recovery.lock'
    while guard.exists() and guard.read_text().strip()!=str(os.getpid()):time.sleep(2)
    wallets=sorted(set(wallets))
    marks=MarketMarks()
    scope=hashlib.sha256('\n'.join(sorted(marks.token_condition)).encode()).hexdigest()
    directory=OUT/'polymarket_transfer_histories';directory.mkdir(exist_ok=True)
    missing=[]
    for w in wallets:
        path=directory/(w+'.json.zlib')
        if path.exists():
            old=json.loads(zlib.decompress(path.read_bytes()))
            if old['end']==TEST_END and old['scope']==scope:continue
        missing.append(w)
    if not missing:return
    batch=hashlib.sha256('\n'.join(missing).encode()).hexdigest()[:16]
    db=sqlite3.connect(OUT/('inventory_recovery_'+batch+'.sqlite'))
    db.execute('PRAGMA journal_mode=WAL');db.execute('PRAGMA synchronous=NORMAL')
    db.execute('CREATE TABLE IF NOT EXISTS done(first INTEGER,side INTEGER,PRIMARY KEY(first,side)) WITHOUT ROWID')
    db.execute('CREATE TABLE IF NOT EXISTS movements(wallet TEXT,ts INTEGER,tx TEXT,token TEXT,units INTEGER,PRIMARY KEY(wallet,ts,tx,token)) WITHOUT ROWID')
    db.commit()
    topics=['0x'+w[2:].zfill(64) for w in missing]
    wanted=set(missing);known=marks.token_condition
    final=end_block()
    # Begin at genesis: opening quantities are observed, not guessed from the
    # first visible trade or inferred from a later sale.
    jobs=[(first,side) for first in range(0,final+1,30000) for side in (2,3)]
    done=set(db.execute('SELECT first,side FROM done'))
    pending=iter(j for j in jobs if j not in done)
    total=len(jobs);completed=len(done);last=0;errors=[]
    def fetch(job):
        first,side=job
        def read(left,right):
            filters=[[SINGLE,BATCH],None,None,None];filters[side]=topics
            try:return rpc('eth_getLogs',[dict(address=CONTRACT,fromBlock=hex(left),toBlock=hex(right),topics=filters)])
            except b.DataError as exc:
                if any(s in str(exc).lower() for s in ('too many','limit exceeded','too large','result size')) and left<right:
                    mid=(left+right)//2
                    return read(left,mid)+read(mid+1,right)
                raise
        rows=read(first,min(first+29999,final));net=collections.defaultdict(int)
        for row in rows:
            topics_row=row['topics'];wallet='0x'+topics_row[side][-40:]
            if wallet not in wanted:raise b.DataError('Unexpected wallet in filtered Polymarket logs')
            at=int(row['blockTimestamp'],16)
            if at>=TEST_END:continue
            raw=bytes.fromhex(row['data'][2:])
            def uint(offset):return int.from_bytes(raw[offset:offset+32],'big')
            if topics_row[0]==SINGLE:pairs=[(uint(0),uint(32))]
            else:
                ids,amounts=uint(0),uint(32);n=uint(ids)
                if n!=uint(amounts):raise b.DataError('Unequal token/value arrays')
                pairs=[(uint(ids+32*(i+1)),uint(amounts+32*(i+1))) for i in range(n)]
            for token,units in pairs:
                token=str(token)
                if token in known:net[(wallet,at,row['transactionHash'],token)]+=(units if side==3 else -units)
        return job,[(*key,value) for key,value in net.items()]
    b.log(f'Recovering observed Polymarket holdings for {len(missing):,} affected accounts in shared archive requests')
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures={};exhausted=False
        while futures or not exhausted:
            while len(futures)<workers*2 and not exhausted:
                job=next(pending,None)
                if job is None:exhausted=True
                else:futures[pool.submit(fetch,job)]=job
            if not futures:break
            ready,_=concurrent.futures.wait(futures,timeout=1,return_when=concurrent.futures.FIRST_COMPLETED)
            for future in ready:
                job=futures.pop(future)
                try:
                    job,rows=future.result()
                    with db:
                        db.executemany('INSERT INTO movements VALUES(?,?,?,?,?) ON CONFLICT(wallet,ts,tx,token) DO UPDATE SET units=movements.units+excluded.units',rows)
                        db.execute('INSERT INTO done VALUES(?,?)',job)
                    completed+=1
                except Exception as exc:errors.append(dict(job=job,error=str(exc)))
            if time.monotonic()-last>=15:
                dump('inventory_recovery_progress.json',dict(status='RECOVERING',affected_accounts=len(missing),
                    historical_coverage_fraction=completed/total,errors=errors))
                b.log(f'{len(missing):,} affected accounts: archive coverage {completed/total:.1%}; {len(errors)} errors')
                last=time.monotonic()
    if errors:raise b.DataError(f'{len(errors)} archive requests need retry; progress is saved')
    for w in missing:
        rows=[[at,tx,t,units/1_000_000] for at,tx,t,units in db.execute('SELECT ts,tx,token,units FROM movements WHERE wallet=?',(w,))]
        path=directory/(w+'.json.zlib');tmp=path.with_suffix('.tmp')
        tmp.write_bytes(zlib.compress(json.dumps(dict(end=TEST_END,scope=scope,movements=rows),separators=(',',':')).encode(),3));tmp.replace(path)
    dump('inventory_recovery_progress.json',dict(status='COMPLETE',affected_accounts=len(missing),
        recovered_accounts=len(missing),historical_coverage_fraction=1,errors=[]))
    b.log(f'Observed Polymarket holdings recovered for {len(missing):,} accounts')


if __name__=='__main__':
    c=sqlite3.connect(OUT/'active_book_screened_accounts.sqlite')
    processed=dict(c.execute('SELECT wallet,error FROM processed'))
    inputs=sqlite3.connect(OUT/'candidate_inputs.sqlite')
    pending=[w for w, in inputs.execute('SELECT wallet FROM candidates') if w not in processed]
    affected=[w for w,e in processed.items() if 'first_inventory_issues' in e]+pending
    guard=OUT/'inventory_recovery.lock'
    guard.write_text(str(os.getpid()))
    try:recover(affected)
    finally:guard.unlink(missing_ok=True)
