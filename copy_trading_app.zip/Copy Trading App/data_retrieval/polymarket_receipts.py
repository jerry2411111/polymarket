"""Resolve ambiguous Polymarket inventory actions from their transaction logs."""
import collections
import json
import os
import time
import urllib.request

import rolling_copy_backtest as b
from macro_universe_data import OUT

SINGLE='0xc3d58168c5ae7397731d063d5bbf3d657854427343f4c083240f7aacaa2d0f62'
BATCH='0x4a39dc06d4c0dbc64b70af90fd698a233a518aa5d07e595d983b8c0526c8f7fb'


def receipt(tx):
    directory=OUT/'polymarket_receipts'
    directory.mkdir(exist_ok=True)
    path=directory/(tx+'.json')
    if path.exists():return json.loads(path.read_text())
    body=json.dumps(dict(jsonrpc='2.0',id=1,method='eth_getTransactionReceipt',params=[tx])).encode()
    error='No receipt'
    for url in ('https://polygon.drpc.org','https://polygon.publicnode.com'):
        try:
            request=urllib.request.Request(url,data=body,headers={'Content-Type':'application/json',
                'User-Agent':'polymarket-macro-research/1.0'})
            with urllib.request.urlopen(request,timeout=20) as response:payload=json.load(response)
            result=payload.get('result')
            if result:
                temporary=path.with_suffix(f'.{os.getpid()}.tmp')
                temporary.write_text(json.dumps(result),encoding='utf-8')
                temporary.replace(path)
                return result
            error=str(payload.get('error') or 'Receipt absent')
        except Exception as exc:error=str(exc)
    raise b.DataError('Polymarket receipt unavailable: '+tx+': '+error)


def token_deltas(tx,wallet,known_tokens):
    changes=collections.defaultdict(float)
    wallet=wallet.lower()
    for row in receipt(tx)['logs']:
        topics=row.get('topics',[])
        if len(topics)!=4 or topics[0] not in (SINGLE,BATCH):continue
        sender='0x'+topics[2][-40:]
        receiver='0x'+topics[3][-40:]
        sign=int(receiver==wallet)-int(sender==wallet)
        if not sign:continue
        data=bytes.fromhex(row['data'][2:])
        def integer(offset):return int.from_bytes(data[offset:offset+32],'big')
        if topics[0]==SINGLE:
            pairs=[(integer(0),integer(32))]
        else:
            ids,amounts=integer(0),integer(32)
            n=integer(ids)
            if n!=integer(amounts):raise b.DataError('Unequal ERC1155 token/value arrays')
            pairs=[(integer(ids+32*(i+1)),integer(amounts+32*(i+1))) for i in range(n)]
        for token,amount in pairs:
            token=str(token)
            if token in known_tokens:changes[token]+=sign*amount/1_000_000
    return dict(changes)
