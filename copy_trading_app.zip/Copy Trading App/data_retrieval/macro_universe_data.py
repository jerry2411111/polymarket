"""Expanded macro/geopolitical universe, isolated from the previous studies.

Retain every account in the market trade index. Backfill the older history of
catalog markets without applying account-level selection rules during discovery.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import csv
import hashlib
import gzip
import http.client
import json
from pathlib import Path
import shutil
import sqlite3
import threading
import time
import urllib.parse
import zlib

import rolling_copy_backtest as b

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results_all_accounts_macro'
BACKUP_START = b.stamp('2024-09-14')
TEST_START = b.stamp('2025-09-14')
TEST_END = b.stamp('2026-09-14')


def load_markets():
    expanded=OUT/'expanded_market_catalog.json'
    path=expanded if expanded.exists() else ROOT/'results/rolling_market_catalog.json'
    return json.loads(path.read_text(encoding='utf-8'))


def prepare_return_metadata(markets=None):
    """Keep worker metadata compact without duplicating complete Gamma events."""
    if markets is None:markets=load_markets()
    compact=[{k:m.get(k) for k in ('conditionId','clobTokenIds','outcomes','question')} |
        {'events':[{'slug':e.get('slug')} for e in m.get('events',[])]} for m in markets]
    dump('macro_markets_for_returns.json',compact)
    groups={}
    for market in markets:
        if market.get('negRisk') and market.get('negRiskMarketID') and len(json.loads(market.get('clobTokenIds') or '[]'))==2:
            groups.setdefault(market['negRiskMarketID'],[]).append(market)
    valid={}
    for group,members in groups.items():
        try:indices=[int(m['questionID'],16)&255 for m in members]
        except (KeyError,TypeError,ValueError):continue
        if sorted(indices)==list(range(len(members))):
            valid[group]=[m['conditionId'] for m in sorted(members,key=lambda m:int(m['questionID'],16))]
    dump('negative_risk_valuation_groups.json',valid)


def dump(name, value):
    OUT.mkdir(exist_ok=True)
    path = OUT / name
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')
    temporary.replace(path)


class LayeredAPI(b.API):
    """Read prior responses, writing newly requested data to a separate cache."""
    def __init__(self, workers=8, requests_per_second=None):
        OUT.mkdir(exist_ok=True)
        super().__init__(OUT / 'additional_api_cache.sqlite', workers)
        self.db.execute('PRAGMA busy_timeout=30000')
        self.old = sqlite3.connect(f'file:{(ROOT / "polymarket_data.sqlite").as_posix()}?mode=ro',
                                  uri=True, check_same_thread=False)
        self.old_lock = threading.Lock()
        self.net=threading.local()
        self.request_spacing=1/requests_per_second if requests_per_second else 0.0
        self.request_lock=threading.Lock()
        self.next_request_at=0.0
        self.backoff_until=0.0

    def pace_request(self):
        while True:
            with self.request_lock:
                now=time.monotonic()
                delay=max(self.next_request_at,self.backoff_until)-now
                if delay<=0:
                    self.next_request_at=now+self.request_spacing
                    return
            time.sleep(min(delay,1.0))

    def get(self, base, route, params=None):
        url = base + route
        if params:
            url += '?' + urllib.parse.urlencode(sorted(params.items()))
        with self.old_lock:
            row = self.old.execute('SELECT body FROM responses WHERE url=?', (url,)).fetchone()
        if row:return json.loads(zlib.decompress(row[0]))
        with self.lock:
            row=self.db.execute('SELECT body FROM responses WHERE url=?',(url,)).fetchone()
        if row:return json.loads(zlib.decompress(row[0]))
        parsed=urllib.parse.urlsplit(url)
        error='No response'
        for attempt in range(6):
            try:
                if not hasattr(self.net,'connections'):self.net.connections={}
                if parsed.netloc not in self.net.connections:
                    self.net.connections[parsed.netloc]=http.client.HTTPSConnection(parsed.netloc,timeout=30)
                connection=self.net.connections[parsed.netloc]
                with self.gate:
                    self.pace_request()
                    connection.request('GET',parsed.path+('?' + parsed.query if parsed.query else ''),headers={
                        'Accept':'application/json','Accept-Encoding':'gzip','User-Agent':'polymarket-macro-research/1.0'})
                    response=connection.getresponse()
                    raw=response.read()
                if response.getheader('Content-Encoding')=='gzip':raw=gzip.decompress(raw)
                if response.status>=400:
                    error=f'HTTP {response.status}: {raw[:250].decode(errors="replace")}'
                    if response.status not in (429,500,502,503,504):break
                    delay=max(float(response.getheader('Retry-After','0') or 0),min(2**attempt,15))
                    if response.status==429:
                        with self.request_lock:
                            self.backoff_until=max(self.backoff_until,time.monotonic()+max(10,delay))
                    else:time.sleep(delay)
                    continue
                result=json.loads(raw)
                compressed=zlib.compress(raw,3)
                with self.lock:
                    self.db.execute('INSERT OR REPLACE INTO responses VALUES(?,?)',(url,compressed));self.db.commit()
                    self.requests+=1
                return result
            except (OSError,ValueError,http.client.HTTPException) as exc:
                error=str(exc)
                if hasattr(self.net,'connections'):
                    connection=self.net.connections.pop(parsed.netloc,None)
                    if connection:connection.close()
                time.sleep(min(2**attempt,10))
        raise b.DataError(url+': '+error)


def definition():
    OUT.mkdir(exist_ok=True)
    saved = OUT / 'previous_reports'
    saved.mkdir(exist_ok=True)
    original_reports = []
    for name in ('Polymarket_Allocation_rawsharpe.pdf', 'Polymarket_Daily_updated.pdf',
                 'Polymarket_Effective.pdf'):
        source = ROOT.parent / name
        target = saved / name
        if not target.exists():
            shutil.copy2(source, target)
        original_reports.append(dict(file=name, sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
    dump('study_definition.json', dict(
        status='PREPARING', original_reports=original_reports,
        backup_start=b.iso(BACKUP_START), simulation_start=b.iso(TEST_START),
        simulation_end_exclusive=b.iso(TEST_END),
        dates_reason='Keep the three reproduced reports on their original test dates; preceding year is warm-up.',
        universe='Every account in all 9,411 macro/geopolitical catalog markets, including older backfill accounts.',
        discovery='No account frequency, holding-time, concentration, Sharpe or prior-shortlist gate.',
        selection_scope='Macro/geopolitical trades and position performance only.',
        maximum_average_trades_per_day_exclusive=50,
        maximum_closed_shares_under_one_hour_fraction=.10,
        maximum_two_sided_token_hour_fraction=.20,
        maximum_both_outcomes_market_hour_fraction=.20,
        macro_participation_fraction_minimum=None, minimum_trade_frequency=None,
        minimum_recent_trades=None, median_holding_time_range=None,
        minimum_completed_markets=None, minimum_closed_lots=None,
        ranking=None, top_n=None, selection_active_trading_days_minimum=30,
        selection_active_trading_days_window=40,
        active_trading_day='UTC calendar day containing at least one macro/geopolitical BUY or SELL before the reset.',
        frequency_denominator='Calendar days in available preceding history, including inactive days, capped at 365.',
        selection_history_days_maximum=365,
        shorter_history='Use actual available observations; do not fabricate a full year.',
        fees=0, slippage=0,
        return_basis='Daily direct position-value-weighted returns: use previous closing macro quantities and marked values to weight next-day position returns. Current position changes only set the following day weights.',
        return_interpretation='Return of the trader active macro/geopolitical book conditional on being invested in macro/geopolitics; not whole-account returns.',
        sleeve_cash_assignment='No inferred source cash, no inferred category capital flows, no standardized trading-account simulation for account screening.',
        portfolio_basis='Relative source macro position market values at daily boundaries; no-exposure days excluded from account moments. Strategy cash days remain in strategy Sharpe.',
        allocation='Inverse volatility of the same historical macro/geopolitical sleeve daily returns, across every qualifying account.',
        report_cases=dict(allocation=225, daily=12, effective=55),
        report_pages=dict(allocation=6, daily=3, effective=1)))


def backfill(workers=8):
    """Fetch preceding older market trades into a separate, resumable supplement.

    Download to market inception where older opening inventory may be required;
    only the requested two years will contribute observations to the study.
    """
    definition()
    source = sqlite3.connect(f'file:{(ROOT / "rolling_discovery.sqlite").as_posix()}?mode=ro', uri=True)
    coverage = dict(source.execute('SELECT condition,left_ts FROM completed'))
    source.close()
    markets = json.loads((ROOT / 'results/rolling_market_catalog.json').read_text())
    jobs = [m for m in markets if b.stamp(m['createdAt']) < coverage[m['conditionId']]]
    api = LayeredAPI(workers)
    lock = threading.Lock()
    db = sqlite3.connect(OUT / 'older_macro_trades.sqlite', check_same_thread=False)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA synchronous=NORMAL')
    db.execute('CREATE TABLE IF NOT EXISTS completed(condition TEXT PRIMARY KEY, rows INTEGER, earliest INTEGER)')
    db.execute('''CREATE TABLE IF NOT EXISTS trades(
        wallet TEXT, ts INTEGER, token TEXT, side TEXT, tx TEXT, condition TEXT,
        size REAL, price REAL, cash REAL, title TEXT, outcome TEXT, outcome_index INTEGER,
        PRIMARY KEY(wallet,ts,token,side,tx)) WITHOUT ROWID''')
    db.execute('CREATE INDEX IF NOT EXISTS trades_condition ON trades(condition)')
    db.commit()
    insert = '''INSERT INTO trades VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(wallet,ts,token,side,tx) DO UPDATE SET
        price=(trades.price*trades.size+excluded.price*excluded.size)/(trades.size+excluded.size),
        size=trades.size+excluded.size,cash=trades.cash+excluded.cash'''

    def one(market):
        condition = market['conditionId']
        with lock:
            hit = db.execute('SELECT rows,earliest FROM completed WHERE condition=?', (condition,)).fetchone()
            if hit:
                return dict(condition=condition, rows=hit[0], earliest=hit[1], reused=True)
            db.execute('DELETE FROM trades WHERE condition=?', (condition,))
            db.commit()
        number, earliest = 0, None
        for raw in api.pages('/v2/trades', dict(condition=condition, limit=1000, taker_only='false')):
            records = []
            for row in raw:
                e = b.Event.parse(row)
                if e.ts >= coverage[condition] or e.size <= 0:
                    continue
                records.append((e.wallet,e.ts,e.token,e.side,e.tx,e.condition,e.size,e.price,
                                e.cash,e.title,e.outcome,e.outcome_index))
                earliest = e.ts if earliest is None else min(earliest, e.ts)
            if records:
                with lock:
                    db.executemany(insert, records)
                    db.commit()
                number += len(records)
        with lock:
            db.execute('INSERT INTO completed VALUES(?,?,?)', (condition, number, earliest))
            db.commit()
        return dict(condition=condition, rows=number, earliest=earliest, reused=False)

    completed, errors = [], []
    b.log(f'Backfilling older history for {len(jobs)} markets; no account screening')
    last = time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(one, m): m for m in jobs}
        for future in concurrent.futures.as_completed(futures):
            try:
                completed.append(future.result())
            except Exception as exc:
                errors.append(dict(condition=futures[future]['conditionId'], error=str(exc)))
            if time.monotonic() - last >= 15 or len(completed) + len(errors) == len(jobs):
                status = dict(completed_markets=len(completed), total_markets=len(jobs),
                              older_trade_rows=sum(r['rows'] for r in completed),
                              errors=errors, new_api_requests=api.requests)
                dump('backfill_progress.json', status)
                b.log(json.dumps(status))
                last = time.monotonic()
    db.close()
    dump('backfill_summary.json', dict(status='COMPLETE' if not errors else 'INCOMPLETE',
        completed=completed, errors=errors, new_api_requests=api.requests))
    if errors:
        raise SystemExit('Market backfill has errors; see backfill_summary.json')


def inventory():
    """Enumerate every original discovery wallet without eligibility filtering."""
    OUT.mkdir(exist_ok=True)
    source = sqlite3.connect(f'file:{(ROOT / "rolling_discovery.sqlite").as_posix()}?mode=ro', uri=True)
    count = total = 0
    first = last = None
    started = time.monotonic()
    previous = started
    with (OUT / 'all_discovered_accounts.csv').open('w', newline='', encoding='utf-8') as handle:
        writer = csv.writer(handle)
        writer.writerow(['wallet', 'macro_trade_count_in_original_index', 'first_macro_trade_utc', 'last_macro_trade_utc'])
        for wallet, n, left, right in source.execute('SELECT wallet,count(*),min(ts),max(ts) FROM trades GROUP BY wallet'):
            writer.writerow([wallet,n,b.iso(left),b.iso(right)])
            count += 1
            total += n
            first = left if first is None else min(first, left)
            last = right if last is None else max(last, right)
            if time.monotonic() - previous >= 15:
                b.log(f'Unfiltered universe: {count:,} accounts; {total:,} macro trade decisions')
                previous = time.monotonic()
    result = dict(accounts=count, macro_trade_decisions=total, first_trade_utc=b.iso(first),
                  last_trade_utc=b.iso(last), elapsed_seconds=time.monotonic()-started,
                  account_filter_applied=False)
    dump('original_universe_inventory.json', result)
    b.log(json.dumps(result))
    source.close()


def market_prices(workers=8,candidates_only=False):
    """Collect historical marks and timestamped payouts for all catalog tokens."""
    OUT.mkdir(exist_ok=True)
    # The final pass reuses the optional overlapping price pass, then fills any
    # tokens newly found in completed candidate histories. Avoid duplicate jobs.
    while (OUT/'market_price_prefetch.lock').exists():time.sleep(2)
    markets = load_markets()
    prepare_return_metadata(markets)
    if candidates_only:
        needed=set()
        accounts=sqlite3.connect(f'file:{(OUT/"candidate_inputs.sqlite").as_posix()}?mode=ro',uri=True)
        economics=sqlite3.connect(f'file:{(OUT/"account_economics.sqlite").as_posix()}?mode=ro',uri=True)
        event_slugs=set()
        for wallet,blob in accounts.execute('SELECT wallet,body FROM candidates'):
            source=json.loads(zlib.decompress(blob))
            needed.update(r[5] for r in source['rows'])
            hit=economics.execute('SELECT body FROM accounts WHERE wallet=?',(wallet,)).fetchone()
            if hit:
                account=json.loads(zlib.decompress(hit[0]))
                needed.update(r.get('condition_id') for r in account['actions'])
                event_slugs.update(r.get('event_slug') for r in account['actions'] if r['type']=='CONVERSION')
        markets=[m for m in markets if m['conditionId'] in needed or
            any(e.get('slug') in event_slugs for e in m.get('events',[]))]
        accounts.close();economics.close()
    tokens = sorted({str(t) for m in markets for t in json.loads(m.get('clobTokenIds') or '[]')})
    api = LayeredAPI(workers,requests_per_second=18)
    db = sqlite3.connect(OUT/'market_prices.sqlite')
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('CREATE TABLE IF NOT EXISTS prices(token TEXT PRIMARY KEY,body BLOB) WITHOUT ROWID')
    db.execute('CREATE TABLE IF NOT EXISTS resolutions(condition TEXT PRIMARY KEY,body TEXT) WITHOUT ROWID')
    db.commit()
    done = {r[0] for r in db.execute('SELECT token FROM prices')}
    errors = []

    def one(token):
        try:
            points = {}
            for rows in api.pages('/v2/prices-history',dict(token_id=token,interval='max',bucket_seconds=10800,limit=10000)):
                for p in rows:
                    at = int(p['timestamp']) + int(p['resolution_seconds'])
                    if at <= TEST_END and p.get('price') is not None:
                        points[at] = float(p['price'])
            return token,zlib.compress(json.dumps(sorted(points.items()),separators=(',',':')).encode(),3),None
        except Exception as exc:
            return token,None,str(exc)

    count, last = len(done.intersection(tokens)), time.monotonic()
    b.log(f'Historical market marks: {count:,}/{len(tokens):,} tokens already prepared')
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        for token,body,error in pool.map(one,(t for t in tokens if t not in done),buffersize=workers*2):
            if error:
                errors.append(dict(token=token,error=error))
            else:
                db.execute('INSERT OR REPLACE INTO prices VALUES(?,?)',(token,body))
                count += 1
            if time.monotonic()-last >= 15:
                db.commit()
                status=dict(prepared_tokens=count,total_tokens=len(tokens),errors=len(errors),new_api_requests=api.requests)
                dump('market_price_progress.json',status)
                b.log(json.dumps(status))
                last=time.monotonic()
    db.commit()
    done_conditions = {r[0] for r in db.execute('SELECT condition FROM resolutions')}
    conditions = [m['conditionId'] for m in markets if m['conditionId'] not in done_conditions]
    batches = [conditions[i:i+5] for i in range(0,len(conditions),5)]
    def resolution(batch):
        try:
            return batch,api.get(b.DATA,'/v2/resolutions',dict(condition=','.join(batch)))
        except b.DataError:
            data=[]
            for condition in batch:
                data.extend(api.get(b.DATA,'/v2/resolutions',dict(condition=condition))['data'])
            return batch,dict(data=data)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        for batch,payload in pool.map(resolution,batches,buffersize=workers*2):
            found={r['condition_id']:r for r in payload['data'] if r.get('condition_id')}
            for condition in batch:
                db.execute('INSERT OR REPLACE INTO resolutions VALUES(?,?)',
                           (condition,json.dumps(found.get(condition))))
            db.commit()
            if time.monotonic()-last>=15:
                b.log(f'Market resolution states: {db.execute("SELECT count(*) FROM resolutions").fetchone()[0]:,}/{len(markets):,}')
                last=time.monotonic()
    dump('market_price_summary.json',dict(status='COMPLETE' if not errors else 'INCOMPLETE',
        prepared_tokens=count,total_tokens=len(tokens),errors=errors,new_api_requests=api.requests))
    db.close()
    b.log(f'Market marks and resolutions ready: {count:,} tokens; {len(errors)} errors')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['inventory', 'backfill', 'definition', 'prices'])
    parser.add_argument('--workers', type=int, default=8)
    parser.add_argument('--candidates-only',action='store_true')
    args = parser.parse_args()
    if args.stage == 'backfill':
        backfill(args.workers)
    elif args.stage == 'inventory':
        inventory()
    elif args.stage == 'prices':
        market_prices(args.workers,args.candidates_only)
    else:
        definition()
