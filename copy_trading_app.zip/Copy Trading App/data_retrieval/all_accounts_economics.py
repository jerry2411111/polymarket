"""Collect historical equity inputs for every discovered account, resumably.

Daily whole-account economic P&L and deposits/withdrawals establish total equity.
Macro market transactions come from the exhaustive market index; collect the
non-trade inventory actions too so splits, merges and redeems are represented.
No trading-style or performance eligibility filter is applied in this collector.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import csv
import http.client
import json
import os
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib

import rolling_copy_backtest as b
from macro_universe_data import OUT, ROOT, TEST_END, dump

TYPES = 'DEPOSIT,WITHDRAWAL,SPLIT,MERGE,REDEEM,CONVERSION'


class Collector:
    def __init__(self,macro_only=False):
        self.local = threading.local()
        self.lock = threading.Lock()
        self.requests = 0
        self.cache_hits = 0
        self.wait_until = 0.0
        self.macro_only=macro_only

    def old_db(self):
        if not hasattr(self.local, 'db'):
            self.local.db = sqlite3.connect(f'file:{(ROOT / "polymarket_data.sqlite").as_posix()}?mode=ro', uri=True)
        return self.local.db

    def cached(self, route, params):
        url = b.DATA + route + '?' + urllib.parse.urlencode(sorted(params.items()))
        hit = self.old_db().execute('SELECT body FROM responses WHERE url=?', (url,)).fetchone()
        if hit:
            with self.lock:
                self.cache_hits += 1
            return json.loads(zlib.decompress(hit[0]))
        return None

    def get(self, route, params):
        hit = self.cached(route, params)
        if hit is not None:
            return hit
        url = b.DATA + route + '?' + urllib.parse.urlencode(sorted(params.items()))
        for attempt in range(8):
            delay = self.wait_until - time.monotonic()
            if delay > 0:
                time.sleep(delay)
            try:
                if not hasattr(self.local, 'http'):
                    self.local.http = http.client.HTTPSConnection('data-api.polymarket.com', timeout=45)
                self.local.http.request('GET', route+'?'+urllib.parse.urlencode(sorted(params.items())),
                    headers={'User-Agent':'polymarket-macro-research/1.0','Accept':'application/json'})
                response = self.local.http.getresponse()
                raw = response.read()
                if response.status >= 400:
                    if response.status not in (429,500,502,503,504):
                        raise b.DataError(f'HTTP {response.status}: {raw.decode(errors="replace")[:400]}')
                    delay=max(float(response.getheader('Retry-After','0') or 0),min(2**attempt,30))
                    with self.lock:
                        self.wait_until=max(self.wait_until,time.monotonic()+delay)
                    continue
                result=json.loads(raw)
                with self.lock:
                    self.requests += 1
                return result
            except urllib.error.HTTPError as exc:
                if exc.code not in (429,500,502,503,504):
                    raise b.DataError(f'HTTP {exc.code}: {exc.read().decode(errors="replace")[:400]}')
                delay = max(float(exc.headers.get('Retry-After', '0') or 0), min(2 ** attempt, 30))
                with self.lock:
                    self.wait_until = max(self.wait_until, time.monotonic() + delay)
            except (OSError, ValueError, http.client.HTTPException):
                if hasattr(self.local,'http'):
                    self.local.http.close()
                    del self.local.http
                if attempt == 7:
                    raise
                time.sleep(min(2 ** attempt, 15))
        raise b.DataError('API retries exhausted: '+url)

    def one(self, wallet):
        try:
            points=[]
            if not self.macro_only:
                native = self.get('/v2/user-pnl', dict(user=wallet, interval='max', fidelity='1d'))
                points = [[int(p['timestamp']),p.get('economic_pnl'),p.get('cashflow_net')]
                          for p in native['data']['points'] if int(p['timestamp']) <= TEST_END]
            params = dict(user=wallet, start=1, end=TEST_END-1, sort_direction='ASC',
                          limit=1000, exclude_deposits_withdrawals='false')
            # The older full-history downloads are directly reusable.
            first = self.cached('/v2/activity', params)
            if first is None:
                params['type'] = 'SPLIT,MERGE,REDEEM,CONVERSION' if self.macro_only else TYPES
                first = self.get('/v2/activity', params)
            payload, cursors, actions = first, set(), []
            name = ''
            while True:
                for r in payload['data']:
                    name = name or r.get('name') or r.get('pseudonym') or ''
                    if r.get('type') in TYPES.split(','):
                        actions.append(r)
                pagination = payload.get('pagination', {})
                cursor = pagination.get('next_cursor')
                if not cursor:
                    if pagination.get('has_more'):
                        raise b.DataError('Activity page has_more without cursor')
                    break
                if cursor in cursors:
                    raise b.DataError('Repeated activity cursor')
                cursors.add(cursor)
                payload = self.get('/v2/activity', dict(params, cursor=cursor))
            body = dict(wallet=wallet,name=name,points=points,actions=actions)
            return wallet, zlib.compress(json.dumps(body,separators=(',',':')).encode(), 3), None
        except Exception as exc:
            return wallet, None, str(exc)


def wallets(candidates_only=False):
    """Consume the original inventory as it is written, then backfill newcomers."""
    path = OUT / ('priority_accounts.txt' if candidates_only else 'all_discovered_accounts.csv')
    while not path.exists():
        time.sleep(1)
    seen = set()
    with path.open(encoding='utf-8', newline='') as handle:
        if not candidates_only:handle.readline()
        while True:
            where = handle.tell()
            line = handle.readline()
            if line and line.endswith('\n'):
                wallet = line.strip().split(',',1)[0]
                if wallet.startswith('0x') and wallet not in seen:
                    seen.add(wallet)
                    yield wallet
            else:
                handle.seek(where)
                finished='activity_screen_summary.json' if candidates_only else 'original_universe_inventory.json'
                if (OUT/finished).exists():
                    break
                time.sleep(1)
    if candidates_only:return
    while not (OUT/'backfill_summary.json').exists():
        time.sleep(1)
    status = json.loads((OUT/'backfill_summary.json').read_text())
    if status['status'] != 'COMPLETE':
        raise b.DataError('Older market backfill is incomplete')
    db = sqlite3.connect(f'file:{(OUT/"older_macro_trades.sqlite").as_posix()}?mode=ro', uri=True)
    for wallet, in db.execute('SELECT DISTINCT wallet FROM trades'):
        if wallet not in seen:
            seen.add(wallet)
            yield wallet
    db.close()


def main(workers=12,candidates_only=False,macro_only=False):
    OUT.mkdir(exist_ok=True)
    db = sqlite3.connect(OUT/'account_economics.sqlite')
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA synchronous=NORMAL')
    db.execute('CREATE TABLE IF NOT EXISTS accounts(wallet TEXT PRIMARY KEY,body BLOB) WITHOUT ROWID')
    db.execute('CREATE TABLE IF NOT EXISTS errors(wallet TEXT PRIMARY KEY,error TEXT) WITHOUT ROWID')
    db.commit()
    existing = {r[0] for r in db.execute('SELECT wallet FROM accounts')}
    source = Collector(macro_only)
    completed, failures, seen = len(existing), 0, 0
    started = time.monotonic()
    last = started
    (OUT/'account_collector.pid').write_text(str(os.getpid()))
    stop_file=OUT/'stop_account_collector'
    if stop_file.exists():stop_file.unlink()

    def pending():
        nonlocal seen
        requested=set(existing)
        priority_offset=0
        for wallet in wallets(candidates_only):
            seen += 1
            path=OUT/'priority_accounts.txt'
            if path.exists() and not candidates_only:
                with path.open(encoding='utf-8') as handle:
                    handle.seek(priority_offset)
                    for line in handle:
                        w=line.strip()
                        if len(w)==42 and w not in requested:
                            requested.add(w)
                            yield w
                    priority_offset=handle.tell()
            if wallet not in requested:
                requested.add(wallet)
                yield wallet

    label='Polymarket inventory actions' if macro_only else 'equity and inventory inputs'
    b.log(f'Collecting {label} for requested accounts; {completed:,} already cached')
    paused=False
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        iterator=iter(pending())
        futures=set()
        exhausted=False
        while futures or not exhausted:
            while len(futures)<workers*2 and not exhausted and not stop_file.exists():
                wallet=next(iterator,None)
                if wallet is None:
                    exhausted=True
                else:
                    futures.add(pool.submit(source.one,wallet))
            if stop_file.exists():
                exhausted=True
                paused=True
            if not futures:break
            ready,futures=concurrent.futures.wait(futures,timeout=1,
                return_when=concurrent.futures.FIRST_COMPLETED)
            for future in ready:
                wallet,body,error=future.result()
                if error:
                    db.execute('INSERT OR REPLACE INTO errors VALUES(?,?)',(wallet,error))
                    failures += 1
                else:
                    db.execute('INSERT OR REPLACE INTO accounts VALUES(?,?)',(wallet,body))
                    db.execute('DELETE FROM errors WHERE wallet=?',(wallet,))
                    completed += 1
            if time.monotonic()-last >= 15:
                db.commit()
                status = dict(status='COLLECTING',complete_accounts=completed,errors_this_run=failures,
                    enumerated_accounts=seen,new_api_requests=source.requests,cache_hits=source.cache_hits,
                    elapsed_seconds=time.monotonic()-started)
                dump('account_collection_progress.json',status)
                b.log(json.dumps(status))
                last = time.monotonic()
    db.commit()
    errors = db.execute('SELECT count(*) FROM errors').fetchone()[0]
    result = dict(status='PAUSED' if paused else ('COMPLETE' if not errors else 'INCOMPLETE'), complete_accounts=completed,
                  enumerated_accounts=seen, errors=errors, new_api_requests=source.requests,
                  cache_hits=source.cache_hits,elapsed_seconds=time.monotonic()-started)
    dump('account_collection_summary.json',result)
    b.log(json.dumps(result))
    db.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers',type=int,default=12)
    parser.add_argument('--candidates-only',action='store_true')
    parser.add_argument('--macro-only',action='store_true')
    args=parser.parse_args()
    main(args.workers,args.candidates_only,args.macro_only)
