"""Observed Polymarket ERC-1155 movements for inventory reconciliation only.

Trades still determine trading activity and execution-side style checks. These
records supply missing position movements; they are never cash flows or returns.
"""
from __future__ import annotations
import collections
import hashlib
import json
import zlib

import rolling_copy_backtest as b
from macro_universe_data import OUT, TEST_END

def history(wallet,known_tokens):
    directory=OUT/'polymarket_transfer_histories';directory.mkdir(exist_ok=True)
    path=directory/(wallet+'.json.zlib')
    scope=hashlib.sha256('\n'.join(sorted(known_tokens)).encode()).hexdigest()
    if path.exists():
        body=json.loads(zlib.decompress(path.read_bytes()))
        if body['end']==TEST_END and body['scope']==scope:return body['movements']
    raise b.DataError('Polymarket transfer archive is not yet prepared for '+wallet)


def reconcile_events(events,wallet,marks,observed=None):
    """Append only differences between observed transfers and represented actions."""
    if observed is None:observed=history(wallet,marks.token_condition)
    actual={(tx,token):(at,qty) for at,tx,token,qty in observed}
    represented=collections.defaultdict(float)
    refs={}
    for e in events:
        refs[e.tx]=e
        if e.kind in ('TRADE','INVENTORY_DELTA'):
            represented[e.tx,e.token]+=e.size if e.side=='BUY' else -e.size
        elif e.kind=='REDEEM':represented[e.tx,e.token]-=e.size
        elif e.kind in ('SPLIT','MERGE'):
            for token in marks.condition_tokens[e.condition]:
                represented[e.tx,token]+=e.size if e.kind=='SPLIT' else -e.size
    adjustments=[]
    for key in set(actual)|set(represented):
        tx,token=key
        at,qty=actual.get(key,(refs[tx].ts if tx in refs else 0,0))
        delta=qty-represented.get(key,0)
        if abs(delta)<=1e-7:continue
        adjustments.append(b.Event(at,wallet,token,marks.token_condition[token],
            'INVENTORY_DELTA','BUY' if delta>0 else 'SELL',abs(delta),0,0,
            marks.by_condition[marks.token_condition[token]].get('question',''),tx))
    return sorted(events+adjustments,key=lambda e:(e.ts,0 if e.kind=='SPLIT' else 1,
        0 if e.side=='BUY' else 1,e.tx,e.token))
