"""Expand the market-derived wallet universe up to the requested unique-account target."""
from __future__ import annotations

import argparse
import collections
import concurrent.futures
import csv
import json
import re
import sqlite3
import threading
import time

import rolling_copy_backtest as b
from macro_universe_data import ROOT,OUT,BACKUP_START,TEST_END,LayeredAPI,dump
from macro_account_registry import AccountRegistry

TAGS={225:'Economics',100265:'Geopolitics',2:'Politics',101970:'World',120:'Finance',
      144:'Elections',1597:'Global Elections',159:'Fed'}
NATIONAL=re.compile(r'\b(presiden\w*|prime minister|chancellor|parliament\w*|senate|congress\w*|'
    r'general election|national election|legislative election|government|coalition|cabinet|'
    r'head of state|election winner|electoral|electors|supreme court|referendum|constitution\w*|'
    r'trade|tariff\w*|sanction\w*|foreign policy|diploma\w*|budget|national debt|treasury|'
    r'secretary of state|defense secretary|secretary of defense|state department)\b',re.I)
MACRO_EXTRA=re.compile(r'\b(oil|brent|wti|crude|natural gas|gasoline|gold|silver|copper|bond yield\w*|'
    r'exchange rate|dollar index|us dollar|eur/usd|usd/jpy|s&p 500|nasdaq|dow jones|'
    r'consumer confidence|retail sales|manufacturing|industrial production|jobless claims|'
    r'employment|wages|housing starts|national debt|sovereign|capital controls)\b',re.I)
LOCAL=re.compile(r'\b(mayor\w*|municipal|city council|school board|county|local election|'
    r'governor\w*|gubernatorial|provincial|oblast)\b',re.I)
NON_MACRO=re.compile(r'\b(nba|nfl|nhl|mlb|fifa|soccer|football|basketball|baseball|tennis|cricket|'
    r'volleyball|hockey|rugby|olympic\w*|champions league|world cup|ufc|mma|boxing|esports?|'
    r'counter.strike|dota|league of legends|bitcoin|ethereum|solana|btc|eth|xrp|'
    r'tweet\w*|mentions?|say|speech|box office|gta|oscar|grammy|nobel|peace prize|'
    r'photographed|selfie|highest temperature|lowest temperature|rainfall|snowfall)\b',re.I)
MACRO_LOCAL_EXCEPTION=re.compile(r'\b(fed|federal reserve|central bank|bank of england|bank of japan|'
    r'capture|invade|invasion|annex|military|ceasefire|airstrike|missile|troops|battle|war)\b',re.I)


def classify(market,event,queried_tag):
    question=market.get('question','')
    context=question+' '+event.get('title','')
    if NON_MACRO.search(question):return None
    if LOCAL.search(context) and not MACRO_LOCAL_EXCEPTION.search(context):return None
    labels={str(t.get('slug','')).lower() for t in event.get('tags',[])}
    if labels.intersection({'sports','soccer','nba','nfl','nhl','mlb','tennis','cricket','esports',
            'weather','temperature','pop-culture','movies','music','celebrity','celebrities',
            'mention-markets','mentions','truth-social','tweets'}):return None
    event_tags={int(t['id']) for t in event.get('tags',[]) if str(t.get('id','')).isdigit()}
    if b.MACRO.search(context) or MACRO_EXTRA.search(context):return 'macro_or_geopolitical_subject'
    if 100265 in event_tags:return 'geopolitics_event_category'
    if NATIONAL.search(context):return 'national_government_election_or_policy'
    if event_tags.intersection({144,1597}) and re.search(r'\b(election|president|minister|parliament|senate|congress)\b',context,re.I):
        return 'national_election_event'
    return None


def catalog(workers=8):
    original=json.loads((ROOT/'results/rolling_market_catalog.json').read_text())
    markets={m['conditionId']:m for m in original}
    original_ids=set(markets)
    api=LayeredAPI(workers)
    lock=threading.Lock()
    seen_events=set()
    done=[]
    errors=[]
    audit={}
    last=time.monotonic()

    def one(tag):
        nonlocal last
        cursor=None
        cursors=set()
        pages=0
        while True:
            params=dict(tag_id=tag,related_tags='true',limit=100,order='id',ascending='true',
                end_date_min=b.iso(BACKUP_START),start_date_max=b.iso(TEST_END))
            if cursor:params['after_cursor']=cursor
            payload=api.get(b.GAMMA,'/events/keyset',params)
            events=payload.get('events')
            if not isinstance(events,list):raise b.DataError('Invalid event catalog payload')
            with lock:
                for event in events:
                    seen_events.add(event['id'])
                    for m in event.get('markets',[]):
                        c=m.get('conditionId')
                        if not c or not m.get('createdAt') or b.stamp(m['createdAt'])>=TEST_END:continue
                        if not m.get('clobTokenIds'):continue
                        reason=classify(m,event,tag)
                        if reason is None:continue
                        enriched=dict(m)
                        enriched['events']=[{k:v for k,v in event.items() if k!='markets'}]
                        enriched['discovery_tag_ids']=sorted({tag}|set(markets.get(c,{}).get('discovery_tag_ids',[])))
                        enriched['expanded_scope_reason']=reason
                        markets[c]=enriched
                        audit[c]=dict(condition_id=c,market_id=m.get('id'),question=m.get('question'),
                            event_title=event.get('title'),scope_reason=reason,
                            queried_category=TAGS[tag],is_new=c not in original_ids)
                if time.monotonic()-last>=15:
                    progress=dict(status='DISCOVERING',original_markets=len(original_ids),
                        expanded_markets=len(markets),new_markets=len(set(markets)-original_ids),
                        events_examined=len(seen_events),completed_categories=done,new_api_requests=api.requests)
                    dump('expanded_discovery_progress.json',progress);b.log(json.dumps(progress));last=time.monotonic()
            pages+=1
            cursor=payload.get('next_cursor')
            if not cursor:break
            if cursor in cursors:raise b.DataError('Repeated Gamma cursor')
            cursors.add(cursor)
        return dict(tag=tag,category=TAGS[tag],pages=pages)

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures={pool.submit(one,tag):tag for tag in TAGS}
        for future in concurrent.futures.as_completed(futures):
            try:done.append(future.result())
            except Exception as e:errors.append(dict(tag=futures[future],error=str(e)))
    if errors:
        dump('expanded_discovery_errors.json',errors)
        raise b.DataError('Expanded category discovery incomplete')
    ordered=sorted(markets.values(),key=lambda m:(m.get('createdAt',''),m['conditionId']))
    dump('expanded_market_catalog.json',ordered)
    with (OUT/'expanded_market_scope.csv').open('w',newline='',encoding='utf-8') as f:
        rows=sorted(audit.values(),key=lambda r:r['condition_id'])
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    result=dict(status='COMPLETE',original_markets=len(original_ids),expanded_markets=len(markets),
        new_markets=len(set(markets)-original_ids),events_examined=len(seen_events),categories=done,
        scope='Macro/geopolitical subjects and national government/election events; no wallet, volume or profitability cap.')
    dump('expanded_discovery_summary.json',result);b.log(json.dumps(result))


def collect(workers=12,max_accounts=None):
    limit_path=OUT/'expanded_collection_limit.json'
    if max_accounts is not None:
        if max_accounts<=0:raise ValueError('Account limit must be positive')
        dump('expanded_collection_limit.json',dict(max_accounts=max_accounts,stop_metric='unique_accounts'))
    elif limit_path.exists():max_accounts=json.loads(limit_path.read_text()).get('max_accounts')
    (OUT/'expanded_collection_summary.json').unlink(missing_ok=True)
    catalog=json.loads((OUT/'expanded_market_catalog.json').read_text())
    original={m['conditionId'] for m in json.loads((ROOT/'results/rolling_market_catalog.json').read_text())}
    jobs=[m for m in catalog if m['conditionId'] not in original]
    api=LayeredAPI(workers,requests_per_second=18)
    db=sqlite3.connect(OUT/'expanded_market_trades.sqlite',check_same_thread=False)
    db.execute('PRAGMA journal_mode=WAL');db.execute('PRAGMA synchronous=NORMAL')
    db.execute('PRAGMA cache_size=-524288')
    db.execute('PRAGMA wal_autocheckpoint=50000')
    db.execute('CREATE TABLE IF NOT EXISTS completed(condition TEXT PRIMARY KEY,rows INTEGER,earliest INTEGER)')
    db.execute('CREATE TABLE IF NOT EXISTS checkpoints(condition TEXT PRIMARY KEY,cursor TEXT,rows INTEGER,earliest INTEGER)')
    if 'page_offset' not in {r[1] for r in db.execute('PRAGMA table_info(checkpoints)')}:
        db.execute('ALTER TABLE checkpoints ADD COLUMN page_offset INTEGER NOT NULL DEFAULT 0')
    db.execute('''CREATE TABLE IF NOT EXISTS trades(
        wallet TEXT, ts INTEGER, token TEXT, side TEXT, tx TEXT, condition TEXT,
        size REAL, price REAL, cash REAL, title TEXT, outcome TEXT, outcome_index INTEGER,
        PRIMARY KEY(wallet,ts,token,side,tx)) WITHOUT ROWID''')
    db.execute('CREATE INDEX IF NOT EXISTS trades_condition ON trades(condition)');db.commit()
    accounts=AccountRegistry(db)
    dump('expanded_account_count.json',accounts.snapshot('COLLECTION_IN_PROGRESS',max_accounts))
    insert='''INSERT INTO trades VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(wallet,ts,token,side,tx) DO UPDATE SET
        price=(trades.price*trades.size+excluded.price*excluded.size)/(trades.size+excluded.size),
        size=trades.size+excluded.size,cash=trades.cash+excluded.cash'''
    lock=threading.Lock()
    stopped=threading.Event()
    total_raw=0
    timings=collections.Counter()
    previously_collected=(db.execute('SELECT COALESCE(sum(rows),0) FROM completed').fetchone()[0]+
        db.execute('SELECT COALESCE(sum(rows),0) FROM checkpoints').fetchone()[0])
    if max_accounts is not None and len(accounts.known)>=max_accounts:stopped.set()
    done=[]
    errors=[]
    last=time.monotonic()
    completed_ids={r[0] for r in db.execute('SELECT condition FROM completed')}
    checkpoint_ids={r[0] for r in db.execute('SELECT condition FROM checkpoints')}
    visited_ids=completed_ids|checkpoint_ids
    seen_cursors=collections.defaultdict(set)
    # Breadth first: visit previously untouched markets before returning to deep
    # pages in large markets. Resume every feed; no market or account is dropped.
    pending=collections.deque([m for m in jobs if m['conditionId'] not in visited_ids]+
        [m for m in jobs if m['conditionId'] in checkpoint_ids])
    def one(m):
        nonlocal total_raw
        condition=m['conditionId']
        with lock:
            if stopped.is_set():return None
            old=db.execute('SELECT rows,earliest FROM completed WHERE condition=?',(condition,)).fetchone()
            if old:return dict(condition=condition,rows=old[0],earliest=old[1],reused=True)
            checkpoint=db.execute('SELECT cursor,rows,earliest,page_offset FROM checkpoints WHERE condition=?',(condition,)).fetchone()
            if checkpoint:cursor,count,earliest,page_offset=checkpoint
            else:
                db.execute('DELETE FROM trades WHERE condition=?',(condition,));db.commit()
                cursor=None;count=0;earliest=None;page_offset=0
        seen=set()
        while True:
            if stopped.is_set():return None
            params=dict(condition=condition,limit=1000,taker_only='false')
            if cursor:params['cursor']=cursor
            started=time.monotonic()
            payload=api.get(b.DATA,'/v2/trades',params)
            downloaded=time.monotonic()
            page=payload.get('data')
            if not isinstance(page,list):raise b.DataError('Invalid trade feed')
            rows=[]
            for raw in page:
                e=b.Event.parse(raw)
                # Retain earlier observable opening history too; the screening
                # lookback and simulation still use their fixed two-year dates.
                if e.ts>=TEST_END or e.size<=0:continue
                rows.append((e.wallet,e.ts,e.token,e.side,e.tx,e.condition,e.size,e.price,e.cash,e.title,e.outcome,e.outcome_index))
            rows=rows[page_offset:]
            pagination=payload.get('pagination',{})
            following=pagination.get('next_cursor')
            if pagination.get('has_more') and not following:raise b.DataError('Trade feed has_more without cursor')
            if following and (following==cursor or following in seen_cursors[condition] or not page):
                raise b.DataError('Repeated or empty trade page')
            parsed=time.monotonic()
            with lock:
                acquired=time.monotonic()
                if stopped.is_set():return None
                if max_accounts is not None and len(accounts.known)>=max_accounts:
                    stopped.set();return None
                retained=accounts.trim_at_limit(rows,max_accounts)
                partial=len(retained)<len(rows)
                rows=retained
                count+=len(rows)
                for record in rows:earliest=record[1] if earliest is None else min(earliest,record[1])
                try:
                    new_wallets=accounts.stage(rows)
                    # Match primary-key order to reduce random B-tree page visits.
                    # Keep the feed order above for exact account-cap checkpoints.
                    db.executemany(insert,sorted(rows,key=lambda r:r[:5]))
                    if partial:
                        db.execute('INSERT OR REPLACE INTO checkpoints VALUES(?,?,?,?,?)',
                            (condition,cursor,count,earliest,page_offset+len(rows)))
                    elif following:
                        db.execute('INSERT OR REPLACE INTO checkpoints VALUES(?,?,?,?,?)',(condition,following,count,earliest,0))
                    else:
                        db.execute('INSERT OR REPLACE INTO completed VALUES(?,?,?)',(condition,count,earliest))
                        db.execute('DELETE FROM checkpoints WHERE condition=?',(condition,))
                    db.commit()
                except Exception:
                    db.rollback();raise
                accounts.committed(new_wallets);total_raw+=len(rows)
                timings.update(pages=1,download_seconds=downloaded-started,
                    parse_seconds=parsed-downloaded,write_wait_seconds=acquired-parsed,
                    write_seconds=time.monotonic()-acquired)
                if max_accounts is not None and len(accounts.known)>=max_accounts:stopped.set()
            if partial:return None
            if not following:break
            seen_cursors[condition].add(following)
            # A saved next-page cursor is the resumable work item. Requeue at the
            # back so old high-volume markets cannot monopolize discovery.
            return dict(condition=condition,continue_feed=True)
        return dict(condition=condition,rows=count,earliest=earliest,reused=False)
    b.log(f'Collecting all observed wallets in {len(jobs):,} additional macro/geopolitical markets')
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures={}
        while futures or (pending and not stopped.is_set()):
            while pending and len(futures)<workers*2 and not stopped.is_set():
                market=pending.popleft();futures[pool.submit(one,market)]=market
            ready,_=concurrent.futures.wait(futures,timeout=1,return_when=concurrent.futures.FIRST_COMPLETED)
            for f in ready:
                market=futures.pop(f)
                if f.cancelled():continue
                try:
                    result=f.result()
                    if result is not None:
                        if result.get('continue_feed'):pending.append(market)
                        else:done.append(result)
                except Exception as e:
                    detail=dict(condition=market['conditionId'],error=str(e))
                    errors.append(detail)
                    dump('expanded_collection_errors.json',errors)
                    b.log('Collection retry needed: '+json.dumps(detail))
            if stopped.is_set():
                for future in futures:future.cancel()
            if time.monotonic()-last>=15 or (not futures and not pending):
                status='CAPPED' if stopped.is_set() else ('COLLECTING' if futures or pending else ('COMPLETE' if not errors else 'INCOMPLETE'))
                with lock:
                    completed_count=db.execute('SELECT count(*) FROM completed').fetchone()[0]
                    snapshot=accounts.snapshot(status,max_accounts)
                dump('expanded_account_count.json',snapshot)
                progress=dict(snapshot,completed_markets=completed_count,total_new_markets=len(jobs),
                    errors=len(errors),new_api_requests=api.requests,
                    timing_totals=dict(timings))
                dump('expanded_collection_progress.json',progress);b.log(json.dumps(progress));last=time.monotonic()
    partial_feeds=[dict(condition=r[0],collected_rows=r[1]) for r in db.execute('SELECT condition,rows FROM checkpoints')]
    completed_count=db.execute('SELECT count(*) FROM completed').fetchone()[0]
    final_status='INCOMPLETE' if errors else ('CAPPED' if stopped.is_set() else 'COMPLETE')
    dump('expanded_account_count.json',accounts.snapshot(final_status,max_accounts))
    dump('expanded_collection_summary.json',dict(status=final_status,
        completed_markets=completed_count,total_new_markets=len(jobs),completed=done,errors=errors,
        total_collected_raw_trade_rows=previously_collected+total_raw,account_limit=max_accounts,
        total_unique_accounts=len(accounts.known),stop_metric='unique_accounts',
        partial_market_feeds=partial_feeds,untouched_market_feeds=len(jobs)-completed_count-len(partial_feeds)))
    db.close()


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['catalog','collect'])
    p.add_argument('--workers',type=int,default=8)
    p.add_argument('--max-accounts',type=int);args=p.parse_args()
    if args.stage=='catalog':catalog(args.workers)
    else:collect(args.workers,args.max_accounts)
