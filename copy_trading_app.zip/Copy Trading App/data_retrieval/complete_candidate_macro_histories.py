"""Complete shortlisted macro books when account-capped discovery leaves partial feeds.

Only wallets that already passed the two cheap activity filters are downloaded.
This fills their observable histories; it adds no account-selection rule.
"""
from __future__ import annotations

import argparse
import collections
import concurrent.futures
import csv
import hashlib
import json
import sqlite3
import threading
import time
import zlib

import rolling_copy_backtest as b
from all_macro_prepare import candidate_dates
from macro_universe_data import ROOT,OUT,BACKUP_START,TEST_START,TEST_END,LayeredAPI,dump,load_markets


def main(workers=16,prefetch_only=False,follow=False):
    prefetch_path=OUT/'candidate_history_prefetch.json'
    if not prefetch_only:
        while prefetch_path.exists() and json.loads(prefetch_path.read_text()).get('status')=='RUNNING':
            time.sleep(2)
    collection=json.loads((OUT/'expanded_collection_summary.json').read_text())
    if collection['status'] not in ('CAPPED','STOPPED_BY_USER'):
        b.log('Market feeds are complete; reuse their existing account trade histories')
        return
    conditions={m['conditionId'] for m in load_markets()}
    scope=hashlib.sha256('\n'.join(sorted(conditions)).encode()).hexdigest()
    inputs=sqlite3.connect(OUT/'candidate_inputs.sqlite')
    cache=sqlite3.connect(OUT/'complete_candidate_histories.sqlite')
    cache.execute('PRAGMA journal_mode=WAL')
    cache.execute('CREATE TABLE IF NOT EXISTS histories(wallet TEXT PRIMARY KEY,scope TEXT,end INTEGER,body BLOB) WITHOUT ROWID')
    cache.commit()
    wallets=[w for w, in inputs.execute('SELECT wallet FROM candidates')]
    done={w for w, in cache.execute('SELECT wallet FROM histories WHERE scope=? AND end=?',(scope,TEST_END))}
    api=LayeredAPI(workers,requests_per_second=18)
    errors=[]
    finished=len(done.intersection(wallets))
    last=time.monotonic()
    partial=sorted(r['condition'] for r in collection.get('partial_market_feeds',[]))
    partial_set=set(partial)
    local=threading.local()
    if prefetch_only:dump('candidate_history_prefetch.json',dict(status='RUNNING'))

    def activity_finished():
        summary=json.loads((OUT/'activity_screen_summary.json').read_text())
        return summary.get('status')=='COMPLETE' and summary.get('accounts_examined')==collection['total_unique_accounts']

    def scoped_history(wallet,name):
        # A long whole-wallet feed can be dominated by unrelated markets. Reuse
        # all complete macro feeds, and fill every partial macro feed directly.
        # This is an equivalent data path, not a trading/history eligibility cap.
        if not hasattr(local,'sources'):
            paths=[ROOT/'rolling_discovery.sqlite',OUT/'older_macro_trades.sqlite',OUT/'expanded_market_trades.sqlite']
            local.sources=[sqlite3.connect(f'file:{p.as_posix()}?mode=ro',uri=True) for p in paths]
            local.economics=sqlite3.connect(f'file:{(OUT/"account_economics.sqlite").as_posix()}?mode=ro',uri=True)
        grouped={}
        def add(row):
            key=tuple(row[:5]);old=grouped.get(key)
            if old is None:grouped[key]=row
            else:
                size=old[6]+row[6]
                grouped[key]=(*old[:6],size,(old[6]*old[7]+row[6]*row[7])/size,old[8]+row[8],*old[9:])
        for connection in local.sources:
            for row in connection.execute('SELECT * FROM trades WHERE wallet=? AND ts<?',(wallet,TEST_END)):
                if row[5] not in partial_set:add(row)
        params=dict(user=wallet,start=1,end=TEST_END-1,sort_direction='ASC',
            limit=1000,exclude_deposits_withdrawals='false')
        for i in range(0,len(partial),20):
            query=dict(params,condition=','.join(partial[i:i+20]),type='TRADE')
            for page in api.pages('/v2/activity',query):
                for raw in page:
                    e=b.Event.parse(raw)
                    if e.kind=='TRADE' and e.condition in partial_set and e.ts<TEST_END and e.size>0:
                        add((e.wallet,e.ts,e.token,e.side,e.tx,e.condition,e.size,e.price,e.cash,e.title,e.outcome,e.outcome_index))
                        name=name or raw.get('name') or raw.get('pseudonym') or ''
        hit=local.economics.execute('SELECT body FROM accounts WHERE wallet=?',(wallet,)).fetchone()
        if hit:
            economic=json.loads(zlib.decompress(hit[0]));actions=economic['actions']
            name=name or economic.get('name','')
        else:
            actions=[]
            for page in api.pages('/v2/activity',dict(params,type='SPLIT,MERGE,REDEEM,CONVERSION')):
                actions.extend(r for r in page if r.get('type') in ('SPLIT','MERGE','REDEEM','CONVERSION'))
        return dict(wallet=wallet,name=name,rows=sorted(grouped.values(),key=lambda r:r[1]),actions=actions)

    def fetch(wallet):
        grouped={}
        actions=[]
        name=''
        params=dict(user=wallet,start=1,end=TEST_END-1,sort_direction='ASC',
            limit=1000,exclude_deposits_withdrawals='false')
        for page_number,page in enumerate(api.pages('/v2/activity',params),1):
            if page_number>8:
                body=scoped_history(wallet,name)
                return wallet,zlib.compress(json.dumps(body,separators=(',',':')).encode(),3)
            for raw in page:
                e=b.Event.parse(raw)
                name=name or raw.get('name') or raw.get('pseudonym') or ''
                if e.ts>=TEST_END:continue
                if e.kind in ('SPLIT','MERGE','REDEEM','CONVERSION'):
                    actions.append(raw)
                if e.kind!='TRADE' or e.condition not in conditions or e.size<=0:continue
                row=(e.wallet,e.ts,e.token,e.side,e.tx,e.condition,e.size,e.price,e.cash,e.title,e.outcome,e.outcome_index)
                key=row[:5]
                old=grouped.get(key)
                if old is None:grouped[key]=row
                else:
                    size=old[6]+row[6]
                    grouped[key]=(*old[:6],size,(old[6]*old[7]+row[6]*row[7])/size,old[8]+row[8],*old[9:])
        body=dict(wallet=wallet,name=name,rows=sorted(grouped.values(),key=lambda r:r[1]),actions=actions)
        return wallet,zlib.compress(json.dumps(body,separators=(',',':')).encode(),3)

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        pending=iter(w for w in wallets if w not in done)
        observed=set(wallets)
        futures={}
        exhausted=False
        while True:
            if exhausted and follow:
                fresh=[w for w, in inputs.execute('SELECT wallet FROM candidates') if w not in observed]
                if fresh:
                    wallets.extend(fresh);observed.update(fresh)
                    pending=iter(w for w in fresh if w not in done);exhausted=False
            while len(futures)<workers*2 and not exhausted:
                wallet=next(pending,None)
                if wallet is None:exhausted=True
                else:futures[pool.submit(fetch,wallet)]=wallet
            if not futures:
                if not follow or activity_finished():break
                time.sleep(2)
                continue
            ready,_=concurrent.futures.wait(futures,timeout=1,return_when=concurrent.futures.FIRST_COMPLETED)
            for future in ready:
                wallet=futures.pop(future)
                try:
                    wallet,body=future.result()
                    cache.execute('INSERT OR REPLACE INTO histories VALUES(?,?,?,?)',(wallet,scope,TEST_END,body))
                    finished+=1
                except Exception as exc:errors.append(dict(wallet=wallet,error=str(exc)))
            if time.monotonic()-last>=15:
                cache.commit()
                progress=dict(status='COMPLETING_CANDIDATE_HISTORIES',completed_accounts=finished,
                    candidate_accounts=len(wallets),errors=len(errors),new_api_requests=api.requests)
                dump('candidate_history_progress.json',progress);b.log(json.dumps(progress));last=time.monotonic()
    cache.commit()
    if prefetch_only:
        dump('candidate_history_prefetch.json',dict(status='COMPLETE' if not errors else 'RETRY_NEEDED',
            completed_accounts=finished,candidate_accounts=len(wallets),errors=errors))
        cache.close();inputs.close()
        return
    if errors:
        dump('candidate_history_errors.json',errors)
        raise b.DataError(f'{len(errors)} shortlisted account histories need a resumable retry')

    economics=sqlite3.connect(OUT/'account_economics.sqlite')
    economics.execute('PRAGMA journal_mode=WAL')
    economics.execute('CREATE TABLE IF NOT EXISTS accounts(wallet TEXT PRIMARY KEY,body BLOB) WITHOUT ROWID')
    patches={}
    counts=collections.Counter()
    retained=[]
    windows=0
    for wallet in wallets:
        hit=cache.execute('SELECT body FROM histories WHERE wallet=? AND scope=? AND end=?',(wallet,scope,TEST_END)).fetchone()
        full=json.loads(zlib.decompress(hit[0]))
        rows=full['rows']
        dates=candidate_dates(rows)
        count=sum(BACKUP_START<=r[1]<TEST_END for r in rows)
        active=len({r[1]//b.DAY for r in rows if BACKUP_START<=r[1]<TEST_END})
        patches[wallet]=dict(macro_trades=count,active_days_in_two_years=active,candidate_reset_dates=len(dates),
            screen_status='NEEDS_PERFORMANCE_AND_STYLE_SCREEN' if dates else 'NO_DATE_PASSES_30_OF_40_AND_AVERAGE_BELOW_50')
        if not dates:
            inputs.execute('DELETE FROM candidates WHERE wallet=?',(wallet,))
            continue
        retained.append(wallet);counts.update(dates);windows+=len(dates)
        source=dict(wallet=wallet,rows=rows,dates=dates)
        inputs.execute('INSERT OR REPLACE INTO candidates VALUES(?,?)',
            (wallet,zlib.compress(json.dumps(source,separators=(',',':')).encode(),3)))
        economic=dict(wallet=wallet,name=full['name'],points=[],actions=full['actions'])
        economics.execute('INSERT OR REPLACE INTO accounts VALUES(?,?)',
            (wallet,zlib.compress(json.dumps(economic,separators=(',',':')).encode(),3)))
    inputs.commit();economics.commit()
    path=OUT/'all_account_activity_screen.csv';temp=path.with_suffix('.csv.tmp')
    observed_trade_decisions=0
    with path.open(newline='',encoding='utf-8') as src,temp.open('w',newline='',encoding='utf-8') as dst:
        reader=csv.DictReader(src);writer=csv.DictWriter(dst,fieldnames=reader.fieldnames);writer.writeheader()
        for row in reader:
            if row['wallet'] in patches:row.update(patches[row['wallet']])
            observed_trade_decisions+=int(row['macro_trades'])
            writer.writerow(row)
    temp.replace(path)
    (OUT/'priority_accounts.txt').write_text(''.join(w+'\n' for w in retained))
    with (OUT/'reset_activity_counts.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['reset_utc','accounts_passing_activity_and_frequency'])
        writer.writerows((b.iso(at),counts[at]) for at in range(TEST_START,TEST_END,b.DAY))
    summary=json.loads((OUT/'activity_screen_summary.json').read_text())
    summary.update(initial_activity_candidates=len(wallets),
        macro_trade_decisions=observed_trade_decisions,
        accounts_passing_activity_and_frequency_at_any_reset=len(retained),qualifying_account_dates=windows,
        candidate_history_basis='Complete available account activity, macro/geopolitical trades only; fetched after the two initial activity checks.')
    dump('activity_screen_summary.json',summary)
    dump('candidate_history_summary.json',dict(status='COMPLETE',completed_accounts=finished,
        candidates_before_completion=len(wallets),candidates_after_activity_recheck=len(retained)))
    inputs.close();cache.close();economics.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--workers',type=int,default=16)
    parser.add_argument('--prefetch-only',action='store_true')
    parser.add_argument('--follow',action='store_true')
    args=parser.parse_args()
    if args.follow and not args.prefetch_only:parser.error('--follow requires --prefetch-only')
    try:main(args.workers,args.prefetch_only,args.follow)
    except BaseException:
        if args.prefetch_only:dump('candidate_history_prefetch.json',dict(status='RETRY_NEEDED'))
        raise
