# Copy Trading App — Runtime Workspace

Run `python prepare_project.py` from the project root to assemble executable source
here with the original relative paths. Then run the historical preparation stages
in [Data retrieval](../../data_retrieval/README.md).

No historical observations or portfolio state are present initially. Source
assembly alone does not make the data-dependent app ready. The generated app
entry point will be `polymarket_mock_app/server.py`; research outputs will be in
`results_all_accounts_macro/`. Use the project-root launcher after
`python prepare_project.py --check-ready` passes.
