# Copy Trading App — Data Storage

`runtime/` starts without historical or user data. `prepare_project.py` assembles
the original executable source layout there. Data preparation then creates the
SQLite schemas and, through actual collection/simulation, the historical inputs.
See [setup](../README.md) and [data preparation](../data_retrieval/README.md).

The generated runtime has sibling research modules and a `polymarket_mock_app`
directory, which preserves the app's `ROOT`, `HISTORY`, import and launcher paths.
Research outputs live at `runtime/results_all_accounts_macro`; app state lives at
`runtime/polymarket_mock_app/data`. All histories, quotes, selections, transaction
records, credentials entered in memory, and portfolio accounting belong to the
local user's environment. The `.gitignore` prevents runtime contents being added
to source control by default.

Stop processes before moving or restoring their storage. Back up SQLite with its
backup API or after a clean shutdown; copying a live database without its WAL can
lose committed observations. Do not delete a ledger to fix an unresolved live
order. Reconcile the order against the exchange through the app.

Fresh data retrieval cannot guarantee recovery of every historical observation
that was available during the original research. The readiness check verifies
necessary files and schemas; it does not certify full historical completeness.
