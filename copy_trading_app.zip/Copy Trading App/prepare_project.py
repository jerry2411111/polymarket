"""Assemble the original relative-path layout inside local data storage."""
from pathlib import Path
import argparse
import ast
import csv
import gzip
import json
import shutil
import sqlite3
import sys

ROOT=Path(__file__).resolve().parent
RUNTIME=ROOT/'data_storage'/'runtime'
HISTORY=RUNTIME/'results_all_accounts_macro'
DEFAULT='effective_effective_range_3_4_reset75_vol365'


def assemble():
    if sys.version_info < (3,14):
        raise RuntimeError('Use Python 3.14 or later; the collectors use Executor.map(buffersize=...).')
    RUNTIME.mkdir(parents=True,exist_ok=True)
    for folder in ('data_retrieval','final_simulation'):
        for source in (ROOT/folder).glob('*.py'):
            if source.name=='prepare_history.py':continue
            shutil.copy2(source,RUNTIME/source.name)
    app=RUNTIME/'polymarket_mock_app';app.mkdir(exist_ok=True)
    for source in (ROOT/'app').iterdir():
        if source.is_file() and source.suffix in ('.py','.html','.js','.css','.ps1','.cmd','.txt','.md'):
            shutil.copy2(source,app/source.name)
    for folder in (app/'data',HISTORY,HISTORY/'simulations',HISTORY/'reports',
                   HISTORY/'reports_returns',RUNTIME/'results'):
        folder.mkdir(parents=True,exist_ok=True)
    print('Runtime source assembled at data_storage/runtime. No historical data was fabricated.')
    print('Next: python data_retrieval/prepare_history.py init')


def check_ready():
    """Read-only readiness check; never construct the app or start a network feed."""
    expected=[HISTORY/'strategy_results.json',HISTORY/'macro_markets_for_returns.json',
              HISTORY/'complete_candidate_histories.sqlite',HISTORY/'candidate_inputs.sqlite',
              HISTORY/'account_economics.sqlite',RUNTIME/'polymarket_mock_app'/'server.py']
    missing=[str(p.relative_to(ROOT)) for p in expected if not p.exists()]
    if missing:
        raise RuntimeError('Prepare historical inputs first. Missing:\n'+'\n'.join(missing))
    definition=json.loads(expected[0].read_text(encoding='utf-8'))
    if definition.get('status')!='COMPLETE':
        raise RuntimeError('Historical research is not marked COMPLETE.')
    case=next((c for c in definition['cases'] if c['case_id']==DEFAULT),None)
    if not case:raise RuntimeError('The default configuration is missing from strategy_results.json.')
    for c in definition['cases']:
        for field in ('daily_dataset','accounts_dataset','period_dataset'):
            path=(HISTORY/'simulations'/c[field]).resolve()
            if not path.is_relative_to(HISTORY/'simulations') or not path.is_file():
                raise RuntimeError('Missing replay file for '+c['case_id']+': '+field)
    # The unmodified server uses the last archived followed set for feed probes.
    with gzip.open(HISTORY/'simulations'/case['accounts_dataset'],'rt',newline='',encoding='utf-8') as f:
        if next(csv.DictReader(f),None) is None:
            raise RuntimeError('Default replay has no selected accounts; the existing server needs an archived feed-probe set.')
    for name,table in [('complete_candidate_histories.sqlite','histories'),
                       ('candidate_inputs.sqlite','candidates'),('account_economics.sqlite','accounts')]:
        with sqlite3.connect((HISTORY/name).resolve().as_uri()+'?mode=ro',uri=True) as db:
            db.execute('SELECT 1 FROM '+table+' LIMIT 1').fetchall()
    print('Required historical files and default replay are ready. Authenticated trading is not checked.')


def check_syntax():
    paths=[ROOT/'prepare_project.py',ROOT/'run_checks.py',*list((ROOT/'data_retrieval').glob('*.py')),
           *list((ROOT/'final_simulation').glob('*.py')),*list((ROOT/'app').glob('*.py'))]
    for p in paths:ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p))
    print(f'Python syntax passed for {len(paths)} source files; no data or network required.')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-ready',action='store_true')
    parser.add_argument('--syntax',action='store_true')
    args=parser.parse_args()
    try:
        check_ready() if args.check_ready else check_syntax() if args.syntax else assemble()
    except (OSError,ValueError,RuntimeError,sqlite3.Error) as exc:
        parser.exit(1,str(exc)+'\n')
