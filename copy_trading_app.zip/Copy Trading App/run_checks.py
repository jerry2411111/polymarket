"""Run offline checks, with original-history regression checks opt-in."""
from pathlib import Path
import argparse
import sys
import unittest

ROOT=Path(__file__).resolve().parent
APP=ROOT/'data_storage'/'runtime'/'polymarket_mock_app'
HISTORY_TESTS={
    'test_paper.PaperTests.test_saved_selected_configuration_is_exactly_reused',
    'test_paper.PaperTests.test_engine_reset_realtime_copy_and_failed_quote_are_atomic',
    'test_paper.PaperTests.test_delayed_screen_is_not_backdated_or_used_beyond_its_period',
}


def flatten(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite):yield from flatten(item)
        else:yield item


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--with-original-history',action='store_true',
        help='Also run three tests needing prepared history, including an exact original-result regression.')
    args=parser.parse_args()
    if not (APP/'server.py').is_file():parser.error('Run prepare_project.py first.')
    sys.path.insert(0,str(APP))
    suite=unittest.defaultTestLoader.discover(str(APP),pattern='test_*.py')
    tests=list(flatten(suite))
    omitted=[t.id() for t in tests if t.id() in HISTORY_TESTS and not args.with_original_history]
    if omitted:
        print('Historical-data checks not run (use --with-original-history with the original prepared inputs):',flush=True)
        for name in omitted:print('  '+name,flush=True)
    selected=unittest.TestSuite(t for t in tests if t.id() not in omitted)
    result=unittest.TextTestRunner(verbosity=1).run(selected)
    sys.exit(0 if result.wasSuccessful() else 1)
