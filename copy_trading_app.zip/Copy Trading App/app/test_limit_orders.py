"""Execution routing, partial fills, cash isolation and minute refresh; no network."""
import copy,json,tempfile,time,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch,Mock
from core import Store
from execution import ExecutionRouter,make_plan,LiveBroker
from limit_orders import route_rule,rows,live_matches,midpoint_quote,POLICY

class LimitOrderTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'test.sqlite')
        self.run=self.store.create(dict(reset_days=75),10000)
        self.book=dict(price=.5,bid=.49,ask=.51,bids=[(.49,100000)],asks=[(.51,100000)],timestamp=100,tick_size=.01,min_order_size=5)
        self.router=ExecutionRouter(self.store,SimpleNamespace(book=lambda *args,**kw:copy.deepcopy(self.book)))
        p=dict(token_id='x',current_size=100,title='Iran',outcome='Yes',condition_id='c')
        make_plan(self.run,{'A':dict(positions=[p],inventory_key='a')},{'x':self.book},[dict(wallet='A',name='Alice',weight=1,sigma=.01)],100)
        self.store.save(self.run)
    def tearDown(self):self.tmp.cleanup()
    def test_every_size_and_side_is_limit_including_cached_market_route(self):
        book=dict(ask=.5,bid=.49)
        for reason in ('Observed source position change','Account allocation reset'):
            for side in ('BUY','SELL'):
                for qty in (2,10000,10000.02,1e6):
                    target=dict(reason=reason,price_rules={'x':dict(side=side,kind='market',routing_decided=True)})
                    self.assertEqual(route_rule(target,'x',side,qty,book)['kind'],'passive')
    def test_midpoint_uses_decimal_ticks_without_crossing_ask(self):
        self.assertEqual(midpoint_quote(dict(bid=.57,ask=.59,tick_size=.01),'BUY'),.58)
        self.assertEqual(midpoint_quote(dict(bid=.49,ask=.5,tick_size=.01),'BUY'),.49)
        self.assertEqual(midpoint_quote(dict(bid=.48,ask=.52,tick_size=.01),'BUY'),.5)
        self.assertEqual(midpoint_quote(dict(bid=.49,ask=.5,tick_size=.01),'SELL'),.5)
        self.assertEqual(midpoint_quote(dict(bid=.48,ask=.52,tick_size=.01),'SELL'),.5)
        self.assertIsNone(midpoint_quote(dict(bid=.5,ask=None,tick_size=.01),'BUY'))
    def test_sandbox_fills_exact_midpoint_immediately_without_depth_or_trades(self):
        self.book.update(bid=.49,ask=.5,price=.495,bids=[],asks=[],min_order_size=1e9)
        self.router.execute(self.run)
        fill=self.store.rows('SELECT * FROM fills')[0]
        self.assertEqual(fill['price'],.495)
        self.assertEqual(fill['shares'],20000)
        self.assertEqual(rows(self.router,self.run),[])
        self.assertAlmostEqual(self.run['accounts']['A']['cash'],100)
        self.assertEqual(self.run['limit_order_summary']['reserved_cash'],0)
        restarted=ExecutionRouter(self.store,self.router.market)
        restarted.execute(self.store.run())
        self.assertEqual(len(self.store.rows('SELECT * FROM fills')),1)

    def test_sandbox_sells_at_current_midpoint_without_depth(self):
        self.router.execute(self.run)
        self.run['execution_plan']['targets']['A'].update(shares={},price_rules={})
        self.book.update(bid=.59,ask=.6,price=.595,bids=[],asks=[])
        self.router.execute(self.run)
        self.assertEqual(self.run['accounts']['A']['positions'],{})
        self.assertAlmostEqual(self.run['accounts']['A']['cash'],11900)
        self.assertAlmostEqual(self.store.rows('SELECT * FROM fills ORDER BY id DESC')[0]['price'],.595)

    def test_sandbox_cannot_spend_other_account_cash(self):
        self.run['accounts']['A']['cash']=10;self.run['cash']=9990
        self.router.execute(self.run)
        self.assertAlmostEqual(self.run['accounts']['A']['positions']['x']['shares'],20)
        self.assertEqual(self.run['cash'],9990)
        self.assertEqual(self.run['accounts']['A']['cash'],0)

    def test_sandbox_missing_quote_waits_and_pause_prevents_fill(self):
        self.book.update(bid=None)
        self.router.execute(self.run)
        self.assertFalse(self.run['accounts']['A']['positions'])
        self.book.update(bid=.49)
        self.run['status']='paused';self.router.execute(self.run)
        self.assertFalse(self.run['accounts']['A']['positions'])
        self.run['status']='running';self.router.execute(self.run)
        self.assertTrue(self.run['accounts']['A']['positions'])

    def test_sandbox_discards_legacy_remainder_and_preserves_old_partial_fill(self):
        o=self.fake_live_order()
        self.run['mode']='sandbox'
        from limit_orders import apply_delta
        apply_delta(self.router,self.run,o,dict(shares=2,notional=1,fee=0))
        self.book.update(bid=.39,ask=.41,price=.4)
        self.router.execute(self.run)
        self.assertAlmostEqual(self.run['accounts']['A']['positions']['x']['shares'],20000)
        self.assertEqual(len(self.store.rows('SELECT * FROM fills')),2)
        old=self.store.rows('SELECT state,body FROM execution_orders WHERE id=?',(o['id'],))[0]
        self.assertEqual(old['state'],'limit_cancelled')
        self.assertEqual(json.loads(old['body'])['result']['shares'],2)
        self.assertEqual(rows(self.router,self.run),[])
        self.router.execute(self.store.run())
        self.assertEqual(len(self.store.rows('SELECT * FROM fills')),2)

    def test_sandbox_recovery_of_interrupted_intent_does_not_duplicate(self):
        original_apply=self.router.apply
        with patch.object(self.router,'apply',side_effect=RuntimeError('interrupted before commit')):
            with self.assertRaises(RuntimeError):self.router.execute(self.run)
        self.assertEqual(self.store.rows('SELECT * FROM fills'),[])
        restarted=ExecutionRouter(self.store,self.router.market)
        restarted.execute(self.store.run())
        restarted.execute(self.store.run())
        self.assertEqual(len(self.store.rows('SELECT * FROM fills')),1)
        self.assertEqual(self.store.run()['accounts']['A']['positions']['x']['shares'],20000)

    def test_sandbox_skips_resolved_positions(self):
        self.run['resolved_tokens']={'x':dict(price=1.,timestamp=200)}
        self.router.execute(self.run)
        self.assertEqual(self.store.rows('SELECT * FROM fills'),[])

    def test_live_limit_uses_sdk_limit_not_market_and_no_assumed_fill(self):
        broker=LiveBroker();broker.armed=True
        response=SimpleNamespace(ok=True,order_id='exchange',model_dump=lambda **kw:{})
        broker.client=SimpleNamespace(create_limit_order=Mock(return_value='signed'),create_market_order=Mock(),post_order=Mock(return_value=response))
        result=broker.submit(dict(execution_policy=POLICY,order_type='GTC',side='BUY',token='x',shares=10,limit_price=.5,post_only=True,quote_method='midpoint'),self.book)
        self.assertEqual(result['shares'],0);self.assertEqual(result['state'],'submitted')
        broker.client.create_limit_order.assert_called_once();broker.client.create_market_order.assert_not_called()
        broker.client.create_limit_order.reset_mock()
        broker.submit(dict(execution_policy=POLICY,order_type='GTC',side='SELL',token='x',shares=10,limit_price=.5,post_only=True,quote_method='midpoint'),self.book)
        self.assertEqual(broker.client.create_limit_order.call_args.kwargs['side'],'SELL')
        broker.client.create_market_order.assert_not_called()
        for invalid in (dict(order_type='FAK'),dict(post_only=False),dict(execution_policy='legacy')):
            intent=dict(execution_policy=POLICY,order_type='GTC',side='BUY',token='x',shares=10,limit_price=.5,post_only=True,quote_method='midpoint')
            intent.update(invalid)
            with self.assertRaisesRegex(ValueError,'Market orders are disabled'):broker.submit(intent,self.book)
        broker.client.create_market_order.assert_not_called()

    def fake_live_order(self):
        self.run.update(mode='live',wallet_cash_observed=10000.,wallet_token_observed={'x':0.})
        self.router.live.armed=True
        self.router.live.prepare=lambda intent:None
        self.router.live.submit=Mock(return_value=dict(state='submitted',shares=0.,notional=0.,exchange_order_id='own',confirmed_trade_ids=[]))
        self.router.execute(self.run)
        return rows(self.router,self.run)[0]
    def test_live_maker_partial_fill_is_recorded_once_then_cancelled(self):
        o=self.fake_live_order()
        order=SimpleNamespace(associate_trades=('t',),size_matched=3,status='LIVE')
        maker=SimpleNamespace(order_id='own',matched_amount=3,price=.49,fee_rate_bps=500)
        trade=SimpleNamespace(id='t',taker_order_id='someone_else',status='CONFIRMED',maker_orders=[maker])
        self.router.live.client=SimpleNamespace(get_order=lambda **kw:order,
            list_account_trades=lambda **kw:[trade],get_balance_allowance=lambda **kw:SimpleNamespace(balance=9998530000))
        self.router.live.token_balance=lambda token:3
        self.assertTrue(live_matches(self.router,self.run));self.assertTrue(live_matches(self.router,self.run))
        self.assertEqual(len(self.store.rows('SELECT * FROM fills')),1)
        self.assertEqual(self.run['accounts']['A']['positions']['x']['shares'],3)
        self.assertAlmostEqual(self.run['accounts']['A']['cash'],9998.53)
        order.status='CANCELED';live_matches(self.router,self.run)
        self.assertEqual(rows(self.router,self.run),[])
        self.assertEqual(len(self.store.rows('SELECT * FROM fills')),1)
    def test_live_minute_replacement_waits_for_cancel_confirmation(self):
        o=self.fake_live_order();order=SimpleNamespace(associate_trades=(),size_matched=0,status='LIVE')
        self.router.live.client=SimpleNamespace(get_order=lambda **kw:order,cancel_order=Mock(),
            get_balance_allowance=lambda **kw:SimpleNamespace(balance=10000000000))
        self.router.live.token_balance=lambda token:0;self.router.live.armed=True
        self.router.live.prepare=lambda intent:None
        self.router.live.submit=Mock(return_value=dict(state='submitted',shares=0.,notional=0.,exchange_order_id='replacement'))
        self.book.update(bid=.48,bids=[(.48,100000)])
        with patch('limit_orders.time.time',return_value=o['created']+61):self.router.execute(self.run)
        self.router.live.submit.assert_not_called()
        self.assertEqual(rows(self.router,self.run)[0]['state'],'limit_cancel_requested')
        order.status='CANCELED'
        with patch('limit_orders.time.time',return_value=o['created']+66):self.router.execute(self.run)
        self.router.live.submit.assert_called_once()
        self.assertEqual(rows(self.router,self.run)[0]['intent']['limit_price'],.49)

if __name__=='__main__':unittest.main(verbosity=2)
