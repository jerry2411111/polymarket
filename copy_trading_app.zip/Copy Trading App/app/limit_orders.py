"""Sandbox assumes midpoint fills; real orders use minute-refreshed midpoint limits."""
from __future__ import annotations
import collections,decimal,hashlib,json,math,time,uuid
from core import account_nav,cash_value

POLICY='all_sides_midpoint_limit_60s_v1'
SANDBOX_POLICY='sandbox_assumed_midpoint_v1'
MANAGED_POLICIES=(POLICY,'initial_limit_buy_over_5000_limit_other_market_v1')
REFRESH_SECONDS=60
OPEN=('limit_open','limit_partial','limit_cancel_requested','posting','unknown')

def rounded_price(price,tick,side):
    p=decimal.Decimal(str(price));step=decimal.Decimal(str(tick))
    rounding=decimal.ROUND_FLOOR if side=='BUY' else decimal.ROUND_CEILING
    return float((p/step).to_integral_value(rounding=rounding)*step)

def attach_rules(run):
    """Source trades remain attribution; execution pricing follows order side."""
    for d in run.get('_copy_decisions',[]):
        target=run['execution_plan']['targets'][d['wallet']]
        target['price_rules']={}
        for adj in d['adjustments']:
            token,side=adj['token'],adj['side']
            target['price_rules'][token]=dict(side=side)

def route_rule(target,token,side,qty,book):
    rule=target.setdefault('price_rules',{}).setdefault(token,dict(side=side))
    if rule.get('side')!=side:
        rule=dict(side=side);target['price_rules'][token]=rule
    if rule.get('execution_policy')!=POLICY:
        initial=target.get('reason')=='Account allocation reset'
        reference=book.get('ask') if side=='BUY' else book.get('bid')
        if reference is None:return None
        value=qty*reference
        rule.clear()
        rule.update(side=side,kind='passive',execution_policy=POLICY,
            routing_decided=True,planned_order_value=value,initial_allocation=initial)
    return rule

def midpoint_quote(book,side):
    tick=book.get('tick_size',.01);bid=book.get('bid');ask=book.get('ask')
    if bid is None or ask is None or bid>=ask:return None
    raw=(decimal.Decimal(str(bid))+decimal.Decimal(str(ask)))/2
    value=rounded_price(raw,tick,side)
    valid=0<value<1 and (value<ask if side=='BUY' else value>bid)
    return value if valid else None

def rows(router,run):
    placeholders=','.join('?' for _ in OPEN)
    return [dict(r,**json.loads(r['body'])) for r in router.store.rows(
        'SELECT * FROM execution_orders WHERE run=? AND state IN ('+placeholders+') ORDER BY created,id',
        (run['id'],*OPEN)) if json.loads(r['body']).get('intent',{}).get('execution_policy') in MANAGED_POLICIES]

def remaining(o):return max(0.,o['intent']['shares']-o.get('result',{}).get('shares',0.))

def reservations(open_rows):
    cash=collections.defaultdict(float);shares=collections.defaultdict(float)
    for o in open_rows:
        i=o['intent'];q=remaining(o)
        if i['side']=='BUY':cash[i['wallet']]+=q*i['limit_price']
        else:shares[(i['wallet'],i['token'])]+=q
    return cash,shares

def summary(run,open_rows):
    cash,_=reservations(open_rows)
    sandbox=run.get('mode','sandbox')=='sandbox'
    run['execution_policy']=SANDBOX_POLICY if sandbox else POLICY
    run['limit_order_summary']=dict(open_orders=len(open_rows),reserved_cash=sum(cash.values()),
        reserved_by_account=dict(cash),policy=('Sandbox BUYs and SELLs assume immediate fills at the current bid/ask midpoint.' if sandbox else
            'Every BUY and SELL: post-only GTC limit at the tick-rounded bid/ask midpoint, checked every 60 seconds. No market orders.'),
        refresh_seconds=None if sandbox else REFRESH_SECONDS,
        sandbox_fill_model='Immediate assumed fill at (bid + ask) / 2; no trade-print, depth or queue requirement.')
    run['execution_pending']=[f"{o['intent']['name']}: {o['intent']['side']} {remaining(o):.4f} @ {o['intent']['limit_price']:.4f} limit pending" for o in open_rows[:30]]

def cancel(router,run,reason='Superseded target',all_orders=False,order_ids=None):
    for o in rows(router,run):
        if order_ids is not None and o['id'] not in order_ids:continue
        i=o['intent'];target=run.get('execution_plan',{}).get('targets',{}).get(i['wallet'])
        resolved=i['token'] in run.get('resolved_tokens',{})
        stale=all_orders or resolved or order_ids is not None or i.get('execution_policy')!=POLICY or not target or target.get('source_change_id')!=i.get('source_change_id')
        result=dict(o.get('result',{}));why=reason
        if resolved:why='Market resolved: cancel pending limit'
        if not stale and i.get('order_type')=='GTC' and time.time()-result.get('last_price_check',o['created'])>=REFRESH_SECONDS:
            quote=midpoint_quote(router.market.book(i['token'],fresh=run.get('mode')=='live'),i['side'])
            result['last_price_check']=time.time()
            if quote is not None and abs(quote-i['limit_price'])>1e-10:
                stale=True;why='Minute refresh: replace '+i['side']+' at current bid/ask midpoint'
                rule=target.setdefault('price_rules',{}).get(i['token'],{})
                rule.pop('limit_price',None);rule.pop('priced_at',None)
            else:
                router._put(run,o['id'],o['state'],dict(intent=i,result=result))
        if not stale:continue
        if run.get('mode')=='live':
            if o['state'] in ('posting','unknown'):raise ValueError('Unknown limit-order submission requires reconciliation before replacement.')
            if not router.live.client:continue
            if i.get('order_type')=='FAK':continue  # No resting remainder; reconcile its fills.
            if o['state']!='limit_cancel_requested':
                router.live.client.cancel_order(order_id=result['exchange_order_id'])
                result['reason']=why+'; cancellation requested, checking final fills.'
                router._put(run,o['id'],'limit_cancel_requested',dict(intent=i,result=result))
        else:
            result.update(state='cancelled',reason=why)
            router.store.save(run,order_update=(o['id'],'limit_cancelled',dict(intent=i,result=result)))
    summary(run,rows(router,run));router.store.save(run)
    return not rows(router,run)

def apply_delta(router,run,o,delta,terminal=False,reason=None):
    prior=o.get('result',{});i=o['intent'];q=delta.get('shares',0.);value=delta.get('notional',0.)
    if q:
        current=router.market.book(i['token'])
        delta=dict(delta,mark=current['price'],quote_ts=current['timestamp'])
    total_q=prior.get('shares',0.)+q;total_value=prior.get('notional',0.)+value
    complete=total_q>=i['shares']-1e-8
    state='limit_filled' if complete else 'limit_cancelled' if terminal else 'limit_partial' if total_q else 'limit_open'
    result=dict(prior,state='filled' if complete else 'cancelled' if terminal else 'partial' if total_q else 'open',
        shares=total_q,notional=total_value,price=total_value/total_q if total_q else i['limit_price'],
        fee=prior.get('fee',0.)+delta.get('fee',0.),partial=bool(total_q and not complete),
        simulated=run.get('mode','sandbox')=='sandbox',reason=reason or ('Filled at limit or better.' if complete else 'Waiting for liquidity at limit or better.'))
    if 'confirmed_trade_ids' in delta:result['confirmed_trade_ids']=delta['confirmed_trade_ids']
    router.apply(run,o['id'],i,dict(delta,price=value/q if q else i['limit_price']),journal_state=state,journal_result=result)

def sandbox_execute(router,run):
    """Fill only outstanding target differences, at the current unrounded midpoint.

    Old simulated resting orders are cancelled without rewriting their fills.
    The journal and holdings update atomically, so resume cannot buy them twice.
    """
    if run.get('mode','sandbox')!='sandbox':
        raise ValueError('Assumed fills are available only in sandbox mode.')
    if not router.reconcile_active(run):return
    previous=run.get('execution_policy')
    cancel(router,run,'Sandbox changed to immediate midpoint fills; replace unfilled targets',all_orders=True)
    run.pop('sandbox_limit_depth',None)
    if previous!=SANDBOX_POLICY:
        router.store.log('Sandbox now assumes immediate BUY and SELL fills at the current bid/ask midpoint. Existing holdings and past fills retained.',run_id=run['id'])
    summary(run,[])
    if run['status']!='running' or router.halt.is_set():
        router.store.save(run);return
    plan=run.get('execution_plan')
    if not plan:return
    jobs=[];notes=[]
    for wallet,target in plan['targets'].items():
        a=run['accounts'][wallet]
        for token in set(a['positions'])|set(target['shares']):
            delta=target['shares'].get(token,0)-a['positions'].get(token,{}).get('shares',0)
            if abs(delta)>1e-8:jobs.append((delta>0,wallet,token,abs(delta),'BUY' if delta>0 else 'SELL'))
    # SELL proceeds are available only to their own followed-account slice.
    for _,wallet,token,qty,side in sorted(jobs):
        if router.halt.is_set():break
        a=run['accounts'][wallet];target=plan['targets'][wallet]
        if a['positions'].get(token,{}).get('settled') or token in run.get('resolved_tokens',{}):continue
        try:book=router.market.book(token)
        except ValueError:
            notes.append(a['name']+': waiting for a current bid/ask midpoint');continue
        bid,ask=book.get('bid'),book.get('ask')
        if (book.get('settled') or bid is None or ask is None
                or not math.isfinite(bid) or not math.isfinite(ask) or not 0<=bid<=ask<=1):
            notes.append(a['name']+': waiting for a current bid/ask midpoint');continue
        price=float((decimal.Decimal(str(bid))+decimal.Decimal(str(ask)))/2)
        if not 0<price<1:continue
        cash=max(0.,min(cash_value(run),a['cash']))
        qty=min(qty,cash/price) if side=='BUY' else min(qty,a['positions'].get(token,{}).get('shares',0.))
        if qty<=1e-8:
            notes.append(a['name']+': waiting for cash in its own allocation');continue
        meta=target['metadata'].get(token,a['positions'].get(token,{}))
        intent=dict(wallet=wallet,name=a['name'],token=token,side=side,shares=qty,
            title=meta.get('title',''),outcome=meta.get('outcome',''),condition_id=meta.get('condition_id',''),
            limit_price=price,cash_limit=cash,mark=price,quote_ts=book['timestamp'],reason=target['reason'],
            plan_id=plan['id'],source_change_id=target.get('source_change_id'),execution_policy=SANDBOX_POLICY,
            order_type='SIMULATED',post_only=False,price_basis='assumed_midpoint',quote_method='midpoint',
            planned_order_value=qty*price,initial_allocation=target.get('reason')=='Account allocation reset',
            observed_bid=bid,observed_ask=ask)
        oid=uuid.uuid4().hex
        run['active_order']=oid
        router.store.save(run,order_insert=(oid,'posting',dict(intent=intent)))
        router.apply(run,oid,intent,dict(state='filled',shares=qty,notional=qty*price,price=price,
            fee=0.,simulated=True,mark=price,quote_ts=book['timestamp'],
            reason='Assumed immediate sandbox fill at the current bid/ask midpoint.'))
    summary(run,[]);run['execution_pending']=notes[:30];router.store.save(run,point=True)

def live_matches(router,run):
    """Reconcile all own maker/taker fills as a batch before submitting more."""
    pending=rows(router,run)
    if not pending:return True
    if not router.live.client:return False
    if any(o['state'] in ('posting','unknown') for o in pending):
        raise ValueError('A limit-order submission outcome is unknown. Attach its exchange order ID before continuing.')
    changes=[];unconfirmed=False
    for o in pending:
        i=o['intent'];r=o.get('result',{});eid=r['exchange_order_id']
        order=router.live.client.get_order(order_id=eid)
        ids=set(order.associate_trades)|set(r.get('response',{}).get('trade_ids',[]))
        seen=set(r.get('confirmed_trade_ids',[]));q=amount=fee=0.
        for tid in ids-seen:
            trades=[t for t in router.live.client.list_account_trades(id=tid) if str(t.id)==str(tid)]
            if not trades:unconfirmed=True;continue
            t=trades[0]
            if str(t.status).upper()=='FAILED':continue
            if str(t.status).upper()!='CONFIRMED':unconfirmed=True;continue
            if str(t.taker_order_id)==eid:
                qty,p,rate=float(t.size),float(t.price),float(t.fee_rate_bps)
            else:
                legs=[m for m in t.maker_orders if str(m.order_id)==eid]
                if not legs:raise ValueError('Confirmed trade lacks the tracked maker order.')
                m=legs[0];qty,p,rate=float(m.matched_amount),float(m.price),0.
                # Polymarket charges platform fees to takers only. A market fee
                # rate carried on the maker leg is not a debit to our maker fill.
            if (i['side']=='BUY' and p>i['limit_price']+1e-8) or (i['side']=='SELL' and p<i['limit_price']-1e-8):raise ValueError('Exchange fill violates saved limit.')
            q+=qty;amount+=qty*p;fee+=round(qty*p*(1-p)*rate/10000,5);seen.add(tid)
        terminal=str(order.status).upper() in ('CANCELED','CANCELLED','UNMATCHED','MATCHED','FILLED')
        # MATCHED is not complete until its associated trades are confirmed.
        if float(order.size_matched)>r.get('shares',0)+q+1e-6:unconfirmed=True;terminal=False
        changes.append((o,dict(shares=q,notional=amount,fee=fee,cash_amount=amount+fee if i['side']=='BUY' else amount-fee,confirmed_trade_ids=sorted(seen)),terminal))
    actual=router.live.client.get_balance_allowance(asset_type='COLLATERAL').balance/1_000_000
    expected=run.get('wallet_cash_observed',router.live.expected_cash)
    if expected is None:raise ValueError('Missing starting wallet collateral observation.')
    cash_delta=sum((-d['cash_amount'] if o['intent']['side']=='BUY' else d['cash_amount']) for o,d,_ in changes)
    if abs(actual-(expected+cash_delta))>max(.00005,.00005*len(changes)):
        if unconfirmed:return False
        raise ValueError('Wallet collateral differs from confirmed limit fills. Reconciliation required.')
    tokens=collections.defaultdict(float)
    for o,d,_ in changes:
        tokens[o['intent']['token']]+=d['shares']*(1 if o['intent']['side']=='BUY' else -1)
    for token,delta in tokens.items():
        prior=run.get('wallet_token_observed',{}).get(token)
        if prior is None:raise ValueError('Missing token balance checkpoint for limit reconciliation.')
        if abs(router.live.token_balance(token)-(prior+delta))>.00005:return False
    # Persist each delta with the corresponding expected collateral step. If the
    # process stops mid-batch, remaining confirmed fills reconcile on restart.
    for o,d,terminal in changes:
        if d['shares'] or terminal:
            run['wallet_cash_observed']=run.get('wallet_cash_observed',expected)+(-d['cash_amount'] if o['intent']['side']=='BUY' else d['cash_amount'])
            token=o['intent']['token'];run['wallet_token_observed'][token]+=d['shares']*(1 if o['intent']['side']=='BUY' else -1)
            apply_delta(router,run,o,d,terminal,reason='Confirmed own maker/taker fills; collateral reconciled across open orders.')
    router.live.cash=actual;router.live.expected_cash=actual
    return not unconfirmed

def maintain(router,run,paused=False):
    cancel(router,run,'Copying paused' if paused else 'Source target superseded',all_orders=paused)
    if run.get('mode')=='live':ready=live_matches(router,run)
    else:
        ready=True
    summary(run,rows(router,run));router.store.save(run)
    return ready

def execute(router,run):
    if run.get('mode','sandbox')=='sandbox':return sandbox_execute(router,run)
    if not router.reconcile_active(run):return
    paused=run['status']!='running' or router.halt.is_set()
    if not maintain(router,run,paused) or paused:return
    live=run.get('mode')=='live'
    if live and not router.live.armed:return
    plan=run.get('execution_plan')
    if not plan:return
    pending=rows(router,run);held_keys={(o['intent']['wallet'],o['intent']['token']) for o in pending}
    reserve,_=reservations(pending);notes=[];jobs=[]
    for w,target in plan['targets'].items():
        a=run['accounts'][w]
        for token in set(a['positions'])|set(target['shares']):
            delta=target['shares'].get(token,0)-a['positions'].get(token,{}).get('shares',0)
            if abs(delta)>1e-8 and (w,token) not in held_keys:jobs.append((delta>0,w,token,abs(delta),'BUY' if delta>0 else 'SELL'))
    for _,w,token,qty,side in sorted(jobs):
        if router.halt.is_set():break
        a=run['accounts'][w];target=plan['targets'][w]
        if a['positions'].get(token,{}).get('settled') or token in run.get('resolved_tokens',{}):continue
        book=router.market.book(token,fresh=live)
        rule=route_rule(target,token,side,qty,book)
        if rule is None:notes.append(a['name']+': waiting for a valid '+side+' quote');continue
        if rule.get('limit_price') is None or rule.get('quote_method')!='midpoint' or time.time()-rule.get('priced_at',0)>=REFRESH_SECONDS:
            rule['limit_price']=midpoint_quote(book,side);rule['priced_at']=time.time();rule['quote_method']='midpoint'
        limit=rule['limit_price']
        if limit is None or not 0<limit<1:notes.append(a['name']+': waiting for a valid '+side+' quote');continue
        opposite=[o for o in pending if o['intent']['token']==token and o['intent']['side']!=side]
        crossing=[o for o in opposite if (side=='BUY' and limit>=o['intent']['limit_price']) or (side=='SELL' and limit<=o['intent']['limit_price'])]
        if crossing and side=='SELL':
            cancel(router,run,'Cancel own crossing BUY before posting SELL limit',order_ids={o['id'] for o in crossing})
            if live and not live_matches(router,run):return
            pending=rows(router,run);reserve,_=reservations(pending)
            opposite=[o for o in pending if o['intent']['token']==token and o['intent']['side']!=side]
        if any((side=='BUY' and limit>=o['intent']['limit_price']) or (side=='SELL' and limit<=o['intent']['limit_price']) for o in opposite):
            notes.append(a['name']+': waiting to avoid crossing another managed account order');continue
        version=hashlib.sha256(json.dumps([book['bids'],book['asks'],limit,side,qty]).encode()).hexdigest()
        if rule.get('rejected_version')==version:continue
        cash=max(0.,min(cash_value(run)-sum(reserve.values()),a['cash']-reserve[w]))
        if side=='BUY':qty=min(qty,cash/limit)
        if live:
            qty=float(decimal.Decimal(str(qty)).quantize(decimal.Decimal('.01'),rounding=decimal.ROUND_DOWN))
            if qty<max(book['min_order_size'],.01):notes.append(a['name']+': below venue minimum / available account cash');continue
        elif qty<=1e-8:notes.append(a['name']+': waiting for its SELL proceeds');continue
        crosses=(side=='BUY' and book.get('ask') is not None and limit>=book['ask']) or (side=='SELL' and book.get('bid') is not None and limit<=book['bid'])
        if crosses:
            # A previously fixed passive target cannot become an aggressive new
            # order when the quote moves during cancel/replace or funding waits.
            notes.append(a['name']+': '+side+' would cross; waiting for minute refresh');continue
        meta=target['metadata'].get(token,a['positions'].get(token,{}))
        intent=dict(wallet=w,name=a['name'],token=token,side=side,shares=qty,title=meta.get('title',''),outcome=meta.get('outcome',''),condition_id=meta.get('condition_id',''),
            limit_price=limit,cash_limit=cash,mark=book['price'],quote_ts=book['timestamp'],reason=target['reason'],plan_id=plan['id'],source_change_id=target.get('source_change_id'),
            execution_policy=POLICY,order_type='GTC',post_only=True,price_basis=rule['kind'],
            planned_order_value=rule['planned_order_value'],initial_allocation=rule['initial_allocation'],
            observed_bid=book.get('bid'),observed_ask=book.get('ask'),tick_size=book.get('tick_size',.01),quote_method='midpoint')
        if live:
            router.live.prepare(intent)
            if intent.get('before_balances'):
                run.setdefault('wallet_token_observed',{}).setdefault(token,intent['before_balances']['shares'])
        oid=uuid.uuid4().hex
        if live:run['active_order']=oid
        router.store.save(run,order_insert=(oid,'posting',dict(intent=intent)))
        if live:
            try:result=router.live.submit(intent,book)
            except Exception as exc:
                router._put(run,oid,'unknown',dict(intent=intent,result=dict(state='unknown',shares=0.,notional=0.,reason=type(exc).__name__+'; reconcile exchange order ID.')))
                run['active_order']=oid;router.store.save(run)
                raise ValueError('Limit submission outcome unknown; no automatic resubmission.') from None
            state='limit_open' if result['state']=='submitted' else 'limit_rejected'
            if state=='limit_rejected':rule['rejected_version']=version
        else:
            result=dict(state='open',shares=0.,notional=0.,price=limit,fee=0.,simulated=True,reason='Resting simulated GTC limit; waiting for observed executable liquidity.');state='limit_open'
        run['active_order']=None
        router.store.save(run,order_update=(oid,state,dict(intent=intent,result=result)))
        if state=='limit_open':pending.append(dict(id=oid,intent=intent,result=result))
        if state=='limit_open' and side=='BUY':reserve[w]+=qty*limit
    summary(run,rows(router,run));run['execution_pending']+=notes[:10];router.store.save(run,point=True)
