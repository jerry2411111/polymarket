"""Restart checkpoints, incremental catch-up, and isolated execution modes."""
import copy
import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from core import Store, DAY
from engine import poll
from execution import ExecutionRouter, make_plan
from realtime import AccountFeed, inventory_key
from server import Application


class ResumeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / 'paper.sqlite')
        self.run = self.store.create(dict(case_id='test', reset_days=75), 1000)
        self.at = int(time.time())
        self.q = dict(price=.5, timestamp=self.at, bids=[(.49, 1e9)], asks=[(.51, 1e9)],
                      bid=.49, ask=.51, min_order_size=100000)
        self.market = SimpleNamespace(book=lambda *a, **kw: copy.deepcopy(self.q), subscribe=Mock())
        self.router = ExecutionRouter(self.store, self.market)

    def tearDown(self):
        self.temp.cleanup()

    @staticmethod
    def position(token, size):
        return dict(token_id=token, current_size=size, title=token, outcome='Yes', condition_id='macro')

    def seed(self):
        ps = [self.position('iran', 100), self.position('fed', 100)]
        source = dict(positions=ps, inventory_key=inventory_key(ps), checked_at=self.at-4*DAY)
        selected = [dict(wallet='A', name='Alice', sigma=.01, weight=1)]
        make_plan(self.run, {'A': source}, {t:self.q for t in ('iran','fed')}, selected, self.at//DAY*DAY)
        self.store.save(self.run)
        self.router.execute(self.run)
        return source

    def app(self, feed):
        app = Application.__new__(Application)
        app.store = self.store
        app.feed = feed
        app.router = self.router
        app.quotes = lambda tokens, at: {t:copy.deepcopy(self.q) for t in tokens}
        app.probes = []
        app.scanner = SimpleNamespace(thread=None, start=Mock())
        app.wake = threading.Event()
        return app

    def test_inflight_poll_cannot_overwrite_manual_account_exclusion(self):
        from execution import remove_selected_account
        source = self.seed()
        feed = SimpleNamespace(set_wallets=Mock(), set_managed_tokens=Mock(), positions=lambda wallet:source)
        app = self.app(feed)
        def quotes(tokens, at):
            current = self.store.run()
            remove_selected_account(current, 'A')
            self.store.save(current)
            return {t:copy.deepcopy(self.q) for t in tokens}
        app.quotes = quotes
        poll(app)
        current = self.store.run()
        self.assertIn('A', current['excluded_wallets'])
        self.assertTrue(current['pending_selection_reset'])
        self.assertTrue(current['accounts']['A']['exiting'])

    def test_restart_fetches_full_gap_and_blocks_saved_snapshot_until_refreshed(self):
        old = self.seed()
        old.update(wallet='A', activity_through=self.at-4*DAY, latest_activity_at=self.at-5*DAY)
        with self.store.connect() as db:
            db.execute('CREATE TABLE source_snapshots(wallet TEXT PRIMARY KEY,body TEXT)')
            db.execute('INSERT INTO source_snapshots VALUES(?,?)', ('A',json.dumps(old)))
        catalog = SimpleNamespace(relevant_positions=lambda rows, api: rows, has=lambda c:c=='macro')
        with patch('realtime.threading.Thread.start'):
            feed = AccountFeed(Store(self.store.path), catalog, self.market)
        self.addCleanup(feed.close)
        feed.set_wallets([dict(wallet='A')])
        with self.assertRaises(ValueError):feed.positions('A')
        trade = dict(id='missed', timestamp=self.at-3*DAY, condition_id='macro', token_id='iran',
                     type='TRADE', side='SELL', size=20, price=.5)
        feed.api.positions = Mock(return_value=[self.position('iran',80),self.position('fed',100)])
        feed.api.pages = Mock(return_value=iter([[trade]]))
        feed._one('A')
        params = feed.api.pages.call_args.args[1]
        self.assertEqual(params['start'], old['activity_through']-600)
        self.assertEqual(len(self.store.rows('SELECT * FROM source_events')),1)
        fresh = feed.positions('A')
        self.assertGreaterEqual(fresh['activity_through'],self.at)
        self.assertEqual(fresh['new_events'],1)
        self.assertLess(fresh['cycle_seconds'],60)
        # Overlapping fetches never duplicate the missed trade.
        feed.api.pages = Mock(return_value=iter([[trade]]))
        feed._one('A')
        self.assertEqual(len(self.store.rows('SELECT * FROM source_events')),1)
        before = feed.positions('A')['activity_through']
        feed.api.pages = Mock(side_effect=TimeoutError('offline'))
        feed._one('A')
        with self.assertRaises(ValueError):feed.positions('A')
        saved = json.loads(self.store.rows('SELECT body FROM source_snapshots')[0]['body'])
        self.assertEqual(saved['activity_through'],before)

    def test_restart_copies_only_net_changes_once_and_keeps_reset_date(self):
        self.seed()
        saved = Store(self.store.path).run()
        next_reset = saved['next_reset']
        initial_fills = len(self.store.rows('SELECT * FROM fills'))
        Application.prepare_resume(saved)
        self.store.save(saved)
        ps = [self.position('iran',60),self.position('fed',140)]
        latest = dict(positions=ps, inventory_key=inventory_key(ps), checked_at=time.time()+1)
        feed = SimpleNamespace(set_wallets=Mock(),set_managed_tokens=Mock(),positions=lambda w:copy.deepcopy(latest))
        app = self.app(feed)
        # A genuinely restarted router has no in-memory state or liquidity cache.
        app.router = ExecutionRouter(Store(self.store.path),self.market)
        self.q.update(bid=.49,ask=.51,bids=[(.49,1e9)],asks=[(.51,1e9)])
        poll(app)  # SELL rests at midpoint; cash is not credited on submission.
        self.q.update(bid=.5,bids=[(.5,1e9)])
        poll(app)  # SELL fills, then its proceeds reserve the midpoint BUY.
        self.q.update(ask=.5,asks=[(.5,1e9)])
        poll(app)
        after = self.store.run()
        self.assertEqual(after['id'],saved['id'])
        self.assertEqual(after['next_reset'],next_reset)
        self.assertEqual(after['accounts']['A']['positions']['iran']['shares'],600)
        self.assertEqual(after['accounts']['A']['positions']['fed']['shares'],1400)
        fills = self.store.rows('SELECT * FROM fills ORDER BY id')[initial_fills:]
        self.assertEqual({(f['side'],f['token'],f['shares']) for f in fills},
                         {('SELL','iran',400),('BUY','fed',400)})
        self.assertTrue(all(f['ts']>=self.at for f in fills))
        self.assertEqual(after['recovery']['status'],'reconciled')
        self.assertEqual(after['recovery']['changed_accounts'],1)
        decisions = [json.loads(r['body']) for r in self.store.rows('SELECT body FROM copy_decisions')]
        self.assertEqual(sum(d['kind']=='initial' for d in decisions),1)
        self.assertTrue(next(d for d in decisions if d['kind']=='source_change')['catch_up'])
        poll(app)
        self.assertEqual(len(self.store.rows('SELECT * FROM fills')),initial_fills+2)

    def test_unchanged_restart_does_not_buy_again(self):
        source = self.seed()
        run = self.store.run()
        Application.prepare_resume(run);self.store.save(run)
        source['checked_at'] = time.time()+1
        app = self.app(SimpleNamespace(set_wallets=Mock(),set_managed_tokens=Mock(),positions=lambda w:source))
        before = self.store.rows('SELECT * FROM fills')
        poll(app)
        self.assertEqual(self.store.rows('SELECT * FROM fills'),before)
        self.assertEqual(self.store.run()['recovery']['changed_accounts'],0)

    def test_created_portfolios_keep_modes_and_controls_are_scoped(self):
        self.seed()
        original = self.store.run()
        app = self.app(None)
        app.archive = SimpleNamespace(case=lambda _:original['case'])
        app.routers = {original['id']:self.router}
        app.router_lock = threading.RLock()
        app.market = self.market
        broker = Mock(wallet='0x'+'a'*40, cash=3000, armed=False)
        with patch('server.LiveBroker', return_value=broker):
            created = app.command('new',dict(run_id=original['id'],mode='live',capital=2000,
                name='Real test',case_id='test',wallet='0x'+'a'*40,private_key='1'*64,
                credentials=dict(apiKey='test-api-key',secret='test-secret',passphrase='test-passphrase')))
        broker.connect.assert_called_once()
        broker.preflight.assert_called_once_with(2000)
        real = self.store.run(created['run_id'])
        self.assertNotEqual(real['id'],original['id'])
        self.assertEqual(real['accounts'],{})
        self.assertEqual(real['name'],'Real test')
        self.assertEqual(real['status'],'ready')
        self.assertEqual(self.store.run(original['id']),original)
        self.assertEqual(self.store.run()['id'],original['id'])
        with self.assertRaises(ValueError):app.command('start',dict(run_id=real['id']))
        app.command('pause',dict(run_id=real['id']))
        self.assertEqual(self.store.run(original['id']),original)
        self.assertFalse(self.router.halt.is_set())
        with self.assertRaises(ValueError):app.command('switch_mode',dict(mode='live',run_id=original['id']))
        self.assertEqual(self.store.run(original['id'])['mode'],'sandbox')
        self.assertEqual(app.portfolio_list()[0]['mode'],'live')
        self.assertFalse(app.router_for(real).live.armed)

    def test_real_creation_rejects_missing_credentials_or_failed_validation_without_saving(self):
        self.seed()
        original = self.store.run()
        app = self.app(None)
        app.archive = SimpleNamespace(case=lambda _:original['case'])
        base = dict(run_id=original['id'],mode='live',capital=2000,name='Blocked',case_id='test')
        with patch('server.LiveBroker') as factory:
            with self.assertRaisesRegex(ValueError,'creation requires'):
                app.command('new',base)
            factory.assert_not_called()
        body = dict(base,wallet='0x'+'a'*40,private_key='1'*64,
                    credentials=dict(apiKey='secret-test-api',secret='secret-test-value',passphrase='secret-test-pass'))
        broker = Mock(wallet=body['wallet'],cash=3000,armed=False)
        broker.connect.side_effect = ValueError('Authentication failed')
        with patch('server.LiveBroker',return_value=broker):
            with self.assertRaisesRegex(ValueError,'Authentication failed'):
                app.command('new',body)
        broker.disconnect.assert_called_once()
        broker = Mock(wallet=body['wallet'],cash=3000,armed=False)
        broker.preflight.side_effect = RuntimeError('secret-test-value')
        with patch('server.LiveBroker',return_value=broker):
            with self.assertRaisesRegex(ValueError,'Could not verify') as caught:
                app.command('new',body)
        self.assertNotIn('secret-test-value',str(caught.exception))
        self.assertEqual(len(self.store.rows('SELECT id FROM runs')),1)
        self.assertEqual(self.store.run(),original)
        dump=' '.join(r['body'] for r in self.store.rows('SELECT body FROM runs'))
        self.assertNotIn('secret-test',dump)

    def test_two_running_sandboxes_continue_independently(self):
        source = self.seed()
        first = self.store.run()
        second = self.store.create(first['case'],2000,name='Second',activate=False)
        make_plan(second,{'A':source},{t:self.q for t in ('iran','fed')},
                  [dict(wallet='A',name='Alice',sigma=.01,weight=1)],self.at//DAY*DAY)
        self.store.save(second)
        feed = SimpleNamespace(set_wallets=Mock(),set_managed_tokens=Mock(),positions=lambda w:source)
        app = self.app(feed)
        app.routers = {first['id']:self.router}
        app.router_lock = threading.RLock()
        app.market = self.market
        self.q.update(ask=.51,asks=[(.51,1e9)])
        app.poll()
        a,b=self.store.run(first['id']),self.store.run(second['id'])
        self.assertEqual(a['status'],'running')
        self.assertEqual(b['status'],'running')
        self.assertEqual(a['accounts']['A']['positions']['iran']['shares'],1000)
        self.assertEqual(b['accounts']['A']['positions']['iran']['shares'],2000)
        app.command('pause',dict(run_id=second['id']))
        self.assertEqual(self.store.run(first['id'])['status'],'running')
        self.assertFalse(app.router_for(first).halt.is_set())
        self.assertTrue(app.router_for(second).halt.is_set())

    def test_capital_rebase_preserves_source_inventory_and_other_portfolios(self):
        from portfolio_capital import rebase_sandbox
        self.seed()
        original=self.store.run()
        before_fills=self.store.rows('SELECT * FROM fills')
        other=self.store.create(original['case'],2000,mode='live',activate=False)
        result=rebase_sandbox(self.store,original['id'],100000)
        after=self.store.run(original['id'])
        self.assertEqual(result['factor'],100)
        self.assertEqual(after['initial'],100000)
        self.assertEqual(after['accounts']['A']['positions']['iran']['shares'],100000)
        self.assertEqual(after['accounts']['A']['source_inventory'],original['accounts']['A']['source_inventory'])
        self.assertEqual(after['next_reset'],original['next_reset'])
        self.assertEqual(self.store.run(other['id']),other)
        fills=self.store.rows('SELECT * FROM fills')
        self.assertEqual(fills[0]['shares'],before_fills[0]['shares']*100)
        self.assertEqual(fills[0]['price'],before_fills[0]['price'])
        rebase_sandbox(self.store,original['id'],100000)
        self.assertEqual(self.store.run(original['id']),after)
        with self.assertRaises(ValueError):rebase_sandbox(self.store,other['id'],100000)


if __name__ == '__main__':
    unittest.main(verbosity=2)
