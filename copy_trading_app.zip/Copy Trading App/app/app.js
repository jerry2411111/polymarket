'use strict';
const $ = id => document.getElementById(id);
const esc = x => String(x ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = n => Number(n).toLocaleString('en-US', {style:'currency', currency:'USD', maximumFractionDigits:2});
const pct = (n, signed=true) => n == null ? '—' : `${signed && n > 0 ? '+' : ''}${(100*n).toFixed(2)}%`;
const num = n => n == null ? '—' : Number(n).toLocaleString('en-US');
const dec = (n, digits=2) => n == null ? '—' : Number(n).toFixed(digits);
const DISPLAY_TIME_ZONE = 'America/Chicago';
const date = t => t == null ? '—' : new Date(t*1000).toLocaleDateString('en-US', {month:'short', day:'numeric', year:'numeric', timeZone:DISPLAY_TIME_ZONE});
const time = t => t == null ? '—' : new Date(t*1000).toLocaleTimeString('en-US', {hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23',timeZone:DISPLAY_TIME_ZONE,timeZoneName:'short'});
const timestamp = t => t == null ? '—' : `${date(t)} · ${time(t)}`;
const localMessage = message => String(message).replace(/\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z\b/g, value => timestamp(Date.parse(value)/1000));
const signedClass = n => n > 0 ? 'positive' : n < 0 ? 'negative' : '';
let state, cases=[], replay, replayIndex=0, replayTimer, refreshing=null, currentPage='overview', detailWallet=null, detailDecision=null;
const pendingActions=new Set();
let viewedPortfolio=localStorage.getItem('macrobook.portfolio')||null;
let viewLoading=false, viewRevision=0;

async function request(path, options={}) {
  const response=await fetch(path, options);
  const data=await response.json();
  if(!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function toast(message) {
  $('toast').textContent=message; $('toast').classList.add('show');
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>$('toast').classList.remove('show'),7000);
}
async function action(action, extra={}) {
  if(!state || pendingActions.has(action)) return;
  if(viewLoading){toast('Wait for the selected portfolio to finish loading.');return;}
  pendingActions.add(action);
  renderCopyControls();
  try {
    const result=await request('/api/action', {method:'POST',headers:{'Content-Type':'application/json','X-Paper-Token':state.csrf},body:JSON.stringify({action,run_id:state.run.id,...extra})});
    if(action==='new') {viewedPortfolio=result.run_id;localStorage.setItem('macrobook.portfolio',viewedPortfolio);clearPortfolioDetail();}
    await refresh(true);
    const startMessage=state.run.status==='running'
      ? `Copying is active. Following ${state.accounts.filter(a=>!a.exiting).length} accounts.`
      : state.run.status==='waiting_for_screen'
        ? 'Selecting accounts. Copying will begin automatically when screening finishes.'
        : `Current status: ${state.run.status.replaceAll('_',' ')}.`;
    toast(({start:startMessage,pause:'Copying paused; existing positions remain visible.',screen:'Live discovery started. Progress is saved between sessions.',stop_screen:'Discovery will pause after current requests.',new:'New portfolio created.',connect:'Trading account connected; live routing remains disabled.',arm:'Live routing enabled. Start copying when ready.',disarm:'New orders disabled; copying paused.',disconnect:'Trading account disconnected.',reconcile_order:'Exchange order attached for reconciliation.',refresh:'Market refresh requested.'})[action]);
  } catch(e) { toast(e.message); }
  finally { pendingActions.delete(action);renderCopyControls(); }
}
function renderCopyControls() {
  if(!state) return;
  const status=state.run.status;
  const busy=pendingActions.size>0||viewLoading;
  $('start').textContent=pendingActions.has('start')?'Starting…':({running:'✓ Copying active',waiting_for_screen:'Selecting accounts…',paused:'▶ Resume copying'})[status]||'▶ Start copying';
  $('start').disabled=busy || ['running','waiting_for_screen'].includes(status);
  $('start').title=status==='running'?'Already following the selected accounts. Use Pause to stop copying.':status==='waiting_for_screen'?'Copying begins automatically when the current selection is ready.':'';
  $('start').setAttribute('aria-busy',String(pendingActions.has('start')));
  $('pause').textContent=pendingActions.has('pause')?'Pausing…':'Pause';
  $('pause').disabled=busy || ['paused','ready'].includes(status);
  $('portfolio-select').disabled=busy;
  $('run-select').disabled=busy;
  $('create-portfolio').disabled=busy;
  $('create-portfolio').textContent=pendingActions.has('new')?($('new-mode').value==='live'?'Validating credentials…':'Creating…'):($('new-mode').value==='live'?'Validate & create real portfolio':'Create sandbox');
}
function goto(page) {
  currentPage=page;
  document.querySelectorAll('.page').forEach(x=>x.classList.toggle('active',x.id===page));
  document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.page===page));
  $('crumb').textContent=document.querySelector(`.nav[data-page="${page}"]`).textContent.slice(1).trim();
  if(page==='replay'&&!replay) loadReplay();
}
document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>goto(b.dataset.page)));
document.querySelectorAll('[data-goto]').forEach(b=>b.addEventListener('click',()=>goto(b.dataset.goto)));
document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>action(b.dataset.action)));
function clearPortfolioDetail() {
  detailWallet=null;detailDecision=null;
  $('account-detail').classList.add('hidden');$('account-detail').innerHTML='';
  $('position-account').value='';$('transaction-account').value='';$('account-search').value='';
  replay=null;clearInterval(replayTimer);replayTimer=null;
}
async function selectPortfolio(id) {
  if(pendingActions.size||id===viewedPortfolio)return;
  const revision=++viewRevision;
  viewLoading=true;renderCopyControls();
  viewedPortfolio=id;localStorage.setItem('macrobook.portfolio',id);clearPortfolioDetail();
  try {await refresh(true);if(currentPage==='replay')loadReplay();}
  catch(e){toast(e.message);viewedPortfolio=state.run.id;localStorage.setItem('macrobook.portfolio',viewedPortfolio);render();}
  finally {if(revision===viewRevision){viewLoading=false;renderCopyControls();}}
}
$('portfolio-select').addEventListener('change',e=>selectPortfolio(e.target.value));
$('run-select').addEventListener('change',e=>selectPortfolio(e.target.value));

function label(c) {
  return `${c.screen_metric==='effective'?'Effective':'Raw'} ${c.upper==null?`> ${c.lower}`:`(${c.lower}, ${c.upper}]`} · reset ${c.reset_days}d · vol ${c.volatility_days}d`;
}
function table(headers, rows, empty='No records yet.', rowKeys=[]) {
  if(!rows.length) return `<div class="empty">${esc(empty)}</div>`;
  return `<table><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map((r,i)=>`<tr${rowKeys[i]!=null?` data-row-key="${esc(rowKeys[i])}"`:''}>${r.map(v=>`<td>${v}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
}
const renderedOptions=new WeakMap();
function updateOptions(select, html) {
  if(renderedOptions.get(select)===html)return;
  const selected=select.value;
  select.innerHTML=html;
  if([...select.options].some(o=>o.value===selected))select.value=selected;
  renderedOptions.set(select,html);
}
function rememberReadingPosition() {
  const boxes=[...document.querySelectorAll('.table-wrap[id], .journal[id]')]
    .filter(el=>el.getClientRects().length).map(el=>{
      const top=el.getBoundingClientRect().top;
      const readingTop=Math.max(top,el.querySelector('thead th')?.getBoundingClientRect().bottom??top);
      const row=el.scrollTop>0?[...el.querySelectorAll('tbody tr[data-row-key]')]
        .find(row=>row.getBoundingClientRect().bottom>readingTop):null;
      return {id:el.id,x:el.scrollLeft,y:el.scrollTop,
        row:row?.dataset.rowKey,offset:row?row.getBoundingClientRect().top-top:null};
    });
  const active=document.activeElement, container=active?.closest('.table-wrap[id], .allocation-list[id]');
  const focus=container&&active.matches('[data-wallet], [data-decision]')?
    {container:container.id,attribute:active.hasAttribute('data-decision')?'data-decision':'data-wallet',
     value:active.getAttribute(active.hasAttribute('data-decision')?'data-decision':'data-wallet')}:null;
  return {x:window.scrollX,y:window.scrollY,boxes,focus};
}
function restoreReadingPosition(view) {
  for(const box of view.boxes) {
    const el=$(box.id);if(!el||!el.getClientRects().length)continue;
    el.scrollTo({left:box.x,top:box.y,behavior:'instant'});
    const row=box.row?el.querySelector(`tr[data-row-key="${CSS.escape(box.row)}"]`):null;
    if(row)el.scrollTop+=row.getBoundingClientRect().top-el.getBoundingClientRect().top-box.offset;
  }
  if(view.focus) {
    const f=view.focus;
    $(f.container)?.querySelector(`[${f.attribute}="${CSS.escape(f.value)}"]`)?.focus({preventScroll:true});
  }
  window.scrollTo({left:view.x,top:view.y,behavior:'instant'});
}
function accountCell(a) {
  return `<button class="text-button account-link" data-wallet="${esc(a.wallet)}">${esc(a.name||a.account_name||a.wallet)}</button><small class="wallet">${esc(a.wallet)}</small>`;
}
function bindAccounts(container) {
  container.querySelectorAll('[data-wallet]').forEach(b=>b.addEventListener('click',()=>accountDetail(b.dataset.wallet)));
}
function chart(id, points, empty='Your forward performance will appear here.') {
  const el=$(id), W=850,H=285,L=64,R=18,T=18,B=38;
  if(!points.length) {el.innerHTML=`<div class="empty"><b>No observations yet</b>${esc(empty)}</div>`;return;}
  const values=points.map(p=>p.nav), min=Math.min(...values), max=Math.max(...values), pad=Math.max((max-min)*.16,Math.abs(max)*.002,1);
  const lo=min-pad, hi=max+pad;
  const first=points[0].ts, last=points[points.length-1].ts;
  const x=t=>L+(last===first?.5:(t-first)/(last-first))*(W-L-R), y=v=>T+(hi-v)/(hi-lo)*(H-T-B);
  let svg=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Portfolio value over time"><defs><linearGradient id="shade-${id}" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#82b79a" stop-opacity=".24"/><stop offset="100%" stop-color="#c5e6d0" stop-opacity=".02"/></linearGradient></defs>`;
  for(let i=0;i<5;i++) {
    const v=lo+(hi-lo)*i/4,Y=y(v);
    svg+=`<line x1="${L}" x2="${W-R}" y1="${Y}" y2="${Y}" stroke="#edf1e9" stroke-dasharray="4 5"/><text x="${L-12}" y="${Y+4}" text-anchor="end" font-size="10" fill="#93a087">${esc(money(v).replace('.00',''))}</text>`;
  }
  const path=points.map((p,i)=>`${i?'L':'M'}${x(p.ts).toFixed(2)},${y(p.nav).toFixed(2)}`).join(' ');
  if(points.length>1) svg+=`<path d="${path} L${x(last)},${H-B} L${x(first)},${H-B} Z" fill="url(#shade-${id})"/>`;
  svg+=`<path d="${path}" fill="none" stroke="#348966" stroke-width="2.5" stroke-linejoin="round"/><circle cx="${x(last)}" cy="${y(values[values.length-1])}" r="4" fill="#348966"/>`;
  [0,.25,.5,.75,1].forEach((v,i)=>{if(last===first && i!==2)return; const t=first+(last-first)*v;svg+=`<text x="${x(t)}" y="${H-9}" text-anchor="middle" font-size="10" fill="#93a087">${esc(last-first<86400?time(t):date(t).replace(', 2026','').replace(', 2025',''))}</text>`;});
  svg+='</svg>';el.innerHTML=svg;
}

async function refresh(afterAction=false) {
  if(refreshing) {await refreshing;if(!afterAction)return;}
  const task=(async()=>{
    const requested=viewedPortfolio;
    try {
      let next;
      try {next=await request('/api/state'+(requested?'?run='+encodeURIComponent(requested):''));}
      catch(e) {
        if(!requested||e.message!=='Unknown saved portfolio.')throw e;
        next=await request('/api/state');
      }
      if(requested!==viewedPortfolio)return;
      const changed=state?.run.id!==next.run.id;
      state=next;viewedPortfolio=next.run.id;localStorage.setItem('macrobook.portfolio',viewedPortfolio);
      if(changed){clearPortfolioDetail();$('case-select').value=next.run.case.case_id;$('replay-case').value=next.run.case.case_id;}
      render();
    }
    catch(e) {
      $('connection').textContent='Server unavailable';$('connection').className='pill bad';
      if(afterAction)throw new Error('Command sent, but status could not be refreshed. Reconnect to check its result.');
      toast('The local server is unavailable. Open Start Macrobook.cmd to restart it.');
    }
  })();
  refreshing=task;
  try {await task;}finally {if(refreshing===task)refreshing=null;}
}
function render() {
  const readingPosition=rememberReadingPosition();
  const r=state.run,c=r.case,p=state.performance,s=state.screen;
  $('connection').textContent=state.api.last_ok?'PUBLIC DATA CONNECTED':'LOCAL SERVER CONNECTED';
  $('connection').className='pill good';
  if(state.api.last_error){$('connection').textContent='DATA SYNC NEEDS ATTENTION';$('connection').className='pill warn';}
  $('nav').textContent=money(state.nav);$('return').textContent=pct(p.total_return);$('return').className=signedClass(p.total_return);
  $('pnl').textContent=`${money(state.nav-r.initial)} P&L · ${money(state.cash)} cash`;
  $('nav-note').textContent=`${money(r.initial)} starting capital · run ${r.id}`;
  $('sharpe').textContent=dec(p.sharpe);$('sharpe-note').textContent=p.daily_observations<2?'Needs two completed 24-hour returns from funding':`${p.daily_observations} completed 24-hour returns from funding`;
  if(p.has_daily_gaps)$('sharpe-note').textContent='Unavailable: gaps in recorded daily NAV';
  $('count').textContent=num(state.accounts.filter(a=>!a.exiting).length);$('count-note').textContent=state.accounts.length?'Inverse volatility · no ranking':'Waiting for complete live selection';
  $('strategy-name').textContent=c.screen_metric==='effective'?'Effective Sharpe':'Raw Sharpe';
  $('strategy-band').textContent=c.upper==null?`S > ${c.lower}`:`${c.lower} < S ≤ ${c.upper}`;
  $('reset-days').textContent=`${c.reset_days} days`;$('history-days').textContent=`Up to ${c.volatility_days} days`;
  $('selection-date').textContent=timestamp(state.reset_schedule?.selection_date||r.last_screen||s.as_of);
  $('next-reset').textContent=timestamp(r.next_reset||state.reset_schedule?.next_reset);
  $('run-state').textContent=r.status.replaceAll('_',' ');
  $('run-state').className='pill '+(r.status==='running'?'good':'neutral');
  renderCopyControls();
  let banner='Start copying to apply your current account screen and allocate once it is complete.';
  if(r.status==='waiting_for_screen') banner=`Reset date ${date(s.as_of)}. Selecting accounts using the preceding year of available history: ${num(s.checked||0)} / ${num(s.candidates||0)} candidates checked, ${num(s.selected||0)} qualified so far. Discovery, screening and allocation repeat every ${c.reset_days} days. ${s.stage||'Preparing historical inputs'}.`;
  if(r.status==='running') banner=`${r.mode==='live'?'Real-money':'Sandbox'} copying is active. ${state.accounts.filter(a=>!a.exiting).length} accounts followed; observed inventory changes trigger order plans between account resets.`;
  if(r.status==='paused') banner='Copying is paused. Positions continue to be marked and previously submitted orders remain under reconciliation.';
  if(r.status==='running'&&state.selection_snapshot?.unresolved_accounts) banner+=` ${num(state.selection_snapshot.unresolved_accounts)} accounts had unresolved histories and were not allocated; details are shown in Discovery.`;
  if(r.issue) banner=`Execution held: ${r.issue} Last observed marks remain visible; see the order journal for any already confirmed fills.`;
  if(r.recovery?.status==='pending'&&r.status==='running') banner=`Resuming your saved portfolio. Checking source trades and positions since ${date(r.recovery.since)} ${time(r.recovery.since)}; only net position changes will be copied at current prices.`;
  if(r.recovery?.status==='reconciled'&&r.status==='running'&&!r.issue) banner+=` Resume sync checked ${num(r.recovery.accounts_checked)} accounts; ${num(r.recovery.changed_accounts)} changed. Existing holdings were retained.`;
  $('status-banner').textContent=banner;
  $('portfolio-note').textContent=`${r.mode==='sandbox'?'Sandbox':'Real money'} · ${money(r.initial)} starting capital · ${r.id}. Viewing another portfolio does not pause this one.`;
  $('execution-model').textContent=r.mode==='sandbox'?'Assumed immediate midpoint fills':'Confirmed midpoint limit fills';
  chart('live-chart',state.points);
  $('chart-start').textContent=`Started ${date(r.created_at)}`;$('chart-last').textContent=`${state.points.length} saved observations`;
  $('footer-sync').textContent=r.last_sync?`LAST SYNC ${date(r.last_sync)} · ${time(r.last_sync)}`:'WAITING FOR FIRST SYNC';
  const accounts=state.accounts.filter(a=>!a.exiting).sort((a,b)=>b.weight-a.weight);
  $('allocation-list').innerHTML=accounts.length?accounts.slice(0,6).map(a=>`<div class="allocation"><div class="account-avatar">${esc(a.name.slice(0,2).toUpperCase())}</div><div class="allocation-text" title="${esc(a.wallet)}"><button class="text-button" data-wallet="${esc(a.wallet)}">${esc(a.name)}</button></div><div class="allocation-bar"><div data-width="${a.weight*100}"></div></div><div class="allocation-value">${pct(a.weight,false)}<small>${money(a.reset_budget)}</small></div></div>`).join('')+(accounts.length>6?`<div class="copy">+ ${accounts.length-6} additional followed accounts</div>`:''):`<div class="empty"><b>Your selected set will appear here</b>Every account passing the filters receives a share.<br>There is no top-1 or top-5 restriction.</div>`;
  bindAccounts($('allocation-list'));
  $('allocation-list').querySelectorAll('[data-width]').forEach(el=>el.style.width=el.dataset.width+'%');
  $('journal').innerHTML=state.journal.map(j=>`<div class="journal-row"><time>${time(j.ts)}</time><span>${esc(localMessage(j.message))}</span></div>`).join('')||'<div class="empty">No activity yet.</div>';
  renderRealtime();
  renderAccounts();
  renderPositions();
  renderTransactionHistory();
  renderAccountLiveDetail();
  $('markets').textContent=num(s.markets||state.archive_markets);$('discovered').textContent=num(s.accounts_seen||0);$('candidates').textContent=num(s.candidates||0);$('qualified').textContent=num(s.selected||0);
  $('screen-stage').textContent=s.stage||'Ready to discover';$('screen-date').textContent=s.as_of?`Selection uses only history before ${timestamp(s.as_of)}`:'A fresh screen is needed for live allocations.';
  $('screen-status').textContent=s.running?'IN PROGRESS':s.complete?'COMPLETE':s.error?'ATTENTION':'NOT COMPLETE';$('screen-status').className='pill '+(s.complete?'good':s.error?'bad':'neutral');
  const progress=s.complete?100:s.candidates?60+40*(s.checked||0)/s.candidates:s.market_batches?10+50*(s.market_batches_done||0)/s.market_batches:3;
  $('screen-bar').style.width=progress+'%';
  let summary=`${num(s.market_batches_done||0)} / ${num(s.market_batches||0)} market batches completed · ${num(s.checked||0)} / ${num(s.candidates||0)} candidate accounts checked`;
  if(s.markets_remaining!=null)summary=`${num(s.markets_remaining)} markets remaining · `+summary;
  if(s.counts) summary+=' · '+Object.entries(s.counts).map(([k,v])=>`${k.replaceAll('_',' ')}: ${num(v)}`).join(' · ');
  if(s.error) summary+=' · '+s.error;
  $('screen-summary').textContent=summary;
  const options=state.runs.map(x=>`<option value="${esc(x.id)}">${esc(x.name)} · ${x.mode==='live'?'Real money':'Sandbox'} · ${money(x.initial)} · ${esc(x.status.replaceAll('_',' '))}</option>`).join('');
  for(const id of ['run-select','portfolio-select']) {updateOptions($(id),options);$(id).value=r.id;}
  document.querySelectorAll('a[href^="/api/export/"]').forEach(a=>{a.href=a.getAttribute('href').split('?')[0]+'?run='+encodeURIComponent(r.id);});
  restoreReadingPosition(readingPosition);
}
function renderAccounts() {
  if(!state)return;
  const audit=state.allocation||{}, active=state.accounts.filter(a=>!a.exiting);
  $('allocation-audit').textContent=`wᵢ = (1 / σᵢ) / Σⱼ(1 / σⱼ). ${audit.status==='verified'?'Verified: all selected weights match inverse volatility and sum to 100%.':audit.status==='mismatch'?'Allocation check needs attention: stored weights do not match the formula.':'Waiting for the first completed live selection.'} Uses available preceding macro-book daily returns, capped at ${audit.volatility_days||365} days, lagged by one return. All qualifying accounts are included; no ranking.`;
  $('allocated-budget').textContent=money(audit.reset_budget||0);
  $('allocated-invested').textContent=money(audit.invested||0);
  $('allocated-cash').textContent=money(state.cash);
  $('allocated-weights').textContent=pct(audit.weight_sum||0,false);
  const term=$('account-search').value.toLowerCase();
  const rows=state.accounts.filter(a=>(a.name+' '+a.wallet).toLowerCase().includes(term));
  $('account-table').innerHTML=table(['Account / full wallet','Status','Reset weight','Reset budget','Current equity','Current portfolio share','Invested now','Attributed cash','Daily volatility'],rows.map(a=>[
    accountCell(a),`<span class="pill ${a.exiting?'warn':'good'}">${a.exiting?'Exiting':'Following'}</span>`,pct(a.weight,false),money(a.reset_budget),money(a.value),pct(a.portfolio_share,false),money(a.invested),money(a.cash),pct(a.sigma,false)]),'No accounts allocated yet. Fresh screening is still required; monitored feed probes are not selections.',rows.map(a=>a.wallet));
  $('account-performance').innerHTML=table(['Account / full wallet','Period return','Managed P&L','Raw / Effective at selection','History / activity'],rows.map(a=>[
    accountCell(a),`<span class="${signedClass(a.period_return)}">${pct(a.period_return)}</span>`,
    `<span class="${signedClass(a.pnl)}">${money(a.pnl)}</span>`,`${dec(a.metric.raw_sharpe)} / ${dec(a.metric.effective_sharpe)}`,
    `${num(a.metric.historical_observations)} return observations<small>${num(a.metric.active_days_last_40)} active / 40 days</small>`]),'No currently selected accounts. Open Historical replay to inspect the saved strategy while live screening runs.',rows.map(a=>a.wallet));
  bindAccounts($('account-table'));
  bindAccounts($('account-performance'));
}
$('account-search').addEventListener('input',renderAccounts);

function holdingsTable(rows) {
  const sorted=[...rows].sort((a,b)=>b.value-a.value);
  return table(['Market / outcome','Source account','Our shares','Mark','Current value ↓','Portfolio share','Unrealized P&L','Price observed (Chicago)'],sorted.map(p=>[
    `<div class="market-title">${esc(p.title)}<small>${esc(p.outcome)}</small></div>`,accountCell(p),dec(p.shares,4),dec(p.price,4),money(p.value),pct(p.portfolio_share,false),`<span class="${signedClass(p.unrealized)}">${money(p.unrealized)}</span>`,`${date(p.quote_ts)} ${time(p.quote_ts)}`]),'No positions held for this selection.',sorted.map(p=>p.wallet+":"+p.token));
}
function renderPositions() {
  const select=$('position-account'),wallet=select.value;
  updateOptions(select,'<option value="">All accounts</option>'+state.accounts.map(a=>`<option value="${esc(a.wallet)}">${esc(a.name)} · ${esc(a.wallet)}</option>`).join(''));
  select.value=state.accounts.some(a=>a.wallet===wallet)?wallet:'';
  const rows=state.positions.filter(p=>!select.value||p.wallet===select.value);
  $('position-count').textContent=`${num(rows.length)} positions · ${money(rows.reduce((s,p)=>s+p.value,0))}`;
  $('positions-table').innerHTML=holdingsTable(rows);bindAccounts($('positions-table'));
}
$('position-account').addEventListener('change',renderPositions);
function renderTransactionHistory() {
  const select=$('transaction-account'),wallet=select.value;
  const names=new Map();
  [...state.accounts,...state.fills,...(state.copy_activity||[])].forEach(a=>names.set(a.wallet,a.name||a.wallet));
  updateOptions(select,'<option value="">All source accounts</option>'+[...names].sort((a,b)=>a[1].localeCompare(b[1])).map(([w,name])=>`<option value="${esc(w)}">${esc(name)} · ${esc(w)}</option>`).join(''));
  select.value=names.has(wallet)?wallet:'';
  const rows=state.fills.filter(f=>!select.value||f.wallet===select.value).sort((a,b)=>b.ts-a.ts||b.id-a.id);
  $('transaction-count').textContent=`${num(rows.length)} transactions shown`;
  const openOrders=(state.execution.orders||[]).filter(o=>['limit_open','limit_partial','limit_cancel_requested','posting','unknown'].includes(o.state)&&(!select.value||o.intent.wallet===select.value));
  $('open-limit-orders').innerHTML=orderTable(openOrders);bindAccounts($('open-limit-orders'));
  $('limit-summary').textContent=`${num(openOrders.length)} pending orders · ${money(state.run.limit_order_summary?.reserved_cash||0)} reserved cash. Every BUY and SELL uses a bid/ask midpoint limit checked every minute. No market orders.`;
  $('transactions-table').innerHTML=table(['Time (Chicago)','Our action','Market / outcome','Source account / full wallet','Our shares','Fill price','Value','Source / reason'],rows.map(f=>[
    `${date(f.ts)}<small>${time(f.ts)}</small>`,`<span class="pill ${f.side==='BUY'?'good':'neutral'}">${esc(f.side)}</span>`,
    `<div class="market-title">${esc(f.title)}<small>${esc(f.outcome)}</small></div>`,accountCell(f),dec(f.shares,4),dec(f.price,4),money(f.notional),
    `<div class="market-title">${esc(f.reason)}${f.source_change_id?`<small><button class="text-button" data-decision="${esc(f.source_change_id)}">View source trades &amp; our response →</button></small>`:''}</div>`]),'No transactions recorded for this source account.',rows.map(f=>f.id));
  bindAccounts($('transactions-table'));bindDecisions($('transactions-table'));
  renderCopyActivity();
}
$('transaction-account').addEventListener('change',renderTransactionHistory);
function bindDecisions(el) {
  el.querySelectorAll('[data-decision]').forEach(b=>b.addEventListener('click',()=>{
    detailDecision=b.dataset.decision;goto('transactions');renderCopyDetail();$('copy-detail').scrollIntoView({behavior:'smooth',block:'start'});
  }));
}
function decisionTable(rows) {
  return table(['Observed / planned (Chicago)','Source account','What changed','Our adjustment','Filled value','Status / detail'],rows.map(d=>{
    const source=d.kind==='source_change'?`${d.catch_up?'Offline catch-up · ':''}${num(d.source_changes.length)} position changes · ${num(d.source_events.length)} observed trades`:({initial:'Copy starting positions',reset:'Scheduled allocation reset',removed:'Account removed: close our holdings'})[d.kind];
    const preview=d.adjustments.slice(0,2).map(a=>`${esc(a.side)} ${dec(a.shares,2)} · ${esc(a.title)} (${esc(a.outcome)})`).join('<br>');
    return [`${date(d.observed_at||d.ts)}<small>${time(d.observed_at||d.ts)}</small>`,accountCell(d),`<div class="market-title">${source}</div>`,
      `<div class="market-title">${preview||'No position adjustment needed'}${d.adjustments.length>2?`<small>+ ${d.adjustments.length-2} more</small>`:''}</div>`,`${money(d.filled_notional)}<small>${num(d.filled_orders)} filled orders</small>`,
      `<span class="pill ${d.status==='Copied'?'good':d.status.includes('pending')||d.status.includes('Pending')?'warn':'neutral'}">${esc(d.status)}</span><small><button class="text-button" data-decision="${esc(d.id)}">View source &amp; our response →</button></small>`];
  }),'No copy decisions yet. Only selected accounts generate orders; connectivity probes do not.',rows.map(d=>d.id));
}
function renderCopyActivity() {
  const wallet=$('transaction-account').value;
  const el=$('copy-activity');el.innerHTML=decisionTable((state.copy_activity||[]).filter(d=>!wallet||d.wallet===wallet));bindAccounts(el);bindDecisions(el);renderCopyDetail();
}
function renderCopyDetail() {
  const el=$('copy-detail');if(!detailDecision){el.classList.add('hidden');return;}
  el.classList.remove('hidden');
  const d=(state.copy_activity||[]).find(d=>d.id===detailDecision);
  if(!d){el.innerHTML='<p class="copy">This decision is outside the latest 100. Its confirmed executions remain in the fill export.</p>';return;}
  el.innerHTML=`<hr><div class="card-head"><div><h3>${esc(d.name)} · ${esc(d.status)}</h3><span class="wallet">${esc(d.wallet)}</span></div><button id="close-copy-detail" class="text-button">Close detail</button></div><p class="copy">${esc(d.reason)} · ${date(d.ts)} ${time(d.ts)}</p><h4>Observed source inventory changes</h4><div id="copy-source-changes" class="table-wrap">${table(['Market / outcome','Source share change'],d.source_changes.map(c=>[`<div class="market-title">${esc(c.title)}<small>${esc(c.outcome)}</small></div>`,`${c.delta_shares>0?'+':''}${dec(c.delta_shares,4)}`]),d.kind==='source_change'?'No share-quantity change; source position status changed.':'This is an allocation action, not a new source trade.')}</div><h4>Source trades observed between book snapshots</h4><p class="copy">These public trade records provide context. Copy orders follow the net book change; a single transaction is not assumed to cause each order.</p><div id="copy-source-trades" class="table-wrap">${table(['Trade time (Chicago) / observed delay','Market / outcome','Source action','Source shares','Price','Transaction'],d.source_events.map(e=>[`${date(e.event_at)} ${time(e.event_at)}<small>${dec(e.observed_at-e.event_at,2)}s to first observation</small>`,`<div class="market-title">${esc(e.title)}<small>${esc(e.outcome)}</small></div>`,esc(e.side),dec(e.size,4),dec(e.price,4),`<span class="wallet">${esc(e.transaction_hash||e.id)}</span>`]),'No matching newly observed transaction in this snapshot interval.')}</div><h4>Our linked orders</h4><div id="copy-linked-orders" class="table-wrap">${orderTable(d.orders)}</div><p class="copy">Decision ID: ${esc(d.id)}</p>`;
  $('close-copy-detail').onclick=()=>{detailDecision=null;renderCopyDetail();};bindAccounts(el);
}
function renderAccountLiveDetail() {
  const el=$('account-live-detail');if(!el||!detailWallet)return;
  const a=state.accounts.find(a=>a.wallet===detailWallet), rows=state.positions.filter(p=>p.wallet===detailWallet);
  if(el.dataset.wallet!==detailWallet) {
    el.innerHTML='<h3>Our allocation &amp; holdings for this account</h3><p id="account-live-allocation" class="copy"></p><div id="account-live-holdings" class="table-wrap"></div><hr><h3>Account changes &amp; our response</h3><div id="account-live-decisions" class="table-wrap"></div>';
    el.dataset.wallet=detailWallet;
  }
  $('account-live-allocation').textContent=a?`Reset allocation ${pct(a.weight,false)} · ${money(a.reset_budget)} budget · ${money(a.value)} current equity · ${money(a.invested)} invested · ${money(a.cash)} attributed cash`:'This account is not currently allocated capital in this run.';
  $('account-live-holdings').innerHTML=holdingsTable(rows);
  $('account-live-decisions').innerHTML=decisionTable((state.copy_activity||[]).filter(d=>d.wallet===detailWallet));
  bindDecisions($('account-live-decisions'));
}
function orderTable(rows) {
  return table(['Time (Chicago)','Source account / wallet','Mode','Our action','Market / outcome','Requested shares','Filled shares','Limit / pricing rule','Fill price','State','Order / reason'],rows.map(o=>{
    const i=o.intent,x=o.result||{};
    return [`${date(o.created)} ${time(o.created)}`,accountCell(i),esc(o.mode),`${esc(i.side)} ${i.order_type==='GTC'?'LMT':i.order_type==='FAK'?'MKT':i.order_type==='SIMULATED'?'SIM':''}`,`<div class="market-title">${esc(i.title)}<small>${esc(i.outcome)}</small></div>`,dec(i.shares,4),dec(x.shares,4),`${dec(i.limit_price,4)}<small>${i.price_basis==='assumed_midpoint'?'Assumed immediate midpoint':i.price_basis==='market'?'Market depth':i.price_basis==='passive'?'Bid/ask midpoint / 60s refresh':'Previous execution model'}</small>${i.planned_order_value!=null?`<small>${money(i.planned_order_value)} planned${i.initial_allocation?' / initial allocation':''}</small>`:''}`,x.shares?dec(x.price,4):'—',esc(o.state==='applied'?(x.simulated&&x.state==='filled'?'Simulated fill':x.partial?'Partial fill':x.state):o.state.replaceAll('_',' ')),`<div class="market-title"><span class="wallet">${esc(x.exchange_order_id||o.id)}</span><small>${esc(i.reason)}</small><small>${esc(x.reason||'')}</small></div>`];
  }),'No order submitted for this decision yet.',rows.map(o=>o.id));
}

async function accountDetail(wallet) {
  detailWallet=wallet;
  goto('accounts');const el=$('account-detail');el.classList.remove('hidden');el.innerHTML='<p>Loading account history…</p>';
  try {
    const portfolio=state.run.id;
    const x=await request('/api/account?wallet='+encodeURIComponent(wallet)+'&run='+encodeURIComponent(portfolio));
    if(detailWallet!==wallet||viewedPortfolio!==portfolio)return;
    const a=state.accounts.find(a=>a.wallet===wallet);
    el.innerHTML=`<div class="card-head"><div><h3>${esc(a?.name||x.historical?.account_name||wallet)}</h3><span class="wallet">${esc(wallet)}</span></div><a class="button" href="https://polymarket.com/profile/${esc(wallet)}" target="_blank" rel="noopener noreferrer">Public profile ↗</a></div><div class="copy">Portfolio P&L while followed. Allocations between account slices are capital transfers, not profits.</div><div id="account-chart" class="chart"></div>${x.historical?`<hr><h3>Historical macro book · available archive</h3><p class="copy">Through ${esc(timestamp(Date.parse(x.historical.coverage_end)/1000))}. This source-account history is separate from your new paper run.</p><div id="source-chart" class="chart"></div>`:''}`;
    chart('account-chart',x.points.map(p=>({...p,nav:p.pnl})), 'No paper performance recorded for this account yet.');
    if(x.historical) {
      let nav=10000;const h=x.historical, points=[{ts:Date.parse(h.dates[0])/1000,nav}];
      h.returns.forEach((r,i)=>{nav*=1+(r||0);points.push({ts:Date.parse(h.dates[i+1])/1000,nav});});
      chart('source-chart',points);
    }
    el.insertAdjacentHTML('beforeend','<hr><div id="account-live-detail"></div>');renderAccountLiveDetail();
    el.scrollIntoView({behavior:'smooth',block:'start'});
  }catch(e){el.textContent=e.message;}
}

async function loadReplay() {
  clearInterval(replayTimer);replayTimer=null;$('replay-play').textContent='▶ Play';
  const portfolio=viewedPortfolio;
  try {const result=await request('/api/replay?case='+encodeURIComponent($('replay-case').value||state.run.case.case_id));if(portfolio!==viewedPortfolio)return;replay=result;replayIndex=0;$('replay-slider').max=replay.curve.length-1;renderReplay();}
  catch(e){toast(e.message);}
}
function performance(points) {
  if(points.length<3)return null;
  const r=points.slice(1).map((p,i)=>p.nav/points[i].nav-1),avg=r.reduce((a,b)=>a+b,0)/r.length;
  const sd=Math.sqrt(r.reduce((a,b)=>a+(b-avg)**2,0)/(r.length-1));
  return sd>1e-15?Math.sqrt(365)*avg/sd:null;
}
function renderReplay() {
  if(!replay)return;
  const points=replay.curve.slice(0,replayIndex+1),last=points[points.length-1],at=last.ts;
  const period=replay.periods.find(p=>Date.parse(p.period_start_utc)/1000<=at&&Date.parse(p.period_end_exclusive_utc)/1000>at)||replay.periods[replay.periods.length-1];
  const rows=replay.accounts.filter(a=>a.period_start_utc===period.period_start_utc);
  $('replay-nav').textContent=money(last.nav);$('replay-return').textContent=pct(last.nav/points[0].nav-1);$('replay-sharpe').textContent=dec(performance(points));$('replay-count').textContent=num(rows.length);$('replay-date').textContent=date(at)+' · historical';
  $('replay-slider').value=replayIndex;chart('replay-chart',points);
  $('replay-period').textContent=`Selected period: ${timestamp(Date.parse(period.period_start_utc)/1000)} → ${timestamp(Date.parse(period.period_end_exclusive_utc)/1000)} (end exclusive). ${replayIndex===replay.curve.length-1?'The test has ended; the final followed set is shown.':'The table displays the accounts selected at this reset.'}`;
  $('replay-accounts').innerHTML=table(['Account / full wallet','Reset weight','Raw Sharpe','Effective Sharpe','Volatility','History','Active / 40'],rows.map(a=>[
    accountCell(a),pct(Number(a.portfolio_weight),false),dec(a.raw_sharpe),dec(a.effective_sharpe),pct(Number(a.return_volatility_for_weight),false),num(a.history_observations),num(a.active_days_last_40)]),'The saved strategy selected no accounts for this period.');
  bindAccounts($('replay-accounts'));
}
$('replay-load').addEventListener('click',loadReplay);
$('replay-slider').addEventListener('input',e=>{replayIndex=Number(e.target.value);renderReplay();});
$('replay-end').addEventListener('click',()=>{if(replay){replayIndex=replay.curve.length-1;renderReplay();}});
$('replay-play').addEventListener('click',()=>{
  if(!replay)return;
  if(replayTimer){clearInterval(replayTimer);replayTimer=null;$('replay-play').textContent='▶ Play';return;}
  if(replayIndex===replay.curve.length-1)replayIndex=0;
  $('replay-play').textContent='Ⅱ Pause';
  replayTimer=setInterval(()=>{replayIndex=Math.min(replay.curve.length-1,replayIndex+1);renderReplay();if(replayIndex===replay.curve.length-1){clearInterval(replayTimer);replayTimer=null;$('replay-play').textContent='▶ Play';}},180);
});
function newPortfolioMode() {
  const live=$('new-mode').value==='live';
  $('new-live-credentials').classList.toggle('hidden',!live);
  $('new-live-credentials').disabled=!live;
  $('new-live-credentials').querySelectorAll('input').forEach(input=>{input.required=live;if(!live)input.value='';});
  renderCopyControls();
}
$('new-mode').addEventListener('change',newPortfolioMode);
$('new-form').addEventListener('submit',async e=>{
  e.preventDefault();
  if(!$('new-form').reportValidity())return;
  const extra={name:$('portfolio-name').value.trim(),case_id:$('case-select').value,capital:Number($('capital').value),mode:$('new-mode').value};
  if(extra.mode==='live') {
    extra.wallet=$('new-wallet').value.trim();extra.private_key=$('new-signing-key').value.trim();
    extra.credentials={apiKey:$('new-api-key').value.trim(),secret:$('new-api-secret').value.trim(),passphrase:$('new-api-passphrase').value.trim()};
    ['new-signing-key','new-api-key','new-api-secret','new-api-passphrase'].forEach(id=>$(id).value='');
  }
  try {await action('new',extra);}finally {delete extra.private_key;delete extra.credentials;}
});
$('issues-button').addEventListener('click',async()=>{try{const rows=await request('/api/screen-issues?run='+encodeURIComponent(state.run.id));$('issues').innerHTML=rows.length?table(['Account','Pending observation'],rows.map(r=>[esc(r.wallet),esc(r.reasons.join('; '))])):'No unresolved account histories reported in this screen.';}catch(e){toast(e.message);}});

async function init(){
  await refresh();if(!state)return;
  try {
    cases=await request('/api/cases');
    const options=cases.map(c=>`<option value="${esc(c.case_id)}">${esc(label(c))}</option>`).join('');
    $('case-select').innerHTML=options;$('replay-case').innerHTML=options;
    $('case-select').value=state.run.case.case_id;$('replay-case').value=state.run.case.case_id;
    newPortfolioMode();
  }catch(e){toast(e.message);}
}
init();setInterval(refresh,5000);

function age(t){return t==null?'—':`${Math.max(0,Math.round(state.now-t))}s ago`;}
function renderRealtime(){
  const r=state.run,f=state.feeds,m=f.market,live=state.execution.live;
  const isLive=r.mode==='live';
  $('mode-badge').textContent=isLive?'REAL MONEY':'SANDBOX';$('mode-badge').className='pill '+(isLive?'warn':'neutral');
  $('rail-mode').textContent=isLive?'Real-money portfolio':'Sandbox execution';
  $('rail-status').textContent=isLive?(live.armed?'Real orders enabled.':'Real orders disabled.'):'Live data. Simulated positions.';
  const good=f.accounts.filter(a=>a.checked_at&&!a.error&&!a.needs_refresh&&state.now-a.checked_at<=Math.max(15,(a.cycle_seconds||0)*2));
  $('execution-banner').textContent=`Current portfolio: ${isLive?'REAL MONEY':'SANDBOX'} ? ${money(r.initial)} initial budget. ${isLive ? `${live.armed?'REAL ROUTING ENABLED':'Real routing disabled'}. BUYs and SELLs use post-only midpoint LMT orders, checked every 60 seconds and rounded to valid ticks. Only confirmed exchange fills change holdings. No market orders.` : 'BUYs and SELLs assume immediate fills at the current bid/ask midpoint. No trade-print, depth or queue requirement. Each followed account trades within its own allocation.'}`;
  $('live-connection').innerHTML=live.connected?`<span class="pill good">CONNECTED</span><p class="wallet">${esc(live.wallet)}</p><p>Available wallet collateral: <b>${money(live.available_collateral)}</b></p><p>Routing: <b>${live.armed?'Enabled':'Disabled'}</b> · credentials held in memory only</p>`:`<span class="pill neutral">DISCONNECTED</span><p>${esc(live.error||'No account credentials are connected.')}</p>`;
  $('arm-button').disabled=!isLive||!live.connected||live.armed;
  $('execution-pending').textContent=(r.execution_pending||[]).join(' · ');
  $('orders-table').innerHTML=orderTable(state.execution.orders);bindAccounts($('orders-table'));
  if(m.connected&&good.length){$('connection').textContent='LIVE DATA CONNECTED';$('connection').className='pill good';}
}
$('connect-form').addEventListener('submit',async e=>{
  e.preventDefault();const b=$('connect-button');b.disabled=true;b.textContent='Connecting…';
  const extra={wallet:$('wallet-address').value.trim(),private_key:$('signing-key').value.trim()};
  if($('api-key').value||$('api-secret').value||$('api-passphrase').value)extra.credentials={apiKey:$('api-key').value.trim(),secret:$('api-secret').value.trim(),passphrase:$('api-passphrase').value.trim()};
  ['signing-key','api-key','api-secret','api-passphrase'].forEach(id=>$(id).value='');
  try{await action('connect',extra);}finally{delete extra.private_key;delete extra.credentials;b.disabled=false;b.textContent='Connect account';}
});
$('arm-button').addEventListener('click',()=>{if(!$('arm-ack').checked){toast('Check the real-order authorization box before enabling routing.');return;}action('arm',{acknowledge:'ENABLE REAL MONEY'});$('arm-ack').checked=false;});
$('reconcile-form').addEventListener('submit',e=>{e.preventDefault();action('reconcile_order',{exchange_order_id:$('exchange-order-id').value.trim()});});
