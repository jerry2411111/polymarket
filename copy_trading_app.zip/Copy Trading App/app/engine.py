"""Continuously mark and copy observed source books between selection resets."""
import concurrent.futures
import time

from core import DAY, account_nav, nav, utc
from execution import make_plan
from reporting import attach_source_events


def quotes(app, tokens, at):
    result = {}
    conditions = {app.catalog.token_condition[t] for t in tokens if t in app.catalog.token_condition}
    # Completed resolutions are cached forever. Unresolved conditions are
    # refreshed at most once per minute, independently of streamed book prices.
    check = getattr(app, '_resolution_check', {})
    pending = {c for c in conditions if at-check.get(c, 0) >= 60}
    if pending:
        app.api.settlements(pending, at)
        check.update({c: at for c in pending})
        app._resolution_check = check
    for condition in conditions:
        settlement = app.api.settled.get(condition)
        if settlement and settlement['timestamp'] <= at:
            for token, price in zip(app.catalog.tokens(condition), settlement['payouts']):
                if token in tokens:
                    result[token] = dict(price=price, timestamp=settlement['timestamp'], settled=True)
    status = app.market.snapshot()
    connected = status['connected'] and status.get('last_pong') and at-status['last_pong'] < 30
    def get(token):
        # A quiet book is not stale merely because no one has changed it.
        # Verify it with REST when there is no healthy subscribed stream.
        b = app.market.book(token)
        if not connected or token not in app.market.tokens:
            b = app.market.book(token, fresh=True)
        return b
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        jobs = {pool.submit(get, token): token for token in tokens-set(result)}
        for future in concurrent.futures.as_completed(jobs):
            result[jobs[future]] = future.result()
    return result


def poll(app, run_id=None, manage_feed=True):
    run = app.store.run(run_id)
    router = app.router_for(run) if hasattr(app, 'router_for') else app.router
    at = int(time.time())
    due = run.get('pending_selection_reset') or not run['next_reset'] or at >= run['next_reset']
    snapshot = app.snapshot_for(run) if hasattr(app, 'snapshot_for') else app.store.get('screen_snapshot', {})
    ready = app.snapshot_ready(run, snapshot, at)
    reset = run['status'] in ('running', 'waiting_for_screen') and due and ready
    if due and run['status'] in ('running', 'waiting_for_screen') and not ready:
        if run['status'] == 'running':
            with app.store.lock:
                current = app.store.run(run['id'])
                if current['id'] == run['id'] and current['status'] == 'running':
                    current['status'] = 'waiting_for_screen'
                    app.store.save(current)
                    run = current
        progress = app.store.get('screen_progress', {})
        if progress.get('case_id') != run['case']['case_id']:
            progress = {}
        if (not progress.get('paused_by_user') and at >= progress.get('retry_after', 0)
                and not (app.scanner.thread and app.scanner.thread.is_alive())):
            app.scanner.start(run['case'])
    metrics = snapshot['selected'] if reset else [a['metric'] for a in run['accounts'].values() if not a.get('exiting')]
    watch = {r['wallet']: dict(wallet=r['wallet'], name=r['name'], role='selected account' if not reset else 'new screen: waiting to allocate') for r in metrics}
    for w, a in run['accounts'].items():
        watch.setdefault(w, dict(wallet=w, name=a['name'], role='exiting account'))
    if manage_feed:
        app.feed.set_wallets(list(watch.values()) or app.probes)
    managed = {t for a in run['accounts'].values() for t,p in a['positions'].items() if not p.get('settled')}
    if manage_feed:
        app.feed.set_managed_tokens(managed)
    # Reconcile accepted orders even while paused; a local pause cannot erase an
    # exchange side effect which was already submitted.
    if run.get('active_order'):
        with app.store.lock:
            if not router.reconcile_active(run):
                return
    sources, source_error = {}, None
    recovery = run.get('recovery', {})
    if reset or run['status'] == 'running':
        for metric in metrics:
            try:
                sources[metric['wallet']] = app.feed.positions(metric['wallet'])
                if recovery.get('status') == 'pending' and sources[metric['wallet']]['checked_at'] < recovery['started_at']:
                    source_error = 'Refreshing saved account checkpoints before copying offline changes.'
            except ValueError as exc:
                source_error = str(exc)
    tokens = {t for a in run['accounts'].values() for t in a['positions']}
    tokens.update(p['token_id'] for source in sources.values() for p in source['positions'])
    prices = app.quotes(tokens, at)
    with app.store.lock:
        latest = app.store.run(run['id'])
        if (latest['id'] != run['id'] or latest['status'] != run['status'] or latest['last_sync'] != run['last_sync']
                or latest.get('selection_revision', 0) != run.get('selection_revision', 0)):
            return
        run.setdefault('resolved_tokens', {}).update({t:dict(price=q['price'],timestamp=q['timestamp'])
            for t,q in prices.items() if q.get('settled')})
        fills = []
        for wallet, a in run['accounts'].items():
            before = account_nav(a)
            for token, p in list(a['positions'].items()):
                q = prices[token]
                p.update(price=q['price'], quote_ts=q['timestamp'], settled=q.get('settled', False))
                if q.get('settled') and run.get('mode', 'sandbox') == 'sandbox':
                    dollars = p['shares'] * q['price']
                    a['cash'] += dollars
                    fills.append(dict(wallet=wallet, name=a['name'], token=token, title=p['title'], outcome=p['outcome'],
                        side='SETTLEMENT', shares=p['shares'], price=q['price'], notional=dollars,
                        quote_ts=q['timestamp'], reason='Observed resolved payout, credited in sandbox'))
                    a['positions'].pop(token)
            a['pnl'] = a.get('pnl', 0.) + account_nav(a)-before
        # Absolute source-book size changes do not create P&L. Relative weights
        # generate a target only when the observed inventory changes or resets.
        changed = any(s['inventory_key'] != run['accounts'].get(w, {}).get('source_key') for w,s in sources.items())
        selected = []
        if not source_error and not router.halt.is_set():
            if reset:
                if router.limit_orders(run) and not router.cancel_pending(run, 'Scheduled reset: cancel old limits before reallocating'):
                    return
                selected = snapshot['selected']
                make_plan(run, sources, prices, selected, snapshot['as_of'])
            elif run['status'] == 'running' and changed:
                make_plan(run, sources, prices)
            if recovery.get('status') == 'pending' and run['status'] == 'running':
                decisions = run.get('_copy_decisions', [])
                for decision in decisions:
                    if decision['kind'] == 'source_change':
                        decision['catch_up'] = True
                        decision['reason'] = 'Offline catch-up: adjust existing holdings to the latest source book'
                        run['execution_plan']['targets'][decision['wallet']]['reason'] = decision['reason']
                run['recovery'] = dict(recovery, status='reconciled', completed_at=time.time(),
                    accounts_checked=len(sources), changed_accounts=sum(d['kind'] == 'source_change' for d in decisions))
                app.store.log(f"Restart/resume sync checked {len(sources)} accounts; "
                              f"{run['recovery']['changed_accounts']} changed. Existing holdings retained; only differences sent for execution.", run_id=run['id'])
        run['last_sync'] = at
        run['issue'] = source_error
        attach_source_events(app.store, run)
        for wallet, source in sources.items():
            account = run['accounts'].get(wallet)
            if account and account.get('source_key') == source['inventory_key']:
                account['source_observed_at'] = source.get('checked_at', at)
        app.store.save(run, fills=fills, selected=selected, point=True)
        router.reconcile_redemptions(run)
        # No order goes out on a stale or incomplete followed-account snapshot.
        if not source_error and run['status'] == 'running':
            router.execute(run)
        elif run['status'] == 'paused' and router.limit_orders(run):
            router.cancel_pending(run, 'Copying paused')
        retired = run.setdefault('retired_accounts', {})
        for wallet, a in list(run['accounts'].items()):
            if (a.get('exiting') and not a['positions'] and not run.get('active_order')
                    and not any(o['intent']['wallet'] == wallet for o in router.limit_orders(run))):
                run['cash'] += a['cash']
                retired[wallet] = dict(name=a['name'], pnl=a.get('pnl',0))
                run['accounts'].pop(wallet)
                if run.get('execution_plan'):
                    run['execution_plan']['targets'].pop(wallet, None)
        app.store.save(run)
    if reset and not source_error and not router.halt.is_set():
        app.store.log(f"Selected all {len(selected)} qualifying accounts; next reset {utc(run['next_reset'])}.", run_id=run['id'])
