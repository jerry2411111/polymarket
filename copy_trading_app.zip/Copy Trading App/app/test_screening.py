"""Year-history selection and archive reuse; no online requests or live orders."""
import json
import tempfile
import threading
import unittest
import zlib
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import screening
from core import DAY, Store, Database


class ScreeningTests(unittest.TestCase):
    def test_cached_nonmacro_and_future_activity_are_excluded_from_metrics(self):
        marks=SimpleNamespace(by_condition={'fed':{}},event_slugs={'election'})
        rows=[dict(timestamp=10,condition_id='fed',type='TRADE'),
              dict(timestamp=11,condition_id='music',type='TRADE',title='Kanye West performs in Russia'),
              dict(timestamp=12,condition_id='sports',type='TRADE'),
              dict(timestamp=20,condition_id='fed',type='TRADE'),
              dict(timestamp=13,type='CONVERSION',event_slug='election')]
        self.assertEqual(screening.macro_activity(rows,marks,20),[rows[0],rows[4]])

    def test_discovery_reuses_overlap_but_scans_new_markets_and_stops_after_boundary(self):
        import sqlite3, hashlib
        at=1000*DAY;previous=at-4*DAY
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);worker=screening.Scanner.__new__(screening.Scanner)
            worker.path=root/'screen.sqlite';worker.cancel=threading.Event();worker.progress_last=0
            worker.progress=lambda *a,**kw:None
            worker.catalog=SimpleNamespace(markets={'old':{},'new':{}},refresh=lambda *a:None)
            with sqlite3.connect(root/'market_prices.sqlite',factory=Database) as db:
                db.execute('CREATE TABLE resolutions(condition TEXT,body TEXT)')
            with sqlite3.connect(worker.path,factory=Database) as db:
                db.executescript('''CREATE TABLE checkpoints(at,batch,cursor,done,PRIMARY KEY(at,batch));
                    CREATE TABLE activity(at,wallet,ts,token,side,tx,PRIMARY KEY(at,wallet,ts,token,side,tx));
                    CREATE TABLE seen_wallets(at,wallet,PRIMARY KEY(at,wallet));''')
                db.execute('INSERT INTO checkpoints VALUES(?,?,NULL,1)',(previous,hashlib.sha256(b'old').hexdigest()))
                db.executemany('INSERT INTO activity VALUES(?,?,?,?,?,?)',
                    [(previous,'a',at-d*DAY,'old-token','BUY',str(d)) for d in range(5,34)])
            (root/f'market_scope_{previous}.json').write_text(json.dumps(['old']))
            queries=[]
            def get(route,query):
                queries.append(dict(query));condition=query['condition']
                def row(wallet,ts):return dict(proxy_wallet=wallet,timestamp=ts,token_id=condition+'-token',side='BUY',transaction_hash=str(ts),condition_id=condition)
                if condition=='old':
                    # The API ignores dates for market queries. Stop at an older
                    # row, not the opaque cursor's end, and never import future rows.
                    rows=[row('A',at+1),row('A',previous),row('A',previous-1)]
                else:
                    rows=[row('B',at-d*DAY) for d in range(1,31)]+[row('B',at-41*DAY)]
                return dict(data=rows,pagination=dict(next_cursor='older-unused',has_more=True))
            worker.api=SimpleNamespace(get=get)
            with patch.object(screening,'DATA',root),patch.object(screening,'HISTORY',root):
                self.assertEqual(worker.discover(at),['a','b'])
            self.assertEqual(len(queries),2)
            self.assertEqual({q['condition']:q['start'] for q in queries},{'old':previous,'new':at-40*DAY})
            with sqlite3.connect(worker.path,factory=Database) as db:
                self.assertEqual(db.execute('SELECT count(*) FROM activity WHERE at=? AND ts>=?',(at,at)).fetchone()[0],0)

    def test_frequency_floor_excludes_overlap_future_and_non_macro_trades(self):
        import sqlite3
        at = 1000 * DAY
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            worker = screening.Scanner.__new__(screening.Scanner)
            worker.path = root / 'screen.sqlite'
            worker.archived = SimpleNamespace(end=at - 10 * DAY)
            with sqlite3.connect(worker.path, factory=Database) as db:
                db.execute('CREATE TABLE activity(at INTEGER,wallet TEXT,ts INTEGER)')
                db.executemany('INSERT INTO activity VALUES(?,?,?)',
                    [(at, 'w', at - 1), (at, 'w', at), (at, 'w', at - 41 * DAY)])
            with sqlite3.connect(root / 'expanded_market_trades.sqlite', factory=Database) as db:
                db.execute('CREATE TABLE trades(wallet TEXT,ts INTEGER,condition TEXT)')
                db.executemany('INSERT INTO trades VALUES(?,?,?)',
                    [('w', at - 100 * DAY + i, 'macro') for i in range(18248)] +
                    [('w', at - 100 * DAY, 'sports')] * 100 +
                    [('w', at - 40 * DAY, 'macro'), ('w', at - 366 * DAY, 'macro')])
            marks = SimpleNamespace(by_condition={'macro': {}})
            with patch.object(screening, 'HISTORY', root):
                # 18,249 verified trades cannot yet prove 50/day over a year.
                self.assertIsNone(worker.frequency_rejection('w', at, marks))
                with sqlite3.connect(root / 'expanded_market_trades.sqlite', factory=Database) as db:
                    db.execute('INSERT INTO trades VALUES(?,?,?)', ('w', at - 100 * DAY, 'macro'))
                rejected = worker.frequency_rejection('w', at, marks)
                self.assertEqual(rejected['average_trades_per_day_lower_bound'], 50)
                self.assertEqual(rejected['observed_annual_trade_count_lower_bound'], 18250)

    def test_75_day_boundary_starts_fresh_screen_and_manual_pause_is_respected(self):
        from server import Application
        from execution import ExecutionRouter
        at = 1000 * DAY
        with tempfile.TemporaryDirectory() as directory, patch('time.time', return_value=at):
            app = Application.__new__(Application)
            app.store = Store(Path(directory) / 'reset.sqlite')
            case = dict(case_id='case', reset_days=75)
            run = app.store.create(case, 10000)
            run.update(status='running', last_screen=at - 75 * DAY, next_reset=at)
            app.store.save(run)
            app.store.put('screen_snapshot', dict(complete=True, as_of=at - 75 * DAY, case_id='case', selected=[]))
            started = []
            app.scanner = SimpleNamespace(thread=None, start=lambda case: started.append(case))
            app.feed = SimpleNamespace(set_wallets=lambda rows: None, set_managed_tokens=lambda tokens: None)
            app.probes = []
            app.quotes = lambda *args: {}
            app.router = ExecutionRouter(app.store, None)
            app.poll()
            self.assertEqual(started, [case])
            self.assertEqual(app.store.run()['status'], 'waiting_for_screen')
            app.store.put('screen_progress', dict(paused_by_user=True, case_id='case'))
            app.poll()
            self.assertEqual(started, [case])

    def test_one_unresolved_history_does_not_veto_verified_yearly_selection(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(Path(directory) / 'portfolio.sqlite')
            worker = screening.Scanner.__new__(screening.Scanner)
            worker.store, worker.path = store, Path(directory) / 'screen.sqlite'
            worker.cancel = threading.Event()
            worker.catalog = worker.api = None
            worker.discover = lambda at: ['pass-A', 'pass-B', 'unresolved', 'outside-range']
            worker.progress = lambda stage, **kw: store.put('screen_progress', dict(stage=stage, **kw))
            import sqlite3
            with sqlite3.connect(worker.path, factory=Database) as db:
                db.execute('CREATE TABLE accounts(at INTEGER,wallet TEXT,status TEXT,body TEXT,PRIMARY KEY(at,wallet))')
            captured = []
            def account(wallet, at, marks):
                captured.append((wallet, at, screening.model_module.BACKUP_START))
                if wallet == 'unresolved':
                    return dict(wallet=wallet, status='data_pending', reasons=['Missing observable shares'])
                return dict(wallet=wallet, name=wallet, status='computed', qualifies_style_and_activity=True,
                    effective_sharpe=4.1 if wallet == 'outside-range' else 3.5,
                    volatility_available_history=.01 if wallet == 'pass-A' else .02)
            worker.account = account
            at = 1000 * DAY
            with patch.object(screening, 'ArchiveInputs'), patch.object(screening, 'LiveMarks'), patch.object(screening.model_module, 'BACKUP_START', 0):
                worker.run(dict(case_id='test', screen_metric='effective', lower=3, upper=4, volatility_days=365), at)
            snapshot = store.get('screen_snapshot')
            self.assertTrue(snapshot['complete'])
            self.assertFalse(snapshot['coverage_complete'])
            self.assertEqual(snapshot['unresolved_accounts'], 1)
            self.assertEqual({r['wallet'] for r in snapshot['selected']}, {'pass-A', 'pass-B'})
            self.assertAlmostEqual(snapshot['selected'][0]['weight'], 2/3)
            self.assertTrue(all(boundary == at and start == at - 366 * DAY for _, boundary, start in captured))

    def test_resolved_archived_prices_do_not_need_redownload_or_future_marks(self):
        import sqlite3
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'early_market_quotes').mkdir()
            with sqlite3.connect(root / 'market_prices.sqlite', factory=Database) as db:
                db.execute('CREATE TABLE prices(token TEXT PRIMARY KEY,body BLOB)')
                db.execute('INSERT INTO prices VALUES(?,?)', ('t', zlib.compress(json.dumps([[100,.2],[200,.3],[700,.9]]).encode())))
            marks = screening.LiveMarks.__new__(screening.LiveMarks)
            marks.series = {}
            marks.cache = root
            marks.at, marks.archive_end = 600, 500
            marks.resolved = {'t': (400, 1.)}
            marks.token_condition = {'t': 'c'}
            marks.locks = [threading.RLock()]
            def forbidden(*args, **kw):
                raise AssertionError('Resolved archival prices must be reused')
            marks.api = SimpleNamespace(pages=forbidden)
            with patch.object(screening, 'HISTORY', root):
                times, prices = marks.load('t')
            self.assertEqual(list(times), [100, 200])
            self.assertEqual(list(prices), [.2, .3])

    def test_unresolved_price_update_requests_only_unarchived_window(self):
        import sqlite3
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'early_market_quotes').mkdir()
            with sqlite3.connect(root / 'market_prices.sqlite', factory=Database) as db:
                db.execute('CREATE TABLE prices(token TEXT PRIMARY KEY,body BLOB)')
                db.execute('INSERT INTO prices VALUES(?,?)', ('t', zlib.compress(json.dumps([[20000,.4]]).encode())))
            marks = screening.LiveMarks.__new__(screening.LiveMarks)
            marks.series, marks.resolved = {}, {}
            marks.cache = root
            marks.at, marks.archive_end = 70000, 50000
            marks.token_condition = {'t': 'c'}
            marks.locks = [threading.RLock()]
            queries = []
            def pages(route, query):
                queries.append(query)
                return [[dict(timestamp=50000, resolution_seconds=10800, price=.5),
                         dict(timestamp=69000, resolution_seconds=10800, price=.9)]]
            marks.api = SimpleNamespace(pages=pages)
            with patch.object(screening, 'HISTORY', root):
                times, prices = marks.load('t')
            self.assertEqual(queries[0]['start'], 50000 - 10800)
            self.assertEqual(queries[0]['end'], 70000)
            self.assertNotIn('interval', queries[0])
            self.assertEqual(list(times), [20000, 60800])
            self.assertEqual(list(prices), [.4, .5])


if __name__ == '__main__':
    unittest.main(verbosity=2)
