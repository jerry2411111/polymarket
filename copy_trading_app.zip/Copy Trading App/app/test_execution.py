"""Material execution checks. All brokers/quotes in these tests are local fakes."""
import copy
import tempfile
import unittest
import threading
from pathlib import Path
from types import SimpleNamespace

from core import Store, nav
from execution import ExecutionRouter, SandboxBroker, LiveBroker, make_plan
from decimal import Decimal


class ExecutionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.temp.name)/'test.sqlite')
        self.run=self.store.create(dict(case_id='x',reset_days=75),1000)
        self.q=dict(price=.5,timestamp=100,bids=[(.49,100)],asks=[(.51,100)],bid=.49,ask=.51,min_order_size=5)
        self.router=ExecutionRouter(self.store,SimpleNamespace(book=lambda token,fresh=False:copy.deepcopy(self.q)))
        source=dict(positions=[dict(token_id='x',current_size=100,title='Iran',outcome='Yes',condition_id='c')],inventory_key='first')
        make_plan(self.run,{'A':source},{'x':self.q},[dict(wallet='A',name='A',sigma=.01,weight=1)],100)
        self.store.save(self.run)

    def tearDown(self):
        self.temp.cleanup()

    def test_sandbox_cannot_calculate_midpoint_without_both_quotes(self):
        self.q.update(bids=[], asks=[], bid=None, ask=None, min_order_size=100000)
        self.router.execute(self.run)
        self.assertEqual(self.run['accounts']['A']['positions'],{})
        self.assertAlmostEqual(self.run['accounts']['A']['cash'],1000)
        self.assertAlmostEqual(nav(self.run),1000)
        self.router.execute(self.run)
        self.assertEqual(len(self.store.rows('SELECT * FROM fills')),0)

    def test_live_still_obeys_exchange_minimum_and_never_assumes_a_fill(self):
        self.run['mode']='live'
        self.router.live.armed=True
        self.q['min_order_size']=100000
        self.router.execute(self.run)
        self.assertEqual(self.store.rows('SELECT * FROM fills'),[])
        self.assertEqual(self.store.rows('SELECT * FROM execution_orders'),[])

    def test_sandbox_direct_submit_cannot_bypass_persistent_ledger(self):
        with self.assertRaisesRegex(ValueError,'persistent midpoint router'):
            SandboxBroker().submit(dict(side='BUY',shares=100,cash_limit=12),dict(price=.5))

    def test_pause_prevents_new_orders(self):
        self.router.halt.set()
        self.router.execute(self.run)
        self.assertEqual(self.store.rows('SELECT * FROM execution_orders'),[])

    def test_confirmed_fill_applied_once_across_restart(self):
        self.router.execute(self.run)
        self.q.update(ask=.49,asks=[(.49,100000)])
        self.router.execute(self.run)
        order=self.router.orders(self.run['id'])[0]
        before=self.store.run()
        with self.assertRaises(ValueError):
            self.router.apply(copy.deepcopy(before),order['id'],order['intent'],order['result'])
        self.assertEqual(self.store.run(),before)
        self.assertEqual(len(self.store.rows('SELECT * FROM fills')),1)

    def test_unknown_live_order_is_not_retried(self):
        self.run['mode']='live'
        self.router.live.armed=True
        self.router.live.prepare=lambda intent:None
        submitted=[]
        def submit(intent, book):
            submitted.append(intent)
            raise TimeoutError('ambiguous exchange response')
        self.router.live.submit=submit
        with self.assertRaises(ValueError):self.router.execute(self.run)
        restarted=ExecutionRouter(self.store,self.router.market)
        restarted.live.armed=True
        restarted.live.submit=submit
        with self.assertRaises(ValueError):restarted.execute(self.store.run())
        self.assertEqual(len(submitted),1)
        self.assertEqual(self.store.rows('SELECT * FROM fills'),[])

    def test_accepted_live_order_does_not_fabricate_fill(self):
        self.run['mode']='live'
        self.router.live.armed=True
        self.router.live.prepare=lambda intent:None
        self.router.live.submit=lambda intent,book:dict(state='submitted',shares=0,notional=0,exchange_order_id='test')
        self.router.execute(self.run)
        self.assertEqual(len(self.router.limit_orders(self.store.run())),1)
        self.assertEqual(self.run['accounts']['A']['positions'],{})
        self.assertEqual(self.store.rows('SELECT * FROM fills'),[])

    def test_order_and_portfolio_intent_are_atomic(self):
        broken=copy.deepcopy(self.run)
        broken['active_order']='intent'
        broken['cash']=float('nan')
        with self.assertRaises(ValueError):
            self.store.save(broken,order_insert=('intent','posting',dict(intent={})))
        self.assertEqual(self.store.rows('SELECT * FROM execution_orders'),[])
        self.assertFalse(self.store.run().get('active_order'))

    def test_live_cash_must_match_confirmed_fills_and_actual_fee(self):
        broker=LiveBroker()
        trade=SimpleNamespace(id='t',taker_order_id='order',status='CONFIRMED',
            size=Decimal('10'),price=Decimal('.5'),fee_rate_bps=Decimal('500'))
        broker.client=SimpleNamespace(list_account_trades=lambda **kw:[trade],
            get_balance_allowance=lambda asset_type,**kw:SimpleNamespace(balance=994875000 if asset_type=='COLLATERAL' else 60000000))
        intent=dict(token='x',side='BUY',limit_price=.5,before_balances=dict(cash=1000,shares=50))
        result=broker.reconcile(intent,dict(exchange_order_id='order',response=dict(trade_ids=['t'])))
        self.assertEqual(result['state'],'filled')
        self.assertAlmostEqual(result['cash_amount'],5.125)
        self.assertAlmostEqual(result['fee'],.125)
        self.assertEqual(result['shares'],10)
        broker.client.get_balance_allowance=lambda asset_type,**kw:SimpleNamespace(balance=1994875000 if asset_type=='COLLATERAL' else 60000000)
        with self.assertRaises(ValueError):
            broker.reconcile(intent,dict(exchange_order_id='order',response=dict(trade_ids=['t'])))

    def test_resolved_live_position_is_not_cash_until_redeemed(self):
        self.run['mode']='live'
        a=self.run['accounts']['A']
        a['cash']=900
        a['positions']['x']=dict(shares=100,cost=50,price=1,quote_ts=101,settled=True,title='Iran',outcome='Yes',condition_id='c')
        self.run['wallet_cash_observed']=900
        self.router.live.client=SimpleNamespace(get_balance_allowance=lambda asset_type,**kw:SimpleNamespace(balance=900000000 if asset_type=='COLLATERAL' else 100000000))
        self.router.reconcile_redemptions(self.run)
        self.assertEqual(a['cash'],900)
        self.assertIn('x',a['positions'])
        self.run['last_redemption_check']=0
        self.router.live.client.get_balance_allowance=lambda asset_type,**kw:SimpleNamespace(balance=1000000000 if asset_type=='COLLATERAL' else 0)
        self.router.reconcile_redemptions(self.run)
        self.assertEqual(a['cash'],1000)
        self.assertNotIn('x',a['positions'])
        self.assertAlmostEqual(nav(self.run),1000)
        self.assertEqual(len(self.store.rows('SELECT * FROM fills')),1)

    def test_missing_subject_metadata_is_not_a_silent_nonmacro_exclusion(self):
        from screening import Catalog
        c=Catalog.__new__(Catalog)
        c.markets={};c.token_condition={};c.rejected=set();c.lock=threading.RLock()
        api=SimpleNamespace(get=lambda *args,**kw:[])
        with self.assertRaises(ValueError):
            c.relevant_positions([dict(condition_id='new',title='',current_size=10)],api)
        source=dict(condition_id='fed',title='Will the Fed cut interest rates?',current_size=10,token_id='x',opposite_token_id='y',outcome_index=0,event_slug='fed-decision')
        self.assertEqual(c.relevant_positions([source],api),[source])
        self.assertEqual(c.relevant_positions([dict(condition_id='btc',title='Bitcoin Up or Down',current_size=10)],api),[])

if __name__=='__main__':unittest.main(verbosity=2)
