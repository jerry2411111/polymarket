"""Proportionally rebase a sandbox ledger while the local server is stopped."""
import argparse
import json
import math
import time

from core import Store


def multiply(row, keys, factor):
    for key in keys:
        if row.get(key) is not None:
            row[key] *= factor


def rebase_sandbox(store, run_id, capital):
    capital = float(capital)
    if not math.isfinite(capital) or capital <= 0:
        raise ValueError('Capital must be positive.')
    with store.lock, store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('SELECT body FROM runs WHERE id=?', (run_id,)).fetchone()
        if not row:
            raise ValueError('Unknown portfolio.')
        run = json.loads(row[0])
        if run.get('mode', 'sandbox') != 'sandbox':
            raise ValueError('Real-money ledgers cannot be rebased.')
        if run.get('active_order'):
            raise ValueError('Finish reconciling the pending order first.')
        previous = run['initial']
        factor = capital / previous
        if factor == 1:
            return dict(run_id=run_id, previous=previous, capital=capital, factor=1)
        multiply(run, ['initial','cash'], factor)
        for account in run['accounts'].values():
            multiply(account, ['cash','pnl','period_capital'], factor)
            for position in account['positions'].values():
                multiply(position, ['shares','cost'], factor)
        for account in run.get('retired_accounts', {}).values():
            multiply(account, ['pnl'], factor)
        plan = run.get('execution_plan', {})
        for target in plan.get('targets', {}).values():
            target['shares'] = {token:shares*factor for token,shares in target['shares'].items()}
        plan['attempts'] = {}
        run.setdefault('capital_rebases', []).append(dict(at=time.time(), previous=previous,
            capital=capital, factor=factor, method='Proportional sandbox ledger rebase; source observations unchanged'))
        db.execute('UPDATE runs SET body=? WHERE id=?', (json.dumps(run,allow_nan=False),run_id))
        db.execute('UPDATE points SET nav=nav*?,cash=cash*? WHERE run=?', (factor,factor,run_id))
        db.execute('UPDATE account_points SET nav=nav*?,pnl=pnl*? WHERE run=?', (factor,factor,run_id))
        db.execute('UPDATE fills SET shares=shares*?,notional=notional*? WHERE run=?', (factor,factor,run_id))
        for row in db.execute('SELECT id,body FROM copy_decisions WHERE run=?',(run_id,)).fetchall():
            decision = json.loads(row['body'])
            for adjustment in decision['adjustments']:
                multiply(adjustment,['shares'],factor)
            decision['target_shares'] = {token:shares*factor for token,shares in decision['target_shares'].items()}
            db.execute('UPDATE copy_decisions SET body=? WHERE id=?',(json.dumps(decision,allow_nan=False),row['id']))
        for row in db.execute('SELECT id,body FROM execution_orders WHERE run=?',(run_id,)).fetchall():
            order = json.loads(row['body'])
            multiply(order['intent'], ['shares','cash_limit'], factor)
            multiply(order.get('result',{}), ['shares','notional','cash_amount','fee'], factor)
            db.execute('UPDATE execution_orders SET body=? WHERE id=?',(json.dumps(order,allow_nan=False),row['id']))
        db.execute('INSERT INTO journal(ts,level,message,run) VALUES(?,?,?,?)',
            (int(time.time()),'info',f'Sandbox starting capital changed from ${previous:,.2f} to ${capital:,.2f}. Simulated dollar history and holdings scaled proportionally; percentage returns preserved.',run_id))
    return dict(run_id=run_id,previous=previous,capital=capital,factor=factor)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run_id')
    parser.add_argument('capital',type=float)
    args = parser.parse_args()
    print(json.dumps(rebase_sandbox(Store(),args.run_id,args.capital)))
