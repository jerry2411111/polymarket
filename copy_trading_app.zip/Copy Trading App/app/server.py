"""Run: python3.14 server.py --port 8790 [--open] [--screen]."""
from __future__ import annotations

import argparse
import concurrent.futures
import copy
import http.server
import json
import math
import secrets
import threading
import time
import urllib.parse
import webbrowser
from pathlib import Path

from api import PublicAPI
from core import (Archive, DATA, DAY, DEFAULT_CASE, HERE, HISTORY, Database, Store, account_nav,
                  cash_value, csv_text, nav, portfolio_stats, rebalance_account, stats, utc)
from screening import Catalog, Scanner
from realtime import AccountFeed, MarketFeed, ACCOUNT_POLL_SECONDS
from execution import ExecutionRouter, LiveBroker, make_plan
from reporting import portfolio_breakdown, copy_activity


class Application:
    def __init__(self):
        self.store = Store()
        self.archive = Archive()
        self.catalog = Catalog()
        self.scanner = Scanner(self.store, self.catalog)
        self.api = PublicAPI()
        self.stop = threading.Event()
        self.wake = threading.Event()
        self.csrf = secrets.token_urlsafe(32)
        self.port = 8790
        if not self.store.run():
            self.store.create(self.archive.case(DEFAULT_CASE), 10000)
        self.market = MarketFeed()
        self.feed = AccountFeed(self.store, self.catalog, self.market)
        self.routers = {}
        self.router_lock = threading.RLock()
        self.router = self.router_for(self.store.run())
        for row in self.store.rows('SELECT body FROM runs'):
            run = json.loads(row['body'])
            if run.get('mode') == 'live':
                run['status'] = 'paused'
                run['issue'] = 'Reconnect the same wallet and explicitly enable live routing after restart.'
                self.store.save(run)
            elif run.get('accounts'):
                self.prepare_resume(run)
                self.store.save(run)
                self.store.log('Restored saved sandbox holdings. Checking changes since the last saved observation.', run_id=run['id'])
        replay = self.archive.replay(DEFAULT_CASE)
        last = max(r['period_start_utc'] for r in replay['accounts'])
        self.probes = [dict(wallet=r['wallet'], name=r.get('account_name') or r.get('name') or r['wallet'], role='archive feed probe')
                       for r in replay['accounts'] if r['period_start_utc'] == last]
        self.worker = threading.Thread(target=self.loop, name='live-portfolio', daemon=True)
        self.worker.start()

    def router_for(self, run):
        if not hasattr(self, 'routers'):
            return self.router
        with self.router_lock:
            if run['id'] not in self.routers:
                self.routers[run['id']] = ExecutionRouter(self.store, self.market)
            return self.routers[run['id']]

    def snapshot_for(self, run):
        snapshot = self.store.get('screen_snapshot:' + run['case']['case_id'], {})
        if not snapshot:
            snapshot = self.store.get('screen_snapshot', {})
        if snapshot.get('case_id') != run['case']['case_id']:
            return {}
        removed = set(run.get('excluded_wallets', {}))
        if removed:
            from core import inverse_weights
            snapshot = dict(snapshot, selected=inverse_weights([a for a in snapshot['selected'] if a['wallet'] not in removed]),
                            manually_removed=sorted(removed))
        return snapshot

    def portfolio_list(self):
        result = []
        for row in self.store.rows('SELECT body FROM runs ORDER BY rowid DESC'):
            r = json.loads(row['body'])
            result.append(dict(id=r['id'], name=r.get('name') or ('Sandbox ' if r.get('mode','sandbox') == 'sandbox' else 'Real money ') + r['id'][:6],
                mode=r.get('mode','sandbox'), status=r['status'], initial=r['initial'], case_id=r['case']['case_id']))
        return result

    def state(self, run_id=None):
        run = self.store.run(run_id)
        if not run:
            raise ValueError('Unknown saved portfolio.')
        router = self.router_for(run)
        points = self.store.rows('SELECT ts,nav,cash FROM points WHERE run=? ORDER BY ts', (run['id'],))
        performance = portfolio_stats(run, points, int(time.time()))
        accounts, positions, allocation = portfolio_breakdown(run)
        progress = self.store.get('screen_progress', {})
        snapshot = self.snapshot_for(run)
        if progress.get('case_id') != run['case']['case_id']:
            progress = snapshot.get('discovery', {}) if snapshot else {}
        selection_date = run.get('last_screen') or progress.get('as_of') or run['created_at'] // DAY * DAY
        wallets = set(run['accounts'])
        events = self.store.rows('SELECT id,wallet,observed_at,event_at,body FROM source_events WHERE wallet IN (' + ','.join('?' for _ in wallets) + ') ORDER BY observed_at DESC LIMIT 60', tuple(wallets)) if wallets else []
        events = [dict(json.loads(e.pop('body')), **e) for e in events]
        return dict(run=run, nav=nav(run), cash=cash_value(run), performance=performance, points=points,
            feeds=dict(market=self.market.snapshot(), accounts=[a for a in self.feed.snapshot() if a['wallet'] in wallets], events=events, poll_target_seconds=ACCOUNT_POLL_SECONDS),
            execution=dict(live=router.live.status(), orders=router.orders(run['id'])),
            accounts=accounts, positions=positions, allocation=allocation, copy_activity=copy_activity(self.store, run), screen=progress,
            selection_snapshot=snapshot,
            reset_schedule=dict(selection_date=selection_date, history_start=selection_date - 365 * DAY,
                                next_reset=run.get('next_reset') or selection_date + run['case']['reset_days'] * DAY),
            fills=self.store.rows('SELECT * FROM fills WHERE run=? ORDER BY id DESC LIMIT 300', (run['id'],)),
            journal=self.store.rows('SELECT * FROM journal WHERE run=? ORDER BY id DESC LIMIT 35', (run['id'],)),
            api=dict(last_ok=max(self.api.last_ok or 0, self.scanner.api.last_ok or 0) or None,
                     last_error=self.api.last_error, requests=self.api.calls + self.scanner.api.calls),
            now=int(time.time()), csrf=self.csrf,
            archive_accounts=1691425, archive_markets=50508,
            runs=self.portfolio_list())

    @staticmethod
    def prepare_resume(run):
        if run.get('accounts'):
            run['recovery'] = dict(status='pending', started_at=time.time(),
                since=min((a.get('source_observed_at') or run.get('last_sync') or time.time())
                          for a in run['accounts'].values()))

    def create_portfolio(self, body):
        mode = body.get('mode', 'sandbox')
        if mode not in ('sandbox', 'live'):
            raise ValueError('Choose sandbox or real-money mode.')
        case = self.archive.case(body['case_id'])
        capital = float(body.get('capital', 10000))
        if not math.isfinite(capital) or not 0 < capital <= 1e9:
            raise ValueError('Starting capital must be between 0 and $1 billion.')
        broker = None
        saved = False
        try:
            if mode == 'live':
                wallet = str(body.get('wallet', '')).strip().lower()
                private_key = str(body.get('private_key', '')).strip()
                credentials = body.get('credentials')
                if (not wallet or not private_key or not isinstance(credentials, dict)
                        or not all(isinstance(credentials.get(k), str) and credentials[k].strip()
                                   for k in ('apiKey','secret','passphrase'))):
                    raise ValueError('Real portfolio creation requires a wallet address, signing private key, API key, API secret and API passphrase.')
                if len(wallet) != 42 or not wallet.startswith('0x') or any(c not in '0123456789abcdef' for c in wallet[2:]):
                    raise ValueError('Enter a valid Polymarket trading wallet address.')
                key_hex = private_key[2:] if private_key.startswith('0x') else private_key
                if len(key_hex) != 64 or any(c not in '0123456789abcdefABCDEF' for c in key_hex):
                    raise ValueError('Enter a valid signing private key.')
                broker = LiveBroker()
                broker.connect(private_key, wallet, credentials)
                # Validate funding and trading permissions without placing orders.
                try:
                    broker.preflight(capital)
                except Exception as exc:
                    known = ('The requested live budget exceeds available collateral.',
                             'Collateral approval is missing. Set trading approvals through Polymarket first.',
                             'This account is in exchange closed-only mode.',
                             'This wallet has open exchange orders. Resolve them before enabling a separate automated run.')
                    raise ValueError(str(exc) if str(exc) in known else 'Could not verify wallet funding and trading permissions. The portfolio was not created.') from None
            with self.store.lock:
                run = self.store.create(case, capital, mode, body.get('name'), activate=False)
                if broker:
                    run['live_wallet'] = broker.wallet
                    run['wallet_cash_observed'] = broker.cash
                    self.store.save(run)
                    self.router_for(run).live = broker
                    self.store.log('Credentials and trading permissions verified. Real routing remains disabled.', run_id=run['id'])
                saved = True
            self.wake.set()
            return dict(run_id=run['id'])
        finally:
            if broker and not saved:
                broker.disconnect()

    def command(self, action, body):
        if action not in ('new','start','pause','disarm','disconnect','connect','arm','reconcile_order','screen','stop_screen','refresh','remove_account'):
            raise ValueError('Unknown action. Choose a saved portfolio to view it.')
        run = self.store.run(body.get('run_id'))
        if not run:
            raise ValueError('Unknown saved portfolio.')
        if action == 'new':
            return self.create_portfolio(body)
        run_id = run['id']
        router = self.router_for(run)
        if action in ('pause', 'disarm', 'disconnect'):
            router.halt.set()
            router.live.armed = False
        with self.store.lock:
            run = self.store.run(run_id)
            if action == 'start':
                if run.get('mode') == 'live' and not router.live.armed:
                    raise ValueError('Connect and explicitly enable real-money execution on the Execution page first.')
                router.halt.clear()
                if run['status'] == 'paused':
                    self.prepare_resume(run)
                snapshot = self.snapshot_for(run)
                due = run.get('pending_selection_reset') or not run['next_reset'] or time.time() >= run['next_reset']
                ready = self.snapshot_ready(run, snapshot, int(time.time()))
                if due and not ready:
                    run['status'] = 'waiting_for_screen'
                    if not (self.scanner.thread and self.scanner.thread.is_alive()):
                        self.scanner.start(run['case'])
                else:
                    run['status'] = 'running'
                run['issue'] = None
                self.store.save(run)
                self.store.log('Copying resumed with saved holdings; checking intervening source changes.'
                               if run['status'] == 'running' else 'Selecting accounts; copying will start automatically when ready.', run_id=run_id)
            elif action in ('pause', 'disarm', 'disconnect'):
                run['status'] = 'paused'
                self.store.save(run)
                router.cancel_pending(run, 'User paused/disarmed copying')
                if action == 'disconnect':
                    if router.limit_orders(run):
                        raise ValueError('Limit cancellations or fills are still reconciling. Retry disconnect after they finish.')
                    router.live.disconnect()
                self.store.log('Copying paused. Existing positions remain marked; in-flight orders are still reconciled.', run_id=run_id)
            elif action == 'remove_account':
                if run.get('mode', 'sandbox') != 'sandbox':
                    raise ValueError('This manual selection action is available for sandbox portfolios.')
                from execution import remove_selected_account
                from limit_orders import cancel
                wallet = str(body.get('wallet', '')).lower()
                remove_selected_account(run, wallet)
                self.store.save(run)
                pending = {o['id'] for o in router.limit_orders(run) if o['intent']['wallet'] == wallet}
                cancel(router, run, 'User removed followed account', order_ids=pending)
                self.store.log('Excluded ' + run['accounts'][wallet]['name'] +
                    ' from current and future selections; remaining accounts will be reweighted by inverse volatility.', run_id=run_id)
            elif action == 'connect':
                wallet = str(body.get('wallet', '')).lower()
                if run.get('live_wallet') and wallet != run['live_wallet'].lower():
                    raise ValueError('Reconnect the wallet bound to this live portfolio.')
                router.live.connect(body.get('private_key', ''), wallet, body.get('credentials'))
            elif action == 'arm':
                if run.get('mode') != 'live' or body.get('acknowledge') != 'ENABLE REAL MONEY':
                    raise ValueError('Create a live portfolio and acknowledge its real-money execution before enabling it.')
                if run.get('live_wallet') and run['live_wallet'].lower() != str(router.live.wallet).lower():
                    raise ValueError('This live portfolio belongs to a different wallet.')
                for row in self.store.rows('SELECT body FROM runs WHERE id<>?', (run_id,)):
                    other = json.loads(row['body'])
                    if (other.get('mode') == 'live' and other.get('live_wallet')
                            and other['live_wallet'].lower() == str(router.live.wallet).lower()
                            and (other['status'] in ('running','waiting_for_screen') or other.get('active_order')
                                 or any(a['positions'] for a in other['accounts'].values()))):
                        raise ValueError('This wallet is already managed by another live portfolio. Use its saved portfolio.')
                router.live.preflight(max(.000001, cash_value(run)))
                run['live_wallet'] = router.live.wallet
                if run.get('wallet_cash_observed') is None:
                    run['wallet_cash_observed'] = router.live.cash
                self.store.save(run)
                router.live.armed = True
                self.store.log('User enabled live routing for portfolio ' + run['id'] + '. Start copying to run the strategy.', run_id=run_id)
            elif action == 'reconcile_order':
                if not run.get('active_order') or not router.live.client:
                    raise ValueError('Connect the portfolio wallet and select an unresolved order first.')
                order = router.live.client.get_order(order_id=str(body.get('exchange_order_id','')))
                saved = self.store.rows('SELECT body FROM execution_orders WHERE id=?', (run['active_order'],))
                intent = json.loads(saved[0]['body'])['intent']
                if (str(order.asset_id) != intent['token'] or order.side != intent['side'] or
                    str(order.maker_address).lower() != str(router.live.wallet).lower() or
                    order.created_at.timestamp() < float(run['execution_plan']['created_at']) - 1):
                    raise ValueError('The supplied exchange order does not match the pending account, token, side and time.')
                result = dict(state='submitted', shares=0., notional=0., price=intent['limit_price'],
                    exchange_order_id=order.id, response=dict(trade_ids=list(order.associate_trades)))
                is_limit = bool(intent.get('execution_policy'))
                router._put(run, run['active_order'], 'limit_open' if is_limit else 'submitted', dict(intent=intent, result=result))
                if is_limit:
                    run['active_order'] = None
                    self.store.save(run)
            elif action == 'screen':
                self.scanner.start(run['case'])
            elif action == 'stop_screen':
                progress = self.store.get('screen_progress', {})
                if progress.get('case_id') == run['case']['case_id']:
                    self.scanner.stop()
            elif action == 'refresh':
                pass
            else:
                raise ValueError('Unknown action.')
        self.wake.set()
        return dict(run_id=run['id'])

    @staticmethod
    def snapshot_ready(run, snapshot, at):
        earliest = run['next_reset'] or (run['created_at'] // DAY * DAY)
        if run.get('pending_selection_reset'):
            earliest = run.get('last_screen') or (run['created_at'] // DAY * DAY)
        boundary = snapshot.get('as_of', 0)
        return (snapshot.get('complete', False) and snapshot.get('case_id') == run['case']['case_id']
                and earliest <= boundary <= at // DAY * DAY
                and at < boundary + run['case']['reset_days'] * DAY)

    def quotes(self, tokens, at):
        from engine import quotes
        return quotes(self, tokens, at)

    def poll(self):
        from engine import poll
        runs = [json.loads(row['body']) for row in self.store.rows('SELECT body FROM runs')]
        watch, managed = {}, set()
        at = int(time.time())
        for run in runs:
            for wallet, a in run['accounts'].items():
                watch[wallet] = dict(wallet=wallet, name=a['name'], role='selected account')
                managed.update(t for t,p in a['positions'].items() if not p.get('settled'))
            snapshot = self.snapshot_for(run)
            due = run.get('pending_selection_reset') or not run['next_reset'] or at >= run['next_reset']
            if run['status'] in ('running','waiting_for_screen') and due and self.snapshot_ready(run,snapshot,at):
                for a in snapshot['selected']:
                    watch[a['wallet']] = dict(wallet=a['wallet'],name=a['name'],role='selected account')
        self.feed.set_wallets(list(watch.values()) or self.probes)
        self.feed.set_managed_tokens(managed)
        for run in runs:
            if not run['accounts'] and run['status'] not in ('running','waiting_for_screen'):
                continue
            try:
                poll(self, run['id'], manage_feed=False)
            except Exception as exc:
                with self.store.lock:
                    current = self.store.run(run['id'])
                    message = str(exc)
                    if current.get('issue') != message:
                        self.store.log('Execution held: ' + message, 'error', run_id=current['id'])
                    current['issue'] = message
                    self.store.save(current)

    def loop(self):
        while not self.stop.is_set():
            try:
                self.poll()
            except Exception as exc:
                self.store.log('Portfolio monitor: ' + str(exc), 'error')
            self.wake.wait(5)
            self.wake.clear()

    def export(self, kind, run_id=None):
        run = self.store.run(run_id)
        if not run:
            raise ValueError('Unknown saved portfolio.')
        if kind == 'fills':
            rows = self.store.rows('SELECT * FROM fills WHERE run=? ORDER BY id', (run['id'],))
        elif kind == 'nav':
            rows = self.store.rows('SELECT ts,nav,cash FROM points WHERE run=? ORDER BY ts', (run['id'],))
        elif kind == 'accounts':
            rows = []
            for r in self.store.rows('SELECT ts,body FROM selections WHERE run=? ORDER BY ts,wallet', (run['id'],)):
                a = json.loads(r['body'])
                rows.append(dict(selected_at_utc=utc(r['ts']), wallet=a['wallet'], name=a['name'], weight=a['weight'],
                    raw_sharpe=a['raw_sharpe'], effective_sharpe=a['effective_sharpe'],
                    volatility=a['sigma'], history_observations=a['historical_observations']))
        else:
            raise ValueError('Unknown export.')
        return csv_text(rows)


class Handler(http.server.BaseHTTPRequestHandler):
    app: Application

    def log_message(self, *args):
        pass

    def send(self, value, status=200, content_type='application/json; charset=utf-8'):
        try:
            return self._send(value, status, content_type)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            # Closing/reloading an app window may cancel its in-flight read.
            return

    def _send(self, value, status=200, content_type='application/json; charset=utf-8'):
        payload = json.dumps(value, allow_nan=False).encode() if content_type.startswith('application/json') else value
        if isinstance(payload, str):
            payload = payload.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(payload)

    def allowed_host(self):
        return self.headers.get('Host') in (f'127.0.0.1:{self.app.port}', f'localhost:{self.app.port}')

    def do_GET(self):
        if not self.allowed_host():
            return self.send({'error': 'Local host required.'}, 403)
        path, _, query = self.path.partition('?')
        params = urllib.parse.parse_qs(query)
        try:
            if path == '/api/state':
                return self.send(self.app.state(params.get('run', [None])[0]))
            if path == '/api/cases':
                return self.send(list(self.app.archive.cases.values()))
            if path == '/api/replay':
                return self.send(self.app.archive.replay(params.get('case', [DEFAULT_CASE])[0]))
            if path == '/api/account':
                wallet = params.get('wallet', [''])[0]
                if len(wallet) != 42 or not wallet.startswith('0x') or any(c not in '0123456789abcdef' for c in wallet[2:]):
                    raise ValueError('Invalid wallet.')
                points = self.app.store.rows('SELECT ts,nav,pnl FROM account_points WHERE run=? AND wallet=? ORDER BY ts',
                                            (self.app.store.run(params.get('run',[None])[0])['id'], wallet))
                file = HISTORY / 'account_backtests' / 'data' / 'lifetimes' / (wallet + '.js')
                source = None
                if file.exists():
                    source = json.loads(file.read_text(encoding='utf-8').split('(', 1)[1].rsplit(')', 1)[0])
                return self.send(dict(wallet=wallet, points=points, historical=source))
            if path == '/api/screen-issues':
                progress = self.app.store.get('screen_progress', {})
                run = self.app.store.run(params.get('run',[None])[0])
                if not run or progress.get('case_id') != run['case']['case_id']:
                    return self.send([])
                import sqlite3
                with sqlite3.connect(self.app.scanner.path, factory=Database) as db:
                    rows = [json.loads(r[0]) for r in db.execute("SELECT body FROM accounts WHERE at=? AND status='data_pending' LIMIT 100", (progress.get('as_of', 0),))]
                return self.send(rows)
            if path.startswith('/api/export/'):
                return self.send(self.app.export(path.rsplit('/', 1)[-1], params.get('run',[None])[0]), content_type='text/csv; charset=utf-8')
            files = {'/': ('index.html', 'text/html'), '/app.js': ('app.js', 'text/javascript'), '/style.css': ('style.css', 'text/css')}
            if path not in files:
                return self.send({'error': 'Not found.'}, 404)
            name, mime = files[path]
            return self.send((HERE / name).read_bytes(), content_type=mime + '; charset=utf-8')
        except (ValueError, KeyError) as exc:
            self.send({'error': str(exc)}, 400)
        except Exception as exc:
            self.app.store.log('UI read: ' + str(exc), 'error')
            self.send({'error': str(exc)}, 500)

    def do_POST(self):
        origin = self.headers.get('Origin')
        if (not self.allowed_host() or self.headers.get('X-Paper-Token') != self.app.csrf or
            origin not in (None, f'http://127.0.0.1:{self.app.port}', f'http://localhost:{self.app.port}')):
            return self.send({'error': 'Local app session required.'}, 403)
        try:
            length = int(self.headers.get('Content-Length', 0))
            if length > 16384:
                raise ValueError('Request too large.')
            body = json.loads(self.rfile.read(length) or b'{}')
            if self.path != '/api/action':
                return self.send({'error': 'Not found.'}, 404)
            result = self.app.command(body['action'], body)
            self.send(dict(ok=True, **(result or {})))
        except (ValueError, KeyError) as exc:
            self.send({'error': str(exc)}, 400)
        except Exception as exc:
            self.send({'error': str(exc)}, 500)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8790)
    parser.add_argument('--open', action='store_true')
    parser.add_argument('--screen', action='store_true')
    parser.add_argument('--resume', action='store_true', help='Resume the existing sandbox portfolio')
    args = parser.parse_args()
    # Own the port before starting any account monitors or execution workers.
    # A second launcher must never run a second engine against the same ledger.
    server = http.server.ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    app = Application()
    app.port = args.port
    Handler.app = app
    if (args.screen or args.resume) and app.store.run().get('mode', 'sandbox') == 'sandbox':
        app.command('start', {})
    if args.open:
        webbrowser.open(f'http://127.0.0.1:{args.port}')
    print(f'Macrobook: http://127.0.0.1:{args.port} (live routing disabled until user connects and enables it)', flush=True)
    try:
        server.serve_forever()
    finally:
        app.stop.set()
        for router in app.routers.values():
            router.halt.set()
            router.live.disconnect()
        app.feed.close()
        app.market.close()
        app.scanner.cancel.set()
        server.server_close()


if __name__ == '__main__':
    main()
