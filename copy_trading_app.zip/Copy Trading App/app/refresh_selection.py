"""Refresh today's public-data selection without starting any execution engine."""
import json
import time
from core import Store
from screening import Catalog, Scanner

if __name__ == '__main__':
    store = Store()
    scanner = Scanner(store, Catalog())
    scanner.start(store.run()['case'], resume=False)
    while scanner.thread.is_alive():
        scanner.thread.join(30)
        print(json.dumps(store.get('screen_progress', {})), flush=True)
    if not store.get('screen_progress', {}).get('complete'):
        raise SystemExit('Selection incomplete; completed discovery and account pages are saved.')
