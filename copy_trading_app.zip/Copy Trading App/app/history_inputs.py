"""Reuse the finished research inputs; append only observations not yet archived."""
import json
import sqlite3
import zlib

from core import HISTORY, Database, stamp


def read_database(path):
    return sqlite3.connect('file:' + path.as_posix() + '?mode=ro', uri=True, factory=Database)


def trade_activity(row, name):
    w, ts, token, side, tx, condition, size, price, cash, title, outcome, oi = row
    return dict(proxy_wallet=w, timestamp=ts, token_id=token, side=side,
        transaction_hash=tx, condition_id=condition, size=size, price=price,
        usdc_size=cash, title=title, outcome=outcome, outcome_index=oi, type='TRADE', name=name)


class ArchiveInputs:
    def __init__(self, catalog):
        definition = json.loads((HISTORY / 'strategy_results.json').read_text(encoding='utf-8'))
        self.end = stamp(definition['simulation_end_exclusive'])
        old = json.loads((HISTORY / 'macro_markets_for_returns.json').read_text(encoding='utf-8'))
        self.conditions = {m['conditionId'] for m in old}
        self.additional_old = []
        for condition, m in catalog.markets.items():
            if condition in self.conditions:
                continue
            created = m.get('createdAt')
            if not created or stamp(created) < self.end:
                self.additional_old.append(condition)

    def activity(self, wallet):
        with read_database(HISTORY / 'complete_candidate_histories.sqlite') as db:
            row = db.execute('SELECT end,body FROM histories WHERE wallet=?', (wallet,)).fetchone()
        if not row:
            return None
        end, blob = row
        source = json.loads(zlib.decompress(blob))
        name = source.get('name') or wallet
        trades, actions = source['rows'], source['actions']
        # These are the finalized inputs used by the preserved backtest.
        with read_database(HISTORY / 'candidate_inputs.sqlite') as db:
            row = db.execute('SELECT body FROM candidates WHERE wallet=?', (wallet,)).fetchone()
        if row:
            trades = json.loads(zlib.decompress(row[0]))['rows']
            with read_database(HISTORY / 'account_economics.sqlite') as db:
                row = db.execute('SELECT body FROM accounts WHERE wallet=?', (wallet,)).fetchone()
            if row:
                economics = json.loads(zlib.decompress(row[0]))
                actions = economics['actions']
                name = economics.get('name') or name
        return dict(through=min(end, self.end), rows=[trade_activity(r, name) for r in trades] + actions)
