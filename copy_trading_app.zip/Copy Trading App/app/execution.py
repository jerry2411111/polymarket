"""One order planner; sandbox and authenticated exchange execution adapters.

The agent never connects credentials or submits real orders. A user must connect
an existing account, explicitly arm live mode, and start a separately funded run.
"""
from __future__ import annotations

import copy
import decimal
import hashlib
import json
import math
import sys
import threading
import time
import uuid

from core import HERE, DAY, account_nav, cash_value, nav

sys.path.insert(0, str(HERE / 'vendor'))


def rounded_shares(qty):
    return float(decimal.Decimal(str(max(0, qty))).quantize(decimal.Decimal('.01'), rounding=decimal.ROUND_DOWN))


def targets_for_book(capital, positions, quotes):
    valued = [(p, float(p['current_size']) * quotes[p['token_id']]['price']) for p in positions]
    total = math.fsum(v for _, v in valued)
    return {p['token_id']: capital * value / total / quotes[p['token_id']]['price']
            for p, value in valued if total > 0 and value > 0 and not p.get('redeemable')
            and not quotes[p['token_id']].get('settled')}


def make_plan(run, sources, quotes, selected=None, as_of=None):
    """Capital transfers change attribution, never aggregate cash or NAV."""
    reset = selected is not None
    before = nav(run)
    metrics = {r['wallet']: r for r in selected} if reset else {
        w: a['metric'] for w, a in run['accounts'].items() if not a.get('exiting')}
    previous_plan = run.get('execution_plan', {})
    desired, attempts = {}, {}
    for wallet in set(run['accounts']) | set(metrics):
        metric = metrics.get(wallet)
        existing = wallet in run['accounts']
        if wallet not in run['accounts']:
            previous = run.setdefault('retired_accounts', {}).pop(wallet, {})
            run['accounts'][wallet] = dict(name=metric['name'], cash=0., positions={}, pnl=previous.get('pnl', 0.))
        a = run['accounts'][wallet]
        old_target = previous_plan.get('targets', {}).get(wallet)
        if (not reset and old_target and
                (not metric or a.get('source_key') == sources[wallet]['inventory_key'])):
            # Another account's activity must not rebalance this unchanged book
            # or relabel its outstanding orders as a new source transaction.
            desired[wallet] = old_target
            attempts.update({k: v for k, v in previous_plan.get('attempts', {}).items()
                             if k.startswith(wallet + ':')})
            continue
        previous_source = a.get('source_inventory', {})
        previous_observed = a.get('source_observed_at')
        if reset:
            capital = before * metric['weight'] if metric else 0.
            transfer = capital - account_nav(a)
            a['cash'] += transfer
            run['cash'] -= transfer
            a['period_capital'] = capital
        else:
            capital = account_nav(a)
        a['exiting'] = metric is None
        if metric:
            a.update(name=metric['name'], weight=metric['weight'], metric=metric)
            a['source_key'] = sources[wallet]['inventory_key']
            positions = sources[wallet]['positions']
            a['source_inventory'] = {p['token_id']: dict(p) for p in positions}
            a['source_observed_at'] = sources[wallet].get('checked_at', time.time())
        else:
            a['weight'] = 0.
            positions = []
        decision_id = uuid.uuid4().hex
        desired[wallet] = dict(shares=targets_for_book(capital, positions, quotes),
            metadata={p['token_id']: p for p in positions}, source_key=a.get('source_key'),
            source_change_id=decision_id,
            reason=('Account removed: flatten' if not metric else 'Account allocation reset')
                   if reset else 'Observed source position change')
        target = desired[wallet]
        kind = ('removed' if not metric else 'reset' if existing else 'initial') if reset else 'source_change'
        source_changes = []
        if kind == 'source_change':
            current_source = a['source_inventory']
            for token in sorted(set(previous_source) | set(current_source)):
                old, new = previous_source.get(token, {}), current_source.get(token, {})
                delta = float(new.get('current_size', 0)) - float(old.get('current_size', 0))
                if abs(delta) > 1e-8:
                    meta = new or old
                    source_changes.append(dict(token=token, title=meta.get('title', ''),
                        outcome=meta.get('outcome', ''), delta_shares=delta))
        adjustments = []
        for token in sorted(set(a['positions']) | set(target['shares'])):
            held = a['positions'].get(token, {})
            delta = target['shares'].get(token, 0) - held.get('shares', 0)
            if rounded_shares(abs(delta)) > 0:
                meta = target['metadata'].get(token, held)
                adjustments.append(dict(token=token, side='BUY' if delta > 0 else 'SELL',
                    shares=rounded_shares(abs(delta)), title=meta.get('title', ''), outcome=meta.get('outcome', '')))
        run.setdefault('_copy_decisions', []).append(dict(id=decision_id, wallet=wallet,
            name=a['name'], ts=time.time(), kind=kind, reason=target['reason'],
            observed_at=a.get('source_observed_at') if metric else None,
            previous_observed_at=previous_observed, source_changes=source_changes,
            adjustments=adjustments, target_shares=target['shares'], source_events=[]))
    if not math.isclose(nav(run), before, rel_tol=1e-10, abs_tol=1e-7):
        raise ValueError('Allocation transfer changed aggregate portfolio NAV.')
    run['execution_plan'] = dict(id=uuid.uuid4().hex, created_at=time.time(), targets=desired, attempts=attempts)
    if reset:
        run.pop('pending_selection_reset', None)
        run['last_screen'] = as_of
        run['next_reset'] = as_of + run['case']['reset_days'] * DAY
        run['status'] = 'running'
    return run


def remove_selected_account(run, wallet):
    """Persist a wallet exclusion and request reallocation among remaining accounts."""
    account = run['accounts'].get(wallet)
    if not account:
        raise ValueError('This account is not in the current portfolio.')
    if account.get('exiting'):
        return
    before = nav(run)
    run.setdefault('excluded_wallets', {})[wallet] = dict(name=account['name'], excluded_at=time.time())
    run['selection_revision'] = run.get('selection_revision', 0) + 1
    run['pending_selection_reset'] = True
    account.update(exiting=True, weight=0.)
    decision_id = uuid.uuid4().hex
    reason = 'User excluded account; close holdings and reallocate among remaining selected accounts'
    run['execution_plan']['targets'][wallet] = dict(shares={}, metadata=dict(account['positions']),
        source_key=account.get('source_key'), source_change_id=decision_id, reason=reason, price_rules={})
    run.setdefault('_copy_decisions', []).append(dict(id=decision_id, wallet=wallet,
        name=account['name'], ts=time.time(), kind='removed', reason=reason,
        adjustments=[dict(token=t, side='SELL', shares=p['shares'], title=p['title'], outcome=p['outcome'])
                     for t,p in account['positions'].items()], target_shares={}, source_events=[], source_changes=[]))
    if not math.isclose(nav(run), before, abs_tol=1e-7):
        raise ValueError('Removing a selected account changed portfolio NAV.')


class SandboxBroker:
    mode = 'sandbox'

    def submit(self, intent, book):
        raise ValueError('Sandbox fills must use the persistent midpoint router so cash and holdings are saved atomically.')


class LiveBroker:
    mode = 'live'

    def __init__(self):
        self.client = None
        self.armed = False
        self.connected_at = None
        self.cash = None
        self.wallet = None
        self.error = None
        self.expected_cash = None
        self.lock = threading.RLock()

    def connect(self, private_key, wallet, credentials=None):
        from polymarket import SecureClient, ApiKeyCreds
        if not wallet or len(wallet) != 42 or not wallet.startswith('0x') or any(c not in '0123456789abcdefABCDEF' for c in wallet[2:]):
            raise ValueError('Enter the existing funded Polymarket wallet address.')
        class ExistingWalletClient(SecureClient):
            def _deploy_default_deposit_wallet(self):
                raise ValueError('Initialize this wallet through Polymarket first; the app will not deploy it.')
        try:
            supplied = ApiKeyCreds(**credentials) if credentials else None
            client = ExistingWalletClient.create(private_key=private_key, wallet=wallet, credentials=supplied)
            balance = client.get_balance_allowance(asset_type='COLLATERAL')
        except Exception as exc:
            if 'client' in locals():
                client.close()
            # SDK validation messages can contain supplied field values. Never
            # echo key material to the UI, journal, exception log or database.
            self.error = 'Authentication failed (' + type(exc).__name__ + '). Check the signing key, wallet and API credentials.'
            raise ValueError(self.error) from None
        with self.lock:
            if self.client:
                self.client.close()
            self.client = client
            self.wallet = str(client.wallet)
            self.cash = balance.balance / 1_000_000
            self.armed = False
            self.connected_at = int(time.time())
            self.error = None
        return self.status()

    def status(self):
        return dict(connected=self.client is not None, armed=self.armed, wallet=self.wallet,
                    available_collateral=self.cash, connected_at=self.connected_at, error=self.error,
                    credentials_persisted=False, sdk='polymarket-client 0.11.0')

    def preflight(self, budget):
        if not self.client:
            raise ValueError('Connect a trading account in Execution settings first.')
        balance = self.client.get_balance_allowance(asset_type='COLLATERAL')
        self.cash = balance.balance / 1_000_000
        if budget <= 0 or budget > self.cash:
            raise ValueError('The requested live budget exceeds available collateral.')
        if not any(amount > 0 for amount in balance.allowances.values()):
            raise ValueError('Collateral approval is missing. Set trading approvals through Polymarket first.')
        if self.client.get_closed_only_mode():
            raise ValueError('This account is in exchange closed-only mode.')
        if any(True for _ in self.client.list_open_orders()):
            raise ValueError('This wallet has open exchange orders. Resolve them before enabling a separate automated run.')
        self.expected_cash = self.cash

    def prepare(self, intent):
        if not self.client or not self.armed:
            raise ValueError('Real-money routing is not enabled.')
        cash = self.client.get_balance_allowance(asset_type='COLLATERAL').balance / 1_000_000
        shares = self.token_balance(intent['token'])
        if self.expected_cash is not None and abs(cash - self.expected_cash) > .00001:
            raise ValueError('Wallet collateral changed outside the app. Pause and reconcile the wallet before resuming.')
        intent['before_balances'] = dict(cash=cash, shares=shares)
        if intent['side'] == 'BUY' and intent['cash_limit'] > cash + .00001:
            raise ValueError('App cash exceeds available wallet collateral.')
        if intent['side'] == 'SELL' and intent['shares'] > shares + .00001:
            raise ValueError('App sale exceeds available wallet token balance.')

    def token_balance(self, token):
        from polymarket._internal.protocol import is_v2_position_id
        asset_type = 'CONDITIONAL-V2' if is_v2_position_id(str(token)) else 'CONDITIONAL'
        return self.client.get_balance_allowance(asset_type=asset_type, token_id=token).balance / 1_000_000

    def submit(self, intent, book):
        if not self.client or not self.armed:
            raise ValueError('Real-money routing is not enabled.')
        from limit_orders import POLICY
        if (intent.get('execution_policy') != POLICY or intent.get('order_type') != 'GTC'
                or intent.get('post_only') is not True or intent.get('quote_method') != 'midpoint'):
            raise ValueError('Only post-only GTC midpoint limits are allowed. Market orders are disabled.')
        # Signing is separate from submission. Calling post_order directly
        # deliberately avoids the SDK's automatic on-chain allowance recovery.
        try:
            signed = self.client.create_limit_order(token_id=intent['token'], side=intent['side'],
                price=str(intent['limit_price']), size=str(intent['shares']), post_only=True)
        except Exception as exc:
            return dict(state='rejected', shares=0., notional=0., price=intent['limit_price'], fee=0.,
                        reason='Order not submitted: signing/preparation failed (' + type(exc).__name__ + ').', exchange_order_id=None)
        response = self.client.post_order(signed)
        if not response.ok:
            return dict(state='rejected', shares=0., notional=0., price=intent['limit_price'],
                        fee=0., reason=response.message, exchange_order_id=None)
        return dict(state='submitted', shares=0., notional=0., price=intent['limit_price'], fee=0.,
                    exchange_order_id=str(response.order_id), response=response.model_dump(mode='json'),
                    reason='GTC midpoint limit accepted; waiting for confirmed fills.')

    def reconcile(self, intent, result):
        if not self.client:
            return result
        order_id = result.get('exchange_order_id')
        if not order_id:
            return result
        response = result.get('response', {})
        ids = set(response.get('trade_ids', []))
        if not ids:
            order = self.client.get_order(order_id=order_id)
            body = order.model_dump(mode='json')
            ids.update(body.get('associate_trades', []))
            if not ids and str(body.get('status', '')).upper() in ('CANCELED', 'CANCELLED', 'UNMATCHED'):
                return dict(result, state='unfilled', reason='Exchange closed the order without a fill.')
        if not ids:
            return result
        trades = {}
        for trade_id in ids:
            for t in self.client.list_account_trades(id=trade_id):
                if str(t.taker_order_id) == order_id:
                    trades[t.id] = t
        if len(trades) < len(ids):
            return result
        if any(str(t.status).upper() not in ('CONFIRMED', 'FAILED') for t in trades.values()):
            return result
        confirmed = [t for t in trades.values() if str(t.status).upper() == 'CONFIRMED']
        size = sum(float(t.size) for t in confirmed)
        notional = sum(float(t.size * t.price) for t in confirmed)
        if not size:
            return dict(result, state='unfilled', shares=0., notional=0., reason='No confirmed fills.')
        after_cash = self.client.get_balance_allowance(asset_type='COLLATERAL').balance / 1_000_000
        after_shares = self.token_balance(intent['token'])
        before = intent.get('before_balances')
        if not before:
            raise ValueError('Missing pre-order balances; reconcile this order before continuing.')
        buying = intent['side'] == 'BUY'
        cash_delta = before['cash'] - after_cash if buying else after_cash - before['cash']
        share_delta = after_shares - before['shares'] if buying else before['shares'] - after_shares
        if cash_delta < 0:
            raise ValueError('Wallet cash moved in the opposite direction to the confirmed trade. Reconcile external activity.')
        if abs(share_delta-size) > .00002 or cash_delta == 0:
            return dict(result, reason='Confirmed trades observed; waiting for matching wallet balances.')
        fee = cash_delta-notional if buying else notional-cash_delta
        # Fees are observed collateral differences, never an invented cost model.
        # Match those differences to the rate reported on the confirmed trades;
        # external deposits/withdrawals must not be booked as trading P&L.
        reported_fee = sum(round(float(t.size*t.price*(1-t.price)*t.fee_rate_bps/10000), 5) for t in confirmed)
        if abs(fee-reported_fee) > .00005 * max(1, len(confirmed)):
            raise ValueError('Wallet cash movement does not match confirmed trades and reported fees. Reconciliation required.')
        self.cash = after_cash
        self.expected_cash = after_cash
        return dict(result, state='filled' if size else 'unfilled', shares=size, notional=notional,
                    price=notional / size if size else intent['limit_price'],
                    fee=max(0., fee), cash_amount=cash_delta, after_balances=dict(cash=after_cash, shares=after_shares),
                    confirmed_trade_ids=[t.id for t in confirmed],
                    reason='Confirmed exchange trades; wallet collateral independently refreshed.')

    def disconnect(self):
        with self.lock:
            self.armed = False
            if self.client:
                self.client.close()
            self.client = None
            self.cash = None


class ExecutionRouter:
    def __init__(self, store, market):
        self.store, self.market = store, market
        self.sandbox, self.live = SandboxBroker(), LiveBroker()
        self.halt = threading.Event()
        with store.connect() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS execution_orders(
                id TEXT PRIMARY KEY,run TEXT,mode TEXT,state TEXT,created REAL,updated REAL,body TEXT);
                CREATE INDEX IF NOT EXISTS execution_orders_run ON execution_orders(run,created);''')

    def orders(self, run_id):
        return [dict(json.loads(r['body']), id=r['id'], state=r['state'], mode=r['mode'], created=r['created'])
                for r in self.store.rows('''SELECT * FROM execution_orders WHERE run=? AND
                    (state IN ('limit_open','limit_partial','limit_cancel_requested','posting','unknown') OR
                     id IN (SELECT id FROM execution_orders WHERE run=? ORDER BY created DESC LIMIT 300))
                    ORDER BY created DESC''', (run_id,run_id))]

    def _put(self, run, order_id, state, body, create=False):
        with self.store.connect() as db:
            if create:
                db.execute('INSERT INTO execution_orders VALUES(?,?,?,?,?,?,?)',
                    (order_id, run['id'], run.get('mode', 'sandbox'), state, time.time(), time.time(), json.dumps(body)))
            else:
                db.execute('UPDATE execution_orders SET state=?,updated=?,body=? WHERE id=?',
                           (state, time.time(), json.dumps(body), order_id))

    def apply(self, run, order_id, intent, result, journal_state='applied', journal_result=None):
        a = run['accounts'][intent['wallet']]
        qty, dollars = float(result['shares']), float(result['notional'])
        cash_amount = float(result.get('cash_amount', dollars))
        fills = []
        if qty > 1e-9:
            token = intent['token']
            old = a['positions'].get(token, {})
            before = old.get('shares', 0.)
            if intent['side'] == 'BUY':
                if cash_amount > cash_value(run) + 1e-5:
                    raise ValueError('Confirmed fill exceeds available portfolio cash; reconciliation required.')
                if intent.get('execution_policy') and cash_amount > a['cash'] + 1e-5:
                    raise ValueError('Confirmed limit fill exceeds this account allocation cash; reconciliation required.')
                after = before + qty
                cost = old.get('cost', 0.) + cash_amount
                a['cash'] -= cash_amount
            else:
                if qty > before + 1e-5:
                    raise ValueError('Confirmed sale exceeds app-owned shares; reconciliation required.')
                after = max(0, before - qty)
                cost = old.get('cost', 0.) * after / before if before else 0.
                a['cash'] += cash_amount
            mark = result.get('mark', old.get('price', intent['mark']))
            # Resting orders may fill long after posting. Value both the old
            # holding and the new fill at the current quote, not the posting mark.
            a['pnl'] = a.get('pnl', 0.) + before * (mark - old.get('price', mark))
            a['pnl'] = a.get('pnl', 0.) + (qty * mark - cash_amount if intent['side'] == 'BUY' else cash_amount - qty * mark)
            if after > 1e-8:
                a['positions'][token] = dict(shares=after, cost=cost, price=mark, quote_ts=result.get('quote_ts',intent['quote_ts']),
                    title=intent['title'], outcome=intent['outcome'], condition_id=intent['condition_id'])
            else:
                a['positions'].pop(token, None)
            fills.append(dict(intent, order_id=order_id, shares=qty, price=result['price'], notional=dollars,
                mark=mark,quote_ts=result.get('quote_ts',intent['quote_ts'])))
        run['active_order'] = None
        if result.get('after_balances'):
            run['wallet_cash_observed'] = result['after_balances']['cash']
        self.store.save(run, fills=fills, point=True,
            order_update=(order_id, journal_state, dict(intent=intent, result=journal_result if journal_result is not None else result)))

    def limit_orders(self, run):
        from limit_orders import rows
        return rows(self, run)

    def cancel_pending(self, run, reason='Copying paused'):
        from limit_orders import cancel, live_matches
        cancel(self, run, reason, all_orders=True)
        if run.get('mode') == 'live':
            live_matches(self, run)
        return not self.limit_orders(run)

    def reconcile_active(self, run):
        order_id = run.get('active_order')
        if not order_id:
            return True
        rows = self.store.rows('SELECT state,body FROM execution_orders WHERE id=?', (order_id,))
        if not rows:
            raise ValueError('Order journal is incomplete; execution is paused.')
        body = json.loads(rows[0]['body'])
        intent, result = body['intent'], body.get('result', {})
        if rows[0]['state'] in ('posting', 'unknown'):
            if run.get('mode', 'sandbox') == 'sandbox':
                # There is no external exchange side effect in sandbox mode.
                self.apply(run, order_id, intent, dict(state='unfilled', shares=0., notional=0., price=intent['limit_price'], reason='Interrupted local simulation; no committed fill.'))
                return True
            raise ValueError('An order outcome is unknown. Reconcile its exchange order ID before sending another order.')
        if result.get('state') == 'submitted':
            result = self.live.reconcile(intent, result)
            self._put(run, order_id, result['state'], dict(intent=intent, result=result))
        if result.get('state') in ('filled', 'unfilled', 'rejected'):
            self.apply(run, order_id, intent, result)
            return True
        return False

    def reconcile_redemptions(self, run):
        """Credit claims only after the user has actually redeemed them on-chain.

        The app does not convert a winning token into spendable real cash on
        resolution alone. Wallet balance observations must match the payout.
        """
        if run.get('mode') != 'live' or not self.live.client or run.get('active_order'):
            return
        claims = [(w,t,p) for w,a in run['accounts'].items() for t,p in a['positions'].items() if p.get('settled')]
        if not claims or time.time()-run.get('last_redemption_check',0) < 30:
            return
        run['last_redemption_check'] = time.time()
        balances = {t:self.live.token_balance(t)
                    for t in {t for _,t,_ in claims}}
        redeemed = [(w,t,p) for w,t,p in claims if balances[t] <= .000001]
        if not redeemed:
            return
        expected = run.get('wallet_cash_observed')
        actual = self.live.client.get_balance_allowance(asset_type='COLLATERAL').balance / 1_000_000
        payout = sum(p['shares']*p['price'] for _,_,p in redeemed)
        if expected is None or abs(actual-expected-payout) > .00005 * max(1,len(redeemed)):
            raise ValueError('Redeemed claim does not match the wallet cash change. Reconcile external wallet activity first.')
        fills = []
        for wallet, token, p in redeemed:
            a = run['accounts'][wallet]
            dollars = p['shares']*p['price']
            a['cash'] += dollars
            a['positions'].pop(token)
            fills.append(dict(wallet=wallet,name=a['name'],token=token,title=p['title'],outcome=p['outcome'],
                side='REDEMPTION',shares=p['shares'],price=p['price'],notional=dollars,quote_ts=p['quote_ts'],
                reason='Observed extinguished tokens and matching real wallet payout'))
        run['wallet_cash_observed'] = actual
        self.live.cash = self.live.expected_cash = actual
        self.store.save(run,fills=fills,point=True)

    def execute(self, run):
        from limit_orders import execute
        return execute(self, run)

