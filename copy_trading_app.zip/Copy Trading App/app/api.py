"""Read-only public Polymarket data. No trading API or credentials."""
from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request


class PublicAPI:
    def __init__(self, cancel=None, requests_per_second=10):
        self.cancel = cancel or threading.Event()
        self.calls = 0
        self.last_ok = None
        self.last_error = None
        self.gate = threading.Lock()
        self.last_call = 0.
        self.request_spacing = 1 / requests_per_second
        self.settled = {}

    def get(self, route, params=None, gamma=False):
        host = 'https://gamma-api.polymarket.com' if gamma else 'https://data-api.polymarket.com'
        url = host + route + '?' + urllib.parse.urlencode(params or {}, doseq=True)
        for attempt in range(4):
            if self.cancel.is_set():
                raise InterruptedError('Screening paused; completed pages are saved.')
            with self.gate:
                delay = self.request_spacing - (time.monotonic() - self.last_call)
                if delay > 0:
                    self.cancel.wait(delay)
                self.last_call = time.monotonic()
            try:
                req = urllib.request.Request(url, headers={'User-Agent': 'MacroBook-Paper/1.0', 'Accept': 'application/json'})
                with urllib.request.urlopen(req, timeout=25) as response:
                    value = json.load(response)
                self.calls += 1
                self.last_ok = int(time.time())
                self.last_error = None
                return value
            except (OSError, ValueError) as exc:
                self.last_error = str(exc)
                if isinstance(exc, urllib.error.HTTPError) and exc.code not in (429, 500, 502, 503, 504):
                    raise
                if attempt == 3:
                    raise
                self.cancel.wait(min(2 ** attempt, 8))

    def pages(self, route, params):
        params = dict(params)
        cursors = set()
        while True:
            payload = self.get(route, params)
            rows = payload.get('data')
            if not isinstance(rows, list):
                raise ValueError('Invalid Polymarket page for ' + route)
            yield rows
            cursor = payload.get('pagination', {}).get('next_cursor')
            if not cursor:
                if payload.get('pagination', {}).get('has_more'):
                    raise ValueError('Incomplete API page without a continuation cursor.')
                break
            if cursor in cursors:
                raise ValueError('API repeated a cursor; incomplete history retained as pending.')
            cursors.add(cursor)
            params['cursor'] = cursor

    def positions(self, wallet):
        return [r for page in self.pages('/v2/positions', dict(user=wallet, status='OPEN',
                include_archived='true', filter_amount=0, limit=1000)) for r in page]

    def quote(self, token, at):
        payload = self.get('/v2/prices-history', dict(token_id=token, as_of=at))
        usable = []
        for row in payload.get('data', []):
            # Aggregates are available only after their observation window closes.
            available = int(row['timestamp']) + int(row.get('resolution_seconds', 0))
            p = float(row['price'])
            if available <= at and 0 <= p <= 1:
                usable.append(dict(price=p, timestamp=available,
                                   observed_at=int(row['timestamp']), resolution_seconds=row.get('resolution_seconds', 0)))
        if not usable:
            raise ValueError('No actual price available at this time for token ' + str(token))
        return max(usable, key=lambda x: x['timestamp'])

    def settlements(self, conditions, at):
        from core import stamp
        pending = sorted(set(conditions) - set(self.settled))
        for i in range(0, len(pending), 20):
            payload = self.get('/v2/resolutions', {'condition': ','.join(pending[i:i + 20])})
            if not isinstance(payload.get('data'), list):
                raise ValueError('Invalid resolution response.')
            for r in payload['data']:
                condition = r.get('condition_id')
                when = r.get('resolved_at') or r.get('last_update_timestamp')
                if r.get('status') != 'resolved' or not condition or not when:
                    continue
                timestamp = int(when) if str(when).isdigit() else stamp(when)
                if r.get('payouts') is not None:
                    payouts = [float(x) / 1_000_000 for x in r['payouts']]
                elif r.get('price') is not None:
                    yes = float(r['price'])
                    if yes > 1:
                        yes /= 1e18
                    payouts = [yes, 1 - yes]
                else:
                    continue
                if payouts and all(0 <= p <= 1 for p in payouts):
                    self.settled[condition] = dict(timestamp=timestamp, payouts=payouts)
        return {c: self.settled[c] for c in conditions if c in self.settled and self.settled[c]['timestamp'] <= at}
