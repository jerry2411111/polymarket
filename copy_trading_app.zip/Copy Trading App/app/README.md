# Copy Trading App — Application

Use the [project-root setup and launcher](../README.md). Do not start `server.py`
directly from this source directory: `prepare_project.py` deploys it to
`data_storage/runtime/polymarket_mock_app`, beside its required research modules
and historical inputs. Imports, storage locations and the retained `launch.ps1`
then resolve in the same relative layout as the working implementation.

`server.py` serves the local UI and manages separate portfolio ledgers. `screening.py`
discovers and screens source accounts; `history_inputs.py` reuses completed
research history and appends newer public activity. `realtime.py` watches public
source inventories and quotes. `engine.py` marks portfolios and triggers target
updates. `execution.py` computes relative position targets and persists execution;
`limit_orders.py` uses immediate midpoint assumptions for sandbox and confirmed
midpoint limit fills for real trading. The model defaults and case selector come
from the prepared research definitions, not a hardcoded list of followed wallets.

## Main controls

- **Create portfolio / selector:** choose sandbox or real money at creation,
  configuration and budget; later switch which saved portfolio is displayed.
- **Start / Pause copying:** activate the current-date screen and forward copy
  process, or stop new adjustments while retaining positions. Pause cancels
  resting limits and reconciles orders already accepted by the exchange.
- **Followed accounts / Positions held / Transaction history:** inspect allocations,
  source IDs, current holdings, source decisions and our linked executions.
- **Discovery & screening:** progress, unresolved data and discovery pause/resume.
- **Execution:** credentials, explicit real-money enable, disable/pause, pending
  order states and unresolved submission reconciliation.
- **Historical replay:** prepared research results; not the current portfolio.

The current default is Effective Sharpe `(3,4]`, 75-day reselection, and inverse
volatility from up to 365 preceding days. Source activity refreshes on a roughly
five-second-after-completion schedule independently of that reset interval.
The main README documents the exact activity/style gates and allocation formula.

## Position and cash handling

All selected accounts receive their own slices. A changed source inventory
renormalizes relative macro-position targets only within that account's slice.
Purchases, partial sales and full market exits can therefore redistribute value
among its remaining positions. A completely empty macro book leaves the slice in
cash. Price changes alone do not replan an unchanged source book. Between resets,
account weights drift; a reset uses current total NAV and new inverse-volatility
weights. Continuing accounts retain existing holdings subject to target changes.

Sandbox assumes immediate fills at the exact two-sided midpoint, without waiting
for prints, depth, queue priority or minimum order size. Real BUYs/SELLs are
post-only GTC midpoint limits, rounded to valid ticks, checked every 60 seconds;
actual partial fills, cash/share checks and exchange minimums apply. No real
market-order route is enabled by this policy. Real execution can differ materially
from the historical zero-cost, daily book-return simulation.

Ledger changes and fill records commit atomically. Closing the browser leaves the
server running. Restart restores sandbox positions and copies net intervening
source changes at current prices; it never assumes backdated fills. Real mode
restarts paused with credentials cleared. Credentials are entered in the local UI
and remain only in process memory. The public-feed checker performs network
requests but no orders; the unit tests use synthetic fixtures.

The retained browser labels may use the original implementation's internal name.
The distributable project and root launcher are named **Copy Trading App**.
