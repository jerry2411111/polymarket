"""Live market books and publicly observable source-account activity."""
from __future__ import annotations

import concurrent.futures
import copy
import hashlib
import json
import math
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from core import DATA, HERE
from api import PublicAPI

sys.path.insert(0, str(HERE / 'vendor'))
import websocket

ACCOUNT_POLL_SECONDS = 5
MARKET_WS = 'wss://ws-subscriptions-clob.polymarket.com/ws/market'
CLOB = 'https://clob.polymarket.com'


def inventory_key(positions):
    rows = sorted((p['token_id'], str(float(p['current_size'])), bool(p.get('redeemable')))
                  for p in positions if float(p['current_size']) > 1e-8)
    return hashlib.sha256(json.dumps(rows, separators=(',', ':')).encode()).hexdigest()


def event_key(wallet, row):
    return hashlib.sha256(json.dumps([wallet] + [row.get(k) for k in
        ('id', 'timestamp', 'transaction_hash', 'token_id', 'type', 'side', 'size', 'price', 'usdc_size')], separators=(',', ':')).encode()).hexdigest()


class MarketFeed:
    def __init__(self):
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.tokens = set()
        self.books = {}
        self.ws = None
        self.status = dict(connected=False, messages=0, last_message=None, last_pong=None,
                           last_rest=None, reconnects=0, error=None, subscriptions=0)
        self.thread = threading.Thread(target=self._loop, name='market-stream', daemon=True)
        self.thread.start()
        threading.Thread(target=self._heartbeat, name='market-heartbeat', daemon=True).start()

    def subscribe(self, tokens):
        tokens = set(tokens)
        with self.lock:
            added, removed = tokens - self.tokens, self.tokens - tokens
            self.tokens = tokens
            self.status['subscriptions'] = len(tokens)
            ws = self.ws
            connected = self.status['connected']
        if connected and ws:
            try:
                if removed:
                    ws.send(json.dumps(dict(assets_ids=sorted(removed), operation='unsubscribe')))
                if added:
                    ws.send(json.dumps(dict(assets_ids=sorted(added), operation='subscribe', custom_feature_enabled=True)))
            except Exception:
                ws.close()

    def _open(self, ws):
        with self.lock:
            self.status.update(connected=True, error=None, last_pong=time.time())
            tokens = sorted(self.tokens)
        ws.send(json.dumps(dict(assets_ids=tokens, type='market', custom_feature_enabled=True)))

    def _message(self, ws, text):
        now = time.time()
        text = text.strip()
        with self.lock:
            self.status['last_message'] = now
            if text.upper() == 'PONG':
                self.status['last_pong'] = now
                return
            if text.upper() == 'PING':
                ws.send('PONG')
                return
        if not text:
            return
        try:
            payload = json.loads(text)
            for event in payload if isinstance(payload, list) else [payload]:
                self.ingest(event, now)
            with self.lock:
                self.status['error'] = None
        except (ValueError, TypeError, KeyError) as exc:
            with self.lock:
                self.status['error'] = 'Market message: ' + str(exc)

    def ingest(self, event, received=None):
        now = received or time.time()
        kind = event.get('event_type')
        timestamp = float(event.get('timestamp') or now * 1000) / 1000
        with self.lock:
            self.status['messages'] += 1
            if kind == 'book':
                token = event.get('asset_id')
                self._book(token, event, now, 'websocket')
            elif kind == 'price_change':
                for change in event.get('price_changes', []):
                    token = change['asset_id']
                    book = self.books.get(token)
                    if not book or timestamp < book.get('timestamp', 0):
                        continue  # Wait for a full snapshot on a new subscription.
                    side = 'bids' if change['side'] == 'BUY' else 'asks'
                    price, size = float(change['price']), float(change['size'])
                    if size > 0:
                        book[side][price] = size
                    else:
                        book[side].pop(price, None)
                    book.update(timestamp=timestamp, received_at=now, source='websocket')
            elif kind == 'tick_size_change' and event.get('asset_id') in self.books:
                self.books[event['asset_id']]['tick_size'] = float(event['new_tick_size'])
            elif kind == 'last_trade_price' and event.get('asset_id') in self.books:
                self.books[event['asset_id']]['last_trade_price'] = float(event['price'])

    def _book(self, token, raw, now, source):
        if not token:
            return
        old = self.books.get(token, {})
        timestamp = float(raw.get('timestamp') or now * 1000) / 1000
        if timestamp < old.get('timestamp', 0):
            # HTTP can verify an otherwise idle book even if the WS update won
            # a race; never replace a newer book with an older snapshot.
            if source == 'rest':
                old['verified_at'] = now
            return
        levels = lambda name: {float(p['price']): float(p['size']) for p in raw.get(name, [])
                               if 0 < float(p['price']) < 1 and float(p['size']) > 0}
        book = dict(token=token, condition_id=raw.get('market', old.get('condition_id')),
                    bids=levels('bids'), asks=levels('asks'), timestamp=timestamp, received_at=now,
                    source=source, verified_at=now if source == 'rest' else old.get('verified_at'),
                    tick_size=float(raw.get('tick_size') or old.get('tick_size') or .01),
                    min_order_size=float(raw.get('min_order_size') or old.get('min_order_size') or 0),
                    last_trade_price=raw.get('last_trade_price', old.get('last_trade_price')))
        self.books[token] = book

    def rest_book(self, token):
        started = time.monotonic()
        url = CLOB + '/book?' + urllib.parse.urlencode({'token_id': token})
        req = urllib.request.Request(url, headers={'User-Agent': 'Macrobook/2.0'})
        with urllib.request.urlopen(req, timeout=12) as response:
            payload = json.load(response)
        if str(payload.get('asset_id')) != str(token):
            raise ValueError('Order-book response does not identify the requested token.')
        with self.lock:
            self._book(token, payload, time.time(), 'rest')
            self.status.update(last_rest=time.time(), rest_latency_ms=round((time.monotonic()-started)*1000, 1))
        return self.book(token)

    def book(self, token, fresh=False):
        if fresh:
            return self.rest_book(token)
        with self.lock:
            book = copy.deepcopy(self.books.get(token))
        if not book:
            return self.rest_book(token)
        book['bids'] = sorted(book['bids'].items(), reverse=True)
        book['asks'] = sorted(book['asks'].items())
        book['bid'] = book['bids'][0][0] if book['bids'] else None
        book['ask'] = book['asks'][0][0] if book['asks'] else None
        if book['bid'] is not None and book['ask'] is not None:
            if book['bid'] > book['ask']:
                raise ValueError('Crossed order book: waiting for a coherent snapshot.')
            book['price'] = (book['bid'] + book['ask']) / 2
        elif book['bid'] is not None or book['ask'] is not None:
            book['price'] = book['bid'] if book['bid'] is not None else book['ask']
        elif book.get('last_trade_price') is not None:
            book['price'] = float(book['last_trade_price'])
        else:
            raise ValueError('Current order book has no price for token ' + token)
        return book

    def snapshot(self):
        with self.lock:
            result = dict(self.status)
            tokens = sorted(self.tokens)
        rows = []
        for token in tokens:
            try:
                with self.lock:
                    existing = token in self.books
                if existing:
                    b = self.book(token)
                    rows.append({k: b[k] for k in ('token', 'condition_id', 'bid', 'ask', 'price',
                                'timestamp', 'received_at', 'verified_at', 'source', 'min_order_size', 'tick_size')})
            except ValueError:
                continue
        result['books'] = rows
        return result

    def _close(self, ws, code, message):
        with self.lock:
            self.status['connected'] = False

    def _error(self, ws, error):
        with self.lock:
            self.status.update(connected=False, error=str(error))

    def _loop(self):
        while not self.stop.is_set():
            if not self.tokens:
                self.stop.wait(.5)
                continue
            self.ws = websocket.WebSocketApp(MARKET_WS, on_open=self._open, on_message=self._message,
                                             on_close=self._close, on_error=self._error)
            self.ws.run_forever(skip_utf8_validation=True)
            if self.stop.is_set():
                break
            with self.lock:
                self.status['reconnects'] += 1
            self.stop.wait(3)

    def _heartbeat(self):
        while not self.stop.wait(10):
            with self.lock:
                connected, pong = self.status['connected'], self.status['last_pong']
            if connected and self.ws:
                try:
                    if pong and time.time() - pong > 30:
                        self.ws.close()
                    else:
                        self.ws.send('PING')
                except Exception:
                    self.ws.close()

    def close(self):
        self.stop.set()
        if self.ws:
            self.ws.close()


class AccountFeed:
    def __init__(self, store, catalog, market):
        self.store, self.catalog, self.market = store, catalog, market
        self.api = PublicAPI()
        self.stop = threading.Event()
        self.lock = threading.RLock()
        self.wallets, self.snapshots = {}, {}
        self.managed_tokens = set()
        with store.connect() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS source_events(
                id TEXT PRIMARY KEY,wallet TEXT,observed_at REAL,event_at INTEGER,body TEXT);
                CREATE TABLE IF NOT EXISTS source_snapshots(wallet TEXT PRIMARY KEY,body TEXT);''')
            # Restore the activity cursor, but never execute against an offline
            # snapshot until both positions and the intervening activity refresh.
            self.snapshots = {r['wallet']: dict(json.loads(r['body']), needs_refresh=True)
                              for r in db.execute('SELECT wallet,body FROM source_snapshots')}
        self.thread = threading.Thread(target=self._loop, name='source-accounts', daemon=True)
        self.thread.start()

    def set_wallets(self, rows):
        with self.lock:
            self.wallets = {r['wallet']: r for r in rows}

    def set_managed_tokens(self, tokens):
        with self.lock:
            self.managed_tokens = set(tokens)

    def _subscribe(self):
        with self.lock:
            tokens = self.managed_tokens | {p['token_id'] for w in self.wallets
                for p in self.snapshots.get(w, {}).get('positions', []) if not p.get('redeemable')}
        self.market.subscribe(tokens)

    def snapshot(self):
        with self.lock:
            return [dict(copy.deepcopy(self.snapshots.get(w, {})), **r) for w, r in self.wallets.items()]

    def positions(self, wallet):
        with self.lock:
            row = copy.deepcopy(self.snapshots.get(wallet))
        if not row or row.get('error') or not row.get('checked_at') or row.get('needs_refresh'):
            raise ValueError('Source account snapshot is not currently available: ' + wallet)
        # This is connection freshness, not another account selection filter.
        if time.time() - row['checked_at'] > max(ACCOUNT_POLL_SECONDS * 3, row.get('cycle_seconds', 0) * 2):
            raise ValueError('Source account monitor has not completed its next refresh: ' + wallet)
        return row

    def _one(self, wallet):
        started = time.monotonic()
        with self.lock:
            old = copy.deepcopy(self.snapshots.get(wallet, {}))
        try:
            positions = self.catalog.relevant_positions(self.api.positions(wallet), self.api)
            end = int(time.time())
            cursor = old.get('activity_through') or old.get('latest_activity_at') or old.get('checked_at')
            start = max(1, int(cursor or (end - 86400)) - 600)
            activity = [r for page in self.api.pages('/v2/activity', dict(user=wallet, type='TRADE',
                start=start, end=end, limit=1000, sort_direction='DESC', exclude_deposits_withdrawals='true'))
                for r in page if self.catalog.has(r.get('condition_id'))]
            observed = time.time()
            latest = max((int(r['timestamp']) for r in activity), default=old.get('latest_activity_at'))
            new_count = 0
            delays = []
            with self.store.connect() as db:
                for r in activity:
                    key = event_key(wallet, r)
                    inserted = db.execute('INSERT OR IGNORE INTO source_events VALUES(?,?,?,?,?)',
                        (key, wallet, observed, int(r['timestamp']), json.dumps(r))).rowcount
                    if inserted and old.get('checked_at'):
                        new_count += 1
                        delays.append(max(0, observed - int(r['timestamp'])))
            key = inventory_key(positions)
            with self.lock:
                watched_count = len(self.wallets)
            request_seconds = time.monotonic()-started
            estimated_interval = ACCOUNT_POLL_SECONDS + watched_count / 8 * request_seconds
            cycle = observed-old['checked_at'] if old.get('checked_at') and not old.get('needs_refresh') else estimated_interval
            snapshot = dict(wallet=wallet, positions=positions, inventory_key=key,
                checked_at=observed, activity_through=end, latest_activity_at=latest,
                latency_ms=round((time.monotonic()-started)*1000, 1),
                position_count=len(positions), changed_at=observed if key != old.get('inventory_key') else old.get('changed_at'),
                new_events=old.get('new_events', 0) + new_count,
                observed_trade_delay_seconds=min(delays) if delays else old.get('observed_trade_delay_seconds'),
                cycle_seconds=max(cycle, estimated_interval), error=None)
            with self.store.connect() as db:
                db.execute('INSERT OR REPLACE INTO source_snapshots VALUES(?,?)', (wallet, json.dumps(snapshot)))
            with self.lock:
                self.snapshots[wallet] = snapshot
            self._subscribe()
        except Exception as exc:
            with self.lock:
                self.snapshots[wallet] = dict(old, wallet=wallet, error=str(exc), failed_at=time.time())

    def _loop(self):
        pool = concurrent.futures.ThreadPoolExecutor(max_workers=8)
        running, last = {}, {}
        try:
            while not self.stop.wait(.25):
                for wallet, future in list(running.items()):
                    if future.done():
                        future.result()
                        running.pop(wallet)
                        last[wallet] = time.monotonic()
                with self.lock:
                    wallets = sorted(self.wallets, key=lambda w: last.get(w, 0))
                for wallet in wallets:
                    if len(running) >= 8:
                        break
                    if wallet not in running and time.monotonic()-last.get(wallet, 0) >= ACCOUNT_POLL_SECONDS:
                        running[wallet] = pool.submit(self._one, wallet)
                self._subscribe()
        finally:
            pool.shutdown(wait=False, cancel_futures=True)

    def close(self):
        self.stop.set()
        self.api.cancel.set()
