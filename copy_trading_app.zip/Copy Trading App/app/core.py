"""Local, persistent paper portfolios. This module never submits real orders."""
from __future__ import annotations

import csv
import gzip
import io
import json
import math
import sqlite3
import statistics
import threading
import time
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
HISTORY = ROOT / 'results_all_accounts_macro'
DATA = HERE / 'data'
DATA.mkdir(exist_ok=True)
DAY = 86400
DEFAULT_CASE = 'effective_effective_range_3_4_reset75_vol365'


class Database(sqlite3.Connection):
    def __exit__(self, *args):
        try:
            return super().__exit__(*args)
        finally:
            self.close()


def utc(ts=None):
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() if ts is None else ts))


def stamp(text):
    import datetime
    return int(datetime.datetime.fromisoformat(text.replace('Z', '+00:00')).timestamp())


def stats(values):
    if not values:
        return dict(total_return=0, sharpe=None, max_drawdown=0)
    returns = [b / a - 1 if a else 0 for a, b in zip(values, values[1:])]
    sd = statistics.stdev(returns) if len(returns) > 1 else 0
    peak = values[0]
    dd = 0
    for value in values:
        peak = max(peak, value)
        dd = min(dd, value / peak - 1) if peak else dd
    return dict(total_return=values[-1] / values[0] - 1 if values[0] else 0,
                sharpe=math.sqrt(365) * statistics.fmean(returns) / sd if sd > 1e-15 else None,
                max_drawdown=dd)


def portfolio_stats(run, points, at):
    """Completed 24-hour returns from funding, including the first day's P&L."""
    start = run['created_at']
    daily = {}
    observed = sorted((p for p in points if start <= p['ts'] <= at), key=lambda p:p['ts'])
    for point in observed:
        # A point exactly on the boundary closes the preceding 24-hour period.
        period = max(0, math.ceil((point['ts'] - start) / DAY) - 1)
        daily[period] = point
    elapsed = max(0, int((at - start) // DAY))
    completed = [daily[d] for d in sorted(daily) if d < elapsed]
    gaps = len(completed) != elapsed
    result = stats([run['initial']] + [p['nav'] for p in completed])
    if gaps:
        result['sharpe'] = None
    result.update(total_return=nav(run) / run['initial'] - 1,
        daily_observations=len(completed), has_daily_gaps=gaps,
        sharpe_window_start=start,
        sharpe_window_end=completed[-1]['ts'] if completed else None,
        sharpe_window_return=completed[-1]['nav']/run['initial']-1 if completed else None,
        max_drawdown=stats([run['initial']] + [p['nav'] for p in observed] + [nav(run)])['max_drawdown'])
    return result


class Store:
    def __init__(self, path=None):
        self.path = Path(path or DATA / 'paper.sqlite')
        self.lock = threading.RLock()
        with self.connect() as db:
            db.executescript('''
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY,body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY,body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS points(run TEXT,ts INTEGER,nav REAL,cash REAL,PRIMARY KEY(run,ts));
                CREATE TABLE IF NOT EXISTS fills(id INTEGER PRIMARY KEY,run TEXT,ts INTEGER,wallet TEXT,
                    name TEXT,token TEXT,title TEXT,outcome TEXT,side TEXT,shares REAL,price REAL,
                    notional REAL,reason TEXT,quote_ts INTEGER);
                CREATE TABLE IF NOT EXISTS selections(run TEXT,ts INTEGER,wallet TEXT,body TEXT,
                    PRIMARY KEY(run,ts,wallet));
                CREATE TABLE IF NOT EXISTS account_points(run TEXT,ts INTEGER,wallet TEXT,nav REAL,pnl REAL,
                    PRIMARY KEY(run,ts,wallet));
                CREATE TABLE IF NOT EXISTS journal(id INTEGER PRIMARY KEY,ts INTEGER,level TEXT,message TEXT);
                CREATE TABLE IF NOT EXISTS copy_decisions(id TEXT PRIMARY KEY,run TEXT,wallet TEXT,ts REAL,body TEXT);
                CREATE INDEX IF NOT EXISTS copy_decisions_run ON copy_decisions(run,ts);
                CREATE TABLE IF NOT EXISTS source_events(id TEXT PRIMARY KEY,wallet TEXT,observed_at REAL,event_at INTEGER,body TEXT);
                CREATE INDEX IF NOT EXISTS source_events_wallet ON source_events(wallet,observed_at);
            ''')
            columns = {r['name'] for r in db.execute('PRAGMA table_info(fills)')}
            for column in ('order_id', 'source_change_id'):
                if column not in columns:
                    db.execute('ALTER TABLE fills ADD COLUMN ' + column + ' TEXT')
            if 'mark' not in columns:
                db.execute('ALTER TABLE fills ADD COLUMN mark REAL')
            if 'run' not in {r['name'] for r in db.execute('PRAGMA table_info(journal)')}:
                db.execute('ALTER TABLE journal ADD COLUMN run TEXT')
                active = db.execute("SELECT body FROM kv WHERE key='active_run'").fetchone()
                if active:
                    db.execute('UPDATE journal SET run=?', (json.loads(active[0]),))

    def connect(self):
        db = sqlite3.connect(self.path, timeout=30, factory=Database)
        db.row_factory = sqlite3.Row
        return db

    def get(self, key, default=None):
        with self.connect() as db:
            row = db.execute('SELECT body FROM kv WHERE key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def put(self, key, value):
        with self.lock, self.connect() as db:
            db.execute('INSERT OR REPLACE INTO kv VALUES(?,?)', (key, json.dumps(value, allow_nan=False)))

    def log(self, message, level='info', run_id=None):
        with self.connect() as db:
            db.execute('INSERT INTO journal(ts,level,message,run) VALUES(?,?,?,?)',
                       (int(time.time()), level, message, run_id or self.get('active_run')))

    def run(self, run_id=None):
        run_id = run_id or self.get('active_run')
        if not run_id:
            return None
        with self.connect() as db:
            row = db.execute('SELECT body FROM runs WHERE id=?', (run_id,)).fetchone()
        if row:
            result = json.loads(row[0])
            result.setdefault('mode', 'sandbox')
            return result
        return None

    def create(self, case, initial, mode='sandbox', name=None, activate=True):
        if mode not in ('sandbox', 'live'):
            raise ValueError('Choose sandbox or live execution.')
        initial = float(initial)
        if not math.isfinite(initial) or not 0 < initial <= 1e9:
            raise ValueError('Starting capital must be between 0 and $1 billion.')
        with self.lock:
            previous = self.run()
            if previous and activate:
                previous['status'] = 'paused'
                self.save(previous)
            run = dict(id=uuid.uuid4().hex[:12], created_at=int(time.time()), case=case, mode=mode,
                       initial=initial, cash=initial, status='ready', accounts={}, next_reset=None,
                       last_sync=None, last_position_day=None, last_screen=None, issue=None)
            run['name'] = str(name or '').strip()[:80] or ('Sandbox ' if mode == 'sandbox' else 'Real money ') + run['id'][:6]
            self.save(run, point=True)
            if activate or not previous:
                self.put('active_run', run['id'])
            self.log('Created ' + mode + ' portfolio ' + run['id'] + '; execution has not started.', run_id=run['id'])
            return run

    def save(self, run, fills=(), selected=(), point=False, at=None, order_update=None, order_insert=None):
        at = int(time.time()) if at is None else at
        with self.connect() as db:
            if order_update:
                order_id, state, body = order_update
                current = db.execute('SELECT state,body FROM execution_orders WHERE id=?', (order_id,)).fetchone()
                if current and current['state'] in ('applied','limit_filled','limit_cancelled','limit_rejected'):
                    raise ValueError('This order was already applied to the portfolio.')
                if not current:
                    raise ValueError('Missing order journal entry.')
                if state.startswith('limit_'):
                    prior=json.loads(current['body']).get('result',{}).get('shares',0.)
                    delta=body.get('result',{}).get('shares',0.)-prior
                    booked=math.fsum(f['shares'] for f in fills if f.get('order_id')==order_id)
                    if not math.isclose(delta,booked,abs_tol=1e-7):
                        raise ValueError('Limit fill checkpoint does not match the new fill delta.')
                db.execute('UPDATE execution_orders SET state=?,updated=?,body=? WHERE id=?',
                           (state, time.time(), json.dumps(body, allow_nan=False), order_id))
            if order_insert:
                order_id, state, body = order_insert
                db.execute('INSERT INTO execution_orders VALUES(?,?,?,?,?,?,?)',
                    (order_id, run['id'], run.get('mode', 'sandbox'), state, time.time(), time.time(), json.dumps(body, allow_nan=False)))
            saved = {k: v for k, v in run.items() if k != '_copy_decisions'}
            db.execute('INSERT OR REPLACE INTO runs VALUES(?,?)', (run['id'], json.dumps(saved, allow_nan=False)))
            for decision in run.get('_copy_decisions', []):
                db.execute('INSERT OR IGNORE INTO copy_decisions VALUES(?,?,?,?,?)',
                    (decision['id'], run['id'], decision['wallet'], decision['ts'], json.dumps(decision, allow_nan=False)))
            for fill in fills:
                db.execute('''INSERT INTO fills(run,ts,wallet,name,token,title,outcome,side,shares,price,
                    notional,reason,quote_ts,order_id,source_change_id,mark) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                    (run['id'], at, *[fill[k] for k in ('wallet', 'name', 'token', 'title', 'outcome',
                        'side', 'shares', 'price', 'notional', 'reason', 'quote_ts')],
                        fill.get('order_id'), fill.get('source_change_id'), fill.get('mark')))
            for row in selected:
                db.execute('INSERT OR REPLACE INTO selections VALUES(?,?,?,?)',
                           (run['id'], at, row['wallet'], json.dumps(row, allow_nan=False)))
            if point:
                db.execute('INSERT OR REPLACE INTO points VALUES(?,?,?,?)',
                           (run['id'], at, nav(run), cash_value(run)))
                for wallet, account in run['accounts'].items():
                    db.execute('INSERT OR REPLACE INTO account_points VALUES(?,?,?,?,?)',
                        (run['id'], at, wallet, account_nav(account), account.get('pnl', 0)))
                for wallet, account in run.get('retired_accounts', {}).items():
                    db.execute('INSERT OR REPLACE INTO account_points VALUES(?,?,?,?,?)',
                        (run['id'], at, wallet, 0., account['pnl']))
        run.pop('_copy_decisions', None)

    def rows(self, sql, args=()):
        with self.connect() as db:
            return [dict(r) for r in db.execute(sql, args)]


def account_nav(account):
    return account['cash'] + math.fsum(p['shares'] * p['price'] for p in account['positions'].values())


def cash_value(run):
    return run['cash'] + math.fsum(a['cash'] for a in run['accounts'].values())


def nav(run):
    return run['cash'] + math.fsum(account_nav(a) for a in run['accounts'].values())


def inverse_weights(selected):
    if not selected:
        return []
    if any(not math.isfinite(r['sigma']) or r['sigma'] <= 0 for r in selected):
        raise ValueError('Every selected account needs a positive observed volatility.')
    total = math.fsum(1 / r['sigma'] for r in selected)
    return [dict(r, weight=(1 / r['sigma']) / total) for r in selected]


def rebalance_account(account, positions, quotes, wallet, reason):
    """Reallocate one self-financing slice to observed relative macro positions.

    Resolved source positions reserve cash. No quote is an invented zero price.
    All mutations happen on the caller's uncommitted JSON copy, for atomic saves.
    """
    for token, held in account['positions'].items():
        q = quotes[token]
        held.update(price=q['price'], quote_ts=q['timestamp'])
    capital = account_nav(account)
    valued = [(p, quotes[p['token_id']]['price'] * float(p['current_size'])) for p in positions]
    total = math.fsum(v for _, v in valued)
    targets = {p['token_id']: capital * v / total for p, v in valued
               if total > 0 and v > 0 and not p.get('redeemable') and not quotes[p['token_id']].get('settled')}
    source = {p['token_id']: p for p in positions}
    old = account['positions']
    new = {}
    fills = []
    for token in sorted(set(old) | set(targets)):
        q = quotes[token]
        price = q['price']
        prev = old.get(token, {})
        meta = source.get(token, prev)
        shares = targets.get(token, 0) / price if price > 0 else 0
        before = prev.get('shares', 0)
        delta = shares - before
        if abs(delta) > 1e-8:
            fills.append(dict(wallet=wallet, name=account['name'], token=token,
                title=meta.get('title', ''), outcome=meta.get('outcome', ''),
                side='BUY' if delta > 0 else 'SELL', shares=abs(delta), price=price,
                notional=abs(delta) * price, reason=reason, quote_ts=q['timestamp']))
        if shares > 1e-10:
            prior_cost = prev.get('cost', before * price)
            cost = (prior_cost * shares / before if shares <= before and before > 0
                    else prior_cost + (shares - before) * price)
            new[token] = dict(shares=shares, price=price, cost=cost, quote_ts=q['timestamp'],
                              title=meta.get('title', ''), outcome=meta.get('outcome', ''),
                              condition_id=meta.get('condition_id', prev.get('condition_id', '')))
    account['positions'] = new
    account['cash'] = max(0., capital - math.fsum(p['shares'] * p['price'] for p in new.values()))
    if not math.isclose(account_nav(account), capital, rel_tol=1e-10, abs_tol=1e-7):
        raise ValueError('Paper rebalance did not conserve NAV.')
    return fills


class Archive:
    def __init__(self):
        self.result = json.loads((HISTORY / 'strategy_results.json').read_text(encoding='utf-8'))
        self.cases = {r['case_id']: r for r in self.result['cases']}
        self.cached = {}

    def case(self, case_id):
        if case_id not in self.cases:
            raise ValueError('Unknown saved configuration.')
        return self.cases[case_id]

    def replay(self, case_id):
        if case_id in self.cached:
            return self.cached[case_id]
        case = self.case(case_id)
        directory = HISTORY / 'simulations'
        with (directory / case['daily_dataset']).open(newline='', encoding='utf-8') as f:
            curve = [dict(ts=stamp(r['timestamp_utc']), nav=float(r['equity']),
                          daily_return=float(r['daily_return']) if r['daily_return'] else None)
                     for r in csv.DictReader(f)]
        with gzip.open(directory / case['accounts_dataset'], 'rt', newline='', encoding='utf-8') as f:
            accounts = list(csv.DictReader(f))
        with (directory / case['period_dataset']).open(newline='', encoding='utf-8') as f:
            periods = list(csv.DictReader(f))
        result = dict(case=case, curve=curve, accounts=accounts, periods=periods,
                      start=self.result['simulation_start'], end=self.result['simulation_end_exclusive'])
        self.cached[case_id] = result
        return result


def csv_text(rows):
    out = io.StringIO(newline='')
    if rows:
        writer = csv.DictWriter(out, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return out.getvalue()
