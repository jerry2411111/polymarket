"""Offline authentication checks with an ephemeral signer; no real credentials."""
import contextlib
import io
import unittest
from unittest.mock import Mock, patch

import generate_clob_credentials as helper
from eth_account.messages import encode_typed_data
from polymarket._internal.l1_auth import build_api_key_auth_typed_data
from polymarket.errors import RequestRejectedError


class CredentialHelperTests(unittest.TestCase):
    def setUp(self):
        self.signer = helper.Account.create()
        self.transport = Mock()
        self.values = dict(apiKey="example-key", secret="example-secret", passphrase="example-passphrase")
        self.transport.post_json.return_value = self.values
        self.transport.get_json.return_value = self.values
        patcher = patch.object(helper, "SyncTransport", return_value=self.transport)
        self.factory = patcher.start()
        self.addCleanup(patcher.stop)
        guard = patch("socket.socket.connect", side_effect=AssertionError("Network disabled"))
        guard.start()
        self.addCleanup(guard.stop)

    def test_creation_signs_for_correct_signer_chain_and_nonce(self):
        with patch.object(helper.time, "time", return_value=1790553600):
            credentials = helper.generate_credentials(self.signer, 7)
        self.assertEqual(credentials.key, self.values["apiKey"])
        self.factory.assert_called_once_with(base_url="https://clob.polymarket.com")
        call = self.transport.post_json.call_args
        self.assertEqual(call.args, ("/auth/api-key",))
        headers = call.kwargs["headers"]
        typed = build_api_key_auth_typed_data(address=self.signer.address, chain_id=137,
                                             timestamp=1790553600, nonce=7)
        recovered = helper.Account.recover_message(encode_typed_data(full_message=typed),
                                                  signature=headers["POLY_SIGNATURE"])
        self.assertEqual(recovered, self.signer.address)
        self.assertEqual(headers["POLY_NONCE"], "7")
        self.assertEqual(headers["POLY_ADDRESS"], self.signer.address)
        self.assertNotIn(self.signer.key.hex(), str(call))
        self.transport.get_json.assert_not_called()
        self.transport.close.assert_called_once()

    def test_existing_key_is_derived(self):
        self.transport.post_json.side_effect = RequestRejectedError("exists", status=400)
        result = helper.generate_credentials(self.signer)
        self.assertEqual(result.secret, self.values["secret"])
        self.assertEqual(self.transport.get_json.call_args.args, ("/auth/derive-api-key",))
        self.assertEqual(self.transport.get_json.call_args.kwargs["headers"]["POLY_NONCE"], "0")
        self.transport.close.assert_called_once()

    def test_other_rejections_do_not_attempt_derivation(self):
        self.transport.post_json.side_effect = RequestRejectedError("denied", status=403)
        with self.assertRaises(RequestRejectedError):
            helper.generate_credentials(self.signer)
        self.transport.get_json.assert_not_called()
        self.transport.close.assert_called_once()

    def test_invalid_nonce_never_opens_connection(self):
        with self.assertRaises(ValueError):
            helper.generate_credentials(self.signer, -1)
        self.factory.assert_not_called()

    def test_failure_output_does_not_echo_secrets(self):
        output = io.StringIO()
        with patch.object(helper, "read_signer", return_value=self.signer), \
                patch.object(helper, "generate_credentials", side_effect=RuntimeError("SECRET_MUST_NOT_APPEAR")), \
                contextlib.redirect_stdout(output):
            self.assertEqual(helper.main([]), 1)
        self.assertNotIn("SECRET_MUST_NOT_APPEAR", output.getvalue())
        self.assertNotIn(self.signer.key.hex(), output.getvalue())


if __name__ == "__main__":
    unittest.main()
