"""Read-only availability check against archived followed wallets; never trades."""
import json
import time
from core import Archive, DATA, DEFAULT_CASE, Store, utc
from screening import Catalog
from realtime import AccountFeed, MarketFeed

def main():
    replay = Archive().replay(DEFAULT_CASE)
    last = max(r['period_start_utc'] for r in replay['accounts'])
    rows = [dict(wallet=r['wallet'], name=r.get('account_name') or r.get('name') or r['wallet'],
                 role='archived feed probe; not live selected')
            for r in replay['accounts'] if r['period_start_utc'] == last]
    market = MarketFeed()
    feed = AccountFeed(Store(DATA / 'feed_check.sqlite'), Catalog(), market)
    feed.set_wallets(rows)
    deadline = time.time() + 45
    while time.time() < deadline:
        time.sleep(1)
        snapshots = feed.snapshot()
        if snapshots and all(s.get('checked_at') or s.get('error') for s in snapshots) and market.status['messages']:
            break
    snapshots = feed.snapshot()
    book_result = []
    tokens = sorted({p['token_id'] for r in snapshots for p in r.get('positions', []) if not p.get('redeemable')})
    for token in tokens[:5]:
        try:
            book = market.book(token, fresh=True)
            book_result.append({k:book[k] for k in ('token','bid','ask','timestamp','received_at','min_order_size')})
        except Exception as exc:
            book_result.append(dict(token=token, error=str(exc)))
    result = dict(checked_at=utc(), wallets=len(rows), successful=sum(bool(s.get('checked_at')) for s in snapshots),
        accounts=[{k:v for k,v in r.items() if k!='positions'} for r in snapshots],
        macro_positions=sum(r.get('position_count',0) for r in snapshots), market_stream=market.status,
        rest_books=book_result, current_qualification=False)
    (DATA / 'live_availability_report.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2), flush=True)
    feed.close()
    market.close()

if __name__ == '__main__':
    main()
