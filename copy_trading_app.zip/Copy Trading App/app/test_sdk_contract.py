"""Actual installed official SDK, locally signed orders, fake HTTP transport only."""
import unittest
from decimal import Decimal
from types import SimpleNamespace
from unittest.mock import Mock, patch

from execution import LiveBroker
from limit_orders import POLICY
from polymarket import SecureClient, ApiKeyCreds
from polymarket.environments import PRODUCTION
from polymarket.errors import UnexpectedResponseError
from eth_account import Account


class SDKContractTests(unittest.TestCase):
    def setUp(self):
        # An ephemeral unfunded test signer; no user credentials or network.
        signer = Account.create()
        self.http = SimpleNamespace(post_json=Mock(), get_json=Mock(), delete_json=Mock())
        self.client = SecureClient.__new__(SecureClient)
        self.client._ended = False
        self.client._ctx = SimpleNamespace(signer=signer, wallet=signer.address,
            wallet_type='EOA', signer_type='OWNER', environment_config=PRODUCTION._config,
            credentials=ApiKeyCreds(apiKey='local-test', secret='unused', passphrase='unused'),
            secure_clob=self.http,
            order_metadata=SimpleNamespace(resolve_market=lambda *a, **kw:
                SimpleNamespace(tick_size=Decimal('.01'), neg_risk=False)))
        self.broker = LiveBroker()
        self.broker.client = self.client
        self.broker.armed = True
        self.network_guard = patch('socket.socket.connect', side_effect=AssertionError('Network disabled in SDK contract test'))
        self.network_guard.start()
        self.addCleanup(self.network_guard.stop)

    def intent(self, side):
        return dict(execution_policy=POLICY, order_type='GTC', post_only=True,
                    quote_method='midpoint', token='1', side=side, shares=10, limit_price=.5)

    def response(self, **changes):
        return dict(errorMsg='', makingAmount='', takingAmount='', orderID='own-order',
                    status='live', success=True, tradeIDs=[], transactionsHashes=[], **changes)

    def test_official_signing_and_post_payload_for_both_sides(self):
        self.http.post_json.return_value = self.response()
        for side in ('BUY', 'SELL'):
            result = self.broker.submit(self.intent(side), {})
            args = self.http.post_json.call_args
            self.assertEqual(args.args, ('/order',))
            payload = args.kwargs['json']
            self.assertEqual(payload['orderType'], 'GTC')
            self.assertTrue(payload['postOnly'])
            self.assertEqual(payload['order']['side'], side)
            self.assertTrue(payload['order']['signature'].startswith('0x'))
            self.assertEqual(payload['order']['tokenId'], '1')
            self.assertEqual(payload['order']['makerAmount'], '5000000' if side == 'BUY' else '10000000')
            self.assertEqual(result['state'], 'submitted')
            self.assertEqual(result['exchange_order_id'], 'own-order')
            self.assertEqual(result['shares'], 0)
            self.assertEqual(result['response']['status'], 'live')

    def test_official_rejection_is_not_a_fill(self):
        response = self.response()
        response.update(success=False, orderID='', status='', errorMsg='invalid post-only order: order crosses book')
        self.http.post_json.return_value = response
        result = self.broker.submit(self.intent('BUY'), {})
        self.assertEqual(result['state'], 'rejected')
        self.assertEqual(result['shares'], 0)
        self.assertIsNone(result['exchange_order_id'])

    def test_malformed_exchange_ack_is_not_treated_as_rejection_or_fill(self):
        self.http.post_json.return_value = {'unrecognized': 'response'}
        with self.assertRaises(UnexpectedResponseError):
            self.broker.submit(self.intent('BUY'), {})

    def test_order_and_cancel_response_models(self):
        self.http.get_json.return_value = dict(id='own-order', market='0x'+'0'*64,
            asset_id='1', owner='local-test', maker_address=self.client._ctx.wallet,
            side='BUY', price='.5', original_size='10', size_matched='3', outcome='Yes',
            order_type='GTC', status='LIVE', associate_trades=['trade-1'], created_at=1790553600)
        order = self.client.get_order(order_id='own-order')
        self.assertEqual(order.associate_trades, ('trade-1',))
        self.assertEqual(order.size_matched, Decimal('3'))
        self.http.delete_json.return_value = {'canceled':['own-order'], 'not_canceled':{}}
        result = self.client.cancel_order(order_id='own-order')
        self.assertIn('own-order', result.canceled)


if __name__ == '__main__':
    unittest.main(verbosity=2)
