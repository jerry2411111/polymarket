"""Focused checks for paper accounting, persistence and point-in-time quotes."""
import math
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from api import PublicAPI
from core import Archive, DEFAULT_CASE, Store, account_nav, inverse_weights, nav, rebalance_account


def position(token, qty, price, resolved=False):
    return dict(token_id=token, current_size=qty, current_price=price,
                title=token, outcome='Yes', condition_id='condition', redeemable=resolved)


class PaperTests(unittest.TestCase):
    def test_relative_position_changes_are_not_profits(self):
        a = dict(name='A', cash=1000., positions={})
        q = {'iran': dict(price=.5, timestamp=1), 'fed': dict(price=.5, timestamp=1)}
        rebalance_account(a, [position('iran', 40000, .5), position('fed', 10000, .5)], q, 'A', 'initial')
        self.assertAlmostEqual(a['positions']['iran']['shares'] * .5, 800.)
        self.assertAlmostEqual(a['positions']['fed']['shares'] * .5, 200.)
        q = {'iran': dict(price=.55, timestamp=2), 'fed': dict(price=.45, timestamp=2)}
        # Prior weights produce the user's 80% * 10% + 20% * -10% = 6%.
        for token, p in a['positions'].items():
            p['price'] = q[token]['price']
        self.assertAlmostEqual(account_nav(a), 1060.)
        # Doubling source exposure does not double paper NAV.
        rebalance_account(a, [position('iran', 80000, .55), position('fed', 20000, .45)], q, 'A', 'daily')
        self.assertAlmostEqual(account_nav(a), 1060.)

    def test_same_observations_cannot_duplicate_fills(self):
        a = dict(name='A', cash=1000., positions={})
        q = {'x': dict(price=.25, timestamp=1)}
        source = [position('x', 100, .25)]
        first = rebalance_account(a, source, q, 'A', 'initial')
        second = rebalance_account(a, source, q, 'A', 'repeat')
        self.assertEqual(len(first), 1)
        self.assertEqual(second, [])
        self.assertAlmostEqual(account_nav(a), 1000.)

    def test_empty_and_resolved_books_leave_cash(self):
        a = dict(name='A', cash=1000., positions={})
        q = {'x': dict(price=1., timestamp=1)}
        rebalance_account(a, [position('x', 100, 1., True)], q, 'A', 'initial')
        self.assertEqual(a['positions'], {})
        self.assertEqual(a['cash'], 1000.)
        q['x']['price'] = .5
        rebalance_account(a, [position('x', 100, .5)], q, 'A', 'initial')
        fills = rebalance_account(a, [], q, 'A', 'exit')
        self.assertEqual(fills[0]['side'], 'SELL')
        self.assertAlmostEqual(a['cash'], 1000.)

    def test_inverse_volatility_uses_every_account(self):
        rows = inverse_weights([dict(wallet='A', sigma=.01), dict(wallet='B', sigma=.02), dict(wallet='C', sigma=.04)])
        self.assertEqual(len(rows), 3)
        self.assertAlmostEqual(sum(r['weight'] for r in rows), 1.)
        self.assertAlmostEqual(rows[0]['weight'], 4/7)
        self.assertAlmostEqual(rows[2]['weight'], 1/7)

    def test_atomic_ledger_and_restart(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'paper.sqlite'
            store = Store(db)
            run = store.create({'case_id': 'test'}, 1000)
            a = dict(name='A', cash=1000., positions={})
            fills = rebalance_account(a, [position('x', 100, .4)], {'x':dict(price=.4,timestamp=1)}, 'A', 'initial')
            run['accounts'] = {'A':a}
            run['cash'] = 0
            store.save(run, fills=fills, point=True)
            restarted = Store(db)
            self.assertEqual(restarted.run(), run)
            self.assertAlmostEqual(nav(restarted.run()), 1000.)
            self.assertEqual(len(restarted.rows('SELECT * FROM fills')), 1)
            bad = dict(run, cash=math.nan)
            with self.assertRaises(ValueError):
                store.save(bad, fills=fills)
            self.assertEqual(len(restarted.rows('SELECT * FROM fills')), 1)

    def test_unavailable_bucket_is_not_used_before_its_end(self):
        api = PublicAPI()
        with patch.object(api, 'get', return_value={'data':[
            dict(timestamp=100, resolution_seconds=100, price=.9),
            dict(timestamp=90, resolution_seconds=0, price=.4)]}):
            self.assertEqual(api.quote('x', 150)['price'], .4)
        with patch.object(api, 'get', return_value={'data':[]}):
            with self.assertRaises(ValueError):
                api.quote('x', 150)

    def test_settlement_is_only_known_at_actual_resolution_time(self):
        api = PublicAPI()
        with patch.object(api, 'get', return_value={'data':[dict(condition_id='c', status='resolved',
                               resolved_at='200', payouts=[1000000, 0])]}):
            self.assertEqual(api.settlements(['c'], 199), {})
            self.assertEqual(api.settlements(['c'], 200)['c']['payouts'], [1., 0.])

    def test_saved_selected_configuration_is_exactly_reused(self):
        replay = Archive().replay(DEFAULT_CASE)
        self.assertEqual(replay['case']['reset_days'], 75)
        self.assertEqual(replay['case']['lower'], 3)
        self.assertEqual(replay['case']['upper'], 4)
        self.assertEqual(len(replay['curve']), 366)
        self.assertAlmostEqual(replay['curve'][-1]['nav'], 28109.358935410015)
        groups = {}
        for a in replay['accounts']:
            self.assertGreater(float(a['effective_sharpe']), 3)
            self.assertLessEqual(float(a['effective_sharpe']), 4)
            groups.setdefault(a['period_start_utc'], []).append(a)
        self.assertTrue(any(len(g)>1 for g in groups.values()))
        for rows in groups.values():
            self.assertAlmostEqual(sum(float(r['portfolio_weight']) for r in rows), 1.)

    def test_engine_reset_realtime_copy_and_failed_quote_are_atomic(self):
        from server import Application
        from core import DAY
        from types import SimpleNamespace
        from realtime import inventory_key
        from execution import ExecutionRouter
        at = int(time.time()) // DAY * DAY + 120
        with tempfile.TemporaryDirectory() as d, patch('time.time', return_value=at) as clock:
            app = Application.__new__(Application)
            app.store = Store(Path(d) / 'engine.sqlite')
            case = Archive().case(DEFAULT_CASE)
            run = app.store.create(case, 10000)
            run['status'] = 'running'
            app.store.save(run)
            selected = inverse_weights([dict(wallet='A', name='A', sigma=.01), dict(wallet='B', name='B', sigma=.02)])
            app.store.put('screen_snapshot', dict(complete=True, as_of=at // DAY * DAY,
                          case_id=case['case_id'], selected=selected))
            sources = {'A':[position('x', 100, .5)], 'B':[position('y', 500, .5)]}
            app.api = SimpleNamespace(positions=lambda wallet: sources[wallet])
            app.catalog = SimpleNamespace(relevant_positions=lambda rows, api: rows)
            quotes = {'x':dict(price=.5, timestamp=at), 'y':dict(price=.5, timestamp=at)}
            app.quotes = lambda tokens, when: {t:quotes[t] for t in tokens}
            app.probes = []
            app.feed = SimpleNamespace(set_wallets=lambda rows:None, set_managed_tokens=lambda tokens:None,
                positions=lambda wallet:dict(positions=sources[wallet],inventory_key=inventory_key(sources[wallet])))
            def book(token, fresh=False):
                q=quotes[token]
                return dict(q, bids=[(q['price'],1e9)], asks=[(q['price'],1e9)], bid=q['price'],ask=q['price'],min_order_size=.01)
            app.market = SimpleNamespace(book=book)
            app.router = ExecutionRouter(app.store, app.market)
            app.poll()
            self.assertEqual(len(app.store.run()['accounts']), 2)
            self.assertAlmostEqual(nav(app.store.run()), 10000.)
            initial_fills = len(app.store.rows('SELECT * FROM fills'))
            app.poll()
            self.assertEqual(len(app.store.rows('SELECT * FROM fills')), initial_fills)
            clock.return_value = at + 100
            quotes['x']['price'], quotes['y']['price'] = .55, .45
            app.poll()
            self.assertAlmostEqual(nav(app.store.run()), 10000 * (1 + .1 * (2/3) - .1 * (1/3)), delta=.01)
            clock.return_value = at + 105  # Intraday inventory change, not tomorrow.
            sources['B'] = []
            app.poll()
            self.assertEqual(app.store.run()['accounts']['B']['positions'], {})
            saved = app.store.run()
            with patch.object(app, 'quotes', side_effect=ValueError('No observed quote')):
                app.poll()
            saved['issue'] = 'No observed quote'
            self.assertEqual(app.store.run(), saved)
            # At the next account reset A remains, B exits, and all remaining
            # capital is reassigned without manufacturing any portfolio return.
            clock.return_value = at + 75 * DAY
            app.store.put('screen_snapshot', dict(complete=True, as_of=int(clock.return_value) // DAY * DAY,
                case_id=case['case_id'], selected=inverse_weights([selected[0]])))
            before = nav(app.store.run())
            app.poll()
            after = app.store.run()
            self.assertEqual(set(after['accounts']), {'A'})
            self.assertAlmostEqual(nav(after), before)
            self.assertAlmostEqual(after['accounts']['A']['weight'], 1.)

    def test_delayed_screen_is_not_backdated_or_used_beyond_its_period(self):
        from server import Application
        from core import DAY
        case = Archive().case(DEFAULT_CASE)
        run = dict(created_at=100 * DAY, next_reset=None, case=case)
        snapshot = dict(complete=True, as_of=100 * DAY, case_id=case['case_id'])
        self.assertTrue(Application.snapshot_ready(run, snapshot, 102 * DAY))
        self.assertFalse(Application.snapshot_ready(run, snapshot, 175 * DAY))
        self.assertFalse(Application.snapshot_ready(run, dict(snapshot, complete=False), 102 * DAY))


if __name__ == '__main__':
    unittest.main(verbosity=2)
