"""Portfolio return series includes funding and never omits the first day's loss."""
import unittest
from core import DAY, portfolio_stats


class PortfolioStatsTests(unittest.TestCase):
    def test_funding_baseline_and_first_day_loss_are_in_sharpe(self):
        start=100*DAY+1234
        run=dict(created_at=start,initial=1000.,cash=910.,accounts={})
        points=[dict(ts=start,nav=1000),dict(ts=start+DAY,nav=900),dict(ts=start+2*DAY,nav=910)]
        result=portfolio_stats(run,points,start+2*DAY)
        self.assertEqual(result['daily_observations'],2)
        self.assertLess(result['sharpe'],0)
        self.assertAlmostEqual(result['total_return'],-.09)
        self.assertAlmostEqual(result['max_drawdown'],-.1)
        self.assertFalse(result['has_daily_gaps'])

    def test_no_annualized_sharpe_from_intraday_ticks_or_missing_days(self):
        run=dict(created_at=100,initial=1000.,cash=999.,accounts={})
        points=[dict(ts=100+i,nav=1000-i/100) for i in range(100)]
        result=portfolio_stats(run,points,200)
        self.assertIsNone(result['sharpe'])
        self.assertEqual(result['daily_observations'],0)
        points.append(dict(ts=100+3*DAY,nav=999))
        result=portfolio_stats(run,points,100+3*DAY)
        self.assertTrue(result['has_daily_gaps'])
        self.assertIsNone(result['sharpe'])


if __name__=='__main__':unittest.main()
