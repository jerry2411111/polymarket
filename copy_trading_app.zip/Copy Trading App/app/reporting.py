"""Read-only allocation and source-to-execution attribution for the dashboard."""
import json
import math

from core import account_nav, nav


def portfolio_breakdown(run):
    total = nav(run)
    accounts, positions = [], []
    active = [a for a in run['accounts'].values() if not a.get('exiting')]
    sigmas_valid = all(math.isfinite(a['metric'].get('sigma', 0)) and a['metric'].get('sigma', 0) > 0 for a in active)
    inverse_sum = math.fsum(1 / a['metric']['sigma'] for a in active) if sigmas_valid else 0
    for wallet, a in run['accounts'].items():
        value = account_nav(a)
        invested = math.fsum(p['shares'] * p['price'] for p in a['positions'].values())
        sigma = a['metric'].get('sigma')
        expected = (1 / sigma / inverse_sum) if inverse_sum and not a.get('exiting') else 0
        accounts.append(dict(wallet=wallet, name=a['name'], weight=a['weight'],
            expected_weight=expected, sigma=sigma, reset_budget=a.get('period_capital', 0),
            value=value, invested=invested, cash=a['cash'], portfolio_share=value / total if total else None,
            exiting=a.get('exiting', False), pnl=a.get('pnl', 0),
            period_return=value / a['period_capital'] - 1 if a.get('period_capital') else None,
            position_count=len(a['positions']), metric=a['metric']))
        for token, p in a['positions'].items():
            marked = p['shares'] * p['price']
            positions.append(dict(p, token=token, wallet=wallet, name=a['name'], value=marked,
                portfolio_share=marked / total if total else None,
                account_share=marked / value if value else None, unrealized=marked - p['cost']))
    weight_sum = math.fsum(a['weight'] for a in active)
    verified = bool(active) and sigmas_valid and math.isclose(weight_sum, 1., abs_tol=1e-9) and all(
        math.isclose(a['weight'], a['expected_weight'], abs_tol=1e-9) for a in accounts if not a['exiting'])
    audit = dict(formula='w_i = (1 / sigma_i) / sum_j(1 / sigma_j)',
        status='verified' if verified else 'waiting' if not active else 'mismatch',
        weight_sum=weight_sum, selected_count=len(active),
        reset_budget=math.fsum(a['reset_budget'] for a in accounts if not a['exiting']),
        invested=math.fsum(a['invested'] for a in accounts),
        attributed_cash=math.fsum(a['cash'] for a in accounts), unallocated_cash=run['cash'],
        volatility_days=run['case'].get('volatility_days', 365))
    return accounts, positions, audit


def attach_source_events(store, run):
    """Trades observed between snapshots are evidence, not a claimed 1:1 trigger.

    Initial inventory and scheduled resets must not relabel old trades as new.
    """
    for decision in run.get('_copy_decisions', []):
        if decision['kind'] != 'source_change' or not decision.get('previous_observed_at'):
            continue
        rows = store.rows('''SELECT id,wallet,observed_at,event_at,body FROM source_events
            WHERE wallet=? AND observed_at>? AND observed_at<=? ORDER BY event_at''',
            (decision['wallet'], decision['previous_observed_at'], decision['observed_at']))
        decision['source_events'] = [dict(json.loads(r['body']),
            **{k: v for k, v in r.items() if k != 'body'}) for r in rows]
    from limit_orders import attach_rules
    attach_rules(run)


def copy_activity(store, run):
    rows = store.rows('SELECT body FROM copy_decisions WHERE run=? ORDER BY ts DESC LIMIT 100', (run['id'],))
    decisions = [json.loads(r['body']) for r in rows]
    if not decisions:
        return []
    # Query by indexed run/time, then join using the persisted decision ID.
    orders = store.rows('SELECT * FROM execution_orders WHERE run=? AND created>=? ORDER BY created',
                       (run['id'], min(d['ts'] for d in decisions)))
    by_id = {d['id']: [] for d in decisions}
    for row in orders:
        body = json.loads(row['body'])
        decision_id = body['intent'].get('source_change_id')
        if decision_id in by_id:
            by_id[decision_id].append(dict(body, **{k: v for k, v in row.items() if k != 'body'}))
    targets = run.get('execution_plan', {}).get('targets', {})
    for d in decisions:
        d['orders'] = by_id[d['id']]
        fills = [o for o in d['orders'] if o.get('result', {}).get('shares', 0) > 0
                 and o['state'] in ('applied','limit_open','limit_partial','limit_filled','limit_cancelled')]
        d['filled_notional'] = math.fsum(o['result']['notional'] for o in fills)
        d['filled_orders'] = len(fills)
        applied = {}
        for o in fills:
            i = o['intent']
            key = (i['token'], i['side'])
            applied[key] = applied.get(key, 0) + o['result']['shares']
        complete = all(applied.get((a['token'], a['side']), 0) >= a['shares'] - .011 for a in d['adjustments'])
        current = targets.get(d['wallet'], {}).get('source_change_id') == d['id']
        pending = any(o['state'] in ('posting','unknown','submitted','limit_open','limit_partial','limit_cancel_requested') for o in d['orders'])
        if not d['adjustments']:
            status = 'No adjustment needed'
        elif pending:
            status = ('Partly copied; remainder pending' if fills else 'Limit orders pending') if any(o['intent'].get('execution_policy') for o in d['orders']) else 'Awaiting confirmation'
        elif complete:
            status = 'Copied'
        elif not current:
            status = 'Partly copied; superseded' if fills else 'Superseded before fill'
        else:
            status = 'Partly copied; remainder pending' if fills else 'Pending execution'
        d['status'] = status
    return decisions
