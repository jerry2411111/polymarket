"""Resumable live discovery, cheap prefilters, then the existing return model.

The app writes its own databases. Historical backtest outputs stay read-only.
Discovery walks market trade feeds, not a leaderboard or a top-wallet shortlist.
"""
from __future__ import annotations

import bisect
import collections
import concurrent.futures
import hashlib
import json
import math
import sqlite3
import sys
import threading
import time
import zlib
from array import array
from pathlib import Path

from core import DATA, DAY, HISTORY, ROOT, Database, inverse_weights, utc
from api import PublicAPI
from history_inputs import ArchiveInputs

sys.path.insert(0, str(ROOT))
import rolling_copy_backtest as original
from expand_macro_universe import TAGS, classify, NON_MACRO
import macro_account_model as model_module


def readonly(path):
    return sqlite3.connect('file:' + Path(path).as_posix() + '?mode=ro', uri=True, factory=Database)


def macro_activity(rows, marks, at):
    """Apply the same macro scope to cached and newly downloaded activity."""
    return [r for r in rows if int(r['timestamp']) < at and
            (r.get('condition_id') in marks.by_condition or
             (r.get('type') == 'CONVERSION' and r.get('event_slug') in marks.event_slugs))]


class Catalog:
    def __init__(self):
        self.path = DATA / 'catalog.json'
        source = self.path if self.path.exists() else HISTORY / 'macro_markets_for_returns.json'
        markets = json.loads(source.read_text(encoding='utf-8'))
        self.markets = {m['conditionId']: m for m in markets}
        self.token_condition = {token: c for c in self.markets for token in self.tokens(c)}
        self.event_slugs = {e.get('slug') for m in markets for e in m.get('events', []) if e.get('slug')}
        self.lock = threading.RLock()
        self.rejected = set()

    def tokens(self, condition):
        value = self.markets[condition].get('clobTokenIds') or []
        return json.loads(value) if isinstance(value, str) else value

    def has(self, condition):
        with self.lock:
            return condition in self.markets

    def refresh(self, api, at, progress):
        # Preserve all previously discovered markets; collect new/recent events
        # in the same subject categories, including recently closed markets.
        for number, tag in enumerate(TAGS, 1):
            cursor = None
            seen = set()
            while True:
                params = dict(tag_id=tag, related_tags='true', limit=100, order='id', ascending='true',
                              end_date_min=utc(at - 365 * DAY))
                if cursor:
                    params['after_cursor'] = cursor
                payload = api.get('/events/keyset', params, gamma=True)
                events = payload.get('events')
                if not isinstance(events, list):
                    raise ValueError('Market catalog response was incomplete.')
                with self.lock:
                    for event in events:
                        for m in event.get('markets', []):
                            condition = m.get('conditionId')
                            if not condition or not m.get('clobTokenIds') or not classify(m, event, tag):
                                continue
                            self.markets[condition] = {k: m.get(k) for k in
                                ('conditionId', 'clobTokenIds', 'outcomes', 'question', 'createdAt', 'closed')}
                            self.markets[condition]['events'] = [{'slug': event.get('slug')}]
                            if event.get('slug'):
                                self.event_slugs.add(event['slug'])
                            self.token_condition.update({token: condition for token in self.tokens(condition)})
                progress('Discovering macro/geopolitical markets', category=TAGS[tag],
                         categories_done=number - 1, markets=len(self.markets))
                cursor = payload.get('next_cursor')
                if not cursor:
                    break
                if cursor in seen:
                    raise ValueError('Market catalog repeated a page.')
                seen.add(cursor)
        temporary = self.path.with_suffix('.tmp')
        temporary.write_text(json.dumps(list(self.markets.values())), encoding='utf-8')
        temporary.replace(self.path)

    def relevant_positions(self, rows, api):
        result = []
        by_condition = {p['condition_id']: p for p in rows}
        # Apply the existing explicit non-macro subject rule directly to the
        # public position title. Old crypto markets may no longer be in Gamma.
        with self.lock:
            self.rejected.update(c for c,p in by_condition.items() if c not in self.markets and NON_MACRO.search(p.get('title','')))
        unknown = sorted({p['condition_id'] for p in rows if not self.has(p['condition_id']) and p['condition_id'] not in self.rejected})
        for i in range(0, len(unknown), 50):
            group = unknown[i:i+50]
            # Gamma accepts repeated condition_ids. Classify a batch at once so
            # an account with hundreds of sports holdings does not delay its
            # macro book by one network round trip per non-macro market.
            markets = api.get('/markets', {'condition_ids': group, 'limit':100}, gamma=True)
            if not isinstance(markets, list):
                raise ValueError('Market classification response is incomplete.')
            returned = {m.get('conditionId') for m in markets}
            missing = set(group)-returned
            for condition in missing:
                # Gamma omits some archived markets which still appear in the
                # public positions feed. That feed supplies the original market
                # question, event slug and both outcome token IDs. Classify those
                # actual descriptors with the existing subject rule, not an empty
                # Gamma response. Missing descriptions remain an explicit issue.
                p = by_condition[condition]
                if not p.get('title'):
                    raise ValueError('Subject metadata unavailable for a source position: ' + condition)
                event = dict(title=(p.get('event_slug') or '').replace('-', ' '), slug=p.get('event_slug'))
                market = dict(conditionId=condition, question=p['title'], events=[event],
                              metadata_source='Public position title and event slug; archived Gamma metadata unavailable')
                if not NON_MACRO.search(event['title']) and classify(market, event, 0):
                    token, opposite = p.get('token_id'), p.get('opposite_token_id')
                    if not token or not opposite or p.get('outcome_index') not in (0,1):
                        raise ValueError('Outcome identifiers unavailable for macro position: ' + condition)
                    pair = [token, opposite] if p['outcome_index']==0 else [opposite, token]
                    market['clobTokenIds'] = pair
                    with self.lock:
                        self.markets[condition] = market
                        self.token_condition.update({t:condition for t in pair})
            for m in markets:
                condition = m.get('conditionId')
                if condition in group:
                    for e in m.get('events', []):
                        if classify(m, e, 0):
                            with self.lock:
                                self.markets[condition] = m
                                self.token_condition.update({token: condition for token in self.tokens(condition)})
            with self.lock:
                self.rejected.update(c for c in group if c not in self.markets)
        for p in rows:
            condition = p['condition_id']
            if self.has(condition) and float(p.get('current_size', 0)) > 0:
                result.append(p)
        return result


class LiveMarks:
    """Actual observations with availability times; no 24-hour price cutoff."""
    def __init__(self, catalog, api, at):
        self.api, self.at = api, at
        # Source monitoring can discover additional markets concurrently. Keep
        # metadata and token maps from the same frozen screening catalog.
        with catalog.lock:
            self.by_condition = dict(catalog.markets)
        self.condition_tokens = {c: json.loads(m.get('clobTokenIds') or '[]')
                                 if isinstance(m.get('clobTokenIds'), str) else m['clobTokenIds']
                                 for c, m in self.by_condition.items()}
        self.token_condition = {t: c for c, ts in self.condition_tokens.items() for t in ts}
        self.event_slugs = {e.get('slug') for m in self.by_condition.values() for e in m.get('events', [])}
        self.series = {}
        self.resolved = {}
        self.checked_resolutions = set()
        self.cache = DATA / 'historical_prices'
        self.cache.mkdir(exist_ok=True)
        self.archive_end = ArchiveInputs(catalog).end
        self.locks = [threading.RLock() for _ in range(128)]
        self.resolution_lock = threading.Lock()
        self.resolution_pending = {}
        self.early_lock = threading.RLock()
        self.early_loaded = set()
        with readonly(HISTORY / 'market_prices.sqlite') as db:
            for condition, body in db.execute('SELECT condition,body FROM resolutions'):
                r = json.loads(body)
                if not r or r.get('status') != 'resolved':
                    continue
                when = r.get('resolved_at') or r.get('last_update_timestamp')
                if not when:
                    continue
                ts = int(when) if str(when).isdigit() else original.stamp(when)
                payouts = r.get('payouts')
                if payouts is not None:
                    values = [float(x) / 1_000_000 for x in payouts]
                elif r.get('price') is not None:
                    yes = float(r['price'])
                    if yes > 1:
                        yes /= 1e18
                    values = [yes, 1 - yes]
                else:
                    continue
                for token, price in zip(self.condition_tokens.get(condition, []), values):
                    if 0 <= price <= 1:
                        self.resolved[token] = (ts, price)

    def load(self, token):
        with self.locks[hash(token) % len(self.locks)]:
            return self._load(token)

    def _load(self, token):
        if token in self.series:
            return self.series[token]
        path = self.cache / (token + '.json.zlib')
        saved = json.loads(zlib.decompress(path.read_bytes())) if path.exists() else {}
        if not saved:
            with readonly(HISTORY / 'market_prices.sqlite') as db:
                hit = db.execute('SELECT body FROM prices WHERE token=?', (token,)).fetchone()
            if hit:
                saved = dict(through=self.archive_end, points=json.loads(zlib.decompress(hit[0])))
        if saved.get('through', 0) < self.at:
            points = dict(saved.get('points', []))
            resolved = self.resolved.get(token)
            # A finalized market cannot need new post-resolution marks.
            if not resolved or resolved[0] >= saved.get('through', 0):
                query = dict(token_id=token, bucket_seconds=10800, limit=10000)
                if saved.get('through'):
                    query.update(start=max(1, saved['through'] - 10800), end=self.at)
                else:
                    query['interval'] = 'max'
                for page in self.api.pages('/v2/prices-history', query):
                    for row in page:
                        ts = int(row['timestamp']) + int(row.get('resolution_seconds', 0))
                        price = float(row['price'])
                        if ts < self.at and math.isfinite(price) and 0 <= price <= 1:
                            points[ts] = price
            saved = dict(through=self.at, points=sorted(points.items()))
            path.write_bytes(zlib.compress(json.dumps(saved).encode()))
        points = dict(saved['points'])
        points = sorted((int(t), p) for t, p in points.items() if int(t) < self.at and math.isfinite(p) and 0 <= p <= 1)
        self.series[token] = (array('q', (p[0] for p in points)), array('d', (p[1] for p in points)))
        return self.series[token]

    def prepare_resolutions(self, conditions):
        # Batch resolution requests instead of one request for every token.
        with self.resolution_lock:
            unknown = sorted(set(conditions) - self.checked_resolutions)
            owned = [c for c in unknown if c not in self.resolution_pending]
            wait_for = [self.resolution_pending[c] for c in unknown if c in self.resolution_pending]
            for c in owned:
                self.resolution_pending[c] = threading.Event()
        try:
            pending = [c for c in owned if not any(t in self.resolved for t in self.condition_tokens[c])]
            for c, current in self.api.settlements(pending, self.at - 1).items():
                for t, payout in zip(self.condition_tokens[c], current['payouts']):
                    self.resolved[t] = (current['timestamp'], payout)
            with self.resolution_lock:
                self.checked_resolutions.update(owned)
        finally:
            with self.resolution_lock:
                for c in owned:
                    self.resolution_pending.pop(c).set()
        for event in wait_for:
            while not event.wait(.2):
                if self.api.cancel.is_set():
                    raise InterruptedError()
        # A different worker may have had a transient data failure.
        if set(conditions) - self.checked_resolutions:
            self.prepare_resolutions(conditions)

    def mark(self, token, at, last_trade=None):
        condition = self.token_condition[token]
        if condition not in self.checked_resolutions:
            self.prepare_resolutions([condition])
        resolved = self.resolved.get(token)
        if resolved and resolved[0] <= at:
            return resolved[1]
        times, values = self.load(token)
        i = bisect.bisect_right(times, at) - 1
        if last_trade and last_trade[0] <= at and (i < 0 or last_trade[0] > times[i]):
            return last_trade[1]
        if i >= 0:
            return values[i]
        # Match the research model's fallback ordering: observed source trades
        # and price history first; archived earlier market trades only if needed.
        if condition not in self.early_loaded:
            with self.early_lock:
                if condition not in self.early_loaded:
                    self.early_loaded.add(condition)
                    path = HISTORY / 'early_market_quotes' / (condition + '.json.zlib')
                    if path.exists():
                        for t, pairs in json.loads(zlib.decompress(path.read_bytes())).items():
                            old_times, old_values = self.load(t)
                            merged = dict(pairs)
                            merged.update(zip(old_times, old_values))
                            points = sorted((int(ts), p) for ts, p in merged.items()
                                            if int(ts) < self.at and math.isfinite(p) and 0 <= p <= 1)
                            self.series[t] = (array('q', (p[0] for p in points)), array('d', (p[1] for p in points)))
            return self.mark(token, at, last_trade)
        raise original.DataError('No observed price before ' + utc(at))


class Scanner:
    def __init__(self, store, catalog):
        self.store, self.catalog = store, catalog
        self.cancel = threading.Event()
        self.thread = None
        self.path = DATA / 'screening.sqlite'
        self.api = PublicAPI(self.cancel, requests_per_second=16)
        self.archived = ArchiveInputs(catalog)
        self.status_lock = threading.Lock()
        self.progress_last = 0.
        with sqlite3.connect(self.path, factory=Database) as db:
            db.executescript('''PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS checkpoints(at INTEGER,batch TEXT,cursor TEXT,done INTEGER,
                    PRIMARY KEY(at,batch));
                CREATE TABLE IF NOT EXISTS activity(at INTEGER,wallet TEXT,ts INTEGER,token TEXT,side TEXT,tx TEXT,
                    PRIMARY KEY(at,wallet,ts,token,side,tx)) WITHOUT ROWID;
                CREATE TABLE IF NOT EXISTS seen_wallets(at INTEGER,wallet TEXT,PRIMARY KEY(at,wallet)) WITHOUT ROWID;
                CREATE TABLE IF NOT EXISTS accounts(at INTEGER,wallet TEXT,status TEXT,body TEXT,
                    PRIMARY KEY(at,wallet));
            ''')
        state = self.store.get('screen_progress', {})
        if state.get('running'):
            state.update(running=False, stage='Screening interrupted; resume to continue saved pages')
            self.store.put('screen_progress', state)
        # Public on-chain receipts are only an inventory-reconciliation fallback.
        # Reuse the archive read-only; new receipts belong to the paper app cache.
        import polymarket_receipts as receipts
        if not getattr(receipts, '_paper_cache_installed', False):
            archived_receipt = HISTORY / 'polymarket_receipts'
            previous_receipt = receipts.receipt
            receipt_locks = [threading.Lock() for _ in range(128)]
            def local_receipt(tx):
                with receipt_locks[hash(tx) % len(receipt_locks)]:
                    path = archived_receipt / (tx + '.json')
                    return json.loads(path.read_text()) if path.exists() else previous_receipt(tx)
            receipts.OUT = DATA
            receipts.receipt = local_receipt
            receipts._paper_cache_installed = True

    def progress(self, stage, **kwargs):
        with self.status_lock:
            state = self.store.get('screen_progress', {})
            state.update(stage=stage, updated_at=int(time.time()), api_requests=self.api.calls, **kwargs)
            self.store.put('screen_progress', state)

    def start(self, case, resume=True):
        if self.thread and self.thread.is_alive():
            raise ValueError('Screening is already running.')
        now = int(time.time()) // DAY * DAY
        previous = self.store.get('screen_progress', {})
        at = previous.get('as_of', now) if resume and previous.get('case_id') == case['case_id'] and not previous.get('complete') else now
        # A stopped scan can resume within the same UTC day. Older snapshots remain
        # in the audit database; a new live reset needs a new point-in-time snapshot.
        if at != now:
            at = now
        self.cancel.clear()
        self.store.put('screen_progress', dict(running=True, complete=False, as_of=at,
            case_id=case['case_id'], stage='Starting live discovery', started_at=int(time.time()),
            markets=len(self.catalog.markets), accounts_seen=0, candidates=0, checked=0, selected=0,
            scope='All participants found in macro/geopolitical market feeds during the preceding 40 days.'))
        self.thread = threading.Thread(target=self._run, args=(case, at), daemon=True, name='live-screen')
        self.thread.start()

    def stop(self):
        self.cancel.set()
        self.progress('Stopping after active requests; saved pages will resume', paused_by_user=True)

    def _run(self, case, at):
        try:
            self.run(case, at)
        except InterruptedError:
            self.progress('Screening paused', running=False)
        except Exception as exc:
            self.progress('Screening will retry after a data error', running=False, error=str(exc), retry_after=int(time.time()) + 60)
            self.store.log('Live screening: ' + str(exc), 'error')

    def discover(self, at):
        scope_path = DATA / ('market_scope_' + str(at) + '.json')
        with sqlite3.connect(self.path, factory=Database) as db:
            has_checkpoint = db.execute('SELECT 1 FROM checkpoints WHERE at=? LIMIT 1', (at,)).fetchone()
        # Freeze batches for one point-in-time screen. A new market appearing
        # during a restart must not reshuffle every opaque pagination cursor.
        if not scope_path.exists() and not has_checkpoint:
            self.catalog.refresh(self.api, at, self.progress)
        resolved = set()
        with readonly(HISTORY / 'market_prices.sqlite') as db:
            for condition, body in db.execute('SELECT condition,body FROM resolutions'):
                r = json.loads(body)
                when = (r.get('resolved_at') or r.get('last_update_timestamp')) if r else None
                if r and r.get('status') == 'resolved' and when:
                    ts = int(when) if str(when).isdigit() else original.stamp(when)
                    if ts < at - 40 * DAY:
                        resolved.add(condition)
        if scope_path.exists():
            conditions = json.loads(scope_path.read_text(encoding='utf-8'))
        else:
            conditions = sorted(set(self.catalog.markets) - resolved)
            temporary = scope_path.with_suffix('.tmp')
            temporary.write_text(json.dumps(conditions), encoding='utf-8')
            temporary.replace(scope_path)
        # Reuse the overlap of a completed discovery window. Newly discovered
        # markets still get all 40 days; old markets need only the missing days.
        # Freeze these windows with the cursors so restarts cannot skip a page.
        windows_path = DATA / ('discovery_windows_' + str(at) + '.json')
        if windows_path.exists():
            windows = json.loads(windows_path.read_text(encoding='utf-8'))
        else:
            windows = [dict(start=at - 40 * DAY, conditions=conditions)]
            if not has_checkpoint:
                with sqlite3.connect(self.path, timeout=60, factory=Database) as db:
                    prior_dates = [r[0] for r in db.execute('''SELECT at FROM checkpoints
                        WHERE at<? AND at>? GROUP BY at HAVING min(done)=1 ORDER BY at DESC''',
                        (at, at - 40 * DAY))]
                    for previous in prior_dates:
                        prior_scope = DATA / ('market_scope_' + str(previous) + '.json')
                        if not prior_scope.exists():
                            continue
                        old = set(json.loads(prior_scope.read_text(encoding='utf-8')))
                        finished = db.execute('SELECT count(*) FROM checkpoints WHERE at=? AND done=1', (previous,)).fetchone()[0]
                        prior_windows = DATA / ('discovery_windows_' + str(previous) + '.json')
                        expected = sum(math.ceil(len(w['conditions']) / 20) for w in json.loads(prior_windows.read_text())) if prior_windows.exists() else math.ceil(len(old) / 20)
                        if finished != expected:
                            continue
                        db.execute('''INSERT OR IGNORE INTO activity
                            SELECT ?,wallet,ts,token,side,tx FROM activity WHERE at=? AND ts>=? AND ts<?''',
                            (at, previous, at - 40 * DAY, previous))
                        db.execute('INSERT OR IGNORE INTO seen_wallets SELECT DISTINCT at,wallet FROM activity WHERE at=?', (at,))
                        windows = [dict(start=previous, conditions=[c for c in conditions if c in old]),
                                   dict(start=at - 40 * DAY, conditions=[c for c in conditions if c not in old])]
                        self.progress('Updating discovery with new trading days and new markets', reused_until=previous)
                        break
            temporary = windows_path.with_suffix('.tmp')
            temporary.write_text(json.dumps(windows), encoding='utf-8')
            temporary.replace(windows_path)
        groups = [(w['conditions'][i:i + 20], w['start']) for w in windows for i in range(0, len(w['conditions']), 20)]
        self.progress('Collecting recent macro/geopolitical participants', markets=len(self.catalog.markets),
                      markets_to_scan=len(conditions), market_batches=len(groups), market_batches_done=0)
        write_lock = threading.Lock()
        completed = 0
        markets_completed = 0
        with sqlite3.connect(self.path, factory=Database) as db:
            # Migration/resume: rebuild only when upgrading an older app checkpoint.
            if not db.execute('SELECT 1 FROM seen_wallets WHERE at=? LIMIT 1', (at,)).fetchone():
                db.execute('INSERT OR IGNORE INTO seen_wallets SELECT DISTINCT at,wallet FROM activity WHERE at=?', (at,))

        def group_job(job):
            nonlocal completed, markets_completed
            group, start = job
            batch = hashlib.sha256(','.join(group).encode()).hexdigest()
            with sqlite3.connect(self.path, timeout=60, factory=Database) as db:
                saved = db.execute('SELECT cursor,done FROM checkpoints WHERE at=? AND batch=?', (at, batch)).fetchone()
                if saved and saved[1]:
                    with write_lock:
                        completed += 1
                        markets_completed += len(group)
                    return
                params = dict(condition=','.join(group), start=start, end=at - 1, limit=1000,
                              taker_only='false')
                if saved and saved[0]:
                    params['cursor'] = saved[0]
                cursors = set()
                previous_tail = None
                while True:
                    payload = self.api.get('/v2/trades', params)
                    if not isinstance(payload.get('data'), list):
                        raise ValueError('Invalid trade discovery response.')
                    cursor = payload.get('pagination', {}).get('next_cursor')
                    if not cursor and payload.get('pagination', {}).get('has_more'):
                        raise ValueError('Trade discovery omitted its continuation cursor.')
                    timestamps = [int(r['timestamp']) for r in payload['data']]
                    if timestamps != sorted(timestamps, reverse=True) or (timestamps and previous_tail is not None and timestamps[0] > previous_tail):
                        raise ValueError('Market trades are not newest-first; cannot safely stop at the cached history boundary.')
                    if timestamps:
                        previous_tail = timestamps[-1]
                        # Market-shaped /v2/trades ignores start/end. Its keyset
                        # feed is newest-first: stop only after crossing the
                        # required boundary, including all ties at that time.
                        if timestamps[-1] < start:
                            cursor = None
                    rows = [(at, r['proxy_wallet'].lower(), int(r['timestamp']), r['token_id'], r['side'], r['transaction_hash'])
                            for r in payload['data'] if at - 40 * DAY <= int(r['timestamp']) < at
                            and r['condition_id'] in group and r['side'] in ('BUY', 'SELL')]
                    # Rows and continuation cursor commit together; restart cannot
                    # double-count fills or silently skip an unfinished page.
                    with write_lock:
                        db.executemany('INSERT OR IGNORE INTO activity VALUES(?,?,?,?,?,?)', rows)
                        db.executemany('INSERT OR IGNORE INTO seen_wallets VALUES(?,?)', {(at, r[1]) for r in rows})
                        db.execute('INSERT OR REPLACE INTO checkpoints VALUES(?,?,?,?)', (at, batch, cursor, int(not cursor)))
                        db.commit()
                        if time.monotonic() - self.progress_last > 5:
                            count = db.execute('SELECT count(*) FROM seen_wallets WHERE at=?', (at,)).fetchone()[0]
                            self.progress('Collecting recent macro/geopolitical participants', accounts_seen=count,
                                          market_batches_done=completed, markets_completed=markets_completed,
                                          markets_remaining=len(conditions) - markets_completed)
                            self.progress_last = time.monotonic()
                    if not cursor:
                        break
                    if cursor in cursors:
                        raise ValueError('Discovery repeated a continuation cursor.')
                    cursors.add(cursor)
                    params['cursor'] = cursor
            with write_lock:
                completed += 1
                markets_completed += len(group)

        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            # Bounded queue lets pause finish promptly instead of scheduling 2,500 jobs.
            pending = set()
            iterator = iter(groups)
            exhausted = False
            while pending or not exhausted:
                if self.cancel.is_set():
                    raise InterruptedError()
                while len(pending) < 6 and not exhausted:
                    group = next(iterator, None)
                    if group is None:
                        exhausted = True
                    else:
                        pending.add(pool.submit(group_job, group))
                done, pending = concurrent.futures.wait(pending, timeout=1,
                    return_when=concurrent.futures.FIRST_COMPLETED)
                for future in done:
                    future.result()
        with sqlite3.connect(self.path, factory=Database) as db:
            candidates = [r[0] for r in db.execute('''SELECT wallet FROM activity WHERE at=? GROUP BY wallet
                HAVING count(DISTINCT CAST(ts/86400 AS INTEGER))>=30 ORDER BY wallet''', (at,))]
            seen = db.execute('SELECT count(*) FROM seen_wallets WHERE at=?', (at,)).fetchone()[0]
        self.progress('Activity filter complete; checking annual frequency before portfolios',
                      accounts_seen=seen, candidates=len(candidates), market_batches_done=completed,
                      markets_completed=len(conditions), markets_remaining=0)
        return candidates

    def frequency_rejection(self, wallet, at, marks):
        """A verified trade-count floor can prove the existing 50/day failure."""
        with readonly(self.path) as db:
            recent, active = db.execute('''SELECT count(*),count(DISTINCT CAST(ts/86400 AS INTEGER))
                FROM activity WHERE at=? AND wallet=? AND ts>=? AND ts<?''',
                (at, wallet, at - 40 * DAY, at)).fetchone()
        observed = recent
        archive = HISTORY / 'expanded_market_trades.sqlite'
        if observed < 50 * 365 and archive.exists():
            # Disjoint windows prevent double-counting the recent discovery.
            # Missing archive coverage only makes this a smaller lower bound.
            right = min(self.archived.end, at - 40 * DAY)
            with readonly(archive) as db:
                older = db.execute('''SELECT condition,count(*) FROM trades
                    WHERE wallet=? AND ts>=? AND ts<? GROUP BY condition''',
                    (wallet, at - 365 * DAY, right)).fetchall()
            observed += sum(n for condition, n in older if condition in marks.by_condition)
        if observed >= 50 * 365:
            return dict(wallet=wallet, name=wallet, status='activity_rejected',
                active_days_last_40=active, observed_annual_trade_count_lower_bound=observed,
                average_trades_per_day_lower_bound=observed / 365,
                reasons=['Observed macro trades already prove average at least 50 per day'])
        return None

    def refresh_markets(self, wallet, at, conditions):
        """Replace incomplete cached markets with their actual public history."""
        path = DATA / 'account_activity' / (wallet + '.json.zlib')
        saved = json.loads(zlib.decompress(path.read_bytes()))
        repaired = saved.get('refreshed_markets', {})
        conditions = sorted(c for c in conditions if repaired.get(c, 0) < at)
        if not conditions:
            return False
        replacement = []
        for i in range(0, len(conditions), 20):
            group = conditions[i:i + 20]
            for page in self.api.pages('/v2/activity', dict(user=wallet, condition=','.join(group),
                    start=1, end=at - 1, sort_direction='ASC',
                    exclude_deposits_withdrawals='true', limit=1000)):
                replacement.extend(r for r in page if r.get('condition_id') in group
                                   and int(r['timestamp']) < at)
        # Replace whole market histories, not just append potentially duplicated
        # fills. Commit only after all pages have arrived successfully.
        scope = set(conditions)
        saved['rows'] = [r for r in saved['rows'] if r.get('condition_id') not in scope] + replacement
        saved['refreshed_markets'] = dict(repaired, **{c: at for c in conditions})
        temporary = path.with_suffix('.tmp')
        temporary.write_bytes(zlib.compress(json.dumps(saved).encode()))
        temporary.replace(path)
        return True

    def account(self, wallet, at, marks, refreshed=False):
        # Full observable activity supplies opening shares, not an invented cash
        # balance. Store it so another screen only needs incremental activity.
        directory = DATA / 'account_activity'
        directory.mkdir(exist_ok=True)
        path = directory / (wallet + '.json.zlib')
        if not path.exists():
            rejected = self.frequency_rejection(wallet, at, marks)
            if rejected:
                return rejected
        saved = json.loads(zlib.decompress(path.read_bytes())) if path.exists() else None
        if saved is None:
            saved = self.archived.activity(wallet)
            if saved and self.archived.additional_old:
                # Newly classified older markets were outside the archive's scope.
                # Fetch them too; reusing the archive cannot silently omit them.
                for i in range(0, len(self.archived.additional_old), 20):
                    group = self.archived.additional_old[i:i + 20]
                    for page in self.api.pages('/v2/activity', dict(user=wallet, condition=','.join(group),
                            start=1, end=saved['through'] - 1, sort_direction='ASC',
                            exclude_deposits_withdrawals='true', limit=1000)):
                        saved['rows'].extend(r for r in page if r.get('condition_id') in group)
            saved = saved or {'through': 1, 'rows': []}
        additions = []
        if saved['through'] < at:
            queries = [dict(user=wallet, start=saved['through'], end=at - 1,
                    sort_direction='ASC', exclude_deposits_withdrawals='true', limit=1000)]
            if saved['through'] >= at - 40 * DAY:
                # The completed recent-market discovery covers this entire
                # append window. Its token IDs identify every macro trade here.
                # Fetch those markets directly instead of unrelated sports and
                # crypto fills; inventory actions are fetched independently.
                with sqlite3.connect(self.path, factory=Database) as db:
                    tokens = [r[0] for r in db.execute('SELECT DISTINCT token FROM activity WHERE at=? AND wallet=? AND ts>=?',
                                                     (at, wallet, saved['through']))]
                conditions = sorted({marks.token_condition[t] for t in tokens if t in marks.token_condition})
                base = queries[0]
                queries = [dict(base, type='SPLIT,MERGE,REDEEM,CONVERSION')]
                queries.extend(dict(base, type='TRADE', condition=','.join(conditions[i:i+20]))
                               for i in range(0, len(conditions), 20))
            for query in queries:
                for page in self.api.pages('/v2/activity', query):
                    additions.extend(r for r in page if int(r['timestamp']) < at and
                        (self.catalog.has(r.get('condition_id')) or
                         (r.get('type') == 'CONVERSION' and r.get('event_slug') in self.catalog.event_slugs)))
        all_activity = saved['rows'] + additions
        saved.update(through=max(at, saved['through']), rows=all_activity)
        temporary = path.with_suffix('.tmp')
        temporary.write_bytes(zlib.compress(json.dumps(saved).encode()))
        temporary.replace(path)
        activity = macro_activity(all_activity, marks, at)
        rows, actions = {}, []
        name = wallet
        for raw in activity:
            e = original.Event.parse(raw)
            name = raw.get('name') or raw.get('pseudonym') or name
            if e.kind == 'TRADE':
                key = (e.wallet, e.ts, e.token, e.side, e.tx)
                r = (wallet, e.ts, e.token, e.side, e.tx, e.condition, e.size, e.price, e.cash,
                     e.title, e.outcome, e.outcome_index)
                if key in rows:
                    old = rows[key]
                    size = old[6] + r[6]
                    r = (*r[:6], size, (old[6] * old[7] + r[6] * r[7]) / size if size else 0,
                         old[8] + r[8], *r[9:])
                rows[key] = r
            elif e.kind in ('REDEEM', 'SPLIT', 'MERGE', 'CONVERSION'):
                actions.append(raw)
        rows = sorted(rows.values(), key=lambda r: r[1])
        if not rows:
            return dict(wallet=wallet, name=name, status='activity_rejected', reasons=['No observed macro trades'])
        active = len({r[1] // DAY for r in rows if at - 40 * DAY <= r[1] < at})
        first = rows[0][1] // DAY * DAY
        average = sum(at - 365 * DAY <= r[1] < at for r in rows) / max(1, (at - max(at - 365 * DAY, first)) / DAY)
        if active < 30 or average >= 50:
            return dict(wallet=wallet, name=name, status='activity_rejected', active_days_last_40=active,
                        average_trades_per_day=average,
                        reasons=['30 active days / 40 or average fewer than 50 macro trades / day'])
        # Expensive reconstruction only after BOTH cheap rules pass.
        marks.prepare_resolutions({r[5] for r in rows} | {r.get('condition_id') for r in actions if r.get('condition_id') in marks.by_condition})
        events = model_module.events_from_rows(rows, actions, marks)
        archive = HISTORY / 'polymarket_transfer_histories' / (wallet + '.json.zlib')
        if archive.exists():
            from polymarket_transfer_history import reconcile_events
            prior = json.loads(zlib.decompress(archive.read_bytes()))
            boundary = prior['end']
            before = [e for e in events if e.ts < boundary and e.condition in self.archived.conditions]
            after = [e for e in events if e.ts >= boundary or e.condition not in self.archived.conditions]
            moves = [m for m in prior['movements'] if m[2] in marks.token_condition]
            events = sorted(reconcile_events(before, wallet, marks, moves) + after,
                            key=lambda e: (e.ts, 0 if e.kind == 'SPLIT' else 1, 0 if e.side == 'BUY' else 1, e.tx, e.token))
        # Reuse the historical model's daily return and style calculations.
        # This is an app-local process; no backtest source or output is modified.
        # Earlier transactions still reconstruct the opening shares and FIFO
        # lots, but only the preceding year needs daily marks (plus a boundary).
        model = model_module.MacroAccount.__new__(model_module.MacroAccount)
        model.wallet, model.name, model.end, model.marks = wallet, name, at, marks
        model.events = events
        model.times = [e.ts for e in events]
        model.values, model.daily, model.closed = {}, {}, []
        model.inventory_issues, model.unpriced_days, model.unpriced_tokens = [], set(), {}
        model._build()
        metric, error = model.metrics(at)
        if error == 'opening_inventory_needs_reconciliation' and not refreshed:
            conditions = {marks.token_condition[x['token']] for x in model.inventory_issues}
            if self.refresh_markets(wallet, at, conditions):
                return self.account(wallet, at, marks, refreshed=True)
        if error:
            # A defined nonzero-variance Sharpe is needed by the existing rule.
            # A genuinely flat daily book isn't an unfinished data collection.
            status = 'statistics_unavailable' if error == 'daily_returns_unavailable_or_zero_variance' else 'data_pending'
            return dict(wallet=wallet, name=name, status=status, reasons=[error])
        return dict(wallet=wallet, name=name, status='computed',
                    refreshed_history_markets=len(saved.get('refreshed_markets', {})), **metric)

    def run(self, case, at, retry_pending=True):
        candidates = self.discover(at)
        self.archived = ArchiveInputs(self.catalog)
        marks = LiveMarks(self.catalog, self.api, at)
        # Identical daily boundaries for every worker. Each account's metrics
        # still start at its own first observed book, capped at 365 preceding days.
        model_module.BACKUP_START = at - 366 * DAY
        selected, counts = [], collections.Counter()
        version = 'scoped_cached_activity_actual_quotes_v4'
        with sqlite3.connect(self.path, timeout=60, factory=Database) as db:
            cached = {w: json.loads(body) for w, body in db.execute('SELECT wallet,body FROM accounts WHERE at=?', (at,))}
            done = 0

            def consume(wallet, record):
                nonlocal done
                record['data_basis_version'] = version
                db.execute('INSERT OR REPLACE INTO accounts VALUES(?,?,?,?)',
                           (at, wallet, record['status'], json.dumps(record, allow_nan=False)))
                db.commit()
                done += 1
                status = record['status']
                counts[status] += 1
                if status == 'computed':
                    value = record[case['screen_metric'] + '_sharpe']
                    sigma = record['volatility_available_history'] if case['volatility_days'] == 365 else record['volatility_windows'].get(str(case['volatility_days']))
                    accepted = (record['qualifies_style_and_activity'] and value > case['lower'] and
                                (case['upper'] is None or value <= case['upper']))
                    if not record['qualifies_style_and_activity']:
                        counts['style_rejected'] += 1
                    elif not accepted:
                        counts['sharpe_rejected'] += 1
                    elif sigma is None or not math.isfinite(sigma) or sigma <= 0:
                        counts['volatility_unavailable'] += 1
                    else:
                        selected.append(dict(record, sigma=sigma))
                self.progress('Screening preceding-year history; reusing the research archive', checked=done,
                              selected=len(selected), counts=dict(counts), current_account=wallet,
                              history_start=at - 365 * DAY, history_end=at, workers=24)

            remaining = []
            for wallet in candidates:
                record = cached.get(wallet)
                if record and record.get('data_basis_version') == version and (record.get('status') != 'data_pending' or not retry_pending):
                    consume(wallet, record)
                else:
                    remaining.append(wallet)

            with concurrent.futures.ThreadPoolExecutor(max_workers=24, thread_name_prefix='account-screen') as pool:
                iterator = iter(remaining)
                pending = {}
                exhausted = False
                while pending or not exhausted:
                    if self.cancel.is_set():
                        raise InterruptedError()
                    while len(pending) < 24 and not exhausted:
                        wallet = next(iterator, None)
                        if wallet is None:
                            exhausted = True
                        else:
                            pending[pool.submit(self.account, wallet, at, marks)] = wallet
                    ready, _ = concurrent.futures.wait(pending, timeout=1,
                        return_when=concurrent.futures.FIRST_COMPLETED)
                    for future in ready:
                        wallet = pending.pop(future)
                        try:
                            record = future.result()
                        except InterruptedError:
                            raise
                        except Exception as exc:
                            record = dict(wallet=wallet, name=wallet, status='data_pending', reasons=[str(exc)])
                        consume(wallet, record)
        snapshot = dict(as_of=at, completed_at=int(time.time()), case_id=case['case_id'],
                        selected=inverse_weights(sorted(selected, key=lambda r:r['wallet'])),
                        counts=dict(counts), candidates=len(candidates),
                        discovery=self.store.get('screen_progress'), complete=True,
                        coverage_complete=not counts['data_pending'],
                        unresolved_accounts=counts['data_pending'])
        # Unknown metrics cannot qualify an account, but they do not veto the
        # measured selection of unrelated accounts. Keep this coverage visible.
        self.store.put('screen_snapshot', snapshot)
        self.store.put('screen_snapshot:' + case['case_id'], snapshot)
        self.progress('Selection ready' if not counts['data_pending'] else 'Selection ready; unresolved accounts reported separately',
                      running=False, complete=True, selected=len(selected), counts=dict(counts),
                      coverage_complete=snapshot['coverage_complete'])
        self.store.log(f"Live screen: {len(selected)} qualifying accounts from preceding-year history; {counts['data_pending']} unresolved accounts.")
