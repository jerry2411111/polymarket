"""Verify allocation dollars and the source -> decision -> order -> fill chain."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from core import Store, inverse_weights
from execution import make_plan, ExecutionRouter
from reporting import portfolio_breakdown, attach_source_events, copy_activity


class ReportingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / 'test.sqlite')
        self.run = self.store.create(dict(reset_days=75, volatility_days=365), 9000)
        self.quote = dict(price=.5, timestamp=100, bids=[(.49, 1e9)], asks=[(.51, 1e9)],
                          bid=.49, ask=.51, min_order_size=.01)
        self.quotes = {t: copy.deepcopy(self.quote) for t in ('iran', 'fed', 'oil')}
        self.router = ExecutionRouter(self.store, SimpleNamespace(book=lambda t, fresh=False: self.quotes[t]))
        self.sources = {w: dict(inventory_key=w, checked_at=100,
            positions=[dict(token_id=t, current_size=100, title=t, outcome='Yes', condition_id=t)])
            for w, t in [('A', 'iran'), ('B', 'fed')]}
        selected = inverse_weights([dict(wallet='A', name='Alice', sigma=.01), dict(wallet='B', name='Bob', sigma=.02)])
        make_plan(self.run, self.sources, self.quotes, selected, 100)
        self.store.save(self.run)
        self.router.execute(self.run)

    def tearDown(self):
        self.temp.cleanup()

    def test_inverse_allocation_dollars_and_actual_holdings(self):
        accounts, positions, audit = portfolio_breakdown(self.store.run())
        accounts = {a['wallet']: a for a in accounts}
        self.assertEqual(audit['status'], 'verified')
        self.assertAlmostEqual(audit['weight_sum'], 1)
        self.assertAlmostEqual(accounts['A']['reset_budget'], 6000)
        self.assertAlmostEqual(accounts['B']['reset_budget'], 3000)
        self.assertAlmostEqual(accounts['A']['invested'], 6000)
        self.assertAlmostEqual(sum(p['portfolio_share'] for p in positions), 1)
        self.assertAlmostEqual(audit['invested'] + audit['attributed_cash'] + audit['unallocated_cash'], 9000)
        self.run['accounts']['A']['weight'] = .5
        self.assertEqual(portfolio_breakdown(self.run)[2]['status'], 'mismatch')

    def test_manual_exclusion_requests_reset_without_changing_nav(self):
        from execution import remove_selected_account
        from core import nav
        other = copy.deepcopy(self.run['accounts']['B'])
        other_target = copy.deepcopy(self.run['execution_plan']['targets']['B'])
        before = nav(self.run)
        remove_selected_account(self.run, 'A')
        self.assertTrue(self.run['accounts']['A']['exiting'])
        self.assertEqual(self.run['execution_plan']['targets']['A']['shares'], {})
        self.assertEqual(self.run['accounts']['B'], other)
        self.assertEqual(self.run['execution_plan']['targets']['B'], other_target)
        self.assertAlmostEqual(nav(self.run), before)
        self.assertTrue(self.run['pending_selection_reset'])
        self.assertIn('A', self.run['excluded_wallets'])
        remove_selected_account(self.run, 'A')
        self.assertEqual(len(self.run['excluded_wallets']), 1)

    def test_excluded_wallet_stays_out_of_later_selections_and_weights_renormalize(self):
        from server import Application
        from execution import remove_selected_account
        self.run['case']['case_id'] = 'test'
        original = [dict(a['metric']) for a in self.run['accounts'].values()]
        remove_selected_account(self.run, 'A')
        app = Application.__new__(Application)
        app.store = self.store
        for at in (100, 100 + 75*86400):
            self.store.put('screen_snapshot:test', dict(case_id='test', as_of=at, complete=True, selected=original))
            snapshot = app.snapshot_for(self.run)
            self.assertEqual([a['wallet'] for a in snapshot['selected']], ['B'])
            self.assertEqual(snapshot['selected'][0]['weight'], 1.)
            self.assertEqual(len(self.store.get('screen_snapshot:test')['selected']), 2)
        make_plan(self.run, self.sources, self.quotes, snapshot['selected'], snapshot['as_of'])
        self.assertNotIn('pending_selection_reset', self.run)
        self.assertEqual(portfolio_breakdown(self.run)[2]['status'], 'verified')

    def test_source_change_only_replans_that_account_and_links_confirmed_fills(self):
        old_b = copy.deepcopy(self.run['execution_plan']['targets']['B'])
        old_attempts = {k:v for k,v in self.run['execution_plan']['attempts'].items() if k.startswith('B:')}
        self.sources['A']['inventory_key'] = 'A-changed'
        self.sources['A']['checked_at'] = 110
        self.sources['A']['positions'] = [dict(token_id='oil', current_size=200, title='Oil', outcome='No', condition_id='oil')]
        with self.store.connect() as db:
            db.execute('INSERT INTO source_events VALUES(?,?,?,?,?)',
                       ('trade-A', 'A', 109, 108, json.dumps(dict(side='BUY', size=200, token_id='oil', title='Oil'))))
            db.execute('INSERT INTO source_events VALUES(?,?,?,?,?)',
                       ('probe-B', 'B', 109, 108, json.dumps(dict(side='BUY', size=10, token_id='fed'))))
        make_plan(self.run, self.sources, self.quotes)
        self.assertEqual(self.run['execution_plan']['targets']['B'], old_b)
        for key, value in old_attempts.items():
            self.assertEqual(self.run['execution_plan']['attempts'][key], value)
        self.assertEqual(len(self.run['_copy_decisions']), 1)
        attach_source_events(self.store, self.run)
        self.store.save(self.run)
        self.assertEqual(copy_activity(self.store, self.run)[0]['status'], 'Pending execution')
        self.quotes['iran'].update(bid=.49,ask=.51,bids=[(.49,1e9)],asks=[(.51,1e9)])
        self.router.execute(self.run)
        d = copy_activity(self.store, self.run)[0]
        self.assertEqual(d['wallet'], 'A')
        self.assertEqual(d['status'], 'Copied')
        self.assertEqual([e['id'] for e in d['source_events']], ['trade-A'])
        self.assertEqual(len(d['orders']), 2)
        fills = self.store.rows('SELECT * FROM fills WHERE source_change_id=?', (d['id'],))
        self.assertEqual({f['order_id'] for f in fills}, {o['id'] for o in d['orders']})
        self.assertEqual({f['side'] for f in fills}, {'BUY', 'SELL'})
        self.assertEqual({f['wallet'] for f in fills}, {'A'})

    def test_absolute_source_size_change_without_weight_change_is_not_a_fill(self):
        self.sources['A']['inventory_key'] = 'A-double'
        self.sources['A']['checked_at'] = 111
        self.sources['A']['positions'][0]['current_size'] = 200
        before = len(self.store.rows('SELECT * FROM fills'))
        make_plan(self.run, self.sources, self.quotes)
        self.store.save(self.run)
        self.router.execute(self.run)
        d = copy_activity(self.store, self.run)[0]
        self.assertEqual(d['status'], 'No adjustment needed')
        self.assertEqual(d['source_changes'][0]['delta_shares'], 100)
        self.assertEqual(len(self.store.rows('SELECT * FROM fills')), before)

    def test_sandbox_sell_is_immediate_and_persists_across_reload(self):
        self.sources['A']['inventory_key'] = 'A-exit'
        self.sources['A']['positions'] = []
        self.sources['A']['checked_at'] = 112
        self.quotes['iran'].update(bid=.49,ask=.51,bids=[(.49,100)],asks=[(.51,1e9)])
        self.quotes['iran']['timestamp'] = 112
        make_plan(self.run, self.sources, self.quotes)
        self.store.save(self.run)
        self.router.execute(self.run)
        restarted = Store(self.store.path)
        d = copy_activity(restarted, restarted.run())[0]
        self.assertEqual(d['status'], 'Copied')
        self.assertEqual(d['filled_notional'], 6000)
        self.assertEqual(d['filled_orders'], 1)
        self.assertEqual(restarted.run()['accounts']['A']['positions'],{})


if __name__ == '__main__':
    unittest.main(verbosity=2)
