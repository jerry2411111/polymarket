$ErrorActionPreference = 'Stop'
$appDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$appUrl = 'http://127.0.0.1:8790'
$alreadyRunning = $false
try {
    $response = Invoke-RestMethod -Uri "$appUrl/api/state" -TimeoutSec 2
    $alreadyRunning = $null -ne $response.run
} catch { }
if (-not $alreadyRunning) {
    $pythonCommand = Get-Command python3.14 -ErrorAction SilentlyContinue
    if (-not $pythonCommand) { $pythonCommand = Get-Command python -ErrorAction Stop }
    $pythonExecutable = (& $pythonCommand.Source -c 'import sys; print(sys.executable)').Trim()
    $serverProcess = Start-Process -FilePath $pythonExecutable -ArgumentList @('server.py', '--port', '8790', '--resume') -WorkingDirectory $appDirectory -WindowStyle Hidden -RedirectStandardOutput "$appDirectory\data\server.log" -RedirectStandardError "$appDirectory\data\server-errors.log" -PassThru
    Set-Content -LiteralPath "$appDirectory\data\server.pid" -Value $serverProcess.Id
    for ($attempt = 0; $attempt -lt 40; $attempt++) {
        Start-Sleep -Milliseconds 500
        try { $response = Invoke-RestMethod -Uri "$appUrl/api/state" -TimeoutSec 2; $alreadyRunning = $true; break } catch { }
    }
}
if ($alreadyRunning) {
    if ($response.run.mode -eq 'sandbox' -and $response.run.status -in @('paused', 'ready')) {
        $null = Invoke-RestMethod -Uri "$appUrl/api/action" -Method Post -ContentType 'application/json' -Headers @{'X-Paper-Token'=$response.csrf} -Body '{"action":"start"}' -TimeoutSec 30
    }
    $edge = Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'
    if (Test-Path -LiteralPath $edge) {
        # The user requested an app window. Keep it separate from normal tabs.
        Start-Process -FilePath $edge -ArgumentList @("--app=$appUrl", "--user-data-dir=`"$appDirectory\data\app-window`"", '--no-first-run')
    } else { Start-Process $appUrl }
} else { throw "The server did not start. See $appDirectory\data\server-errors.log" }
