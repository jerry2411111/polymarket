"""Generate/retrieve Polymarket.com CLOB credentials without connecting a trading client.

Uses the app's pinned official polymarket-client 0.11.0 authentication helpers.
Only POST /auth/api-key and, if the key already exists, GET /auth/derive-api-key
can be requested. No wallet deployment, approvals, orders, or local secret files.
Reference: https://docs.polymarket.com/getting-started/api#authentication
"""
from __future__ import annotations

import argparse
import getpass
import logging
from pathlib import Path
import sys
import time
import warnings

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent / "vendor"))

from eth_account import Account
from polymarket._internal.actions.auth import create_or_derive_api_key_sync
from polymarket._internal.l1_auth import sign_api_key_auth
from polymarket.clients._transport import SyncTransport
from polymarket.errors import RequestRejectedError, UnexpectedResponseError


def read_signer():
    # Refuse getpass's fallback to echoed input when no secure console exists.
    with warnings.catch_warnings():
        warnings.simplefilter("error", getpass.GetPassWarning)
        private_key = getpass.getpass("Paste your signing private key (hidden), then press Enter: ").strip()
    try:
        return Account.from_key(private_key)
    except Exception:
        raise ValueError("Enter a 64-hex-character signing private key, optionally starting with 0x.") from None
    finally:
        del private_key


def generate_credentials(signer, nonce=0):
    if not isinstance(nonce, int) or not 0 <= nonce < 2**256:
        raise ValueError("Nonce must be an unsigned 256-bit integer.")
    signature = sign_api_key_auth(signer, chain_id=137, timestamp=int(time.time()), nonce=nonce)
    clob = SyncTransport(base_url="https://clob.polymarket.com")
    try:
        credentials = create_or_derive_api_key_sync(clob, signature)
        if not all((credentials.key, credentials.secret, credentials.passphrase)):
            raise UnexpectedResponseError("Incomplete CLOB credentials.")
        return credentials
    finally:
        clob.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--nonce", type=int, default=0,
                        help="Credential nonce; leave at 0 unless retrieving a known different set.")
    parser.add_argument("--pause", action="store_true", help="Keep the launcher window open after completion.")
    args = parser.parse_args(argv)
    if not 0 <= args.nonce < 2**256:
        parser.error("--nonce must be an unsigned 256-bit integer")
    logging.disable(logging.CRITICAL)
    print("Polymarket.com CLOB API credentials")
    print("Use the signing key for your existing account. No trading wallet address is needed here.")
    print("The private key stays on this computer; only a signed authentication message is sent.")
    print("Credentials appear in this window only. Do not share this window or its output.\n")
    try:
        signer = read_signer()
        print(f"\nSigner address: {signer.address}")
        print("This is the signing address, which can differ from your Polymarket trading wallet.")
        print(f"Creating or retrieving CLOB credentials for nonce {args.nonce}...")
        credentials = generate_credentials(signer, args.nonce)
        print("\nCopy these values into the matching fields in the app:\n")
        print(f"API key:        {credentials.key}")
        print(f"API secret:     {credentials.secret}")
        print(f"API passphrase: {credentials.passphrase}")
        print("\nUse the same signing private key in the app. Keep the trading wallet address separate.")
        print("No files were saved and no orders were placed. Close this window when finished.")
        return 0
    except (KeyboardInterrupt, EOFError):
        print("\nCanceled.")
        return 1
    except getpass.GetPassWarning:
        print("\nOpen the .cmd launcher or run this script in an interactive PowerShell window.")
        return 1
    except ValueError:
        print("\nInvalid private key. Use your account's signing private key, not a wallet address or API key.")
        return 1
    except RequestRejectedError as exc:
        print(f"\nPolymarket rejected authentication (HTTP {exc.status}).")
        print("Check your signing key and nonce, and synchronize the Windows date/time before retrying.")
        return 1
    except Exception as exc:
        # SDK errors can embed response bodies or field values; never echo them.
        print(f"\nCredential retrieval failed ({type(exc).__name__}). No credentials were displayed.")
        print("Check your network connection. You can rerun with the same key and nonce.")
        return 1
    finally:
        if args.pause:
            try:
                input("\nPress Enter to close this window...")
            except (KeyboardInterrupt, EOFError):
                pass


if __name__ == "__main__":
    raise SystemExit(main())
