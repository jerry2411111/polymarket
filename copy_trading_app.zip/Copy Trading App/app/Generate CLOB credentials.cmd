@echo off
setlocal
set "CLOB_HELPER_PYTHON=%APPDATA%\uv\python\cpython-3.14-windows-x86_64-none\python.exe"
if not exist "%CLOB_HELPER_PYTHON%" (
    echo Python was not found at the app's installed location.
    echo Run generate_clob_credentials.py with your installed Python instead.
    pause
    exit /b 1
)
"%CLOB_HELPER_PYTHON%" -B "%~dp0generate_clob_credentials.py" --pause
exit /b %errorlevel%
