@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Follow README.md to create the Python environment and prepare historical data.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" prepare_project.py --check-ready
if errorlevel 1 (
  pause
  exit /b 1
)
".venv\Scripts\python.exe" "data_storage\runtime\polymarket_mock_app\server.py" --port 8790 --open
if errorlevel 1 pause
