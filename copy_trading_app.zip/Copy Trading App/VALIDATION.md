# Copy Trading App — Validation

Validation performed for the source package on **30 September 2026** uses a separate
temporary installation, not the running app or its data.

## Data-independent checks

- Python source parses successfully without compiling into the project folders.
- Runtime assembly and empty-schema initialization work from a clean directory.
- Local import dependencies were traced recursively. External imports are supplied
  by the official Polymarket SDK, its `eth-account` dependency, `websocket-client`,
  Matplotlib and ReportLab. Dependency resolution succeeded for Python 3.14.
- The offline runner separates **62 data-independent tests** from three historical
  tests. The offline tests exercise allocation, midpoint sandbox accounting,
  actual-fill live reconciliation with fakes, duplicate prevention, restart state,
  per-account cash isolation, screening statistics and credential input handling.
- Historical readiness correctly fails on an empty installation and identifies
  missing research files. No placeholder performance or wallet histories are
  substituted for them.
- Required copied implementation/configuration files are byte-identical to the
  inspected working sources. Runtime assembly restores the original relative
  sibling-module and app/history paths. New code only assembles the runtime,
  initializes empty schemas, orchestrates preparation, or runs checks.
- Markdown links, README coverage, ZIP CRC/integrity and the source/configuration
  file allowlist are checked. Text checks inspect potential key assignments,
  private-key blocks, credential URLs and non-placeholder environment values.
  Public contract/event constants and explicit synthetic test credentials are
  distinguishable from user credentials.

Re-run after installing dependencies and assembling the runtime:

```powershell
& .\.venv\Scripts\python.exe prepare_project.py --syntax
& .\.venv\Scripts\python.exe run_checks.py
```

These checks do not open a wallet or submit real orders. The packaging run uses
the locally installed SDK dependencies for execution tests; dependency resolution
is checked separately. It does not claim a new funded order or a full new-data
simulation was performed.

## Historical-data checks

Full screening, all 292 simulations, PDF generation, account lifetime charts and
complete app startup/replay require actual prepared inputs. They are not executed
as part of source-only validation. Use [data preparation](data_retrieval/README.md)
and [simulation](final_simulation/README.md), then:

```powershell
& .\.venv\Scripts\python.exe prepare_project.py --check-ready
& .\.venv\Scripts\python.exe run_checks.py --with-original-history
```

The last command adds three existing tests that read historical configuration or
replay files. One explicitly asserts the original default ending NAV of
$28,109.358935410015 and therefore requires the original observed dataset for an
exact comparison. Fresh downloads with different coverage may legitimately fail
that fixed-result assertion. Do not edit new results to force it to pass.

## Network and authenticated checks

`check_live_feeds.py` and discovery require access to public Polymarket APIs.
Historical inventory repair may additionally require Polygon RPC archive access.
Real order permissions, wallet balances/approvals, cancellations and exchange fills
need the user's actual credentials and explicit trading authorization in the app.
They are not certified by offline tests or by a successful sandbox run.
