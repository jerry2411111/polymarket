# Archive layout

The root directory is `sports_prediction_app/`, matching the supplied reference ZIP. Every one of its 553 file paths is retained, with current source taking priority over reference code. This release adds the current execution UI, cost accounting, tests, and NHL/soccer collection modules.

```text
sports_prediction_app/
  .env.example
  .gitignore
  README.md
  prepare_storage.ps1
  requirements.txt
  Open Sports App.cmd
  collected data/
    raw/
    result/
  data collecting/
    nhl_soccer_iteration/
    soccer_nhl_granular/
  final_models/
    history/
    mlb/probability_split_test/
    nba/
    reference_market/
    runtime/
    sources/
  reports/
  sports_app/
    models/
    static/
  tests/
  tools/
```

There are 682 collection/reconstruction source files under `data collecting/`. The live automatic collectors are also included under `sports_app/`. Placeholder READMEs retain the data/model/report directories. Acquired datasets, fitted models, virtual environments and private account state are excluded.
