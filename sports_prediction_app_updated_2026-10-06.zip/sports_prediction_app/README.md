# Sports Prediction App

**Command directory: `sports_prediction_app`.** Updated October 6, 2026.

The app combines NBA, MLB, NHL and soccer forecasts, automatic data collection,
and a shared **Polymarket US** execution engine. The prediction dashboard is at
http://127.0.0.1:8766; account and trading controls are at
http://127.0.0.1:8766/trading.

Soccer coverage includes Premier League, La Liga, Bundesliga, Serie A, Ligue 1
and UEFA Champions League, with separate away, home and regulation-draw
probabilities. UEFA Nations League research is not an enabled live route.
An official fixture still needs a verified matching US market before execution.

## Package layout and data

The source ZIP retains the `sports_prediction_app/` layout, including
`data collecting/`, `collected data/raw/`, `collected data/result/`,
`final_models/`, `reports/`, `sports_app/` and `tests/`. It includes 682 historical
collection/reconstruction scripts, the current live collectors, setup helpers,
model code and tests. Placeholder READMEs retain the data directories.

Acquired datasets, fitted model artifacts, virtual environments, API credentials,
account preferences, purchases and execution ledgers are excluded. A fresh source
checkout needs the retained historical/model assets or their reconstruction;
creating empty storage does not prepare forecasts.

Use the [data requirements](<DATA_REQUIREMENTS.md>),
[collection guide](<data collecting/README.md>),
[model recipes](<final_models/README.md>) and
[package layout](<PACKAGE_LAYOUT.md>) for the corresponding paths.

## Install and start

On an already prepared installation, double-click **Open Sports App.cmd**, or run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\sports_app\launch.ps1
```

For a new installation, use Windows and Python 3.14. From the extracted
`sports_prediction_app` directory:

```powershell
py -3.14 -m venv final_models\.venv
& .\final_models\.venv\Scripts\python.exe -m pip install -r requirements.txt -r final_models\requirements.txt
& .\final_models\.venv\Scripts\python.exe -m pip install -r sports_app\requirements-live.txt
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\prepare_storage.ps1
```

The storage helper creates the local directories and the `data` junction to
`collected data`. It does not download history and refuses to replace an unrelated
existing `data` path. Restore or prepare the dated feature tables and model assets
listed in the data requirements before expecting forecasts.

If the NBA estimator configuration has not been restored, create it with:

```powershell
& .\final_models\.venv\Scripts\python.exe -B .\final_models\nba\create_template.py
```

This creates the unfitted recipe and refuses to overwrite an existing template.
It does not supply training data. Then use the launcher above. To run the server
in a visible terminal instead:

```powershell
& .\final_models\.venv\Scripts\python.exe -B .\sports_app\server.py --port 8766
```

Keep the server running for collection and execution; closing the browser does
not stop either. Before intentionally shutting down an enabled instance, use
**STOP NEW TRADING** and wait for the cancellation/reconciliation result. Filled
positions remain held. A foreground server can then be stopped with Ctrl+C.

## Automatic collection and model updates

Collection starts with the app, including when no trading account is connected
and execution is OFF. NBA/MLB completed-game collection feeds dated player/team
history and rolling training. The separate NHL/soccer worker catches up calendars,
completed reports, validated features and selected monthly model preparation.
Missed work is retried after downtime. The collection status endpoint is
`/api/collection/status`.

The main collection entry points are `sports_app/lifecycle.py` for NBA/MLB and
`sports_app/live_worker.py` for NHL/soccer, with their schedule, detail, feature
and model modules. Historical discovery, acquisition, parsing, normalization and
date-query scripts are in `data collecting/`; current NHL/soccer support also
uses `nhl_soccer_iteration/` and `soccer_nhl_granular/` within that folder.
Run historical stages in their documented dependency order.

Sports history remains usable until new results, input revisions or rescheduling
require an update. It does not expire merely because a few minutes passed.
Account state, market books and official event status still need current checks.
Missing historical inputs, unconfirmed lineups, unavailable US markets and source
failures have separate readiness messages. Collection cannot make an unavailable
input or exchange listing immediately available.

NBA retains its rolling logistic model with 27 raw features, ten interactions
and the established T-12h feature cutoff. MLB retains the 53-input daily
logistic/CatBoost ensemble with dated calibration and confirmed official lineups;
its history-only preliminary forecast is labelled separately. NHL/soccer use
their selected monthly sports models, with soccer's separate confidence model.
Training and calibration preserve observation cutoffs, and started-game forecasts
stay frozen.

## Dashboard and account controls

Use sport/league filters, team search and the date window to inspect official
fixtures, forecasts, model readiness and US quotes. **Bought this game** remains
a manual purchase record; it does not send an order. Automatic orders are managed
on the separate execution page.

To start execution on a new installation:

1. Open `/trading`, enter the Polymarket US API key ID and secret, and use
   **Connect & save**. Review the account-check result beside the controls.
2. Select **DRY RUN** or **LIVE**, enter the bot allocation, and confirm it for
   that mode. Each mode retains its own confirmed budget.
3. Edit the sport amounts and the soccer/NHL dollars-per-point values as needed,
   then use **Confirm sport budgets**.
4. Use **Start dry run** for simulated execution. For real orders, use
   **Enable LIVE trading** and the separate on-page confirmation.

Dry run uses live account/book inputs and the same decision rules, with simulated
fills. It does not establish real queue priority, fillability or exchange fees.
The match list explains whether execution is working, holding or waiting.

Sign-in is encrypted with Windows DPAPI for the current Windows user. On restart,
the app restores the saved account, mode and allocation. Previously enabled
execution resumes only after the saved identity and mode match and account,
storage and allocation checks succeed. **Stop** clears the saved execution intent.
**Disconnect** retains the saved sign-in but disables automatic reconnection;
**Forget saved sign-in** removes it. A new source checkout has no account or
enabled trading preference.

Account actions show queued, running, succeeded or failed status. A local
connection interruption retains the last displayed account state and retries.
An uncertain account check delays new orders while verification retries; the
displayed reason identifies the unresolved step.

## Allocation and current sport rules

Confirmed allocation **A** may be up to **10 times account value** for strategy
sizing: an account value of $100 permits an allocation of $1,000. This does not
create extra cash or borrowing capacity; actual orders remain limited by available
cash after reservations and existing commitments.

Automatic starting sport targets are soccer 35%, NHL 30%, NBA 20% and MLB 15%.
The displayed dollar amounts are editable directly, with a confirmation button.
Confirmed custom sport budgets become the limits for new matches and must total
no more than A. Existing match budgets remain locked when allocation changes.

Here `p` is the selected sports-model probability, `ask` is the economic price of
the selected outcome, and `c` is that sport's editable dollars-per-point value
(initially $5 for soccer and NHL).

| Sport | Entry timing | Current qualification | Requested match budget before cash/sport limits |
| --- | --- | --- | --- |
| NBA | From T-3h until start | Selected forecast winner; the current execution rule has no probability-discount filter | 3% of A below $10,000; 2% of A at or above $10,000 |
| MLB | Pregame, as soon as confirmed inputs are ready | Selected winner's ask <= p - 0.05 | 3% of A below $10,000; 2% of A at or above $10,000 |
| Soccer | From T-12h until start | p > 51%, confidence > 55%, selected outcome's YES contract | c × max(100p - 51, 0) |
| NHL | From T-12h until start | p > 60%, ask > $0.50; first two matches per UTC day in each floor((p - ask) / 0.04) band | c × max(100p - 51, 0) |

The NBA T-3h order-entry window is separate from its unchanged T-12h model cutoff.
MLB has no additional fixed 12-hour gate in the execution engine; confirmed-model
readiness still applies. Historical backtest sizing and entry settings are not
the current live execution rules. The current rules are implemented in
`sports_app/trading_rules.py` and `sports_app/trading_engine.py`.

## Limit orders and reconciliation

The engine uses **limit orders (LMT)**. Subject to exchange increments, minimum
size and available cash, it divides remaining locked match dollars between a
midpoint limit and an ask-price limit. Working orders are reviewed on the normal
five-minute refresh cycle, with cancellation confirmed before replacement.
Pregame ordering ends at the scheduled start; filled positions are held through
settlement. Manual or externally managed positions are protected from automatic
changes.

For a NO purchase, the connector converts the Polymarket US complementary-YES
quote convention to the economic NO bid, ask and order price before qualification,
midpoint and sizing calculations. YES-side quotes are not used as NO purchase
prices without this conversion.

An uncertain submission response triggers checks of open orders, recent fills,
position, available balance and relevant market/order state. The engine adopts
a verified existing order, reconciles fills, or recomputes the remaining action.
It does not blindly resubmit an ambiguous attempt or permanently stop solely
because a submission response was uncertain.

## Account values and execution costs

| Field | Meaning |
| --- | --- |
| Estimated portfolio value | Cash and marked positions with complementary/short obligations accounted for; the estimate can differ from another screen's prices or observation time |
| Available cash after reservations | Exchange-reported cash currently available after exchange reservations |
| Confirmed allocation A | The confirmed strategy sizing budget |
| Capital invested | Purchase principal of confirmed app fills on unsettled matches, before fees |
| Fees paid (net rebates) | Verified exchange commissions, keeping rebates negative |
| Spread/slippage (estimate) | Filled purchase principal minus filled quantity times the economic midpoint recorded before each order |
| Execution cost (estimate) | Net fees plus the spread/slippage estimate |
| App unfilled order reserves | Principal reserved for the unfilled remainder of active or unresolved app orders |
| Available bot capital | Uncommitted capacity for new matches, limited by allocation, sport budgets, existing commitments and available cash |
| Manual/external cost basis | Exchange-reported cost basis of positions treated as manual or externally managed; it is separate from app execution expenses |

The account-level app cost totals cover orders on unsettled matches. Invested
principal is separate from execution expenses. Spread/slippage is already embedded
in the purchase price and is **not an additional cash charge**. Negative estimates
can represent price improvement. Missing verified fees or pre-order midpoint
evidence display as unavailable rather than zero.

An unfilled order is a reservation, not a paid execution expense. A canceled
remainder releases its reservation; any earlier partial fill and its actual fees
remain recorded. Locked capital includes the match budget already committed to
filled contracts, working orders and intended future fills.

## Validation

The October 6 application revision passed 147 regression tests plus browser and
live account-reconciliation checks. Packaging also verified the retained folder
layout, source hashes, storage initialization and NBA template reproduction.
These checks do not claim new model backtest results or guarantee future fills.

Run the packaged execution/accounting checks with simulated exchanges:

```powershell
& .\final_models\.venv\Scripts\python.exe -B .\tools\run_execution_checks.py
```

Data-dependent tests and `sports_app/verify_final_models.py` require the retained
official history and model assets. The source archive's `FILE_MANIFEST.json`
records per-file SHA-256 values; the adjacent ZIP checksum verifies the archive.

