import collections,json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
issues=[json.loads(b) for b, in db.execute('SELECT body FROM _mlb_market_matching_audit')]
for reason in sorted({x['reason'] for x in issues}):
    xs=[x for x in issues if x['reason']==reason]
    print(reason,len(xs));print(json.dumps(xs[:8],indent=2))
    if 'labels' in reason:print(collections.Counter(tuple(x['outcomes']) for x in xs).most_common(30))
rows=[json.loads(b) for b, in db.execute('SELECT body FROM _official_mlb_schedule')]
print('OFFICIAL games',len(rows),'by year/type',collections.Counter((x['official_date'][:4],x['game_type_code']) for x in rows))
for t in ['Athletics','Diamondbacks','Royals']:
    print(t,[(x['official_date'],x['raw_game']['teams']['away']['team']) for x in rows if t in x['teams'][0]][:1])
