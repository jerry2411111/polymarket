"""Kalshi minute quotes only inside verified NBA opening and break windows."""
import argparse,collections,concurrent.futures,json,sqlite3
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT
from core import utc
from collect_history import K

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--through-date',default='2026-09-14');ap.add_argument('--limit-games',type=int);args=ap.parse_args()
    db=sqlite3.connect(DB,timeout=60);maps={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_map')};games={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_games')}
    clocks={i:json.loads(b) for i,r,b in db.execute('SELECT game_id,request_id,body FROM _official_nba_clocks')};bygame=collections.defaultdict(list)
    for (body,) in db.execute('SELECT body FROM _history_contracts'):
        m=json.loads(body);old=m['game_id']
        if m['provider']=='kalshi' and old in maps:
            gid=maps[old]['game_id'];bygame[gid].append(m)
    ids=sorted((gid for gid in bygame if games[gid]['date']<=args.through_date and any(s in clocks for s in games[gid]['source_game_ids'])),key=lambda k:(games[k]['date'],k))
    if args.limit_games:ids=ids[:args.limit_games]
    db.execute('CREATE TABLE IF NOT EXISTS _nba_break_acquisition (job_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();c=HistoryClient();cutoff,_=c.get(K+'/historical/cutoff');cut=utc(cutoff['market_settled_ts']);jobs=[]
    for gid in ids:
        clock=next(clocks[s] for s in games[gid]['source_game_ids'] if s in clocks);start=int(utc(clock['official_start_utc']).timestamp());windows=[(0,start+60,start+120)]
        windows.extend((i,int(utc(w['start_utc']).timestamp()),int(utc(w['end_utc']).timestamp())) for i,w in enumerate(clock['breaks'],1) if w['start_utc'] and w['end_utc'])
        for m in bygame[gid]:
            for ordinal,lo,hi in windows:jobs.append((gid,m,ordinal,lo,hi))
    count=collections.Counter();usable=0;new_requests_before=c.requests
    def fetch(job):
        gid,m,n,lo,hi=job;key=f'{m["contract_id"]}:{n}:{lo}:{hi}'
        try:
            archive=utc(m['settled'])<cut;path='/historical/markets/'+m['contract_id']+'/candlesticks' if archive else '/series/'+m['series']+'/markets/'+m['contract_id']+'/candlesticks'
            d,r=c.get(K+path,dict(start_ts=lo-60,end_ts=hi,period_interval=1));suffix='close' if archive else 'close_dollars'
            if d.get('ticker')!=m['contract_id']:raise ValueError('Returned market ticker differs')
            inside=[]
            for x in d['candlesticks']:
                bid=x.get('yes_bid',{}).get(suffix);ask=x.get('yes_ask',{}).get(suffix)
                if bid is not None and not 0<=float(bid)<=1:raise ValueError('Probability scale invalid')
                if bid is not None and ask is not None and float(bid)>float(ask):raise ValueError('Crossed bid/ask source quote')
                if lo<=x['end_period_ts']<hi and bid is not None:inside.append(x)
            out=dict(game_id=gid,provider='kalshi',contract_id=m['contract_id'],checkpoint_ordinal=n,start_utc=utc(lo).isoformat(),end_utc=utc(hi).isoformat(),status='ok',request_id=r['request_id'],returned_rows=len(d['candlesticks']),usable_rows=len(inside))
        except Exception as e:out=dict(game_id=gid,provider='kalshi',contract_id=m['contract_id'],checkpoint_ordinal=n,status='error',error=str(e))
        return key,out
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
        for n,(key,r) in enumerate(pool.map(fetch,jobs),1):
            db.execute('INSERT OR REPLACE INTO _nba_break_acquisition VALUES (?,?)',(key,json.dumps(r)));db.commit();count[r['status']]+=1;usable+=int(r.get('usable_rows',0)>0)
            if n%200==0 or n==len(jobs):print('NBA BREAK QUOTES',n,len(jobs),'windows with quotes',usable,'status',dict(count),flush=True)
    db.close();report=dict(games=len(ids),requested_windows=len(jobs),windows_with_usable_quotes=usable,statuses=dict(count),new_requests=c.requests-new_requests_before,selection='Normalizer keeps only first available quote inside each verified opening/break interval')
    (ROOT/'reports/nba_break_quote_acquisition.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))

if __name__=='__main__':main()
