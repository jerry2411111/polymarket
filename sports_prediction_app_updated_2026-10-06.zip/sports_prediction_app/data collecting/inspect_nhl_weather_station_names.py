import json,re,sqlite3
from collect_history_weather import DOC
from history_client import HistoryClient
from build_history_catalog import DB
c=HistoryClient();b,r=c.get(DOC+'ghcnh-station-list.txt',document=True)
patterns=['COLUMBUS','KENNEDY','JFK','LAS VEGAS','PITTSBURGH','RALEIGH','SAN JOSE','STOCKHOLM','ARLANDA','NEWARK']
for line in b.decode().splitlines():
    if any(p in line.upper() for p in patterns):print(line)
db=sqlite3.connect(DB)
print('NEW NHL SELECTIONS')
for city,year,b in db.execute('SELECT city,year,body FROM _weather_city_stations'):
    r=json.loads(b)
    if r.get('official_city_evidence') and year=='2025':print(city,r['station_directory_row'])
db.close()
