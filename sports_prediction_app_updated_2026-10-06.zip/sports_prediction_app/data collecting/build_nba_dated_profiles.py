"""Daily NBA profiles from past-only facts, with explicit limits on histories."""
import collections,csv,datetime as dt,json,math,sqlite3
import pyarrow as pa
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT

def months(start,end):
    a=dt.date.fromisoformat(start);b=dt.date.fromisoformat(end)
    return (b.year-a.year)*12+b.month-a.month-(b.day<a.day)

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    bio={r['player_id']:dict(r) for r in db.execute('SELECT * FROM _nba_player_bio_constants')}
    for b in bio.values():b['dob']=dt.date.fromisoformat(b['birth_date']) if b['birth_date'] else None;b['seasons']=json.loads(b['regular_seasons']) if b['regular_seasons'] is not None else None
    aff=collections.defaultdict(list)
    for r in db.execute("SELECT * FROM _player_affiliation_observations WHERE league='NBA' AND is_temporary=0 ORDER BY observed_date,observation_id"):
        aff[r['observed_date']].append(dict(r))
    acquisitions={(r['player_id'],r['event_date'],r['team_name']) for r in db.execute("SELECT * FROM _nba_affiliation_events WHERE kind='DATED_OFFICIAL_ACQUISITION'")}
    perf_changes=collections.defaultdict(list)
    for r in db.execute("SELECT * FROM _player_performance_periods WHERE league='NBA'"):perf_changes[r['effective_from']].append(dict(r))
    rosters=collections.defaultdict(list)
    for r in db.execute('SELECT * FROM _nba_roster_game_observations ORDER BY game_date,game_id'):rosters[r['game_date']].append(dict(r))
    injuries={(r['player_id'],r['game_id']):r['reported_injured'] for r in db.execute('SELECT * FROM _nba_injury_observations')}
    cohorts={r['as_of_date']:dict(r) for r in db.execute("SELECT * FROM _player_score_cohorts WHERE league='NBA'")}
    state={};performance={};rows=[];count=0;milestone=10;missing=collections.Counter();positive_injury_profiles=0;game_links=[]
    games=collections.defaultdict(list);by_game={};latest_rosters={};link_audit=[]
    partial_roster_games={r[0] for r in db.execute("SELECT DISTINCT game_id FROM _nba_player_game_facts WHERE json_extract(body,'$.roster_request_id') IS NULL AND json_extract(body,'$.pointer') IS NULL")}
    for gid,b in db.execute('SELECT id,body FROM _nba_canonical_games'):
        g=json.loads(b)
        if db.execute("SELECT 1 FROM polymarket_pre_match WHERE game_id=? UNION SELECT 1 FROM kalshi_pre_match WHERE game_id=?",(gid,gid)).fetchone():
            by_game[gid]=g
            cutoff=(dt.date.fromisoformat(g['date'])-dt.timedelta(days=1)).isoformat();games[cutoff].append(g)
    def person(pid):return state.setdefault(pid,dict(team=None,history=[],tenure_start=None,overall_n=0,overall_played=0,current_n=0,current_played=0,current_starts=0,current_starts_known=0,injured=False,ever_injured=False,first_known_date=None))
    def affiliation(a,day):
        p=person(a['player_id']);p['first_known_date']=p['first_known_date'] or day
        if p['team']!=a['team_name']:
            p.update(team=a['team_name'],tenure_start=None,current_n=0,current_played=0,current_starts=0,current_starts_known=0)
            p['history'].append(a['team_name'])
            if (a['player_id'],day,a['team_name']) in acquisitions:p['tenure_start']=day
        elif p['tenure_start'] is None and p['current_n']==0 and (a['player_id'],day,a['team_name']) in acquisitions:p['tenure_start']=day
    for day in sorted(d for d in aff if d<start):
        for a in aff[day]:affiliation(a,day)
    cols=[r[1] for r in db.execute('PRAGMA table_info(player_profiles)')]
    db.execute("DELETE FROM game_player_profiles WHERE game_id LIKE 'NBA_%'")
    db.execute("DELETE FROM player_profiles WHERE league='NBA'")
    insert='INSERT INTO player_profiles VALUES ('+','.join('?' for _ in cols)+')'
    first=dt.date.fromisoformat(start);last=dt.date.fromisoformat(end);total_days=(last-first).days+1
    for i in range(total_days):
        d=first+dt.timedelta(days=i);day=d.isoformat()
        # Game roster observations are applied in source-ID order. Official
        # acquisition/current-roster events on the same date take final priority.
        ordinary=[a for a in aff[day] if not a['observation_id'].startswith('ROSTER_EVENT:')]
        official=[a for a in aff[day] if a['observation_id'].startswith('ROSTER_EVENT:')]
        for a in ordinary:affiliation(a,day)
        for r in rosters[day]:
            p=person(r['player_id']);p['first_known_date']=p['first_known_date'] or day;p['overall_n']+=1;p['overall_played']+=r['did_play']
            if not r['is_temporary'] and r['team_name']==p['team']:
                p['current_n']+=1;p['current_played']+=r['did_play']
                if r['did_play'] and r['starter'] is not None:p['current_starts']+=r['starter'];p['current_starts_known']+=1
            p['injured']=bool(injuries[r['player_id'],r['game_id']]);p['ever_injured']|=p['injured']
        roster_groups=collections.defaultdict(set)
        for r in rosters[day]:roster_groups[r['game_id'],r['team_name']].add(r['player_id'])
        for (gid,team),ids in roster_groups.items():
            program='Summer League' if 'Summer League' in by_game[gid]['season'] else 'All-Star' if 'All-Star' in by_game[gid]['season'] else 'NBA'
            # A scorer-only fallback does not prove the full roster. Keep the
            # last complete roster and record the newly observed players too.
            previous=latest_rosters.get((team,program))
            sources=[dict(game_id=gid,observed_date=day,partial_roster=gid in partial_roster_games)]
            if gid in partial_roster_games and previous:
                ids=ids|previous['players'];sources=previous['sources']+sources
            latest_rosters[team,program]=dict(game_id=gid,observed_date=day,players=ids,sources=sources)
        for a in official:affiliation(a,day)
        for p in perf_changes[day]:performance[p['player_id']]=p
        cohort=cohorts.get(day,{})
        for pid,p in state.items():
            b=bio[pid];m=performance.get(pid,{});dob=b['dob'];mu=cohort.get('mu');sigma=cohort.get('sigma');avg=m.get('average_score_per_game')
            row=dict(player_id=pid,player_name=b['player_name'],game_type='Basketball',league='NBA',team=p['team'],overall_winrate=m.get('overall_winrate'),average_score_per_game=avg,average_assists_per_game=m.get('average_assists_per_game'),std_score_per_game=m.get('std_score_per_game'),std_assists_per_game=m.get('std_assists_per_game'),age=d.year-dob.year-((d.month,d.day)<(dob.month,dob.day)) if dob else None,weight_kg=b['weight_kg'],height_cm=b['height_cm'],years_played=sum(f'{s+1:04d}-07-01'<=day for s in b['seasons']) if b['seasons'] is not None else None,score_z_score=(avg-mu)/sigma if avg is not None and sigma and mu is not None else None,injured_times_till_as_of_date=None if p['ever_injured'] else 0,currently_injured_till_as_of_date=int(p['injured']),number_of_teams_served=None,participation_rate_current_team=p['current_played']/p['current_n'] if p['current_n'] else None,participation_rate_overall=p['overall_played']/p['overall_n'] if p['overall_n'] else None,starter_percentage_current_team=p['current_starts']/p['current_played'] if p['current_played'] and p['current_starts_known']==p['current_played'] else None,starter_percentage_overall=m.get('starter_percentage_overall'),average_minutes_per_game=m.get('average_minutes_per_game'),std_minutes_per_game=m.get('std_minutes_per_game'),served_team_history=','.join(p['history']) or None,months_serving_current_team=months(p['tenure_start'],day) if p['tenure_start'] else None,as_of_date=day)
            rows.append(tuple(row[c] for c in cols));count+=1
            if row['currently_injured_till_as_of_date']:positive_injury_profiles+=1
            for k,v in row.items():
                if v is None:missing[k]+=1
        # Associate only affiliations already observed by t-1 with each game.
        # The future game's actual lineup is not used to choose feature rows.
        for g in games[day]:
            program='Summer League' if 'Summer League' in g['season'] else 'All-Star' if 'All-Star' in g['season'] else 'NBA'
            eligible=set();sources=[]
            for team in g['teams']:
                roster=latest_rosters.get((team,program))
                if roster:
                    eligible.update(pid for pid in roster['players'] if pid in state and state[pid]['team']==team)
                    sources.append(dict(team=team,source_game_id=roster['game_id'],observed_date=roster['observed_date'],roster_sources=roster['sources']))
                # A dated new acquisition can supplement the previous roster.
                if program=='NBA':
                    eligible.update(pid for pid,when,tm in acquisitions if tm==team and (roster is None or when>roster['observed_date']) and when<=day and pid in state and state[pid]['team']==team)
            game_links.extend((g['game_id'],pid,day) for pid in sorted(eligible))
            link_audit.append(dict(game_id=g['game_id'],as_of_date=day,program=program,profile_links=len(eligible),prior_roster_sources=sources,note='Previous observed roster of the same NBA/Summer/All-Star program plus documented acquisitions; not the future actual lineup. Missing prior rosters are not invented.'))
        if len(rows)>=10000:db.executemany(insert,rows);db.commit();rows=[]
        if (i+1)*100//total_days>=milestone:
            print('NBA DATED PROFILES',milestone,'percent;',day,'rows',count,flush=True);milestone+=10
    if rows:db.executemany(insert,rows)
    db.executemany('INSERT INTO game_player_profiles VALUES (?,?,?)',game_links)
    # All leagues use their dated profile membership; do not depend on a
    # separate snapshot table that may not exist in an imported database.
    kind=db.execute("SELECT type FROM sqlite_master WHERE name='player_current_team'").fetchone()[0]
    if kind=='table':
        db.execute('DROP TABLE player_current_team')
    else:db.execute('DROP VIEW player_current_team')
    db.execute("CREATE VIEW player_current_team AS SELECT player_id,player_name,game_type,league,team AS current_team,as_of_date FROM player_profiles")
    db.execute('CREATE TABLE IF NOT EXISTS _nba_profile_scope (key TEXT PRIMARY KEY,value TEXT NOT NULL) STRICT')
    db.execute('CREATE TABLE IF NOT EXISTS _nba_game_profile_link_audit (game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nba_game_profile_link_audit');db.executemany('INSERT INTO _nba_game_profile_link_audit VALUES (?,?)',[(x['game_id'],json.dumps(x)) for x in link_audit])
    scope=dict(performance='Only collected played games through as_of_date; game-linked features use t-1.',membership='Latest documented acquisition or observed non-All-Star roster; not a complete transaction archive.',served_team_history='Only source-observed team sequence through date; incomplete career histories. number_of_teams_served remains null until complete career coverage is established.',participation='Played appearances divided by collected roster observations; current-team rate resets on observed team change. These are observed roster opportunities, not proof of a complete historical roster.',injury='Latest dated injury/illness/concussion status carried until the next roster observation. No report defaults to false by user instruction. Distinct injury counts are null after a reported injury because medical episode IDs are unavailable; zero means no injury reported in collected observations.',experience='Number of documented regular seasons completed by query date (July 1 boundary); not current-year SEASON_EXP.',physical='DOB-derived age; sourced constant height and weight, exact inch/cm and pound/kg conversions.',tenure='Completed months since a documented acquisition for the current observed stint; missing when no start is established.',game_links='Player affiliations known by t-1, not actual future game lineups. Missing transaction history can leave stale membership; review coverage before modeling.')
    db.executemany('INSERT OR REPLACE INTO _nba_profile_scope VALUES (?,?)',list(scope.items()));db.commit()
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',first_date=start,last_date=end,calendar_dates=total_days,nba_profile_rows=count,native_player_ids=len(state),game_to_t_minus_one_profile_links=len(game_links),games_missing_both_prior_rosters=sum(not x['prior_roster_sources'] for x in link_audit),missing={k:dict(count=v,total=count,percentage=round(v*100/count,4)) for k,v in missing.items()},scope=scope,positive_injury_state_rows=positive_injury_profiles)
    (ROOT/'reports/nba_dated_profiles.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['missing','scope']}));db.close()

if __name__=='__main__':main()
