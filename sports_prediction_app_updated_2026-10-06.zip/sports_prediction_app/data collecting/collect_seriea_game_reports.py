"""Collect source-identified official Serie A lineups, headers and full event feeds."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from urllib.parse import quote
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from probe_seriea_api import BASE
from core import utc

def goal_scores(g,events):
 candidates=[]
 for flip_own in [False,True]:
  counts={'FirstHalf':[0,0],'SecondHalf':[0,0]};proofs=[];valid=True
  for i,e in enumerate(events):
   if e['type'] not in ['goal','penalty-goal','own-goal']:continue
   sides=[(j,e.get(s)) for j,s in enumerate(['away','home']) if e.get(s)]
   if len(sides)!=1:valid=False;break
   j,v=sides[0]
   if v.get('phase') not in counts or v.get('team',{}).get('teamId')!=g[['away','home'][j]]['id']:valid=False;break
   beneficiary=j^int(flip_own and e['type']=='own-goal');counts[v['phase']][beneficiary]+=1;proofs.append(dict(event_id=e['eventId'],pointer='/events/'+str(i),side=beneficiary,phase=v['phase']))
  total=[sum(counts[p][j] for p in counts) for j in [0,1]]
  if valid and total==g['scores']:candidates.append(dict(half=counts['FirstHalf'],second=counts['SecondHalf'],total=total,own_goal_side_inverted=flip_own,goal_proofs=proofs))
 if not candidates:return None
 if len(candidates)==2 and candidates[0]['goal_proofs']!=candidates[1]['goal_proofs']:return None
 return candidates[0]

def derive(g,events):
 clock={};proofs={};issues=[];diagnostics=[];half=None;goals=goal_scores(g,events)
 for field,kind in [('actual_start_utc','first-half'),('halftime_start_utc','half-time-break'),('second_half_start_utc','second-half'),('regulation_end_utc','end-second-half')]:
  hits=[(i,e) for i,e in enumerate(events) if e['type']==kind];times={e.get('timeStamp') for _,e in hits if e.get('timeStamp')};clock[field]=None
  if len(times)==1:
   i,e=next((i,e) for i,e in hits if e.get('timeStamp'));stamp=utc(next(iter(times)));clock[field]=stamp.isoformat();proofs[field]=dict(event_id=e['eventId'],pointer='/events/'+str(i)+'/timeStamp',raw=next(iter(times)))
  else:issues.append(dict(field=field,reason='Missing or ambiguous official phase timestamp',values=sorted(times)))
  if kind=='half-time-break':
   pairs={tuple(e.get(s+'ScorePush') for s in ['away','home']) for _,e in hits}
   if len(pairs)==1 and all(type(x) is int and x>=0 for x in next(iter(pairs))):half=list(next(iter(pairs)))
 ts=[utc(clock[k]) for k in clock]
 if all(ts):
  if not (ts==sorted(ts) and 40*60<=(ts[1]-ts[0]).total_seconds()<=100*60 and 3*60<=(ts[2]-ts[1]).total_seconds()<=60*60 and 40*60<=(ts[3]-ts[2]).total_seconds()<=100*60):
   issues.append(dict(reason='Unusable phase chronology',clock=dict(clock)));clock={k:None for k in clock}
 if clock['actual_start_utc'] and abs((utc(clock['actual_start_utc'])-utc(g['scheduled_start_utc'])).total_seconds())>1800:
  issues.append(dict(reason='Event kickoff over 30 minutes from official scheduled kickoff; requires separate delay verification',clock=dict(clock)));clock={k:None for k in clock}
 if any(ts and not -1800<=(utc(ts)-utc(g['scheduled_start_utc'])).total_seconds()<=5*3600 for ts in clock.values()):
  issues.append(dict(reason='Phase timestamp outside official game date window; possible later feed editing time',clock=dict(clock)));clock={k:None for k in clock}
 for e in events:
  if e['type']=='first-half' and [e.get(s+'ScorePush') for s in ['away','home']]!=[0,0]:issues.append(dict(reason='Nonzero opening event score; phase data excluded',event_id=e['eventId']));clock={k:None for k in clock}
 final=[e for e in events if e['type'] in ['end-second-half','full-time']]
 verified_final=bool(final)
 for e in final:
  pushed=[e.get(s+'ScorePush') for s in ['away','home']]
  if pushed!=g['scores']:
   if goals and pushed==goals['second']:diagnostics.append(dict(reason='ScorePush resets at halftime; final match score verified with all goal events and official header',event_id=e['eventId'],raw=pushed,normalized=g['scores']))
   else:issues.append(dict(reason='Event score does not reconcile to calendar and match header; exclude timeline-derived score and performance',event_id=e['eventId'],raw=pushed,official=g['scores']));verified_final=False;half=None
 if goals:
  if half is not None and half!=goals['half']:issues.append(dict(reason='Official halftime field conflicts with goal chronology; halftime score excluded',raw=half,goal_sum=goals['half']));half=None
  else:half=goals['half']
 if half and not all(half[i]<=g['scores'][i] for i in [0,1]):issues.append(dict(reason='Halftime score exceeds final score',raw=half));half=None
 return dict(clock=clock,clock_proofs=proofs,halftime_scores=half,issues=issues,diagnostics=diagnostics,goal_reconciliation=goals,final_score_verified=verified_final)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100;db=sqlite3.connect(DB,timeout=60);c=HistoryClient();HOSTS.add('seriea-api.prd.sdp.deltatre.digital');games={mid:json.loads(b) for mid,b in db.execute('SELECT * FROM _official_seriea_calendar')};ordered=sorted(games.values(),key=lambda g:g['date']);pilots={ordered[0]['official_match_id'],next(g for g in ordered if g['date']>='2025-08-01')['official_match_id'],ordered[-1]['official_match_id']};ids=pilots if a.pilot else pilots|{json.loads(b)['official_match_id'] for b, in db.execute("SELECT body FROM _eu_validated_contracts WHERE competition='SEA'")};by_month=collections.defaultdict(list)
 with db:db.execute('CREATE TABLE IF NOT EXISTS _official_seriea_game_reports (match_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
 done={mid:json.loads(b) for mid,b in db.execute('SELECT * FROM _official_seriea_game_reports') if json.loads(b)['status']=='ok' and json.loads(b).get('derivation_version')==4}
 for mid in ids:by_month[games[mid]['date'][:7]].append(mid)
 def fetch(mid):
  if mid in done:return mid,done[mid]
  g=games[mid];path=BASE+'/seasons/'+quote(g['season_id'],safe='')+'/matches/'+quote(mid,safe='');sources={};row=dict(match_id=mid,date=g['date'],competition='SEA',sources=sources)
  try:
   for kind in ['header','lineups','feed']:
    d,r=c.get(path+'/'+kind);assert d['matchId']==mid;sources[kind]=dict(request_id=r['request_id'],data=d)
   h=sources['header']['data'];lineups=sources['lineups']['data'];f=sources['feed']['data'];assert f['status']=='FINISHED';assert [h['provider'+s.title()+'Score'] for s in ['away','home']]==g['scores'];pagination=f['pagination']
   # Never silently truncate. The observed endpoint supplies a complete feed;
   # any actual multi-page response pauses collection for a verified pager.
   assert pagination['isLastPage'] and pagination['currentPage']==pagination['totalPages']==1,'Unexhausted feed pagination; inspect current official paging contract'
   for side in ['away','home']:
    assert lineups[side]['teamId']==g[side]['id'];assert h[side]['teamId']==g[side]['id'];xs=lineups[side]['fielded']+lineups[side]['benched'];assert len({p['playerId'] for p in xs})==len(xs)
   assert len({e['eventId'] for e in f['events']})==len(f['events']);row.update(status='ok',derivation_version=4,derived=derive(g,f['events']))
  except Exception as e:row.update(status='error',error=type(e).__name__+': '+str(e))
  return mid,row
 day=dt.date(2024,1,1);parts=[];milestone=10
 while day<=dt.date(2026,9,14) and (a.pilot or len(parts)<math.ceil(33*a.through_percent/100)):
  month=day.strftime('%Y-%m');counts=collections.Counter();errors=[]
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
   for mid,row in pool.map(fetch,by_month[month]):
    if mid not in done:
     with db:db.execute('INSERT OR REPLACE INTO _official_seriea_game_reports VALUES (?,?)',(mid,json.dumps(row)))
    counts[row['status']]+=1
    if row['status']=='error':errors.append(dict(match_id=mid,error=row['error']))
  parts.append(dict(month=month,games=len(by_month[month]),counts=dict(counts),errors=errors));out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Serie A official match reports',pilot=a.pilot,processed_months=len(parts),total_months=33,months=parts,new_requests=c.requests);(ROOT/'reports'/('seriea_game_reports_pilot.json' if a.pilot else 'seriea_game_reports_months.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
  if counts:print('SERIE A REPORT MONTH',month,dict(counts),'months',len(parts),'/33',flush=True)
  while not a.pilot and milestone<=100 and len(parts)>=math.ceil(33*milestone/100):print('SERIE A REPORT DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  if errors:print('ERRORS',json.dumps(errors),flush=True);break
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print('SERIE A NEW REQUESTS',c.requests,flush=True);db.close()

if __name__=='__main__':main()
