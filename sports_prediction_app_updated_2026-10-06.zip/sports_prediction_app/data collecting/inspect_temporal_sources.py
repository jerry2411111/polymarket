import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for name,kind in db.execute("SELECT name,type FROM sqlite_master WHERE (name LIKE '%contract%' OR name LIKE '%membership%' OR name LIKE '%tenure%' OR name LIKE '%injur%' OR name LIKE '%biogr%' OR name LIKE '%manager%' OR name LIKE '%team_history%') AND type IN ('view','table')"):
    print(name,kind,[r[1] for r in db.execute('PRAGMA table_info('+name+')')])
    if kind=='table':print('COUNT',db.execute('SELECT count(*) FROM '+name).fetchone()[0],'EXAMPLE',db.execute('SELECT * FROM '+name+' LIMIT 1').fetchone())
