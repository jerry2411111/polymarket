"""Classify missing head-coach assignments without promoting assistants automatically."""
import collections,json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB);counts=collections.Counter();samples=[]
for gid,b in db.execute('SELECT * FROM _eu_player_event_audit'):
 a=json.loads(b)
 if a['competition']!='SEA':continue
 for issue in a['issues']:
  if issue['field']!='manager':continue
  p=json.loads(db.execute('SELECT body FROM _eu_source_player_game_facts WHERE game_id=? LIMIT 1',(gid,)).fetchone()[0]);r=json.loads(db.execute('SELECT body FROM _official_seriea_game_reports WHERE match_id=?',(p['official_match_id'],)).fetchone()[0]);staff=r['sources']['lineups']['data'][['away','home'][issue['side']]]['staff'];key=tuple(sorted((str(s.get('role')),s.get('roleLabel')) for s in staff));counts[key]+=1
  if len(samples)<10:samples.append(dict(game_id=gid,side=issue['side'],staff=[{k:v for k,v in s.items() if k in ['staffId','role','roleLabel','mediaFirstName','mediaLastName','shortName']} for s in staff]))
print('CATEGORIES',[(k,n) for k,n in counts.items()]);print('EXAMPLES',json.dumps(samples,ensure_ascii=False));db.close()
