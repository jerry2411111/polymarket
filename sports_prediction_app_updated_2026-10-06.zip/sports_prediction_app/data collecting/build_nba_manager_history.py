"""Date-specific NBA head-coach performance from selected official game results.

Official reports correct appointment-source errors. The performance basis is
the head coach of record, including documented interim responsibility; this
does not claim verification of every brief game-day absence.
"""
import collections,datetime as dt,json,re,sqlite3,unicodedata
from build_history_catalog import DB
from build_nba_dated_profiles import months
from probe_history import ROOT

NEWS='https://www.nba.com/news/'
NOTES='https://www.nba.com/gamenotes/'
TEAMS={'Atlanta Hawks':'hawks','Boston Celtics':'celtics','Brooklyn Nets':'nets','Charlotte Hornets':'hornets','Chicago Bulls':'bulls','Cleveland Cavaliers':'cavaliers','Dallas Mavericks':'mavericks','Denver Nuggets':'nuggets','Detroit Pistons':'pistons','Golden State Warriors':'warriors','Houston Rockets':'rockets','Indiana Pacers':'pacers','Los Angeles Clippers':'clippers','Los Angeles Lakers':'lakers','Memphis Grizzlies':'grizzlies','Miami Heat':'heat','Milwaukee Bucks':'bucks','Minnesota Timberwolves':'timberwolves','New Orleans Pelicans':'pelicans','New York Knicks':'knicks','Oklahoma City Thunder':'thunder','Orlando Magic':'magic','Philadelphia 76ers':'sixers','Phoenix Suns':'suns','Portland Trail Blazers':'blazers','Sacramento Kings':'kings','San Antonio Spurs':'spurs','Toronto Raptors':'raptors','Utah Jazz':'jazz','Washington Wizards':'wizards'}
CORRECTIONS={
 ('doc-rivers','Milwaukee Bucks'):('2024-01-26','2026-04-13','https://www.nba.com/bucks/news/milwaukee-bucks-hire-doc-rivers-as-head-coach','Official hiring date; departure confirmed by the Bucks on April 13, 2026.'),
 ('doug-christie','Sacramento Kings'):('2024-12-27',None,'https://www.nba.com/kings/news/mike-brown-relieved-as-kings-head-coach','Interim appointment, retained continuously after permanent promotion.'),
 ('mike-brown','Sacramento Kings'):('2022-05-09','2024-12-27','https://cdn.nba.com/teams/uploads/sites/1610612758/2025/01/2024-25-Sacramento-Kings-Media-Guide.pdf','Official franchise transaction chronology; December 27 departure announcement.'),
 ('mike-brown','New York Knicks'):('2025-07-07',None,NOTES+'knicks.pdf','Formal appointment in official team notes; earlier reports concerned agreement.'),
 ('jj-redick','Los Angeles Lakers'):('2024-06-20',None,NOTES+'lakers.pdf','Official team notes identify June 20 hiring, before June 24 introduction.'),
 ('jb-bickerstaff','Detroit Pistons'):('2024-07-03',None,'https://www.nba.com/pistons/news/detroit-pistons-announce-j-b-bickerstaff-as-head-coach','Official appointment date, rather than initial agreement report.'),
 ('jordan-ott','Phoenix Suns'):('2025-06-06',None,NEWS+'cavs-hire-jordan-ott-coach','Official team announcement.'),
 ('kenny-atkinson','Cleveland Cavaliers'):('2024-06-28',None,NEWS+'cavs-to-hire-kenny-atkinson-as-coach','Official team announcement.'),
 ('nick-nurse','Philadelphia 76ers'):('2023-06-01',None,'https://www.nba.com/sixers/76ers-coaches/nick-nurse','Official coaching biography.'),
 ('mitch-johnson','San Antonio Spurs'):('2024-11-02',None,NEWS+'gregg-popovich-career-record-adjusted-by-nba','NBA credited the 77 games from November 2, 2024 to Johnson.'),
 ('gregg-popovich','San Antonio Spurs'):('1996-12-10','2024-11-02',NEWS+'gregg-popovich-career-record-adjusted-by-nba','Performance assignment ends when Johnson took over; formal employment continued until May 2, 2025.'),
 ('joe-mazzulla','Boston Celtics'):('2022-09-22',None,NEWS+'nba-starting-5-june-3-2024','Continuous head-coach service begins with interim appointment.'),
 ('steve-clifford','Charlotte Hornets'):('2022-06-24','2024-04-15',NEWS+'steve-clifford-to-step-down-hornets','April 3 announcement specified continuing through the final seven games; final regular-season date April 14.'),
 ('dusty-may','Dallas Mavericks'):('2026-06-23',None,NEWS+'mavs-hire-dusty-may-coach','Official appointment.'),
 ('sean-sweeney','Orlando Magic'):('2026-06-01',None,NEWS+'magic-hire-sean-sweeney-coach','Official appointment; retained Spurs assistant responsibilities through Finals.'),
 ('michael-nori','Portland Trail Blazers'):('2026-06-23',None,NEWS+'blazers-hire-micah-nori-coach','Official name is Micah Nori.'),
}

def key(s):return ''.join(c for c in unicodedata.normalize('NFKD',s).casefold() if c.isalnum())

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    docs=[dict(r) for r in db.execute('SELECT * FROM _nba_coach_document_pages')];raw=[json.loads(r[0]) for r in db.execute('SELECT body FROM _nba_coach_tenure_sources')];stints=[];issues=[];corrections=[]
    for s in raw:
        if s['effective_to'] and s['effective_to']<start:continue
        slug=s['coach_id'].split(':')[1]
        if slug=='jb-bickerstaff' and s['team_name']=='Atlanta Hawks':issues.append(dict(source=s,reason='Excluded source error: NBA reports place Bickerstaff in Cleveland/Detroit, not Atlanta.'));continue
        original=dict(s);change=CORRECTIONS.get((slug,s['team_name']))
        if change:s.update(effective_from=change[0],effective_to=change[1],correction_url=change[2],correction_reason=change[3]);corrections.append(dict(original=original,selected=s))
        if slug=='chauncey-billups':s['effective_to']='2025-10-23';s['correction_reason']='Interim Splitter responsibility began October 23; validate with official Portland game notes.'
        if slug=='michael-nori':s['coach_id']='NBA_COACH:micah-nori';s['coach_or_manager_name']='Micah Nori'
        if slug=='mike-malone':s['coach_or_manager_name']='Michael Malone'
        # Official team notes and appointment reports confirm identity/role.
        person=key(s['coach_or_manager_name']);own=NOTES+TEAMS[s['team_name']]+'.pdf';official=[]
        for d in docs:
            norm=key(d['text'])
            if person not in norm:continue
            if d['source_url']==own or d['source_url']==s.get('correction_url') or ('/news/' in d['source_url'] and key(s['team_name']) in norm):
                official.append(dict(request_id=d['request_id'],source_url=d['source_url'],page_number=d['page_number']))
        s.update(official_confirmation=official,tenure_date_source='OFFICIAL' if change else 'SALARYSWISH_DATED_HISTORY',source_candidate=original,status='OFFICIAL_IDENTITY_CONFIRMED' if official else 'OFFICIAL_CONFIRMATION_PENDING')
        # No guessed head-coach assignment is published without official role evidence.
        if not official:issues.append(dict(coach=s['coach_or_manager_name'],team=s['team_name'],reason='Official role confirmation pending'));continue
        stints.append(s)
    # An official 2026 appointment is absent from the financial-source history.
    url=NEWS+'bucks-name-taylor-jenkins-head-coach';d=next(x for x in docs if x['source_url']==url)
    stints.append(dict(coach_id='NBA_COACH:taylor-jenkins',coach_or_manager_name='Taylor Jenkins',team_name='Milwaukee Bucks',effective_from='2026-04-30',effective_to=None,role='Head Coach',official_confirmation=[dict(request_id=d['request_id'],source_url=url,page_number=1)],tenure_date_source='OFFICIAL',source_url=url,request_id=d['request_id'],status='OFFICIAL_IDENTITY_CONFIRMED'))
    # Merge continuous interim/permanent service, keeping both source records.
    merged=[]
    for s in sorted(stints,key=lambda x:(x['coach_id'],x['team_name'],x['effective_from'])):
        if merged and merged[-1]['coach_id']==s['coach_id'] and merged[-1]['team_name']==s['team_name'] and (merged[-1]['effective_to'] is None or merged[-1]['effective_to']>=s['effective_from']):
            old=merged[-1];old['effective_to']=None if not old['effective_to'] or not s['effective_to'] else max(old['effective_to'],s['effective_to']);old['official_confirmation']+=s['official_confirmation']
        else:merged.append(s)
    stints=merged
    facts=[];audit=[];unmatched=[]
    games={r['id']:json.loads(r['body']) for r in db.execute('SELECT * FROM _nba_canonical_games')}
    for t in db.execute("SELECT * FROM _team_game_results WHERE league='NBA'"):
        g=games[t['game_id']]
        if 'Summer League' in g['season'] or 'All-Star' in g['season']:unmatched.append(dict(game_id=t['game_id'],team=t['team_name'],reason='Special-program coaching roster is not established'));continue
        hits=[s for s in stints if s['team_name']==t['team_name'] and s['effective_from']<=t['game_date'] and (not s['effective_to'] or s['effective_to']>t['game_date'])]
        if len(hits)!=1:unmatched.append(dict(game_id=t['game_id'],team=t['team_name'],reason='Head-coach interval missing or ambiguous',candidates=[s['coach_id'] for s in hits]));continue
        s=hits[0];facts.append((s['coach_id'],s['coach_or_manager_name'],'Basketball','NBA',t['team_name'],t['game_id'],t['game_date'],t['home_away'],t['score_for'],t['score_against'],t['win']));audit.append((s['coach_id'],t['game_id'],json.dumps(dict(stint=s,score_source='Official NBA canonical game and selected-game team facts',performance_basis='Head coach of record with documented interim changes; not a claim of physical presence at every game.'))))
    db.execute('CREATE TABLE IF NOT EXISTS _nba_manager_stints (body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nba_manager_stints');db.executemany('INSERT INTO _nba_manager_stints VALUES (?)',[(json.dumps(s),) for s in stints]);db.execute("DELETE FROM _manager_game_results WHERE league='NBA'");db.executemany('INSERT INTO _manager_game_results VALUES (?,?,?,?,?,?,?,?,?,?,?)',facts)
    db.execute('CREATE TABLE IF NOT EXISTS _nba_manager_game_audit (manager_id TEXT NOT NULL,game_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(manager_id,game_id)) STRICT');db.execute('DELETE FROM _nba_manager_game_audit');db.executemany('INSERT INTO _nba_manager_game_audit VALUES (?,?,?)',audit);db.commit()
    people=collections.defaultdict(list)
    for s in stints:people[s['coach_id']].append(s)
    changes=collections.defaultdict(list)
    for f in facts:changes[f[6]].append(f)
    n=collections.Counter();wins=collections.Counter();profiles=[];a=dt.date.fromisoformat(start);z=dt.date.fromisoformat(end);milestone=10
    for i in range((z-a).days+1):
        day=(a+dt.timedelta(days=i)).isoformat()
        for f in changes[day]:n[f[0]]+=1;wins[f[0]]+=f[-1]
        for pid,ss in people.items():
            known=sorted((s for s in ss if s['effective_from']<=day),key=lambda x:x['effective_from'])
            if not known:continue
            active=[s for s in known if not s['effective_to'] or s['effective_to']>day];assert len(active)<=1,(pid,day,active)
            current=active[0] if active else None;history=[]
            if current is None:continue
            for s in known:
                if not history or history[-1]!=s['team_name']:history.append(s['team_name'])
            tenure=months(current['effective_from'],day) if current and current['tenure_date_source']=='OFFICIAL' else None
            profiles.append((pid,known[-1]['coach_or_manager_name'],'Basketball','NBA',current['team_name'],None,','.join(history),wins[pid]/n[pid] if n[pid] else None,day))
        if (i+1)*100//((z-a).days+1)>=milestone:print('NBA DATED MANAGERS',milestone,'percent;',day,flush=True);milestone+=10
    db.execute("DELETE FROM manager_profiles WHERE league='NBA'");db.executemany('INSERT INTO manager_profiles VALUES (?,?,?,?,?,?,?,?,?)',profiles);db.commit()
    assert db.execute("SELECT COUNT(*) FROM _manager_game_results WHERE league='NBA'").fetchone()[0]==len(facts)
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',manager_ids=len(people),dated_profile_rows=len(profiles),head_coach_stints=len(stints),selected_team_games=5534,attributed_team_games=len(facts),unattributed_team_games=len(unmatched),unattributed_percentage=round(len(unmatched)*100/5534,4),date_corrections=corrections,issues=issues,unattributed=unmatched,scope='Selected collected games only through date. Summer League/All-Star assignments require separate evidence. Current assignment is head-coaching responsibility, not a payroll/employment claim. Complete career team counts and unverified tenure starts remain null.')
    (ROOT/'reports/nba_manager_history.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['date_corrections','issues','unattributed']}))
    from sync_nba_manager_links import sync
    link_report=sync(db);(ROOT/'reports/nba_manager_links_validation.json').write_text(json.dumps(link_report,indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
