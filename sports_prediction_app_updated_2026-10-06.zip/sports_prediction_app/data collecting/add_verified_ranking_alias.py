import datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT
def main():
    db=sqlite3.connect(DB);db.execute('CREATE TABLE IF NOT EXISTS _nba_verified_name_aliases (alias TEXT NOT NULL,player_id TEXT NOT NULL,source_url TEXT NOT NULL,request_id TEXT NOT NULL,PRIMARY KEY(alias,player_id)) STRICT')
    for pid,slug,full,alias in [('1630529','herbert-jones','Herbert Jones','Herb Jones'),('1626181','norman-powell','Norman Powell','Norm Powell'),('1629661','cameron-johnson','Cameron Johnson','Cam Johnson')]:
        if db.execute('SELECT 1 FROM _nba_verified_name_aliases WHERE alias=? AND player_id=?',(alias,'NBA:'+pid)).fetchone():continue
        url={'1626181':'https://www.nba.com/news/john-collins-norman-powell-trade','1629661':'https://www.nba.com/nuggets/news/offseason-additions-cam-johnson'}.get(pid,f'https://www.nba.com/player/{pid}/{slug}/bio');body,r=HistoryClient().get(url,document=True);s=BeautifulSoup(body,'html.parser');text=s.get_text(' ',strip=True)
        script=s.find('script',id='__NEXT_DATA__')
        if script:
            page=json.loads(script.string)['props']['pageProps'].get('pageObject',{})
            text+=' '+str(page.get('title',''))+' '+' '.join(BeautifulSoup(x.get('html',''),'html.parser').get_text(' ',strip=True) for x in page.get('contentStructured',[]) if isinstance(x,dict))
        if full not in text or alias not in text:
            print('Official alias not established',alias,r['request_id']);continue
        db.execute('INSERT OR IGNORE INTO _nba_verified_name_aliases VALUES (?,?,?,?)',(alias,'NBA:'+pid,url,r['request_id']));db.commit();print('Verified official name alias',full,alias,r['request_id'])
    db.close()
if __name__=='__main__':main()
