import datetime as dt,hashlib,json,sqlite3
from probe_history import ROOT
from build_history_catalog import DB
report=json.loads((ROOT/'reports/raw_provenance_audit.json').read_text());db=sqlite3.connect(DB)
for x in report['unreferenced_raw_files_older_than_120_seconds']:
    p=ROOT/x['path'];b=p.read_bytes();d=json.loads(b);sha=hashlib.sha256(b).hexdigest();same=db.execute("SELECT request_id,return_status,json_extract(metadata_json,'$.raw_file') FROM _request_audit WHERE json_extract(metadata_json,'$.sha256')=?",(sha,)).fetchall()
    print(json.dumps(dict(path=x['path'],modified=dt.datetime.fromtimestamp(p.stat().st_mtime,dt.UTC).isoformat(),sha256=sha,keys=list(d),ticker=d.get('ticker'),rows=len(d.get('candlesticks',[])),body_if_small=d if len(b)<200 else None,same_hash_logged_sources=same[:3])))
