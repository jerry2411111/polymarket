"""Audit exact points potentially inserted by a resolved-market history API."""
import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

db=sqlite3.connect(DB,timeout=60);counts=collections.Counter();examples=[];keys=collections.Counter();kinds=collections.Counter()
for b, in db.execute('SELECT body FROM _history_selections'):
    x=json.loads(b)
    keys.update(x.keys());kinds[str(x.get('source_kind'))]+=1
    if x.get('source_kind')=='v2' and x.get('source_resolution_seconds')==0:
        counts[x['game_id'].split('_')[0],x['target'].split('_')[0],str(x.get('normalized_price'))]+=1
        if len(examples)<8:examples.append(x)
print(json.dumps(dict(counts=[dict(league=k[0],kind=k[1],price=k[2],count=v) for k,v in counts.items()],examples=examples,keys=keys,source_kinds=kinds),indent=2))
