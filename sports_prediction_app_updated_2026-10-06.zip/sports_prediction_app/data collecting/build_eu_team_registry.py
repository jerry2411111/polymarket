"""Link official domestic club IDs to UEFA IDs with retained naming evidence."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from eu_official_games import CONFIG,games,club_key
from probe_history import ROOT

def main():
 db=sqlite3.connect(DB,timeout=60);uefa={};domestic={};rows=[];issues=[]
 for b, in db.execute('SELECT body FROM _official_uefa_calendar'):
  g=json.loads(b)
  for side in ['away','home']:
   t=g['raw'][side+'Team'];names={t.get('internationalName')}|{v for key,vs in t['translations'].items() if key in ['displayName','displayOfficialName','shortName'] for lang,v in vs.items() if lang in ['EN','DE','ES','FR','IT','PT']};uefa[t['id']]=dict(id=t['id'],name=t['translations']['displayOfficialName']['EN'],names=sorted(names-{None}),country=t['countryCode'],abbr=t['teamCode'],request_id=g['request_id'],pointer=g['pointer']+'/'+side+'Team')
 for b, in db.execute('SELECT body FROM _official_epl_calendar'):
  g=json.loads(b)
  for side in ['away','home']:
   t=g[side];uid=str(t['id']);name=t['name'];match=[u for u in uefa.values() if u['country']=='ENG' and club_key(name) in {club_key(n) for n in u['names']}]
   assert len(match)<=1,'Ambiguous Premier League/UEFA club identity';proof=match[0] if match else None;domestic['PL',uid]=dict(competition_code='PL',official_team_id=uid,name=name,uefa_id=proof['id'] if proof else None,domestic_request_id=g['request_id'],domestic_pointer=g['pointer']+'/'+side+'Team',uefa_proof=proof,basis='Same national association and exact normalized official team name')
 for code in CONFIG:
  if code=='UCL':continue
  for g in games(db,code).values():
   for side in ['away','home']:
    t=g[side];proof=t.get('uefa_identity_proof');suffix='/'+side+'_team' if code=='LAL' else '/teams/'+side if code=='BUN' else '/'+side+'/clubIdentity' if code=='FL1' else '/'+side;domestic[code,t['id']]=dict(competition_code=code,official_team_id=t['id'],name=t['name'],uefa_id=proof['team_id'] if proof else None,domestic_request_id=g['request_id'],domestic_pointer=g['pointer']+suffix,uefa_proof=proof,basis=proof['basis'] if proof else 'Native official domestic club ID only')
 # Retain the already published full Premier League names consistently across
 # all competitions; use UEFA's official full name for other linked clubs.
 preferred={d['uefa_id']:d['name'] for d in domestic.values() if d['competition_code']=='PL' and d['uefa_id']}
 for d in domestic.values():
  uid=d['uefa_id'];d.update(team_id='EU_UEFA_CLUB:'+uid if uid else 'EU_'+d['competition_code']+'_CLUB:'+d['official_team_id'],team_name=preferred.get(uid) or uefa[uid]['name'] if uid else d['name']);rows.append((d['competition_code'],d['official_team_id'],json.dumps(d)))
 for uid,u in uefa.items():
  d=dict(competition_code='UCL',official_team_id=uid,team_id='EU_UEFA_CLUB:'+uid,team_name=preferred.get(uid) or u['name'],uefa_id=uid,uefa_proof=u,basis='Official UEFA native club ID');rows.append(('UCL',uid,json.dumps(d)))
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _eu_team_identity (competition_code TEXT,official_team_id TEXT,body TEXT NOT NULL,PRIMARY KEY(competition_code,official_team_id)) STRICT');db.execute('DELETE FROM _eu_team_identity');db.executemany('INSERT INTO _eu_team_identity VALUES (?,?,?)',rows)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',native_club_ids=len(rows),canonical_clubs=len({json.loads(b)['team_id'] for _,_,b in rows}),domestic_clubs_linked_to_uefa=sum(d['uefa_id'] is not None for d in domestic.values()),premier_league_names_preserved=len(preferred),by_competition=dict(collections.Counter(c for c,_,_ in rows)),issues=issues,scope='Internal club identity and full-name consistency only; no current roster is used for historical membership');(ROOT/'reports/eu_team_registry.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
