"""Date-batch progress for the NBA main table, separate from project completion."""
import argparse,calendar,collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--through-month',required=True);args=ap.parse_args()
    proof=json.loads((ROOT/'reports/nba_main_validation.json').read_text())
    if proof['status']!='WORKING':raise ValueError('Current NBA output validation has not passed')
    db=sqlite3.connect(DB,timeout=60)
    mappings={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_map')}
    games={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_games')}
    exclusions=set()
    for (b,) in db.execute('SELECT body FROM _nba_contract_choice_audit'):exclusions.update(json.loads(b)['excluded_contract_ids'])
    contracts=collections.defaultdict(list)
    for (b,) in db.execute('SELECT body FROM _history_contracts'):
        c=json.loads(b)
        if c['game_id'] in mappings and c['contract_id'] not in exclusions:
            gid=mappings[c['game_id']]['game_id'];contracts[games[gid]['date'][:7]].append(c)
    jobs={}
    text=(ROOT/'reports/history_acquisition_jobs.jsonl').read_text();lines=text.splitlines()
    if text and not text.endswith('\n'):lines=lines[:-1]
    for line in lines:
        j=json.loads(line)
        if j['kind']=='price':jobs[j['contract_id']]=j
    official=collections.Counter()
    for (b,) in db.execute('SELECT body FROM _official_nba_schedule'):official[json.loads(b)['date'][:7]]+=1
    normalized={(json.loads(b)['provider'],json.loads(b)['game_id']) for (b,) in db.execute('SELECT body FROM _game_odds_eligibility')}
    db.execute('CREATE TABLE IF NOT EXISTS _nba_month_progress (month TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
    rows=[];day=dt.date(2024,1,1);end=dt.date(2026,9,14)
    while day<=end and day.strftime('%Y-%m')<=args.through_month:
        month=day.strftime('%Y-%m');cs=contracts[month];missing=[c['contract_id'] for c in cs if c['contract_id'] not in jobs];failed=[c['contract_id'] for c in cs if c['contract_id'] in jobs and jobs[c['contract_id']]['status']!='ok']
        unnormalized={(c['provider'],mappings[c['game_id']]['game_id']) for c in cs}-normalized
        status='VERIFIED_PARTIAL_COVERAGE' if not missing and not failed and not unnormalized else 'ACQUISITION_OR_NORMALIZATION_PENDING'
        obtained={p:db.execute(f"SELECT count(*) FROM {p}_pre_match WHERE league='NBA' AND substr(date,1,7)=?",(month,)).fetchone()[0] for p in ['polymarket','kalshi']}
        r=dict(month=month,status=status,official_games_in_window=official[month],matched_contracts=len(cs),unrequested_contracts=len(missing),failed_contracts=len(failed),unnormalized_game_provider_pairs=len(unnormalized),empty_source_histories=sum(jobs[c['contract_id']].get('rows')==0 for c in cs if c['contract_id'] in jobs),provider_games_with_usable_odds=obtained,scope='NBA main table only; all competition types. Supporting tables and full project are separate work.');rows.append(r)
        db.execute('INSERT OR REPLACE INTO _nba_month_progress VALUES (?,?)',(month,json.dumps(r)))
        day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
    db.commit();allrows=[json.loads(b) for (b,) in db.execute('SELECT body FROM _nba_month_progress ORDER BY month')];db.close()
    complete=sum(r['status']=='VERIFIED_PARTIAL_COVERAGE' for r in allrows);result=dict(work_unit='NBA main table calendar-month batches',verification_current=True,validated_at_utc=proof.get('verified_at_utc'),completed_months=complete,total_months=33,progress_pct=round(100*complete/33,2),ten_percent_milestone=int(100*complete/33)//10*10,meaning='Processing/verification progress, not percentage of all NBA games with odds or whole-project completion',months=allrows)
    (ROOT/'reports/nba_month_progress.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k!='months'}))

if __name__=='__main__':main()
