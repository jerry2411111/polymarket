"""Exhaust official provider pagination for the authorized three-year league scope."""
import collections,datetime as dt,json,os
from probe_history import Client,ROOT

LEAGUES={'NBA':('basketball','KXNBAGAME',745),'MLB':('baseball','KXMLBGAME',100381),'NHL':('hockey','KXNHLGAME',899)}
START='2023-09-13';END='2026-09-13'

def walk(c,url,params,key):
 cursor=None;seen=set();count=0;pages=0
 while True:
  q=dict(params)
  if cursor:q['cursor']=cursor
  d,r=c.get(url,q);items=d[key];count+=len(items);pages+=1
  yield items,r
  cursor=d.get('cursor')
  if not cursor:break
  if cursor in seen:raise ValueError('Repeated cursor; cannot claim completeness')
  seen.add(cursor)
  if pages>=1000:raise RuntimeError('Pagination safeguard reached, incomplete')

def main():
 os.environ['PILOT_MAX_REQUESTS']='2000'
 c=Client(ROOT);summary=[]
 for league,(sport,series,tag) in LEAGUES.items():
  tasks=[('milestones',{'minimum_start_date':START+'T00:00:00Z','competition':league,'limit':500},'milestones'),
    ('structured_targets',{'competition':league,'type':sport+'_team','page_size':2000},'structured_targets'),
    ('structured_targets',{'competition':league,'type':sport+'_player','page_size':2000},'structured_targets'),
    ('historical/markets',{'series_ticker':series,'limit':1000},'markets'),
    ('markets',{'series_ticker':series,'limit':1000,'status':'settled'},'markets')]
  for path,params,key in tasks:
   n=0;dates=[];ids=set();sim=0;error=None
   try:
    for items,r in walk(c,'https://external-api.kalshi.com/trade-api/v2/'+path,params,key):
     for x in items:
      uid=x.get('id') or x.get('ticker')
      if uid in ids:raise ValueError('Duplicate identity across pages')
      ids.add(uid);n+=1
      if path=='milestones':
       if any(t.startswith('SIM') for t in x.get('primary_event_tickers',[])):sim+=1
       else:dates.append(x['start_date'])
      elif key=='markets':dates.append(x.get('close_time'))
   except Exception as e:error=str(e)
   row=dict(provider='kalshi',league=league,endpoint=path,rows=n,pagination_exhausted=error is None,error=error,
       simulated_milestones_excluded=sim,earliest=min(filter(None,dates),default=None),latest=max(filter(None,dates),default=None))
   summary.append(row);print('DISCOVERY',json.dumps(row),flush=True)
  offset=0;ids=set();dates=[];error=None
  try:
   while True:
    q={'tag_id':tag,'closed':'true','end_date_min':START+'T00:00:00Z','end_date_max':'2026-09-15T00:00:00Z','order':'id','ascending':'true','limit':500,'offset':offset}
    d,r=c.get('https://gamma-api.polymarket.com/events',q)
    for x in d:
     if x['id'] in ids:raise ValueError('Repeated Polymarket event page')
     ids.add(x['id']);dates.append(x.get('endDate'))
    # The server may cap a requested page size. Only an empty next page
    # establishes exhaustion for offset pagination; advance by actual rows.
    if not d:break
    offset+=len(d)
    if offset>100000:raise RuntimeError('Offset safeguard reached')
  except Exception as e:error=str(e)
  row=dict(provider='polymarket',league=league,endpoint='events',rows=len(ids),pagination_exhausted=error is None,error=error,earliest=min(filter(None,dates),default=None),latest=max(filter(None,dates),default=None))
  summary.append(row);print('DISCOVERY',json.dumps(row),flush=True)
  (ROOT/'reports/discovery_coverage.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 print('DISCOVERY COMPLETE',flush=True)

if __name__=='__main__':main()
