"""Inspect real finished-game API schemas before general normalization."""
import json
from probe_history import Client,ROOT

def main():
 c=Client(ROOT);examples={}
 for line in (ROOT/'data/raw/requests.jsonl').read_text(encoding='utf-8').splitlines():
  r=json.loads(line)
  if r['status']!=200 or not r['endpoint'].endswith('/milestones'):continue
  d=json.loads((ROOT/r['raw_file']).read_bytes())
  for m in d['milestones']:
   league=m['details'].get('league')
   if league in ['NBA','MLB','NHL'] and not any(t.startswith('SIM') for t in m['primary_event_tickers']) and m['start_date']<'2026-01-01':examples.setdefault(league,m)
 ids=[m['id'] for m in examples.values()]
 d,r=c.get('https://external-api.kalshi.com/trade-api/v2/live_data/batch',{'milestone_ids':ids,'include_player_stats':'true'})
 out={'milestones':examples,'batch':d}
 for league,m in examples.items():
  d,r=c.get('https://external-api.kalshi.com/trade-api/v2/live_data/milestone/'+m['id']+'/game_stats')
  out[league]=d
 (ROOT/'reports/game_schema_examples.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
 for k,v in out.items():
  if k=='milestones':continue
  print(k,'keys',list(v) if isinstance(v,dict) else type(v).__name__)
  if k=='batch':print(json.dumps(v)[:15000])
  else:
   print(json.dumps({a:b for a,b in v.items() if a!='pbp'})[:6000])
   pbp=v.get('pbp') or {};print('pbp keys',list(pbp));print(json.dumps({a:b for a,b in pbp.items() if a!='periods'})[:4000]);print('first period',json.dumps((pbp.get('periods') or [{}])[0])[:2000])
if __name__=='__main__':main()
