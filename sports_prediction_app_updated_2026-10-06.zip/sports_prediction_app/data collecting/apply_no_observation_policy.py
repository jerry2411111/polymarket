import datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from apply_requested_revision import STATS
from no_observation_policy import install
ZERO_STATS=STATS+['score_z_score','participation_rate_current_team','participation_rate_overall','starter_percentage_current_team']

def main():
 db=sqlite3.connect(DB,timeout=120);out={'generated_at_utc':dt.datetime.now(dt.UTC).isoformat(),'counts':{}}
 db.execute('CREATE INDEX IF NOT EXISTS _player_games_person_date ON _player_game_results(player_id,league,game_date)')
 for league in ['NBA','MLB','NHL','EU soccer']:
  count=0;last=0
  while True:
   ids=[r[0] for r in db.execute('SELECT p.rowid FROM player_profiles p WHERE league=? AND p.rowid>? AND ('+' OR '.join('p.'+c+' IS NULL' for c in ZERO_STATS)+') AND NOT EXISTS(SELECT 1 FROM _player_performance_periods m WHERE m.player_id=p.player_id AND m.league=p.league AND m.effective_from<=p.as_of_date) ORDER BY p.rowid LIMIT 25000',(league,last))]
   if not ids:break
   with db:db.execute('UPDATE player_profiles SET '+','.join(c+'=0' for c in ZERO_STATS)+' WHERE rowid IN ('+','.join('?' for _ in ids)+')',ids)
   count+=len(ids);last=ids[-1]
  out['counts'][league]=count;print('NO-OBSERVATION ZERO PROFILES',league,count,flush=True)
 with db:
  out['manager_profiles_zero_history']=db.execute('UPDATE manager_profiles AS p SET overall_winrate=0 WHERE overall_winrate IS NULL AND NOT EXISTS(SELECT 1 FROM _manager_game_results g WHERE g.manager_id=p.manager_id AND g.league=p.league AND g.game_date<=p.as_of_date AND g.game_date>=(SELECT collection_start FROM _collection_scope))').rowcount
  install(db)
 (ROOT/'reports/no_observation_policy.json').write_text(json.dumps(out,indent=2),encoding='utf-8');db.close();print(json.dumps(out),flush=True)
if __name__=='__main__':main()
