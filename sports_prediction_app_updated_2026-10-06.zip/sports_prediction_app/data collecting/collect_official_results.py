"""Official league reports for final scores: public HTML fallback, raw first.

MLB public Stats API documentation currently requires access; NHL public reports
provide fields absent from the documented market APIs. No hidden API is called.
"""
import argparse,collections,concurrent.futures,datetime as dt,json,re,sqlite3
from bs4 import BeautifulSoup
from history_client import HistoryClient
from history_index import records
from probe_history import ROOT
from build_history_catalog import DB,clean
from official_html import decode_html

def mlb_scoreboard(body,date,rid):
    soup=BeautifulSoup(body,'html.parser')
    if '"route":"/scores/'+date+'"' not in body.decode('utf-8',errors='replace'):raise ValueError('Official scoreboard requested date not established')
    rows=[]
    for card in soup.find_all(attrs={'data-test-mlb':'singleGameContainer'}):
        label=card.find(attrs={'data-mlb-test':'gameStartTimesStateLabel'})
        if not label or not label.get_text(' ',strip=True).startswith('Final'):continue
        box=card.find('a',attrs={'data-mlb-test':'productlink-box'})
        if not box:raise ValueError('Final MLB game lacks native game link')
        gid=re.search(r'/gameday/(\d+)/',box['href'])
        if not gid:raise ValueError('Unrecognized MLB game identity link')
        tables=card.find_all('table');line=tables[0];trs=line.find_all('tr');names=[];teamids=[];innings=[]
        for tr in trs[1:]:
            cells=tr.find_all(['td','th'],recursive=False);im=cells[0].find('img')
            if not im:raise ValueError('Missing official MLB full team name')
            names.append(im['alt']);teamids.append(re.search(r'/(\d+)\.svg',im['src'])[1]);innings.append([int(t) if t.isdigit() else None for x in cells[1:] if (t:=x.get_text(' ',strip=True))])
        totals=[]
        for table in tables[1:]:
            tr=table.find_all('tr');heads=[x.get_text(' ',strip=True) for x in tr[0].find_all(['td','th'],recursive=False)]
            if heads==['R','H','E']:
                scores=[int(tr[i].find_all(['td','th'],recursive=False)[0].get_text()) for i in [1,2]];totals.append(scores)
        if len(names)!=2 or not totals or len({tuple(x) for x in totals})!=1:raise ValueError('Inconsistent official MLB score schema')
        scores=totals[0]
        if any(sum(n for n in ins if n is not None)!=sc for ins,sc in zip(innings,scores)):raise ValueError('MLB inning sum disagrees with final')
        text=card.get_text(' ',strip=True);double=re.search(r'\bGame\s*([12])\b',text,re.I)
        # Scope the label to this game card; the site's global navigation also
        # mentions spring training even on regular-season dates.
        training=bool(re.search(r'\bSpring Training\b|\bExhibition\b',text,re.I))
        rows.append(dict(provider='MLB official',league='MLB',date=date,official_game_id=gid[1],teams=names,official_team_ids=teamids,scores=scores,winner=names[int(scores[1]>scores[0])] if scores[0]!=scores[1] else None,result='win' if scores[0]!=scores[1] else 'draw',innings=innings,home_away='Away;Home',competition_type='Spring Training / Exhibition' if training else None,is_training=True if training else None,doubleheader_number=int(double[1]) if double else None,source_url='https://www.mlb.com'+box['href'],request_id=rid))
    unique={r['official_game_id']:r for r in rows}
    return list(unique.values())

def nhl_summary(body,season,code,rid):
    soup=body if isinstance(body,BeautifulSoup) else BeautifulSoup(decode_html(body),'html.parser');info=soup.find(id='GameInfo')
    if not info:raise ValueError('No official NHL game report')
    text=info.get_text(' ',strip=True).replace('\xa0',' ')
    if not re.search(r'\bFinal\b',text):return None
    hit=re.search(r'(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday),\s+([A-Za-z]+ \d{1,2}, \d{4})',text)
    if not hit:raise ValueError('Official NHL report date missing')
    date=dt.datetime.strptime(hit[1],'%B %d, %Y').date().isoformat();teams=[];scores=[]
    for key in ['Visitor','Home']:
        el=soup.find(id=key);im=el.find('img',alt=True);txt=el.get_text(' ',strip=True)
        score=re.search(r'^(?:VISITOR|HOME)\s+(\d+)\s+',txt)
        if not score or not im or not im.get('alt'):raise ValueError('NHL named team score absent')
        teams.append(im['alt']);scores.append(int(score[1]))
    if scores[0]==scores[1]:raise ValueError('Tied final NHL result')
    venue=re.search(r'Attendance\s+[\d,]+\s+at\s+(.*?)\s+Start',text)
    start=re.search(r'Start\s+(\d{1,2}:\d{2})\s+([A-Z]+)',text)
    kind={'01':'Preseason','02':'Regular Season','03':'Playoffs'}.get(code[:2])
    return dict(provider='NHL official',league='NHL',date=date,official_game_id=season[:4]+code,teams=teams,scores=scores,winner=teams[int(scores[1]>scores[0])],location=venue[1] if venue else None,home_away='Away;Home',competition_type=kind,is_training=code.startswith('01'),start_clock=start[1] if start else None,start_zone=start[2] if start else None,source_url=f'https://www.nhl.com/scores/htmlreports/{season}/GS{code}.HTM',request_id=rid)

def tasks(kind,dates,seasons):
    if kind=='mlb':return [(date,'https://www.mlb.com/scores/'+date) for date in sorted(dates)]
    result=[]
    for season in seasons:
        # Both 2024-25 and 2025-26 official schedules contain 1,312 regular games.
        for n in range(1,1313):result.append(((season,f'02{n:04d}'),f'https://www.nhl.com/scores/htmlreports/{season}/GS02{n:04d}.HTM'))
        for rnd,series in [(1,8),(2,4),(3,2),(4,1)]:
            for matchup in range(1,series+1):
                for game in range(1,8):
                    code=f'030{rnd}{matchup}{game}';result.append(((season,code),f'https://www.nhl.com/scores/htmlreports/{season}/GS{code}.HTM'))
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--kind',choices=['mlb','nhl'],required=True);ap.add_argument('--limit',type=int);ap.add_argument('--from-date',default='2024-01-01');ap.add_argument('--through-date',default=dt.date.today().isoformat());args=ap.parse_args()
    db=sqlite3.connect(DB);games=[json.loads(x[0]) for x in db.execute('SELECT body FROM _history_games')];db.close()
    dates={g['date'] for g in games if g['league']==args.kind.upper() and args.from_date<=g['date']<=args.through_date}
    seasons=sorted({str(int(d[:4])-(d[5:7]<'07'))+str(int(d[:4])+(d[5:7]>='07')) for d in dates})
    todo=tasks(args.kind,dates,seasons);todo=todo[:args.limit] if args.limit else todo;c=HistoryClient();out=[];errors=[]
    def fetch(job):
        key,url=job
        try:
            b,r=c.get(url,document=True);items=mlb_scoreboard(b,key,r['request_id']) if args.kind=='mlb' else [nhl_summary(b,*key,r['request_id'])]
            return [x for x in items if x],None
        except Exception as e:return [],dict(key=key,url=url,error=str(e))
    # Small pool and explicit host rate configured by invoking command.
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for n,(items,error) in enumerate(pool.map(fetch,todo),1):
            out.extend(items)
            if error:errors.append(error)
            if n%50==0 or n==len(todo):print('OFFICIAL',args.kind,n,len(todo),'final games',len(out),'issues',len(errors),flush=True)
    db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _official_game_reports (league TEXT NOT NULL,official_game_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(league,official_game_id)) STRICT')
    for x in out:db.execute('INSERT OR REPLACE INTO _official_game_reports VALUES (?,?,?)',(x['league'],x['official_game_id'],json.dumps(x)))
    db.commit();db.close();(ROOT/'reports'/f'official_{args.kind}_acquisition.json').write_text(json.dumps(dict(requested=len(todo),final_games=len(out),new_requests=c.requests,errors=errors),indent=2),encoding='utf-8')

if __name__=='__main__':main()
