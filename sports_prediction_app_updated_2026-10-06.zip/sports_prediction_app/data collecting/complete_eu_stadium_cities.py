"""Retain and verify four outstanding official Spanish stadium-city bindings."""
import datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from urllib.parse import urlsplit
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS

def main():
 db=sqlite3.connect(DB,timeout=60);c=HistoryClient();proofs=[]
 urls={
  'betis':'https://www.realbetisbalompie.es/club/la-cartuja',
  'barcelona':'https://www.fcbarcelona.com/en/card/1649624/what-is-the-estadi-johan-cruyff-like',
  'mallorca':'https://www.rcdmallorca.es/videos/daredevil-x-rcd-mallorca-ya-disponible-la-segunda-temporada-de-daredevil-lgytt7atwho'}
 docs={}
 for key,url in urls.items():
  HOSTS.add(urlsplit(url).hostname);raw,r,redirects=get(c,url);soup=BeautifulSoup(raw,'html.parser');text=' '.join(soup.stripped_strings);docs[key]=(r,text);row=dict(url=url,request_id=r['request_id'],redirects=redirects)
  with db:db.execute('INSERT OR REPLACE INTO _eu_location_documents VALUES (?,?)',(url,json.dumps(row)))
 def review(key,names,city,proof,extra=None):
  r,text=docs[key];assert all(p in text for p in proof),(key,proof);body=dict(competition_code='LAL',venue_names=names,city=city,country='ES',request_id=r['request_id'],pointer='Official stadium article text',latitude=None,longitude=None,method='Literal official stadium name and city; dated game stadium must match',evidence_phrases=proof,additional_source=extra);proofs.append(('LAL','review:'+names[0],json.dumps(body)))
 review('betis',['Estadio La Cartuja'],'Sevilla',['Estadio La Cartuja','ciudad de Sevilla'])
 review('betis',['Estadio Benito Villamarín'],'Sevilla',['Estadio Benito Villamarín','41012 Sevilla'])
 review('barcelona',['Estadi Johan Cruyff'],'Sant Joan Despí',['Estadi Johan Cruyff','Sant Joan Despí'])
 row=json.loads(db.execute('SELECT body FROM _official_laliga_club_location_sources WHERE team_id=?',('33',)).fetchone()[0]);meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(row['request_id'],)).fetchone()[0]);raw=(ROOT/meta['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==meta['sha256'];script=re.search(rb'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',raw,re.S);club=json.loads(script[1])['props']['pageProps']['club'];assert club==row['club'] and 'Palma de Mallorca' in club['address'] and 'Son Moix' in club['venue']['name']
 review('mallorca',['Estadio Daredevil Son Moix'],'Palma de Mallorca',['Daredevil','Son Moix'],dict(request_id=row['request_id'],pointer='/props/pageProps/club/address',raw_address=club['address'],venue=club['venue']))
 with db:db.executemany('INSERT OR REPLACE INTO _eu_stadium_location_reviews VALUES (?,?,?)',proofs)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',stadiums_reviewed=len(proofs),new_requests=c.requests,limits='City and stadium identity only; no new public location columns. Postal address establishes geography, not historical team affiliation.');(ROOT/'reports/eu_remaining_stadium_cities.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
