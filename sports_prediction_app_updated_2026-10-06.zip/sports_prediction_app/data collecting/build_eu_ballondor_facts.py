"""Original France Football award Top 10, as published by co-organizer UEFA."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_nba_ranking_facts import objects
from collect_laliga_people import namekey
from probe_history import ROOT
from install_eu_goal_rankings import CLUBS
def date(value):return dt.datetime.strptime(value.replace('\u202f',' '),'%m/%d/%Y %I:%M:%S %p %z').date().isoformat()
db=sqlite3.connect(DB,timeout=60);people={p:json.loads(b) for p,b in db.execute('SELECT * FROM _eu_people_registry')};aliases=collections.defaultdict(set);games=collections.defaultdict(list);rows=[];editions=[]
for b, in db.execute('SELECT body FROM _eu_player_game_facts'):
 p=json.loads(b);games[p['player_id']].append(p)
for pid,p in people.items():
 if p['kind']=='player' and pid in games:
  for n in p['aliases']:aliases[namekey(n)].add(pid)
for b, in db.execute("SELECT body FROM _eu_editorial_sources WHERE json_extract(body,'$.publisher')='france_football'"):
 source=json.loads(b);meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(source['request_id'],)).fetchone()[0]);raw=(ROOT/meta['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==meta['sha256'];soup=BeautifulSoup(raw,'html.parser');a=next(a for a in objects(source['metadata']['structured']) if a.get('@type')=='NewsArticle');pub=date(a['datePublished']);version=max(pub,date(a.get('dateModified',a['datePublished'])));eid='EU_FRANCE_FOOTBALL_'+pub;found=[]
 for index,el in enumerate(soup.select('p')):
  text=el.get_text(' ',strip=True)
  if not text.startswith('1.') or '10.' not in text:continue
  for m in re.finditer(r'(\d+)\.\s*(.+?)\s*\(([^,]+),\s*(.+?)\)(?=\s*\d+\.|$)',text):
   line=m[0]
   if not m:continue
   rank=int(m[1]);name=m[2];club=m[4];clubs={CLUBS.get(t.strip(),t.strip()) for t in club.split('/')};clubs={('FC Bayern München' if c=='Bayern München' else c) for c in clubs};candidates={pid for pid in aliases[namekey(name)] if any(g['team_name'] in clubs and g['game_date']<=version for g in games[pid])};assert len(candidates)==1,(name,sorted(candidates),sorted(aliases[namekey(name)]));pid=next(iter(candidates));found.append(dict(list_id=eid,publisher_key='france_football',league='EU soccer',scope='European subset of global overall top ten',publication_date=pub,version_verified_date=version,rank=rank,source_player_name=name,source_club=club,player_id=pid,player_name=people[pid]['person_name'],request_id=source['request_id'],source_url=source['url'],selector='p',index=index,raw_value=el.get_text(' ',strip=True),raw_rank_fragment=line,source_scope='Worldwide Ballon d’Or; all ten preceding ranks verified to be in the collected European competition population.'))
 assert len(found)==10 and {r['rank'] for r in found}==set(range(1,11)),(eid,len(found));rows+=found;editions.append(dict(list_id=eid,publisher_key='france_football',league='EU soccer',scope='European subset of global overall top ten',publication_date=pub,version_verified_date=version,complete_list=False,request_id=source['request_id'],note='Original France Football/Groupe Amaury award ranking, published by official co-organizer UEFA. Every global top-ten player is verified in the collected EU population, so these ten ordinals also hold within that population. No ranks beyond ten inferred; nominee lists are not ordinal ranks. France Football and L’Équipe count as one publishing group.'))
with db:
 db.execute("DELETE FROM _eu_ranking_candidate_facts WHERE json_extract(body,'$.publisher_key')='france_football'");db.executemany('INSERT INTO _eu_ranking_candidate_facts VALUES (?)',[(json.dumps(r),) for r in rows]);db.executemany('INSERT OR REPLACE INTO _eu_ranking_candidate_editions VALUES (?,?)',[(e['list_id'],json.dumps(e)) for e in editions])
print(json.dumps(dict(status='CANDIDATES_REQUIRE_INDEPENDENT_VALIDATION',facts=len(rows),editions=len(editions))));db.close()
