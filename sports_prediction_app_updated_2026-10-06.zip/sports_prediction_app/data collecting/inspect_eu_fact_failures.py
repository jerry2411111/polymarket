import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB);r=json.loads((ROOT/'reports/eu_source_player_facts_months.json').read_text());print('ISSUE GROUPS',json.dumps([dict(competition=c,field=f,reason=reason,count=n) for (c,f,reason),n in collections.Counter((i['competition'],i['field'],i['reason']) for i in r['issues']).items()]));print('MISSING',json.dumps(r['missing']))
for item in [i for i in r['issues'] if i['field']=='event_derivation'][:10]:
 p=json.loads(db.execute('SELECT body FROM _eu_source_player_game_facts WHERE game_id=? LIMIT 1',(item['game_id'],)).fetchone()[0]);code=item['competition'];table='uefa' if code=='UCL' else 'seriea';report=json.loads(db.execute('SELECT body FROM _official_'+table+'_game_reports WHERE match_id=?',(p['official_match_id'],)).fetchone()[0]);print('FAILURE',json.dumps(item))
 if code=='UCL':
  for e in report['sources']['events']['data']:
   if e['type'] in ['SUBSTITUTION','RED_CARD','RED_YELLOW_CARD','ASSIST'] and not e.get('primaryActor',{}).get('person',{}).get('id'):
    actor=e.get('primaryActor',{});q=actor.get('person',{});who=q.get('person',{});print('STAFF ACTOR',json.dumps(dict(event_id=e['id'],actor_fields=list(actor),wrapper_fields=list(q),wrapper_role=q.get('role'),wrapper_type=q.get('type'),actor_role=actor.get('role'),actor_type=actor.get('type'),person_id=who.get('id'),name=who.get('translations',{}).get('name',{}).get('EN'))))
 else:
  for e in report['sources']['feed']['data']['events']:
   if e['type']=='substitution':
    for side in ['away','home']:
     if e.get(side) and not (e[side].get('player',{}).get('relatedPlayerId') and e[side].get('player',{}).get('playerId')):print('SUB IDS',json.dumps({k:e.get(k) for k in ['eventId','type','description','timeStamp']}))
db.close()
