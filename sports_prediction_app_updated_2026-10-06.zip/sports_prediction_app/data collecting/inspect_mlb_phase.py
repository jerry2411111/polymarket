﻿import sqlite3,json,collections
from build_history_catalog import DB
db=sqlite3.connect(DB)
for name in ['_history_games','_official_game_facts','_history_contracts','_history_price_points']:
 if name in ['_history_contracts','_history_price_points']:print(name,db.execute('SELECT count(*) FROM '+name).fetchone()[0]);continue
 xs=[json.loads(b) for (b,) in db.execute('SELECT body FROM '+name)];xs=[x for x in xs if x.get('league')=='MLB'];print(name,'n',len(xs),'dates',min(x['date'] for x in xs),max(x['date'] for x in xs),'years',collections.Counter(x['date'][:4] for x in xs));print('first',xs[0])
for p in ['polymarket','kalshi']:
 rows=db.execute('SELECT substr(date,1,4),count(*),min(date),max(date) FROM '+p+"_pre_match WHERE league='MLB' GROUP BY substr(date,1,4)").fetchall();print(p,rows)
print('existing raw requests',db.execute("SELECT request_type,count(*) FROM _request_audit WHERE requested_data LIKE '%MLB%' GROUP BY request_type").fetchall())
