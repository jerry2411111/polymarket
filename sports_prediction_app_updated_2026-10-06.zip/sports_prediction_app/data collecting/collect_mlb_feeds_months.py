"""Acquire official game/player reports only for matched market game candidates."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,sqlite3
from history_client import HistoryClient
from mlb_official_api import feed
from build_history_catalog import DB
from probe_history import ROOT

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--max-new-months',type=int);a=ap.parse_args();db=sqlite3.connect(DB,timeout=60)
    gs=[json.loads(b) for (b,) in db.execute('SELECT body FROM _mlb_canonical_games')];schedules={n:json.loads(b) for n,b in db.execute('SELECT * FROM _official_mlb_schedule')};by_month=collections.defaultdict(list)
    for g in gs:by_month[g['date'][:7]].append(g)
    client=HistoryClient();path=ROOT/'reports/mlb_feed_months.json';old=json.loads(path.read_text()) if path.exists() else {};done={x['month']:x for x in old.get('months',[]) if x['status']=='WORKING'};parts=[];processed=0;day=dt.date(2024,1,1);end=dt.date(2026,9,14)
    def get(g):
        try:return g,feed(client,schedules[g['official_game_id']]),None
        except Exception as e:return g,None,str(e)
    while day<=end:
        month=day.strftime('%Y-%m');last=min(day.replace(day=calendar.monthrange(day.year,day.month)[1]),end);wanted=sorted(by_month[month],key=lambda g:(g['date'],g['game_id']))
        if month in done and done[month]['candidate_native_ids']==sorted(g['official_game_id'] for g in wanted):parts.append(done[month]);day=last+dt.timedelta(days=1);continue
        if a.max_new_months and processed>=a.max_new_months:break
        errors=[];count=0;players=0;played=0
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            for g,f,error in pool.map(get,wanted):
                if error:errors.append(dict(game_id=g['game_id'],official_game_id=g['official_game_id'],error=error));continue
                db.execute('INSERT OR REPLACE INTO _official_mlb_feeds VALUES (?,?)',(g['official_game_id'],json.dumps(f)));db.commit();count+=1;players+=len(f['players']);played+=sum(p['did_play'] for p in f['players'])
        row=dict(month=month,status='WORKING' if not errors else 'PARTIALLY WORKING',candidate_games=len(wanted),candidate_native_ids=sorted(g['official_game_id'] for g in wanted),verified_feeds=count,player_roster_rows=players,played_player_rows=played,errors=errors);parts.append(row);processed+=1
        out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Official MLB reports for matched market games; usable odds eligibility is a later check',total_months=33,completed_months=sum(x['status']=='WORKING' for x in parts),months=parts,new_requests_in_this_run=client.requests);path.write_text(json.dumps(out,indent=2),encoding='utf-8');print('MLB REPORT MONTH',month,'games',count,'/',len(wanted),'played rows',played,'errors',len(errors),'months',out['completed_months'],'/33',flush=True)
        if errors:break
        day=last+dt.timedelta(days=1)
    db.close()

if __name__=='__main__':main()
