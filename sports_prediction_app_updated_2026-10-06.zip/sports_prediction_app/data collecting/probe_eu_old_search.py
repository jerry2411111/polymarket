"""Bounded independent official search cross-check of older sports discovery."""
import argparse,datetime as dt,json,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT
ap=argparse.ArgumentParser();ap.add_argument('--all-pages',action='store_true');a=ap.parse_args();c=HistoryClient();doc,dr=c.get('https://docs.polymarket.com/api-reference/search/search-markets-events-and-profiles.md',document=True);assert b'keep_closed_markets' in doc and b'public-search' in doc;db=sqlite3.connect(DB);known={str(r[0]) for r in db.execute('SELECT event_id FROM _eu_pm_event_sources')};reports=[];rows=[]
for q in ['Barcelona','Bayern','Juventus','Paris Saint-Germain','Manchester City']:
 page=1;seen=set();old=[];pages=[]
 while True:
  params=dict(q=q,events_status='closed',keep_closed_markets=1,limit_per_type=50,page=page,sort='endDate',ascending='true',search_profiles='false',search_tags='false');d,r=c.get('https://gamma-api.polymarket.com/public-search',params);events=d.get('events') or [];new={str(e['id']) for e in events}-seen;assert new or not d.get('pagination',{}).get('hasMore'),'Pagination repeated without progress';seen.update(new)
  for i,e in enumerate(events):
   date=(e.get('endDate') or '')[:10]
   if str(e['id']) in new and date and '2024-01-01'<=date<'2025-01-01':old.append(dict(event_id=e['id'],title=e['title'],date=date,already_discovered=str(e['id']) in known));rows.append((q,str(e['id']),json.dumps(dict(request_id=r['request_id'],pointer='/events/'+str(i),event=e))))
  pages.append(dict(page=page,request_id=r['request_id'],events=len(events),pagination=d.get('pagination')))
  if not a.all_pages or not d.get('pagination',{}).get('hasMore'):break
  page+=1;assert page<=100,'Bounded search cap exceeded'
 reports.append(dict(query=q,events=len(seen),pages=pages,old_events=old,exhausted=not d.get('pagination',{}).get('hasMore')));print('OFFICIAL SEARCH',q,'events',len(seen),'pages',page,'old',len(old),'new_old',sum(not e['already_discovered'] for e in old),'exhausted',reports[-1]['exhausted'],flush=True)
with db:
 db.execute('CREATE TABLE IF NOT EXISTS _eu_search_discovery (query TEXT,event_id TEXT,body TEXT NOT NULL,PRIMARY KEY(query,event_id)) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_search_discovery VALUES (?,?,?)',rows)
(ROOT/'reports/eu_old_search_probe.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),documentation_url='https://docs.polymarket.com/api-reference/search/search-markets-events-and-profiles',documentation_request_id=dr['request_id'],scope='Five team-name search cross-checks; even exhausted search results do not establish all-league discovery completeness',queries=reports,new_requests=c.requests),indent=2),encoding='utf-8');db.close()
