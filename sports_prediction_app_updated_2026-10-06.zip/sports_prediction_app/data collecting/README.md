# Data collection and historical reconstruction

The collection scripts are included in this folder. Run commands from the project root after dependency installation and `prepare_storage.ps1`. The directory layout matches the reference source archive; current NHL/soccer support is also included in `nhl_soccer_iteration/` and `soccer_nhl_granular/`.

## Automatic collection in the app

Run `Open Sports App.cmd` or `sports_app/launch.ps1`. NBA/MLB completed-game updates are handled by `sports_app/lifecycle.py`, with schedules, lineups, features and rolling training in the adjoining application modules. The app starts `sports_app/live_worker.py` for NHL/soccer schedule catch-up, completed reports and model preparation. These collectors do not require a trading account or LIVE execution to be enabled. Collection status is available at `/api/collection/status`.

The current app uses Polymarket US for live markets. Historical research tools retain their original provider-specific sources. Starting the collector does not reconstruct every historical dataset immediately; a new installation needs the retained assets listed in `DATA_REQUIREMENTS.md` at the project root.

## Historical collection stages

| Purpose | Included scripts |
| --- | --- |
| Find historical games and contracts | `discover_history.py`, `discover_polymarket.py`, league-specific `discover_*.py` |
| NBA schedules and official facts | `collect_nba_schedule.py`, `collect_nba_game_pages.py`, `collect_nba_gamebooks.py` and associated parsers/builders |
| MLB schedules, reports and dated histories | `collect_mlb_schedule_months.py`, `collect_mlb_feeds_months.py`, `collect_mlb_player_histories.py`, `collect_mlb_transactions_months.py` |
| NHL schedules and official reports | `collect_nhl_schedule_months.py`, `collect_nhl_game_reports.py`, `collect_nhl_player_game_logs.py`, and `nhl_soccer_iteration/` support |
| Soccer calendars and reports | `collect_premier_calendar.py`, `collect_laliga_calendar.py`, `collect_bundesliga_calendar.py`, `collect_seriea_calendar.py`, `collect_ligue1_calendar.py`, `collect_uefa_calendar.py`, and league report collectors |
| Historical odds and checkpoints | `collect_history.py`, league-specific price collectors, `collect_eu_checkpoint_prices.py` |
| Normalize and publish retained facts | `parse_*.py`, `build_*.py`, `refresh_revision_outputs.py`, `generate_data_catalog.py` |
| Query dated results | `query_sql.py` |

Each stage has specific source/table dependencies. Review its arguments and prerequisite tables; the scripts are not a batch to run alphabetically. Preserve original responses under `collected data/raw/` and normalized tables under `collected data/result/`, including actual observation times. The `data` junction points to the same storage for historical tools.

Example argument inspection and a query against prepared data:

```powershell
./final_models/.venv/Scripts/python.exe 'data collecting/collect_history.py' --help
./final_models/.venv/Scripts/python.exe 'data collecting/query_sql.py' --table player_performance --date 2025-07-01
```

Set request limits through process environment variables using the root `.env.example` as a reference. The source ZIP contains neither acquired datasets nor private trading records.
