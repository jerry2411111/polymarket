"""Load only retained EPL price requests and preserve exact native field provenance."""
import collections,concurrent.futures,hashlib,json,math
from probe_history import ROOT

def pointer(data,path):
    for key in path.strip('/').split('/') if path!='/' else []:data=data[int(key)] if isinstance(data,list) else data[key]
    return data

class Sources:
    def __init__(self,db):self.db=db;self.cache={}
    def get(self,rid):
        if rid not in self.cache:
            r=json.loads(self.db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert r['status']==200 and hashlib.sha256(b).hexdigest()==r['sha256'];self.cache[rid]=(json.loads(b),r)
        return self.cache[rid]
    def prefetch(self,request_ids):
        pending=sorted(set(request_ids)-self.cache.keys())
        def read(item):
            rid,text=item;r=json.loads(text);b=(ROOT/r['raw_file']).read_bytes();assert r['status']==200 and hashlib.sha256(b).hexdigest()==r['sha256'];return rid,(json.loads(b),r)
        # Only immutable retained files are read concurrently. The SQLite
        # connection and acquisition/request logs stay in the calling thread.
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            for start in range(0,len(pending),500):
                batch=pending[start:start+500];records=list(self.db.execute('SELECT request_id,metadata_json FROM _request_audit WHERE request_id IN ('+','.join('?' for _ in batch)+')',batch));assert len(records)==len(batch)
                for rid,value in pool.map(read,records):self.cache[rid]=value

def load(db,contracts,sources,acquisition_tables=None):
    grouped=collections.defaultdict(list);points={};seen=set();conflicts=[];excluded=collections.Counter()
    if acquisition_tables is None:
        acquisition_tables=['_epl_price_acquisition']
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='_epl_polymarket_asof'").fetchone():acquisition_tables.append('_epl_polymarket_asof')
    assert all(t in ['_epl_price_acquisition','_epl_polymarket_asof','_eu_price_acquisition','_eu_polymarket_asof'] for t in acquisition_tables)
    query=' UNION ALL '.join('SELECT body FROM '+t for t in acquisition_tables)
    jobs=[job for body, in db.execute(query) if (job:=json.loads(body))['status']=='ok' and (job['provider'],job['contract_id']) in contracts]
    sources.prefetch(rid for job in jobs for rid in job['request_ids'])
    for job in jobs:
        key=(job['provider'],job['contract_id'])
        for rid in job['request_ids']:
            if rid in seen:continue
            seen.add(rid);data,r=sources.get(rid);provider,cid=key
            if provider=='kalshi':
                assert data['ticker']==cid and r['endpoint'].split('/markets/')[1].split('/')[0]==cid;items=data['candlesticks'];suffix='close' if '/historical/' in r['endpoint'] else 'close_dollars'
            else:assert r['parameters']['token_id']==cid;items=data['data']
            for i,v in enumerate(items):
                if provider=='kalshi':
                    p=v.get('yes_bid',{}).get(suffix);ask=v.get('yes_ask',{}).get(suffix);ts=v['end_period_ts'];resolution=r['parameters']['period_interval']*60;kind='candle';path=f'/candlesticks/{i}/yes_bid/{suffix}'
                    if p is not None and ask is not None and float(p)>float(ask):conflicts.append(dict(request_id=rid,pointer=path,reason='Crossed bid/ask'));continue
                else:p=v.get('price');ts=v['timestamp'];resolution=v['resolution_seconds'];kind='v2';path=f'/data/{i}/price'
                if p is None:excluded['null_price']+=1;continue
                if kind=='v2' and resolution==0:excluded['ambiguous_terminal_resolution_points']+=1;continue
                # A query cutting through a native bucket can return a partial
                # average under the same timestamp. Do not compare or select
                # that as the complete bucket from a different request window.
                if kind=='v2' and (ts<r['parameters'].get('start',ts) or ts+resolution>r['parameters'].get('end',ts+resolution)):
                    excluded['query_boundary_partial_buckets']+=1;continue
                p=float(p);assert math.isfinite(p) and 0<=p<=1 and isinstance(ts,int)
                x=dict(provider=provider,contract_id=cid,timestamp=ts,price=p,resolution_seconds=resolution,kind=kind,request_id=rid,pointer=path,retrieved_at_utc=r['retrieved_at_utc']);pk=provider,cid,ts,resolution,kind;old=points.get(pk)
                if old and old['price']!=p:conflicts.append(dict(reason='Source observation revision',old=old,new=x))
                if old and old['retrieved_at_utc']>=x['retrieved_at_utc']:continue
                points[pk]=x
    for x in points.values():grouped[x['provider'],x['contract_id']].append(x)
    return grouped,conflicts,dict(excluded)
