"""Bounded inspection of retained official lineup and event schemas."""
import collections,json,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources
from probe_history import ROOT
from probe_eu_official_reports import brief

def main():
 db=sqlite3.connect(DB);src=Sources(db);report=json.loads((ROOT/'reports/seriea_game_details_pilot.json').read_text())
 for row in report['rows']:
  if row.get('status')!=200:continue
  d,_=src.get(row['request_id']);print('SOURCE',row['date'],row['kind'],row['request_id'])
  if row['kind']=='lineups':
   for side in ['away','home']:
    for key in ['fielded','benched','staff']:
     xs=d[side][key];print(side,key,len(xs),json.dumps(xs[0] if xs else None,ensure_ascii=False)[:2200])
  if row['kind']=='feed':
   print('PAGINATION',d['pagination'],'TYPES',dict(collections.Counter(e['type'] for e in d['events'])))
   shown=set()
   for e in d['events']:
    if e['type'] not in shown:print('EVENT',json.dumps(e,ensure_ascii=False)[:2000]);shown.add(e['type'])
 db.close()

if __name__=='__main__':main()
