"""Follow a small set of actual official frontend module references."""
import datetime as dt,json,sqlite3
from urllib.parse import urljoin,urlsplit
from bs4 import BeautifulSoup
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT,HOSTS

def main():
    client=HistoryClient();db=sqlite3.connect(DB);sources=json.loads((ROOT/'reports/eu_soccer_pages_sources.json').read_text())['sources'];urls=['https://www.premierleague.com/resources/v1.52.5/scripts/match-list-root.js','https://www.premierleague.com/resources/v1.52.5/scripts/match-centre.js','https://www.premierleague.com/resources/v1.52.5/scripts/filters-constants.js','https://www.uefa.com/CompiledAssets/UefaCom/js/86718.9954228f.js'];out=[]
    for source in sources:
        if not any(t in source['url'] for t in ['bundesliga','uefa.com']):continue
        r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(source['request_id'],)).fetchone()[0]);soup=BeautifulSoup((ROOT/r['raw_file']).read_text(encoding='utf-8'),'html.parser')
        if 'bundesliga' in source['url']:urls.extend(u for u in source['scripts'] if '/main-' in u)
        else:
            for t in soup.find_all(attrs={'data-src':True}):
                if '.js' in t['data-src']:urls.append(urljoin(source['url'],t['data-src']))
            for t in soup.find_all(attrs={'data-href':True}):
                if '.js' in t['data-href']:urls.append(urljoin(source['url'],t['data-href']))
    for url in dict.fromkeys(urls):
        HOSTS.add(urlsplit(url).hostname)
        try:b,r=client.get(url,document=True);out.append(dict(url=url,request_id=r['request_id'],bytes=len(b)));print(json.dumps(out[-1]),flush=True)
        except Exception as e:out.append(dict(url=url,error=str(e)));print(json.dumps(out[-1]),flush=True)
    (ROOT/'reports/eu_soccer_client_modules.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=out),indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
