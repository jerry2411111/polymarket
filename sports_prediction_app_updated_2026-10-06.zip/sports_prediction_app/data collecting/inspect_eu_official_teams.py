"""Bounded inspection of official club identity schemas, preserving native fields."""
import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for comp,t in [('LaLiga','laliga'),('Bundesliga','bundesliga'),('Ligue 1','ligue1'),('Serie A','seriea'),('UEFA Champions League','uefa')]:
 g=json.loads(db.execute('SELECT body FROM _official_'+t+'_calendar LIMIT 1').fetchone()[0]);print(json.dumps(dict(competition=comp,away=g['away'],home=g['home'],raw_other={k:v for k,v in g['raw'].items() if any(x in k.lower() for x in ['venue','stadium','time','city'])}),ensure_ascii=False)[:5000])
for b, in db.execute('SELECT body FROM _official_ligue1_calendar'):
 g=json.loads(b)
 for s in ['away','home']:
  if 'shortId' not in g[s]:print('MISSING LIGUE 1 SHORT ID',json.dumps(dict(match_id=g['official_match_id'],team=g[s]),ensure_ascii=False))
 if any('shortId' not in g[s] for s in ['away','home']):break
db.close()
