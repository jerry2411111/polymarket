"""Small quote windows at verified kickoffs and breaks, in calendar-date batches."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT
from eu_verified_details import details
from eu_official_games import games,CONFIG
from core import utc
from collect_eu_pregame_prices import K

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['kickoff','break'],default='kickoff');ap.add_argument('--through-percent',type=int,default=10);ap.add_argument('--pilot',action='store_true');a=ap.parse_args();assert 0<a.through_percent<=100;db=sqlite3.connect(DB,timeout=60);ds=details(db);gs={code:games(db,code) for code in CONFIG};c=HistoryClient();cutoff,cr=c.get(K+'/historical/cutoff',refresh=True);cut=utc(cutoff['market_settled_ts']);done={k:json.loads(b) for k,b in db.execute('SELECT job_key,body FROM _eu_price_acquisition') if json.loads(b)['status']=='ok'};by_month=collections.defaultdict(list);missing=collections.Counter();pilot_games={}
 for code,b in db.execute('SELECT competition,body FROM _eu_validated_contracts'):
  m=json.loads(b);g=gs[code][m['official_match_id']];d=ds.get((code,m['official_match_id']),{});clock=d.get('clock',{});s=utc(clock.get('actual_start_utc'))
  if not s:missing[code]+=1;continue
  if a.pilot:
   if g['date'][:7]!='2025-09':continue
   group=code,m['provider'];pilot_games.setdefault(group,m['game_id'])
   if m['game_id']!=pilot_games[group]:continue
  start=s.timestamp();scheduled=utc(g['scheduled_start_utc']).timestamp()
  if a.mode=='kickoff':
   # A short final window supplements the broad hourly history. Polymarket
   # windows include a full native 3-hour bucket so partial averages are never
   # selected as observations that existed before kickoff.
   if m['provider']=='kalshi':windows=[('pre_0',math.floor(start)-3660,math.ceil(start),1)]
   elif start>scheduled:windows=[('pre_0',math.floor(scheduled/10800)*10800-10800,math.ceil(start),3600)]
   else:windows=[]
  else:
   windows=[('START',math.floor(start)-60,math.ceil(start+120),1)];hs=utc(clock.get('halftime_start_utc'));rs=utc(clock.get('second_half_start_utc'))
   if hs and rs:windows.extend([('HALFTIME',math.floor(hs.timestamp())-60,math.ceil(rs.timestamp()),1),('SECOND_HALF_START',math.floor(rs.timestamp())-60,math.ceil(rs.timestamp()+120),1)])
  for name,lo,hi,res in windows:by_month[g['date'][:7]].append((m,name,lo,hi,res))
 def fetch(job):
  m,name,lo,hi,res=job;cid=m['contract_id'];p=m['provider'];key=f'{a.mode}:{p}:{cid}:{name}:{lo}:{hi}:{res}';ids=[]
  if key in done:return key,done[key]
  row=dict(competition=m['competition'],provider=p,contract_id=cid,game_id=m['game_id'],official_match_id=m['official_match_id'],mode=a.mode,checkpoint=name,start_ts=lo,end_ts=hi,boundary_basis='verified_official_game_clock',request_ids=ids)
  try:
   if p=='kalshi':
    archive=utc(m['settled'])<cut;path='/historical/markets/'+cid+'/candlesticks' if archive else '/series/'+m['series']+'/markets/'+cid+'/candlesticks';data,r=c.get(K+path,dict(start_ts=lo,end_ts=hi,period_interval=res));ids.append(r['request_id']);assert data['ticker']==cid;xs=data['candlesticks'];field='close' if archive else 'close_dollars'
    for x in xs:
     bid=x.get('yes_bid',{}).get(field);ask=x.get('yes_ask',{}).get(field);assert bid is None or 0<=float(bid)<=1;assert ask is None or 0<=float(ask)<=1;assert bid is None or ask is None or float(bid)<=float(ask)
    row.update(rows=len(xs),resolutions=[res*60],route='historical' if archive else 'recent',price_key=field,cutoff_request_id=cr['request_id'])
   else:
    params=dict(token_id=cid,start=lo,end=hi,bucket_seconds=3600 if a.mode=='kickoff' else 60,limit=10000);total=0;resolutions=set();cursors=set()
    for page in range(20):
     data,r=c.get('https://data-api.polymarket.com/v2/prices-history',params);ids.append(r['request_id']);xs=data['data']
     for x in xs:assert isinstance(x['timestamp'],int) and 0<=x['price']<=1;resolutions.add(x['resolution_seconds'])
     total+=len(xs);cursor=data.get('pagination',{}).get('next_cursor')
     if not cursor:assert not data.get('pagination',{}).get('has_more');break
     assert cursor not in cursors;cursors.add(cursor);params['cursor']=cursor
    else:raise ValueError('Unexhausted price pagination')
    row.update(rows=total,resolutions=sorted(resolutions))
   row['status']='ok'
  except Exception as e:row.update(status='error',error=type(e).__name__+': '+str(e))
  return key,row
 day=dt.date(2024,1,1);parts=[];milestone=10
 while day<=dt.date(2026,9,14) and (a.pilot or len(parts)<math.ceil(33*a.through_percent/100)):
  month=day.strftime('%Y-%m');counts=collections.Counter();errors=[];rows=0
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
   for key,row in pool.map(fetch,by_month[month]):
    if key not in done:
     with db:db.execute('INSERT OR REPLACE INTO _eu_price_acquisition VALUES (?,?,?)',(key,row['competition'],json.dumps(row)))
    counts[row['status']]+=1;rows+=row.get('rows',0)
    if row['status']=='error':errors.append(row)
    elif not row['rows']:counts['empty']+=1
  parts.append(dict(month=month,jobs=len(by_month[month]),rows=rows,counts=dict(counts),errors=errors));out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='EU verified '+a.mode+' quote windows',pilot=a.pilot,processed_months=len(parts),total_months=33,missing_official_clock_contracts=dict(missing),new_requests=c.requests,cutoff=cutoff,cutoff_request_id=cr['request_id'],months=parts);(ROOT/'reports'/('eu_'+a.mode+'_prices_'+('pilot' if a.pilot else 'months')+'.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
  if counts:print('EU',a.mode,'MONTH',month,'jobs',len(by_month[month]),'rows',rows,dict(counts),'months',len(parts),'/33',flush=True)
  while not a.pilot and milestone<=100 and len(parts)>=math.ceil(33*milestone/100):print('EU',a.mode,'DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  if errors:break
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print('EU',a.mode,'NEW REQUESTS',c.requests,flush=True);db.close()

if __name__=='__main__':main()
