﻿import json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from history_index import index,records
x=index();rs={r['request_id']:r for r in records()}
for key,(m,rid,ptr) in x['milestones'].items():
 if m.get('details',{}).get('league')=='MLB' and '2025-05-23' in m.get('start_date','') and any('BALBOS' in e for e in m.get('primary_event_tickers',[])):print('MILESTONE',m)
ps=[(m,rid) for e,rid,ptr in x['polymarket_events'].values() if str(rs[rid]['parameters'].get('tag_id'))=='100381' for m in e.get('markets',[]) if m.get('sportsMarketType')=='moneyline'];print('MONEYLINE COUNT',len(ps));print('EXAMPLES', [{k:m.get(k) for k in ['id','question','slug','gameStartTime','outcomes','outcomePrices','groupItemTitle','sportsMarketType']} for m,rid in ps[-3:]])
