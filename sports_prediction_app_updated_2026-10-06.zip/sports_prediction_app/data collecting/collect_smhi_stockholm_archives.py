"""Acquire four official archives for the two otherwise missing Stockholm dates."""
import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

HOSTS.update({'opendata-download-metobs.smhi.se','www.smhi.se'});c=HistoryClient();meta=json.loads((ROOT/'reports/smhi_archive_metadata.json').read_text());out=[]
for a in meta['archives']:
    url=next(l['href'] for d in a['metadata']['data'] for l in d['link'] if l['type']=='text/plain')
    b,r=c.get(url,document=True);lines=b.decode('utf-8-sig').splitlines()
    print('SMHI ARCHIVE',a['parameter'],'bytes',len(b),'rows',len(lines),'header',lines[:12],flush=True)
    out.append(dict(parameter=a['parameter'],station_id=a['station_id'],url=url,request_id=r['request_id'],metadata_request_id=a['request_id'],bytes=len(b),header=lines[:12]))
report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=out,new_requests=c.requests,scope='Four published corrected archives; the documented download links expose the entire station/parameter archive. Only collected game dates will be normalized.')
(ROOT/'reports/smhi_stockholm_archives.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
