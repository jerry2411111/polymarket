"""Locate dated team-history validation discrepancies without rebuilding data."""
import collections,json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB);db.row_factory=sqlite3.Row
members=collections.defaultdict(list);facts=collections.defaultdict(list)
for b, in db.execute('SELECT body FROM _eu_player_memberships'):
 m=json.loads(b);members[m['player_id']].append(m)
for b, in db.execute('SELECT body FROM _eu_player_game_facts'):
 p=json.loads(b);facts[p['player_id']].append(p)
for day in ['2024-01-01','2024-08-16','2024-12-31','2025-05-25','2025-09-01','2025-12-31','2026-05-31','2026-09-14']:
 count=0
 for r in db.execute("SELECT player_id,player_name,served_team_history FROM player_profiles WHERE league='EU soccer' AND as_of_date=?",(day,)):
  prior={m['team_name'] for m in members[r['player_id']] if m['start_date'] and m['start_date']<=day}|{x['team_name'] for x in facts[r['player_id']] if x['game_date']<=day}
  bad=[t for t in (r['served_team_history'] or '').split(',') if t and t not in prior]
  if bad:
   count+=1
   if count<=3:print(json.dumps(dict(day=day,**dict(r),bad=bad,prior=sorted(prior)),ensure_ascii=False))
 print(day,'discrepancies',count)
