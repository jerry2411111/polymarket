"""Bounded raw calendar structure to identify official report links."""
import json,sqlite3
from build_history_catalog import DB
from probe_uefa_game_reports import shape
db=sqlite3.connect(DB)
for table in ['laliga','ligue1','bundesliga']:
 mid,b=db.execute('SELECT * FROM _official_'+table+'_calendar LIMIT 1').fetchone();g=json.loads(b);print(table,mid,'NORMALIZED',list(g));raw=g.get('raw') or g.get('source');print('RAW',json.dumps(shape(raw),ensure_ascii=False))
db.close()
