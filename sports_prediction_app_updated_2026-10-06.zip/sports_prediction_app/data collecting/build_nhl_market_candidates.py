"""Match NHL full-game winner contracts using official teams and scheduled dates.

Provider scores never establish identity or a winner. Settlements are compared
only after an independent native NHL schedule match.
"""
import collections,datetime as dt,itertools,json,re,sqlite3,unicodedata
from build_history_catalog import DB,clean,team_name,short
from history_index import index,records
from core import utc,array
from probe_history import ROOT
def clean(s):
 value=re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().lower())
 return 'unitedstates' if value in ['usa','teamusa'] else value

def main():
 data=index();rs={r['request_id']:r for r in records()};db=sqlite3.connect(DB,timeout=60);schedule={n:json.loads(b) for n,b in db.execute('SELECT * FROM _official_nhl_schedule')};aliases=collections.defaultdict(set);pairs=collections.defaultdict(list)
 for g in schedule.values():
  pairs[frozenset(g['official_team_ids'])].append(g)
  for side,s in enumerate(['awayTeam','homeTeam']):
   t=g['raw'][s];tid=str(t['id'])
   for name in [g['teams'][side],t.get('abbrev'),t.get('commonName',{}).get('default'),t.get('placeName',{}).get('default')]:
    if name:aliases[clean(name)].add(tid)
 for (body,) in db.execute('SELECT body FROM _polymarket_nhl_teams'):
  t=json.loads(body)['team'];ids=aliases[clean(t.get('name'))]
  if ids:
   for value in [t.get('abbreviation'),t.get('alias')]:
    if value:aliases[clean(value)].update(ids)
 evidence=json.loads((ROOT/'reports/nhl_identity_sources.json').read_text())
 postponement=next(r for r in evidence if 'blue-jackets-kings-game-postponed' in r['url']);assert all(term in postponement['text'] for term in ['January 26, 2026','Monday, March 9','Los Angeles Kings'])
 postponed=schedule['2025020828'];assert postponed['local_date']=='2026-03-09' and postponed['official_team_ids']==['26','29']
 provider_teams={}
 for pid,(t,rid,ptr) in data['teams'].items():
  if t['details'].get('league')!='NHL':continue
  found={next(iter(aliases[clean(n)])) for n in [team_name(t),t.get('name'),t['details'].get('team_name'),t['details'].get('short_name'),short(t)] if n and len(aliases[clean(n)])==1}
  if aliases[clean(short(t))]:provider_teams[pid]=set(aliases[clean(short(t))])
  elif len(found)==1:provider_teams[pid]=found
 def match(tids,start):
  if len(tids)!=2 or len(set(tids))!=2 or start is None:return None
  xs=[g for g in pairs[frozenset(tids)] if abs((utc(g['scheduled_start_utc'])-start).total_seconds())<=6*3600]
  if len(xs)>1:
   xs.sort(key=lambda g:abs((utc(g['scheduled_start_utc'])-start).total_seconds()));dist=[abs((utc(g['scheduled_start_utc'])-start).total_seconds()) for g in xs]
   if dist[0]<=15*60 and dist[1]-dist[0]>=60*60:xs=xs[:1]
  return xs[0] if len(xs)==1 else None
 def match_sets(sets,start):
  matches={g['official_game_id']:g for tids in itertools.product(*sets) if (g:=match(tids,start))}
  return next(iter(matches.values())) if len(matches)==1 else None
 # Rare preseason split-squad double games remain separate native identities.
 groups=collections.defaultdict(list)
 for g in schedule.values():groups[g['local_date'],*g['official_team_ids']].append(g)
 gids={}
 for group in groups.values():
  for n,g in enumerate(sorted(group,key=lambda g:(g['scheduled_start_utc'],g['official_game_id'])),1):gids[g['official_game_id']]='NHL_'+g['local_date'].replace('-','')+'_'+'_'.join(g['team_codes'])+('_G'+str(n) if len(group)>1 else '')
 events=collections.defaultdict(list);issues=[];contracts=[];used={};providers=collections.defaultdict(set)
 for mid,(m,rid,ptr) in data['milestones'].items():
  if m.get('details',{}).get('league')=='NHL':
   for eid in set(m.get('primary_event_tickers',[])+[m.get('details',{}).get('main_game_event_ticker','')]):
    if eid.startswith('KXNHLGAME-'):events[eid].append((m,rid,ptr))
 for ticker,(m,rid,ptr) in data['kalshi_markets'].items():
  if not ticker.startswith('KXNHLGAME-'):continue
  if m.get('result') not in ['yes','no']:issues.append(dict(provider='kalshi',market_id=ticker,reason='Non-binary or voided market result; not a completed win/loss contract',request_id=rid,raw_result=m.get('result')));continue
  found=[]
  for mile,mrid,mptr in events[m['event_ticker']]:
   teamsets=[provider_teams.get(mile['details'].get(k),set()) for k in ['away_team_id','home_team_id']];g=match_sets(teamsets,utc(mile['start_date']))
   if not g and m['event_ticker']=='KXNHLGAME-26JAN26LACBJ' and teamsets==[{'26'},{'29'}]:g=postponed
   if g:found.append((g,mile,mrid))
  if len({g['official_game_id'] for g,_,_ in found})!=1:issues.append(dict(provider='kalshi',market_id=ticker,reason='No unique official completed game from milestone',request_id=rid));continue
  g,mile,mrid=found[0];teamset=provider_teams.get((m.get('custom_strike') or {}).get('hockey_team'),set()) & set(g['official_team_ids'])
  if len(teamset)!=1:issues.append(dict(provider='kalshi',market_id=ticker,reason='YES outcome team not uniquely established',request_id=rid));continue
  tid=next(iter(teamset))
  side=g['official_team_ids'].index(tid);expected='yes' if g['scores'][side]>g['scores'][1-side] else 'no'
  if m.get('result') in ['yes','no'] and m['result']!=expected:issues.append(dict(provider='kalshi',market_id=ticker,official_game_id=g['official_game_id'],reason='Settlement disagrees after official identity match',request_id=rid));continue
  gid=gids[g['official_game_id']];used[gid]=g;providers[gid].add('kalshi');contracts.append(dict(provider='kalshi',game_id=gid,official_game_id=g['official_game_id'],side=side,contract_id=ticker,market_id=ticker,event_id=m['event_ticker'],series='KXNHLGAME',open=m['open_time'],close=m['close_time'],settled=m.get('settlement_ts'),request_id=rid,pointer=ptr,condition_id=None,outcome=m.get('yes_sub_title'),source_start_utc=mile['start_date'],identity_request_id=mrid,official_schedule_request_id=g['request_id']))
 for eid,(e,rid,ptr) in data['polymarket_events'].items():
  if str(rs[rid]['parameters'].get('tag_id'))!='899':continue
  for mi,m in enumerate(e.get('markets',[])):
   if m.get('sportsMarketType')!='moneyline':continue
   text=' '.join(str(m.get(k) or '') for k in ['question','slug','groupItemTitle']);labels=array(m.get('outcomes',[]));tokens=array(m.get('clobTokenIds',[]));values=array(m.get('outcomePrices',[]));raw_start=m.get('gameStartTime') or e.get('startTime');start=utc(raw_start);description=m.get('description') or '';identity_basis='Native teams and unique official scheduled start';extra_identity_sources=[]
   if re.search(r'\b(?:period|regulation|60[- ]?min|first goal|series winner|series outcome|division|conference|trophy|fights)\b',text+' '+e.get('title',''),re.I) or re.search(r'if .*?are the .*?Stanley Cup Champions',description,re.I):issues.append(dict(provider='polymarket',market_id=m['id'],reason='Not an entire game winner including overtime/shootout',request_id=rid));continue
   if m.get('umaResolutionStatus')=='resolved' and [float(v) for v in values]==[.5,.5]:issues.append(dict(provider='polymarket',market_id=m['id'],reason='Voided split-resolution market',request_id=rid));continue
   if len(labels)!=2 or len(tokens)!=2 or len(set(tokens))!=2:issues.append(dict(provider='polymarket',market_id=m['id'],reason='Not two distinct team-outcome tokens',request_id=rid));continue
   # Alternate abbreviations are accepted only when the same source question
   # independently spells out both native team names; no global guesswork.
   sets=[aliases[clean(n)] for n in labels]
   reviewed_codes={'605038':{'WAS':('15','Washington Capitals')},'605065':{'WAS':('15','Washington Capitals')},'605041':{'VEG':('54','Vegas Golden Knights')},'605056':{'VEG':('54','Vegas Golden Knights')},'605069':{'VEG':('54','Vegas Golden Knights')},'605074':{'VEG':('54','Vegas Golden Knights')}}
   for i,label in enumerate(labels):
    if label in reviewed_codes.get(m['id'],{}):
     native,full=reviewed_codes[m['id']][label];assert aliases[clean(full)]=={native};sets[i]={native};extra_identity_sources.append(dict(kind='Reviewed provider abbreviation for this market only',source_label=label,official_team_id=native,official_team_name=full,provider_request_id=rid))
   question_parts=re.split(r'\s+vs\.?\s+',m.get('question',''),flags=re.I)
   if len(question_parts)==2:
    for i in range(2):
     if not sets[i] and re.fullmatch('[A-Z]{2,3}',labels[i]) and len(aliases[clean(question_parts[i])])==1:sets[i]=aliases[clean(question_parts[i])]
   if any(not s for s in sets):issues.append(dict(provider='polymarket',market_id=m['id'],reason='Outcome labels do not uniquely map to NHL official teams',outcomes=labels,request_id=rid));continue
   g=match_sets(sets,start)
   if not g and m['id']=='1066639' and sets==[{'26'},{'29'}]:g=postponed;identity_basis='Official dated postponement announcement; provider scheduled time stale';extra_identity_sources.append(dict(kind='Official postponement announcement',request_id=postponement['request_id'],url=postponement['url']))
   if not g and start is None:
    # Older explicit single-game contracts may omit gameStartTime. Require
    # the described Finals game number, season and both native opponents.
    desc=re.search(r'Game (\d+) of the (20\d\d) NHL Stanley Cup Finals',description,re.I)
    if desc:
     xs=[v for tids in itertools.product(*sets) for v in pairs[frozenset(tids)] if v['official_game_id'][4:9]=='03041' and v['official_game_id'].endswith(desc[1]) and v['local_date'][:4]==desc[2]]
     if len(xs)==1:g=xs[0];start=utc(g['scheduled_start_utc']);identity_basis='Provider description names year and Finals game number; exact start supplied solely by official NHL schedule'
   if not g:issues.append(dict(provider='polymarket',market_id=m['id'],reason='No unique official completed game within six hours',outcomes=labels,source_start_utc=start.isoformat() if start else None,request_id=rid));continue
   tids=[next(iter(s & set(g['official_team_ids']))) for s in sets];assert len(set(tids))==2
   order=[g['official_team_ids'].index(t) for t in tids];vs=[float(x) for x in values] if len(values)==2 else []
   if m.get('umaResolutionStatus')=='resolved' and vs==[.5,.5]:issues.append(dict(provider='polymarket',market_id=m['id'],reason='Voided split-resolution market',request_id=rid));continue
   if sorted(vs)==[0.,1.] and order[vs.index(1.)]!=int(g['scores'][1]>g['scores'][0]):issues.append(dict(provider='polymarket',market_id=m['id'],official_game_id=g['official_game_id'],reason='Resolution disagrees after official identity match',request_id=rid));continue
   gid=gids[g['official_game_id']];used[gid]=g;providers[gid].add('polymarket')
   for i,token in enumerate(tokens):contracts.append(dict(provider='polymarket',game_id=gid,official_game_id=g['official_game_id'],side=order[i],contract_id=token,market_id=m['id'],event_id=eid,series=None,open=m.get('createdAt') or e.get('createdAt'),close=m.get('closedTime') or m.get('endDate'),settled=m.get('closedTime') or m.get('endDate'),request_id=rid,pointer=ptr+'/markets/'+str(mi),condition_id=m.get('conditionId'),outcome=labels[i],source_start_utc=utc(raw_start).isoformat() if raw_start else None,identity_basis=identity_basis,additional_identity_evidence=extra_identity_sources,official_schedule_request_id=g['request_id']))
 assert len({(c['provider'],c['contract_id']) for c in contracts})==len(contracts)
 types={1:'Preseason',2:'Regular Season',3:'Playoffs',4:'All-Star',19:'4 Nations Face-Off',20:'4 Nations Face-Off Final'};games=[]
 for gid,g in used.items():
  kind=types.get(g['game_type_code'],'Official game type '+str(g['game_type_code']));season=g['season'][:4]+'-'+g['season'][6:]+' '+kind
  games.append(dict(game_id=gid,league='NHL',game_type='Hockey',official_game_id=g['official_game_id'],date=g['local_date'],start=g['scheduled_start_utc'],start_basis='Official NHL scheduled start; actual scorer-report start pending',teams=g['teams'],team_ids=g['official_team_ids'],scores=g['scores'],winner=g['winner'],home_away='Away;Away' if g['neutral_site'] is True else 'Away;Home',location=g['venue'].get('default') if g['venue'] else None,city=None,season=season,competition_type=kind,is_training=g['game_type_code']==1,provider_sources=sorted(providers[gid]),official_schedule_request_id=g['request_id'],validation_status='OFFICIAL_NHL_SCHEDULE_MATCHED',venue_timezone=g['raw'].get('venueTimezone')))
 with db:
  for name,key,rows in [('_nhl_canonical_games','game_id',games),('_nhl_market_candidates','contract_id',contracts)]:
   db.execute('CREATE TABLE IF NOT EXISTS '+name+' (id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM '+name);db.executemany('INSERT INTO '+name+' VALUES (?,?)',[(r[key],json.dumps(r)) for r in rows])
  db.execute('CREATE TABLE IF NOT EXISTS _nhl_market_matching_audit (body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nhl_market_matching_audit');db.executemany('INSERT INTO _nhl_market_matching_audit VALUES (?)',[(json.dumps(r),) for r in issues])
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='CANDIDATES_REQUIRE_GAME_AND_PRICE_VALIDATION',canonical_games=len(games),provider_contracts=dict(collections.Counter(c['provider'] for c in contracts)),games_by_year=dict(collections.Counter(g['date'][:4] for g in games)),seasons=dict(collections.Counter(g['season'] for g in games)),earliest=min((g['date'] for g in games),default=None),latest=max((g['date'] for g in games),default=None),issues=dict(collections.Counter(x['reason'] for x in issues)))
 (ROOT/'reports/nhl_market_candidates.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
