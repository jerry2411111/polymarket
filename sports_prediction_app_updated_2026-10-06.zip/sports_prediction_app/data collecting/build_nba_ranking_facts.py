"""Extract factual, publisher-separated rankings from retained public pages.

Article and modification dates remain separate. A changed page is never assumed
to have contained today's ranks on its original publication date.
"""
import collections,datetime as dt,hashlib,json,re,sqlite3
from zoneinfo import ZoneInfo
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_nba_performance import identity_keys
from probe_history import ROOT

def objects(x):
    if isinstance(x,list):
        for v in x:yield from objects(v)
    elif isinstance(x,dict):
        yield x
        if '@graph' in x:yield from objects(x['@graph'])

def source_dates(source):
    articles=[x for x in objects(source['metadata']['structured']) if x.get('@type') in ['NewsArticle','Article']]
    assert len(articles)==1,(source['url'],'Ambiguous article metadata')
    a=articles[0];published=a['datePublished'];modified=a.get('dateModified') or published
    return published[:10],max(published[:10],modified[:10]),a

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;index=collections.defaultdict(set);canonical={};sources={r['url']:json.loads(r['body']) for r in db.execute('SELECT * FROM _nba_ranking_sources')}
    for pid,name in db.execute('SELECT player_id,player_name FROM _nba_player_bio_constants'):
        canonical[pid]=name
        for k in identity_keys(name):index[k].add(pid)
    for pid,b in db.execute('SELECT official_player_id,body FROM _nba_profile_sources'):
        p=json.loads(b)
        if 'NBA:'+pid not in canonical:continue
        for alias in p.get('aliases',[]):
            if alias:
                for k in identity_keys(alias):index[k].add('NBA:'+pid)
    for alias,pid in db.execute('SELECT alias,player_id FROM _nba_verified_name_aliases'):
        for k in identity_keys(alias):index[k].add(pid)
    rows=[];editions={};issues=[];pagechecks=[]
    for source in sources.values():
        if source['status']!='ACQUIRED_NOT_VALIDATED':issues.append(dict(url=source['url'],reason=source.get('error',source['status'])));continue
        pub=source['publisher']
        if pub=='the_ringer':
            publication='2026-06-16';version=dt.datetime.fromisoformat(source['retrieved_at_utc'].replace('Z','+00:00')).astimezone(ZoneInfo('America/Chicago')).date().isoformat();article={}
        else:
            try:publication,version,article=source_dates(source)
            except (AssertionError,KeyError) as e:issues.append(dict(url=source['url'],reason=str(e)));continue
        if article.get('isAccessibleForFree') is False:
            issues.append(dict(url=source['url'],reason='Article metadata marks the content as subscription access; full-list automation is not used. Existing limited publicly reviewed facts are retained.'));continue
        rid=source['request_id'];r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);raw=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];soup=BeautifulSoup(raw,'html.parser');facts=[]
        if pub=='the_ringer':
            payload=json.loads(soup.find('script',id='__NEXT_DATA__').string)['props']['pageProps'];settings=payload['settings']['pages']['rankings'];players=payload['content']['processedPlayers']
            assert '2025-26 season' in settings['intro'] and 'June 16' in json.dumps(settings)
            selected=[(pid,players['playerData'][pid]) for pid in players['rankings'] if (players['playerData'][pid].get('weekly_rankings') or {}).get('weekly_rankings_4') is not None]
            assert len(selected)==100 and sorted(p['order'] for pid,p in selected)==list(range(1,101))
            for pid,p in selected:
                assert p['order']==p['weekly_rankings']['weekly_rankings_4']
                name=(p.get('first_name','')+' '+p.get('last_name','')).strip()
                assert name
                facts.append((pub,p['order'],name,'__NEXT_DATA__/props/pageProps/content/processedPlayers/playerData/'+pid+'/order',json.dumps(dict(name=name,order=p['order'],weekly_rankings_4=p['weekly_rankings']['weekly_rankings_4']))))
            issues.append(dict(url=source['url'],reason='Older weekly fields contain duplicate/stale records. Only the internally consistent current 100-player list is accepted; its known version date is this capture date, not the page claimed June edition date.'))
        elif pub=='cbs_sports':
            for i,tr in enumerate(soup.select('table.ranked-players tr')):
                name=tr.select_one('.player-name');cells=tr.find_all('td',recursive=False)
                if name and len(cells)==2 and re.fullmatch(r'\d+',cells[0].get_text(strip=True)):
                    facts.append((pub,int(cells[0].get_text(strip=True)),name.get_text(' ',strip=True),f'table.ranked-players tr[{i}]',tr.get_text(' ',strip=True)))
        elif pub=='sporting_news':
            for ti,table in enumerate(soup.find_all('table')):
                if 'Rank Player Team' not in table.get_text(' ',strip=True):continue
                for ri,tr in enumerate(table.select('tr')):
                    cells=tr.find_all(['td','th'],recursive=False)
                    if len(cells)>=3 and re.fullmatch(r'\d+\.?',cells[0].get_text(strip=True)):
                        facts.append((pub,int(cells[0].get_text(strip=True).strip('.')),cells[1].get_text(' ',strip=True),f'table[{ti}] tr[{ri}]',tr.get_text(' ',strip=True)))
        elif pub=='hoopshype_syndicated':
            article_body=soup.select_one('.content-body');assert article_body and 'HoopsHype' in str(article.get('author'))
            publishers={'HoopsHype':'hoopshype','ESPN.com':'espn','CBS Sports':'cbs_sports','The Ringer':'the_ringer','Action Network':'action_network'}
            for hi,h in enumerate(article_body.select('h2,h3')):
                match=re.match(r'^\d+\. (.*?)\s*\([^)]*\)$',h.get_text(' ',strip=True))
                if not match:continue
                pieces=[]
                for nxt in h.next_siblings:
                    if getattr(nxt,'name',None) in ['h2','h3']:break
                    if getattr(nxt,'get_text',None):pieces.append(nxt.get_text(' ',strip=True))
                text=' '.join(pieces)
                for label,publisher in publishers.items():
                    m=re.search(re.escape(label)+r' rank:\s*No\.\s*(\d+)',text)
                    if m:facts.append((publisher,int(m[1]),match[1],f'.content-body heading[{hi}] {label} rank',label+' rank: No. '+m[1]+'; '+h.get_text(' ',strip=True)))
        elif pub in ['espn','bleacher_report','usa_today_syndicated','action_network']:
            body=soup.select_one('.content-body') if pub=='usa_today_syndicated' else soup
            assert body
            if pub=='usa_today_syndicated':assert 'USA TODAY' in str(article.get('author'))
            for hi,h in enumerate(body.select('h2,h3,h4')):
                text=h.get_text(' ',strip=True);m=re.match(r'^(?:Tie-)?(\d+)\.\s*(.+)',text)
                if not m:continue
                name=m[2].split(',')[0].strip();name=re.sub(r'\s*\(tie\)\s*','',name,flags=re.I)
                facts.append(('usa_today' if pub=='usa_today_syndicated' else pub,int(m[1]),name,f'heading[{hi}]',text))
        else:issues.append(dict(url=source['url'],reason='Publisher-specific parser is still required'));continue
        pagechecks.append(dict(url=source['url'],publisher=pub,source_facts=len(facts),publication_date=publication,version_date=version,updated_after_publication=version>publication))
        for publisher,rank,name,pointer,rawvalue in facts:
            ids=set().union(*(index[k] for k in identity_keys(name)))
            if len(ids)!=1:issues.append(dict(url=source['url'],raw_name=name,rank=rank,reason='No unique official native identity',candidate_ids=sorted(ids)));pid=None
            else:pid=next(iter(ids))
            # A syndicated historical edition is its own dated observation of
            # that publisher, not another independent publisher or Yahoo vote.
            # Split ESPN pages form one annual list, available only when its
            # final page/current revision is known. Never three publisher votes.
            eid='NBA:'+publisher+':'+(publication[:4]+':annual' if pub=='espn' else version+':'+('syndicated' if 'syndicated' in pub else 'direct'))
            edition=editions.setdefault(eid,dict(list_id=eid,publisher_key=publisher,league='NBA',publication_date=publication,version_verified_date=version,source_urls=[],raw_request_ids=[],acquisition_method='PUBLIC_AUTHORIZED_SYNDICATION' if 'syndicated' in pub else 'PUBLIC_ORIGINAL_PUBLISHER_HTML',complete_list=False,note='Factual rank and identity only. Current article metadata supplies the known revision date; no historical snapshot at publication is claimed.'))
            edition['publication_date']=max(edition['publication_date'],publication)
            edition['version_verified_date']=max(edition['version_verified_date'],version)
            edition['stated_list_size']=30 if publisher=='sporting_news' else 25 if publisher=='usa_today' else 100
            if pub=='the_ringer':edition['note']='Current ranking payload has exactly 100 unique native publisher records with order == final dated rank. Stale extra record and ambiguous earlier weekly columns excluded. June 16, 2026 is the claimed edition; capture date is used as the conservative known version date because later content updates exist.'
            if source['url'] not in edition['source_urls']:edition['source_urls'].append(source['url']);edition['raw_request_ids'].append(rid)
            rows.append(dict(list_id=eid,publisher_key=publisher,league='NBA',player_id=pid,player_name=canonical.get(pid,name),rank=rank,source_player_name=name,source_url=source['url'],request_id=rid,raw_pointer=pointer,raw_value=rawvalue,source_publication_date=publication,source_version_date=version,identity_basis='Unique official name/biography alias match' if pid else 'UNMATCHED'))
    for eid,e in editions.items():
        fs=[r for r in rows if r['list_id']==eid];counts=collections.Counter(r['rank'] for r in fs);e['raw_rank_count']=len(fs);e['mapped_rank_count']=sum(r['player_id'] is not None for r in fs);e['unique_ranks']=len(counts);e['minimum_rank']=min(counts);e['maximum_rank']=max(counts);e['duplicate_ranks']=[k for k,v in counts.items() if v>1]
        # Competition ranks can legitimately tie: 19,19,21. Compare the rank
        # to one plus the number of preceding entries rather than forcing 20.
        expected=1;valid=True
        for rank,count in sorted(counts.items()):
            if rank!=expected:valid=False
            expected+=count
        e['complete_list']=len(fs)==e['stated_list_size'] and valid
        if not e['complete_list']:e['note']+=' Partial list: missing players are unknown, not outside all thresholds.'
    db.execute('CREATE TABLE IF NOT EXISTS _nba_ranking_candidate_facts (body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nba_ranking_candidate_facts');db.executemany('INSERT INTO _nba_ranking_candidate_facts VALUES (?)',[(json.dumps(r),) for r in rows])
    db.execute('CREATE TABLE IF NOT EXISTS _nba_ranking_candidate_editions (list_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nba_ranking_candidate_editions');db.executemany('INSERT INTO _nba_ranking_candidate_editions VALUES (?,?)',[(k,json.dumps(v)) for k,v in editions.items()]);db.commit();db.close()
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='CANDIDATES_REQUIRE_REVIEW',rank_facts=len(rows),native_identity_mapped=sum(r['player_id'] is not None for r in rows),editions=list(editions.values()),page_checks=pagechecks,issues=issues)
    (ROOT/'reports/nba_ranking_facts.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['editions','issues','page_checks']}));print('ISSUES',json.dumps(issues));print('EDITIONS',json.dumps([{k:v for k,v in e.items() if k not in ['source_urls','raw_request_ids','note']} for e in editions.values()]))

if __name__=='__main__':main()
