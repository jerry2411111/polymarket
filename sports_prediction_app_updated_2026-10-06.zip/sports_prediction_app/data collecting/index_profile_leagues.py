"""Support league-filtered profile queries and bounded replacement without full rescans."""
import sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB,timeout=60)
with db:
 for table in ['player_profiles','manager_profiles']:db.execute('CREATE INDEX IF NOT EXISTS '+table+'_league ON '+table+'(league)')
print('League profile indexes available');db.close()
