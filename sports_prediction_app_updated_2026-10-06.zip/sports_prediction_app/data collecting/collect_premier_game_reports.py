"""Collect dated official lineups/events/commentary in resumable calendar-month batches."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,re,sqlite3
from zoneinfo import ZoneInfo
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from collect_premier_pilot import BASE

PILOT=['2444470','2444475','2444823','2645230']

def derive(row):
    m=row['sources']['match']['data'];schedule=row['schedule'];issues=[]
    assert m['matchId']==row['match_id'] and m['competitionId']=='8' and m['period']=='FullTime'
    for k in ['homeTeam','awayTeam','kickoff','kickoffTimezone','kickoffTimezoneString','ground']:assert m[k]==schedule[k],(row['match_id'],k)
    local=dt.datetime.fromisoformat(m['kickoff']).replace(tzinfo=ZoneInfo(m['kickoffTimezoneString']));assert local.tzname()==m['kickoffTimezone']
    cs=row['commentary_complete']['rows'];assert row['commentary_complete']['pagination_exhausted']
    keys=['First Half begins','First Half ends','Second Half begins','Second Half ends'];points=[]
    for key in keys:
        found=[c for c in cs if isinstance(c['raw'].get('comment'),str) and c['raw']['comment'].startswith(key)]
        if len(found)!=1:issues.append(dict(field=key,reason='Expected exactly one explicit official commentary checkpoint',count=len(found)));points.append(None)
        else:points.append(found[0])
    stamps=[]
    def walk(x):
        if isinstance(x,dict):
            if isinstance(x.get('timestamp'),str) and re.fullmatch(r'\d{8}T\d{6}[+-]\d{4}',x['timestamp']):stamps.append(dt.datetime.strptime(x['timestamp'],'%Y%m%dT%H%M%S%z').astimezone(dt.UTC))
            for v in x.values():walk(v)
        elif isinstance(x,list):
            for v in x:walk(v)
    # Commentary has no explicit offset and uses the match's local timezone.
    # Summer examples are independently checked against event timestamps +0100.
    clock=lambda value:dt.datetime.fromisoformat(value).replace(tzinfo=ZoneInfo(m['kickoffTimezoneString'])).astimezone(dt.UTC)
    walk(row['sources']['events']['data']);cts={clock(c['raw']['timestamp']) for c in cs if c['raw'].get('timestamp')};matches=sum(t in cts for t in stamps)
    if not matches:issues.append(dict(field='clock_timezone',reason='No explicitly offset event timestamp matches commentary'))
    clocks=[clock(c['raw']['timestamp']) if c else None for c in points]
    if all(clocks):
        if clocks!=sorted(clocks) or not 5*60<(clocks[2]-clocks[1]).total_seconds()<30*60:issues.append(dict(field='break_window',reason='Invalid half-time interval'))
        if abs((clocks[0]-local.astimezone(dt.UTC)).total_seconds())>10*60:issues.append(dict(field='start_time',reason='Opening play more than ten minutes from scheduled kickoff'))
        h,a=m['homeTeam'],m['awayTeam']
        expected=[None,(h['halfTimeScore'],a['halfTimeScore']),(h['halfTimeScore'],a['halfTimeScore']),(h['score'],a['score'])]
        for i,(point,score) in enumerate(zip(points,expected)):
            if score and h['name']+' '+str(score[0])+', '+a['name']+' '+str(score[1]) not in point['raw']['comment']:issues.append(dict(field=keys[i],reason='Commentary score differs from official summary'))
    lineup=row['sources']['lineups']['data'];seen=set();roster_count=0
    for key,side in [('away_team','awayTeam'),('home_team','homeTeam')]:
        t=lineup[key];assert t['teamId']==m[side]['id'];ids=[p['id'] for p in t['players']];assert len(ids)==len(set(ids)) and not seen.intersection(ids);seen.update(ids);starters=[p for line in t['formation']['lineup'] for p in line];assert len(starters)==len(set(starters))==11 and set(starters)<=set(ids);roster_count+=len(ids)
    valid_clock=matches>0
    names=['actual_start_utc','halftime_start_utc','second_half_start_utc','regulation_end_utc']
    result={n:v.isoformat() if v and valid_clock else None for n,v in zip(names,clocks)}
    if any(i['field'] in ['break_window','start_time'] for i in issues):result={n:None for n in names}
    result.update(schema_version=2,scheduled_start_utc=local.astimezone(dt.UTC).isoformat(),timezone_abbreviation=local.tzname(),explicit_event_clock_matches=matches,explicit_event_clock_count=len(stamps),roster_count=roster_count,checkpoint_sources={n:p for n,p in zip(names,points)},issues=issues)
    return result

def acquire(client,g):
    mid=g['official_match_id'];row=dict(match_id=mid,schedule_request_id=g['request_id'],schedule=g['raw'],sources={})
    for key,path in [('match','/v2/matches/'+mid),('lineups','/v3/matches/'+mid+'/lineups'),('events','/v1/matches/'+mid+'/events')]:
        data,r=client.get(BASE+path);row['sources'][key]=dict(request_id=r['request_id'],data=data)
    cs=[];requests=[];seen={};duplicates=[];cursors=set();params=dict(lang='en',_limit=100)
    for _ in range(20):
        data,r=client.get(BASE+'/v2/matches/'+mid+'/commentary',params);requests.append(r['request_id'])
        for i,c in enumerate(data['data']):
            key=json.dumps(c,sort_keys=True);item=dict(raw=c,request_id=r['request_id'],pointer='/data/'+str(i))
            if key in seen:duplicates.append(dict(duplicate=item,retained=seen[key]));continue
            seen[key]=dict(request_id=r['request_id'],pointer=item['pointer']);cs.append(item)
        cursor=data['pagination'].get('_next')
        if not cursor:break
        assert cursor not in cursors;cursors.add(cursor);params['_next']=cursor
    else:raise ValueError('Unexhausted commentary pagination')
    row['commentary_complete']=dict(rows=cs,request_ids=requests,pagination_exhausted=True,exact_duplicates=duplicates);row['derived']=derive(row);return row

def main():
    p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');p.add_argument('--through-percent',type=int,default=10);a=p.parse_args();assert 0<a.through_percent<=100
    HOSTS.update({'sdp-prem-prod.premier-league-prod.pulselive.com'});db=sqlite3.connect(DB,timeout=60);client=HistoryClient();games={mid:json.loads(b) for mid,b in db.execute('SELECT * FROM _official_epl_calendar')};ids=PILOT if a.pilot else [r[0] for r in db.execute("SELECT DISTINCT json_extract(body,'$.official_match_id') FROM _epl_market_families")];monthmap=collections.defaultdict(list)
    for mid in ids:monthmap[games[mid]['date'][:7]].append(games[mid])
    done=set()
    for mid,b in db.execute('SELECT * FROM _official_epl_game_reports').fetchall():
        row=json.loads(b)
        if 'commentary_complete' in row:
            if row.get('derived',{}).get('schema_version')!=2:
                row['derived']=derive(row)
                with db:db.execute('UPDATE _official_epl_game_reports SET body=? WHERE match_id=?',(json.dumps(row),mid))
            done.add(mid)
    parts=[];day=dt.date(2024,1,1);out={};new=0
    while day<=dt.date(2026,9,14) and (a.pilot or len(parts)<math.ceil(33*a.through_percent/100)):
        month=day.strftime('%Y-%m');errors=[];clock_issues=0;items=monthmap[month];before_new=new
        def get_one(g):
            try:return g['official_match_id'],acquire(client,g),None
            except Exception as e:return g['official_match_id'],None,type(e).__name__+': '+str(e)
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            for mid,row,error in pool.map(get_one,[g for g in items if g['official_match_id'] not in done]):
                if error:errors.append(dict(match_id=mid,error=error));print('EPL REPORT ERROR',mid,error,flush=True);continue
                with db:db.execute('INSERT OR REPLACE INTO _official_epl_game_reports VALUES (?,?)',(mid,json.dumps(row)))
                done.add(mid);new+=1
        for g in items:
            mid=g['official_match_id']
            if mid not in done:continue
            row=json.loads(db.execute('SELECT body FROM _official_epl_game_reports WHERE match_id=?',(mid,)).fetchone()[0]);clock_issues+=bool(row['derived']['issues'])
        parts.append(dict(month=month,games=len(items),acquired=sum(g['official_match_id'] in done for g in items),errors=errors,games_with_checkpoint_issues=clock_issues))
        out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Official EPL candidate game reports',pilot=a.pilot,total_months=33,completed_months=len(parts),new_games=new,new_requests=client.requests,months=parts)
        (ROOT/'reports'/('epl_market_pilot_reports.json' if a.pilot else 'epl_game_report_acquisition.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
        if new>before_new or errors:print('EPL OFFICIAL REPORT MONTH',month,parts[-1],'months',len(parts),'/33',flush=True)
        day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
        if errors:break
    print(json.dumps(dict(new_games=new,requests=client.requests,months=len(parts))),flush=True);db.close()

if __name__=='__main__':main()
