import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for b, in db.execute('SELECT body FROM _official_mlb_schedule'):
    g=json.loads(b)
    if g['official_date'] in ['2025-05-19','2025-05-20','2025-05-21'] and set(g['official_team_ids'])=={'114','142'}:
        print({k:v for k,v in g.items() if k not in ['raw_game']})
        print('EXTRA',{k:v for k,v in g['raw_game'].items() if any(t in k.lower() for t in ['date','time','resume','resched','description'])})
