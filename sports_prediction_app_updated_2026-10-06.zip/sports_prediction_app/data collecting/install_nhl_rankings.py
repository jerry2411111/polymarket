"""Publish validated dated NHL ranking facts and publisher-specific flags."""
import collections,datetime as dt,hashlib,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_nhl_ranking_facts import extract
from install_nba_rankings import NAMES
from probe_history import ROOT
from temporal_queries import FLAGS

def other_digest(db,table):
    return hashlib.sha256(json.dumps(db.execute('SELECT * FROM '+table+" WHERE league!='NHL' ORDER BY 1,2,3,4").fetchall(),separators=(',',':')).encode()).hexdigest()

def main():
    db=sqlite3.connect(DB,timeout=60);fs=[json.loads(b) for b, in db.execute('SELECT body FROM _nhl_ranking_candidate_facts')];es={i:json.loads(b) for i,b in db.execute('SELECT * FROM _nhl_ranking_candidate_editions')};assert fs and all(f['player_id'] for f in fs)
    assert len({(f['list_id'],f['player_id']) for f in fs})==len(fs)
    raws={};checks=0;now=dt.datetime.now(dt.UTC).isoformat()
    for f in fs:
        rid=f['request_id']
        if rid not in raws:
            r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];s=BeautifulSoup(b,'html.parser');raws[rid]=(r,s,extract(s,f['publisher_key']))
        r,s,actual=raws[rid];assert s.select(f['selector'])[f['index']].get_text(' ',strip=True)==f['raw_value']
        assert any(x['rank']==f['rank'] and x['source_player_name']==f['source_player_name'] and x['index']==f['index'] for x in actual)
        if f.get('editorial_context'):
            assert s.select(f['selector'])[f['editorial_context_index']].get_text(' ',strip=True)==f['editorial_context']
        if f.get('verified_name_alias'):
            v=f['verified_name_alias'];a=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(v['request_id'],)).fetchone()[0]);b=(ROOT/a['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==a['sha256'];text=BeautifulSoup(b,'html.parser').get_text(' ',strip=True);assert v['name_evidence'] in text and v['date_evidence'] in text
        if f.get('identity_evidence'):
            v=f['identity_evidence'];a=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(v['request_id'],)).fetchone()[0]);b=(ROOT/a['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==a['sha256'];data=json.loads(b)
            for k in v['pointer'].strip('/').split('/'):data=data[int(k)] if isinstance(data,list) else data[k]
            assert data==v['raw_value']
        checks+=1
    with db:
        for eid,e in es.items():
            row=(eid,'NHL_'+e['publisher_key'].upper(),NAMES[e['publisher_key']],'NHL','overall',e['publication_date'],e['version_verified_date'],int(e['complete_list']),'PUBLIC_ORIGINAL_PUBLISHER_HTML',e['note'],now)
            old=db.execute('SELECT * FROM ranking_list_versions WHERE list_id=?',(eid,)).fetchone()
            if old:assert old[:-1]==row[:-1]
            else:db.execute('INSERT INTO ranking_list_versions VALUES (?,?,?,?,?,?,?,?,?,?,?)',row)
            db.execute('INSERT OR IGNORE INTO _ranking_edition_audit VALUES (?,?,1)',(eid,json.dumps(e)))
        for f in fs:
            row=(f['list_id'],f['player_id'],f['player_name'],'NHL',f['rank'],None,f['source_url'],raws[f['request_id']][0]['raw_file']);old=db.execute('SELECT * FROM player_media_rankings WHERE list_id=? AND player_id=?',row[:2]).fetchone()
            if old:assert old==row
            else:db.execute('INSERT INTO player_media_rankings VALUES (?,?,?,?,?,?,?,?)',row)
            db.execute('INSERT OR IGNORE INTO _ranking_fact_audit VALUES (?,?,?)',(f['list_id'],f['player_id'],json.dumps(f)))
    db.row_factory=sqlite3.Row
    dates=[r[0] for r in db.execute('SELECT as_of_date FROM _ranking_snapshot_dates ORDER BY 1')]
    players=[dict(r) for r in db.execute("SELECT player_id,player_name,min(as_of_date) AS first_seen FROM player_profiles WHERE league='NHL' GROUP BY player_id")]
    editions=[dict(r) for r in db.execute("SELECT v.* FROM ranking_list_versions v LEFT JOIN _ranking_edition_audit a ON a.list_id=v.list_id WHERE league='NHL' AND coalesce(a.use_for_flags,1)=1")]
    observations={(r['list_id'],r['player_id']):dict(r) for r in db.execute("SELECT * FROM player_media_rankings WHERE league='NHL'")};groups=collections.defaultdict(list)
    for e in editions:groups[e['publisher']].append(e)
    snaps=[];flags={};known_ranks=0
    for day in dates:
        for publisher,eds in groups.items():
            eligible=[e for e in eds if max(e['publication_date'],e['version_verified_date'])<=day];e=max(eligible,key=lambda e:(e['version_verified_date'],e['publication_date'],e['list_id'])) if eligible else None
            key=next(k for k,v in NAMES.items() if v==publisher)
            for p in players:
                if p['first_seen']>day:continue
                o=observations.get((e['list_id'],p['player_id'])) if e else None;rank=o['rank'] if o else None;age=(dt.date.fromisoformat(day)-dt.date.fromisoformat(e['version_verified_date'])).days if e else None
                snaps.append((day,p['player_id'],p['player_name'],'NHL',publisher,e['publication_date'] if e else None,rank,o['rating'] if o else None,'overall',age,int(age>=90) if age is not None else None,'OBSERVED' if o else 'NOT_LISTED_ELIGIBILITY_UNKNOWN' if e and e['complete_list'] else 'PARTIAL_LIST_NOT_OBSERVED' if e else 'NO_DATED_LIST_ACQUIRED',o['source_url'] if o else None))
                f=flags.setdefault((day,p['player_id'],'NHL'),{c:None for c in FLAGS})
                for n in [5,10,20,50]:f[key+'_top_'+str(n)]=int(rank<=n) if rank is not None else None
                known_ranks+=rank is not None
    db.row_factory=None;tables=['_ranking_quarterly_results','_ranking_flag_results'];before={t:other_digest(db,t) for t in tables}
    with db:
        for t in tables:db.execute('DELETE FROM '+t+" WHERE league='NHL'")
        db.executemany('INSERT INTO _ranking_quarterly_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',snaps)
        db.executemany('INSERT INTO _ranking_flag_results VALUES ('+','.join('?' for _ in range(3+len(FLAGS)))+')',[k+tuple(f[c] for c in FLAGS) for k,f in flags.items()])
        assert before=={t:other_digest(db,t) for t in tables},'Other league rankings changed'
        from index_ranking_flags import refresh
        refresh(db)
    out=dict(generated_at_utc=now,status='WORKING',coverage_status='PARTIALLY WORKING',raw_rank_checks=checks,source_hash_checks=len(raws),editions=len(es),independent_publishers=len({e['publisher_key'] for e in es.values()}),required_publishers=10,quarterly_rows=len(snaps),known_rank_snapshots=known_ranks,flag_rows=len(flags),resolved_source_identity_discrepancies=[dict(list_id=f['list_id'],player_id=f['player_id'],reason=f['source_identity_discrepancy'],request_id=f['request_id']) for f in fs if f.get('source_identity_discrepancy')],limitations=['Publisher coverage remains below the requested ten; the measured count is recorded separately.','NHL Network 2025 rolls out ten ranks at a time; cumulative editions preserve earlier ranks without using later installments early.','Later visible revision dates override older embedded dates. These are retrospective publication records, not contemporaneously archived captures.','Quarterly snapshots carry the most recently available edition; no new quarterly rankings are fabricated.','Sportsnet full 50-player 2024 and 2025 pages are dated; earlier linked installment bodies were unavailable. The Hockey News supplies four original-publisher facts.','Unlisted or ineligible players remain null, not false.'])
    (ROOT/'reports/nhl_rankings_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
