import collections,json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for code,table in [('LAL','laliga'),('BUN','bundesliga'),('UCL','uefa')]:
 r=json.loads(db.execute('SELECT body FROM _official_'+table+'_game_reports ORDER BY match_id LIMIT 1').fetchone()[0]);s=r['sources'];print('COMPETITION',code)
 if code=='LAL':
  d=s['match_page']['data'];print('PAGE',list(d),'MATCH',list(d['match']));print('STATS',json.dumps(d['data']['stats'],ensure_ascii=False)[:1800]);print('MATCH EVENTS',json.dumps(d['match'].get('events'),ensure_ascii=False)[:4000]);print('DATA EVENTS',json.dumps(d.get('events'),ensure_ascii=False)[:1800])
 elif code=='BUN':
  wanted={'goal','substitution','yellow_redCard','redCard','end_firstHalf','end_secondHalf'};seen=set()
  ev=s['match']['data']['liveBlogEntries'];print('TYPES',dict(collections.Counter(e['entryType'] for e in ev.values())))
  for k,e in ev.items():
   t=e['entryType']
   if t in seen or not any(x in t.lower() for x in ['goal','sub','card','end_first','end_second']):continue
   seen.add(t);print('EVENT',k,json.dumps(e,ensure_ascii=False)[:1800])
 else:
  for side in ['homeTeam','awayTeam']:
   d=s['lineups']['data'][side];print(side,'KEYS',list(d));print('COACH',json.dumps(d.get('coaches'),ensure_ascii=False)[:900])
  seen=set()
  for e in s['events']['data']:
   t=e.get('type')
   if t in seen or t not in ['GOAL','ASSIST','SUBSTITUTION','RED_CARD','SECOND_YELLOW_CARD','START_PHASE','END_PHASE']:continue
   seen.add(t);print('EVENT',json.dumps(e,ensure_ascii=False)[:1900])
db.close()
