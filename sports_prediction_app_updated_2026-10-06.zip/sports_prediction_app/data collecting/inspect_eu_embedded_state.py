"""Locate season and public API metadata inside retained official page state."""
import argparse,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT

def main():
    ap=argparse.ArgumentParser();ap.add_argument('competition_host');a=ap.parse_args();db=sqlite3.connect(DB);pages=json.loads((ROOT/'reports/eu_soccer_pages_sources.json').read_text())['sources']
    for source in pages:
        if a.competition_host not in source['url']:continue
        r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(source['request_id'],)).fetchone()[0]);soup=BeautifulSoup((ROOT/r['raw_file']).read_text(encoding='utf-8'),'html.parser');print(source['url'],source['request_id'])
        for t in soup.find_all('a',href=True):
            if re.search('matchday/20',t['href']):print('SEASON LINK',t['href'])
        def walk(x,path=''):
            if isinstance(x,dict):
                for k,v in x.items():
                    if re.search(r'key|token|password|secret|transfer-translate',k,re.I):continue
                    key=path+'/'+k
                    if re.search('season',k,re.I) and (isinstance(v,(str,int)) or isinstance(v,list)) and not 'matches' in path:print(key,json.dumps(v,ensure_ascii=False)[:1400])
                    elif re.search('api.*url|base.*url|backendUrl',k,re.I) and isinstance(v,str):print(key,v)
                    elif k in ['props','pageProps','runtimeConfig','publicRuntimeConfig']:print(key,'keys',list(v) if isinstance(v,dict) else type(v).__name__)
                    if not 'matches' in path:walk(v,key)
            elif isinstance(x,list):
                for i,v in enumerate(x[:10]):walk(v,path+'/'+str(i))
        for t in soup.find_all('script',type='application/json'):
            data=json.loads(t.get_text());walk(data)
    db.close()

if __name__=='__main__':main()
