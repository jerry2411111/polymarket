"""Official NBA individual biographies for the collected player population.

Personal measurements are sourced constants, as requested. Current affiliation
and experience are observations and must not be projected into past profiles.
"""
import argparse,collections,concurrent.futures,datetime as dt,json,re,sqlite3,unicodedata
from urllib.parse import urljoin,urlsplit
from build_history_catalog import DB
from collect_nba_profiles import next_data
from history_client import HistoryClient
from probe_history import ROOT

def slug(name):
    name=unicodedata.normalize('NFKD',name).encode('ascii','ignore').decode().lower()
    return re.sub('[^a-z0-9]+','-',name).strip('-')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--limit',type=int);args=ap.parse_args()
    db=sqlite3.connect(DB,timeout=60)
    wanted={p.split(':',1)[1] for (p,) in db.execute('SELECT DISTINCT player_id FROM _nba_player_game_facts')}
    names=collections.defaultdict(collections.Counter)
    for pid,b in db.execute('SELECT official_player_id,body FROM _official_nba_page_players'):
        if pid in wanted:names[pid][json.loads(b)['player_name']]+=1
    db.execute('CREATE TABLE IF NOT EXISTS _nba_profile_sources (official_player_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit()
    done={p for p,b in db.execute('SELECT official_player_id,body FROM _nba_profile_sources') if json.loads(b).get('status')=='ok'}
    redirects={}
    for (b,) in db.execute("SELECT metadata_json FROM _request_audit WHERE return_status IN ('301','302','303','307','308') ORDER BY request_number"):
        r=json.loads(b)
        if 'nba.com/' in r['endpoint']:redirects[r['endpoint']]=r
    todo=sorted(wanted-done);todo=todo[:args.limit] if args.limit else todo
    c=HistoryClient();ok=0;errors=[];threshold=10
    def fetch(pid):
        name=names[pid].most_common(1)[0][0];url=f'https://www.nba.com/player/{pid}/{slug(name)}'
        try:
            redirect_ids=[]
            for _ in range(3):
                redirect=redirects.get(url)
                if not redirect:break
                target=urljoin(url,redirect.get('location') or '')
                if urlsplit(target).hostname!='www.nba.com' or not re.match(r'^/(?:stats/)?player/'+re.escape(pid)+r'(?:/|$)',urlsplit(target).path):
                    raise ValueError('Official redirect has no individual page for requested ID; request '+redirect['request_id'])
                redirect_ids.append(redirect['request_id']);url=target
            b,r=c.get(url,document=True);player=next_data(b)['player'];info=player['info']
            if str(info['PERSON_ID'])!=pid:raise ValueError('Official profile identity differs from requested native ID')
            birth=info.get('BIRTHDATE');birth=dt.datetime.fromisoformat(birth).date().isoformat() if birth else None
            x=dict(status='ok',official_player_id=pid,player_name=info['DISPLAY_FIRST_LAST'],league='NBA',birth_date=birth,height=info.get('HEIGHT') or None,weight=info.get('WEIGHT') or None,years_played=info.get('SEASON_EXP'),first_season=info.get('FROM_YEAR'),seasons=info.get('SEASONS'),team_name=(info.get('TEAM_CITY','')+' '+info.get('TEAM_NAME','')).strip() or None,official_team_id=info.get('TEAM_ID') or None,aliases=[info.get('DISPLAY_FIRST_LAST'),info.get('PLAYERCODE','').replace('_',' '),(info.get('FIRST_NAME','')+' '+info.get('LAST_NAME','')).strip()],observed_at_utc=r['retrieved_at_utc'],request_id=r['request_id'],source_url=url,pointer='/props/pageProps/player/info')
            x['redirect_request_ids']=redirect_ids;return x
        except Exception as e:return dict(status='unavailable',official_player_id=pid,player_name=name,source_url=url,error=str(e))
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for n,x in enumerate(pool.map(fetch,todo),1):
            db.execute('INSERT OR REPLACE INTO _nba_profile_sources VALUES (?,?)',(x['official_player_id'],json.dumps(x)))
            if x['status']=='ok':
                ok+=1;db.execute('INSERT OR IGNORE INTO _official_player_biographies VALUES (?,?,?,?)',('NBA',x['player_name'],x['observed_at_utc'],json.dumps(x)))
            else:errors.append(x)
            db.commit()
            percent=100*n//len(todo)
            if percent>=threshold or n==len(todo):
                print('NBA INDIVIDUAL BIOGRAPHIES',min(threshold,100),'percent;',n,'/',len(todo),'verified',ok,'unavailable',len(errors),flush=True)
                threshold+=10
    rows=[json.loads(b) for (b,) in db.execute('SELECT body FROM _nba_profile_sources')];db.close()
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),population=len(wanted),attempted_now=len(todo),verified_now=ok,new_requests=c.requests,verified_total=sum(x['status']=='ok' for x in rows),unavailable=[x for x in rows if x['status']!='ok'],scope='Personal constants only; source affiliation and experience are dated observations, not proof of past team membership.')
    (ROOT/'reports/nba_individual_biographies.json').write_text(json.dumps(report,indent=2),encoding='utf-8')

if __name__=='__main__':main()
