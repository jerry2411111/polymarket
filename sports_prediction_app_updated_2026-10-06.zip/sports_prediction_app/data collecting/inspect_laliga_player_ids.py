"""Test whether lineup row IDs identify a person or a game-specific entry."""
import collections,json,sqlite3
from build_history_catalog import DB

def main():
 db=sqlite3.connect(DB);seen=collections.defaultdict(set);samples=[]
 for mid,b in db.execute('SELECT * FROM _official_laliga_game_reports'):
  r=json.loads(b)
  for side in ['away','home']:
   for p in r['sources']['match_page']['data']['data']['lineups'][side]['starts']:
    seen[p['person']['name']].add(str(p['id']))
    if p['person']['name']=='Giorgi Mamardashvili' and len(samples)<2:samples.append(dict(match_id=mid,row=p))
 print('NAMES',len(seen),'MULTIPLE_IDS',sum(len(v)>1 for v in seen.values()));print('FIRST_MULTIPLE',[(k,len(v),sorted(v)[:4]) for k,v in seen.items() if len(v)>1][:5]);print(json.dumps(samples,ensure_ascii=False)[:4200]);db.close()

if __name__=='__main__':main()
