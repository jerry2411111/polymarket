import json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB);s=json.loads(db.execute("SELECT body FROM _nba_ranking_sources WHERE url='https://nbarankings.theringer.com/'").fetchone()[0]);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(s['request_id'],)).fetchone()[0]);html=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser');p=json.loads(html.find('script',id='__NEXT_DATA__').string)
def walk(x,path='',depth=0):
    if depth>3:return
    if isinstance(x,dict):
        print(path,'KEYS',list(x)[:30])
        for k,v in x.items():
            if isinstance(v,(dict,list)):walk(v,path+'/'+k,depth+1)
            elif any(w in k.lower() for w in ['date','updated','title','rank']):print(path+'/'+k,str(v)[:150])
    elif isinstance(x,list):
        print(path,'LIST',len(x))
        if x:walk(x[0],path+'/0',depth+1)
page=p['props']['pageProps'];players=page['content']['processedPlayers']
print('SETTINGS CURRENT WEEK',page['settings'].get('current_week'))
print('RANKING PAGE SETTINGS',json.dumps(page['settings']['pages']['rankings'])[:2500])
print('LABELS',page['settings']['weekly_rankings_labels'])
for pid in players['rankings'][:6]+players['rankings'][-2:]:
    x=players['playerData'][pid];print(pid,{k:x.get(k) for k in ['title','order','weekly_rankings','updated','production_status','deleted']})
for i in range(6):
    vs=[p['weekly_rankings'].get('weekly_rankings_'+str(i)) for p in players['playerData'].values() if p.get('weekly_rankings',{}).get('weekly_rankings_'+str(i)) is not None]
    from collections import Counter
    print('WEEK',i,'rank_values',Counter(vs))
db.close()
