import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
from collect_nba_ranking_pages import PAGES,metadata
db=sqlite3.connect(DB)
for pub,url in PAGES:
    rows=db.execute("SELECT metadata_json FROM _request_audit WHERE json_extract(metadata_json,'$.endpoint')=? AND json_extract(metadata_json,'$.status')=200 ORDER BY json_extract(metadata_json,'$.retrieved_at_utc') DESC LIMIT 1",(url,)).fetchone()
    if not rows:continue
    r=json.loads(rows[0]);s=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser');print('PAGE',pub,url)
    md=metadata(s);print('DATES',md['meta'],md['times'])
    headings=[dict(tag=h.name,classes=h.get('class'),text=h.get_text(' ',strip=True)) for h in s.select('h2,h3,h4') if re.match(r'^\d+[.\s]',h.get_text(' ',strip=True))];print('HEADINGS',len(headings),headings[:3],headings[-2:])
    print('TABLES',[(t.get('class'),len(t.select('tr')),t.get_text(' ',strip=True)[:170]) for t in s.find_all('table')][:4])
    if pub=='washington_post':print('KUMINGA',str(s)[max(0,str(s).find('Jonathan Kuminga')-400):str(s).find('Jonathan Kuminga')+400])
    if pub=='cbs_sports':
        p=s.find(string=re.compile('Nikola Jokic'));print('NAME PARENT',str(p.parent.parent)[:1800] if p else None)
db.close()
