import json,re
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT
from official_html import decode_html
c=HistoryClient();p=json.loads((ROOT/'reports/nhl_public_api_validation.json').read_text())['examples'][1]
for kind in ['boxscore','landing','play-by-play','right-rail']:
 d,r=c.get('https://api-web.nhle.com/v1/gamecenter/'+p['official_game_id']+'/'+kind)
 if kind=='boxscore':print('PLAYERS',json.dumps({s:{k:v[:1] for k,v in gs.items()} for s,gs in d.get('playerByGameStats',{}).items()}))
 if kind=='landing':print('SUMMARY KEYS',list(d.get('summary',{})))
 if kind=='play-by-play':print('ROSTER',json.dumps(d.get('rosterSpots',[])[:2]),'PERIOD_EVENTS',json.dumps([e for e in d['plays'] if e['typeDescKey'] in ['period-end','period-start']]))
 if kind=='right-rail':print('GAMEINFO',json.dumps(d.get('gameInfo')))
for kind in ['PL','TV','TH']:
 url=f'https://www.nhl.com/scores/htmlreports/{p["season"]}/{kind}{p["official_game_id"][4:]}.HTM'
 try:
  b,r=c.get(url,document=True);s=BeautifulSoup(decode_html(b),'html.parser');t=s.get_text(' ',strip=True)
  print('REPORT',kind,r['request_id'], 'PERIOD_ROWS',[[cell.get_text(' ',strip=True) for cell in row.find_all('td',recursive=False)][:7] for row in s.find_all('tr') if re.search(r'(?:Period (?:Start|End)|Local time)',row.get_text(' ',strip=True)) and len(row.find_all('td',recursive=False)) in [7,8]], 'WALL_CLOCK_CANDIDATES',re.findall(r'.{0,70}(?:Period Start|Period End|Local time).{0,70}',t)[:15])
 except Exception as e:print('REPORT ERROR',kind,str(e))
