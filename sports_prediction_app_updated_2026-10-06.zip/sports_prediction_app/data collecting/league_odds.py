"""Common provider interfaces across US sports and the six soccer competitions."""
import csv
import sqlite3
import pyarrow as pa
import pyarrow.parquet as pq
from schema import HOURS, PRE_COLUMNS, INGAME_COLUMNS
from probe_history import ROOT

SOCCER_LEAGUES = ('Premier League', 'La Liga', 'Bundesliga', 'Serie A', 'Ligue 1', 'UEFA Champions League')
COMMON_PRE = PRE_COLUMNS[:6] + [f'{side}_pre_{hour}_{kind}' for hour in HOURS
    for side in ['teamA','teamB','draw'] for kind in ['odd','p']] + PRE_COLUMNS[-6:]
COMMON_INGAME = ['match','game_type','league','season','timestamp','checkpoint',
    'teamA_ingame_odd','teamB_ingame_odd','draw_ingame_odd',
    'teamA_ingame_p','teamB_ingame_p','draw_ingame_p','teamA_score','teamB_score','game_id']

def source_table(provider, kind, soccer=False):
    assert provider in ('polymarket','kalshi') and kind in ('pre_match','in_game')
    return '_source_' + provider + ('_soccer_' if soccer else '_us_') + kind

def installed(db):
    return bool(db.execute('SELECT 1 FROM sqlite_master WHERE name=?',
        (source_table('polymarket','pre_match'),)).fetchone())

def refresh_views(db):
    for provider in ['polymarket','kalshi']:
        for kind,columns in [('pre_match',COMMON_PRE),('in_game',COMMON_INGAME)]:
            parts=[]
            for soccer in [False,True]:
                table=source_table(provider,kind,soccer)
                fields={r[1] for r in db.execute('PRAGMA table_info('+table+')')}
                if not fields:continue
                expressions=[]
                for column in columns:
                    if column=='league' and soccer:
                        expressions.append("CASE competition WHEN 'LaLiga' THEN 'La Liga' ELSE competition END AS league")
                    elif column in fields:expressions.append('"'+column+'"')
                    else:expressions.append('NULL AS "'+column+'"')
                parts.append('SELECT '+','.join(expressions)+' FROM '+table)
            name=provider+'_'+kind
            db.execute('DROP VIEW IF EXISTS '+name)
            db.execute('CREATE VIEW '+name+' AS '+' UNION ALL '.join(parts))
            deletes=' '.join('DELETE FROM '+source_table(provider,kind,soccer)+' WHERE game_id=OLD.game_id;'
                for soccer in [False,True] if db.execute('SELECT 1 FROM sqlite_master WHERE name=?',
                (source_table(provider,kind,soccer),)).fetchone())
            db.execute('CREATE TRIGGER '+name+'_delete INSTEAD OF DELETE ON '+name+' BEGIN '+deletes+' END')
    db.execute('DROP VIEW IF EXISTS main')
    db.execute('CREATE VIEW main AS '+ ' UNION ALL '.join(
        "SELECT *, '"+p+"' AS provider FROM "+p+'_pre_match' for p in ['polymarket','kalshi']))
    db.execute('DROP VIEW IF EXISTS in_game')
    db.execute('CREATE VIEW in_game AS '+ ' UNION ALL '.join(
        "SELECT i.*,p.date,'"+p+"' AS provider FROM "+p+'_in_game i JOIN '+p+'_pre_match p USING(game_id)'
        for p in ['polymarket','kalshi']))

def export_provider(db,provider,kind):
    columns=COMMON_PRE if kind=='pre_match' else COMMON_INGAME
    order='date,game_id' if kind=='pre_match' else 'game_id'
    rows=[dict(zip(columns,r)) for r in db.execute('SELECT '+','.join('"'+c+'"' for c in columns)+
        ' FROM '+provider+'_'+kind+' ORDER BY '+order)]
    schema=pa.schema([(c,pa.float64() if '_pre_' in c else pa.int64() if c in
        ['teamA_final_score','teamB_final_score'] else pa.string()) for c in columns])
    path=ROOT/'data/result'/provider/kind
    path.parent.mkdir(parents=True,exist_ok=True)
    pq.write_table(pa.Table.from_pylist(rows,schema=schema),path.with_suffix('.parquet'),compression='zstd')
    with path.with_suffix('.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns);w.writeheader();w.writerows(rows)
    return len(rows)
