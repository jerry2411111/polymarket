"""Past-only manager statistics, for dates with a known serving team."""
import collections,datetime as dt,sqlite3
from build_history_catalog import DB
def main():
 db=sqlite3.connect(DB,timeout=120);db.row_factory=sqlite3.Row;start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone();end=(dt.date.fromisoformat(end)+dt.timedelta(days=1)).isoformat();groups=collections.defaultdict(lambda:collections.defaultdict(list));rows=[]
 for g in db.execute('SELECT * FROM _manager_game_results WHERE game_date>=? ORDER BY game_date,game_id',(start,)):groups[g['manager_id'],g['league']][g['game_date']].append(g)
 for (pid,league),days in groups.items():
  ordered=sorted(days);n=w=h=a=margin=0
  for i,day in enumerate(ordered):
   for g in days[day]:n+=1;w+=g['win'];h+=g['home_away']=='Home';a+=g['home_away']=='Away';margin+=g['score_for']-g['score_against']
   rows.append((pid,league,day,ordered[i+1] if i+1<len(ordered) else end,n,w/n,h,a,margin/n))
 with db:
  db.execute('DROP TABLE IF EXISTS _manager_performance_periods');db.execute('CREATE TABLE _manager_performance_periods (manager_id TEXT,league TEXT,effective_from TEXT,effective_to TEXT,games_played INTEGER,overall_winrate REAL,home_times INTEGER,away_times INTEGER,average_score_margin REAL,PRIMARY KEY(manager_id,league,effective_from)) STRICT');db.executemany('INSERT INTO _manager_performance_periods VALUES (?,?,?,?,?,?,?,?,?)',rows)
  db.execute('DROP VIEW manager_performance');db.execute('''CREATE VIEW manager_performance AS SELECT p.manager_id,p.manager_name,p.game_type,p.league,p.as_of_date,
  coalesce(m.games_played,0) AS games_played,coalesce(m.overall_winrate,0.0) AS overall_winrate,coalesce(m.home_times,0) AS home_times,coalesce(m.away_times,0) AS away_times,coalesce(m.average_score_margin,0.0) AS average_score_margin
  FROM manager_profiles p LEFT JOIN _manager_performance_periods m ON m.manager_id=p.manager_id AND m.league=p.league AND m.effective_from<=p.as_of_date AND m.effective_to>p.as_of_date''')
 print('Serving-manager performance',db.execute('SELECT count(*) FROM manager_performance').fetchone()[0],'dated rows');db.close()
if __name__=='__main__':main()
