"""Thread-safe, resumable public GET client with raw-first logging and backoff."""
import datetime as dt,email.utils,hashlib,json,os,threading,time,uuid
from urllib.parse import urlsplit
import requests
from probe_history import ROOT,HOSTS
from request_audit import all_records,connect,save
from shared_http_limits import initialize,acquire,cooldown

class HistoryClient:
 def __init__(self,root=ROOT):
  self.root=root;self.lock=threading.Lock();self.rate_lock=threading.Lock();self.local=threading.local();self.next_at={};self.cache={};self.requests=0
  db=connect(root);initialize(db);db.close()
  for r in all_records(root):
   if r.get('status')==200:
    previous=self.cache.get(r['cache_key'])
    def capture(record):return (record.get('retrieved_at_utc') or record['requested_at_utc'],record['requested_at_utc'],record['request_id'])
    if previous is None or capture(r)>capture(previous):self.cache[r['cache_key']]=r
 def get(self,url,params=None,document=False,refresh=False):
  host=urlsplit(url).hostname
  if urlsplit(url).scheme!='https' or host not in HOSTS:raise ValueError('Unapproved public HTTPS host')
  headers={}
  params=params or {}
  if any(any(s in k.lower() for s in ['secret','password','key','token']) for k in params if k!='token_id'):raise ValueError('Secrets must never enter request logs')
  cache_parts=[url,params]
  key=hashlib.sha256(json.dumps(cache_parts,sort_keys=True).encode()).hexdigest()
  with self.lock:r=self.cache.get(key)
  if r and not refresh:
   b=(self.root/r['raw_file']).read_bytes()
   if hashlib.sha256(b).hexdigest()!=r['sha256']:raise ValueError('Raw response hash mismatch')
   return (b if document else json.loads(b)),r
  if not hasattr(self.local,'session'):
   self.local.session=requests.Session();self.local.session.headers['User-Agent']='SentinentSnakeResearch/3.0'
   self.local.audit=connect(self.root)
  for attempt in range(1,6):
   acquire(self.local.audit,host)
   with self.lock:
    if self.requests>=int(os.getenv('HISTORY_MAX_REQUESTS','60000')):raise RuntimeError('Acquisition request budget exhausted')
    self.requests+=1
   now=lambda:dt.datetime.now(dt.UTC).isoformat()
   r=dict(request_id=uuid.uuid4().hex,method='GET',endpoint=url,parameters=params,requested_at_utc=now(),attempt=attempt,cache_key=key,status=None,request_state='in_flight')
   save(self.local.audit,r)
   try:
    response=self.local.session.get(url,params=params,headers=headers,timeout=(10,45),allow_redirects=False);b=response.content
    path=self.root/'data/raw/responses'/(r['request_id']+('.bin' if document else '.json'));path.parent.mkdir(exist_ok=True);path.write_bytes(b)
    r.update(status=response.status_code,raw_file=path.relative_to(self.root).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),retrieved_at_utc=now(),content_type=response.headers.get('Content-Type'),retry_after=response.headers.get('Retry-After'),location=response.headers.get('Location'))
   except requests.RequestException as e:r.update(status=None,error=str(e),retrieved_at_utc=now())
   r['request_state']='complete'
   with self.lock:
    save(self.local.audit,r)
    if r['status']==200:self.cache[key]=r
   if r['status']==200:return (b if document else json.loads(b)),r
   if r['status'] not in {None,408,429,500,502,503,504}:raise RuntimeError('HTTP failure '+str(r['status'])+'; request '+r['request_id'])
   delay=2**attempt
   if r.get('retry_after'):
    try:delay=max(delay,float(r['retry_after']))
    except ValueError:delay=max(delay,(email.utils.parsedate_to_datetime(r['retry_after'])-dt.datetime.now(dt.UTC)).total_seconds())
   if r['status']==429:delay=max(delay,30)
   cooldown(self.local.audit,host,delay,rate_limited=r['status']==429)
   if attempt==5:raise RuntimeError('HTTP failure '+str(r['status'])+'; request '+r['request_id'])
   if delay>60:raise RuntimeError('Long rate limit; resume after '+str(delay)+' seconds')
   time.sleep(delay)
