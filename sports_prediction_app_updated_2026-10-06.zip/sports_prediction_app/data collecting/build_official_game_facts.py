"""Join league-authored results to the canonical game; never source results from markets."""
import collections,datetime as dt,json,re,sqlite3,unicodedata
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
from history_index import records
from official_html import decode_html

def namekey(s):
    s=''.join(c for c in unicodedata.normalize('NFKD',s) if not unicodedata.combining(c))
    s=re.sub('[^a-z0-9]','',s.lower())
    return {'oaklandathletics':'athletics','losangelesclippers':'laclippers'}.get(s,s)

def nhl_period_scores(body,finals):
    soup=body if isinstance(body,BeautifulSoup) else BeautifulSoup(decode_html(body),'html.parser');parts=[]
    for table in soup.find_all('table'):
        rows=[[x.get_text(' ',strip=True) for x in tr.find_all(['td','th'],recursive=False)] for tr in table.find_all('tr',recursive=False)]
        if not rows or rows[0]!=['Per','Goals','Shots','PN','PIM']:continue
        periods={};total=None
        for cells in rows[1:]:
            if cells[0] in {'1','2','3'}:periods[int(cells[0])]=int(cells[1])
            elif cells[0]=='TOT':total=int(cells[1])
        if set(periods)!={1,2,3} or total is None:raise ValueError('Incomplete NHL period score table')
        parts.append((periods,total))
    if len(parts)!=2:raise ValueError('NHL period score tables absent')
    totals=[x[1] for x in parts]
    if totals!=finals:
        # The period table excludes the shootout winner's extra scoreboard
        # goal. Require both the tied hockey total and an explicit SO entry.
        shootout=totals[0]==totals[1] and [f-t for f,t in zip(finals,totals)] in ([1,0],[0,1]) and re.search(r'\bSO\b',soup.get_text(' ',strip=True))
        if not shootout:raise ValueError('NHL period total does not match final')
    return [[0,0],[parts[0][0][1],parts[1][0][1]],[parts[0][0][1]+parts[0][0][2],parts[1][0][1]+parts[1][0][2]]]

def main():
    db=sqlite3.connect(DB,timeout=60);games=[json.loads(x[0]) for x in db.execute('SELECT body FROM _history_games')];rs={r['request_id']:r for r in records()}
    reports=[json.loads(x[0]) for x in db.execute('SELECT body FROM _official_game_reports')];idx=collections.defaultdict(list)
    for r in reports:idx[r['league'],r['date'],frozenset(map(namekey,r['teams']))].append(r)
    nba=collections.defaultdict(list)
    for (body,) in db.execute('SELECT body FROM _official_nba_schedule'):
        r=json.loads(body);nba[r['date'],frozenset(r['team_tricodes'])].append(r)
    cp=collections.defaultdict(list)
    for (s,) in db.execute('SELECT body FROM _history_checkpoints'):
        x=json.loads(s);cp[x['game_id']].append(x)
    facts=[];audit=[]
    for g in games:
        gid=g['game_id'];row=None
        if g['league']=='NBA':
            parts=gid.split('_');cards=nba[g['date'],frozenset(parts[2:4])]
            if g.get('official_score_request_id') and g.get('validation_status')=='OFFICIAL_NBA_FINAL_VERIFIED':
                scores=g['scores'];rid=g['official_score_request_id'];r=rs[rid]
                row=dict(game_id=gid,league='NBA',date=g['date'],teams=g['teams'],scores=scores,winner=g['teams'][int(scores[1]>scores[0])],home_away=g.get('home_away'),location=g.get('location'),city=g.get('city'),request_id=rid,source_url=r['endpoint'],official_game_id=None,
                    break_scores=[[x['teamA_score'],x['teamB_score']] if x.get('score_request_id')==rid else [None,None] for x in sorted(cp[gid],key=lambda x:x['ordinal'])])
            if len(cards)==1:
                c=cards[0];order=[c['team_tricodes'].index(t) for t in parts[2:4]];scores=[c['scores'][i] for i in order]
                if row and row['scores']!=scores:
                    audit.append(dict(game_id=gid,reason='Official NBA date page and report disagree',report_scores=row['scores'],date_page_scores=scores,request_ids=[row['request_id'],c['request_id']],resolution_status='UNRESOLVED_OFFICIAL_CONFLICT'))
                    row=None
                elif row:
                    row.update(official_game_id=c['official_game_id'],season_year=c.get('season_year'),competition_type=c['competition_type'],is_training=c['is_training'],classification_request_id=c['request_id'],scheduled_start_utc=c['start_utc'])
                else:
                    row=dict(game_id=gid,league='NBA',date=c['date'],teams=g['teams'],scores=scores,winner=g['teams'][int(scores[1]>scores[0])],home_away=';'.join(['Away','Home'][i] for i in order),location=None,city=None,request_id=c['request_id'],source_url=c['source_url'],official_game_id=c['official_game_id'],break_scores=[[s[i] for i in order] for s in c['break_scores']],season_year=c.get('season_year'),competition_type=c['competition_type'],is_training=c['is_training'],classification_request_id=c['request_id'],scheduled_start_utc=c['start_utc'])
            elif len(cards)>1:audit.append(dict(game_id=gid,reason='Multiple official NBA game cards for same date and teams',candidate_game_ids=[c['official_game_id'] for c in cards]))
        else:
            matches=idx[g['league'],g['date'],frozenset(map(namekey,g['teams']))]
            if len(matches)>1 and g['league']=='MLB':
                ordinal=int(gid.rsplit('_G',1)[1]);matches=[m for m in matches if m.get('doubleheader_number')==ordinal]
            if len(matches)==1:
                m=matches[0];order=[next(i for i,n in enumerate(m['teams']) if namekey(n)==namekey(team)) for team in g['teams']];scores=[m['scores'][i] for i in order];rid=m['request_id'];r=rs[rid]
                if g['league']=='MLB':
                    cpvalues=[[0,0]]
                    for n in [3,5,7]:cpvalues.append([sum(v for v in m['innings'][i][:n] if v is not None) if len(m['innings'][i])>=n else None for i in range(2)])
                else:
                    try:cpvalues=nhl_period_scores((ROOT/r['raw_file']).read_bytes(),m['scores'])
                    except Exception as e:audit.append(dict(game_id=gid,reason=str(e),request_id=rid));cpvalues=[[None,None]]*3
                row=dict(game_id=gid,league=g['league'],date=m['date'],teams=g['teams'],scores=scores,winner=g['teams'][int(scores[1]>scores[0])] if scores[0]!=scores[1] else None,home_away=';'.join(m['home_away'].split(';')[i] for i in order),location=m.get('location') or g.get('location'),city=g.get('city'),request_id=rid,source_url=r['endpoint'],official_game_id=m['official_game_id'],break_scores=[[s[i] for i in order] for s in cpvalues])
                row.update(competition_type=m.get('competition_type'),is_training=m.get('is_training'),classification_request_id=rid)
                if g['league']=='NHL':
                    kind=m['official_game_id'][4:6];year=int(m['official_game_id'][:4]);row.update(season_year=f'{year}-{(year+1)%100:02d}',competition_type={'01':'Preseason','02':'Regular Season','03':'Playoffs'}.get(kind),is_training=kind=='01')
                else:row['season_year']=m['date'][:4]
                if all(v is not None for v in g['scores']) and scores!=g['scores']:audit.append(dict(game_id=gid,reason='Official final score differs from provider',provider_scores=g['scores'],official_scores=scores,request_id=rid,resolution_status='RESOLVED_OFFICIAL_SCORER'))
                if row['winner']!=g['winner']:audit.append(dict(game_id=gid,reason='Official winner differs from provider',provider_winner=g['winner'],official_winner=row['winner'],request_id=rid,resolution_status='RESOLVED_OFFICIAL_SCORER'))
            elif len(matches)>1:audit.append(dict(game_id=gid,reason='Multiple official games need distinct doubleheader mapping',candidate_game_ids=[m['official_game_id'] for m in matches]))
        if row:
            row['season']=' '.join(str(row[k]) for k in ['season_year','competition_type'] if row.get(k)) or None
            facts.append(row)
        else:audit.append(dict(game_id=gid,reason='No uniquely verified official result acquired'))
    db.execute('CREATE TABLE IF NOT EXISTS _official_game_facts (game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _official_game_facts')
    db.executemany('INSERT INTO _official_game_facts VALUES (?,?)',[(r['game_id'],json.dumps(r)) for r in facts]);db.execute('CREATE TABLE IF NOT EXISTS _official_result_audit (body TEXT NOT NULL)');db.execute('DELETE FROM _official_result_audit');db.executemany('INSERT INTO _official_result_audit VALUES (?)',[(json.dumps(x),) for x in audit]);db.commit();db.close()
    result=dict(matched_games=len(games),official_results=len(facts),by_league=dict(collections.Counter(r['league'] for r in facts)),issues=dict(collections.Counter(x['reason'] for x in audit)))
    (ROOT/'reports/official_result_matching.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))

if __name__=='__main__':main()
