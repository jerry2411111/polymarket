"""Dated GOAL European overall rankings with conservative official identity links."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_nba_ranking_facts import source_dates
from collect_laliga_people import namekey
from probe_history import ROOT

def main():
 db=sqlite3.connect(DB,timeout=60);people={pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _eu_people_registry')};published={p for p, in db.execute('SELECT DISTINCT player_id FROM _eu_player_game_facts')};aliases=collections.defaultdict(set);games=collections.defaultdict(list)
 for pid,p in people.items():
  if p['kind']=='player' and pid in published:
   for n in [p['person_name']]+p['aliases']:aliases[namekey(n)].add(pid)
 for b, in db.execute('SELECT body FROM _eu_player_game_facts'):
  p=json.loads(b);games[p['player_id']].append(p)
 rows=[];editions=[];missing=[]
 for b, in db.execute("SELECT body FROM _eu_editorial_sources WHERE json_extract(body,'$.kind')='ranking' AND json_extract(body,'$.publisher')='goal'"):
  source=json.loads(b)
  if source['status']=='UNAVAILABLE':continue
  published_date,version_date,article=source_dates(source);rid=source['request_id'];audit=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);raw=(ROOT/audit['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==audit['sha256'];soup=BeautifulSoup(raw,'html.parser');eid='EU_GOAL_'+published_date;edition=[]
  for index,h in enumerate(soup.select('h2')):
   text=h.get_text(' ',strip=True);m=re.fullmatch(r'(\d+)\s+(.+?)\s*\((.+)\)',text)
   if not m:continue
   rank=int(m[1]);name=m[2];club=m[3];lookup={'Vinicius Jr':'Vinícius Júnior'}.get(name,name);candidates=aliases[namekey(lookup)];club_names={'Barcelona':'FC Barcelona','Real Madrid':'Real Madrid C.F.','Paris Saint-Germain':'Paris Saint-Germain'}
   if len(candidates)>1:
    candidates={pid for pid in candidates if any(p['team_name']==club_names.get(club,club) and p['game_date']<=version_date for p in games[pid])}
   pid=next(iter(candidates)) if len(candidates)==1 else None
   row=dict(list_id=eid,publisher_key='goal',league='EU soccer',scope='European overall',publication_date=published_date,version_verified_date=version_date,rank=rank,source_player_name=name,source_club=club,player_id=pid,player_name=people[pid]['person_name'] if pid else None,request_id=rid,source_url=source['url'],selector='h2',index=index,raw_value=text)
   if pid:
    ps=[p for p in games[pid] if p['game_date']<=version_date];row['official_club_candidates']=sorted({p['team_name'] for p in ps});row['official_name_aliases']=people[pid]['aliases']
   else:missing.append(row)
   rows.append(row);edition.append(row)
  assert len(edition)==50 and {r['rank'] for r in edition}==set(range(1,51)),eid
  editions.append(dict(list_id=eid,publisher_key='goal',league='EU soccer',scope='European overall',publication_date=published_date,version_verified_date=version_date,complete_list=True,request_id=rid,note='Original GOAL European-season overall Top 50. Later modification date controls historical availability. Quarterly observations carry the latest eligible edition; no invented quarterly publications. Publisher Europe-wide scope includes clubs outside the five domestic leagues when covered by the combined UEFA Champions League dataset.'))
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _eu_ranking_candidate_facts (body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _eu_ranking_candidate_facts');db.executemany('INSERT INTO _eu_ranking_candidate_facts VALUES (?)',[(json.dumps(r),) for r in rows]);db.execute('CREATE TABLE IF NOT EXISTS _eu_ranking_candidate_editions (list_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _eu_ranking_candidate_editions');db.executemany('INSERT INTO _eu_ranking_candidate_editions VALUES (?,?)',[(e['list_id'],json.dumps(e)) for e in editions])
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='CANDIDATES_REQUIRE_IDENTITY_REVIEW',editions=len(editions),rank_facts=len(rows),unmatched=[{k:r[k] for k in ['list_id','rank','source_player_name','source_club']} for r in missing]);(ROOT/'reports/eu_goal_ranking_candidates.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
if __name__=='__main__':main()
