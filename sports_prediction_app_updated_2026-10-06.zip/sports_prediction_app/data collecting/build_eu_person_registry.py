"""Conservative person crosswalk using documented native IDs, full names and DOB."""
import collections,datetime as dt,json,re,sqlite3
from build_history_catalog import DB
from collect_laliga_people import namekey
from probe_history import ROOT

def day(v):
 try:return dt.date.fromisoformat(str(v)[:10]).isoformat()
 except ValueError:return None

def positive(v):
 try:return float(v) if float(v)>0 else None
 except (ValueError,TypeError):return None

def main():
 db=sqlite3.connect(DB,timeout=60);db.execute('BEGIN');people={};issues=[];edges=[];birth_resolutions=[]
 def person(pid,kind,code):return people.setdefault(pid,dict(source_person_id=pid,kind=kind,competition_code=code,names=set(),births=set(),bios=[],observations=[],native_profile_ids=set(),stable=True))
 def bio(p,names,birth,height,weight,rid,source):
  p['names'].update(n for n in names if n);birth=day(birth)
  if birth:p['births'].add(birth)
  p['bios'].append(dict(birth_date=birth,height_cm=positive(height),weight_kg=positive(weight),request_id=rid,source=source))
 lal={k:json.loads(b) for k,b in db.execute('SELECT * FROM _official_laliga_people_sources')};bun={k:json.loads(b) for k,b in db.execute('SELECT * FROM _official_bundesliga_people_sources')};sea={k:json.loads(b) for k,b in db.execute('SELECT * FROM _official_seriea_people_sources')};lal_revisions={pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _official_laliga_native_profile_revisions')} if db.execute("SELECT 1 FROM sqlite_master WHERE name='_official_laliga_native_profile_revisions'").fetchone() else {};ambiguous_names={namekey(n) for r in lal_revisions.values() for n in r['source_names']};quarantined=set()
 extras={pid:json.loads(b) for b, in db.execute('SELECT body FROM _eu_opta_biographies') for pid in json.loads(b)['source_person_ids']} if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_opta_biographies'").fetchone() else {}
 for extra in extras.values():
  for name in extra['aliases']:
   row=lal.get(namekey(name))
   if row and row['status']=='ok' and extra['birth_date'] and day(row['data'].get('date_of_birth')) and extra['birth_date']!=day(row['data']['date_of_birth']) and not re.findall(r'/(p\d+)/',str(row['data'].get('squads',[]))):ambiguous_names.add(namekey(name))
 for key,b in db.execute('SELECT * FROM _epl_people_biographies'):
  v=json.loads(b);kind=v['kind'];pid=('EU_PL:' if kind=='player' else 'EU_PL_COACH:')+v['official_person_id'];p=person(pid,kind,'PL');bio(p,[v['person_name']],v['birth_date'],v['height_cm'],v['weight_kg'],v['biography_request_id'],'Official Premier League biography')
 for table,kind in [('_epl_player_game_facts','player'),('_epl_manager_game_facts','manager'),('_eu_source_player_game_facts','player'),('_eu_source_manager_game_facts','manager')]:
  for b, in db.execute('SELECT body FROM '+table):
   v=json.loads(b);pid=v[kind+'_id'];code=v.get('competition_code','PL');p=person(pid,kind,code);p['names'].add(v[kind+'_name']);p['names'].update(v.get('aliases',[]));p['stable'] &= v.get('source_identity_stable',True);rid=v.get('roster_request_id') or v['request_id'];p['observations'].append(dict(game_id=v['game_id'],date=v['game_date'],team_name=v['team_name'],official_team_id=v.get('official_team_id'),request_id=rid));native=pid.split(':',1)[1];b=v.get('biography',{})
   if b:bio(p,[],b.get('birth_date'),b.get('height_cm'),b.get('weight_kg'),rid,'Dated official lineup person object')
   if code=='BUN' and native in bun and bun[native]['status']=='ok':
    row=bun[native];d=row['data'];height=d.get('bio',{}).get('height') or {};weight=d.get('bio',{}).get('weight') or {};assert not height or height.get('unit')=='cm';assert not weight or weight.get('unit')=='kg';bio(p,list(d['names'].values()),d.get('birth',{}).get('date'),height.get('height'),weight.get('weight'),row['request_id'],'Official Bundesliga profile with explicit units')
   elif code=='LAL' and kind=='player':
    row=lal_revisions.get(pid) or lal.get(namekey(v['player_name']))
    if row and row['status']=='ok':
     assets=set(re.findall(r'/(p\d+)/',str(row['data'].get('squads',[]))))
     extra=extras.get(pid);same_dob=bool(extra and extra['birth_date'] and extra['birth_date']==day(row['data'].get('date_of_birth')))
     if (native.startswith('p') and ((assets and native not in assets) or (not assets and not same_dob))) or (not native.startswith('p') and namekey(v['player_name']) in ambiguous_names):quarantined.add(pid);row=None
    elif pid in lal_revisions:quarantined.add(pid)
    if row and row['status']=='ok':
     d=row['data']
     if 'source_lineup_ids' in row:assert str(v['raw_player']['id']) in row['source_lineup_ids']
     p['native_profile_ids'].add(row['person_id']);bio(p,[d['name'],' '.join(filter(None,[d.get('firstname'),d.get('lastname')]))],d.get('date_of_birth'),d.get('height'),d.get('weight'),row['request_id'],'Official LaLiga profile; native asset ID checked whenever available; ambiguous same-name profiles quarantined')
   elif code=='SEA' and kind=='player' and native in sea and sea[native]['status']=='ok':
    row=sea[native];d=row['data'];bio(p,[' '.join(filter(None,[d.get('mediaFirstName'),d.get('mediaLastName')])),d.get('shortName')],d.get('dateOfBirth'),d.get('height'),d.get('weight'),row['request_id'],'Official Serie A profile linked by native UUID')
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_opta_biographies'").fetchone():
  for b, in db.execute('SELECT body FROM _eu_opta_biographies'):
   v=json.loads(b)
   for pid in v['source_person_ids']:
    if pid in people:bio(people[pid],v['aliases'],v['birth_date'],v['height_cm'],v['weight_kg'],v['biography_request_id'],'Official Premier League global biography matched by source-native Opta/asset ID and dated name; independent Ligue 1 DOB when available')
 reviews=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_person_alias_reviews')] if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_person_alias_reviews'").fetchone() else []
 for review in reviews:
  for pid in review['source_person_ids']:
   assert pid in people and review['person_name'] in people[pid]['names'];source=next(s for s in review['sources'] if s['kind']=='profile');bio(people[pid],[review['person_name']],review.get('birth_date'),None,None,source['request_id'],'Reviewed official club person biography and dated same-role evidence')
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_documented_player_aliases'").fetchone():
  for b, in db.execute('SELECT body FROM _eu_documented_player_aliases'):
   a=json.loads(b);assert a['source_person_id'] in people;people[a['source_person_id']]['names'].add(a['alias'])
 # Reduce repeated observations of the same source biography before grouping.
 for p in people.values():
  p['bios']=list({json.dumps(b,sort_keys=True):b for b in p['bios']}.values());p['birth_date']=next(iter(p['births'])) if len(p['births'])==1 else None
  if len(p['births'])>1:
   primary={b['birth_date'] for b in p['bios'] if b['birth_date'] and ((p['competition_code']=='LAL' and b['source'].startswith('Official LaLiga profile')) or (p['competition_code']=='FL1' and b['source']=='Dated official lineup person object'))}
   if len(primary)==1:
    p['birth_date']=next(iter(primary));resolution=dict(source_person_id=p['source_person_id'],field='birth_date',raw_values=sorted(p['births']),selected=p['birth_date'],reason='Prefer the directly responsible league source with verified native identity over a different league global biography service; all conflicting official values retained');birth_resolutions.append(resolution)
   else:issues.append(dict(source_person_id=p['source_person_id'],field='birth_date',values=sorted(p['births']),reason='Conflicting official values; DOB withheld and not used for cross-provider matching'))
 parent={pid:pid for pid in people};members={pid:{pid} for pid in people}
 def root(pid):
  while parent[pid]!=pid:parent[pid]=parent[parent[pid]];pid=parent[pid]
  return pid
 def union(a,b,basis,proof):
  ra,rb=root(a),root(b)
  if ra==rb:return
  merged=members[ra]|members[rb];codes=collections.defaultdict(list)
  for pid in merged:codes[people[pid]['competition_code']].append(pid)
  # Multiple LaLiga photo/lineup IDs can represent one explicitly verified profile.
  for code,pids in codes.items():
   reviewed=any(set(pids)<=set(r['source_person_ids']) for r in reviews)
   if len(pids)>1 and not reviewed and not (code=='LAL' and len(set.intersection(*(people[pid]['native_profile_ids'] for pid in pids)))==1):
    issues.append(dict(field='person_matching',source_person_ids=sorted(merged),reason='More than one native person ID in one competition; review before merging',basis=basis));return
  if len({people[p]['kind'] for p in merged})!=1:return
  ra,rb=sorted([ra,rb]);parent[rb]=ra;members[ra]=merged;del members[rb];edges.append(dict(source_a=a,source_b=b,basis=basis,proof=proof))
 same_lal=collections.defaultdict(list);dated_names=collections.defaultdict(set)
 for pid,p in people.items():
  for native in p['native_profile_ids']:same_lal[native].append(pid)
  if p['birth_date']:
   for n in p['names']:
    # Single-name and initial-only labels cannot establish cross-provider identity.
    words=n.replace('-',' ').split()
    if len(words)>=2 and all(len(namekey(w))>1 for w in words):dated_names[p['kind'],namekey(n),p['birth_date']].add(pid)
 for native,ids in same_lal.items():
  for pid in sorted(ids)[1:]:union(sorted(ids)[0],pid,'Same official LaLiga profile ID with independently verified dated lineup names',dict(profile_id=native))
 for (kind,n,dob),ids in sorted(dated_names.items()):
  ids=sorted(ids)
  for pid in ids[1:]:union(ids[0],pid,'Exact normalized official full name and birth date',dict(normalized_name=n,birth_date=dob))
 # Coaches often have no DOB in a lineup. The same complete official name
 # serving the same native-linked club in nearby dated reports supplies a
 # second independent identifier; short surnames alone are never sufficient.
 clubmap={(code,tid):json.loads(b) for code,tid,b in db.execute('SELECT * FROM _eu_team_identity')};clubnames=collections.defaultdict(set)
 for t in clubmap.values():clubnames[t['competition_code'],t['team_name']].add(t['team_id'])
 coaches=collections.defaultdict(set)
 for pid,p in people.items():
  if p['kind']=='manager':
   for n in p['names']:
    if len(n.split())>=2 and all(len(namekey(w))>1 for w in n.split()):coaches[namekey(n)].add(pid)
 def clubobs(p):
  out=[]
  for o in p['observations']:
   t=clubmap.get((p['competition_code'],str(o['official_team_id']))) if o['official_team_id'] is not None else None;ids={t['team_id']} if t else clubnames[p['competition_code'],o['team_name']]
   if len(ids)==1:out.append((next(iter(ids)),dt.date.fromisoformat(o['date']),o))
  return out
 for name,ids in sorted(coaches.items()):
  ids=sorted(ids)
  for i,a in enumerate(ids):
   for b in ids[i+1:]:
    if root(a)==root(b) or people[a]['competition_code']==people[b]['competition_code']:continue
    if people[a]['birth_date'] and people[b]['birth_date'] and people[a]['birth_date']!=people[b]['birth_date']:continue
    obs_a=clubobs(people[a]);obs_b=clubobs(people[b]);proof=next((dict(normalized_name=name,canonical_team_id=ta,observation_a=oa,observation_b=ob) for ta,da,oa in obs_a for tb,dd,ob in obs_b if ta==tb and abs((da-dd).days)<=14),None)
    if proof:union(a,b,'Exact official full name and same native-linked club in official head-coach reports within 14 days',proof)
 # A shared playing name is insufficient alone. DOB plus the same native-linked
 # club in dated reports supplies two additional independent identity checks.
 playing_names=collections.defaultdict(set)
 for pid,p in people.items():
  if p['kind']=='player' and p['birth_date']:
   for n in p['names']:
    if len(namekey(n))>=3:playing_names[namekey(n),p['birth_date']].add(pid)
 for (name,dob),ids in sorted(playing_names.items()):
  ids=sorted(ids)
  for i,a in enumerate(ids):
   for b in ids[i+1:]:
    if root(a)==root(b) or people[a]['competition_code']==people[b]['competition_code']:continue
    proof=next((dict(normalized_name=name,birth_date=dob,role='player',canonical_team_id=ta,observation_a=oa,observation_b=ob) for ta,da,oa in clubobs(people[a]) for tb,dd,ob in clubobs(people[b]) if ta==tb and abs((da-dd).days)<=14),None)
    if proof:union(a,b,'Exact official playing name and DOB plus same native-linked club in dated reports within 14 days',proof)
 groups=collections.defaultdict(list)
 for pid in people:groups[root(pid)].append(pid)
 canonical=[];cross=[];priority={'PL':0,'UCL':1,'BUN':2,'SEA':3,'FL1':4,'LAL':5}
 for ids in groups.values():
  ids.sort(key=lambda pid:(priority[people[pid]['competition_code']],pid));cid=ids[0];ps=[people[pid] for pid in ids];names={n for p in ps for n in p['names']};births={p['birth_date'] for p in ps}-{None};assert len(births)<=1;bios=[b for p in ps for b in p['bios']];bio_fields={};conflicts={}
  for k in ['height_cm','weight_kg']:
   vals={b[k] for b in bios if b[k] is not None};bio_fields[k]=next(iter(vals)) if len(vals)==1 else None
   if len(vals)>1:
    # The user permits one constant. Select the latest retrieved official value,
    # retaining conflicting raw observations and source timestamps in the audit.
    candidates=[]
    for b in bios:
     if b[k] is None:continue
     meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(b['request_id'],)).fetchone()[0]);candidates.append((meta.get('retrieved_at_utc') or meta.get('retrieved_at') or '',b['request_id'],b[k]))
    assert candidates;chosen=max(candidates);bio_fields[k]=chosen[2];conflicts[k]=dict(values=sorted(vals),selected_request_id=chosen[1],policy='Latest retrieved official constant, without altering raw values')
  row=dict(person_id=cid,kind=ps[0]['kind'],person_name=max(names,key=lambda n:(len(n.split()),len(n),n)),aliases=sorted(names),birth_date=next(iter(births)) if births else None,**bio_fields,source_person_ids=ids,biography_sources=bios,constant_value_differences=conflicts,first_collected_date=min(o['date'] for p in ps for o in p['observations']) if any(p['observations'] for p in ps) else None)
  canonical.append((cid,json.dumps(row)));cross.extend((pid,cid,json.dumps(dict(source_person_id=pid,person_id=cid,kind=people[pid]['kind'],source_identity_stable=people[pid]['stable'] or bool(people[pid]['native_profile_ids']),names=sorted(people[pid]['names']),birth_date=people[pid]['birth_date'],source_native_profile_ids=sorted(people[pid]['native_profile_ids'])))) for pid in ids)
 # End the read snapshot before acquiring a write transaction. Collectors may
 # have appended unrelated request records meanwhile; upgrading an older WAL
 # read snapshot directly would fail with SQLITE_BUSY_SNAPSHOT.
 (ROOT/'reports/eu_birth_date_source_resolutions.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),resolutions=birth_resolutions),indent=2),encoding='utf-8')
 db.commit()
 with db:
  for table,cols in [('_eu_people_registry','person_id TEXT PRIMARY KEY,body TEXT NOT NULL'),('_eu_person_crosswalk','source_person_id TEXT PRIMARY KEY,person_id TEXT NOT NULL,body TEXT NOT NULL')]:db.execute('CREATE TABLE IF NOT EXISTS '+table+' ('+cols+') STRICT');db.execute('DELETE FROM '+table)
  db.executemany('INSERT INTO _eu_people_registry VALUES (?,?)',canonical);db.executemany('INSERT INTO _eu_person_crosswalk VALUES (?,?,?)',cross);db.execute('CREATE TABLE IF NOT EXISTS _eu_person_identity_edges (body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _eu_person_identity_edges');db.executemany('INSERT INTO _eu_person_identity_edges VALUES (?)',[(json.dumps(e),) for e in edges])
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING' if issues else 'WORKING',source_people=len(people),canonical_people=len(canonical),linked_source_ids=len(people)-len(canonical),identity_edges=len(edges),counts_by_kind=dict(collections.Counter(json.loads(b)['kind'] for _,b in canonical)),missing={k:sum(json.loads(b)[k] is None for _,b in canonical) for k in ['birth_date','height_cm','weight_kg']},quarantined_laliga_biography_links=sorted(quarantined),issues=issues,scope='Source-native person crosswalk only; public profiles and performance must be rebuilt separately after odds-game filtering. No names alone or current clubs establish a historical person link.');(ROOT/'reports/eu_person_registry.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='issues'}));print('IDENTITY ISSUES',len(issues),json.dumps(issues[:8]));db.close()

if __name__=='__main__':main()
