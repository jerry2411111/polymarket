"""Clock-time break intervals from official NBA report play-by-play pages.

Minute-labelled endpoints have one minute of uncertainty. Safe interval begins
after the full reported end minute and ends at the beginning of the next start
minute. Exact provider clocks can narrow that uncertainty independently.
"""
import argparse,datetime as dt,io,json,re,sqlite3
from zoneinfo import ZoneInfo
from pypdf import PdfReader
from probe_history import ROOT
from build_history_catalog import DB
from history_index import records
from core import utc

ZONES={
 'Boston':'America/New_York','Brooklyn':'America/New_York','New York':'America/New_York','Philadelphia':'America/New_York','Toronto':'America/Toronto',
 'Cleveland':'America/New_York','Detroit':'America/Detroit','Indianapolis':'America/Indiana/Indianapolis','Atlanta':'America/New_York','Charlotte':'America/New_York','Miami':'America/New_York','Orlando':'America/New_York','Washington':'America/New_York',
 'Chicago':'America/Chicago','Milwaukee':'America/Chicago','Minneapolis':'America/Chicago','Oklahoma City':'America/Chicago','Dallas':'America/Chicago','Houston':'America/Chicago','Memphis':'America/Chicago','New Orleans':'America/Chicago','San Antonio':'America/Chicago',
 'Denver':'America/Denver','Salt Lake City':'America/Denver','Phoenix':'America/Phoenix','Portland':'America/Los_Angeles','San Francisco':'America/Los_Angeles','Los Angeles':'America/Los_Angeles','Inglewood':'America/Los_Angeles','Sacramento':'America/Los_Angeles','San Diego':'America/Los_Angeles','Las Vegas':'America/Los_Angeles',
 'Abu Dhabi':'Asia/Dubai','Mexico City':'America/Mexico_City','Paris':'Europe/Paris','Honolulu':'Pacific/Honolulu',
 'Austin':'America/Chicago','Palm Desert':'America/Los_Angeles','San Juan':'America/Puerto_Rico','Puerto Rico':'America/Puerto_Rico',
 'Charleston':'America/New_York','Vancouver':'America/Vancouver','Fort Worth':'America/Chicago',
 'Macao':'Asia/Macau','Macau':'Asia/Macau','Birmingham':'America/Chicago','Greensboro':'America/New_York',
 'Berlin':'Europe/Berlin','London':'Europe/London'}

def parse(body,g):
    city=g.get('city');zone=ZONES.get(city) or ZONES.get((city or '').split(',',1)[0].strip())
    if not zone:raise ValueError('Venue city has no verified clock-zone mapping: '+str(city))
    reader=PdfReader(io.BytesIO(body));events=[]
    for n,page in enumerate(reader.pages):
        # First eight pages normally contain boxes; skip by content, not count,
        # because report layouts and overtime length vary.
        text=page.extract_text()
        for hit in re.finditer(r'(Start|End) of Period\s*\((\d{1,2}:\d{2}\s*[AP]M)\)',text):
            raw=hit[2];clock=dt.datetime.strptime(raw,'%I:%M %p').time();local=dt.datetime.combine(dt.date.fromisoformat(g['date']),clock,tzinfo=ZoneInfo(zone));time=local.astimezone(dt.UTC)
            # An evening game can cross midnight. A malformed later clock
            # must not shift all subsequent events onto a fabricated next day.
            if events and clock.hour<12 and dt.datetime.strptime(events[0]['raw_clock'],'%I:%M %p').hour>=12:time+=dt.timedelta(days=1)
            events.append(dict(kind=hit[1].lower(),timestamp_utc=time.isoformat(),page=n+1,raw_clock=raw))
    if len(events)<8 or [x['kind'] for x in events[:8]]!=['start','end']*4:raise ValueError('Incomplete or unordered official period clocks')
    start=utc(events[0]['timestamp_utc']);scheduled=utc(g['start'])
    if abs((start-scheduled).total_seconds())>3*3600:raise ValueError('Official opening clock differs from game start by >3h; review timezone/date')
    intervals=[]
    for q in range(1,4):
        end=events[2*q-1];begin=events[2*q];lo=utc(end['timestamp_utc'])+dt.timedelta(minutes=1);hi=utc(begin['timestamp_utc'])
        raw_seconds=(hi-utc(end['timestamp_utc'])).total_seconds()
        # Minute labels can leave no guaranteed interior for one short break.
        # Preserve the other verified periods and mark only this one missing.
        valid=0<=raw_seconds<3600;usable=valid and hi>lo
        reason=None if usable else 'Minute-labelled break has no guaranteed interior' if valid else 'Official clock labels produce an invalid break length; other verified periods retained'
        intervals.append(dict(ordinal=q,start_utc=lo.isoformat() if usable else None,end_utc=hi.isoformat() if usable else None,raw_end=end,raw_next_start=begin,uncertainty_seconds=60,reason=reason))
    return dict(game_id=g['game_id'],official_start_utc=start.isoformat(),timezone=zone,city=city,events=events,breaks=intervals)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--from-date',default='2024-01-01');ap.add_argument('--through-date',default=dt.date.today().isoformat());ap.add_argument('--limit',type=int);args=ap.parse_args()
    db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _official_nba_clocks (game_id TEXT PRIMARY KEY,request_id TEXT NOT NULL,body TEXT NOT NULL) STRICT');db.commit()
    games=[json.loads(x[0]) for x in db.execute("SELECT body FROM _history_games WHERE json_extract(body,'$.league')='NBA'")];games=[g for g in games if g.get('official_score_request_id') and args.from_date<=g['date']<=args.through_date];games=sorted(games,key=lambda g:(g['date'],g['game_id']))
    if args.limit:games=games[:args.limit]
    cached={x[0]:x[1] for x in db.execute('SELECT game_id,request_id FROM _official_nba_clocks')};rs={r['request_id']:r for r in records()};issues=[];ok=0
    maps={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_map')}
    canonical={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_games')}
    for n,g in enumerate(games,1):
        rid=g['official_score_request_id']
        try:
            if cached.get(g['game_id'])==rid:ok+=1;continue
            source_gid=g['game_id'];reference=canonical.get(maps.get(source_gid,{}).get('game_id'))
            if reference:g=dict(g,date=reference['date'],start=reference['start'],city=reference.get('city') or g.get('city'))
            r=rs[rid];x=parse((ROOT/r['raw_file']).read_bytes(),g);x['request_id']=rid;x['source_url']=r['endpoint'];db.execute('INSERT OR REPLACE INTO _official_nba_clocks VALUES (?,?,?)',(source_gid,rid,json.dumps(x)));db.commit();ok+=1
        except Exception as e:issues.append(dict(game_id=g['game_id'],request_id=rid,error=str(e)))
        if n%25==0 or n==len(games):print('NBA BREAK CLOCKS',n,len(games),'verified',ok,'issues',len(issues),flush=True)
    db.close();(ROOT/'reports/official_nba_break_times.json').write_text(json.dumps(dict(games_attempted=len(games),verified=ok,issues=issues),indent=2),encoding='utf-8')

if __name__=='__main__':main()
