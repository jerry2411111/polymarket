"""Date-batched biographies from official public pages after the API returned 403."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from urllib.parse import quote
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100;proof=json.loads((ROOT/'reports/bundesliga_person_api_pilot.json').read_text());assert any(x['status']=='API_UNAVAILABLE_USE_OFFICIAL_PUBLIC_PAGE' for x in proof);db=sqlite3.connect(DB,timeout=60);c=HistoryClient();HOSTS.add('www.bundesliga.com');people={}
 for mid,b in db.execute('SELECT * FROM _official_bundesliga_game_reports ORDER BY json_extract(body,\'$.date\')'):
  r=json.loads(b)
  for side in ['away','home']:
   for kind,v in r['sources']['lineups']['data'][side].items():
    for p in v['persons']:
     pid=p['dflDatalibraryObjectId'];people.setdefault(pid,dict(person_id=pid,kind='manager' if kind=='coaches' else 'player',name=p['name'],slug=p['slugifiedShortName'],first_date=r['date'],lineup_request_id=r['sources']['lineups']['request_id']))
 with db:db.execute('CREATE TABLE IF NOT EXISTS _official_bundesliga_people_sources (person_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
 done={pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _official_bundesliga_people_sources')};by_month=collections.defaultdict(list)
 for p in list(people.values())[:3 if a.pilot else None]:by_month[p['first_date'][:7]].append(p)
 def fetch(p):
  pid=p['person_id']
  if pid in done:return pid,done[pid]
  row=dict(**p,api_fallback='Official biography endpoint returned HTTP 403; public page embeds the biography without authentication')
  try:
   url='https://www.bundesliga.com/en/player/'+quote(p['slug'],safe='-');b,r,redirects=get(c,url);row.update(url=url,request_id=r['request_id'],redirects=redirects);soup=BeautifulSoup(b,'html.parser');matches=[]
   for script in soup.find_all('script',type='application/json'):
    for k,v in json.loads(script.get_text()).items():
     if isinstance(v,dict) and isinstance(v.get('b'),dict) and v['b'].get('id')==pid and 'names' in v['b']:matches.append((k,v))
   assert len(matches)==1,'No unique source-native person biography on official page';key,v=matches[0];row.update(status='ok',data=v['b'],json_pointer='/'+key+'/b',source_api_url=v.get('u'))
  except Exception as e:row.update(status='unavailable',error=type(e).__name__+': '+str(e))
  return pid,row
 day=dt.date(2024,1,1);parts=[];milestone=10
 while day<=dt.date(2026,9,14) and (a.pilot or len(parts)<math.ceil(33*a.through_percent/100)):
  month=day.strftime('%Y-%m');counts=collections.Counter()
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
   for pid,row in pool.map(fetch,by_month[month]):
    if pid not in done:
     with db:db.execute('INSERT OR REPLACE INTO _official_bundesliga_people_sources VALUES (?,?)',(pid,json.dumps(row)))
    counts[row['status']]+=1
  parts.append(dict(month=month,people=len(by_month[month]),counts=dict(counts)));out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Bundesliga official player and coach biographies by first collected game date',pilot=a.pilot,processed_months=len(parts),total_months=33,total_requested_people=3 if a.pilot else len(people),new_requests=c.requests,months=parts);(ROOT/'reports'/('bundesliga_people_pilot.json' if a.pilot else 'bundesliga_people_months.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
  if counts:print('BUNDESLIGA PEOPLE',month,dict(counts),'months',len(parts),'/33',flush=True)
  while not a.pilot and milestone<=100 and len(parts)>=math.ceil(33*milestone/100):print('BUNDESLIGA PEOPLE DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print('BUNDESLIGA BIOGRAPHY NEW REQUESTS',c.requests,flush=True);db.close()

if __name__=='__main__':main()
