"""Save source shape examples internally and print selected fields only."""
import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB);out={}
for code,table in [('LAL','laliga'),('BUN','bundesliga'),('FL1','ligue1'),('SEA','seriea'),('UCL','uefa')]:
 r=json.loads(db.execute('SELECT body FROM _official_'+table+'_game_reports ORDER BY match_id LIMIT 1').fetchone()[0]);s=r['sources'];x={}
 if code=='LAL':
  d=s['match_page']['data'];x=dict(keys=list(d['data']),player=d['data']['lineups']['home']['starts'][0],coach=d['data']['lineups']['home']['manager'][0],events=d.get('events'),stats=d['data'].get('stats'));x['comments']=d['data'].get('comments',[])[:4]
 elif code=='BUN':
  d=s['match']['data'];x=dict(keys=list(d),player=s['lineups']['data']['home']['startingEleven']['persons'][0],coach=s['lineups']['data']['home']['coaches']['persons'][0]);seen=set();ev=[]
  for v in d.get('liveBlogEntries',{}).values():
   if v['entryType'] not in seen:seen.add(v['entryType']);ev.append(v)
  x['events']=ev
 elif code=='FL1':
  d=s['match']['data'];x=dict(keys=list(d),player=next(iter(d['home']['players'].values())),coach=d['home']['manager'],goals=d['home']['goals'],timeline=d.get('timeline',[])[:2] if isinstance(d.get('timeline'),list) else None)
 elif code=='SEA':
  d=s['lineups']['data'];x=dict(keys=list(d),side_keys=list(d['home']),players=d['home']['fielded'][:1],coach=d['home']['staff'][:1],feed_keys=list(s['feed']['data']))
 else:
  d=s['lineups']['data'];x=dict(keys=list(d));x['lineup']=d; x['event_types']=dict(collections.Counter(e.get('type') for e in r['sources']['events']['data']))
 out[code]=dict(match_id=r.get('match_id'),sample=x)
(ROOT/'reports/eu_player_source_samples.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
for code,v in out.items():
 x=v['sample'];print(code,'KEYS',x.get('keys'));print('SELECTED',json.dumps({k:val for k,val in x.items() if k not in ['events','stats','lineup','timeline','keys']},ensure_ascii=False)[:5500])
 if code=='UCL':
  for k,val in x['lineup'].items():print('UCL',k,str(val)[:3500])
db.close()
