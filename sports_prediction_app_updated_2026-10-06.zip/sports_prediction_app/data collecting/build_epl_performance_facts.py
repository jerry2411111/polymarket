"""Dated player/team/head-coach facts from official reports of games with published odds."""
import argparse,collections,datetime as dt,json,re,sqlite3
from zoneinfo import ZoneInfo
from build_history_catalog import DB
from probe_history import ROOT
from epl_price_points import Sources
from core import utc

def derive_players(g,report):
    m=report['sources']['match']['data'];d=report['derived'];events=report['sources']['events']['data'];lineups=report['sources']['lineups']['data'];rows=[];issues=[];goals=collections.Counter();assists=collections.Counter();assist_complete=True
    cancelled=[]
    for side in ['away','home']:
        ev=events[side+'Team'];assert ev['id']==m[side+'Team']['id'];valid=[]
        for n,v in enumerate(ev['goals']):
            proof=[c for c in report['commentary_complete']['rows'] if c['raw'].get('type')=='VAR cancelled goal' and c['raw'].get('player1')==v['playerId'] and sum(map(int,re.findall(r'\d+',c['raw']['time'])))==int(v['time'])]
            if proof:
                assert len(proof)==1
                if v.get('timestamp'):assert dt.datetime.strptime(v['timestamp'],'%Y%m%dT%H%M%S%z').astimezone(dt.UTC)==dt.datetime.fromisoformat(proof[0]['raw']['timestamp']).replace(tzinfo=ZoneInfo(m['kickoffTimezoneString'])).astimezone(dt.UTC)
                cancelled.append(dict(side=side,events_pointer='/'+side+'Team/goals/'+str(n),raw=v,cancellation_source=proof[0]));continue
            assert v.get('timestamp') and v.get('period') in ['FirstHalf','SecondHalf'],(g['game_id'],'Unverified goal entry without a valid period/timestamp',v)
            valid.append(v)
        assert len(valid)==m[side+'Team']['score'],(g['game_id'],'Official valid goal-list count differs from final score')
        for v in valid:
            assert v['goalType'] in ['Goal','Penalty','Own'],'Unreviewed goal type'
            if v['goalType']!='Own':goals[v['playerId']]+=1
            if 'assistPlayerId' not in v:assist_complete=False
            elif v['assistPlayerId']:assists[v['assistPlayerId']]+=1
    clock=lambda x:dt.datetime.strptime(x,'%Y%m%dT%H%M%S%z').astimezone(dt.UTC).timestamp()
    start=utc(d['actual_start_utc']).timestamp() if d['actual_start_utc'] else None;hs=utc(d['halftime_start_utc']).timestamp() if d['halftime_start_utc'] else None;resume=utc(d['second_half_start_utc']).timestamp() if d['second_half_start_utc'] else None;finish=utc(d['regulation_end_utc']).timestamp() if d['regulation_end_utc'] else None
    for side_index,side in enumerate(['away','home']):
        t=lineups[side+'_team'];players={p['id']:p for p in t['players']};starters={p for group in t['formation']['lineup'] for p in group};ev=events[side+'Team'];played=starters|{v['playerOnId'] for v in ev['subs'] if v['playerOnId'] is not None};assert played<=set(players),(g['game_id'],'Unknown substitution entrant');minutes={};minute_problem=None;timeline=[]
        if all(v is not None for v in [start,hs,resume,finish]):
            assert start<hs<resume<finish
            elapsed=lambda lo,hi:((hi-lo)-max(0,min(hi,resume)-max(lo,hs)))/60
            active={p:start for p in starters};seconds=collections.defaultdict(float)
            for v in ev['subs']:
                if v['playerOnId'] is None:
                    proof=[c for c in report['commentary_complete']['rows'] if c['raw'].get('type')=='player retired' and c['raw'].get('player1')==v['playerOffId'] and 'went off injured' in c['raw']['comment']];assert len(proof)==1,(g['game_id'],'Null substitute needs explicit retirement evidence')
                timeline.append((clock(v['timestamp']),'sub',v))
            for v in ev['cards']:
                if v['type'] in ['StraightRed','SecondYellow']:timeline.append((clock(v['timestamp']),'red',v))
            try:
                for when,kind,v in sorted(timeline,key=lambda x:(x[0],x[1])):
                    if kind=='red' and when>finish:continue # Post-whistle discipline cannot reduce completed playing time.
                    if kind=='red' and v['playerId'] not in active:continue # A bench or post-game card changes no playing interval.
                    assert start<=when<=finish,'Substitution/card lies outside regulation clock'
                    if kind=='sub':
                        off,on=v['playerOffId'],v['playerOnId'];assert off in active and on not in active,'Substitution contradicts official starting/on-pitch state';seconds[off]+=elapsed(active.pop(off),when)
                        if on is not None:active[on]=when
                    else:
                        off=v['playerId'];seconds[off]+=elapsed(active.pop(off),when)
                for p,lo in active.items():seconds[p]+=elapsed(lo,finish)
                assert set(seconds)==played and all(0<=v<=elapsed(start,finish)+1e-8 for v in seconds.values());minutes=dict(seconds)
            except AssertionError as e:minute_problem=str(e);issues.append(dict(game_id=g['game_id'],side=side,field='minutes',reason=minute_problem))
        else:minute_problem='An official start, half-time boundary or final clock is missing/ambiguous'
        for pid,p in players.items():
            name=p.get('knownName') or ' '.join(filter(None,[p.get('firstName'),p.get('lastName')]));assert name
            rows.append(dict(player_id='EU_PL:'+pid,official_player_id=pid,player_name=name,game_id=g['game_id'],official_match_id=g['official_match_id'],game_type='Soccer',league='EU soccer',competition='Premier League',team_name=g['teams'][side_index],official_team_id=g['team_ids'][side_index],side=side_index,did_play=pid in played,starter=pid in starters,score=goals[pid] if pid in played else None,assists=assists[pid] if pid in played and assist_complete else None,minutes=minutes.get(pid) if pid in played and not minute_problem else None,minutes_reason=minute_problem if pid in played else 'Did not enter the field',minutes_basis='Elapsed time between official substitution/card/whistle timestamps, excluding half-time and including added time; not the rounded 90-minute statistical convention',win=int(g['winner']==g['teams'][side_index]),roster_request_id=report['sources']['lineups']['request_id'],events_request_id=report['sources']['events']['request_id'],clock_sources=d['checkpoint_sources'],verified_cancelled_goals=cancelled,raw_player=p))
    assert set(goals)|set(assists)<=set(r['official_player_id'] for r in rows if r['did_play']),'Credited scorer/assister did not appear in official participants'
    return rows,issues

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inspect-only',action='store_true');a=ap.parse_args();db=sqlite3.connect(DB,timeout=60);src=Sources(db);games={gid:json.loads(b) for gid,b in db.execute("SELECT * FROM _eu_game_facts WHERE json_extract(body,'$.competition')='Premier League'")};rosters=[];teams=[];coaches=[];issues=[]
    for gid,g in sorted(games.items()):
        f=json.loads(db.execute('SELECT body FROM _official_epl_game_reports WHERE match_id=?',(g['official_match_id'],)).fetchone()[0])
        for key in ['match','lineups','events']:raw,r=src.get(f['sources'][key]['request_id']);assert raw==f['sources'][key]['data']
        day=utc(g['completion_utc']).astimezone(ZoneInfo('Europe/London')).date().isoformat() if g['completion_utc'] else (dt.date.fromisoformat(g['date'])+dt.timedelta(days=1)).isoformat();assert day>=g['date'];rs,errs=derive_players(g,f);issues.extend(errs)
        for p in rs:p.update(game_date=day,original_game_date=g['date'],temporary_team=False,affiliation_observation_safe=day==g['date']);rosters.append(p)
        for side in range(2):
            teams.append((gid,g['teams'][side],'Soccer','EU soccer',day,['Away','Home'][side],g['scores'][side],g['scores'][1-side],int(g['winner']==g['teams'][side])))
            source=f['sources']['lineups']['data'][['away_team','home_team'][side]]['managers'];ms=[m for m in source if m.get('type')=='Manager'];assert len(ms)==1,'Head-coach identity is ambiguous';m=ms[0];name=m.get('knownName') or m['firstName']+' '+m['lastName'];coaches.append(dict(manager_id='EU_PL_COACH:'+m['id'],manager_name=name,game_type='Soccer',league='EU soccer',competition='Premier League',team_name=g['teams'][side],game_id=gid,game_date=day,home_away=['Away','Home'][side],score_for=g['scores'][side],score_against=g['scores'][1-side],win=int(g['winner']==g['teams'][side]),request_id=f['sources']['lineups']['request_id'],raw=m))
    played=[p for p in rosters if p['did_play']];assert len(rosters)==len({(p['player_id'],p['game_id']) for p in rosters})
    if not a.inspect_only:
        with db:
            db.execute('CREATE TABLE IF NOT EXISTS _epl_player_game_facts (player_id TEXT,game_id TEXT,body TEXT NOT NULL,PRIMARY KEY(player_id,game_id)) STRICT');db.execute('DELETE FROM _epl_player_game_facts');db.executemany('INSERT INTO _epl_player_game_facts VALUES (?,?,?)',[(p['player_id'],p['game_id'],json.dumps(p)) for p in rosters]);db.execute('CREATE TABLE IF NOT EXISTS _epl_manager_game_facts (manager_id TEXT,game_id TEXT,body TEXT NOT NULL,PRIMARY KEY(manager_id,game_id)) STRICT');db.execute('DELETE FROM _epl_manager_game_facts');db.executemany('INSERT INTO _epl_manager_game_facts VALUES (?,?,?)',[(p['manager_id'],p['game_id'],json.dumps(p)) for p in coaches])
            db.execute("DELETE FROM _player_game_results WHERE player_id LIKE 'EU_PL:%'");db.executemany('INSERT INTO _player_game_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',[(p['player_id'],p['player_name'],'Soccer','EU soccer',p['team_name'],p['game_id'],p['game_date'],p['score'],p['assists'],p['minutes'],int(p['starter']),p['win']) for p in played])
            db.execute("DELETE FROM _team_game_results WHERE game_id LIKE 'EPL_%'");db.executemany('INSERT INTO _team_game_results VALUES (?,?,?,?,?,?,?,?,?)',teams);db.execute("DELETE FROM _manager_game_results WHERE game_id LIKE 'EPL_%'");db.executemany('INSERT INTO _manager_game_results VALUES (?,?,?,?,?,?,?,?,?,?,?)',[tuple(p[k] for k in ['manager_id','manager_name','game_type','league','team_name','game_id','game_date','home_away','score_for','score_against','win']) for p in coaches])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING' if issues else 'WORKING',scope='EPL source game facts only; dated public profiles require separate installation',games=len(games),roster_rows=len(rosters),played_rows=len(played),players=len({p['player_id'] for p in rosters}),coach_game_rows=len(coaches),coaches=len({p['manager_id'] for p in coaches}),source_hash_checks=len(src.cache),issues=issues,missing={k:dict(count=sum(p[k]is None for p in played),denominator=len(played),percentage=round(sum(p[k]is None for p in played)*100/len(played),4) if played else None) for k in ['score','assists','minutes','starter']},minutes_definition='Actual elapsed on-pitch minutes including added time, excluding half-time, reconstructed from explicit official clocks; not rounded 90-minute statistical minutes',performance_scope='Only games currently published with usable odds; future games and uncollected career totals excluded',inspection_only=a.inspect_only);(ROOT/'reports/epl_performance_facts.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
