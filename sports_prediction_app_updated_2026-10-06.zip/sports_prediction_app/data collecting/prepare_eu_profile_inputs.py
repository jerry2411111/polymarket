"""Join verified personal constants and dated memberships through canonical IDs."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from eu_official_games import club_key
from probe_history import ROOT

def main():
 db=sqlite3.connect(DB,timeout=60);people={pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _eu_people_registry')};cross=dict(db.execute('SELECT source_person_id,person_id FROM _eu_person_crosswalk'));wanted={p for p, in db.execute('SELECT DISTINCT player_id FROM _eu_player_game_facts')}|{p for p, in db.execute('SELECT DISTINCT manager_id FROM _eu_manager_game_facts')};bios={};aliases=collections.defaultdict(set);members={};issues=[]
 pl_teams={}
 for code,tid,b in db.execute('SELECT * FROM _eu_team_identity'):
  t=json.loads(b);names={t['team_name'],t.get('name')}|set((t.get('uefa_proof') or {}).get('names',[]))
  if code=='PL':pl_teams[tid]=t['team_name']
  for name in names-{None}:aliases[club_key(name)].add(t['team_name'])
 for pid in wanted:
  p=people[pid];bios[pid]=dict(person_id=pid,person_name=p['person_name'],birth_date=p['birth_date'],height_cm=p['height_cm'],weight_kg=p['weight_kg'],completed_season_evidence=None,biography_sources=p['biography_sources'])
 for table in ['_epl_people_biographies','_eu_opta_biographies']:
  for b, in db.execute('SELECT body FROM '+table):
   p=json.loads(b);source_ids=p.get('source_person_ids') or [('EU_PL:' if p['kind']=='player' else 'EU_PL_COACH:')+p['official_person_id']];ids={cross[x] for x in source_ids if x in cross}&wanted
   for pid in ids:
    if p.get('completed_season_evidence') is not None:
     if bios[pid]['completed_season_evidence'] is None:bios[pid]['completed_season_evidence']={}
     bios[pid]['completed_season_evidence'].update(p['completed_season_evidence'])
    if p.get('kind')=='manager':bios[pid].update(raw_joined_club=p.get('raw_joined_club'),raw_current_team=p.get('raw_current_team'))
 for table in ['_epl_player_memberships','_eu_opta_memberships']:
  for b, in db.execute('SELECT body FROM '+table):
   m=json.loads(b);ids={cross[x] for x in m.get('source_person_ids',[m.get('player_id')]) if x in cross}&wanted
   for pid in ids:
    row=dict(m,player_id=pid,source_team_name=m['team_name']);names=aliases[club_key(m['team_name'])]
    if str(m['raw_fields'].get('opContestantId')) in pl_teams:row['team_name']=pl_teams[str(m['raw_fields']['opContestantId'])];row['team_name_basis']='Same native club ID in official Premier League calendar and global career service'
    elif len(names)==1:row['team_name']=next(iter(names));row['team_name_basis']='Unique exact normalized documented official club name'
    else:row['team_name_basis']='Official career name retained; no unique canonical club-name correspondence'
    key=(pid,m['native_membership_id'])
    if key in members:
     old=members[key];assert (old['start_date'],old['end_date'],old['team_name'])==(row['start_date'],row['end_date'],row['team_name']),(key,old,row)
    members[key]=row
 appointments=[]
 for b, in db.execute('SELECT body FROM _eu_manager_appointments'):
  a=json.loads(b)
  if a['source_person_id'] in cross and cross[a['source_person_id']] in wanted:appointments.append(dict(a,manager_id=cross[a['source_person_id']]))
 with db:
  for table,ddl in [('_eu_profile_biographies','person_id TEXT PRIMARY KEY,body TEXT NOT NULL'),('_eu_player_memberships','player_id TEXT,membership_id TEXT,body TEXT NOT NULL,PRIMARY KEY(player_id,membership_id)'),('_eu_profile_appointments','body TEXT NOT NULL')]:db.execute('CREATE TABLE IF NOT EXISTS '+table+' ('+ddl+') STRICT');db.execute('DELETE FROM '+table)
  db.executemany('INSERT INTO _eu_profile_biographies VALUES (?,?)',[(pid,json.dumps(b)) for pid,b in bios.items()]);db.executemany('INSERT INTO _eu_player_memberships VALUES (?,?,?)',[(pid,mid,json.dumps(b)) for (pid,mid),b in members.items()]);db.executemany('INSERT INTO _eu_profile_appointments VALUES (?)',[(json.dumps(a),) for a in appointments])
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',published_people=len(wanted),canonical_memberships=len(members),dated_coach_appointments=len(appointments),issues=issues,limits='Club histories are dated source evidence, not full-career completeness or contract salary. Career performance totals are excluded.');(ROOT/'reports/eu_profile_inputs.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
