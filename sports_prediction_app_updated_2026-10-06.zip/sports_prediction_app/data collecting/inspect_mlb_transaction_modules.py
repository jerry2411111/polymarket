import json,re,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',('189fd17314594c67969a68fbd71c40b8',)).fetchone()[0]);s=(ROOT/r['raw_file']).read_text(encoding='utf-8')
for word in ['siteJS','patternScript','const scripts','roster_transactions','statsapi','data-init','transactions_data']:
    for m in list(re.finditer(re.escape(word),s))[-4:]:print(word,s[max(0,m.start()-130):m.start()+650])
