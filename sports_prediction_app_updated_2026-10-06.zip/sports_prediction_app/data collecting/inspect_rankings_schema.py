import sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for name,sql in db.execute("SELECT name,sql FROM sqlite_master WHERE name LIKE '%rank%' AND type IN ('table','view')"):
    print(name,sql);print('FIRST ROW',db.execute('SELECT * FROM '+name+' LIMIT 1').fetchone())
db.close()
