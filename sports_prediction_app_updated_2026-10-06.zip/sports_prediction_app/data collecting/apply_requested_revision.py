"""Apply requested public schema reductions and synchronize dated profile statistics."""
import datetime as dt,json,sqlite3
from pathlib import Path
from build_history_catalog import DB
from probe_history import ROOT
from eu_schema import refresh_main_views

STATS=['overall_winrate','average_score_per_game','std_score_per_game','average_assists_per_game','std_assists_per_game','average_minutes_per_game','std_minutes_per_game','starter_percentage_overall']

def main():
 db=sqlite3.connect(DB,timeout=120);out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat())
 with db:
  refresh_main_views(db)
  out['removed_manager_profiles_without_team']=db.execute("SELECT count(*) FROM manager_profiles WHERE team IS NULL OR trim(team)=''").fetchone()[0]
  out['removed_manager_links_without_known_team']=db.execute("DELETE FROM game_manager_profiles WHERE EXISTS(SELECT 1 FROM manager_profiles p WHERE p.manager_id=game_manager_profiles.manager_id AND p.as_of_date=game_manager_profiles.as_of_date AND (p.team IS NULL OR trim(p.team)=''))").rowcount
  db.execute("DELETE FROM manager_profiles WHERE team IS NULL OR trim(team)=''")
  if 'months_serving_current_team' in [r[1] for r in db.execute('PRAGMA table_info(manager_profiles)')]:
   db.execute('ALTER TABLE manager_profiles DROP COLUMN months_serving_current_team')
 assert not db.execute("PRAGMA foreign_key_check('game_manager_profiles')").fetchall()
 print('PUBLIC SCHEMA UPDATED',json.dumps(out),flush=True)
 # Derive all updates from past-only intervals; leave biographies/affiliations intact.
 db.execute('PRAGMA temp_store=FILE')
 expressions=['m.'+c for c in STATS]+['CASE WHEN c.sigma>0 THEN (m.average_score_per_game-c.mu)/c.sigma END']
 cols=STATS+['score_z_score']
 changed=['(p.'+c+' IS NULL) != (v.'+c+' IS NULL) OR abs(p.'+c+'-v.'+c+')>1e-10' for c in cols]
 db.execute('CREATE TEMP TABLE revised_profile_stats AS SELECT p.rowid AS profile_rowid,'+','.join(e+' AS '+c for e,c in zip(expressions,cols))+''' FROM _player_performance_periods m
 JOIN player_profiles p ON p.player_id=m.player_id AND p.league=m.league AND p.as_of_date>=m.effective_from AND p.as_of_date<m.effective_to
 JOIN _player_score_cohorts c ON c.league=p.league AND c.as_of_date=p.as_of_date''')
 db.execute('CREATE UNIQUE INDEX revised_profile_row ON revised_profile_stats(profile_rowid)')
 db.execute('DELETE FROM revised_profile_stats AS v WHERE NOT EXISTS(SELECT 1 FROM player_profiles p WHERE p.rowid=v.profile_rowid AND ('+' OR '.join(changed)+'))')
 total=db.execute('SELECT count(*) FROM revised_profile_stats').fetchone()[0];done=0;mark=10;last=0
 while True:
  ids=[r[0] for r in db.execute('SELECT profile_rowid FROM revised_profile_stats WHERE profile_rowid>? ORDER BY profile_rowid LIMIT 25000',(last,))]
  if not ids:break
  with db:
   db.execute('UPDATE player_profiles AS p SET '+','.join(c+'=v.'+c for c in cols)+' FROM revised_profile_stats v WHERE p.rowid=v.profile_rowid AND v.profile_rowid>? AND v.profile_rowid<=?',(last,ids[-1]))
  done+=len(ids);last=ids[-1]
  while total and done*100//total>=mark:
   print('PROFILE STATISTIC UPDATE',mark,'percent;',done,'of',total,flush=True);mark+=10
 out['profile_statistics_corrected']=done
 out['manager_profiles_retained']=db.execute('SELECT count(*) FROM manager_profiles').fetchone()[0]
 out['manager_team_missing']=db.execute("SELECT count(*) FROM manager_profiles WHERE team IS NULL OR trim(team)=''").fetchone()[0]
 out['main_columns']=[r[1] for r in db.execute('PRAGMA table_info(main)')]
 out['in_game_columns']=[r[1] for r in db.execute('PRAGMA table_info(in_game)')]
 (ROOT/'reports/requested_revision.json').write_text(json.dumps(out,indent=2),encoding='utf-8');db.close();print(json.dumps(out),flush=True)
if __name__=='__main__':main()
