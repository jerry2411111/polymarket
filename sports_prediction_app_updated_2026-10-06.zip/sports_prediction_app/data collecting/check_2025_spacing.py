"""Stratified 2025 audit of actual hourly history coverage, raw source retained.

Three games (first, middle and last in date order) per month/league/provider,
both team outcomes. These are samples, not a claim to audit every 2025 market.
"""
import bisect,collections,concurrent.futures,datetime as dt,json,sqlite3,statistics,time
from history_client import HistoryClient
from history_index import records,payload
from build_history_catalog import DB
from core import utc
from probe_history import ROOT
from schema import HOURS
from quote_selection import nearest_pregame
K='https://external-api.kalshi.com/trade-api/v2'

def main():
 db=sqlite3.connect(DB);games={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _history_games')};contracts=[json.loads(r[0]) for r in db.execute('SELECT body FROM _history_contracts')];db.close()
 groups=collections.defaultdict(set);mc=collections.defaultdict(list)
 for m in contracts:
  g=games[m['game_id']]
  if g['date'][:4]!='2025':continue
  groups[g['date'][:7],g['league'],m['provider']].add(g['game_id']);mc[g['game_id'],m['provider']].append(m)
 selected=[];sample_groups=[]
 for key,gids in sorted(groups.items()):
  gids=sorted(gids,key=lambda gid:(games[gid]['date'],games[gid]['start'],gid));chosen=[gids[i] for i in sorted(set([0,len(gids)//2,len(gids)-1]))]
  sample_groups.append(dict(month=key[0],league=key[1],provider=key[2],available_matched_games=len(gids),sampled_game_ids=chosen))
  for gid in chosen:selected.extend(mc[gid,key[2]])
 c=HistoryClient();cutoff,r=c.get(K+'/historical/cutoff');cut=utc(cutoff['market_settled_ts']);started=time.monotonic()
 def task(m):
  g=games[m['game_id']];anchor=utc(g['start']);end=int(anchor.timestamp());start=end-84*3600;ids=[]
  out=dict(game_id=g['game_id'],match='/'.join(g['teams']),date=g['date'],month=g['date'][:7],league=g['league'],provider=m['provider'],side=m['side'],outcome=m['outcome'],contract_id=m['contract_id'],anchor=anchor.isoformat(),market_open=m['open'],request_ids=ids)
  try:
   if m['provider']=='kalshi':
    path='/historical/markets/'+m['contract_id']+'/candlesticks' if utc(m['settled'])<cut else '/series/'+m['series']+'/markets/'+m['contract_id']+'/candlesticks'
    d,r=c.get(K+path,dict(start_ts=start,end_ts=end,period_interval=60));ids.append(r['request_id'])
    if d.get('ticker')!=m['contract_id']:raise ValueError('Returned market differs')
    suffix='close' if '/historical/' in path else 'close_dollars';points=[]
    for i,x in enumerate(d['candlesticks']):
     p=x['yes_bid'].get(suffix);ask=x['yes_ask'].get(suffix)
     if p is not None and ask is not None and float(p)>float(ask):raise ValueError('Crossed source bid/ask')
     if p is not None:points.append(dict(timestamp=x['end_period_ts'],price=float(p),resolution_seconds=3600,request_id=r['request_id'],pointer=f'/candlesticks/{i}/yes_bid/{suffix}'))
    out['hourly_request_returned_rows']=len(d['candlesticks'])
   else:
    params=dict(token_id=m['contract_id'],start=start,end=end,bucket_seconds=3600,limit=10000)
    d,r=c.get('https://data-api.polymarket.com/v2/prices-history',params);ids.append(r['request_id']);out['hourly_request_returned_rows']=len(d.get('data',[]))
    if not d.get('data'):
     params.pop('bucket_seconds');d,r=c.get('https://data-api.polymarket.com/v2/prices-history',params);ids.append(r['request_id'])
    points=[];seen=set()
    while True:
     for i,x in enumerate(d.get('data',[])):points.append(dict(**x,request_id=r['request_id'],pointer=f'/data/{i}/price'))
     cursor=(d.get('pagination') or {}).get('next_cursor')
     if not cursor:break
     if cursor in seen:raise ValueError('Repeated cursor')
     seen.add(cursor);params['cursor']=cursor;d,r=c.get('https://data-api.polymarket.com/v2/prices-history',params);ids.append(r['request_id'])
   points=[x for x in points if start<=x['timestamp']<end]
   bytime={}
   for x in points:
    if not 0<=float(x['price'])<=1:raise ValueError('Probability outside [0,1]')
    if x['timestamp'] in bytime and bytime[x['timestamp']]['price']!=x['price']:raise ValueError('Conflicting duplicate value')
    bytime[x['timestamp']]=x
   ts=sorted(bytime);gaps=[(b-a)/3600 for a,b in zip(ts,ts[1:])];lookbacks=[]
   for hour in HOURS:
    target=end-hour*3600-(1 if hour==0 else 0);x=nearest_pregame(list(bytime.values()),target,end);age=(target-x['timestamp'])/3600 if x else None
    opened=utc(m['open']);not_open=opened is not None and target<int(opened.timestamp())
    lookbacks.append(dict(hour=hour,target_utc=utc(target).isoformat(),source_timestamp_utc=utc(x['timestamp']).isoformat() if x else None,source_offset_hours=-age if age is not None else None,absolute_offset_hours=abs(age) if age is not None else None,source_price=x['price'] if x else None,within_one_hour=(age is not None and abs(age)<=1),not_yet_open=not_open,request_id=x['request_id'] if x else None,pointer=x['pointer'] if x else None))
   out.update(status='ok',pre_match_observations=len(ts),first_observation=utc(ts[0]).isoformat() if ts else None,last_observation=utc(ts[-1]).isoformat() if ts else None,reported_resolution_seconds=sorted(set(x.get('resolution_seconds') for x in points)),gap_hours_min=min(gaps) if gaps else None,gap_hours_median=statistics.median(gaps) if gaps else None,gap_hours_max=max(gaps) if gaps else None,gap_counts=dict(collections.Counter(gaps)),lookbacks=lookbacks)
  except Exception as e:out.update(status='error',error=str(e))
  return out
 out=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
  for n,x in enumerate(pool.map(task,selected),1):
   out.append(x)
   if n%50==0 or n==len(selected):print('2025 SPACING',n,len(selected),'new requests',c.requests,flush=True)
 monthly=[]
 for key in sorted(groups):
  rows=[x for x in out if (x['month'],x['league'],x['provider'])==key];good=[x for x in rows if x['status']=='ok'];gaps=collections.Counter()
  for x in good:gaps.update(x['gap_counts'])
  weights=[(float(k),v) for k,v in gaps.items()];pairs=sum(gaps.values());targets=[v for x in good for v in x['lookbacks']];eligible=targets
  monthly.append(dict(month=key[0],league=key[1],provider=key[2],sampled_games=len({x['game_id'] for x in rows}),sampled_outcomes=len(rows),errors=len(rows)-len(good),empty_histories=sum(x['pre_match_observations']==0 for x in good),observations=sum(x['pre_match_observations'] for x in good),typical_gap_hours=max(weights,key=lambda x:x[1])[0] if weights else None,max_gap_hours=max((x[0] for x in weights),default=None),adjacent_pairs=pairs,pairs_over_one_hour=sum(v for k,v in weights if k>1),pairs_over_one_hour_pct=100*sum(v for k,v in weights if k>1)/pairs if pairs else None,eligible_lookbacks=len(eligible),lookbacks_within_one_hour=sum(x['within_one_hour'] for x in eligible),lookbacks_missing_or_over_one_hour_pct=100*sum(not x['within_one_hour'] for x in eligible)/len(eligible) if eligible else None,lookbacks_before_market_open=len(targets)-len(eligible)))
 result=dict(scope='Stratified sample: first, middle and last matched game per available 2025 month/league/provider; both outcome contracts. Not every 2025 game.',lookback_hours=HOURS,selection_policy='Closest retained observation strictly before game start, before or after target; ties earlier. No age cutoff. Offset >1h is descriptive, not grounds for rejection.',sample_groups=sample_groups,monthly=monthly,outcomes=out,new_requests=c.requests,cutoff=cutoff,retrieval_completed_at_utc=dt.datetime.now(dt.UTC).isoformat())
 (ROOT/'reports/2025_quote_spacing.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 lines=['# 2025 quote-spacing checks','',result['scope'],'','Actual consecutive non-null price timestamps strictly before game start. Kalshi = YES bid candle close, Polymarket = historical token price. A requested bucket does not prove actual observations exist at that frequency.','', '| Month | League | Provider | Games | Typical gap (hours) | Largest gap (hours) | Empty outcome histories | Eligible lookbacks missing or >1h old |','|---|---|---|---:|---:|---:|---:|---:|']
 for x in monthly:lines.append('| '+' | '.join(str(x[k]) if x[k] is not None else 'N/A' for k in ['month','league','provider','sampled_games','typical_gap_hours','max_gap_hours','empty_histories','lookbacks_missing_or_over_one_hour_pct'])+' |')
 lines+=['',result['selection_policy'],'Lookback hours: '+', '.join(map(str,HOURS))+'. Targets before market listing may use a later pre-game quote, with that offset explicitly recorded. Empty histories are not assigned zero probability. Exact endpoints, parameters, raw values and response hashes are linked by request ID in SQL _request_audit. The public log has only four columns.','', 'Full normalized data completeness and in-game checkpoint odds require separate validation.']
 (ROOT/'reports/2025_quote_spacing.md').write_text('\n'.join(lines),encoding='utf-8')
 print(json.dumps(dict(monthly=monthly,new_requests=c.requests,elapsed_seconds=round(time.monotonic()-started))),flush=True)
if __name__=='__main__':main()
