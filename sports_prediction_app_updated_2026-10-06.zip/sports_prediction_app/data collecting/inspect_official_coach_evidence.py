import io,json,sqlite3
from pypdf import PdfReader
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
for (body,) in db.execute("SELECT body FROM _history_appearances WHERE json_extract(body,'$.league')='NBA' LIMIT 1"):
    p=json.loads(body);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(p['request_id'],)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes()
    pdf=PdfReader(io.BytesIO(b));print('PDF',r['endpoint'],'PAGES',len(pdf.pages));print(pdf.pages[0].extract_text())
    for i,page in enumerate(pdf.pages):
        s=page.extract_text()
        for line in s.splitlines():
            if 'coach' in line.lower():print('COACH LINE',i,line)
for (body,) in db.execute("SELECT body FROM _official_player_biographies WHERE json_extract(body,'$.official_player_id')='1629029' LIMIT 1"):print('BIO',body)
