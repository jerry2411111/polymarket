import datetime as dt,json,sqlite3
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT
c=HistoryClient();rows=[];seen=set();requests=[]
for offset in range(0,1000,100):
 d,r=c.get('https://gamma-api.polymarket.com/teams',dict(league='nhl',limit=100,offset=offset,order='id',ascending=True));assert isinstance(d,list);requests.append(r['request_id'])
 for i,t in enumerate(d):
  assert str(t['league']).lower()=='nhl' and t['id'] not in seen;seen.add(t['id']);rows.append(dict(team=t,request_id=r['request_id'],pointer='/'+str(i)))
 if len(d)<100:break
else:raise ValueError('Unexhausted team pagination')
db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _polymarket_nhl_teams (provider_team_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
with db:db.executemany('INSERT OR REPLACE INTO _polymarket_nhl_teams VALUES (?,?)',[(str(r['team']['id']),json.dumps(r)) for r in rows])
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',teams=len(rows),requests=requests,new_requests=c.requests,aliases=[{k:r['team'].get(k) for k in ['id','name','abbreviation','alias']} for r in rows]);(ROOT/'reports/polymarket_nhl_team_directory.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
