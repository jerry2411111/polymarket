"""Date-batched official details and lineups for Bundesliga, La Liga and Ligue 1.

La Liga's public API requires an unavailable subscription key (retained 401).
Its official server-rendered match page provides the same match data openly;
only that official fallback is used, with the original HTML saved unchanged.
"""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS
from eu_official_games import CONFIG
from probe_bundesliga_archives import BASE as B
from core import utc

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100;db=sqlite3.connect(DB,timeout=60);c=HistoryClient();HOSTS.update({'ma-api.ligue1.fr','www.laliga.com','bundesliga-web-prod.europe-west1.firebasedatabase.app'});games={};by_month=collections.defaultdict(list);done={}
 for code in ['BUN','LAL','FL1']:
  table=CONFIG[code][1];allgames={mid:json.loads(b) for mid,b in db.execute('SELECT * FROM _official_'+table+'_calendar')};ids={json.loads(b)['official_match_id'] for b, in db.execute('SELECT body FROM _eu_validated_contracts WHERE competition=?',(code,))};ids|={g['official_match_id'] for g in sorted(allgames.values(),key=lambda g:g['date'])[:3]}
  db.execute('CREATE TABLE IF NOT EXISTS _official_'+table+'_game_reports (match_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
  for mid,b in db.execute('SELECT * FROM _official_'+table+'_game_reports'):
   v=json.loads(b)
   if v['status']=='ok':done[code,mid]=v
  for mid in ids:g=allgames[mid];games[code,mid]=g;by_month[g['date'][:7]].append((code,mid))
 db.commit()
 def fetch(job):
  code,mid=job
  if job in done:return job,done[job]
  g=games[job];sources={};row=dict(competition=code,match_id=mid,date=g['date'],sources=sources)
  try:
   if code=='FL1':
    d,r=c.get('https://ma-api.ligue1.fr/championship-match/'+mid);assert d['id']==mid and d['period']=='fullTime';assert d['home']['clubId']==g['raw']['home']['clubId'] and d['away']['clubId']==g['raw']['away']['clubId'];assert [d[s]['score'] for s in ['away','home']]==g['scores'];assert utc(d['date'])==utc(g['scheduled_start_utc']);sources['match']=dict(request_id=r['request_id'],data=d)
   elif code=='BUN':
    m=g['raw'];node='/DFL-COM-000001/seasons/'+g['native_season_id']+'/matchdays/'+m['dflDatalibraryMatchdayId'];params=dict(orderBy='"slugs/slugLong"',equalTo=json.dumps(m['slugs']['slugLong']),limitToFirst=2);data,r=c.get(B+'/en'+node+'.json',params);assert isinstance(data,dict) and set(data)=={mid};d=data[mid];assert d['matchId']==mid and d['matchStatus']=='FINAL_WHISTLE';assert utc(d['kickOff'])==utc(g['actual_start_utc']);assert [d['teams'][s]['dflDatalibraryClubId'] for s in ['away','home']]==[g[s]['dflDatalibraryClubId'] for s in ['away','home']];sources['match']=dict(request_id=r['request_id'],pointer='/'+mid,data=d)
    data,r=c.get(B+'/all'+node+'/'+mid+'/lineup.json');sources['lineups']=dict(request_id=r['request_id'],data=data)
   else:
    url='https://www.laliga.com/en-GB/match/'+g['raw']['slug'];b,r,redirects=get(c,url);soup=BeautifulSoup(b,'html.parser');script=soup.find('script',id='__NEXT_DATA__');assert script;d=json.loads(script.get_text())['props']['pageProps'];m=d['match'];assert str(m['id'])==mid and m['status']=='FullTime';assert [m[s+'_team']['id'] for s in ['away','home']]==[g[s]['id'] for s in ['away','home']];assert [m['away_score'],m['home_score']]==g['scores'];assert utc(m['date'])==utc(g['scheduled_start_utc']);sources['match_page']=dict(request_id=r['request_id'],json_pointer='/props/pageProps',data=d,redirects=redirects,api_fallback_reason='Official API 401 without a subscription key; public official SSR match payload is sufficient')
   row['status']='ok'
  except Exception as e:row.update(status='error',error=type(e).__name__+': '+str(e))
  return job,row
 day=dt.date(2024,1,1);parts=[];milestone=10
 while day<=dt.date(2026,9,14) and len(parts)<math.ceil(33*a.through_percent/100):
  month=day.strftime('%Y-%m');counts=collections.defaultdict(collections.Counter);errors=[]
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
   for (code,mid),row in pool.map(fetch,by_month[month]):
    if (code,mid) not in done:
     with db:db.execute('INSERT OR REPLACE INTO _official_'+CONFIG[code][1]+'_game_reports VALUES (?,?)',(mid,json.dumps(row)))
    counts[code][row['status']]+=1
    if row['status']=='error':errors.append(dict(competition=code,match_id=mid,error=row['error']))
  parts.append(dict(month=month,counts={k:dict(v) for k,v in counts.items()},errors=errors));report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Official Bundesliga, La Liga and Ligue 1 game reports',total_months=33,processed_months=len(parts),months=parts,new_requests=c.requests);(ROOT/'reports/eu_domestic_game_reports_months.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print('DOMESTIC EU REPORT MONTH',month,dict(counts),'months',len(parts),'/33',flush=True)
  while len(parts)>=math.ceil(33*milestone/100) and milestone<=100:print('DOMESTIC EU REPORT DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  if errors:print('ERRORS',json.dumps(errors),flush=True);break
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print('DOMESTIC EU REPORT NEW REQUESTS',c.requests,flush=True);db.close()

if __name__=='__main__':main()
