import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB);gs={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_mlb_schedule')};out=[]
for b, in db.execute("SELECT body FROM _mlb_market_matching_audit WHERE json_extract(body,'$.reason') LIKE 'Voided%'"):
    a=json.loads(b);g=gs[a['official_game_id']];out.append(dict(market_id=a['market_id'],official_game_id=a['official_game_id'],date=g['official_date'],teams=g['teams'],scores=g['scores'],winner_flags=g['winner_flags'],competition=g['competition_type']))
print(json.dumps(out,indent=2));db.close()
