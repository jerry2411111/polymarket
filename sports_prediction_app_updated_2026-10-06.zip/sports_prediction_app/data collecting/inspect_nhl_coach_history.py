"""Inspect original coach history shapes and the remaining player-log issue."""
import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for n in ['1870','1797']:
    row=db.execute('SELECT body FROM _official_nhl_coach_registry WHERE official_coach_id=?',(n,)).fetchone()
    if not row:continue
    r=json.loads(row[0]);d=r['raw'];print('COACH',n,r['full_name'],r['request_id'])
    print(json.dumps({k:d[k] for k in ['history','bio','description','briefDescription','teamId','isActive']},ensure_ascii=False)[:4500])
    print('SEASON SAMPLE',json.dumps([{k:v for k,v in r.items() if k in ['id','firstCoachedDate','lastCoachedDate','teamId','teamName','franchiseId','games','season']} for r in d['coachFranchiseSeasonRecords'][-2:]],ensure_ascii=False))
r=json.loads(db.execute('SELECT body FROM _official_nhl_career_sources WHERE official_player_id=?',('8479547',)).fetchone()[0]);print('PLAYER',r['player_name'],json.dumps([x for x in r['season_totals'] if x.get('leagueAbbrev')=='NHL' and x['season']==20232024 and x['gameTypeId']==2]))
for b, in db.execute("SELECT body FROM _nhl_coach_sources WHERE url LIKE '%nhl-coaches-2023-24-season%'"):
    s=json.loads(b);print('CURRENT COACH LIST STRUCTURE',json.dumps([x.get('articleBody') for x in s['metadata'].get('structured',[]) if x.get('@type')=='NewsArticle'])[:3500]);print('CURRENT COACH PARAGRAPHS',json.dumps(s['paragraphs'][:3],ensure_ascii=False))
db.close()
