"""Bounded station gap counts and unique city names; no raw archive dump."""
import collections,json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB);counts=collections.Counter();groups=collections.defaultdict(list)
for city,year,b in db.execute('SELECT * FROM _eu_weather_station_jobs'):
 r=json.loads(b);counts[r['status']]+=1
 if r['status']!='ok':groups['no_candidate' if r['candidate_count']==0 else 'archive_unavailable'].append(dict(city=city,year=year,candidates=r['candidate_count']))
print('STATION COVERAGE',dict(counts))
for kind,rows in groups.items():print(kind,len(rows),json.dumps(rows,ensure_ascii=False))
db.close()
