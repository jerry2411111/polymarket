"""Complete closed-event discovery in month partitions, respecting offset limits."""
import datetime as dt,json,os
from probe_history import Client,ROOT
from discover_history import LEAGUES,START,END

def months():
 lo=dt.date.fromisoformat(START)
 while lo<dt.date(2026,9,15):
  hi=(lo.replace(day=28)+dt.timedelta(days=4)).replace(day=1)
  hi=min(hi,dt.date(2026,9,15));yield lo,hi;lo=hi

def main():
 os.environ['PILOT_MAX_REQUESTS']='2000';c=Client(ROOT);summary=[]
 for league,(_,_,tag) in LEAGUES.items():
  total=set();partitions=[]
  for lo,hi in months():
   offset=0;seen=set();error=None
   try:
    while True:
     q={'tag_id':tag,'closed':'true','end_date_min':lo.isoformat()+'T00:00:00Z','end_date_max':hi.isoformat()+'T00:00:00Z','order':'id','ascending':'true','limit':100,'offset':offset}
     d,r=c.get('https://gamma-api.polymarket.com/events',q)
     if not d:break
     for x in d:
      if x['id'] in seen:raise ValueError('Repeated event within page traversal')
      if not x.get('endDate') or not lo.isoformat()<=x['endDate'][:10]<=hi.isoformat():raise ValueError('Date filter was not honored')
      seen.add(x['id']);total.add(x['id'])
     offset+=len(d)
     if offset>2000:raise RuntimeError('Partition exceeds documented offset support; subdivide')
   except Exception as e:error=str(e)
   part=dict(start=str(lo),end=str(hi),rows=len(seen),pagination_exhausted=error is None,error=error);partitions.append(part)
   print('MONTH',league,str(lo),len(seen),error or 'COMPLETE',flush=True)
  row=dict(provider='polymarket',league=league,rows=len(total),partitions=partitions,pagination_exhausted=all(p['pagination_exhausted'] for p in partitions))
  summary.append(row);(ROOT/'reports/polymarket_discovery.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 print('ALL POLYMARKET PARTITIONS FINISHED',flush=True)
if __name__=='__main__':main()
