"""Inspect official UK station identities before selecting any weather archive."""
import json,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from collect_history_weather import DOC
db=sqlite3.connect(DB);cities=sorted({json.loads(b)['location'].rsplit(', ',1)[-1] for b, in db.execute("SELECT body FROM _eu_game_facts WHERE json_extract(body,'$.competition')='Premier League'")});client=HistoryClient();raw,r=client.get(DOC+'ghcnh-station-list.txt',document=True);lines=raw.decode().splitlines();print('OFFICIAL DIRECTORY',r['request_id']);aliases={'Falmer':['SHOREHAM','BRIGHTON'],'Brentford':['HEATHROW'],'Burnley':['STONYHURST','BURNLEY'],'Wolverhampton':['HALFPENNY','WOLVERHAMPTON'],'Ipswich':['IPSWICH','WATTISHAM'],'Hull':['HUMBERSIDE','HULL'],'Sunderland':['SUNDERLAND','NEWCASTLE']}
for city in cities:
    words=aliases.get(city,[city]);xs=[line for line in lines if line.startswith('UK') and any(w.upper() in line.upper() for w in words)];print(json.dumps(dict(city=city,candidates=xs[:12]),ensure_ascii=False))
