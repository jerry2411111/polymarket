import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
for b, in db.execute('SELECT body FROM _nba_ranking_sources'):
    s=json.loads(b)
    if 'syndicated' not in s['publisher'] or s['status']!='ACQUIRED_NOT_VALIDATED':continue
    r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(s['request_id'],)).fetchone()[0]);html=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
    print('SOURCE',s['url']);print('META',s['metadata']['meta']);print('ARTICLE JSON',[(d.get('@type'),d.get('datePublished'),d.get('dateModified'),d.get('author')) for d in s['metadata']['structured'] if isinstance(d,dict)])
    hs=[h.get_text(' ',strip=True) for h in html.select('h2,h3,h4')];print('HEADINGS',hs[:10],hs[-4:])
    h=next((h for h in html.select('h2,h3') if re.match(r'^1\. ',h.get_text(' ',strip=True))),None)
    if h:
        print('ANCESTORS',[(p.name,p.get('class'),p.get('id')) for p in list(h.parents)[:5]])
        print('FIRST SECTION',str(h.parent)[:2300])
db.close()
