"""Read official team responses to assess venue-location metadata for weather joins."""
import datetime as dt,json
from collect_premier_pilot import BASE
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def main():
    HOSTS.add('sdp-prem-prod.premier-league-prod.pulselive.com');client=HistoryClient();rows=[]
    for tid in ['1','36','54']:
        try:
            data,r=client.get(BASE+'/v2/teams/'+tid);row=dict(team_id=tid,request_id=r['request_id'],data=data);print(json.dumps(row),flush=True)
        except Exception as e:row=dict(team_id=tid,error=str(e));print(json.dumps(row),flush=True)
        rows.append(row)
    (ROOT/'reports/epl_venue_probes.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=rows,new_requests=client.requests),indent=2),encoding='utf-8')

if __name__=='__main__':main()
