"""Read-only summary of current NHL acquisition and temporal prerequisites."""
import json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

db=sqlite3.connect(DB)
for name in ['_official_nhl_player_game_logs','_official_nhl_career_sources','_official_nhl_player_bios','_nhl_price_acquisition']:
    rows=db.execute('SELECT json_extract(body,\'$.status\'),count(*) FROM '+name+' GROUP BY 1').fetchall()
    print(name,rows)
for key,b in db.execute("SELECT * FROM _official_nhl_player_game_logs WHERE json_extract(body,'$.status')='error' AND json_extract(body,'$.error')!=?",("KeyError: 'gameId'",)):
    v=json.loads(b);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(v['request_id'],)).fetchone()[0]);raw=json.loads((ROOT/r['raw_file']).read_bytes())
    print('LOG SOURCE EXCEPTION',key,json.dumps(v),json.dumps(raw)[:1200])
for name in ['player_profiles','manager_profiles','game_manager_profiles','_nhl_canonical_games']:
    print('SCHEMA',name,[(x[1],x[2]) for x in db.execute('PRAGMA table_info('+name+')')])
for key,b in db.execute("SELECT * FROM _official_nhl_player_game_logs WHERE json_extract(body,'$.status')='ok' LIMIT 1"):
    print('LOG ROW EXAMPLE',json.dumps(json.loads(b)['games'][0]))
for pid in ['8478400','8481848']:
    r=db.execute('SELECT body FROM _official_nhl_career_sources WHERE official_player_id=?',(pid,)).fetchone()
    if r:print('CAREER EXCEPTION ROWS',pid,json.dumps([x for x in json.loads(r[0])['season_totals'] if x.get('leagueAbbrev')=='NHL' and x['season']==20242025]))
for n,b in db.execute('SELECT * FROM _official_nhl_game_reports'):
    v=json.loads(b)
    if any(not x['start_utc'] for x in v['breaks']) and v['request_ids'].get('PL'):
        print('CLOCK REVIEW',n,json.dumps({k:v[k] for k in ['date','teams','breaks','period_clock_events']}))
db.close()
