"""Verify NOAA city/airport stations for NHL cities absent from existing mappings."""
import collections,datetime as dt,io,json,re,sqlite3
from bs4 import BeautifulSoup
import pyarrow.parquet as pq
from build_history_catalog import DB
from collect_history_weather import DOC,STATIONS
from history_client import HistoryClient
from probe_history import ROOT

# Official NOAA station names are airport or metropolitan names. These are
# explicit city-to-airport selections, not claimed stadium measurements.
ALIASES={'Abbotsford':['ABBOTSFORD'],'Anaheim':['SANTA ANA JOHN WAYNE','SANTA ANA JOHN','FULLERTON'], 'Bakersfield':['BAKERSFIELD'],'Boise':['BOISE'],'Buffalo':['BUFFALO'],'Calgary':['CALGARY'],'Columbus':['COLUMBUS PORT','COLUMBUS JOHN','COLUMBUS INTL'],'Elmont':['NEW YORK JFK','NEW YORK J F K','JOHN F KENNEDY'],'Hershey':['HARRISBURG'],'Montreal':['MONTREAL PIERRE','MONTREAL INTL','MONTREAL DORVAL'],'Nashville':['NASHVILLE'],'Newark':['NEWARK'],'Ontario':['ONTARIO INT'],'Ottawa':['OTTAWA'],'Paradise':['LAS VEGAS HARRY','LAS VEGAS MCCARRAN'],'Pittsburgh':['PITTSBURGH INT'],'Quebec City':['QUEBEC JEAN','QUEBEC INT'],'Raleigh':['RALEIGH DURHAM'],'San Jose':['SAN JOSE INT'],'Seattle':['SEATTLE TACOMA'],'St. Louis':['ST LOUIS LAMBERT','ST LOUIS INT'],'St. Paul':['MINNEAPOLIS ST PAUL'],'Stockholm':['STOCKHOLM ARLANDA'],'Tampa':['TAMPA INT'],'Winnipeg':['WINNIPEG']}

def norm(s):return re.sub(r'[^A-Z0-9]+',' ',s.upper()).strip()

# Reviewed against the actual NOAA directory, including its state/country and
# coordinates; this prevents same-city-name matches in another region.
REVIEWED_IDS={'Columbus':['USW00004804'],'Elmont':['USW00094789'],'Paradise':['USW00023169'],'Pittsburgh':['USW00094823'],'Raleigh':['USW00013722'],'San Jose':['USW00023293'],'Newark':['USW00014734'],'Stockholm':['SWU66-00002','SWM00002465','SWU66-00109']}

def main():
    db=sqlite3.connect(DB,timeout=60);cities=collections.defaultdict(list);existing={(city,year):json.loads(b) for city,year,b in db.execute('SELECT city,year,body FROM _weather_city_stations')}
    for b, in db.execute('SELECT body FROM _nhl_canonical_games'):
        g=json.loads(b);city=g.get('city');year=g['date'][:4]
        assert city,'Official game city enrichment required'
        needs_correction=city in REVIEWED_IDS and (city,year) in existing and existing[city,year]['station'] not in REVIEWED_IDS[city]
        if city not in STATIONS and ((city,year) not in existing or needs_correction):cities[city,year].append(dict(game_id=g['game_id'],request_id=g['city_request_id'],pointer=g['city_pointer'],location=g['location'],venue_timezone=g['venue_timezone']))
    c=HistoryClient();b,dr=c.get(DOC+'ghcnh-station-list.txt',document=True);stations={line[:11]:line for line in b.decode().splitlines()};available={};directory={};directory_issues=[]
    for year in sorted({y for _,y in cities}):
        try:
            b,r=c.get(f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/parquet/',document=True);available[year]={m[1] for a in BeautifulSoup(b,'html.parser').find_all('a') if (m:=re.search(r'GHCNh_(.{11})_'+year+r'\.parquet$',a.get('href','')))};directory[year]=r['request_id']
        except RuntimeError as e:
            if 'HTTP failure 404' not in str(e):raise
            directory_issues.append(dict(year=year,error=str(e),action='Probe documented individual annual filenames for official station IDs; missing directory index is not a missing archive'))
            available[year]=set(stations);directory[year]=None
    rows=[];issues=[]
    for (city,year),evidence in sorted(cities.items()):
        aliases=ALIASES.get(city,[]);candidates=[]
        for sid in available[year]:
            if sid not in stations:continue
            name=norm(stations[sid][11:]);ranks=[i for i,a in enumerate(aliases) if norm(a) in name]
            if ranks:candidates.append((min(ranks),0 if sid.startswith('USW') else 1,sid))
        if city in REVIEWED_IDS:
            assert all(sid in stations for sid in REVIEWED_IDS[city]),'Reviewed station absent from official directory'
            candidates=[(n,0,sid) for n,sid in enumerate(REVIEWED_IDS[city])]
        checked=[];hit=None
        for _,__,sid in sorted(candidates)[:8]:
            try:
                b,r=c.get(f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/parquet/GHCNh_{sid}_{year}.parquet',document=True);pf=pq.ParquetFile(io.BytesIO(b));usable=pf.metadata.num_rows>=100 and all(k in pf.schema_arrow.names for k in ['DATE','temperature']);checked.append(dict(station=sid,station_row=stations[sid],request_id=r['request_id'],rows=pf.metadata.num_rows,usable=usable))
                if usable:hit=(sid,r['request_id']);break
            except Exception as e:checked.append(dict(station=sid,error=str(e)))
        if not hit:issues.append(dict(city=city,year=year,reason='No usable official station archive matching reviewed city/airport aliases',aliases=aliases,candidates=len(candidates),checked=checked));continue
        sid,rid=hit;body=dict(city=city,year=year,station=sid,official_city_evidence=evidence,station_directory_request_id=dr['request_id'],archive_directory_request_id=directory[year],archive_request_id=rid,station_directory_row=stations[sid],aliases=aliases,alternatives=checked,method='Explicit official game city to NOAA city/airport station name; outdoor metropolitan observation, not indoor arena weather or verified nearest-station distance')
        if (city,year) in existing:body['replaced_mapping']=existing[city,year];body['correction_reason']='Disambiguated NOAA state/location: Newark, New Jersey rather than Newark, Ohio; no public NHL weather values had been published'
        rows.append((city,year,sid,json.dumps(body)));print('NHL WEATHER STATION',city,year,sid,flush=True)
    with db:db.executemany('INSERT OR REPLACE INTO _weather_city_stations VALUES (?,?,?,?)',rows)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),needed_city_years=len(cities),mapped=len(rows),issues=issues,directory_issues=directory_issues,new_requests=c.requests)
    (ROOT/'reports/nhl_weather_station_mapping.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
