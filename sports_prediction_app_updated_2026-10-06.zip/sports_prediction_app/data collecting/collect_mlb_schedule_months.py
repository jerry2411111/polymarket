"""Acquire official MLB schedules in resumable calendar-month date batches."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,sqlite3
from history_client import HistoryClient
from mlb_official_api import schedule
from build_history_catalog import DB
from probe_history import ROOT

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--max-new-months',type=int);a=ap.parse_args()
    assert json.loads((ROOT/'reports/mlb_public_api_validation.json').read_text())['status']=='WORKING'
    path=ROOT/'reports/mlb_schedule_months.json';old=json.loads(path.read_text()) if path.exists() else {};done={x['month']:x for x in old.get('months',[]) if x['status']=='WORKING'}
    client=HistoryClient();db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _official_mlb_schedule_observations (official_game_id TEXT NOT NULL,requested_date TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(official_game_id,requested_date)) STRICT');db.execute('CREATE TABLE IF NOT EXISTS _mlb_schedule_dates (date TEXT PRIMARY KEY,request_id TEXT NOT NULL,completed_games INTEGER NOT NULL,status TEXT NOT NULL) STRICT');db.commit()
    day=dt.date(2024,1,1);end=dt.date(2026,9,14);parts=[];processed=0
    def fetch(date):
        try:
            rows,r=schedule(client,date);return date,rows,r,None
        except Exception as e:return date,[],None,str(e)
    while day<=end:
        last=min(day.replace(day=calendar.monthrange(day.year,day.month)[1]),end);month=day.strftime('%Y-%m')
        if month in done:parts.append(done[month]);day=last+dt.timedelta(days=1);continue
        if a.max_new_months and processed>=a.max_new_months:break
        dates=[(day+dt.timedelta(days=i)).isoformat() for i in range((last-day).days+1)];errors=[];count=0;ids=set();kinds=collections.Counter()
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            for date,rows,r,error in pool.map(fetch,dates):
                if error:errors.append(dict(date=date,error=error));continue
                for row in rows:
                    native=row['official_game_id'];db.execute('INSERT OR REPLACE INTO _official_mlb_schedule_observations VALUES (?,?,?)',(native,date,json.dumps(row)))
                    prior=db.execute('SELECT body FROM _official_mlb_schedule WHERE official_game_id=?',(native,)).fetchone();prior=json.loads(prior[0]) if prior else None
                    if not prior or date==row['official_date'] or prior['requested_date']!=prior['official_date']:db.execute('INSERT OR REPLACE INTO _official_mlb_schedule VALUES (?,?)',(native,json.dumps(row)))
                    ids.add(native);kinds[row['competition_type']]+=1
                db.execute('INSERT OR REPLACE INTO _mlb_schedule_dates VALUES (?,?,?,?)',(date,r['request_id'],len(rows),'WORKING'));db.commit();count+=len(rows)
        parts.append(dict(month=month,status='WORKING' if not errors else 'PARTIALLY WORKING',dates=len(dates),successful_dates=len(dates)-len(errors),completed_game_observations=count,unique_native_games=len(ids),competition_types=dict(kinds),errors=errors));processed+=1
        out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Official MLB schedule collection, 2024-01-01 through 2026-09-14; distinct from market and odds completeness',total_months=33,completed_months=sum(x['status']=='WORKING' for x in parts),months=parts,new_requests_in_this_run=client.requests)
        path.write_text(json.dumps(out,indent=2),encoding='utf-8');print('OFFICIAL MLB MONTH',month,'dates',len(dates)-len(errors),'/',len(dates),'games',count,'errors',len(errors),'months',out['completed_months'],'/33',flush=True)
        if errors:break
        day=last+dt.timedelta(days=1)
    db.close()

if __name__=='__main__':main()
