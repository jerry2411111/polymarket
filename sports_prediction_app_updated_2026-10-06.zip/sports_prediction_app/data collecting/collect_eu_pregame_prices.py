"""Collect modest, date-batched pregame histories for validated EU outcome contracts.

Official scheduled kickoff is a provisional acquisition boundary; publication
must select against the best verified official clock. No post-start values are
published by this collector. Raw native values and request provenance stay intact.
"""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from build_history_catalog import DB
from eu_official_games import CONFIG,games
from history_client import HistoryClient
from probe_history import ROOT
from core import utc

K='https://external-api.kalshi.com/trade-api/v2'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100
 assert json.loads((ROOT/'reports/eu_market_candidates_validation.json').read_text())['status']=='WORKING'
 db=sqlite3.connect(DB,timeout=60);official={code:games(db,code) for code in CONFIG};c=HistoryClient();cutoff,cr=c.get(K+'/historical/cutoff',refresh=True);cut=utc(cutoff['market_settled_ts']);by_month=collections.defaultdict(list)
 db.execute('CREATE TABLE IF NOT EXISTS _eu_price_acquisition (job_key TEXT PRIMARY KEY,competition TEXT NOT NULL,body TEXT NOT NULL) STRICT');db.commit();done={k:json.loads(b) for k,b in db.execute('SELECT job_key,body FROM _eu_price_acquisition') if json.loads(b)['status']=='ok'}
 for code,b in db.execute('SELECT competition,body FROM _eu_validated_contracts'):
  m=json.loads(b);g=official[code][m['official_match_id']];start=int(utc(g['scheduled_start_utc']).timestamp());by_month[g['date'][:7]].append((m,start-84*3600,start))
 def fetch(job):
  m,lo,hi=job;provider=m['provider'];cid=m['contract_id'];key=f'pre:{provider}:{cid}:{lo}:{hi}';ids=[]
  if key in done:return key,done[key]
  row=dict(competition=m['competition'],provider=provider,contract_id=cid,game_id=m['game_id'],official_match_id=m['official_match_id'],mode='pre',checkpoint='pre',start_ts=lo,end_ts=hi,boundary_basis='official_scheduled_kickoff_pending_actual_clock_validation',request_ids=ids)
  try:
   if provider=='kalshi':
    archive=utc(m['settled'])<cut;path='/historical/markets/'+cid+'/candlesticks' if archive else '/series/'+m['series']+'/markets/'+cid+'/candlesticks';data,r=c.get(K+path,dict(start_ts=lo,end_ts=hi,period_interval=60));ids.append(r['request_id']);assert data['ticker']==cid;xs=data['candlesticks'];field='close' if archive else 'close_dollars'
    for x in xs:
     bid=x.get('yes_bid',{}).get(field);ask=x.get('yes_ask',{}).get(field);assert bid is None or 0<=float(bid)<=1;assert ask is None or 0<=float(ask)<=1;assert bid is None or ask is None or float(bid)<=float(ask)
    row.update(rows=len(xs),resolutions=[3600],route='historical' if archive else 'recent',price_key=field,cutoff_request_id=cr['request_id'])
   else:
    params=dict(token_id=cid,start=lo,end=hi,bucket_seconds=3600,limit=10000);total=0;res=set();cursors=set()
    for page in range(20):
     data,r=c.get('https://data-api.polymarket.com/v2/prices-history',params);ids.append(r['request_id']);xs=data['data']
     if page==0 and not xs:
      params.pop('bucket_seconds');data,r=c.get('https://data-api.polymarket.com/v2/prices-history',params);ids.append(r['request_id']);xs=data['data']
     for x in xs:assert isinstance(x['timestamp'],int) and 0<=x['price']<=1;res.add(x['resolution_seconds'])
     total+=len(xs);cursor=data.get('pagination',{}).get('next_cursor')
     if not cursor:assert not data.get('pagination',{}).get('has_more');break
     assert cursor not in cursors;cursors.add(cursor);params['cursor']=cursor
    else:raise ValueError('Unexhausted price pagination')
    row.update(rows=total,resolutions=sorted(res))
   row['status']='ok'
  except Exception as e:row.update(status='error',error=type(e).__name__+': '+str(e))
  return key,row
 day=dt.date(2024,1,1);parts=[];milestone=10
 while day<=dt.date(2026,9,14) and len(parts)<math.ceil(33*a.through_percent/100):
  month=day.strftime('%Y-%m');counts=collections.Counter();errors=[];rows=0;competitions=collections.defaultdict(collections.Counter)
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
   for key,row in pool.map(fetch,by_month[month]):
    if key not in done:
     with db:db.execute('INSERT OR REPLACE INTO _eu_price_acquisition VALUES (?,?,?)',(key,row['competition'],json.dumps(row)))
    counts[row['status']]+=1;rows+=row.get('rows',0);competitions[row['competition']][row['provider']]+=1
    if row['status']=='error':errors.append(row)
    elif not row['rows']:counts['empty']+=1
  parts.append(dict(month=month,jobs=len(by_month[month]),rows=rows,counts=dict(counts),competitions={k:dict(v) for k,v in competitions.items()},errors=errors))
  report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Five remaining EU competitions: pregame price acquisition',status='PARTIALLY WORKING',total_months=33,processed_months=len(parts),completed_months=sum(not p['errors'] for p in parts),cutoff=cutoff,cutoff_request_id=cr['request_id'],new_requests=c.requests,months=parts,publication='Raw collection only. Actual clock, selected value, age and export validation still required.')
  (ROOT/'reports/eu_pregame_prices_months.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print('EU PRICE MONTH',month,'jobs',len(by_month[month]),'rows',rows,dict(counts),'months',len(parts),'/33',flush=True)
  while len(parts)>=math.ceil(33*milestone/100) and milestone<=100:print('EU PRICE DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  if errors:break
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print('EU PRICE NEW REQUESTS',c.requests,flush=True);db.close()

if __name__=='__main__':main()
