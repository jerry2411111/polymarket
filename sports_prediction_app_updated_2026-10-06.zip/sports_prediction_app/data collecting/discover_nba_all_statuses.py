"""Recheck NBA event discovery without requiring the parent event to be closed.

A completed game can sit inside an event whose other markets are still open.
Current official keyset pagination avoids offset truncation. Date partitions
remain independently reviewable and resumable through the raw-response cache.
"""
import calendar,datetime as dt,json
from history_client import HistoryClient
from history_index import index
from probe_history import ROOT

DOC='https://docs.polymarket.com/api-reference/events/list-events-keyset-pagination'

def main():
    known=set(index()['polymarket_events']);client=HistoryClient()
    _,doc=client.get(DOC+'.md',document=True)
    day=dt.date(2024,1,1);end=dt.date(2026,9,15);parts=[];new=set()
    while day<end:
        hi=min(day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1),end)
        params=dict(tag_id=745,end_date_min=day.isoformat()+'T00:00:00Z',end_date_max=hi.isoformat()+'T00:00:00Z',order='id',ascending='true',limit=500)
        seen=set();cursors=set();requests=[];error=None
        try:
            for _ in range(50):
                data,r=client.get('https://gamma-api.polymarket.com/events/keyset',params);requests.append(r['request_id'])
                for event in data['events']:
                    if event['id'] in seen:raise ValueError('Repeated event in keyset traversal')
                    if not day.isoformat()<=(event.get('endDate') or '')[:10]<=hi.isoformat():raise ValueError('Returned event outside requested date bounds')
                    seen.add(event['id'])
                cursor=data.get('next_cursor')
                if not cursor:break
                if cursor in cursors:raise ValueError('Repeated continuation cursor')
                cursors.add(cursor);params['after_cursor']=cursor
            else:raise ValueError('Keyset page safety limit reached')
        except Exception as e:error=str(e)
        added=seen-known;new.update(added);parts.append(dict(month=day.strftime('%Y-%m'),events=len(seen),new_event_ids=sorted(added),pagination_exhausted=error is None,error=error,request_ids=requests))
        print('NBA ALL STATUS DISCOVERY',day.strftime('%Y-%m'),'events',len(seen),'new',len(added),'status',error or 'ok',flush=True)
        day=hi
    result=dict(documentation_url=DOC,documentation_request_id=doc['request_id'],closed_filter='omitted',new_events=len(new),new_requests=client.requests,months=parts)
    (ROOT/'reports/nba_all_status_discovery.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print('NBA all-status discovery finished; new events:',len(new),'errors:',sum(p['error'] is not None for p in parts),flush=True)

if __name__=='__main__':main()
