"""Official NHL performance facts restricted to games published with usable odds."""
import collections,datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from build_nhl_market_candidates import clean
from nhl_scoring_summary import verified_counts

def main():
    db=sqlite3.connect(DB,timeout=60)
    wanted={r[0] for r in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='NHL' UNION SELECT game_id FROM kalshi_pre_match WHERE league='NHL'")}
    games={g:json.loads(b) for g,b in db.execute('SELECT * FROM _nhl_canonical_games') if g in wanted}
    assert games and set(games)==wanted and all(g.get('completion_local_date') for g in games.values()),'Publish verified expanded NHL odds first'
    feeds={n:json.loads(b) for n,b in db.execute('SELECT * FROM _official_nhl_game_reports')}
    bios={n:json.loads(b) for n,b in db.execute('SELECT * FROM _official_nhl_player_bios') if json.loads(b)['status']=='ok'}
    coaches={clean(json.loads(b)['game_report_name']):json.loads(b) for b, in db.execute('SELECT body FROM _official_nhl_coach_registry')}
    sources={r:json.loads(b) for r,b in db.execute('SELECT request_id,metadata_json FROM _request_audit')};raws={};rosters=[];teamrows=[];coachrows=[];coachaudit=[];issues=[];checks=0;log_index={};supplemented=0;summary_recovered=0;summary_audit=[]
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='_official_nhl_player_game_logs'").fetchone():
        for b, in db.execute('SELECT body FROM _official_nhl_player_game_logs'):
            record=json.loads(b)
            if record['status']!='ok':continue
            for n,row in enumerate(record['games']):log_index[record['official_player_id'],str(row['id'])]=(row,record['request_id'],n)
    def raw(rid):
        if rid not in raws:
            r=sources[rid];data=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(data).hexdigest()==r['sha256'];raws[rid]=json.loads(data)
        return raws[rid]
    for gid,g in sorted(games.items()):
        f=feeds[g['official_game_id']];assert f['scores']==g['scores'] and f['official_team_ids']==g['team_ids'];day=g['completion_local_date']
        assert day>=g['date']
        if day>'2026-09-14':issues.append(dict(game_id=gid,reason='Final completion after cutoff'));continue
        temporary=any(k in g['season'] for k in ['All-Star','4 Nations'])
        wins=[int(g['winner']==team) for team in g['teams']]
        for side in range(2):
            teamrows.append((gid,g['teams'][side],'Hockey','NHL',day,g['home_away'].split(';')[side],g['scores'][side],g['scores'][1-side],wins[side]))
            name=f['coaches'][side]
            if name:
                # NHL gameInfo supplies a full coach name, but no native coach
                # ID. This explicit internal identity retains its raw evidence.
                identity=coaches.get(clean(name));coach_id='NHL_COACH:'+identity['official_coach_id'] if identity else 'NHL_COACH_UNRESOLVED:'+hashlib.sha256(name.strip().casefold().encode()).hexdigest()[:16]
                if identity:
                    registry=raw(identity['request_id']);assert len(registry['data'])==1 and str(registry['data'][0]['id'])==identity['official_coach_id'] and clean(registry['data'][0]['fullName'])==clean(name)
                key=['awayTeam','homeTeam'][side];rail=raw(f['request_ids']['right-rail']);assert rail['gameInfo'][key]['headCoach']['default']==name
                coachrows.append((coach_id,name,'Hockey','NHL',g['teams'][side],gid,day,g['home_away'].split(';')[side],g['scores'][side],g['scores'][1-side],wins[side]))
                coachaudit.append(dict(manager_id=coach_id,manager_name=name,game_id=gid,game_date=day,team_id=g['team_ids'][side],team_name=g['teams'][side],temporary_team=temporary,request_id=f['request_ids']['right-rail'],pointer='/gameInfo/'+key+'/headCoach/default',official_coach_id=identity['official_coach_id'] if identity else None,identity_request_id=identity['request_id'] if identity else None,identity_basis='Official NHL Records native coach ID matched to full official game-report name' if identity else 'Unresolved native identity; separate internal full-name key'))
            else:issues.append(dict(game_id=gid,side=side,reason='Official head coach absent'))
        summary=None;summary_checked=False
        for source in f['players']:
            p=dict(source);native=p['official_player_id'];pid='NHL:'+native;name=bios.get(native,{}).get('player_name') or p['player_name'];assert name
            d=raw(p['request_id'])
            for key in p['pointer'].strip('/').split('/'):d=d[int(key)] if isinstance(d,list) else d[key]
            assert d==p['raw'];checks+=1
            if p['played'] is True:assert p['minutes'] is not None and p['minutes']>0
            log=log_index.get((native,g['official_game_id']))
            if p['played'] is True and log and any(p[k] is None for k in ['score','assists']):
                row,rid,n=log;source=raw(rid)['gameLog'][n];assert source==row and str(source['id'])==g['official_game_id'] and source['gameDate']==g['date']
                assert [source['awayScore'],source['homeScore']]==g['scores'] and str(source['homeTeam' if source['homeRoadFlag']=='H' else 'awayTeam']['id'])==p['official_team_id']
                p['supplemental_stat_sources']={}
                for field,native_field in [('score','goals'),('assists','assists')]:
                    if p[field] is None and source.get(native_field) is not None:
                        p[field]=source[native_field];p['supplemental_stat_sources'][field]=dict(request_id=rid,pointer='/gameLog/'+str(n)+'/'+native_field,raw_value=source[native_field]);supplemented+=1
            if p['played'] is True and any(p[k] is None for k in ['score','assists']):
                rid=f['request_ids']['landing']
                if not summary_checked:
                    summary,reason=verified_counts(raw(rid),g,f['players']);summary_checked=True
                    summary_audit.append(dict(game_id=gid,request_id=rid,verified=summary is not None,reason=reason,proof={k:v for k,v in summary.items() if k!='counts'} if summary else None))
                if summary is not None:
                    # Zero is an explicit event count over a verified complete
                    # goal/assist list, never a missing-field default.
                    counts=summary['counts'].get(native,dict(score=0,assists=0))
                    for field in ['score','assists']:
                        if p[field] is None:
                            p[field]=counts[field];summary_recovered+=1
                            p.setdefault('supplemental_stat_sources',{})[field]=dict(request_id=rid,pointer='/summary/scoring',normalized_value=p[field],method='Count native player IDs in complete official non-shootout scoring summary; final scores and explicit player boxscores cross-checked')
            p.update(player_id=pid,player_name=name,team_name=g['teams'][p['side']],game_id=gid,game_type='Hockey',league='NHL',game_date=day,original_game_date=g['date'],did_play=p['played'],win=wins[p['side']],temporary_team=temporary,affiliation_observation_safe=not g['spans_multiple_local_dates'],spans_multiple_local_dates=g['spans_multiple_local_dates'])
            rosters.append(p)
    assert len({(p['player_id'],p['game_id']) for p in rosters})==len(rosters)
    played=[p for p in rosters if p['did_play'] is True]
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _nhl_player_game_facts (player_id TEXT,game_id TEXT,body TEXT NOT NULL,PRIMARY KEY(player_id,game_id)) STRICT');db.execute('DELETE FROM _nhl_player_game_facts');db.executemany('INSERT INTO _nhl_player_game_facts VALUES (?,?,?)',[(p['player_id'],p['game_id'],json.dumps(p)) for p in rosters])
        db.execute("DELETE FROM _player_game_results WHERE league='NHL'");db.executemany('INSERT INTO _player_game_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',[(p['player_id'],p['player_name'],'Hockey','NHL',p['team_name'],p['game_id'],p['game_date'],p['score'],p['assists'],p['minutes'],p['starter'],p['win']) for p in played])
        db.execute("DELETE FROM _team_game_results WHERE league='NHL'");db.executemany('INSERT INTO _team_game_results VALUES (?,?,?,?,?,?,?,?,?)',teamrows)
        db.execute("DELETE FROM _manager_game_results WHERE league='NHL'");db.executemany('INSERT INTO _manager_game_results VALUES (?,?,?,?,?,?,?,?,?,?,?)',coachrows)
        db.execute('CREATE TABLE IF NOT EXISTS _nhl_manager_game_facts (manager_id TEXT,game_id TEXT,body TEXT NOT NULL,PRIMARY KEY(manager_id,game_id)) STRICT');db.execute('DELETE FROM _nhl_manager_game_facts');db.executemany('INSERT INTO _nhl_manager_game_facts VALUES (?,?,?)',[(p['manager_id'],p['game_id'],json.dumps(p)) for p in coachaudit])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Source performance facts; date-queryable aggregates and profiles are installed separately',selected_games=len(games),roster_rows=len(rosters),played_rows=len(played),native_players=len({p['player_id'] for p in rosters}),coach_game_rows=len(coachrows),coach_identities=len({p[0] for p in coachrows}),raw_player_checks=checks,source_hash_checks=len(raws),official_game_log_statistics_recovered=supplemented,issues=issues,missing={k:dict(count=sum(p[k] is None for p in played),total=len(played),percentage=round(sum(p[k] is None for p in played)*100/len(played),4)) for k in ['score','assists','minutes','starter']},meaning=dict(score='Official individual goals, not goals plus assists. A shootout team deciding goal is not an individual goal.',minutes='Official TOI converted from mm:ss to fractional minutes; zero-TOI bench goalies do not become played appearances.',completion='Statistics enter on the verified local completion date; when wall-clock end is unavailable they are withheld until the next local date.',rosters='Dated boxscore and scratch observations; temporary national/All-Star rosters cannot replace a club affiliation.'))
    out.update(official_complete_scoring_statistics_recovered=summary_recovered,scoring_summary_checks=summary_audit)
    (ROOT/'reports/nhl_performance_facts.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='scoring_summary_checks'}));db.close()

if __name__=='__main__':main()
