"""Bounded identity conflicts revealed by a second native-ID biography source."""
import json,re,sqlite3
from build_history_catalog import DB
from collect_laliga_people import namekey
from probe_history import ROOT
db=sqlite3.connect(DB);report=json.loads((ROOT/'reports/eu_person_registry.json').read_text());lal={k:json.loads(b) for k,b in db.execute('SELECT * FROM _official_laliga_people_sources')}
for e in report['issues']:
 pid=e.get('source_person_id')
 if pid:
  cross=json.loads(db.execute('SELECT body FROM _eu_person_crosswalk WHERE source_person_id=?',(pid,)).fetchone()[0]);row=next((lal[namekey(n)] for n in cross['names'] if namekey(n) in lal and lal[namekey(n)]['status']=='ok'),None);print(json.dumps(dict(issue=e,names=cross['names'],profile_id=row.get('person_id') if row else None,profile_assets=sorted(set(re.findall(r'/(p\d+)/',str(row['data'].get('squads',[]))))) if row else []),ensure_ascii=False))
 else:print(json.dumps(e,ensure_ascii=False))
db.close()
