"""Read current official player-page payloads and the player-detail client."""
import json,re,sqlite3
from bs4 import BeautifulSoup
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS

def main():
 c=HistoryClient();HOSTS.update({'www.bundesliga.com','www.laliga.com'});out=[]
 for url in ['https://www.bundesliga.com/chunk-Q4VXFNZE.js','https://www.bundesliga.com/en/player/oliver-baumann','https://www.laliga.com/en-GB/player/giorgi-mamardashvili']:
  try:
   b,r,redirects=get(c,url);out.append(dict(url=url,request_id=r['request_id'],status=r['status'],redirects=redirects));s=b.decode('utf-8');print('SOURCE',url,r['request_id'],r['status'])
   if url.endswith('.js'):
    for h in list(re.finditer(r'getPlayer|playerSlug|Firebase|/players|/persons|playerId',s))[:7]:print('CLIENT',h.start(),s[max(0,h.start()-70):h.end()+230])
   else:
    soup=BeautifulSoup(b,'html.parser');print('TITLE',soup.title.get_text() if soup.title else None)
    for t in soup.find_all('script',type='application/json'):
     d=json.loads(t.get_text())
     if t.get('id')=='__NEXT_DATA__':print('PROPS',list(d['props']['pageProps']));print('PERSON',json.dumps(d['props']['pageProps'].get('player'),ensure_ascii=False)[:1800])
     else:
      for k,v in d.items():
       if k.startswith('_getDataFromFirebase') and any(w in k.lower() for w in ['player','person']):print('TRANSFER',k,'TYPE',type(v).__name__,'KEYS',list(v)[:25] if isinstance(v,dict) else None)
  except Exception as e:print('ERROR',url,str(e));out.append(dict(url=url,error=str(e)))
 (ROOT/'reports/eu_biography_route_pilot.json').write_text(json.dumps(out,indent=2),encoding='utf-8')

if __name__=='__main__':main()
