"""Carry the most recent eligible publisher edition forward on every query date."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

def refresh(db):
    from temporal_queries import FLAGS
    from install_nba_rankings import NAMES
    from ranking_policy import refresh_policy
    db.row_factory=sqlite3.Row
    start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    suppressed={r[0] for r in db.execute('SELECT list_id FROM _ranking_edition_audit WHERE use_for_flags=0')}
    names={v:k for k,v in NAMES.items()}
    editions=[]
    for row in db.execute('SELECT * FROM ranking_list_versions'):
        e=dict(row)
        if e['list_id'] in suppressed:continue
        e['known_from']=max(e['publication_date'],e['version_verified_date']);e['publisher_key']=names[e['publisher']]
        if e['known_from']<=end:editions.append(e)
    aliases={(r['source_player_id'],r['league']):r['player_id'] for r in db.execute('SELECT * FROM _player_identity_aliases')}
    facts={};people=collections.defaultdict(set)
    for r in db.execute('SELECT * FROM player_media_rankings'):
        pid=aliases.get((r['player_id'],r['league']),r['player_id']);k=r['list_id'],pid
        if k in facts:assert facts[k]==r['rank'],('Conflicting canonical ranks',k)
        facts[k]=r['rank'];people[r['league']].add(pid)
    days=sorted({start}|{max(start,e['known_from']) for e in editions})
    cache=[];selected=[]
    for day in days:
        for league in ['NBA','MLB','NHL','EU soccer']:
            choices={}
            for e in editions:
                if e['league']!=league or e['known_from']>day:continue
                key=e['publisher_key'];old=choices.get(key)
                if not old or (e['publication_date'],e['version_verified_date'],e['list_id'])>(old['publication_date'],old['version_verified_date'],old['list_id']):choices[key]=e
            for pub,e in choices.items():selected.append((day,league,pub,e['list_id'],e['publication_date'],e['version_verified_date']))
            for pid in people[league]:
                values={c:None for c in FLAGS}
                for pub,e in choices.items():
                    rank=facts.get((e['list_id'],pid))
                    for n in [5,10,20,50]:values[pub+'_top_'+str(n)]=int(rank<=n) if rank is not None else None
                cache.append((day,pid,league,*[values[c] for c in FLAGS]))
    db.execute('DELETE FROM _ranking_snapshot_dates');db.executemany('INSERT INTO _ranking_snapshot_dates VALUES (?)',[(d,) for d in days])
    db.execute('DELETE FROM _ranking_canonical_cache');db.executemany('INSERT INTO _ranking_canonical_cache VALUES ('+','.join('?' for _ in range(3+len(FLAGS)))+')',cache)
    db.execute('CREATE TABLE IF NOT EXISTS _ranking_asof_selection(as_of_date TEXT,league TEXT,publisher_key TEXT,list_id TEXT,publication_date TEXT,version_verified_date TEXT,PRIMARY KEY(as_of_date,league,publisher_key)) STRICT')
    db.execute('DELETE FROM _ranking_asof_selection');db.executemany('INSERT INTO _ranking_asof_selection VALUES(?,?,?,?,?,?)',selected)
    db.execute('CREATE TABLE IF NOT EXISTS _ranking_asof_policy(policy TEXT PRIMARY KEY) STRICT')
    db.execute("INSERT OR IGNORE INTO _ranking_asof_policy VALUES('LATEST_ELIGIBLE_PUBLISHER_EDITION_NO_QUARTER_DELAY')")
    refresh_policy(db,FLAGS)
    # Each selected edition must already be available and be the newest eligible one.
    for day,league,pub,eid,published,version in selected:
        eligible=[e for e in editions if e['league']==league and e['publisher_key']==pub and e['known_from']<=day]
        assert eid==max(eligible,key=lambda e:(e['publication_date'],e['version_verified_date'],e['list_id']))['list_id']
        assert published<=day and version<=day
    return dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),edition_count=len(editions),change_dates=len(days),cache_rows=len(cache),publisher_date_selections=len(selected),
                policy='Most recent publication/version eligible on or before query date; carried forward without quarterly delay. Unlisted players are false after publisher evidence exists. Before any eligible edition, flags remain NULL.',failures=0)

def main():
    db=sqlite3.connect(DB,timeout=120)
    with db:out=refresh(db)
    db.close();(ROOT/'reports/latest_ranking_install.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out),flush=True)
if __name__=='__main__':main()
