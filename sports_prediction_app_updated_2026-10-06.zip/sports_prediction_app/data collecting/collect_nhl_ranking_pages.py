"""Acquire original-publisher NHL rankings and their dated linked installments."""
import datetime as dt,json,re,sqlite3
from urllib.parse import urljoin,urlsplit
from bs4 import BeautifulSoup
from build_history_catalog import DB
from collect_nba_ranking_pages import metadata
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS
PAGES=[
 ('espn','https://www.espn.com/nhl/story/_/id/41753159/nhl-rank-2024-25-top-100-players-rankings-predictions'),
 ('cbs_sports','https://new.cbssports.com/nhl/news/nhls-top-75-players-ranked-how-connor-mcdavid-sidney-crosby-compare-to-their-peers-entering-2025-26/'),
 ('espn','https://www.espn.com/nhl/story/_/id/46582574/nhl-2025-26-rankings-top-100-players-predictions-stats'),
 ('bleacher_report','https://bleacherreport.com/articles/25257517-brs-top-32-nhl-player-rankings-start-2025-26-season/'),
 ('sportsnet','https://www.sportsnet.ca/nhl/longform/sportsnets-insiders-rank-the-nhls-top-50-players-in-2025-26-10-1/'),
 ('sportsnet','https://www.sportsnet.ca/nhl/longform/sportsnet-insiders-rank-the-nhls-top-50-players-10-1/'),
 ('nhl_network','https://www.nhl.com/news/nhl-network-countdown-top-players-numbers-10-1'),
 ('nhl_network','https://www.nhl.com/news/topic/season-previews/nhl-network-countdown-top-players-numbers-40-31'),
 ('nhl_network','https://www.nhl.com/news/topic/catching-up-with/nhl-network-countdown-top-players-numbers-30-21'),
 ('nhl_network','https://www.nhl.com/news/topic/season-previews/nhl-network-countdown-top-players-numbers-50-41'),
 ('the_hockey_news','https://thehockeynews.com/nhl/vancouver-canucks/latest-news/4-canucks-featured-in-the-hockey-news-top-50-players-ahead-of-the-2024-25-season'),
]
def main():
 HOSTS.update(urlsplit(u).hostname for _,u in PAGES);c=HistoryClient();db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _nhl_ranking_sources (url TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();queue=list(PAGES);seen=set();out=[]
 while queue:
  publisher,url=queue.pop(0)
  if url in seen:continue
  seen.add(url)
  try:
   b,r,redirects=get(c,url);s=BeautifulSoup(b,'html.parser');meta=metadata(s);x=dict(publisher=publisher,url=url,final_url=r['endpoint'],status='ACQUIRED_NOT_VALIDATED',request_id=r['request_id'],retrieved_at_utc=r['retrieved_at_utc'],title=s.title.get_text(' ',strip=True) if s.title else None,metadata=meta,redirects=redirects)
   # Follow only original publisher links explicitly present in an acquired
   # ranking. No guessed URLs, mirrors, paywall routes or article proxies.
   for a in s.find_all('a',href=True):
    link=urljoin(r['endpoint'],a['href']).split('#')[0]
    if urlsplit(link).hostname!=urlsplit(url).hostname:continue
    if publisher=='sportsnet' and any(p in link for p in ['/longform/','/article/']) and 'top-50-players' in link and re.search(r'-(?:50-41|40-31|30-21|20-11|10-1)/?$',link):
     if ('2025-26' in link)==('2025-26' in url):queue.append((publisher,link))
    if publisher=='nhl_network' and 'nhl-network-countdown-top-players-numbers-' in link and re.search(r'(?:50-41|40-31|30-21|20-11|10-1)/?$',link):queue.append((publisher,link))
  except Exception as e:x=dict(publisher=publisher,url=url,status='UNAVAILABLE',error=type(e).__name__+': '+str(e))
  db.execute('INSERT OR REPLACE INTO _nhl_ranking_sources VALUES (?,?)',(url,json.dumps(x)));db.commit();out.append(x);print('NHL RANKING SOURCE',publisher,x['status'],x.get('title') or x.get('error'),flush=True)
  assert len(seen)<=50,'Unexpected ranking link expansion'
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=out,new_requests=c.requests,scope='Acquisition only; source dates, subscription flags, overall-list scope, installment deduplication and native IDs require validation.',access_limitations=['Web retrieval reports robots restrictions for NYTimes/The Athletic, TSN and USA Today; no access-control workaround attempted.','A publisher reporting another publisher ranking is not an independent list.','All-time, age-limited, positional, fantasy and playoff-only lists cannot populate overall current-league flags.'])
 (ROOT/'reports/nhl_ranking_acquisition.json').write_text(json.dumps(report,indent=2),encoding='utf-8');db.close()
if __name__=='__main__':main()
