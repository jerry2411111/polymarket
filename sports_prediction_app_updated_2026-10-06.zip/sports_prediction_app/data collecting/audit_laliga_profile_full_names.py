"""Detect homonyms and full-name mismatches before identity/profile publication."""
import collections,datetime as dt,json,re,sqlite3
from build_history_catalog import DB
from collect_laliga_people import namekey
from probe_history import ROOT
db=sqlite3.connect(DB);profiles={k:json.loads(b) for k,b in db.execute('SELECT * FROM _official_laliga_people_sources')};people={};groups=collections.defaultdict(set);mismatch=[]
for b, in db.execute("SELECT body FROM _eu_source_player_game_facts WHERE json_extract(body,'$.competition_code')='LAL'"):
 p=json.loads(b);raw=p['raw_player']['person'];full=' '.join(filter(None,[raw.get('firstname'),raw.get('lastname')]));people.setdefault(p['player_id'],dict(player_id=p['player_id'],names=set(),full_names=set(),team_ids=set(),source_request_ids=set()));v=people[p['player_id']];v['names'].add(p['player_name']);v['full_names'].add(full);v['team_ids'].add(p['official_team_id']);v['source_request_ids'].add(p['roster_request_id']);groups[namekey(p['player_name'])].add(full)
for p in people.values():
 rows=[profiles.get(namekey(n)) for n in p['names']];rows=[r for r in rows if r and r['status']=='ok']
 for r in rows:
  d=r['data'];full=' '.join(filter(None,[d.get('firstname'),d.get('lastname')]));source={namekey(n) for n in p['full_names'] if n}
  if namekey(full) not in source:mismatch.append(dict(player_id=p['player_id'],source_names=sorted(p['names']),source_full_names=sorted(p['full_names']),profile_name=full,profile_id=r['person_id'],request_id=r['request_id'],reason='Complete personal name differs'))
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),source_ids=len(people),homonym_display_names=[dict(display_key=k,full_names=sorted(v)) for k,v in groups.items() if len(v)>1],profile_name_mismatches=mismatch);(ROOT/'reports/laliga_profile_full_name_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
asset_mismatches=[];counts=collections.Counter()
for pid,p in people.items():
 if not pid.startswith('EU_LAL:p'):continue
 row=next((profiles[namekey(n)] for n in p['names'] if namekey(n) in profiles and profiles[namekey(n)]['status']=='ok'),None)
 if not row:continue
 expected=pid.split(':')[1];assets=set(re.findall(r'/(p\d+)/',str(row['data'].get('squads',[]))));counts['matched' if expected in assets else 'missing_assets' if not assets else 'mismatched']+=1
 if assets and expected not in assets:asset_mismatches.append(dict(player_id=pid,names=sorted(p['names']),profile_id=row['person_id'],profile_assets=sorted(assets),source_team_ids=sorted(p['team_ids'])))
out['profile_asset_checks']=dict(counts);out['profile_asset_mismatches']=asset_mismatches;(ROOT/'reports/laliga_profile_full_name_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('ASSET AUDIT',json.dumps(out['profile_asset_checks']),'MISMATCHES',json.dumps(asset_mismatches))
db.close()
