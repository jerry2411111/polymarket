"""Bounded, nonsecret inspection of retained official UEFA match records."""
import argparse,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
p=argparse.ArgumentParser();p.add_argument('ids',nargs='+');a=p.parse_args();db=sqlite3.connect(DB);seen=set()
for rid,body in db.execute("SELECT request_id,metadata_json FROM _request_audit WHERE json_extract(metadata_json,'$.endpoint') LIKE 'https://match.uefa.com/v5/matches%' AND json_extract(metadata_json,'$.status')=200 ORDER BY request_number DESC"):
 r=json.loads(body);data=json.loads((ROOT/r['raw_file']).read_bytes());data=data if isinstance(data,list) else [data]
 for i,m in enumerate(data):
  if m.get('id') not in a.ids or m['id'] in seen:continue
  seen.add(m['id']);out={k:m.get(k) for k in ['id','kickOffTime','score','status','type','seasonYear','fullTimeAt','condition']};out.update(away=m['awayTeam']['translations']['displayOfficialName']['EN'],home=m['homeTeam']['translations']['displayOfficialName']['EN'],request_id=rid,pointer='/'+str(i),winner={k:dict(reason=v.get('reason'),team_id=v.get('team',{}).get('id')) for k,v in m.get('winner',{}).items()},goals=[dict(id=e['id'],phase=e.get('phase'),team_id=e.get('teamId'),time=e.get('time'),goalType=e.get('goalType')) for e in m.get('playerEvents',{}).get('scorers',[])]);print(json.dumps(out,ensure_ascii=False))
 if seen==set(a.ids):break
db.close()
