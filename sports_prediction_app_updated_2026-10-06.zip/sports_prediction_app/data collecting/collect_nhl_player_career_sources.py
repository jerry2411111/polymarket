"""Acquire official career-season and dated-move evidence, separate from performance.

Season totals are never used to fill the collected-games-only performance table.
They support biographical career history, subject to season/date eligibility.
"""
import collections,concurrent.futures,datetime as dt,json,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT
db=sqlite3.connect(DB,timeout=60);people={p:json.loads(b) for p,b in db.execute('SELECT * FROM _official_nhl_player_bios') if json.loads(b)['status']=='ok'};db.execute('CREATE TABLE IF NOT EXISTS _official_nhl_career_sources (official_player_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();done={p for p,b in db.execute('SELECT * FROM _official_nhl_career_sources') if json.loads(b)['status']=='ok'};todo=sorted(set(people)-done);c=HistoryClient();errors=[];count=0
def fetch(pid):
 try:
  d,r=c.get('https://api-web.nhle.com/v2/player/'+pid+'/player-stats');seasons=d.get('seasonTotals');assert isinstance(seasons,list)
  assert all(isinstance(x['season'],int) for x in seasons),'Career row lacks a native season'
  return pid,dict(status='ok',official_player_id=pid,player_name=people[pid]['player_name'],request_id=r['request_id'],season_totals=seasons,notes_transactions=people[pid]['raw_bio'].get('notesTransactions',{}).get('default'),notes_request_id=people[pid]['request_id'],notes_pointer='/bio/notesTransactions/default',meaning='Raw official career sources. An unfinished season total is never as-of evidence; performance remains restricted to separately collected completed game facts.')
 except Exception as e:return pid,dict(status='error',official_player_id=pid,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for pid,row in pool.map(fetch,todo):
  db.execute('INSERT OR REPLACE INTO _official_nhl_career_sources VALUES (?,?)',(pid,json.dumps(row)));db.commit();count+=1
  if row['status']=='error':errors.append(row)
  if count%100==0:print('NHL CAREER SOURCES',count,'/',len(todo),'errors',len(errors),flush=True)
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),biography_population=len(people),attempted=len(todo),new_requests=c.requests,errors=errors,total_cached=db.execute("SELECT count(*) FROM _official_nhl_career_sources WHERE json_extract(body,'$.status')='ok'").fetchone()[0]);(ROOT/'reports/nhl_career_source_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
