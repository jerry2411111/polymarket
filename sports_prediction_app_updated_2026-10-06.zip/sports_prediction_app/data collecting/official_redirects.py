"""Follow normal redirects only within the requested official HTTPS origin."""
import json,re,sqlite3
from urllib.parse import urljoin,urlsplit
from build_history_catalog import DB

def get(client,url):
    origin=urlsplit(url).hostname;current=url;redirects=[]
    for _ in range(5):
        try:
            b,r=client.get(current,document=True)
            return b,r,redirects
        except RuntimeError as e:
            m=re.fullmatch(r'HTTP failure (?:301|302|307|308); request ([a-f0-9]{32})',str(e))
            if not m:raise
            with sqlite3.connect(DB,timeout=60) as db:a=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(m[1],)).fetchone()[0])
            target=urljoin(current,a['location']);assert urlsplit(target).scheme=='https' and urlsplit(target).hostname==origin,'Official redirect changed origin'
            redirects.append(dict(request_id=m[1],from_url=current,to_url=target));current=target
    raise RuntimeError('Official redirect limit exceeded')
