"""Inspect official club/venue fallback pages where game APIs omit city."""
import json,re,sqlite3
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS
c=HistoryClient();HOSTS.update(['www.laliga.com','www.bundesliga.com']);urls=['https://www.laliga.com/en-GB/clubs/valencia-cf','https://www.bundesliga.com/en/bundesliga/news/stadiums-germany-2025-26-allianz-arena-signal-iduna-park-32656'];db=sqlite3.connect(DB,timeout=60);results=[]
for url in urls:
 raw,r,redirects=get(c,url);soup=BeautifulSoup(raw,'html.parser');blocks=[]
 for script in soup.find_all('script'):
  if script.get('id')=='__NEXT_DATA__':blocks.append(json.loads(script.get_text())['props']['pageProps'])
  elif script.get('type') in ['application/json','application/ld+json']:
   try:blocks.append(json.loads(script.get_text()))
   except ValueError:pass
 hits=[]
 def walk(v,path,depth=0):
  if depth>7:return
  if isinstance(v,dict):
   for k,x in v.items():
    if any(s in k.lower() for s in ['stadium','venue','city','address','latitude','longitude']):hits.append((path+'/'+k,x))
    elif k not in ['images','photos','translations']:walk(x,path+'/'+k,depth+1)
  elif isinstance(v,list):
   for i,x in enumerate(v[:10]):walk(x,path+'/'+str(i),depth+1)
 for i,b in enumerate(blocks):walk(b,'/'+str(i))
 clubs=sorted({urljoin(url,a['href']) for a in soup.find_all('a',href=True) if '/clubs/' in a['href']});row=dict(url=url,request_id=r['request_id'],redirects=redirects,structured_venue_fields=hits,club_links=clubs);results.append(row);print('OFFICIAL LOCATION PAGE',url,'STRUCTURE',json.dumps(hits,ensure_ascii=False)[:4000],'CLUB LINKS',clubs[:5],flush=True)
with db:
 db.execute('CREATE TABLE IF NOT EXISTS _eu_location_documents (url TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_location_documents VALUES (?,?)',[(r['url'],json.dumps(r)) for r in results])
(ROOT/'reports/eu_location_page_pilot.json').write_text(json.dumps(results,indent=2),encoding='utf-8');db.close()
