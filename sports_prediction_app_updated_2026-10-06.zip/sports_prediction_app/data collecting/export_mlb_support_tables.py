"""Export final MLB support tables, preserving all available date history."""
import argparse,collections,csv,datetime as dt,hashlib,json,sqlite3
import pyarrow as pa
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT

TABLES=['player_profiles','player_current_team','player_performance','manager_profiles','manager_performance','team_history','weather']

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--league',choices=['MLB','NHL','EU soccer'],default='MLB');ap.add_argument('--table',choices=TABLES);ap.add_argument('--resume',action='store_true');args=ap.parse_args();league=args.league;prefix=league.lower().replace(' ','_')
 validations=['eu_profiles_validation.json','eu_performance_validation.json','player_query_name_validation.json','weather_tables_validation.json'] if league=='EU soccer' else [prefix+'_temporal_validation.json','ranking_temporal_validation.json']
 for filename in validations:assert json.loads((ROOT/'reports'/filename).read_text())['status']=='WORKING',filename
 db=sqlite3.connect(DB,timeout=60);dest=ROOT/'data/result'/prefix;dest.mkdir(exist_ok=True);outputs=[]
 for name in ([args.table] if args.table else TABLES):
  report_path=ROOT/'reports'/(prefix+'_'+name+'_export.json')
  if args.resume and report_path.exists():
   old=json.loads(report_path.read_text());path=ROOT/old['parquet'];assert path.is_file() and (ROOT/old['csv']).is_file() and pq.ParquetFile(path).metadata.num_rows==old['rows'];outputs.append(old);print(league,'SUPPORT EXPORT retained completed',name,old['rows'],flush=True);continue
  n=0;types={r[1]:r[2] for r in db.execute('PRAGMA table_info('+name+')')}
  sql='SELECT * FROM '+name+" WHERE league='"+league+"'" if name!='weather' else "SELECT w.* FROM weather w WHERE EXISTS(SELECT 1 FROM _game_weather_links l WHERE l.city=w.city AND l.date=w.date AND "+("EXISTS(SELECT 1 FROM _eu_game_facts g WHERE g.game_id=l.game_id)" if league=='EU soccer' else "l.game_id LIKE '"+league+"_%'")+")"
  if name=='player_performance':
   from temporal_queries import FLAGS,PLAYER_OUTPUT
   from ranking_policy import active_flags
   sql='SELECT '+','.join(PLAYER_OUTPUT+active_flags(db,league,FLAGS))+" FROM player_performance WHERE league='"+league+"'"
  total=db.execute('SELECT count(*) FROM ('+sql+')').fetchone()[0];cur=db.execute(sql);cols=[x[0] for x in cur.description]
  if name in ['player_performance','manager_performance']:
   text={'player_id','player_name','manager_id','manager_name','game_type','league','team','as_of_date','performance_status'};ints={'games_played','home_times','away_times'};types={c:'TEXT' if c in text else 'INTEGER' if c in ints or '_top_' in c else 'REAL' for c in cols}
  schema=pa.schema([(c,pa.int64() if types.get(c)=='INTEGER' else pa.float64() if types.get(c)=='REAL' else pa.string()) for c in cols]);milestone=10;missing=collections.Counter();expected_hash=hashlib.sha256();expected_csv=hashlib.sha256()
  def normalize(row):return tuple(None if v is None else int(v) if types.get(c)=='INTEGER' else float(v) if types.get(c)=='REAL' else str(v) for c,v in zip(cols,row))
  def digest(h,row):h.update((json.dumps(row,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode())
  with (dest/(name+'.csv')).open('w',newline='',encoding='utf-8') as f,pq.ParquetWriter(dest/(name+'.parquet'),schema,compression='zstd') as pw:
   cw=csv.writer(f);cw.writerow(cols)
   while batch:=cur.fetchmany(10000):
    batch=[normalize(r) for r in batch]
    for row in batch:
     digest(expected_hash,row);digest(expected_csv,['' if v is None else str(v) for v in row]);missing.update(c for c,v in zip(cols,row) if v is None)
    cw.writerows(batch);pw.write_table(pa.Table.from_pylist([dict(zip(cols,r)) for r in batch],schema=schema));n+=len(batch)
    while milestone<=100 and n*100>=milestone*total:print(league,'SUPPORT EXPORT',name,str(milestone)+'%',n,'/',total,flush=True);milestone+=10
  assert n==total and pq.ParquetFile(dest/(name+'.parquet')).metadata.num_rows==total
  actual_hash=hashlib.sha256();actual_csv=hashlib.sha256()
  for batch in pq.ParquetFile(dest/(name+'.parquet')).iter_batches(batch_size=10000):
   for row in batch.to_pylist():digest(actual_hash,[row[c] for c in cols])
  with (dest/(name+'.csv')).open(newline='',encoding='utf-8') as f:
   reader=csv.reader(f);assert next(reader)==cols
   for row in reader:digest(actual_csv,row)
  assert actual_hash.digest()==expected_hash.digest() and actual_csv.digest()==expected_csv.digest(),'Full exported values differ from SQL'
  output=dict(table=name,rows=n,columns=len(cols),csv=(dest/(name+'.csv')).relative_to(ROOT).as_posix(),parquet=(dest/(name+'.parquet')).relative_to(ROOT).as_posix(),sql_and_parquet_values_sha256=expected_hash.hexdigest(),sql_and_csv_values_sha256=expected_csv.hexdigest(),missing={c:dict(count=missing[c],total=n,percentage=round(missing[c]*100/n,4) if n else None) for c in cols});outputs.append(output)
  (ROOT/'reports'/(prefix+'_'+name+'_export.json')).write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),**output),indent=2),encoding='utf-8')
 manifest=[json.loads(p.read_text()) for name in TABLES if (p:=ROOT/'reports'/(prefix+'_'+name+'_export.json')).exists()]
 (ROOT/'reports'/(prefix+'_support_exports.json')).write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),outputs=manifest),indent=2),encoding='utf-8');print(json.dumps([{k:v for k,v in o.items() if k!='missing'} for o in outputs]));db.close()

if __name__=='__main__':main()
