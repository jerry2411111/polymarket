"""Read the official linked statistics tab and verify exposed public API nodes."""
import datetime as dt,json,sqlite3
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS
from probe_bundesliga_archives import BASE
from probe_eu_official_reports import brief
db=sqlite3.connect(DB);meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',('3b142708657b446a91eb34ab262435b5',)).fetchone()[0]);soup=BeautifulSoup((ROOT/meta['raw_file']).read_bytes(),'html.parser');links=[a['href'] for a in soup.find_all('a',href=True) if 'bayern-muenchen-vs-1-fc-union-berlin' in a['href'] and a['href'].endswith('/stats')];assert len(links)==1;c=HistoryClient();HOSTS.update({'www.bundesliga.com','bundesliga-web-prod.europe-west1.firebasedatabase.app'});url=urljoin(meta['endpoint'],links[0]);b,r,redirects=get(c,url);print('STATS PAGE',r['request_id']);page=BeautifulSoup(b,'html.parser');out=[]
for tag in page.find_all('script',type='application/json'):
 for key,v in json.loads(tag.get_text()).items():
  if key.startswith('_getDataFromFirebase-'):
   print('SSR NODE',key,json.dumps(brief(v),ensure_ascii=False)[:1700])
   if '/DFL-MAT-J03YGU/' in key and any(s in key.lower() for s in ['stats','statistics']):
    api=BASE+key.removeprefix('_getDataFromFirebase-')+'.json';raw,rr=c.get(api);assert raw==v;out.append(dict(page_request_id=r['request_id'],request_id=rr['request_id'],endpoint=api,summary=brief(raw)));print('EXACT API',rr['request_id'])
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),page_url=url,page_request_id=r['request_id'],sources=out,new_requests=c.requests);(ROOT/'reports/bundesliga_match_stats_probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8');db.close()
