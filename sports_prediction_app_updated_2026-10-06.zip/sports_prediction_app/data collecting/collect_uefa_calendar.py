"""Date-batched UEFA Champions League calendar, including qualification rounds."""
import argparse,calendar,collections,datetime as dt,json,math,sqlite3
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT,HOSTS
from probe_uefa_api import BASE
from uefa_regulation_scores import score

def normalize(m,rid,pointer):
 assert m['competition']['id']=='1' and m['competition']['code']=='UCL';assert m['status']=='FINISHED';ko=m['kickOffTime'];stamp=dt.datetime.fromisoformat(ko['dateTime']);assert stamp.tzinfo;offset=ko.get('utcOffsetInHours');assert isinstance(offset,(int,float)) and -12<=offset<=14;local=stamp.astimezone(dt.timezone(dt.timedelta(hours=offset)));assert local.date().isoformat()==ko['date'];sides={}
 for s in ['away','home']:
  t=m[s+'Team'];assert not t.get('isPlaceHolder') and t['typeTeam']=='DOMESTIC';sides[s]=dict(id=t['id'],name=t['translations']['displayOfficialName']['EN'],abbr=t['teamCode'],country_code=t['countryCode'])
 assert sides['away']['id']!=sides['home']['id'];sc=score(m);scores=sc['scores']
 if scores is not None:
  assert all(type(s)is int and s>=0 for s in scores);winner='Draw' if scores[0]==scores[1] else sides[['away','home'][scores[1]>scores[0]]]['name'];w=m.get('winner',{}).get('match',{})
  if w.get('reason')=='WIN_REGULAR':assert w['team']['id']==sides[['away','home'][scores[1]>scores[0]]]['id'] and scores[0]!=scores[1]
  elif w.get('reason')=='DRAW' and scores[0]!=scores[1]:sc['winner_field_discrepancy']=dict(raw_reason='DRAW',normalized_regulation=scores)
  # Extra time in a second leg follows a level aggregate, not necessarily a
  # drawn single game. Never infer the 90-minute score from tie progression.
 else:winner=None
 stadium=m.get('stadium') or {};city=stadium.get('city',{}).get('translations',{}).get('name',{}).get('EN');venue=stadium.get('translations',{}).get('officialName',{}).get('EN');year=int(m['seasonYear'])
 return dict(schema_version=3,official_match_id=m['id'],competition='UEFA Champions League',competition_id='1',season=f'{year-1}-{str(year)[-2:]}',season_year=year,date=ko['date'],scheduled_start_utc=stamp.astimezone(dt.UTC).isoformat(),source_utc_offset_hours=offset,away=sides['away'],home=sides['home'],winner=winner,status=m['status'],competition_phase=m['competitionPhase'],round_id=m['round']['id'],round_name=m['round']['metaData']['name'],round_type=m['round']['metaData']['type'],match_type=m['type'],location=', '.join(filter(None,[venue,city])),city=city,stadium_id=stadium.get('id'),completion_utc=m.get('fullTimeAt'),request_id=rid,pointer=pointer,raw=m,**sc)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100 and json.loads((ROOT/'reports/uefa_pilot_validation.json').read_text())['status']=='WORKING';HOSTS.add('match.uefa.com');c=HistoryClient();db=sqlite3.connect(DB,timeout=60)
 with db:db.execute('CREATE TABLE IF NOT EXISTS _official_uefa_calendar (match_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('CREATE TABLE IF NOT EXISTS _official_uefa_calendar_months (month TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
 with db:
  for mid,body in db.execute('SELECT match_id,body FROM _official_uefa_calendar').fetchall():
   g=json.loads(body)
   if g.get('schema_version',0)<3:db.execute('UPDATE _official_uefa_calendar SET body=? WHERE match_id=?',(json.dumps(normalize(g['raw'],g['request_id'],g['pointer'])),mid))
 day=dt.date(2024,1,1);end=dt.date(2026,9,15);n=0
 while day<end and n<math.ceil(33*a.through_percent/100):
  hi=min(day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1),end);month=day.strftime('%Y-%m');prior=db.execute('SELECT body FROM _official_uefa_calendar_months WHERE month=?',(month,)).fetchone()
  if prior and json.loads(prior[0])['complete']:n+=1;day=hi;continue
  year=day.year+int(day.month>=7);offset=0;seen=set();pages=[];games=[];statuses=collections.Counter()
  while True:
   params=dict(competitionId='1',seasonYear=year,fromDate=day.isoformat(),toDate=(hi-dt.timedelta(days=1)).isoformat(),order='ASC',limit=50,offset=offset);data,r=c.get(BASE+'/v5/matches',params);assert isinstance(data,list) and len(data)<=50;ids=[m['id'] for m in data];assert len(set(ids))==len(ids) and not seen&set(ids),'Pagination repeated match IDs';seen.update(ids);pages.append(dict(request_id=r['request_id'],parameters=params,rows=len(data)))
   for i,m in enumerate(data):
    assert m['competition']['id']=='1' and int(m['seasonYear'])==year and day.isoformat()<=m['kickOffTime']['date']<hi.isoformat();statuses[m['status']]+=1
    if m['status']=='FINISHED':games.append(normalize(m,r['request_id'],'/'+str(i)))
   if len(data)<50:break
   offset+=len(data);assert offset<1000
  part=dict(month=month,complete=True,completed_games=len(games),statuses=dict(statuses),pages=pages)
  with db:db.executemany('INSERT OR REPLACE INTO _official_uefa_calendar VALUES (?,?)',[(g['official_match_id'],json.dumps(g)) for g in games]);db.execute('INSERT OR REPLACE INTO _official_uefa_calendar_months VALUES (?,?)',(month,json.dumps(part)))
  n+=1;print('UEFA CALENDAR',month,len(games),'completed games;',n,'/33',flush=True);day=hi
 games=[json.loads(b) for b, in db.execute('SELECT body FROM _official_uefa_calendar')];parts=[json.loads(b) for b, in db.execute('SELECT body FROM _official_uefa_calendar_months ORDER BY month')];out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='ACQUIRED_REQUIRES_INDEPENDENT_VALIDATION',completed_months=len(parts),total_months=33,completed_games=len(games),by_season=dict(collections.Counter(g['season'] for g in games)),by_phase=dict(collections.Counter(g['competition_phase'] for g in games)),missing_regulation_score=sum(g['scores'] is None for g in games),earliest_date=min((g['date'] for g in games),default=None),latest_date=max((g['date'] for g in games),default=None),new_requests=c.requests,months=parts,scope='Calendar includes qualifying and tournament matches. Published odds require separate verified matching and quote acquisition.');(ROOT/'reports/uefa_calendar_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='months'}),flush=True);db.close()

if __name__=='__main__':main()
