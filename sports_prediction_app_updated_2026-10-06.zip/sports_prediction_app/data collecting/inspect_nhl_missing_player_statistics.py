import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB);missing=[json.loads(b) for b, in db.execute("SELECT body FROM _nhl_player_game_facts WHERE json_extract(body,'$.did_play')=1 AND json_extract(body,'$.score') IS NULL")];print('MISSING',len(missing),collections.Counter(p['position'] for p in missing))
for p in missing[:2]:
    g=json.loads(db.execute('SELECT body FROM _nhl_canonical_games WHERE id=?',(p['game_id'],)).fetchone()[0]);f=json.loads(db.execute('SELECT body FROM _official_nhl_game_reports WHERE official_game_id=?',(g['official_game_id'],)).fetchone()[0]);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(f['request_ids']['landing'],)).fetchone()[0]);d=json.loads((ROOT/r['raw_file']).read_bytes());print(json.dumps(dict(game=g['game_id'],player=p['player_name'],id=p['official_player_id'],scores=g['scores'],summary=d.get('summary',{}).get('scoring'),outcome=d.get('gameOutcome')),ensure_ascii=False)[:6500])
db.close()
