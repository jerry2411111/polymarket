"""Acquire the official NHL calendar in resumable monthly date partitions."""
import calendar,collections,datetime as dt,json,sqlite3
from zoneinfo import ZoneInfo
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT
from nhl_official import full_team_name

def main():
 assert json.loads((ROOT/'reports/nhl_public_api_validation.json').read_text())['status']=='WORKING'
 c=HistoryClient();db=sqlite3.connect(DB,timeout=60)
 db.execute('CREATE TABLE IF NOT EXISTS _official_nhl_schedule (official_game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('CREATE TABLE IF NOT EXISTS _nhl_schedule_dates (date TEXT PRIMARY KEY,request_id TEXT NOT NULL,game_count INTEGER NOT NULL) STRICT');db.commit()
 path=ROOT/'reports/nhl_schedule_months.json';old=json.loads(path.read_text()) if path.exists() else {};complete={p['month']:p for p in old.get('months',[]) if p['status']=='WORKING'};day=dt.date(2024,1,1);end=dt.date(2026,9,14);parts=[];milestone=10
 while day<=end:
  last=min(day.replace(day=calendar.monthrange(day.year,day.month)[1]),end);month=day.strftime('%Y-%m')
  if month in complete:parts.append(complete[month]);day=last+dt.timedelta(days=1);continue
  cursor=day;covered=set();ids=set();requests=[];errors=[]
  while cursor<=last:
   try:
    data,r=c.get('https://api-web.nhle.com/v1/schedule/'+cursor.isoformat());weeks=data['gameWeek'];requests.append(r['request_id'])
    assert isinstance(weeks,list) and weeks and weeks[0]['date']==cursor.isoformat()
    for wi,w in enumerate(weeks):
     wd=w['date']
     if not day.isoformat()<=wd<=last.isoformat():continue
     covered.add(wd);db.execute('INSERT OR REPLACE INTO _nhl_schedule_dates VALUES (?,?,?)',(wd,r['request_id'],len(w['games'])))
     for gi,g in enumerate(w['games']):
      if g.get('gameState') not in ['OFF','FINAL']:continue
      native=str(g['id']);teams=[full_team_name(g[s]) for s in ['awayTeam','homeTeam']];scores=[g[s].get('score') for s in ['awayTeam','homeTeam']];assert all(type(v) is int for v in scores) and scores[0]!=scores[1]
      start=dt.datetime.fromisoformat(g['startTimeUTC'].replace('Z','+00:00'));local=start.astimezone(ZoneInfo(g['venueTimezone'])).date().isoformat() if g.get('venueTimezone') else wd
      if not '2024-01-01'<=local<='2026-09-14':continue
      row=dict(official_game_id=native,season=str(g['season']),game_type_code=g['gameType'],official_date=wd,local_date=local,scheduled_start_utc=g['startTimeUTC'],teams=teams,official_team_ids=[str(g[s]['id']) for s in ['awayTeam','homeTeam']],team_codes=[g[s]['abbrev'] for s in ['awayTeam','homeTeam']],scores=scores,winner=teams[int(scores[1]>scores[0])],venue=g.get('venue'),neutral_site=g.get('neutralSite'),request_id=r['request_id'],pointer=f'/gameWeek/{wi}/games/{gi}',raw=g)
      db.execute('INSERT OR REPLACE INTO _official_nhl_schedule VALUES (?,?)',(native,json.dumps(row)));ids.add(native)
    db.commit();cursor+=dt.timedelta(days=7)
   except Exception as e:errors.append(dict(request_date=cursor.isoformat(),error=str(e)));break
  expected={(day+dt.timedelta(days=i)).isoformat() for i in range((last-day).days+1)};assert errors or covered==expected
  parts.append(dict(month=month,status='WORKING' if not errors else 'PARTIALLY WORKING',dates_checked=len(covered),expected_dates=len(expected),completed_games=len(ids),requests=requests,errors=errors));out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),total_months=33,completed_months=sum(p['status']=='WORKING' for p in parts),months=parts,new_requests=c.requests,scope='Official calendar discovery only. Games enter public research tables only after odds availability and identity validation.')
  path.write_text(json.dumps(out,indent=2),encoding='utf-8');print('NHL OFFICIAL CALENDAR',month,len(covered),'dates',len(ids),'completed games',len(errors),'errors',flush=True)
  while milestone<=100 and out['completed_months']*100>=milestone*33:print('NHL OFFICIAL CALENDAR',str(milestone)+'%',out['completed_months'],'/33 month partitions',flush=True);milestone+=10
  if errors:break
  day=last+dt.timedelta(days=1)
 print('NHL CALENDAR TOTAL',db.execute('SELECT count(*) FROM _official_nhl_schedule').fetchone()[0],'completed games',db.execute('SELECT count(*) FROM _nhl_schedule_dates').fetchone()[0],'dates',flush=True);db.close()

if __name__=='__main__':main()
