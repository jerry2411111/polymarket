"""Normalize verified official global biographies and dated club memberships."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources
from normalize_epl_people import valid_date
from probe_history import ROOT

def main():
 db=sqlite3.connect(DB,timeout=60);src=Sources(db);bios=[];memberships=[];issues=[];counts=collections.Counter()
 assert json.loads((ROOT/'reports/eu_opta_people_validation.json').read_text())['status']=='WORKING'
 for pid,b in db.execute('SELECT * FROM _official_eu_opta_people_sources'):
  r=json.loads(b)
  if not r.get('biography_identity_verified'):continue
  s=r['sources']['biography'];raw,meta=src.get(s['request_id']);assert raw==s['raw'];eligible=[(i,v) for i,v in enumerate(raw) if int(v['id']['seasonId'])<=2026];eligible.sort(key=lambda iv:(-int(iv[1]['id']['seasonId']),str(iv[1]['id']['competitionId'])!='8',str(iv[1]['id']['competitionId']),iv[0]))
  if not eligible:continue
  i,latest=eligible[0];out=dict(native_id=pid,source_person_ids=r['source_person_ids'],person_name=latest['name']['display'],aliases=sorted({v['name']['display'] for _,v in eligible}),birth_date=None,height_cm=None,weight_kg=None,biography_request_id=s['request_id'],sources={},completed_season_evidence=None)
  career=r['sources'].get('career') if r['status']=='ok' else None;person=None
  if career:
   craw,cm=src.get(career['request_id']);assert craw==career['raw'] and len(craw['person'])==1 and str(craw['person'][0]['opId'])==pid;person=craw['person'][0];out['completed_season_evidence']={}
  births={valid_date(v.get('dates',{}).get('birth')) for _,v in eligible}-{None};selected=valid_date(latest.get('dates',{}).get('birth'))
  if len(births)==1:out['birth_date']=next(iter(births))
  elif len(births)>1:
   latest_births={valid_date(v.get('dates',{}).get('birth')) for _,v in eligible if v['id']['seasonId']==latest['id']['seasonId']}-{None}
   if selected and latest_births=={selected} and person and valid_date(person.get('dateOfBirth'))==selected:out['birth_date']=selected;out['birth_date_resolution']=dict(raw_values=sorted(births),selected=selected,career_request_id=career['request_id'],career_pointer='/person/0/dateOfBirth');counts['birth_conflict_resolved_latest_and_career']+=1
   else:issues.append(dict(native_id=pid,field='birth_date',reason='Conflicting official values',values=sorted(births)))
  if out['birth_date']:
   idx=next(idx for idx,v in eligible if v.get('dates',{}).get('birth')==out['birth_date']);out['sources']['birth_date']=f'/{idx}/dates/birth'
  for field,key in [('height','height_cm'),('weight','weight_kg')]:
   candidates=[(idx,v) for idx,v in eligible if isinstance(v.get(field),(int,float)) and v[field]>0]
   if candidates:
    idx,v=candidates[0];values={x[field] for _,x in candidates if x['id']['seasonId']==v['id']['seasonId'] and x['id']['competitionId']==v['id']['competitionId']}
    if len(values)==1:out[key]=v[field];out['sources'][key]=f'/{idx}/{field}'
    else:issues.append(dict(native_id=pid,field=key,reason='Conflicting latest-season constants',values=sorted(values)))
  for idx,m in enumerate(person.get('membership',[]) if person else []):
   if m.get('contestantType')!='club' or m.get('role')!='player':continue
   start=valid_date(m.get('startDate','').removesuffix('Z'));end=valid_date((m.get('endDate') or '').removesuffix('Z'))
   if start and end and end<start:issues.append(dict(native_id=pid,field='membership',reason='End before start',membership_id=m['id']));continue
   name=m.get('contestantOptaOfficialName') or m.get('contestantName');assert name
   row=dict(source_person_ids=r['source_person_ids'],native_id=pid,official_team_id=str(m.get('opContestantId') or m['contestantId']),team_name=name,start_date=start,end_date=end,request_id=career['request_id'],pointer=f'/person/0/membership/{idx}',native_membership_id=m['id'],transfer_type=m.get('transferType'),raw_fields={k:v for k,v in m.items() if k!='stat'});memberships.append((pid,m['id'],json.dumps(row)));counts['dated_memberships']+=1
   for j,stat in enumerate(m.get('stat',[])):
    season=stat.get('tournamentCalendarName','')
    if stat.get('isFriendly')=='no' and len(season)==9 and season[4]=='/' and season[:4].isdigit() and season[5:].isdigit() and int(season[5:])==int(season[:4])+1 and stat.get('appearances',0)>0:out['completed_season_evidence'].setdefault(season,dict(available_date=season[5:]+'-07-01',request_id=career['request_id'],pointer=f'/person/0/membership/{idx}/stat/{j}'))
  bios.append((pid,json.dumps(out)))
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _eu_opta_biographies (native_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _eu_opta_biographies');db.executemany('INSERT INTO _eu_opta_biographies VALUES (?,?)',bios)
  db.execute('CREATE TABLE IF NOT EXISTS _eu_opta_memberships (native_id TEXT,membership_id TEXT,body TEXT NOT NULL,PRIMARY KEY(native_id,membership_id)) STRICT');db.execute('DELETE FROM _eu_opta_memberships');db.executemany('INSERT INTO _eu_opta_memberships VALUES (?,?,?)',memberships)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',coverage_status='PARTIALLY WORKING' if issues else 'WORKING',biographies=len(bios),memberships=len(memberships),counts=dict(counts),source_hashes=len(src.cache),missing={k:sum(json.loads(b)[k] is None for _,b in bios) for k in ['birth_date','height_cm','weight_kg']},issues=issues,limits='Official source memberships are incomplete career evidence. No career performance aggregates are imported. Latest physical constants are user-authorized.');(ROOT/'reports/eu_opta_people_normalization.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='issues'}));db.close()

if __name__=='__main__':main()
