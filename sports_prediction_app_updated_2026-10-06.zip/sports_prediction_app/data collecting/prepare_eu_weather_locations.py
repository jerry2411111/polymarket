"""Official venue-city bindings for candidate EU games; public filters remain downstream."""
import collections,datetime as dt,json,re,sqlite3
from build_history_catalog import DB
from eu_official_games import CONFIG,games,club_key
from eu_verified_details import details
from probe_history import ROOT

COUNTRIES={'ALB':'AL','AND':'AD','ARM':'AM','AUT':'AT','AZE':'AZ','BEL':'BE','BIH':'BA','BLR':'BY','BUL':'BG','CRO':'HR','CYP':'CY','CZE':'CZ','DEN':'DK','ENG':'GB','ESP':'ES','EST':'EE','FIN':'FI','FRA':'FR','FRO':'FO','GEO':'GE','GER':'DE','GIB':'GI','GRE':'GR','HUN':'HU','IRL':'IE','ISL':'IS','ISR':'IL','ITA':'IT','KAZ':'KZ','KOS':'XK','LIE':'LI','LTU':'LT','LUX':'LU','LVA':'LV','MDA':'MD','MKD':'MK','MLT':'MT','MNE':'ME','MON':'MC','NED':'NL','NIR':'GB','NOR':'NO','POL':'PL','POR':'PT','ROU':'RO','RUS':'RU','SCO':'GB','SMR':'SM','SRB':'RS','SUI':'CH','SVK':'SK','SVN':'SI','SWE':'SE','TUR':'TR','UKR':'UA','WAL':'GB'}

def main():
 COUNTRIES['MCO']='MC';db=sqlite3.connect(DB,timeout=60);stadia={};ds=details(db);locations=[];issues=[];counts=collections.Counter();reviews=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_stadium_location_reviews')] if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_stadium_location_reviews'").fetchone() else []
 for b, in db.execute('SELECT body FROM _official_uefa_calendar'):
  g=json.loads(b);s=g['raw']['stadium'];names={v for vs in s['translations'].values() for lang,v in vs.items() if lang in ['EN','DE','ES','FR','IT']};city=s['city']['translations']['name']['EN'];country=s['countryCode'];geo=s.get('geolocation',{});stadia[s['id']]=dict(stadium_id=s['id'],city=city,country=COUNTRIES.get(country),native_country=country,latitude=geo.get('latitude'),longitude=geo.get('longitude'),names=names,request_id=g['request_id'],pointer=g['pointer']+'/stadium')
 corrections={gid:json.loads(b) for gid,b in db.execute('SELECT * FROM _eu_game_location_corrections')} if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_game_location_corrections'").fetchone() else {}
 for code in CONFIG:
  wanted={json.loads(b)['official_match_id'] for b, in db.execute('SELECT body FROM _eu_validated_contracts WHERE competition=?',(code,))}
  for mid,g in games(db,code).items():
   if mid not in wanted or (code,mid) not in ds:continue
   row=json.loads(db.execute('SELECT body FROM _official_'+CONFIG[code][1]+'_game_reports WHERE match_id=?',(mid,)).fetchone()[0]);s=row['sources'];city=None;country={'LAL':'ES','BUN':'DE','SEA':'IT','FL1':'FR'}.get(code);venue=None;rid=None;path=None;geo={};proof=None;review=None
   if code=='UCL':
    v=s['match']['data']['stadium'];city=v['city']['translations']['name']['EN'];country=COUNTRIES.get(v['countryCode']);venue=v['translations']['name']['EN'];rid=s['match']['request_ids'][0];path='/stadium';geo=v.get('geolocation') or {};proof=stadia.get(v['id'])
   elif code=='SEA':v=s['header'];city=v['data'].get('cityName');venue=v['data'].get('stadiumName');rid=v['request_id'];path='/cityName'
   elif code=='FL1':v=s['match'];stadium=v['data'].get('stadium') or {};city=stadium.get('address',{}).get('city');venue=stadium.get('name');rid=v['request_id'];path='/stadium/address/city'
   elif code=='LAL':v=s['match_page'];venue=v['data']['match'].get('venue',{}).get('name');rid=v['request_id'];path='/props/pageProps/match/venue/name'
   else:v=s['match'];venue=v['data'].get('stadiumName');rid=v['request_id'];path=v['pointer']+'/stadiumName'
   matches=[st for st in stadia.values() if st['country']==country and venue and club_key(venue) in {club_key(n) for n in st['names']}]
   if proof is None and len(matches)==1:proof=matches[0]
   if proof:
    city=proof['city'];geo=dict(latitude=proof['latitude'],longitude=proof['longitude'])
   if not city:
    native=re.search(r'(DFL-STA-[A-Z0-9]+)_',s['match']['data'].get('stadiumIconUrlBlack','')) if code=='BUN' else None
    hits=[r for r in reviews if r['competition_code']==code and ((native and r.get('native_stadium_id')==native[1]) or venue in r['venue_names'])]
    if len(hits)==1:review=hits[0];city=review['city'];country=review['country'];geo=dict(latitude=review['latitude'],longitude=review['longitude'])
   correction=corrections.get(g['game_id'])
   if correction:
    assert correction['venue']==venue;city=correction['city'];country=correction['country'];review=correction
    if correction.get('uefa_stadium_proof'):geo=correction['uefa_stadium_proof']['raw'].get('geolocation') or {}
   if not city or not country:issues.append(dict(game_id=g['game_id'],competition=code,venue=venue,city=city,country=country,reason='Official report omits city or country, and no unique same-country official UEFA stadium-name match'));continue
   city=city.title() if city.isupper() else city
   # Reuse already reviewed English city names and international NBA venue
   # cities. Qualify other new locations to prevent cross-country collisions.
   weather_city=city if country=='GB' or city in ['Berlin','London','Paris'] else city+', '+country
   p={k:v for k,v in (proof or {}).items() if k!='names'};body=dict(game_id=g['game_id'],competition=code,raw_city=city,city=weather_city,country=country,latitude=geo.get('latitude'),longitude=geo.get('longitude'),venue=venue,request_id=rid,pointer=path,uefa_stadium_identity_proof=p or None,reviewed_stadium_city_source=review,city_derivation='Official game city, reviewed official stadium record, or unique same-country exact official stadium-name cross-reference; coordinates retained internally for station selection');locations.append((g['game_id'],json.dumps(body)));counts[code]+=1
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _eu_game_weather_locations (game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_game_weather_locations VALUES (?,?)',locations)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING' if issues else 'WORKING',candidate_games_mapped=len(locations),by_competition=dict(counts),city_years=len({(json.loads(b)['city'],gid.split('_')[1][:4]) for gid,b in locations}),coordinates_available=sum(json.loads(b)['latitude'] is not None for _,b in locations),issues=issues,scope='Candidate location audit only. Weather collection joins these locations only to games with published usable odds.');(ROOT/'reports/eu_weather_location_mapping.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='issues'}));print('UNMAPPED',len(issues),'VENUES',json.dumps(sorted({(e['competition'],e['venue']) for e in issues})));db.close()

if __name__=='__main__':main()
