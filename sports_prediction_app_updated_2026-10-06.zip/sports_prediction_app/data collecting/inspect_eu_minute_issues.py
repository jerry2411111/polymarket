import json,sqlite3
from build_history_catalog import DB
from eu_verified_details import details
from core import utc
db=sqlite3.connect(DB);ds=details(db)
for gid,b in db.execute('SELECT * FROM _eu_player_event_audit'):
 a=json.loads(b)
 if not any(i['field']=='minutes' for i in a['issues']):continue
 p=json.loads(db.execute('SELECT body FROM _eu_source_player_game_facts WHERE game_id=? LIMIT 1',(gid,)).fetchone()[0]);d=ds[a['competition'],p['official_match_id']];clock=d['clock'];lo=utc(clock['actual_start_utc']);hi=utc(clock['regulation_end_utc']);bad=[t for t in a['timeline'] if not t['timestamp'] or not lo<=utc(t['timestamp'])<=hi];print(gid,json.dumps(clock));print('OUTSIDE',json.dumps(bad[:3]));r=json.loads(db.execute('SELECT body FROM _official_laliga_game_reports WHERE match_id=?',(p['official_match_id'],)).fetchone()[0]);print('PERIODS',json.dumps(r['sources']['match_page']['data']['match']['period_started']))
db.close()
