"""Date-aware, source-linked MLB affiliation and injured-list observations.

Transactions may have a retroactive effective date. Their information is not
available to a feature until the published transaction date as well.
"""
import collections,datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from history_index import records,payload
from probe_history import ROOT

ACQUIRED={'SGN','SFA','TR','CLW','RTN','PUR','R5','R5M','ACQ','CP','OBT'}
EXIT={'REL','DFA','RET'}

def interpret(x,major):
    to=str(x.get('toTeam',{}).get('id',''));fr=str(x.get('fromTeam',{}).get('id',''))
    code=x.get('typeCode');description=x.get('description','').casefold()
    day=max(x['date'][:10],x.get('effectiveDate',x['date'])[:10])
    result=dict(known_date=day,source_publication_date=x['date'][:10],source_effective_date=x.get('effectiveDate',x['date'])[:10],team_id=None,affiliation_action=None,acquisition=False,active_roster=None,injury_action=None)
    if to in major:
        result.update(team_id=to,affiliation_action='depart' if code in EXIT else 'observe',acquisition=code in ACQUIRED)
        if code in EXIT or code=='DES':result['active_roster']=False
        elif code in {'CU','SE'}:result['active_roster']=True
        if ('injured list' in description or 'disabled list' in description):
            if 'activated ' in description and ' from ' in description:result['injury_action']='clear';result['active_roster']=True
            elif 'placed ' in description or 'transferred ' in description:result['injury_action']='injured';result['active_roster']=False
    elif fr in major:
        result.update(team_id=fr,affiliation_action='depart' if code in {'TR','CLW','RTN','R5','R5M','REL'} else 'observe')
        if code in {'OUT','OPT','ASG'}:result['active_roster']=False
    # All-Star/national/minor-league transactions cannot silently change the
    # current major-league club or its documented MLB injured-list status.
    return result

def main():
    db=sqlite3.connect(DB,timeout=60);source={r['request_id']:r for r in records(ROOT)}
    def verified_payload(r):
        raw=(ROOT/r['raw_file']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==r['sha256'],r['request_id']
        return json.loads(raw)
    names=collections.defaultdict(list)
    for b, in db.execute('SELECT body FROM _official_mlb_schedule'):
        g=json.loads(b)['raw_game']
        for side in ['away','home']:
            t=g['teams'][side]['team']
            if t.get('league',{}).get('id') in [103,104] and str(t['id']) not in ['159','160']:
                names[str(t['id'])].append((g['officialDate'],t['name']))
    major=set(names);assert len(major)==30,len(major)
    def team_name(tid,day):
        if not tid:return None
        choices=[(d,n) for d,n in names[tid] if d<=day]
        if choices:return max(choices)[1]
        # Stable identity for a pre-collection transaction; retain the actual
        # historical club name in the transaction description/source audit.
        return min(names[tid])[1]
    wanted={p['official_player_id'] for b, in db.execute('SELECT body FROM _official_mlb_feeds') for p in json.loads(b)['players']}
    versions=collections.defaultdict(list);raw_checks=0;hash_checks=0
    for pid,b in db.execute('SELECT * FROM _mlb_player_transaction_history'):
        h=json.loads(b)
        if h.get('status')!='ok' or pid not in wanted:continue
        r=source[h['request_id']];d=verified_payload(r);assert d['transactions']==h['records'];raw_checks+=len(h['records']);hash_checks+=1
        for n,x in enumerate(h['records']):
            key=(str(x['id']),pid,str(x.get('fromTeam',{}).get('id','')),str(x.get('toTeam',{}).get('id','')))
            versions[key].append((r['retrieved_at_utc'],x,r['request_id'],'/transactions/'+str(n)))
    daily_groups=collections.defaultdict(list)
    for b, in db.execute('SELECT body FROM _official_mlb_transactions'):
        v=json.loads(b);x=v['raw'];pid=str(x.get('person',{}).get('id',''))
        if pid in wanted:daily_groups[v['request_id']].append(v)
    for rid,vs in daily_groups.items():
        r=source[rid];d=verified_payload(r);hash_checks+=1
        for v in vs:
            x=v['raw'];pointer=v['pointer'];raw=d
            for k in pointer.strip('/').split('/'):raw=raw[int(k)] if isinstance(raw,list) else raw[k]
            assert x==raw;raw_checks+=1;pid=str(x['person']['id']);key=(str(x['id']),pid,str(x.get('fromTeam',{}).get('id','')),str(x.get('toTeam',{}).get('id','')))
            versions[key].append((r['retrieved_at_utc'],x,rid,pointer))
    events=[];changes=[]
    for key,vs in versions.items():
        _,x,rid,pointer=max(vs,key=lambda v:v[0]);p=interpret(x,major)
        if p['known_date']>'2026-09-14':continue
        different={json.dumps(v[1],sort_keys=True) for v in vs}
        if len(different)>1:changes.append(dict(transaction_key=key,request_ids=[v[2] for v in vs],reason='Official historical transaction versions differ; latest retrieved raw version retained'))
        if p['affiliation_action'] is None and p['injury_action'] is None:continue
        p.update(event_id=':'.join(key),player_id='MLB:'+key[1],official_player_id=key[1],player_name=x['person']['fullName'],team_name=team_name(p['team_id'],p['known_date']),type_code=x.get('typeCode'),description=x.get('description'),request_id=rid,pointer=pointer,raw=x)
        events.append(p)
    events.sort(key=lambda x:(x['known_date'],int(x['raw']['id']),x['event_id']))
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _mlb_temporal_events (event_id TEXT PRIMARY KEY,player_id TEXT NOT NULL,known_date TEXT NOT NULL,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _mlb_temporal_events');db.executemany('INSERT INTO _mlb_temporal_events VALUES (?,?,?,?)',[(x['event_id'],x['player_id'],x['known_date'],json.dumps(x)) for x in events]);db.execute('CREATE INDEX IF NOT EXISTS _mlb_temporal_person_dates ON _mlb_temporal_events(player_id,known_date)')
        db.execute('CREATE TABLE IF NOT EXISTS _mlb_transaction_version_changes (body TEXT NOT NULL)');db.execute('DELETE FROM _mlb_transaction_version_changes');db.executemany('INSERT INTO _mlb_transaction_version_changes VALUES (?)',[(json.dumps(x),) for x in changes])
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',source_value_checks=raw_checks,source_hash_checks=hash_checks,normalized_events=len(events),people=len({x['player_id'] for x in events}),retroactive_records=sum(x['source_effective_date']<x['source_publication_date'] for x in events),injury_observations=dict(collections.Counter(x['injury_action'] for x in events if x['injury_action'])),version_changes=len(changes),earliest=min(x['known_date'] for x in events),latest=max(x['known_date'] for x in events),rules=['known_date=max(publication date,effective date)','Official transaction archive, not proof that every career move or medical episode is covered','Minor-league and temporary All-Star/national teams do not replace major-league affiliation','Native franchise identity retained across Oakland/Athletics name change'])
    (ROOT/'reports/mlb_temporal_events_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));db.close()

if __name__=='__main__':main()
