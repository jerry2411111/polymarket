"""Apply the user's all-competitions-with-real-odds rule to built results."""
import collections,json,sqlite3
from build_history_catalog import DB
from build_history_odds import export
from probe_history import ROOT
from schema import PRE_COLUMNS,INGAME_COLUMNS

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    items=[json.loads(r[0]) for r in db.execute('SELECT body FROM _game_odds_eligibility')]
    for e in items:
        if e['usable_odds'] is False and (e['league']=='NBA' or e.get('is_training') is True):e.update(included=False,reason='No usable odds acquired yet')
    # Every exclusion retains its source audit and raw responses.
    for p in ['polymarket','kalshi']:
        excluded=[(e['game_id'],) for e in items if e['provider']==p and not e['included']]
        for kind in ['pre_match','in_game']:db.executemany(f'DELETE FROM _source_{p}_us_{kind} WHERE game_id=?',excluded)
    db.execute('DELETE FROM _game_odds_eligibility');db.executemany('INSERT INTO _game_odds_eligibility VALUES (?)',[(json.dumps(e),) for e in items]);db.commit()
    counts={}
    for p in ['polymarket','kalshi']:
        for kind,columns in [('pre_match',PRE_COLUMNS),('in_game',INGAME_COLUMNS)]:
            rows=[dict(r) for r in db.execute(f'SELECT * FROM _source_{p}_us_{kind} ORDER BY date,game_id' if kind=='pre_match' else f'SELECT * FROM _source_{p}_us_{kind} ORDER BY game_id')]
            export(p+'/'+kind,rows,columns,db=db);counts['_source_'+p+'_us_'+kind]=len(rows)
    report=dict(rule='All competitions, only games with usable acquired odds and verified official results',counts=counts,excluded_by_reason=dict(collections.Counter(e['reason'] for e in items if not e['included'])),coverage_status='PARTIAL: acquisition is ongoing; excluded games without acquired odds are not necessarily unavailable at the provider')
    (ROOT/'reports/game_eligibility.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));db.close()

if __name__=='__main__':main()
