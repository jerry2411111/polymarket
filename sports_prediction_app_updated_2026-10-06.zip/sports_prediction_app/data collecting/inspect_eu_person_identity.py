"""Inspect bounded native identity fields before cross-competition linking."""
import json,sqlite3
from build_history_catalog import DB

def main():
 db=sqlite3.connect(DB)
 for code,table in [('LAL','laliga'),('FL1','ligue1'),('UCL','uefa'),('SEA','seriea')]:
  r=json.loads(db.execute('SELECT body FROM _official_'+table+'_game_reports LIMIT 1').fetchone()[0]);s=r['sources']
  if code=='LAL':p=s['match_page']['data']['data']['lineups']['home']['starts'][0]['person']
  elif code=='FL1':p=next(iter(s['match']['data']['home']['players'].values()))['playerIdentity']
  elif code=='UCL':p=s['lineups']['data']['homeTeam']['field'][0]['player']
  else:p=s['lineups']['data']['home']['fielded'][0]
  print(code,json.dumps({k:v for k,v in p.items() if k not in ['photos','images','imagery','translations','skills','socialAccounts']},ensure_ascii=False)[:2400])
 row=json.loads(db.execute("SELECT body FROM _official_epl_people_sources WHERE person_key LIKE 'player:%' LIMIT 1").fetchone()[0]);p=row['sources']['biography']['raw'][0];print('EPL',json.dumps(p,ensure_ascii=False)[:3000]);db.close()

if __name__=='__main__':main()
