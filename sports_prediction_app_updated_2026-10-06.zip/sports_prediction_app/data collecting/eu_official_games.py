"""Consistent internal adapters for separately validated official EU calendars."""
import json,re,unicodedata
from probe_history import ROOT

CONFIG={
 'LAL':('LaLiga','laliga','KXLALIGAGAME'),
 'BUN':('Bundesliga','bundesliga','KXBUNDESLIGAGAME'),
 'SEA':('Serie A','seriea','KXSERIEAGAME'),
 'FL1':('Ligue 1','ligue1','KXLIGUE1GAME'),
 'UCL':('UEFA Champions League','uefa','KXUCLGAME')}

def club_key(s):
 s=str(s).translate(str.maketrans({'ø':'o','Ø':'O','ł':'l','Ł':'L','ß':'ss','æ':'ae','Æ':'AE'}));s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower().replace('.','');s=re.sub(r'\b(?:fc|cf|afc|sad|football club)\b','',s);return re.sub('[^a-z0-9]','',s)

def games(db,code):
 name,table,series=CONFIG[code];assert json.loads((ROOT/'reports'/(table+'_calendar_validation.json')).read_text())['status']=='WORKING';out={}
 for mid,b in db.execute('SELECT * FROM _official_'+table+'_calendar'):
  g=json.loads(b);sides={}
  for i,s in enumerate(['away','home']):
   t=g[s];aliases=[]
   if code=='BUN':sid=t['dflDatalibraryClubId'];full=t['nameFull'];abbr=t['threeLetterCode'];aliases=[t['nameShort']]
   elif code=='LAL':sid=str(t['id']);full=t['name'];abbr=t['shortname'];aliases=[t['nickname'],t['boundname'],t['slug'].replace('-',' ')]
   elif code=='FL1':
    parsed=re.fullmatch(r'l1_championship_club_\d{4}_(\d+)',t['id']);assert parsed;sid=parsed[1];assert 'shortId' not in t or str(t['shortId'])==sid;full=t['name'];abbr=t['trigram'];aliases=[t[k] for k in ['officialName','shortName','displayName','businessName'] if t.get(k)]
   elif code=='SEA':sid=t['id'];full=t['name'];abbr=t['abbr'];native=g['raw'][s];aliases=[native[k] for k in ['officialName','shortName'] if native.get(k)]
   else:
    sid=t['id'];full=t['name'];abbr=t['abbr'];native=g['raw'][s+'Team'];aliases=[native.get('internationalName')]+[v for k,vs in native['translations'].items() if k in ['displayName','displayOfficialName','shortName'] for lang,v in vs.items() if lang in ['EN','DE','ES','FR','IT','PT']]
   sides[s]=dict(id=str(sid),native_id=str(t.get('id',sid)),name=full,abbr=abbr,aliases=list(dict.fromkeys([full,abbr,*[v for v in aliases if v]])),score=g['scores'][i] if g.get('scores') is not None else None)
  # The later disciplinary award remains dated. Before historical performance
  # publication this match requires a temporal result revision, never a
  # retrospective replacement of the played result.
  out[mid]=dict(g,code=code,competition=name,series=series,home=sides['home'],away=sides['away'],game_id=code+'_'+g['date'].replace('-','')+'_'+sides['away']['abbr']+'_'+sides['home']['abbr'])
 if code!='UCL':
  country={'LAL':'ESP','BUN':'GER','SEA':'ITA','FL1':'FRA'}[code];uefa={}
  for b, in db.execute('SELECT body FROM _official_uefa_calendar'):
   ug=json.loads(b)
   for s in ['away','home']:
    t=ug['raw'][s+'Team']
    if t['countryCode']!=country:continue
    names=[t.get('internationalName')]+[v for k,vs in t['translations'].items() if k in ['displayName','displayOfficialName','shortName'] for lang,v in vs.items() if lang in ['EN','DE','ES','FR','IT','PT']];uefa[t['id']]=dict(names=names,full_name=t['translations']['displayOfficialName']['EN'],abbr=t['teamCode'],request_id=ug['request_id'],pointer=ug['pointer']+'/'+s+'Team')
  for g in out.values():
   for s in ['away','home']:
    t=g[s];keys={club_key(n) for n in t['aliases'] if len(club_key(n))>3};found=[(uid,u) for uid,u in uefa.items() if club_key(t['name'])==club_key(u['full_name']) or (club_key(t['abbr'])==club_key(u['abbr']) and keys&{club_key(n) for n in u['names'] if n and len(club_key(n))>3})]
    if len(found)==1:
     uid,u=found[0];t['aliases']=list(dict.fromkeys(t['aliases']+[n for n in u['names'] if n]+[u['abbr']]));t['uefa_identity_proof']=dict(team_id=uid,request_id=u['request_id'],pointer=u['pointer'],basis='Same national association, plus exact official full name or matching abbreviation and name');t['name']=u['full_name']
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_team_identity'").fetchone():
  clubmap={tid:json.loads(b) for tid,b in db.execute('SELECT official_team_id,body FROM _eu_team_identity WHERE competition_code=?',(code,))}
  for g in out.values():
   for s in ['away','home']:
    t=g[s];mapped=clubmap.get(t['id'])
    if mapped:t['aliases']=list(dict.fromkeys(t['aliases']+[mapped['team_name']]));t['name']=mapped['team_name'];t['canonical_team_id']=mapped['team_id']
 assert len({g['game_id'] for g in out.values()})==len(out),'Canonical collision; review same-day repeated games'
 return out
