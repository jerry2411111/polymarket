"""Parse dated head-coach service; preserve provenance.

These source candidates are not themselves proof of who coached a specific
game. Interim roles, Summer League and All-Star games need individual evidence.
"""
import datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT

def date_value(s):return dt.datetime.strptime(s,'%b %d, %Y').date().isoformat()

def main():
    db=sqlite3.connect(DB,timeout=60);sources=json.loads((ROOT/'reports/coach_page_acquisition.json').read_text());stints=[];issues=[]
    for s in sources:
        if s['status']!='ok':continue
        r=db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(s['request_id'],)).fetchone();assert r
        r=json.loads(r[0]);body=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(body).hexdigest()==r['sha256']
        soup=BeautifulSoup(body,'html.parser');name=soup.find('h1').get_text(' ',strip=True).title();slug=s['url'].rsplit('/',1)[-1]
        if slug=='jj-redick':name='JJ Redick'
        for n,tr in enumerate(soup.select('#gmhistory tbody tr')):
            cells=[c.get_text(' ',strip=True) for c in tr.find_all(['td','th'],recursive=False)]
            if len(cells)<3 or 'Head Coach' not in cells[1]:continue
            match=re.fullmatch(r'([A-Za-z]{3} \d{1,2}, \d{4})\s*-\s*(Present|[A-Za-z]{3} \d{1,2}, \d{4})',cells[2])
            if not match:issues.append(dict(coach=name,cells=cells,reason='Unparsed staff-history dates'));continue
            team={'LA Clippers':'Los Angeles Clippers'}.get(cells[0],cells[0])
            stints.append(dict(coach_id='NBA_COACH:'+slug,coach_or_manager_name=name,team_name=team,role=cells[1],effective_from=date_value(match[1]),effective_to=None if match[2]=='Present' else date_value(match[2]),source_url=s['url'],request_id=r['request_id'],pointer=f'#gmhistory tbody tr[{n}]',status='DATED_STAFF_SOURCE_CANDIDATE',note='Appointment dates and acting-game responsibility require official confirmation.'))
    for table,rows in [('_nba_coach_tenure_sources',stints)]:
        db.execute('CREATE TABLE IF NOT EXISTS '+table+' (body TEXT NOT NULL) STRICT');db.execute('DELETE FROM '+table);db.executemany('INSERT INTO '+table+' VALUES (?)',[(json.dumps(x),) for x in rows])
    db.commit();db.close()
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),coach_pages=len(sources),head_coach_stints=len(stints),issues=issues,status='SOURCE_CANDIDATES_PARSED_NOT_PUBLISHED')
    (ROOT/'reports/nba_coach_source_inventory.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))

if __name__=='__main__':main()
