import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
for b, in db.execute('SELECT body FROM _nba_ranking_sources'):
    s=json.loads(b)
    if s['status']!='ACQUIRED_NOT_VALIDATED':continue
    if s['publisher'] not in ['espn','cbs_sports','bleacher_report']:continue
    r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(s['request_id'],)).fetchone()[0]);html=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
    if s['publisher']=='espn':print('ESPN LINKS',[(a.get_text(' ',strip=True),a['href']) for a in html.find_all('a',href=True) if any(t in a.get_text(' ',strip=True) for t in ['100-51','50-11'])])
    if s['publisher']=='cbs_sports':print('CBS RANK ROW',str(html.select('table.ranked-players tr')[0])[:2400])
    if s['publisher']=='bleacher_report':print('BR HEADERS',[h.get_text(' ',strip=True) for h in html.select('h2') if any(ch.isdigit() for ch in h.get_text())][:105])
db.close()
