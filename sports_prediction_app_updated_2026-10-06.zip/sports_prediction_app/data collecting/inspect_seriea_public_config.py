"""Read only whitelisted public route/identity configuration from retained league HTML."""
import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT

def main():
 db=sqlite3.connect(DB);rid='059621d82b5d4be09902efd8fe55a54a';r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);raw=(ROOT/r['raw_file']).read_text(encoding='utf-8');parts=[raw]
 for script in BeautifulSoup(raw,'html.parser').find_all('script'):
  s=script.string or script.get_text()
  if s.startswith('self.__next_f.push('):
   try:x=json.loads(s[len('self.__next_f.push('):].rstrip(');'));parts.extend(v for v in x if isinstance(v,str))
   except (ValueError,TypeError):pass
 text='\n'.join(parts);keys=['SDP_PROJECT','SDP_SPORT','SDP_FOOTBALL_SEASON_ID_KEY','SDP_FOOTBALL_MATCH_ID_KEY','SDP_FOOTBALL_TEAM_ID_KEY','SDP_FOOTBALL_COMPETITION_ID_KEY','SDP_API_URL','SDP_API_BASE_URL','SDP_IMAGERY_BASE_URL'];out={k:sorted(set(re.findall(r'"'+k+r'"\s*:\s*"([^"\\]+)"',text))) for k in keys};out['native_season_ids']=sorted(set(re.findall(r'serie-a::Football_Season::[a-zA-Z0-9:_-]+',text)));out['native_competition_ids']=sorted(set(re.findall(r'serie-a::Football_Competition::[a-zA-Z0-9:_-]+',text)));print(json.dumps(dict(request_id=rid,public_config=out),ensure_ascii=False));db.close()

if __name__=='__main__':main()
