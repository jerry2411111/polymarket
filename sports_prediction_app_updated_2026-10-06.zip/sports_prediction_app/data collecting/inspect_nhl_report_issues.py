import json,sqlite3
from build_history_catalog import DB
from history_index import records
from collect_official_results import nhl_summary
from probe_history import ROOT
db=sqlite3.connect(DB);rs={r['request_id']:r for r in records()}
for n,b in db.execute('SELECT * FROM _official_nhl_game_reports'):
 f=json.loads(b)
 if not f['issues']:continue
 print('ISSUE',n,f['teams'],f['scores'],f['date'],f['issues'])
 for kind in ['GS','PL']:
  if kind not in f['request_ids']:continue
  r=rs[f['request_ids'][kind]];s=json.loads(db.execute('SELECT body FROM _official_nhl_schedule WHERE official_game_id=?',(n,)).fetchone()[0])
  try:print(kind,nhl_summary((ROOT/r['raw_file']).read_bytes(),s['season'],n[4:],r['request_id']))
  except Exception as e:print('PARSER ISSUE',kind,str(e))
db.close()
