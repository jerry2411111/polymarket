"""Official UEFA DOB fallback where match APIs omit identity fields.

Only ambiguous same-name, same-club cross-competition identities are targeted.
Current appearance totals are never imported from these biography pages.
"""
import collections,concurrent.futures,datetime as dt,json,re,sqlite3
from urllib.parse import quote
from bs4 import BeautifulSoup
from build_history_catalog import DB
from collect_laliga_people import namekey
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
def main():
 db=sqlite3.connect(DB,timeout=60);people={p:json.loads(b) for p,b in db.execute('SELECT * FROM _eu_people_registry')};aliases=collections.defaultdict(set);obs=collections.defaultdict(list)
 for pid,p in people.items():
  if p['kind']=='player':
   for n in p['aliases']:aliases[namekey(n)].add(pid)
 for b, in db.execute('SELECT body FROM _eu_player_game_facts'):
  p=json.loads(b);obs[p['player_id']].append((p['team_name'],dt.date.fromisoformat(p['game_date'])))
 targets={}
 for key,ids in aliases.items():
  if len(ids)<2:continue
  for pid in ids:
   p=people[pid]
   if not pid.startswith('EU_UCL:'):continue
   matches=[]
   for other in ids-{pid}:
    if people[other]['birth_date'] and any(t==tt and abs((d-dd).days)<=14 for t,d in obs[pid] for tt,dd in obs[other]):matches.append(other)
   if matches:targets[pid]=dict(person_id=pid,native_id=pid.split(':')[1],name=p['person_name'],aliases=p['aliases'],candidate_person_ids=matches,first_date=p['first_collected_date'])
 with db:db.execute('CREATE TABLE IF NOT EXISTS _official_uefa_identity_profiles (person_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
 done={p:json.loads(b) for p,b in db.execute('SELECT * FROM _official_uefa_identity_profiles')};c=HistoryClient();HOSTS.add('www.uefa.com');rows=[]
 def fetch(item):
  pid=item['person_id']
  if pid in done:return done[pid]
  url='https://www.uefa.com/uefachampionsleague/clubs/players/'+item['native_id']+'--'+quote(item['name'].lower().replace(' ','-'))+'/';out=dict(item,url=url)
  try:
   raw,r=c.get(url,document=True);s=BeautifulSoup(raw,'html.parser');text=s.get_text(' ',strip=True);hit=re.search(r'Date of birth\s*(\d{2}/\d{2}/\d{4})',text);assert hit,'DOB unavailable in official HTML';dob=dt.datetime.strptime(hit[1],'%d/%m/%Y').date().isoformat();heads=[h.get_text(' ',strip=True) for h in s.select('h1,h2')];assert any(namekey(n)==namekey(h) or h.startswith(n+' ') for n in item['aliases'] for h in heads),'Official profile name differs';out.update(status='ok',birth_date=dob,date_evidence=hit[0],request_id=r['request_id'],headings=heads,raw_file=r['raw_file'])
  except Exception as e:out.update(status='unavailable',error=str(e))
  return out
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  for n,row in enumerate(pool.map(fetch,sorted(targets.values(),key=lambda r:(r['first_date'],r['person_id']))),1):
   with db:db.execute('INSERT OR REPLACE INTO _official_uefa_identity_profiles VALUES (?,?)',(row['person_id'],json.dumps(row)))
   rows.append(row);print('UEFA IDENTITY BIOGRAPHY',n,'/',len(targets),row['person_id'],row['status'],flush=True)
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),targets=len(targets),new_requests=c.requests,counts=dict(collections.Counter(r['status'] for r in rows)),scope='Official native UEFA profile DOB, where lineup API biography is missing. Identity matching only; no current player statistics are imported.');(ROOT/'reports/eu_uefa_identity_profiles.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
if __name__=='__main__':main()
