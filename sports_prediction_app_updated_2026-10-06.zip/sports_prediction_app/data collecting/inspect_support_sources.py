"""Print bounded official-source schemas needed for support-table work."""
import json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT

db=sqlite3.connect(DB);db.row_factory=sqlite3.Row
for name in ['player_profiles','manager_profiles','game_player_profiles','_player_performance_periods','_official_nba_page_games','_manager_game_results']:
    print(name,[dict(r) for r in db.execute('PRAGMA table_info('+name+')')])
    r=db.execute('SELECT * FROM '+name+' LIMIT 1').fetchone() if db.execute('SELECT 1 FROM sqlite_master WHERE name=?',(name,)).fetchone() else None
    print('sample',dict(r) if r else None)
for r in db.execute("SELECT body FROM _official_nba_page_games LIMIT 1"):
    g=json.loads(r[0]);print('page fact',g)
    rid=g.get('request_id');audit=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/audit['raw_file']).read_bytes()
    node=BeautifulSoup(b,'html.parser').find('script',id='__NEXT_DATA__');j=json.loads(node.string)
    def walk(x,path=''):
        if isinstance(x,dict):
            for k,v in x.items():
                if 'coach' in k.lower():print('COACH',path+'/'+k,str(v)[:2500])
                else:walk(v,path+'/'+k)
        elif isinstance(x,list):
            for i,v in enumerate(x):walk(v,path+'/'+str(i))
    walk(j)
print('latest bios', [dict(r) for r in db.execute("SELECT * FROM _nba_player_bio_constants WHERE player_name IN ('Luka Dončić','Zach LaVine','Malik Monk')")])
print('fallbacks',[dict(r) for r in db.execute("SELECT DISTINCT game_id FROM _nba_player_game_facts WHERE json_extract(body,'$.roster_request_id') IS NULL AND json_extract(body,'$.pointer') IS NULL")])
db.close()
