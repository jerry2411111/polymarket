"""Only independently verified official game clocks and phase scores."""
import json
from probe_history import ROOT

def details(db):
 out={}
 for code,mid,b in db.execute('SELECT * FROM _eu_official_game_details'):
  d=json.loads(b);assert d['competition']==code and d['official_match_id']==mid;out[code,mid]=d
 uv=json.loads((ROOT/'reports/uefa_game_reports_validation.json').read_text());assert uv['status']=='WORKING'
 halves={mid:json.loads(b) for mid,b in db.execute('SELECT * FROM _uefa_verified_phase_scores')}
 for mid,b in db.execute('SELECT * FROM _official_uefa_game_reports'):
  r=json.loads(b)
  if r['status']!='ok' or mid not in halves:continue
  d=r['derived'];m=r['sources']['match']['data'];clock={k:d.get(k) for k in ['actual_start_utc','halftime_start_utc','second_half_start_utc','regulation_end_utc']};out['UCL',mid]=dict(competition='UCL',official_match_id=mid,clock=clock,clock_proofs=d.get('clock_proofs',{}),halftime_scores=halves[mid]['halftime_scores'],scores=halves[mid]['scores'])
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_game_location_corrections'").fetchone():
  for b, in db.execute('SELECT body FROM _eu_game_location_corrections'):
   c=json.loads(b);key=c['competition_code'],c['official_match_id']
   if key in out:out[key]['location']=c['location'];out[key]['location_correction']=c
 return out
