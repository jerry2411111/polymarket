"""Discover native soccer competition identifiers from documented provider APIs."""
import datetime as dt,json,re
from history_client import HistoryClient
from probe_history import ROOT

def main():
    client=HistoryClient();sports,sr=client.get('https://gamma-api.polymarket.com/sports');series,kr=client.get('https://external-api.kalshi.com/trade-api/v2/series',{'category':'Sports','include_product_metadata':'true'});cutoff,cr=client.get('https://external-api.kalshi.com/trade-api/v2/historical/cutoff',refresh=True)
    assert isinstance(sports,list) and isinstance(series['series'],list) and cutoff.get('market_settled_ts')
    # Selection is discovery only: individual rules and native official fixtures
    # must still validate competition, regulation duration and outcome mapping.
    pm=[s for s in sports if s.get('sport') in {'epl','lal','bun','sea','fl1','ucl'} or re.search(r'^(Premier League|La Liga|LaLiga|Bundesliga|Serie A|Ligue 1|UEFA Champions League)$',s.get('name',''),re.I)]
    ks=[s for s in series['series'] if re.search(r'Premier League|La Liga|Bundesliga|Serie A|Ligue 1|Champions League|\bEPL\b|\bUCL\b',s.get('title',''),re.I)]
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='DISCOVERY_ONLY',polymarket_request_id=sr['request_id'],kalshi_request_id=kr['request_id'],cutoff_request_id=cr['request_id'],historical_cutoff=cutoff,polymarket_competition_candidates=pm,kalshi_series_candidates=ks,requests=client.requests)
    (ROOT/'reports/eu_soccer_provider_metadata.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(dict(sports=pm,series=[{k:s.get(k) for k in ['ticker','title']} for s in ks if s.get('product_metadata',{}).get('scope')=='Game'],cutoff=cutoff,requests=client.requests)),flush=True)

if __name__=='__main__':main()
