"""Official dated head-coach rosters for game dates, t-1 and month anchors."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--max-new-months',type=int);a=ap.parse_args();db=sqlite3.connect(DB,timeout=60);games=[json.loads(b) for b, in db.execute('SELECT body FROM _mlb_canonical_games')];c=HistoryClient()
    b,pr=c.get('https://www.mlb.com/press-release/press-release-statement-from-the-orioles',document=True);text=BeautifulSoup(b,'html.parser').get_text(' ',strip=True).casefold();assert 'tony mansolino' in text and 'brandon hyde' in text and 'may 17' in text
    proof=json.loads((ROOT/'reports/mlb_person_coach_history_probe.json').read_text());tested={x['date']:x for x in proof['examples'] if x['kind']=='dated_coach_probe'}
    assert tested['2025-05-16']['managers'][0]['person']['id']==492493 and tested['2025-05-18']['managers'][0]['person']['id']==489081
    db.execute('CREATE TABLE IF NOT EXISTS _official_mlb_coach_observations (team_id TEXT NOT NULL,date TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(team_id,date)) STRICT');db.commit()
    wanted=set();teams={str(t) for g in games for t in g['team_ids'] if str(t) not in ['159','160']}
    for g in games:
        day=dt.date.fromisoformat(g['date'])
        for date in [day,day-dt.timedelta(days=1)]:
            if date>=dt.date(2024,1,1):wanted.update((str(t),date.isoformat()) for t in g['team_ids'])
    months=[];day=dt.date(2024,1,1);end=dt.date(2026,9,14)
    while day<=end:
        last=min(day.replace(day=calendar.monthrange(day.year,day.month)[1]),end);months.append(day.strftime('%Y-%m'))
        for date in [day.isoformat(),last.isoformat()]:wanted.update((t,date) for t in teams)
        day=last+dt.timedelta(days=1)
    groups=collections.defaultdict(list)
    for team,date in sorted(wanted,key=lambda x:(x[1],x[0])):groups[date[:7]].append((team,date))
    path=ROOT/'reports/mlb_coach_months.json';old=json.loads(path.read_text()) if path.exists() else {};done={x['month']:x for x in old.get('months',[]) if x['status']=='WORKING'};parts=[];processed=0
    def fetch(job):
        team,date=job
        try:
            d,r=c.get('https://statsapi.mlb.com/api/v1/teams/'+team+'/coaches',dict(date=date));assert str(d['teamId'])==team
            managers=[dict(x,pointer='/roster/'+str(n)) for n,x in enumerate(d['roster']) if x.get('jobId') in ['MNGR','NTRM']]
            return dict(team_id=team,date=date,status='ok',managers=managers,request_id=r['request_id'],source_url=r['endpoint'],note='Official head/interim manager roster on this date; not proof of the acting in-game replacement during a suspension or split-squad game'),None
        except Exception as e:return dict(team_id=team,date=date,status='error'),type(e).__name__+': '+str(e)
    for month in months:
        jobs=groups[month];signature=[t+':'+d for t,d in jobs]
        if month in done and done[month]['signature']==signature:parts.append(done[month]);continue
        if a.max_new_months and processed>=a.max_new_months:break
        errors=[];success=0;empty=0;multiple=0
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            for n,(row,error) in enumerate(pool.map(fetch,jobs),1):
                if error:errors.append(dict(**row,error=error));continue
                db.execute('INSERT OR REPLACE INTO _official_mlb_coach_observations VALUES (?,?,?)',(row['team_id'],row['date'],json.dumps(row)));db.commit();success+=1;empty+=not row['managers'];multiple+=len(row['managers'])>1
                if n%300==0:print('MLB COACH DATE CHECKS',month,n,'/',len(jobs),flush=True)
        parts.append(dict(month=month,status='WORKING' if not errors else 'PARTIALLY WORKING',signature=signature,jobs=len(jobs),successful=success,empty_head_coach_rosters=empty,multiple_head_coaches=multiple,errors=errors));processed+=1
        report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Official dated head-coach roster acquisition; stint boundaries and historical performance checked separately',total_months=33,total_team_date_checks=len(wanted),completed_months=sum(x['status']=='WORKING' for x in parts),months=parts,new_requests=c.requests,official_transition_validation_request_id=pr['request_id'])
        path.write_text(json.dumps(report,indent=2),encoding='utf-8');print('MLB COACH MONTH',month,'dates',success,'/',len(jobs),'empty',empty,'multiple',multiple,'errors',len(errors),'months',report['completed_months'],'/33',flush=True)
        if errors:break
    db.close()

if __name__=='__main__':main()
