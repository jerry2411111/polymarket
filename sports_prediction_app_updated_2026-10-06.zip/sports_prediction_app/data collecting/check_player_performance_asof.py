"""Check one date against independently accumulated collected player-game facts."""
import argparse
import collections
import datetime as dt
import json
import math
import sqlite3
import statistics

from build_history_catalog import DB
from probe_history import ROOT

FIELDS = ['games_played', 'overall_winrate', 'average_score_per_game',
    'std_score_per_game', 'average_assists_per_game', 'std_assists_per_game',
    'average_minutes_per_game', 'std_minutes_per_game', 'starter_percentage_overall',
    'score_z_score']

def same(a, b):
    return (a is None and b is None or a is not None and b is not None
            and math.isclose(a, b, rel_tol=1e-8, abs_tol=1e-8))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--date', required=True)
    day = dt.date.fromisoformat(parser.parse_args().date).isoformat()
    db = sqlite3.connect(DB.resolve().as_uri() + '?mode=ro', uri=True, timeout=60)
    db.row_factory = sqlite3.Row
    start, end = db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    assert start <= day <= end
    facts = collections.defaultdict(list)
    bounds = collections.defaultdict(list)
    for row in db.execute('SELECT * FROM _player_game_results WHERE game_date BETWEEN ? AND ?', (start, day)):
        facts[row['player_id'], row['league']].append(dict(row))
        bounds[row['league']].append(row['game_date'])
    expected = {}
    for key, games in facts.items():
        result = dict(games_played=len(games), overall_winrate=statistics.mean(g['win'] for g in games))
        for stat in ['score', 'assists', 'minutes']:
            values = [g[stat] for g in games if g[stat] is not None]
            result['average_' + stat + '_per_game'] = statistics.mean(values) if values else None
            result['std_' + stat + '_per_game'] = statistics.stdev(values) if len(values) > 1 else None
        starters = [g['starter'] for g in games if g['starter'] is not None]
        result['starter_percentage_overall'] = statistics.mean(starters) if starters else None
        expected[key] = result
    cohorts = {}
    for league in bounds:
        means = [v['average_score_per_game'] for (pid, lg), v in expected.items()
                 if lg == league and v['average_score_per_game'] is not None]
        cohorts[league] = (statistics.mean(means), statistics.pstdev(means)) if means else (None, None)
    for (pid, league), result in expected.items():
        mean, sd = cohorts[league]
        result['score_z_score'] = ((result['average_score_per_game'] - mean) / sd
            if sd and result['average_score_per_game'] is not None else None)
    print('Recomputed', sum(map(len, facts.values())), 'past player-game observations through', day, flush=True)
    failures = []; checks = 0; counts = collections.defaultdict(collections.Counter)
    for table in ['player_performance', 'player_profiles']:
        fields = FIELDS if table == 'player_performance' else [f for f in FIELDS if f != 'games_played']
        projection = ['player_id', 'player_name', 'league', 'as_of_date'] + fields
        if table == 'player_performance': projection.append('performance_status')
        seen = set()
        for row in db.execute('SELECT ' + ','.join(projection) + ' FROM ' + table + ' WHERE as_of_date=?', (day,)):
            key = row['player_id'], row['league']
            if key in seen: failures.append(dict(table=table, key=key, error='Duplicate player/league/date'))
            seen.add(key)
            want = expected.get(key, dict.fromkeys(FIELDS, 0))
            counts[row['league']][table + '_rows'] += 1
            if table == 'player_performance':
                counts[row['league']]['observed_players' if key in expected else 'no_observation_players'] += 1
                status = 'observed matches' if key in expected else 'insufficient matches'
                if row['performance_status'] != status:
                    failures.append(dict(table=table, key=key, field='performance_status'))
            for field in fields:
                checks += 1
                if not same(row[field], want[field]):
                    failures.append(dict(table=table, key=key, player_name=row['player_name'],
                        field=field, actual=row[field], expected=want[field]))
        if table == 'player_performance':
            for key in expected.keys() - seen:
                failures.append(dict(table=table, key=key, error='Observed player absent from output'))
    future = dict(db.execute('SELECT league,count(*) FROM _player_game_results WHERE game_date>? GROUP BY league', (day,)).fetchall())
    summary = []
    for league in sorted(counts):
        summary.append(dict(league=league, **counts[league],
            included_player_game_observations=len(bounds[league]),
            first_included_game=min(bounds[league]), last_included_game=max(bounds[league]),
            later_player_game_observations_excluded=future.get(league, 0)))
    report = dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(), query_date=day,
        collection_start=start, date_semantics='Inclusive local game-date cutoff; game prediction features use the preceding day.',
        scope='Performance arithmetic and date isolation against collected official-derived game facts; source acquisition was not repeated.',
        fields_checked=FIELDS, numeric_comparisons=checks, leagues=summary, failures=failures,
        status='PASS' if not failures else 'FAIL')
    stem = 'player_performance_asof_' + day.replace('-', '')
    (ROOT/'reports'/(stem+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# Player performance at '+day, '',
        'Uses collected completed games from '+start+' through '+day+', inclusive. Later games are excluded.', '',
        'Win rate, scoring/assist/playing-time means and sample standard deviations, starting percentage and scoring z-score were recomputed independently from the stored game observations. The same performance fields in dated player profiles were checked.', '',
        'Only players with no collected appearances receive zero performance and insufficient matches. Missing source statistics remain null after appearances exist.', '',
        '| League | Performance rows | With history | No observations | Included player-games | Later player-games excluded |',
        '|---|---:|---:|---:|---:|---:|']
    for r in summary:
        lines.append('| '+' | '.join(str(r[k]) for k in ['league','player_performance_rows','observed_players','no_observation_players','included_player_game_observations','later_player_game_observations_excluded'])+' |')
    lines += ['',f'Numeric comparisons: {checks:,}. Discrepancies: {len(failures):,}.', '',
        'Dates represent end-of-day cumulative history. For a game on '+day+', use the preceding date to avoid including that day\'s results.']
    (ROOT/'reports'/(stem+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf-8')
    db.close()
    print(json.dumps(report,ensure_ascii=False),flush=True)
    return bool(failures)

if __name__ == '__main__':
    raise SystemExit(main())
