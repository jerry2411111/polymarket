"""Dated official NHL biography transactions, never current-roster backfills."""
import collections,datetime as dt,json,re,sqlite3
from build_history_catalog import DB
from build_nhl_market_candidates import clean
from probe_history import ROOT

def franchise(name):
    value=clean(name)
    return 'utah_nhl' if value in ['utahhockeyclub','utahmammoth'] else value

def main():
    db=sqlite3.connect(DB,timeout=60);aliases=collections.defaultdict(set);names={};events=[];issues=[];season_facts=[]
    for b, in db.execute('SELECT body FROM _official_nhl_schedule'):
        g=json.loads(b)
        for side,key in enumerate(['awayTeam','homeTeam']):
            t=g['raw'][key];name=g['teams'][side];fid=franchise(name);names[fid]=name
            for label in [name,t.get('abbrev'),t.get('placeName',{}).get('default'),t.get('commonName',{}).get('default')]:
                if label:aliases[clean(label)].add(fid)
            if name.startswith('New York '):aliases[clean(name.replace('New York ','NY '))].add(fid)
    sources=[json.loads(b) for b, in db.execute('SELECT body FROM _official_nhl_career_sources') if json.loads(b)['status']=='ok']
    for source in sources:
        pid='NHL:'+source['official_player_id']
        for n,row in enumerate(source['season_totals']):
            if row.get('leagueAbbrev')!='NHL' or row.get('gameTypeId') not in [2,3] or not row.get('gamesPlayed'):continue
            name=row.get('teamName',{}).get('default')
            if not name:issues.append(dict(player_id=pid,reason='Official NHL career team name missing',request_id=source['request_id'],pointer='/seasonTotals/'+str(n)));continue
            year=int(str(row['season'])[4:]);known=f'{year}-07-01'
            season_facts.append(dict(player_id=pid,season=row['season'],sequence=row.get('sequence'),team_name=name,franchise_id=franchise(name),completed_season_available_date=known,request_id=source['request_id'],pointer='/seasonTotals/'+str(n),game_type_code=row['gameTypeId'],games_played=row['gamesPlayed']))
        for n,line in enumerate((source.get('notes_transactions') or '').splitlines()):
            text=line.strip().lstrip('*').strip()
            if not re.match(r'^(Traded|Signed|Claimed|Retired|Released)',text,re.I):continue
            dates=re.findall(r'([A-Z][a-z]+\s+\d{1,2},\s+\d{4})',text)
            if len(dates)!=1:issues.append(dict(player_id=pid,reason='Transaction lacks one explicit date',raw_value=text,request_id=source['notes_request_id']));continue
            try:day=dt.datetime.strptime(dates[0],'%B %d, %Y').date().isoformat()
            except ValueError:issues.append(dict(player_id=pid,reason='Unparsed transaction date',raw_value=text));continue
            target=None;kind=None
            for pattern,label in [(r'^Traded to (.+?)(?: by | with )','acquire'),(r'^Signed as a free agent by (.+?),','acquire'),(r'^Claimed (?:on|off) waivers by (.+?) from ','acquire'),(r'^Claimed by (.+?) from .*Expansion Draft','acquire')]:
                match=re.match(pattern,text,re.I)
                if match:target=match[1];kind=label;break
            if re.match(r'^(Retired|Released)',text,re.I):kind='depart'
            ids=aliases[clean(target)] if target else set()
            if kind is None or (kind=='acquire' and len(ids)!=1):issues.append(dict(player_id=pid,reason='Transaction action or NHL club identity needs review',raw_value=text,target=target,request_id=source['notes_request_id']));continue
            fid=next(iter(ids)) if ids else None;team=names.get(fid)
            if fid=='utah_nhl':team='Utah Hockey Club' if day<'2025-05-07' else 'Utah Mammoth'
            eid=source['official_player_id']+':'+day+':'+str(n)
            events.append(dict(event_id=eid,player_id=pid,event_date=day,known_date=day,kind=kind,team_name=team,franchise_id=fid,raw_value=text,source_line=n,request_id=source['notes_request_id'],pointer='/bio/notesTransactions/default',availability_basis='Explicit historical transaction date in official biography; retrospective source capture, not contemporaneous archival proof'))
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _nhl_temporal_events (event_id TEXT PRIMARY KEY,player_id TEXT,known_date TEXT,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nhl_temporal_events');db.executemany('INSERT INTO _nhl_temporal_events VALUES (?,?,?,?)',[(e['event_id'],e['player_id'],e['known_date'],json.dumps(e)) for e in events])
        db.execute('CREATE TABLE IF NOT EXISTS _nhl_career_season_facts (body TEXT NOT NULL)');db.execute('DELETE FROM _nhl_career_season_facts');db.executemany('INSERT INTO _nhl_career_season_facts VALUES (?)',[(json.dumps(s),) for s in season_facts])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),player_sources=len(sources),dated_transactions=len(events),career_season_team_rows=len(season_facts),issues=issues,meaning='Career rows can support biography/history after the season ends. They never enter collected-games performance. Current NHL roster is never historical evidence; ambiguous moves are not guessed.')
    (ROOT/'reports/nhl_temporal_events.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='issues'},ensure_ascii=False),'issues',len(issues));db.close()

if __name__=='__main__':main()
