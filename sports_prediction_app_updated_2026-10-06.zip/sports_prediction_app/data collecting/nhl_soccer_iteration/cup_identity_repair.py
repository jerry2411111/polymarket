"""Recover missing native person bridges using retained official biographies."""
import json,pickle
import pandas as pd
from common import ROOT_OUT,read_db,dump,stamp
import soccer_identity_repair as identity

RUN=ROOT_OUT/'soccer_cup_identity_v75'
PRIOR=ROOT_OUT/'soccer_cup_players_v74'


def prepare():
    RUN.mkdir(exist_ok=True)
    with (PRIOR/'feature_inputs.pkl').open('rb') as f:g,keys,main,cup,known=pickle.load(f)
    affected=pd.read_parquet(PRIOR/'affected_sides.parquet');missing=set()
    for r in affected.itertuples():
        history=main[main.game_id.isin(r.prior_pool_games)&main.team_key.eq(r.team_key)]
        for minutes in history.minutes:missing.update(pid for pid,value in minutes.items() if value>0 and pid not in known)
    with (ROOT_OUT/'soccer_identity_v55/full_sources.pkl').open('rb') as f:_,_,players,_,*_=pickle.load(f)
    cross=pd.read_parquet(ROOT_OUT/'soccer_identity_sources_v58/identity_crosswalk.parquet');mapping=dict(zip(cross.source_player_id,cross.canonical_player_id))
    def canonical(pid):
        seen=set()
        while pid in mapping:
            assert pid not in seen;seen.add(pid);pid=mapping[pid]
        return pid
    cols=['game_id','side','league','official_player_id','player_id','player_name','available_at_utc']
    players=players[cols].copy();players['player_id']=players.player_id.map(canonical)
    native=players[players.league.eq('UEFA Champions League')][['official_player_id','player_id']].drop_duplicates();assert not native.official_player_id.duplicated().any()
    bridge=dict(zip(native.official_player_id,native.player_id));extra=[];sources=[]
    with read_db(PRIOR/'match_statistics.sqlite') as db:
        for body, in db.execute('SELECT body FROM games'):
            record=json.loads(body);league=record['workload_exposure']['players'][0]['league']
            sources.append(record['source_links']['lineup']|dict(identity_league=league))
            for row in record['workload_exposure']['players']:
                extra.append({c:row.get(c) for c in cols}|dict(player_id=bridge.get(row['official_player_id'],canonical('EU_UCL:'+row['official_player_id']))))
    extra=pd.DataFrame(extra);extra['available_at_utc']=pd.to_datetime(extra.available_at_utc,utc=True,format='ISO8601')
    population=pd.concat([players,extra],ignore_index=True);assert not population.duplicated(['game_id','player_id']).any()
    population.to_parquet(RUN/'players.parquet',index=False)
    target=pd.concat([players[players.player_id.isin(missing)],extra])[['league','official_player_id','player_id']].drop_duplicates()
    dump(RUN/'plan.json',dict(at_utc=stamp(),hypothesis='Cup workload coverage changed across years because some domestic-native player IDs had no UEFA bridge. Reuse official full names and birth dates; no inferred identity from name alone.',
        missing_expected_players=len(missing),targets=len(target),source_policy='Retained raw official profiles and dated cup lineups; static identity only. No current club, age, contract, ranking or career performance imported.',
        baseline='Preserve v74 features and model results; repair in v75 before any new development test. Candidate choice remains2024/25;2026retrospective.',app_changed=False))
    identity.RUN=RUN;identity.SOURCE=RUN
    identity.catalog(target_rows=target,extra_uefa_sources=sources)
    identity.links()
    import validate_soccer_identity as verify
    verify.RUN=RUN;result=verify.check_identities(RUN/'players.parquet');print(json.dumps(result),flush=True)


if __name__=='__main__':prepare()
