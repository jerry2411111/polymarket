"""Verify incomplete NHL player exposure against current official API records.

Missing time on ice is never treated as a nonappearance. Positive goals,
assists or shots establish participation without inventing playing minutes.
The original historical table is preserved; this dated correction table is
explicitly applied by subsequent feature builders.
"""
import collections,concurrent.futures,json,sqlite3
from urllib.parse import urlencode
import pandas as pd
from common import OfficialClient,ROOT_OUT,PREVIOUS,PROJECT,read_db,dump,stamp,file_sha256

TABLE='nhl_player_exposure_repairs'


def collect():
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games={r['game_id']:dict(r) for r in db.execute("SELECT * FROM nhl_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30'")}
        people=collections.defaultdict(list)
        for r in db.execute('SELECT * FROM nhl_player_games WHERE minutes IS NULL'):
            if r['game_id'] in games:people[r['game_id']].append(dict(r))
    client=OfficialClient(per_second=3)
    config,documentation=client.get('https://api.nhle.com/stats/rest/en/config','Read current official NHL player report configuration','official_api_documentation')
    assert 'timeonice' in config['playerReportData']
    def fetch(gid):
        game=games[gid];native=str(game['official_game_id'])
        box,bs=client.get('https://api-web.nhle.com/v1/gamecenter/'+native+'/boxscore','Verify dated NHL player participation and omitted minutes: '+native,'official_player_time_on_ice')
        url='https://api.nhle.com/stats/rest/en/skater/timeonice?'+urlencode(dict(isAggregate='false',isGame='true',start=0,limit=100,cayenneExp='gameId='+native))
        detail,ds=client.get(url,'Recover official skater time on ice for incomplete preseason player rows: '+native,'official_player_time_on_ice')
        assert box and detail and str(box['id'])==native and box['gameDate']==game['date']
        assert box['gameState'] in ['OFF','FINAL']
        assert detail['total']==len(detail['data']) and detail['total']<=100
        times={str(r['playerId']):(i,r) for i,r in enumerate(detail['data'])}
        output=[]
        for old in people[gid]:
            team='awayTeam' if old['side']=='A' else 'homeTeam'
            assert str(box[team]['id'])==str(old['team_id'])
            assert box[team]['score']==game['score'+old['side']]
            matches=[(f'/playerByGameStats/{team}/{group}/{i}',r) for group,players in box['playerByGameStats'][team].items() if isinstance(players,list) for i,r in enumerate(players) if str(r.get('playerId'))==str(old['official_player_id'])]
            assert len(matches)==1,(gid,old['official_player_id'])
            pointer,raw=matches[0];positive=[field for field in ['goals','assists','sog'] if raw.get(field,0)>0]
            raw_toi=raw.get('toi');minutes=None;basis='Official boxscore omits TOI; statistics API has no player record'
            if raw_toi:
                m,s=map(int,raw_toi.split(':'));assert 0<=s<60 and m>=0
                if m*60+s>0:minutes=(m*60+s)/60;basis='Positive official boxscore TOI'
                else:basis='Official zero TOI is ambiguous for this previously incomplete preseason appearance'
            api_pointer=None
            if str(old['official_player_id']) in times:
                i,r=times[str(old['official_player_id'])];api_pointer='/data/'+str(i)
                assert str(r['gameId'])==native and r['gameDate']==game['date'] and r['teamAbbrev']==box[team]['abbrev']
                value=r.get('timeOnIce')
                if value is not None and value>0:
                    if minutes is not None:assert abs(minutes*60-value)<=1
                    minutes=value/60;basis='Positive official statistics API timeOnIce seconds'
            played=1 if minutes is not None or positive else None
            output.append(dict(game_id=gid,official_player_id=str(old['official_player_id']),side=old['side'],date=game['date'],
                available_at_utc=old['available_at_utc'],original_played=old['played'],played=played,minutes=minutes,
                participation_evidence=';'.join(positive) if positive else ('positive_toi' if minutes is not None else 'not_established'),
                raw_toi=raw_toi,minutes_status=basis,raw_goals=raw.get('goals'),raw_assists=raw.get('assists'),raw_shots=raw.get('sog'),
                boxscore_pointer=pointer,time_api_pointer=api_pointer,boxscore_source_json=json.dumps(bs),time_api_source_json=json.dumps(ds)))
        return output
    rows=[];total=len(people);next_pct=10
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for n,part in enumerate(pool.map(fetch,sorted(people)),1):
            rows.extend(part)
            if n*100>=next_pct*total or n==total:
                print(json.dumps(dict(stage='official_nhl_exposure_check',games=n,total=total,percent=round(100*n/total,1))),flush=True);next_pct+=10
    frame=pd.DataFrame(rows);assert not frame.duplicated(['game_id','side','official_player_id']).any()
    # Independently replay every retained value using hashed source responses.
    raw_cache={};replays=0
    for r in frame.to_dict('records'):
        source=json.loads(r['boxscore_source_json']);path=PROJECT/source['raw_file']
        if source['sha256'] not in raw_cache:
            assert file_sha256(path)==source['sha256'];raw_cache[source['sha256']]=json.loads(path.read_bytes())
        value=raw_cache[source['sha256']]
        for part in r['boxscore_pointer'].strip('/').split('/'):value=value[int(part)] if isinstance(value,list) else value[part]
        assert str(value['playerId'])==r['official_player_id']
        for field,key in [('raw_goals','goals'),('raw_assists','assists'),('raw_shots','sog')]:assert r[field]==value.get(key)
        if r['played']==1:assert any(value.get(k,0)>0 for k in ['goals','assists','sog']) or pd.notna(r['minutes'])
        replays+=1
    source='Official NHL gamecenter boxscore and NHL statistics timeonice API; exact source metadata and raw JSON pointers retained per row.'
    meanings={
      'game_id':('Canonical game identifier linking final NHL tables','identifier'),
      'official_player_id':('Native NHL player identifier','identifier'), 'side':('A away or B home, verified against official team ID','category'),
      'date':('Official game date','YYYY-MM-DD'),'available_at_utc':('Inherited conservative completed-game statistics availability for dated features','UTC timestamp'),
      'original_played':('Original stored participation flag, preserved for comparison','0/1/NULL'),
      'played':('Verified participation:1 when positive official playing time, goals, assists or shots establishes an appearance; NULL when not established','1/NULL'),
      'minutes':('Verified positive official playing time; NULL remains unknown, never inferred from team totals','minutes'),
      'participation_evidence':('Positive official fields supporting participation, or not_established','field names'),
      'raw_toi':('Unmodified official boxscore time-on-ice field','mm:ss or NULL'),
      'minutes_status':('Reason for recovered or unresolved playing time','text'),
      'raw_goals':('Official player goals','goals'),'raw_assists':('Official player assists','assists'),'raw_shots':('Official player shots on goal','shots'),
      'boxscore_pointer':('Exact raw JSON player path','JSON pointer'),'time_api_pointer':('Exact raw JSON statistics player path when present','JSON pointer'),
      'boxscore_source_json':('Official URL, request number, retrieval UTC, raw path and SHA256','JSON'),
      'time_api_source_json':('Official statistics URL, request number, retrieval UTC, raw path and SHA256','JSON')}
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        frame.to_sql(TABLE,db,if_exists='replace',index=False)
        for table in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+table+' WHERE "table"=?',(TABLE,))
        db.execute('INSERT INTO table_catalog VALUES (?,?,?)',(TABLE,len(frame),len(frame.columns)))
        for col in frame:
            meaning,unit=meanings[col]
            db.execute('INSERT INTO column_catalog VALUES (?,?,?,?,?)',(TABLE,col,meaning,unit,source))
            missing=int(frame[col].isna().sum());db.execute('INSERT INTO missing_report VALUES (?,?,?,?,?)',(TABLE,col,len(frame),missing,100*missing/len(frame)))
    frame.to_parquet(ROOT_OUT/(TABLE+'.parquet'),index=False);frame.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    audit=dict(status='PASS',at_utc=stamp(),documentation_urls=[documentation['url']],official_boxscore_replays=replays,raw_hashes_checked=len(raw_cache),
       games=total,rows=len(frame),participation_confirmed=int(frame.played.eq(1).sum()),false_nonappearance_flags_corrected=int((frame.original_played.eq(0)&frame.played.eq(1)).sum()),
       minutes_recovered=int(frame.minutes.notna().sum()),unknown_minutes=int(frame.minutes.isna().sum()),unknown_minutes_pct=100*frame.minutes.isna().mean(),
       unknown_participation=int(frame.played.isna().sum()),original_table_overwritten=False,
       limitation='These current official responses establish participation but do not prove original publication timestamps. Empty statistics responses and omitted TOI remain documented gaps; not a claim of universal source unavailability.')
    dump(ROOT_OUT/'retention/nhl_player_exposure_validation.json',audit);print(json.dumps(audit),flush=True)


def apply(players):
    """Apply verified corrections explicitly; preserve unknown rather than zero."""
    with read_db(ROOT_OUT/'granular.sqlite') as db:patch=pd.read_sql_query('SELECT game_id,side,official_player_id,played,minutes FROM '+TABLE,db)
    players=players.copy();players.official_player_id=players.official_player_id.astype(str)
    key=['game_id','side','official_player_id'];base=players.set_index(key);extra=patch.set_index(key)
    index=base.index.intersection(extra.index)
    for field in ['played','minutes']:
        base[field]=pd.to_numeric(base[field],errors='raise').astype(float)
        base.loc[index,field]=pd.to_numeric(extra.loc[index,field],errors='raise').astype(float)
    return base.reset_index()


def repair_regulation_scores():
    """Recover labels lost when a goals-only shutout had no opponent shot rows."""
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games=pd.read_sql_query("SELECT * FROM nhl_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30' AND phase IN ('Regular Season','Playoffs','Preseason')",db)
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        old=pd.read_sql_query('SELECT * FROM nhl_team_shot_quality',db)
        exists=db.execute("SELECT 1 FROM sqlite_master WHERE name='nhl_regulation_score_repairs'").fetchone()
        previous=pd.read_sql_query('SELECT * FROM nhl_regulation_score_repairs',db) if exists else pd.DataFrame()
    targets=old.pivot(index='game_id',columns='side',values='regulation_goals')
    missing=games[games.game_id.map(targets.A).isna()|games.game_id.map(targets.B).isna()]
    if missing.empty:return
    client=OfficialClient(per_second=3);rows=[]
    for g in missing.itertuples():
        d,s=client.get('https://api-web.nhle.com/v1/gamecenter/'+str(g.official_game_id)+'/landing','Recover missing regulation score labels from complete official scoring summary: '+str(g.official_game_id),'official_regulation_score')
        assert d and str(d['id'])==str(g.official_game_id) and d['gameDate']==g.date and d['gameState'] in ['OFF','FINAL']
        assert d['periodDescriptor']['periodType']=='REG' and d['periodDescriptor']['number']==3
        assert list(map(str,json.loads(g.native_team_ids_json)))==[str(d['awayTeam']['id']),str(d['homeTeam']['id'])]
        goals={'A':0,'B':0};events=set();periods=set()
        for period in d['summary']['scoring']:
            assert period['periodDescriptor']['periodType']=='REG'
            periods.add(period['periodDescriptor']['number'])
            for event in period['goals']:
                assert event['eventId'] not in events;events.add(event['eventId'])
                side='B' if event['isHome'] else 'A';goals[side]+=1
                assert event['teamAbbrev']['default']==d['homeTeam' if side=='B' else 'awayTeam']['abbrev']
                assert [goals['A'],goals['B']]==[event['awayScore'],event['homeScore']]
        assert periods=={1,2,3}
        assert goals['A']==g.scoreA==d['awayTeam']['score'] and goals['B']==g.scoreB==d['homeTeam']['score']
        assert file_sha256(PROJECT/s['raw_file'])==s['sha256']
        rows.append(dict(game_id=g.game_id,official_game_id=str(g.official_game_id),date=g.date,regulation_scoreA=goals['A'],regulation_scoreB=goals['B'],
            available_at_utc=g.available_time,source_json=json.dumps(s),source_pointer='/summary/scoring'))
    frame=pd.concat([previous,pd.DataFrame(rows)],ignore_index=True);assert not frame.game_id.duplicated().any()
    table='nhl_regulation_score_repairs'
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        frame.to_sql(table,db,if_exists='replace',index=False)
        for r in rows:
            for side in ['A','B']:
                if db.execute('SELECT 1 FROM nhl_team_shot_quality WHERE game_id=? AND side=?',(r['game_id'],side)).fetchone():
                    db.execute('UPDATE nhl_team_shot_quality SET regulation_goals=? WHERE game_id=? AND side=?',(r['regulation_score'+side],r['game_id'],side))
                else:db.execute('INSERT INTO nhl_team_shot_quality(game_id,side,regulation_goals) VALUES(?,?,?)',(r['game_id'],side,r['regulation_score'+side]))
        for cat in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+cat+' WHERE "table"=?',(table,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(table,len(frame),len(frame.columns)))
        for col in frame:
            unit='goals' if col.startswith('regulation_score') else ('UTC timestamp' if col=='available_at_utc' else ('JSON' if col=='source_json' else 'identifier/date/source pointer'))
            meaning={'regulation_scoreA':'Verified away-team regulation goals','regulation_scoreB':'Verified home-team regulation goals','source_json':'Official endpoint, request number, retrieval time, raw path and SHA256','available_at_utc':'Conservative completed-game statistics availability'}.get(col,col.replace('_',' '))
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(table,col,meaning,unit,'Complete official NHL landing scoring summary; all three periods, incremental score sequence and final scores verified.'))
            n=int(frame[col].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(table,col,len(frame),n,100*n/len(frame)))
        q=pd.read_sql_query('SELECT * FROM nhl_team_shot_quality',db)
        db.execute('UPDATE table_catalog SET rows=? WHERE "table"=?',(len(q),'nhl_team_shot_quality'))
        db.execute('DELETE FROM missing_report WHERE "table"=?',('nhl_team_shot_quality',))
        for col in q:
            n=int(q[col].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',('nhl_team_shot_quality',col,len(q),n,100*n/len(q)))
        db.execute('UPDATE column_catalog SET source=? WHERE "table"=? AND "column"=?',('Official NHL play-by-play; missing labels recovered from complete official scoring summaries with provenance in nhl_regulation_score_repairs.','nhl_team_shot_quality','regulation_goals'))
    for name,f in [(table,frame),('nhl_team_shot_quality',q)]:
        f.to_parquet(ROOT_OUT/(name+'.parquet'),index=False);f.to_csv(ROOT_OUT/(name+'.csv'),index=False)
    dump(ROOT_OUT/'retention/nhl_regulation_score_validation.json',dict(status='PASS',at_utc=stamp(),recovered_games=len(rows),all_periods_and_final_scores_match=True,unobserved_shot_statistics_left_null=True,examples=rows[:3]))
    print(json.dumps(dict(stage='regulation_score_recovery',games=len(rows),status='PASS')),flush=True)


if __name__=='__main__':
    collect();repair_regulation_scores()
