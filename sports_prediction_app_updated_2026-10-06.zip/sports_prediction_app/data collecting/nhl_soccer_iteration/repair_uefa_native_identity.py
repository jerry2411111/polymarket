"""Versioned source-preserving UEFA identity repair and independent checks."""
import copy,hashlib,json,sqlite3
from collections import Counter
import pandas as pd
from common import ROOT_OUT,PROJECT,read_db,dump,stamp
from uefa_native_identity import RUN,INPUTS,load_records,original


def main():
    evidence=json.loads((RUN/'identity_proofs.json').read_bytes());frames,records=load_records()
    proofs={(r['dataset'],r['game_id'],r['statistics_player_id']):r for r in evidence['proofs']}
    aliases={r['statistics_player_id']:r['lineup_player_id'] for r in evidence['proofs']}
    # Independently verify every alias against untouched profile and lineup bytes.
    for r in proofs.values():
        profile=original(r['profile_source'])[0];node=original(r['lineup_source'])
        for part in r['lineup_pointer'].strip('/').split('/'):node=node[int(part)] if isinstance(node,list) else node[part]
        assert str(profile['id'])==r['statistics_player_id'] and str(node['id'])==r['lineup_player_id']
        assert profile['birthDate']==node['birthDate']==r['birth_date'] and profile['gender']==node['gender']=='MALE'
        left={str(profile.get('internationalName','')).strip().casefold(),str(profile.get('translations',{}).get('name',{}).get('EN','')).strip().casefold()}-{''}
        right={str(node.get('internationalName','')).strip().casefold(),str(node.get('translations',{}).get('name',{}).get('EN','')).strip().casefold()}-{''}
        assert left&right
        assert not(profile.get('countryCode') and node.get('countryCode') and profile['countryCode']!=node['countryCode'])
        assert (profile.get('countryCode') and profile['countryCode']==node.get('countryCode')) or (profile.get('nationalTeamId') and profile['nationalTeamId']==node.get('nationalTeamId'))
        assert aliases[r['statistics_player_id']]==r['lineup_player_id']
    with read_db(ROOT_OUT/'nations_league.sqlite') as c:
        exposure={(r['game_id'],r['official_player_id']):dict(r) for r in c.execute('SELECT game_id,official_player_id,played,minutes,minutes_complete FROM nations_league_player_match_statistics')}
    scope=json.loads((ROOT_OUT/'nations_actions_v41/population_missing_summary.json').read_bytes())['full_match_vs_regulation_scope_rows']
    extra={(r['game_id'],r['player_id']) for r in scope if r['extra_time_substitution_verified']}
    report=[];participation_conflicts=[]
    for label,by_game in records.items():
        repaired=copy.deepcopy(by_game);changed=0
        for gid,g in repaired.items():
            for p in g['players']:
                pid=p['official_player_id'];proof=proofs.get((label,gid,pid))
                p['lineup_player_id']=pid if p['lineup_identity_verified'] else None
                p['canonical_player_id']=aliases.get(pid,pid)
                p['identity_evidence_json']=None
                if proof:
                    p.update(lineup_identity_verified=True,lineup_player_id=proof['lineup_player_id'],
                             player_name=proof['player_name'],position=proof['position'],lineup_group=proof['lineup_group'],
                             identity_evidence_json=json.dumps(proof,sort_keys=True));changed+=1
                    for issue in g['discrepancies']:
                        if issue.get('actor')=='player_identity' and issue.get('player_id')==pid:
                            issue['resolution']='Resolved by exact multi-attribute official profile and dated-lineup identity; original statistics ID preserved'
                            issue['lineup_player_id']=proof['lineup_player_id']
                if label=='nations':
                    x=exposure.get((gid,p['lineup_player_id']))
                    p['participation_eligible']=bool(p['lineup_identity_verified'] and ((x and x['played']) or (gid,pid) in extra))
                    sec=p['played_seconds_including_stoppage']
                    if p['lineup_identity_verified'] and (sec or 0)>0 and not p['participation_eligible']:
                        participation_conflicts.append(dict(game_id=gid,player_id=pid,player_name=p['player_name'],source_seconds=sec,
                             reason='Positive statistics duration not corroborated by completed substitution/starting records; original values retained, excluded from action features pending reconciliation'))
            eligible=[p['canonical_player_id'] for p in g['players'] if p['lineup_identity_verified']]
            assert len(eligible)==len(set(eligible)),gid
        f=pd.DataFrame([p for g in repaired.values() for p in g['players']]);old=frames[label]
        keys=['game_id','official_player_id'];a=f.set_index(keys).sort_index();b=old.set_index(keys).sort_index()
        mutable=['lineup_identity_verified','player_name','position','lineup_group']
        cols=[c for c in b if c not in mutable]
        pd.testing.assert_frame_equal(a[cols],b[cols],check_exact=True)
        assert len(f)==len(old) and f.lineup_identity_verified.sum()-old.lineup_identity_verified.sum()==changed
        with sqlite3.connect(RUN/(label+'_statistics.sqlite')) as c:
            c.execute('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT)')
            c.executemany('INSERT OR REPLACE INTO games VALUES (?,?)',[(gid,json.dumps(g,allow_nan=False)) for gid,g in repaired.items()])
        f.to_parquet(RUN/(label+'_players.parquet'),index=False)
        report.append(dict(dataset=label,rows=len(f),games=len(repaired),recovered_identity_rows=changed,
                  unresolved_lineup_rows=int((~f.lineup_identity_verified).sum()),unresolved_pct=float((~f.lineup_identity_verified).mean()*100),
                  raw_statistic_fields_unchanged=True,native_statistics_ids_unchanged=True))
    dump(RUN/'participation_conflicts.json',participation_conflicts)
    out=dict(status='PASS',at_utc=stamp(),profiles_sha256=hashlib.sha256((RUN/'identity_proofs.json').read_bytes()).hexdigest(),
         identity_proofs_independently_checked=len(proofs),datasets=report,participation_conflicts=len(participation_conflicts),
         source_scope='Only stable identity attributes link IDs; no current clubs or current statistics enter historical forecasts.')
    dump(RUN/'repair_validation.json',out);print(json.dumps(out),flush=True)


def repaired_records(label):
    assert json.loads((RUN/'repair_validation.json').read_bytes())['status']=='PASS'
    with read_db(RUN/(label+'_statistics.sqlite')) as c:return {gid:json.loads(b) for gid,b in c.execute('SELECT game_id,body FROM games')}


if __name__=='__main__':main()
