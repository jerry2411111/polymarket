"""Rebuild soccer histories with native-event repairs to historical end clocks.

Raw responses and frozen baseline matrices stay unchanged. Apply corrections
after merging all player feeds, so a later merge cannot reintroduce the bad clock.
"""
import argparse
import copy
import json
import pickle
import shutil
import sqlite3
import numpy as np
import pandas as pd
from common import ROOT_OUT,dump,stamp,file_sha256
from final_pipeline import cleanup,discard_work

TABLE='soccer_availability_corrections'
LABEL='soccer_clock_recovery'
RESULT=ROOT_OUT/'simulation_results/feature_revisions'/LABEL


def corrections():
    p=ROOT_OUT/'retention/soccer_match_phases_validation.json';proof=json.loads(p.read_bytes())
    assert proof['status']=='PASS'
    assert proof['output_sha256']==file_sha256(ROOT_OUT/'soccer_match_phase_observations.parquet')
    return pd.DataFrame([dict(game_id=r['game_id'],raw_available_time=r['raw_fullTimeAt'],
        corrected_available_time=r['normalized_end_time'],native_event_id=r['event_id'],
        native_event_type=r['event_type'],native_phase=r['phase'],reason=r['reason'],
        source_json=json.dumps(r['event_sources'],sort_keys=True)) for r in proof['clock_corrections']])


def apply(g,o,p,labels,fixes):
    g,o,p,labels=[x.copy() for x in [g,o,p,labels]];audit=[]
    for fix in fixes.itertuples():
        old=pd.Timestamp(fix.raw_available_time);new=pd.Timestamp(fix.corrected_available_time)
        for name,frame,field in [('games',g,'available_time'),('team_observations',o,'available_time'),
                                 ('players',p,'available_at_utc'),('labels',labels,'available_time')]:
            idx=frame.game_id.eq(fix.game_id)
            clock=pd.to_datetime(frame[field],utc=True,format='mixed')
            change=idx&clock.eq(old)
            frame[field]=clock
            frame.loc[change,field]=new
            audit.append(dict(game_id=fix.game_id,frame=name,field=field,changed=int(change.sum()),
                unchanged_same_game=int(idx.sum()-change.sum()),old=str(old),new=str(new)))
        current=g[g.game_id.eq(fix.game_id)].iloc[0]
        assert new>pd.Timestamp(current.start_time)
        assert labels[labels.game_id.eq(fix.game_id)].available_time.iloc[0]==new
        times=p.loc[p.game_id.eq(fix.game_id),'available_at_utc']
        # Genuine later report availability is retained. Only the identified
        # identical invalid clock is replaced; no arbitrary date truncation.
        ingestion=max([new]+times.dropna().tolist())
        assert ingestion<new+pd.Timedelta(days=2),'A different delayed source needs independent review'
        g.loc[g.game_id.eq(fix.game_id),'available_time']=ingestion
        o.loc[o.game_id.eq(fix.game_id),'available_time']=ingestion
    return g,o,p,labels,audit


def aliases(frame):
    f=frame.copy()
    for col in [c for c in f if c.startswith('f_context8_') and c.endswith('_diff')]:f[col.replace('f_context8_','f_ctx_')]=f[col]
    for field in ['quality_xg','quality_xg_against','finishing_residual','shots_on_target','big_chances',
                  'roster_goals_rate','roster_assists_rate','roster_key_passes_rate',
                  'roster_distance_covered_km_rate','roster_challenges_won_rate','roster_shots_at_goal_rate','roster_players']:
        f['f_ctx_'+field+'_diff']=f['f_'+field+'_diff']
    return f


def publish(f):
    meanings={
        'game_id':('Canonical game with a repaired historical availability clock','identifier'),
        'raw_available_time':('Incorrect original source fullTimeAt preserved verbatim','UTC timestamp'),
        'corrected_available_time':('Contemporaneous official terminal-phase event clock','UTC timestamp'),
        'native_event_id':('Official event providing the correction','identifier'),
        'native_event_type':('FULL_TIME or END_PHASE at the actual last playing phase','category'),
        'native_phase':('Actual final playing phase, respecting extra time','category'),
        'reason':('Documented reason the reported clock is rejected','text'),
        'source_json':('Native event response URLs, immutable raw paths, hashes and request references','JSON')}
    f.to_parquet(ROOT_OUT/(TABLE+'.parquet'),index=False);f.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        f.to_sql(TABLE,db,if_exists='replace',index=False)
        for name in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+name+' WHERE "table"=?',(TABLE,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(TABLE,len(f),len(f.columns)))
        for col in f:
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(TABLE,col,*meanings[col],'Official UEFA native match events; original raw clock retained. Repairs apply after player-source merging, not to immutable baseline artifacts.'))
            db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(TABLE,col,len(f),int(f[col].isna().sum()),100*f[col].isna().mean()))
    from publish import main
    main()


def build():
    import features
    import team_context_features as context
    import uefa_exposure_features as exposure
    import additional_soccer_features as additional
    work=ROOT_OUT/'_work'/LABEL
    assert not work.exists(),'Inspect unfinished reconstruction rather than restarting'
    work.mkdir(parents=True);RESULT.mkdir(exist_ok=True)
    fixes=corrections();publish(fixes)
    for module in [context,exposure,additional]:module.OUT=work
    dump(RESULT/'experiment_plan.json',dict(at_utc=stamp(),hypothesis='Repair two invalid source clocks that delayed2021/2023 observations until2026. Compare corrected histories with the same current source rebuild without that repair; immutable app and baseline matrices remain unchanged.',
        fields_unchanged='Same39pooled-scale model inputs; no new features or betting thresholds.',
        source_refresh='Rebuild the original context recipe: exposure and UEFA exposure enabled; other optional recoveries disabled. If current raw facts differ from the frozen matrix, quantify this as source refresh, separately from the clock repair.',
        timestamps='Patch only exact documented invalid clocks after all player merges. Genuine later availability remains unchanged.',
        reference='soccer_pooled_scale recipe',history_from='2021-01-01',forecasts_from='2024-01-01',
        gate='Inspect raw-history replay before fitting; data corrections require source evidence regardless of whether returns improve.',app_changed=False))
    g,o,p,keys,stats,metrics,evidence,labels=context.context_sources(include_exposure=True,include_uefa_exposure=True,apply_clock_corrections=False)
    print(json.dumps(dict(stage='clock_inputs_loaded',games=len(g),players=len(p))),flush=True)
    cg,co,cp,cl,audit=apply(g,o,p,labels,fixes)
    # Patching source clocks must not change game identities, scores or winners.
    for left,right in [(g,cg),(o,co),(p,cp),(labels,cl)]:
        remaining=[c for c in left if c not in ['available_time','available_at_utc']]
        pd.testing.assert_frame_equal(left[remaining],right[remaining],check_exact=True)
    again=apply(cg,co,cp,cl,fixes)
    for before,after in zip([cg,co,cp,cl],again[:4]):pd.testing.assert_frame_equal(before,after,check_exact=True)
    outputs={}
    for name,gg,oo,pp,ll in [('source_refresh',g,o,p,labels),('clock_repaired',cg,co,cp,cl)]:
        print(json.dumps(dict(stage='build_histories',variant=name)),flush=True)
        f,checks=features.build('soccer',gg,oo,pp,keys,stats,metrics)
        f['observation_available_time']=f.available_time;f['available_time']=f.game_id.map(ll.set_index('game_id').available_time)
        f=aliases(f);f.to_parquet(work/(name+'.parquet'),index=False);outputs[name]=f
    baseline=pd.read_parquet(ROOT_OUT/'retained_models/soccer/soccer_features.parquet').set_index('game_id')
    recipe=json.loads((ROOT_OUT/'simulation_results/feature_revisions/soccer_pooled_scale/experiment_plan.json').read_bytes())['recipe']
    import models
    cols=[c for c in models.columns(baseline,recipe) if not c.startswith('league_')]
    comparison=[]
    for name,f in outputs.items():
        aligned=f.set_index('game_id').loc[baseline.index]
        for c in cols:
            same=np.isclose(aligned[c],baseline[c],rtol=0,atol=1e-12,equal_nan=True)
            comparison.append(dict(variant=name,column=c,changed_rows=int((~same).sum()),rows=len(same)))
    pd.DataFrame(comparison).to_csv(RESULT/'feature_changes_vs_frozen.csv',index=False)
    earlier=outputs['source_refresh'].set_index('game_id');repaired=outputs['clock_repaired'].set_index('game_id').loc[earlier.index]
    changes=~np.isclose(earlier[cols],repaired[cols],rtol=0,atol=1e-12,equal_nan=True)
    detail=pd.DataFrame(dict(game_id=earlier.index,changed_features=changes.sum(axis=1),year=earlier.prediction_time.dt.year.to_numpy()))
    detail.to_csv(RESULT/'clock_affected_forecasts.csv',index=False)
    # The repair must leave forecasts before the first corrected match unchanged.
    before=earlier.prediction_time.lt(pd.to_datetime(fixes.corrected_available_time,utc=True).min())
    assert not changes[before.to_numpy()].any()
    dump(RESULT/'feature_validation.json',dict(status='PASS',at_utc=stamp(),clock_patch_audit=audit,
        rows=len(repaired),feature_columns=cols,clock_affected_games=int(changes.any(axis=1).sum()),
        pre_correction_rows_unchanged=int(before.sum()),idempotent_patch=True,source_values_unchanged=True,
        raw_sources_unchanged=True,feature_hashes={k:file_sha256(work/(k+'.parquet')) for k in outputs},
        current_job='Ready for controlled model comparison; work folder retained until evaluation completes.'))
    print(json.dumps(dict(stage='clock_history_rebuild_ready',rows=len(repaired),affected_games=int(changes.any(axis=1).sum()),
        source_refresh_changed_features=int(sum(x['changed_rows']>0 for x in comparison if x['variant']=='source_refresh')))),flush=True)


def run():
    import models
    import soccer_tie_context as comparison
    work=ROOT_OUT/'_work'/LABEL
    proof=json.loads((RESULT/'feature_validation.json').read_bytes())
    assert proof['status']=='PASS' and not (RESULT/'validation.json').exists()
    baseline=ROOT_OUT/'simulation_results/feature_revisions/soccer_pooled_scale'
    recipe=json.loads((baseline/'experiment_plan.json').read_bytes())['recipe']
    plan=json.loads((RESULT/'experiment_plan.json').read_bytes())
    plan.update(evaluation='Mechanical source correction: report all2024-2026rolling forecasts without choosing whether to correct data based on returns.2026retrospective; no model/hyperparameter tuning.',recipe=recipe)
    dump(RESULT/'experiment_plan.json',plan)
    name='clock_recovery_pooled';models.CANDIDATES[name]=copy.deepcopy(recipe)
    predictions=[];replayed=0;complete=False
    try:
        for variant in ['source_refresh','clock_repaired']:
            source=work/(variant+'.parquet');assert file_sha256(source)==proof['feature_hashes'][variant]
            fit_work=work/('fit_'+variant);fit_work.mkdir(exist_ok=True);models.OUT=fit_work
            shutil.copy2(source,fit_work/'soccer_features.parquet')
            frame=pd.read_parquet(source);features=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
            dump(fit_work/'soccer_selection.json',dict(selected_candidates=[name]))
            for stage in ['development','evaluation']:
                p=models.run('soccer',stage,[name]);p['variant']=variant
                assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
                package=pickle.loads((fit_work/'model_runs/soccer'/stage/(name+'.pkl')).read_bytes())
                last=p[p.fold.eq(package['boundary'].strftime('%Y-%m'))].head(20)
                x=features.loc[last.game_id,package['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
                actual=models.apply_calibration(package['model'].predict_proba(x),package['calibrator'])
                assert np.allclose(actual,last[['p0','p1','p2']],rtol=0,atol=1e-12)
                replayed+=len(last);predictions.append(p)
        original=pd.read_parquet(baseline/'development_predictions.parquet');original=original[original.variant.eq('candidate')].copy()
        original=pd.concat([original,pd.read_parquet(ROOT_OUT/'simulation_results/transferred_account_staking/soccer_evaluation_predictions.parquet')],ignore_index=True)
        original['variant']='frozen_reference';predictions.append(original)
        p=pd.concat(predictions,ignore_index=True)
        assert not p.duplicated(['game_id','variant']).any()
        p.to_parquet(RESULT/'predictions.parquet',index=False);models.metrics(p).to_csv(RESULT/'metrics.csv',index=False)
        decision=dict(at_utc=stamp(),data_correction_source_validated=True,model_parameters_unchanged=True,
            no_return_based_data_selection=True,app_changed=False,adopted=False,
            interpretation='Source-refresh comparison isolates other newly normalized facts; repaired versus source-refresh isolates only two end-clock corrections. No2026threshold selection.')
        dump(RESULT/'selection.json',decision)
        comparison.RESULT=RESULT;comparison.simulate(p[p.prediction_time.dt.year.lt(2026)],p[p.prediction_time.dt.year.eq(2026)])
        dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),feature_proof=proof,
            replayed_forecasts=replayed,each_variant_forecasts=p.groupby('variant').size().to_dict(),
            dated_training_verified=True,source_facts_unchanged_except_validated_clocks=True,
            retained_models_unchanged=True,app_changed=False,adopted=False))
        print(models.metrics(p).to_string(index=False),flush=True)
        complete=True
    except Exception as exc:
        path=ROOT_OUT/'simulation_results/failed_runs.json'
        failures=json.loads(path.read_bytes()) if path.exists() else []
        failures.append(dict(at_utc=stamp(),experiment=LABEL,error=repr(exc),
            unfinished_work_preserved=True))
        dump(path,failures)
        raise
    finally:
        if complete and work.exists():discard_work(work)
        cleanup()


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--train',action='store_true');args=parser.parse_args()
    run() if args.train else build()
