"""Audit actual retained-model transforms on earlier-only development folds.

No new model or betting rule is selected. Inspect fitted transform values,
including imputation indicators; a rare binary indicator is not a source error.
"""
import json
import numpy as np
import pandas as pd

import models
from common import ROOT_OUT,dump,stamp,file_sha256


def main():
    folder=ROOT_OUT/'simulation_results/preprocessing_diagnosis';folder.mkdir(exist_ok=True)
    rows=[];sources={}
    for sport,name in [('soccer','context_league'),('nhl','granular_logistic_strong')]:
        source=ROOT_OUT/f'retained_models/{sport}/{sport}_features.parquet'
        data=pd.read_parquet(source);sources[sport]=file_sha256(source)
        data=pd.concat([data,pd.get_dummies(data.league,prefix='league',dtype=float)],axis=1)
        spec=models.CANDIDATES[name];cols=models.columns(data,spec)
        forecasts=pd.read_parquet(ROOT_OUT/f'retained_models/{sport}/development_predictions.parquet')
        forecasts=forecasts[forecasts.variant.eq(name)]
        for fold,group in forecasts.groupby('fold'):
            boundary=pd.Timestamp(fold+'-01',tz='UTC');prior=data[data.available_time.lt(boundary)]
            current=data.set_index('game_id').loc[group.game_id]
            assert prior.available_time.max()<current.prediction_time.min()
            calibration=prior[prior.prediction_time.ge(boundary-pd.Timedelta(days=180))]
            training=prior[prior.available_time.lt(calibration.prediction_time.min())]
            for stage,train,test in [('forecast',prior,current),('calibration',training,calibration)]:
                pipeline=models.make_model(spec,sport)[:-1]
                pipeline.fit(train[cols].astype(float))
                out=np.asarray(pipeline.transform(test[cols].astype(float)))
                imputer=pipeline[-2];names=list(imputer.get_feature_names_out(cols))
                assert len(names)==out.shape[1] and np.isfinite(out).all()
                for i,field in enumerate(names):
                    native=field.removeprefix('missingindicator_')
                    cardinality=train[native].nunique()
                    kind='missing_indicator' if field.startswith('missingindicator_') else ('low_cardinality' if cardinality<=3 else 'continuous')
                    j=int(np.abs(out[:,i]).argmax())
                    rows.append(dict(sport=sport,model=name,fold=fold,stage=stage,field=field,kind=kind,
                        train_rows=len(train),observed_train_rows=int(train[native].notna().sum()),train_distinct=int(cardinality),
                        test_rows=len(test),max_abs_transformed=float(abs(out[j,i])),
                        rows_above10=int((abs(out[:,i])>10).sum()),largest_game_id=str(test.game_id.iloc[j] if 'game_id' in test else test.index[j])))
    result=pd.DataFrame(rows);result.to_csv(folder/'feature_transforms.csv',index=False)
    summaries=[]
    for (sport,kind),group in result.groupby(['sport','kind']):
        biggest=group.loc[group.max_abs_transformed.idxmax()]
        summaries.append(dict(sport=sport,kind=kind,max_abs_transformed=float(biggest.max_abs_transformed),
            field=biggest.field,fold=biggest.fold,stage=biggest.stage,rows_above10=int(group.rows_above10.sum())))
    report=dict(at_utc=stamp(),status='PASS',source_hashes=sources,fold_feature_checks=len(result),
        years=[2024,2025],no_2026_selection=True,summaries=summaries,
        interpretation='Extreme transformed values identify extrapolation or rare indicator scaling, not automatically bad source data. Threshold10 describes this audit; no filter or betting rule is adopted.')
    dump(folder/'validation.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
