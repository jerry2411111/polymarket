"""Official series discovery; record actual archive boundary before routing."""
import json
import re
from urllib.parse import urlencode

from common import OfficialClient, ROOT_OUT, dump, stamp

BASE = 'https://external-api.kalshi.com/trade-api/v2'
DOCS = [
    'https://docs.kalshi.com/api-reference/market/get-series-list',
    'https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps',
    'https://docs.kalshi.com/api-reference/historical/get-historical-markets',
    'https://docs.kalshi.com/api-reference/market/get-markets',
]


def main():
    client = OfficialClient(per_second=2)
    client.HOSTS.add('external-api.kalshi.com')
    cutoff, cutoff_source = client.get(BASE+'/historical/cutoff',
        'Record current archive cutoff for Nations League discovery', 'kalshi_historical_cutoff', refresh=True)
    assert isinstance(cutoff, dict) and cutoff.get('market_settled_ts')
    result, series_source = client.get(BASE+'/series?'+urlencode(dict(category='Sports', include_product_metadata='true')),
        'Find official UEFA Nations League series without guessed tickers', 'kalshi_series_discovery')
    assert isinstance(result.get('series'), list)
    candidates = []
    for index, row in enumerate(result['series']):
        text = json.dumps({k:row.get(k) for k in ['ticker','title','tags']})
        if re.search(r'nations|\bUNL\b', text, re.I):
            candidates.append(dict(series=row, pointer='/series/'+str(index)))
    report = dict(at_utc=stamp(), documentation_urls=DOCS, cutoff=cutoff,
        cutoff_source=cutoff_source, series_source=series_source,
        series_count=len(result['series']), candidates=candidates,
        scope='Sports-category series discovery only. Candidate titles and rules require competition verification before joining UEFA games.')
    dump(ROOT_OUT/'nations_kalshi_discovery.json', report)
    print(json.dumps(dict(cutoff=cutoff, series_count=report['series_count'],
        candidates=[{k:r['series'].get(k) for k in ['ticker','title','tags','settlement_sources']} for r in candidates])), flush=True)


if __name__ == '__main__':
    main()
