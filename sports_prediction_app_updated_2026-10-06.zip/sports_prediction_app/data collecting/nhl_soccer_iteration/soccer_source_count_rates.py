"""Use already-proved sparse official zeros in the current soccer model inputs.

Raw missing values remain unchanged. Complete participant/team-count proofs
establish individual normalized zeros; no blanket missing-value fill is used.
"""
import argparse
import collections
import copy
import json
import pickle
import numpy as np
import pandas as pd
from common import ROOT_OUT,PROJECT,REPORTS,read_db,dump,stamp,file_sha256
import soccer_squad_model as squad

LABEL='soccer_source_count_rates'
WORK=ROOT_OUT/'_work'/LABEL
RESULT=ROOT_OUT/'simulation_results'/LABEL
REFERENCE=squad.REFERENCE
FIELDS=['goals','assists','key_passes']


def derive(g,p,keys):
    lookup=collections.defaultdict(list)
    for pl in p[['game_id','side','player_id','minutes','available_at_utc']+FIELDS].to_dict('records'):
        lookup[pl['game_id'],pl['side']].append(pl)
    hist=collections.defaultdict(lambda:collections.deque(maxlen=5))
    phist=collections.defaultdict(lambda:collections.deque(maxlen=30));last_team={}
    events=g.sort_values(['available_time','game_id']).to_dict('records');pos=0
    rows=[];audit=[]
    for game in g.sort_values(['prediction_time','game_id']).itertuples():
        while pos<len(events) and events[pos]['available_time']<game.prediction_time:
            old=events[pos];pos+=1
            for side in ['A','B']:
                team=keys[old['game_id'],side];observed=[]
                for pl in lookup[old['game_id'],side]:
                    if pl['minutes'] is None or not np.isfinite(pl['minutes']) or pl['minutes']<=0:continue
                    assert pd.Timestamp(pl['available_at_utc'])<=old['available_time']
                    pid=pl['player_id'];phist[pid].append(pl);last_team[pid]=team;observed.append((pid,pl['minutes']))
                hist[team].append(observed)
        values={};row=dict(game_id=game.game_id)
        for side in ['A','B']:
            weights=collections.defaultdict(float);team=keys[game.game_id,side]
            for old in hist[team]:
                for pid,minutes in old:
                    if last_team.get(pid)==team:weights[pid]+=minutes
            for field in FIELDS:
                rates=[];clocks=[]
                for pid,weight in sorted(weights.items()):
                    obs=[z for z in phist[pid] if z[field] is not None and np.isfinite(z[field])]
                    if obs:
                        rates.append((weight,90*sum(z[field] for z in obs)/sum(z['minutes'] for z in obs)))
                        clocks.extend(pd.Timestamp(z['available_at_utc']) for z in obs)
                value=sum(w*v for w,v in rates)/sum(w for w,v in rates) if rates else np.nan
                assert not clocks or max(clocks)<game.prediction_time
                values[side,field]=value
                audit.append(dict(game_id=game.game_id,side=side,field=field,rate_per90=value,
                    total_roster_minutes=sum(weights.values()),covered_roster_minutes=sum(w for w,v in rates),
                    latest_source_utc=max(clocks) if clocks else None,cutoff_utc=game.prediction_time))
        for field in FIELDS:row['f_ctx_roster_'+field+'_rate_diff']=values['B',field]-values['A',field]
        rows.append(row)
    return pd.DataFrame(rows).set_index('game_id'),pd.DataFrame(audit)


def build():
    import loss_case_revision as case
    from soccer_club_strength import coefficients
    from pl_sparse_statistics import merge_proved_zeros,RUN
    WORK.mkdir(exist_ok=True);RESULT.mkdir(exist_ok=True)
    assert not (RESULT/'validation.json').exists()
    recipe=copy.deepcopy(json.loads((REFERENCE/'experiment_plan.json').read_bytes())['recipe'])
    dump(RESULT/'experiment_plan.json',dict(at_utc=stamp(),recipe=recipe,
        diagnosis='Some sparse goals/assists/key-pass records omit zero-valued appearances. Measured-only denominators can condition a rate on nonzero outcomes. The current model branch does not consume the independently reconciled zeros.',
        correction='Merge only existing validated complete-participant/team-total zero proofs by exact game, side and native player ID. Raw nulls remain unchanged. No result-dependent imputation or blanket zero fill.',
        changed_inputs=['f_ctx_roster_'+f+'_rate_diff' for f in FIELDS],
        source_proof_sha256=file_sha256(RUN/'pl_zero_proofs.parquet'),source_validation=json.loads((RUN/'pl_zero_validation.json').read_bytes()),
        unchanged='41-input club-strength recipe, existing physical-stat coverage adjustment, contribution weights, monthly expanding2021+ training, purged calibration, pre12 and cash policy.',
        gate='Lower rolling2024/25 logloss AND Brier on identical forecasts permits2026evaluation. Correct source facts remain valid whether or not the fitted model improves.',
        interpretation='2026 is repeatedly inspected retrospective rolling research, not an untouched holdout.',app_changed=False))
    reusable=ROOT_OUT/'_work/soccer_role_replacement'
    source=reusable if (reusable/'sources_ready.json').exists() else WORK
    case.WORK=source;case.RESULT=RESULT
    if not (source/'sources_ready.json').exists():case.sources()
    g,_,p,_,keys,_=case.load_sources()
    if (source/'control/soccer_features.parquet').exists():
        frame=pd.read_parquet(source/'control/soccer_features.parquet').set_index('game_id')
    else:
        if not (source/'features_ready.json').exists():case.build()
        frame=pd.read_parquet(source/'candidate/soccer_features.parquet').set_index('game_id')
        ranking=pd.read_parquet(ROOT_OUT/'soccer_uefa_club_coefficients.parquet')
        with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
            registry={(code,str(native)):json.loads(body) for code,native,body in db.execute('SELECT * FROM _eu_team_identity')}
        coef,_=coefficients(g,ranking,registry);frame=frame.join(coef,validate='one_to_one')
    repaired,merge=merge_proved_zeros(p,audit_dir=RESULT)
    assert len(p)==len(repaired) and not repaired.duplicated(['game_id','side','player_id']).any()
    proofs=pd.read_parquet(RUN/'pl_zero_proofs.parquet')
    assert len(proofs)==json.loads((RUN/'pl_zero_validation.json').read_bytes())['proved_zero_cells']
    assert pd.to_datetime(proofs.available_at_utc,utc=True,format='mixed').le(proofs.game_id.map(g.set_index('game_id').available_time)).all()
    old,audit_old=derive(g,p,keys);new,audit_new=derive(g,repaired,keys)
    for c in old:assert np.allclose(old[c],frame.loc[old.index,c],atol=1e-10,rtol=0,equal_nan=True),c
    changed=frame.copy();changed[new.columns]=new.loc[frame.index]
    assert changed.drop(columns=new.columns).equals(frame.drop(columns=new.columns))
    cut=pd.Timestamp('2025-01-01',tz='UTC');early=g[g.prediction_time.lt(cut)];pg=g[g.available_time.lt(cut)|g.game_id.isin(early.game_id)]
    prefix,_=derive(pg,repaired[repaired.game_id.isin(pg.game_id)],keys)
    pd.testing.assert_frame_equal(prefix.loc[early.game_id],new.loc[early.game_id],check_exact=True)
    # Human-readable source-denominator replay of the diagnosed case. It is
    # diagnostic only; every eligible proof is merged, not just these players.
    trace=[];cut=pd.Timestamp('2025-01-29T08:00:00Z')
    for label,f in [('reference',p),('corrected',repaired)]:
        f=f.assign(clock=pd.to_datetime(f.available_at_utc,utc=True,format='mixed'))
        for pid in ['EU_PL:441428','EU_PL:444884','EU_PL:200720']:
            h=f[f.player_id.eq(pid)&f.clock.lt(cut)&f.minutes.gt(0)].sort_values(['clock','game_id']).tail(30)
            for field in FIELDS:
                v=h[h[field].notna()];minutes=float(v.minutes.sum())
                trace.append(dict(variant=label,player_id=pid,player_name=h.iloc[-1].player_name,field=field,
                    appearances=len(h),covered_appearances=len(v),known_total=float(v[field].sum()),covered_minutes=minutes,
                    rate_per90=90*float(v[field].sum())/minutes if minutes else None,cutoff_utc=cut.isoformat()))
    pd.DataFrame(trace).to_csv(RESULT/'diagnosed_player_denominators.csv',index=False)
    for label,f in [('squad',changed),('control',frame)]:
        d=WORK/label;d.mkdir(exist_ok=True);f.reset_index().to_parquet(d/'soccer_features.parquet',index=False)
    audit_old['variant']='reference';audit_new['variant']='corrected'
    pd.concat([audit_old,audit_new],ignore_index=True).to_parquet(RESULT/'rate_evidence.parquet',index=False)
    changes={c:int((~np.isclose(old[c],new[c],atol=1e-12,equal_nan=True)).sum()) for c in new}
    dump(RESULT/'feature_validation.json',dict(status='PASS',at_utc=stamp(),games=len(frame),player_rows=len(p),
        merge=merge,changes=changes,prefix_rows=len(early),unchanged_other_inputs=True,
        old_rates_independently_replayed=True,new_source_requests=0,
        original_source_hash=file_sha256(source/'players.pkl'),candidate_hash=file_sha256(WORK/'squad/soccer_features.parquet')))
    print(json.dumps(dict(stage='features',changes=changes,merge=merge)),flush=True)


def train():
    import models
    recipe=json.loads((RESULT/'experiment_plan.json').read_bytes())['recipe']
    models.OUT=WORK/'control';models.CANDIDATES['count_control']=recipe
    ref=models.run('soccer','development',['count_control']).set_index('game_id')
    old=pd.read_parquet(REFERENCE/'development_predictions.parquet');old=old[old.variant.eq('candidate')].set_index('game_id')
    assert set(ref.index)==set(old.index)
    assert np.allclose(ref.loc[old.index,['p0','p1','p2']],old[['p0','p1','p2']],rtol=0,atol=1e-12)
    dump(RESULT/'control_replay.json',dict(status='PASS',at_utc=stamp(),forecasts=len(old)))
    squad.WORK=WORK;squad.RESULT=RESULT;squad.REFERENCE=REFERENCE;squad.train()


def stake():
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    assert (RESULT/'validation.json').exists() and not (RESULT/'stake_validation.json').exists()
    dump(RESULT/'stake_plan.json',dict(at_utc=stamp(),
        hypothesis='Forecast advantage magnitude should not directly magnify exposure when source coverage changes and probability errors are appreciable.',
        model='Same corrected-count rolling probabilities. No refit or hour search.',
        controls=['Existing$5per probability-minus-price percentage point','Existing fixed$20policy on all positive-value selections','Existing fixed$20policy requiring probability/price>=1.10'],
        stakes='Fixed$20equals1%of annual starting$2000. Cash-only, no compounding or extra fitted cap.',
        selection='For each provider, select fixed policy on2025only if Sharpe higher, drawdown lower, return positive relative to variable-stake control. If both qualify, larger2025Sharpe.2024is a reported small-sample diagnostic.',
        evaluation='Evaluate only qualified policy on2026.2026 already repeatedly inspected retrospective research, not pristine holdout.',app_changed=False))
    transfer.RESULT=RESULT;quotes=quote_inputs(RESULT/'stake_quote_quality.json',revision='closest_v62')
    prior=pd.read_csv(RESULT/'annual.csv');prior=prior[prior.variant.eq('candidate')].copy()
    records=[];positions=[];days=[];checks=[];choices={}
    for stage in ['development','evaluation']:
        if stage=='evaluation' and not any(choices.values()):break
        pred=pd.read_parquet(RESULT/(stage+'_predictions.parquet'));pred=pred[pred.variant.eq('candidate')]
        source=transfer.normalize('soccer',pred,quotes,pick_growth=True)
        for provider,f in source.groupby('provider'):
            if stage=='evaluation' and not choices.get(provider):continue
            rules=['flat20_positive','flat20_relative10'] if stage=='development' else [choices[provider]]
            for year in sorted(f.year.unique()):
                for rule in rules:
                    data=f if rule=='flat20_positive' else f[f.probability.ge(1.10*f.price)]
                    m,b,l,d=engine.simulate(data,int(year),'all_selected_outcomes','flat20_cash_only',5.,2000.)
                    key=dict(sport='soccer',provider=provider,year=int(year),rule=rule)
                    records.append(key|m);checks.append(key|engine.validate(b,l,d,'flat20_cash_only',5.,2000.))
                    if len(b):positions.append(b.assign(**key))
                    days.append(d.assign(**key))
        if stage=='development':
            a=pd.DataFrame(records)
            for provider,f in a[a.year.eq(2025)].groupby('provider'):
                ref=prior[prior.provider.eq(provider)&prior.year.eq(2025)].iloc[0]
                eligible=f[f.sharpe.gt(ref.sharpe)&f.max_drawdown_pct.lt(ref.max_drawdown_pct)&f.return_pct.gt(0)]
                choices[provider]=None if eligible.empty else eligible.sort_values('sharpe',ascending=False).iloc[0].rule
            dump(RESULT/'stake_selection.json',dict(at_utc=stamp(),choices=choices,earlier_scores=a.to_dict('records'),adopted=False))
    a=pd.DataFrame(records);a.to_csv(RESULT/'stake_annual.csv',index=False)
    b=pd.concat(positions,ignore_index=True);b.to_parquet(RESULT/'stake_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'stake_daily.parquet',index=False)
    # Reconcile unchanged opportunity/side/price where the fixed policy uses
    # every positive outcome, and save largest earlier losses for inspection.
    variable=pd.read_parquet(RESULT/'bets.parquet');variable=variable[variable.variant.eq('candidate')]
    for (provider,year,rule),h in b.groupby(['provider','year','rule']):
        ref=variable[variable.provider.eq(provider)&variable.year.eq(year)].set_index('game_id')
        assert set(h.game_id)<=set(ref.index)
        assert np.allclose(h.price,ref.loc[h.game_id,'price']) and np.array_equal(h.side,ref.loc[h.game_id,'side'])
    fields=['game_id','teamA','teamB','side','probability','price','stake','profit','entry_equity','quote_age_hours']
    variable[variable.year.eq(2025)].sort_values('profit').groupby('provider',sort=False).head(15)[['provider']+fields].to_csv(RESULT/'largest_earlier_losses.csv',index=False)
    dump(RESULT/'stake_validation.json',dict(status='PASS',at_utc=stamp(),checks=checks,choices=choices,
        forecasts_prices_sides_unchanged=True,adopted=False,app_changed=False))
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/stake_annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL+'/stake']=dict(plan=json.loads((RESULT/'stake_plan.json').read_bytes()),choices=choices,adopted=False);dump(path,old)
    print(a[['provider','year','rule','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


def winner():
    """Test a change in side selection after fixed stake alone failed its gate."""
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    prior_choice=json.loads((RESULT/'stake_selection.json').read_bytes())
    assert not any(prior_choice['choices'].values()),'This follow-up assumes the first sizing experiment failed'
    assert not (RESULT/'winner_validation.json').exists()
    dump(RESULT/'winner_plan.json',dict(at_utc=stamp(),
        diagnosis='The growth-selected outcome is often not the model most likely result.2025fixed-stake win rates are33-38%despite full-model accuracy53.7%. Choosing large apparent payoff advantage can select forecast errors.',
        rule='Choose the highest predicted probability across home/away/draw BEFORE checking market availability. Buy only that outcome, only if probability>original purchase price. Fixed$20, pre12, unchanged cash accounting.',
        no_missing_draw_substitution=True,no_added_probability_threshold=True,
        gate='Select on2025only. Sharpe must beat both existing fixed-stake alternatives and the variable-stake control, drawdown below variable control, return positive. Show2024diagnostically.',
        model='Same corrected-source forecasts, no further fitting or tuning.',evaluation='Retrospective repeatedly inspected2026; only earlier-qualified provider proceeds.',app_changed=False))
    quotes=quote_inputs(RESULT/'winner_quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    reference=pd.read_csv(RESULT/'annual.csv');reference=reference[reference.variant.eq('candidate')]
    fixed=pd.read_csv(RESULT/'stake_annual.csv');records=[];bets=[];days=[];checks=[];choices={}
    for stage in ['development','evaluation']:
        if stage=='evaluation' and not any(choices.values()):break
        pred=pd.read_parquet(RESULT/(stage+'_predictions.parquet'));pred=pred[pred.variant.eq('candidate')]
        source=transfer.normalize('soccer',pred,quotes,pick_growth=False)
        source=source[source.probability.gt(source.price)]
        for provider,f in source.groupby('provider'):
            if stage=='evaluation' and not choices.get(provider):continue
            for year in sorted(f.year.unique()):
                m,b,l,d=engine.simulate(f,int(year),'all_selected_outcomes','flat20_cash_only',5.,2000.)
                key=dict(sport='soccer',provider=provider,year=int(year),rule='model_most_likely_positive_flat20')
                records.append(key|m);checks.append(key|engine.validate(b,l,d,'flat20_cash_only',5.,2000.))
                assert np.array_equal(b.side,b[['p0','p1','p2']].to_numpy().argmax(axis=1))
                if len(b):bets.append(b.assign(**key))
                days.append(d.assign(**key))
        if stage=='development':
            a=pd.DataFrame(records)
            for row in a[a.year.eq(2025)].itertuples():
                ref=reference[reference.provider.eq(row.provider)&reference.year.eq(2025)].iloc[0]
                other=fixed[fixed.provider.eq(row.provider)&fixed.year.eq(2025)].sharpe.max()
                choices[row.provider]=bool(row.return_pct>0 and row.sharpe>max(ref.sharpe,other) and row.max_drawdown_pct<ref.max_drawdown_pct)
            dump(RESULT/'winner_selection.json',dict(at_utc=stamp(),choices=choices,adopted=False))
    a=pd.DataFrame(records);a.to_csv(RESULT/'winner_annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/'winner_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'winner_daily.parquet',index=False)
    dump(RESULT/'winner_validation.json',dict(status='PASS',at_utc=stamp(),checks=checks,choices=choices,
        chosen_class_matches_full_probability_argmax=True,adopted=False,app_changed=False))
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/winner_annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL+'/winner']=dict(plan=json.loads((RESULT/'winner_plan.json').read_bytes()),choices=choices,adopted=False);dump(path,old)
    print(a[['provider','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


def finish():
    from pathlib import Path
    from final_pipeline import discard_work,cleanup,validate
    for name in ['validation','feature_validation','cash_validation','control_replay']:
        assert json.loads((RESULT/(name+'.json')).read_bytes())['status']=='PASS'
    decision=json.loads((RESULT/'selection.json').read_bytes());proof=json.loads((RESULT/'feature_validation.json').read_bytes())
    a=pd.read_csv(RESULT/'annual.csv');trace=pd.read_csv(RESULT/'diagnosed_player_denominators.csv')
    def table(f):
        def fmt(v):return f'{v:.6f}' if isinstance(v,(float,np.floating)) else str(v)
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(map(fmt,row))+' |' for row in f.itertuples(index=False,name=None)])
    scores=pd.DataFrame([dict(variant=k,**v) for k,v in decision['scores'].items()])
    lines=['# Soccer complete-count source correction','',
        'A sparse per-player response can omit a zero count. Averaging only appearances with an explicitly present value then overstates some rates. The diagnosed example is Liverpool at PSV: a reserve defender has two recorded goals, but many earlier scoreless appearances are excluded from the denominator in the frozen research baseline.','',
        'This run imports only previously validated complete-count proofs. Native participants must be complete and their nonnegative counts must sum exactly to the official team total; only then is an omitted individual count derived as zero. Raw nulls remain null. Neither later results nor a preferred return choose the derived values. The source facts were already collected and validated; no new network calls were needed.','',
        f"The merge supplies {proof['merge']['newly_known_cells']} previously unknown cells, with {proof['merge']['conflicts']} conflicts. Existing explicit values and row identities remain unchanged. Changed current-model feature rows: {proof['changes']}. Full earlier-prefix replay covers {proof['prefix_rows']} games. All3,961 control forecasts independently replay.",'',
        'Only the existing goals, assists and key-pass roster inputs consume these repaired values in this controlled test. Other newly proved fields remain available in the evidence, but no extra model coefficients were added. The existing41-input learner, team/club context, physical-coverage handling, earlier-only imputation/scaling/calibration and monthly expanding history from2021 remain unchanged. Predictions begin2024.','',
        '## Diagnosed denominator change','',table(trace[['variant','player_name','field','appearances','covered_appearances','known_total','covered_minutes','rate_per90']]),'',
        '## Earlier-date probability comparison','',table(scores),'',
        f"Earlier gate passed: {decision['passed']}. Require lower logloss and Brier before a2026model evaluation. Correct source data are retained regardless of the model-selection result. Paired diagnostic: {json.dumps(decision['paired'])}.",'',
        '## Unchanged cash simulation','',
        'Each year starts with$2,000. Stake$5per positive probability-minus-price percentage point on one selected outcome; reuse cash only after official settlement. Pre12 uses the closest earlier quote, at most24hoursold. Providers remain separate. No fee assumptions. Sharpe annualizes daily calendar returns including idle days using sqrt(365.25). Polymarket prices are historical token references, not verified executable US asks; Kalshi keeps its recorded ask basis.','',
        table(a[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        '2026 has been repeatedly inspected and is retrospective rolling evidence, never described as an untouched holdout. No candidate is automatically adopted; the original results remain a frozen comparison, not evidence that omitted known zero counts are preferable source data.','',
        'Reproduce: soccer_source_count_rates.py build, train, finish. The existing pl_sparse_statistics.py and its independently validated source proofs provide the normalized zeros. Exact raw paths, hashes and endpoint URLs are in those proofs and the general source README. Rejected fits and duplicate input matrices are removed after validation; source evidence and result comparisons remain. The NBA/MLB app is unchanged.']
    if (RESULT/'stake_validation.json').exists():
        assert json.loads((RESULT/'stake_validation.json').read_bytes())['status']=='PASS'
        stakes=pd.read_csv(RESULT/'stake_annual.csv')
        choices=json.loads((RESULT/'stake_selection.json').read_bytes())['choices']
        lines+=['','## Exposure revision','',
            'Two existing simple policies are reapplied to the corrected-count model: fixed$20on all positive-value outcomes, or fixed$20with the existing10%relative-advantage hurdle. No price/hour/model tuning. Each provider selects on2025only, requiring higher Sharpe, lower drawdown and positive return versus variable stakes. Every original chosen side and source price is checked. Selection: '+json.dumps(choices)+'.','',
            table(stakes[['provider','year','rule','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
            'Largest earlier variable-stake losses are saved in largest_earlier_losses.csv. Fixed stakes address exposure concentration, not missing information or probability calibration. These results do not by themselves establish an executable or persistent advantage. Run the stake stage after train and before finish.']
    if (RESULT/'winner_validation.json').exists():
        assert json.loads((RESULT/'winner_validation.json').read_bytes())['status']=='PASS'
        w=pd.read_csv(RESULT/'winner_annual.csv');choices=json.loads((RESULT/'winner_selection.json').read_bytes())['choices']
        lines+=['','## Most-likely-outcome follow-up','',
            'Both fixed-stake variants failed the earlier Sharpe gate. The next single rule changes outcome selection: choose the model highest-probability result across all three classes before looking at available quotes, and buy it only with positive expected profit at fixed$20. This tests whether selecting large apparent payoff advantage selects errors. No new confidence cutoff, hour or dollar tuning. The2025Sharpe must beat all three preceding policies, with positive return and lower drawdown than variable staking. Selection: '+json.dumps(choices)+'.','',
            table(w[['provider','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
            'This follow-up also uses retrospective rolling forecasts; it is not independent confirmation of a persistent edge. Reproduce with winner after stake and before finish.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    if WORK.exists():discard_work(WORK)
    cleanup();check=validate()
    receipt=dict(status='PASS',at_utc=stamp(),selection=decision,app_validation=check,adopted=False,goal_achieved=False,temporary_work_removed=True)
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(path.read_bytes())
    m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']),latest_simulation_update=receipt);dump(path,m)
    print(a[['provider','variant','year','funded_games','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['build','train','stake','winner','finish']);args=parser.parse_args();globals()[args.stage]()
