"""Optional recovered-club branch; raw tables and prior studies stay immutable."""
import collections
import hashlib
import json
import math

import pandas as pd

from common import OUT, PROJECT, ROOT_OUT, dump, read_db, stamp

# These additive nonnegative counts were independently reconciled in the raw
# replay. No inference is made for xG, conceded goals, minutes or missing totals.
ADDITIVE = ['passes', 'passes_completed', 'shots', 'shots_on_target',
            'tackles', 'interceptions', 'saves']
PLAYER_FEATURES = ['shots', 'passes_completed', 'final_third_passes_completed',
                   'interceptions', 'recoveries', 'tackles_won', 'aerials_won', 'saves']


def records():
    validation = json.loads((ROOT_OUT/'laliga_club_validation.json').read_text())
    assert validation['status'] == 'PASS'
    valid = {tuple(k) for k in validation['validated_player_keys']}
    with read_db(ROOT_OUT/'laliga_club.sqlite') as c:
        games = [json.loads(b) for b, in c.execute('SELECT body FROM games')]
        people = [json.loads(b) for b, in c.execute('SELECT body FROM player_statistics')]
    assert all((r['game_id'], r['official_player_id']) in valid for r in people)
    return games, people


def recovered_players():
    games, people = records()
    details = {(r['game_id'], r['official_player_id']): r for r in people}
    proofs = []
    # A zero is inferred only when all participants are accounted for and the
    # known individual counts already exhaust the official team's whole count.
    for game in games:
        for side in ['A', 'B']:
            lineup = [r for r in game['players'] if r['side'] == side and r['played']]
            group = [r for r in people if r['game_id'] == game['game_id']
                     and r['side'] == side and r['appearances_reported'] == 1]
            assert {r['official_player_id'] for r in lineup} == {r['official_player_id'] for r in group}
            team = next(r for r in game['teams'] if r['side'] == side)
            for field in ADDITIVE:
                total = team[field]
                known = [r[field] for r in group if r[field] is not None]
                assert all(v >= 0 and float(v).is_integer() for v in known)
                if total is None or math.fsum(known) != total:
                    continue
                for player in group:
                    if player[field] is not None:
                        continue
                    player[field] = 0.0
                    proofs.append(dict(game_id=game['game_id'], side=side,
                        official_player_id=player['official_player_id'], field=field,
                        raw_value=None, derived_value=0.0, team_total=total,
                        sum_explicit_player_values=math.fsum(known),
                        complete_participant_count=len(group),
                        player_source_sha256=player['source']['sha256'],
                        team_source_sha256=team['source']['sha256'],
                        proof='Complete player set; additive nonnegative integer counts; known sum equals official team total.'))
    rows = []
    for game in games:
        for lineup in game['players']:
            row = dict(lineup)
            detail = details.get((row['game_id'], row['official_player_id']))
            if detail:
                # Retain derived regulation minutes and event-verified goals.
                # Reported minutes with provider rounding remain separate.
                for key, value in detail.items():
                    if key not in row and key not in ['source', 'raw_stats']:
                        row[key] = value
                row['available_at_utc'] = max(pd.Timestamp(row['available_at_utc']),
                                              pd.Timestamp(detail['available_at_utc']))
            rows.append(row)
    pd.DataFrame(proofs).to_parquet(OUT/'laliga_derived_zero_proofs.parquet', index=False)
    return games, rows, dict(derived_zero_cells=len(proofs),
        zero_counts_by_field=dict(collections.Counter(r['field'] for r in proofs)),
        raw_nulls_preserved=True)


def merge_club_players(players):
    games, rows, evidence = recovered_players()
    fresh = pd.DataFrame(rows)
    # Keep model inputs flat; exact raw objects already live in source tables.
    fresh = fresh.drop(columns=['source', 'raw_stats'], errors='ignore')
    cross = players[['league', 'official_player_id', 'player_id']].drop_duplicates()
    assert cross.groupby(['league', 'official_player_id']).player_id.nunique().max() == 1
    native = cross.set_index(['league', 'official_player_id']).player_id.to_dict()
    fresh['player_id'] = [native.get((r.league, r.official_player_id),
                                    'EU_LAL:'+r.official_player_id) for r in fresh.itertuples()]
    fresh['player_type'] = fresh.position.map(lambda x: 'goalkeeper' if x == 'G' else None)
    index = ['game_id', 'side', 'official_player_id']
    old = players.set_index(index)
    new = fresh.set_index(index)
    assert not new.index.duplicated().any()
    joined = new.combine_first(old)
    for field in ['minutes', 'minutes_basis', 'position', 'player_type']:
        values = old[field].dropna()
        joined.loc[values.index, field] = values
    # Combining data may never shorten the availability of the retained field.
    times = pd.concat([pd.to_datetime(old.available_at_utc, utc=True, format='mixed'),
                       pd.to_datetime(new.available_at_utc, utc=True, format='mixed')], axis=1)
    joined['available_at_utc'] = times.max(axis=1)
    evidence.update(games=len(games), lineup_rows=len(fresh),
                    added_rows=len(joined)-len(old),
                    statistic_rows=sum('minutes_reported' in r for r in rows))
    dump(OUT/'laliga_club_feature_merge.json', dict(at_utc=stamp(), **evidence))
    return joined.reset_index(), evidence


def correct_clocks(games, obs, players):
    """Repair starts and cutoffs together; retain conservative label delays."""
    repairs = json.loads((ROOT_OUT/'laliga_clock_audit.json').read_text())['records']
    games, obs, players = games.copy(), obs.copy(), players.copy()
    for column in ['start_time', 'available_time']:
        obs[column] = pd.to_datetime(obs[column], utc=True, format='mixed')
    players['available_at_utc'] = pd.to_datetime(players.available_at_utc, utc=True, format='mixed')
    output = []
    for repair in repairs:
        gid = repair['game_id']
        mask = games.game_id.eq(gid)
        assert mask.sum() == 1
        prior = games.loc[mask].iloc[0]
        assert str(prior.official_game_id) == repair['official_game_id']
        assert prior.start_time == pd.Timestamp(repair['prior_start_utc'])
        raw = (PROJECT/repair['source_raw_file']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == repair['source_sha256']
        start = pd.Timestamp(repair['verified_start_utc'])
        cutoff = start-pd.Timedelta(hours=12)
        # Six hours is the existing conservative result release floor, not a
        # claimed exact whistle or publication time. Never move a label earlier.
        available = max(prior.available_time, start+pd.Timedelta(hours=6))
        games.loc[mask, ['start_time', 'prediction_time', 'available_time']] = [start, cutoff, available]
        for column, value in [('timestamp', start.isoformat()),
                              ('prediction_timestamp_utc', cutoff.isoformat()),
                              ('feature_cutoff_date', cutoff.date().isoformat()),
                              ('label_available_at_utc', available.isoformat()),
                              ('clock_basis', 'verified_official_club_fixture'), ('decision_eligible', 1)]:
            if column in games:
                games.loc[mask, column] = value
        om = obs.game_id.eq(gid)
        obs.loc[om, 'start_time'] = start
        obs.loc[om, 'available_time'] = available
        pm = players.game_id.eq(gid)
        if pm.any():
            times = pd.to_datetime(players.loc[pm, 'available_at_utc'], utc=True, format='mixed')
            players.loc[pm, 'available_at_utc'] = times.clip(lower=start+pd.Timedelta(hours=6))
        output.append(dict(game_id=gid, prior_start=prior.start_time, verified_start=start,
                           prediction_time=cutoff, prior_available=prior.available_time,
                           result_available=available, source_sha256=repair['source_sha256']))
    # These twelve games have no retained pre12 prices. Do not shift a quote's
    # timestamp or reuse an old-cutoff price as a newly selected observation.
    counts = {}
    with read_db(PROJECT/'collected data/result/player_depth.sqlite') as c:
        ids = [r['game_id'] for r in repairs]
        for provider in ['polymarket', 'kalshi']:
            n = c.execute('SELECT count(*) FROM '+provider+'_quotes WHERE hours_before=12 AND game_id IN ('+
                          ','.join('?' for _ in ids)+')', ids).fetchone()[0]
            assert n == 0, 'Changed clocks now have quotes: replay source history at the corrected cutoff before modeling'
            counts[provider] = n
    dump(OUT/'laliga_applied_clock_repairs.json', dict(at_utc=stamp(), records=output,
        affected_pre12_quote_rows=counts,
        price_action='No affected retained prices exist. Quote pool unchanged; no odds inferred. Acquisition for newly eligible games remains pending.'))
    return games, obs, players
