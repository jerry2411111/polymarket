"""Traceable own-goal-adjusted keeper shot-quality observations.

Reported xGOT is retained even when it cannot yet support a derived rate.
Conflicting conceded counts are reconciled only from the official final
calendar. Other source inconsistencies remain explicit recovery cases.
"""
import argparse
import collections
import hashlib
import json
import sqlite3
from pathlib import Path

import numpy as np
import pandas as pd

from common import PROJECT, PREVIOUS, ROOT_OUT, read_db, dump, stamp, file_sha256
from pl_sparse_statistics import original

FOLDER=ROOT_OUT/'soccer_keeper_v81'
TABLE='soccer_goalkeeper_shot_difficulty'


def calendar_record(game):
    rid=game['calendar_request_id']
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
        row=db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()
    if row:
        source=json.loads(row[0])
    else:
        with read_db(PROJECT/'collected data/result/soccer_statistics.sqlite') as db:
            row=db.execute('SELECT * FROM source_manifest WHERE request_id=?',(rid,)).fetchone()
        assert row,'Official calendar source must be recovered before reconciliation'
        source=dict(row)
    raw=source['raw_file'].replace('\\','/')
    mapping=json.loads((PROJECT/'final_models/sources/path_map.json').read_bytes())
    for old,new in mapping.items():
        old,new=old.replace('\\','/'),new.replace('\\','/')
        if raw.startswith(old):raw=new+raw[len(old):];break
    if raw.startswith('data/'):raw='collected data/'+raw[5:]
    path=Path(raw);path=path if path.is_absolute() else PROJECT/path
    blob=path.read_bytes();assert hashlib.sha256(blob).hexdigest()==source['sha256']
    item=json.loads(blob)
    for bit in game['calendar_pointer'].strip('/').split('/'):
        item=item[int(bit)] if isinstance(item,list) else item[bit]
    assert str(item['matchId'])==game['official_game_id'] and item['period']=='FullTime'
    native=json.loads(game['native_team_ids_json'])
    assert [str(item[k]['id']) for k in ['awayTeam','homeTeam']]==list(map(str,native))
    assert [item[k]['score'] for k in ['awayTeam','homeTeam']]==[game['scoreA'],game['scoreB']]
    source=dict(source,raw_file=str(path.resolve()),url=source.get('url',source.get('endpoint')))
    return item,source


def repair_clean_sheets(rows,games):
    conflicts=[]
    for row in rows:
        if row['league']!='Premier League':continue
        value=row['goals_conceded'];game=games[row['game_id']]
        against=game['scoreB' if row['side']=='A' else 'scoreA']
        if pd.isna(value) or value<=against:continue
        assert against==0,'A non-clean-sheet discrepancy needs individual event reconciliation'
        calendar,source=calendar_record(game)
        proof=json.loads(row['field_evidence_json'])
        proof['goals_conceded'].update(basis='official clean sheet supersedes conflicting keeper statistic',
            calendar_source=source,calendar_pointer=game['calendar_pointer'],official_opponent_score=0,
            discrepancy='Reported conceded count exceeds official final team conceded count',
            likely_reason='Statistic feed may retain a disallowed goal; confirmed for three public examples, not assumed for every case')
        row['goals_conceded']=0.
        row['field_evidence_json']=json.dumps(proof,sort_keys=True)
        conflicts.append(dict(game_id=row['game_id'],side=row['side'],player_id=row['official_player_id'],
            raw_value=row['raw_goals_conceded'],normalized_value=0.,calendar_source=source,
            calendar_pointer=game['calendar_pointer'],statistic_source=json.loads(row['source_json'])))
    dump(FOLDER/'pl_keeper_score_conflicts.json',dict(at_utc=stamp(),status='PASS',corrected=len(conflicts),
        records=conflicts,raw_values_preserved=True,only_official_final_zero_used=True))
    print(json.dumps(dict(stage='keeper_clean_sheet_reconciliation',corrected=len(conflicts))),flush=True)


def build():
    source=ROOT_OUT/'soccer_goalkeeper_game_observations.parquet'
    check=json.loads((FOLDER/'keeper_validation.json').read_bytes())
    assert check['status']=='PASS' and check['source_sha256']==file_sha256(source)
    frame=pd.read_parquet(source);keepers=frame[frame.keeper_xgot_conceded.notna()].copy()
    assert set(keepers.league)=={'Premier League'},'Additional leagues need their own native own-goal validation'
    with read_db(PREVIOUS/'collection.sqlite') as db:
        sources={r['url']:dict(r) for r in db.execute("SELECT * FROM requests WHERE status=200 AND url LIKE '%prem%/stats'")}
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games={r['game_id']:dict(r) for r in db.execute("SELECT * FROM soccer_games WHERE league='Premier League'")}
    rows=[];counts=collections.Counter();checked=[]
    for r in keepers.itertuples():
        person_source=json.loads(r.source_json);blob=(PROJECT/person_source['raw_file']).read_bytes()
        assert hashlib.sha256(blob).hexdigest()==person_source['sha256']
        raw=json.loads(blob);stats=raw['stats'];assert str(raw['playerMetadata']['id'])==r.official_player_id
        xgot=stats['expectedGoalsOnTargetConceded'];assert xgot==r.keeper_xgot_conceded and xgot>0
        url='https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v3/matches/'+r.official_game_id+'/stats'
        assert url in sources
        teams,path=original(sources[url]);team_source=dict(sources[url],raw_file=path)
        team=next(t for t in teams if str(t['teamId'])==r.team_id);total=team['stats']
        game=games[r.game_id];against=game['scoreB' if r.side=='A' else 'scoreA']
        own=total.get('ownGoals');keeper_own=stats.get('ownGoals');gc=r.goals_conceded
        raw_gc=stats.get('goalsConceded');status='usable';basis=None;excluding=None
        if pd.notna(raw_gc) and raw_gc>against:
            status='conceded-statistic conflict; shot-quality scope needs reconciliation'
        elif pd.isna(gc):
            status='conceded goals need recovery'
        elif gc==0:
            excluding=0.;basis='No conceded goals implies no conceded own goals'
        elif own==0:
            excluding=float(gc);basis='Official team reports zero own goals'
        elif own is not None and keeper_own is not None and own==keeper_own:
            assert gc>=keeper_own
            excluding=float(gc-keeper_own);basis='All reported team own goals attributed to this keeper'
        else:
            status='own-goal count or keeper exposure attribution requires recovery'
        event_proof=None
        if status in ['own-goal count or keeper exposure attribution requires recovery','conceded goals need recovery']:
            from pl_keeper_events import reconcile
            # The native lineup evidence is already independently validated.
            from types import SimpleNamespace
            role=json.loads(r.role_evidence_json)
            event_proof=reconcile(SimpleNamespace(**r._asdict(),derivation_json=json.dumps(dict(role_evidence=role))),game)
            if 'goals_conceded_excluding_own' in event_proof:
                if pd.notna(gc) and gc!=event_proof['goals_conceded']:
                    status='Keeper statistic and official event exposure disagree'
                elif own is not None and own!=event_proof['team_own_goals']:
                    status='Team own-goal statistic and official events disagree'
                else:
                    gc=event_proof['goals_conceded'];excluding=event_proof['goals_conceded_excluding_own']
                    basis=event_proof['own_goal_basis'];status='usable'
            if event_proof.get('source'):checked.append(event_proof['source']['sha256'])
        prevented=xgot-excluding if excluding is not None else None
        role=json.loads(r.role_evidence_json)
        evidence=dict(xgot_pointer='/stats/expectedGoalsOnTargetConceded',conceded_pointer='/stats/goalsConceded',
            team_own_goals_pointer='/'+str(teams.index(team))+'/stats/ownGoals',keeper_own_goals_pointer='/stats/ownGoals',
            normalized_conceded_evidence=json.loads(r.field_evidence_json)['goals_conceded'],
            own_goal_basis=basis,official_event_proof=event_proof,definition='xGOT minus conceded goals excluding own goals; includes penalties as supplied; research derivation, not a separately reported official metric',
            role_evidence=role)
        rows.append(dict(game_id=r.game_id,official_game_id=r.official_game_id,league=r.league,date=r.date,side=r.side,
            team_id=r.team_id,official_player_id=r.official_player_id,id_namespace=r.id_namespace,minutes=r.minutes,
            available_at_utc=r.available_at_utc,xgot_conceded=xgot,goals_conceded=gc,
            raw_goals_conceded=raw_gc,team_own_goals=own,keeper_own_goals=keeper_own,
            goals_conceded_excluding_own=excluding,goals_prevented=prevented,status=status,
            source_json=r.source_json,team_source_json=json.dumps(team_source,sort_keys=True),
            derivation_json=json.dumps(evidence,sort_keys=True)))
        counts[status]+=1
        if excluding is not None:
            assert excluding>=0 and abs((xgot-excluding)-prevented)<1e-12
        checked.extend([person_source['sha256'],team_source['sha256']])
    result=pd.DataFrame(rows);assert not result.duplicated(['game_id','side','official_player_id']).any()
    file=ROOT_OUT/(TABLE+'.parquet');result.to_parquet(file,index=False);result.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    meanings={
        'game_id':('Canonical collected game ID','identifier'), 'official_game_id':('Official Premier League match ID','identifier'),
        'league':('Actual competition','text'), 'date':('Game calendar date','YYYY-MM-DD'), 'side':('A=away; B=home','category'),
        'team_id':('Native dated team ID','identifier'), 'official_player_id':('Native official keeper ID','identifier'),
        'id_namespace':('Native player identity namespace','text'), 'minutes':('Reported keeper playing time','minutes'),
        'available_at_utc':('Historical postgame availability cutoff used for later forecasts','UTC timestamp'),
        'xgot_conceded':('Reported expected goals on target faced; raw value retained even when status bars model use','expected goals'),
        'goals_conceded':('Keeper conceded count after documented final-score reconciliation','goals'),
        'raw_goals_conceded':('Original API conceded count; omission remains null','goals'),
        'team_own_goals':('Raw team-statistic own goals; omitted values stay null even when events establish the derived count','goals'),
        'keeper_own_goals':('Explicitly reported own goals by this keeper; omission remains null','goals'),
        'goals_conceded_excluding_own':('Conceded count excluding own goals only when allocation is proved','goals'),
        'goals_prevented':('xgot_conceded minus goals_conceded_excluding_own; null for unresolved scope','goals above expectation'),
        'status':('Whether source values support the derived metric or require specified recovery','text'),
        'source_json':('Official individual-statistic URL, raw file and hash','JSON'),
        'team_source_json':('Official team-statistic URL, raw file and hash','JSON'),
        'derivation_json':('Raw pointers, native role, own-goal proof, and any conceded-count correction','JSON')}
    origin='Official Premier League v1 individual and v3 team statistics; v1 goal events matched to both final scores for own-goal/exposure recovery; dated official lineup roles; v2 final calendar where a conceded statistic conflicts. Opta/Premier League definitions. No missing statistic is automatically zero.'
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        result.to_sql(TABLE,db,if_exists='replace',index=False)
        for t in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+t+' WHERE "table"=?',(TABLE,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(TABLE,len(result),len(result.columns)))
        for field in result:
            meaning,unit=meanings[field];db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(TABLE,field,meaning,unit,origin))
            n=int(result[field].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(TABLE,field,len(result),n,100*n/len(result)))
        restored=pd.read_sql_query('SELECT * FROM '+TABLE,db)
        pd.testing.assert_frame_equal(result,restored,check_dtype=False)
    report=dict(status='PASS',at_utc=stamp(),rows=len(result),usable=int(result.goals_prevented.notna().sum()),
        source_rows=len(frame),raw_sources=len(set(checked)),counts=dict(counts),source_sha256=check['source_sha256'],
        output_sha256=file_sha256(file),reported_xgot_zero_count=0,missing_xgot_not_filled=True,
        own_goal_adjustments_require_evidence=True,goal_achieved=False)
    dump(FOLDER/'shot_difficulty_validation.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':
    build()
    from publish import main
    main()
    from final_pipeline import cleanup
    cleanup()
