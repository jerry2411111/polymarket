"""Replay native identities and statistic cells independently of the collector."""
import argparse,collections,datetime as dt,hashlib,html,io,json,re
from pypdf import PdfReader
from pathlib import Path
from common import PROJECT,read_db,dump,stamp,OfficialClient
from collect_seriea_keeper_statistics import FOLDER,FIELDS,sources

PUBLIC={
 '2021-01-03':dict(url='https://www.inter.it/en/match_center/4587',scoreA=2,scoreB=6,
     text=['Crotone','Inter','6 - 2','3 January 2021','Handanovic','Cordaz']),
 '2024-01-05':dict(url='https://www.bolognafc.it/storico-stagione/2023-24/',scoreA=1,scoreB=1,
     text=['5 gennaio 2024','BOLOGNA-GENOA 1-1']),
 '2026-01-02':dict(url='https://www.acmilan.com/it/news/articoli/serie-a/2026-01-02/leao-rilancia-il-milan-vittoria-a-cagliari',scoreA=1,scoreB=0,
     text=['2 gennaio 2026','CAGLIARI-MILAN 0-1','Caprile','Maignan'])}

def main(pilot=False,manual_public=False):
    games,old=sources();cache={};counts=collections.Counter();unlinked=[];issues=[];public=[]
    def raw(s):
        key=s['sha256']
        if key not in cache:
            path=Path(s['raw_file']);body=(path if path.is_absolute() else PROJECT/path).read_bytes()
            assert hashlib.sha256(body).hexdigest()==key;cache[key]=json.loads(body)
        return cache[key]
    def pointer(data,path):
        for key in path.strip('/').split('/'):data=data[int(key)] if isinstance(data,list) else data[key]
        return data
    with read_db(FOLDER/'statistics.sqlite') as db:records=[json.loads(b) for b, in db.execute('SELECT body FROM games')]
    if pilot:
        pilot_ids={r['game']['game_id'] for r in json.loads((FOLDER.parent/'seriea_keeper_pilot_requests.json').read_bytes())['records']}
        records=[r for r in records if r['game_id'] in pilot_ids];assert len(records)==3
    for record in records:
        game=games[record['game_id']];ranking=raw(record['source']);lineup=raw(record['lineup_source']);feed=raw(record.get('feed_source',record['result_source']))
        assert ranking['matchId']==lineup['matchId']==feed['matchId']==game['official_game_id']
        assert feed['status']=='FINISHED' and feed['pagination']['isLastPage']
        assert record['parser_version'] in [2,3] and all(p['parser_version']==4 for p in old[game['game_id']])
        end_scores=[(e['providerAwayScore'],e['providerHomeScore']) for e in feed['events'] if e['type'] in ['full-time','end-second-half'] and e.get('providerAwayScore') is not None and e.get('providerHomeScore') is not None]
        calendar=record.get('calendar_source')
        if calendar:
            result=pointer(raw(calendar),calendar['source_pointer'])
            assert result['matchId']==game['official_game_id'] and result['status']=='FINISHED' and result['phase']=='FULL_TIME'
            assert dt.datetime.fromisoformat(result['matchDateUtc'])==dt.datetime.fromisoformat(game['timestamp'])
            assert [result['away']['teamId'],result['home']['teamId']]==json.loads(game['native_team_ids_json'])
            assert (result['providerAwayScore'],result['providerHomeScore'])==(game['scoreA'],game['scoreB'])
            assert (result['awayScorePush'],result['homeScorePush'])==(game['scoreA'],game['scoreB'])
            assert record['result_source']==calendar
            counts['independent_calendar_results']+=1
        assert calendar or all(p['goal_counts_reconcile'] for p in old[game['game_id']]) or (end_scores and set(end_scores)=={(game['scoreA'],game['scoreB'])})
        oldplayers={p['official_player_id']:p for p in old[game['game_id']]}
        seen=set()
        for r in record['players']:
            native='away' if r['side']=='A' else 'home';pid=r['official_player_id'];assert (native,pid) not in seen;seen.add((native,pid))
            assert r['team_id']==ranking[native]['teamId']==lineup[native]['teamId']
            person=pointer(lineup,r['lineup_pointer']);assert person['playerId']==pid and person['roleLabel']=='Goalkeeper'
            match=[p for p in ranking[native]['players'] if p['player']['playerId']==pid];assert len(match)==1
            stats=collections.defaultdict(list)
            for field in match[0]['stats']:stats[field['statsId']].append(field.get('statsValue'))
            evidence=json.loads(r['field_pointers_json'])
            for field,sourcefield in FIELDS.items():
                values=stats.get(sourcefield,[])
                expected=values[0] if values and all(v==values[0] for v in values) else None
                assert expected==r[field],(game['game_id'],pid,field,expected,r[field])
                if r[field] is None:assert evidence[field] is None
                else:
                    assert len(evidence[field])==len(values)
                    assert all(pointer(ranking,p)==r[field] for p in evidence[field]);counts['raw_numeric_cells']+=1
                    counts['explicit_zero_cells']+=int(r[field]==0)
                    counts['duplicate_cells_checked']+=len(values)-1
            prior=oldplayers[pid];assert prior['did_play'] and prior['available_at_utc']==r['available_at_utc']
            assert dt.datetime.fromisoformat(r['available_at_utc'])>dt.datetime.fromisoformat(game['timestamp'])
            changes=[e for e in person.get('events',[]) if e['type'] in ('substitution-in','substitution-out','red-card','second-yellow-card')]
            repair=prior.get('keeper_report_repair')
            if repair:
                src=repair['source'];path=Path(src['raw_file']);body=(path if path.is_absolute() else PROJECT/path).read_bytes()
                assert hashlib.sha256(body).hexdigest()==src['sha256']
                report=PdfReader(io.BytesIO(body));text=' '.join(report.pages[repair['page']-1].extract_text().split())
                assert repair['exact_fixture_text'] in text and '25/05/2025' in text
                assert pid==repair['native_player_id'] and person['shortName']=='Marco Carnesecchi'
                assert '29 Marco Carnesecchi' in ' '.join(report.pages[repair['identity_page']-1].extract_text().split())
                assert stats['minutes']==[90] and stats['minsPlayed']==[90]
                assert prior['started']==1 and prior['minutes']==90 and repair['raw_started']==0
                assert dt.datetime.fromisoformat(r['available_at_utc'])>=dt.datetime.fromisoformat(repair['conservative_available_at_utc'])
                counts['official_report_starter_repairs']+=1
            full=(('/fielded/' in r['lineup_pointer'] or repair) and not changes and not prior['minutes_issues'] and prior['minutes']==90 and r['minutes_reported']>=90)
            assert bool(full)==r['full_match_verified'];opponent=game['scoreB' if r['side']=='A' else 'scoreA']
            expected=r['goals_conceded_raw']
            if expected is None and (full or opponent==0):expected=float(opponent)
            if full and expected is not None and expected!=opponent:expected=None
            assert expected==r['goals_conceded'];counts['keeper_rows']+=1
        for row in record['unlinked_players']:
            item=pointer(ranking,row['source_pointer']);native='away' if row['side']=='A' else 'home'
            assert item['player']['playerId']==row['ranking_player_id']
            assert row['ranking_player_id'] not in {p['playerId'] for g in ['fielded','benched'] for p in lineup[native][g]}
            assert (native,row['ranking_player_id']) not in seen;unlinked.append(row)
        issues.extend(dict(game_id=game['game_id'],**issue) for issue in record['issues']);counts['games']+=1
    if pilot:
        OfficialClient.HOSTS.update(['www.inter.it','www.bolognafc.it','www.acmilan.com']);client=OfficialClient(2)
        for record in records:
            expected=PUBLIC[record['date']];game=games[record['game_id']]
            if manual_public:
                manual=json.loads((FOLDER/'public_manual_review.json').read_bytes())
                review=next(x for x in manual['examples'] if x['date']==record['date'])
                assert review['url']==expected['url'] and review['scoreA']==expected['scoreA'] and review['scoreB']==expected['scoreB']
                assert review['identity_date_result_match'] is True
                source=dict(url=expected['url'],reviewed_at_utc=manual['reviewed_at_utc'],method=manual['method'],review=review)
            else:
                body,source=client.get(expected['url'],'Public club verification of keeper pilot fixture/date/final result','keeper_pilot_public_validation',document=True)
                assert body is not None,source
                plain=html.unescape(re.sub('<[^>]+>',' ',body.decode('utf8')));plain=' '.join(plain.split())
                for text in expected['text']:assert text in plain,(expected['url'],text)
            assert [game['scoreA'],game['scoreB']]==[expected['scoreA'],expected['scoreB']]
            public.append(dict(game_id=game['game_id'],date=record['date'],public_source=source,teams=[game['teamA'],game['teamB']],scores=[game['scoreA'],game['scoreB']],match=True,
                scope='Public fixture identity/date/final score; individual numeric save fields separately checked against raw official API.'))
        dump(FOLDER/'public_validation.json',public)
    dump(FOLDER/'unlinked_players.json',unlinked);dump(FOLDER/'source_issues.json',issues)
    report=dict(status='PASS',scope='Verified rows only; unresolved native player identities retained separately, not asserted complete.',at_utc=stamp(),pilot=pilot,**dict(counts),
        raw_sources=len(cache),unlinked_player_rows=len(unlinked),source_issue_counts=dict(collections.Counter(i['kind'] for i in issues)),public_examples=len(public),
        available_time_policy='Conservative historical source availability from prior validated player parser; not a contemporaneous archive publication timestamp.',
        save_percentage_not_inferred_from_saves_plus_goals=True)
    dump(FOLDER/('pilot_validation.json' if pilot else 'validation.json'),report);print(json.dumps(report),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');p.add_argument('--manual-public',action='store_true');a=p.parse_args();main(a.pilot,a.manual_public)
