"""Dated Bundesliga physical facts and Ligue 1 player actions, official only.

Retained official responses are hash-checked and reused. Additional Bundesliga
ranking and lineup endpoints contain native per-player match measurements.
The rank field is a within-game statistic rank, not a media/player ability rank.
"""
import argparse,collections,concurrent.futures,hashlib,json,re,sqlite3
import pandas as pd
from common import ROOT_OUT,PREVIOUS,PROJECT,OfficialClient,read_db,dump,stamp
PARSER_VERSION=2

LIGUE_FIELDS={
 'shots':'total_scoring_att','shots_on_target':'ontarget_scoring_att','key_passes':'total_att_assist',
 'passes':'total_pass','passes_completed':'accurate_pass','forward_passes':'fwd_pass',
 'long_passes':'total_long_balls','long_passes_completed':'accurate_long_balls',
 'final_third_entries':'final_third_entries','final_third_passes':'total_final_third_passes',
 'final_third_passes_completed':'successful_final_third_passes','touches':'touches',
 'touches_opponent_box':'touches_in_opp_box','through_balls':'total_through_ball',
 'crosses':'total_cross','crosses_completed':'accurate_cross','dribbles':'total_contest',
 'dribbles_completed':'won_contest','tackles':'total_tackle','tackles_won':'won_tackle',
 'interceptions':'interception','recoveries':'ball_recovery','recoveries_attacking_third':'poss_won_att_3rd',
 'recoveries_defensive_third':'poss_won_def_3rd','duels_won':'duel_won','duels_lost':'duel_lost',
 'aerials_won':'aerial_won','aerials_lost':'aerial_lost','clearances':'total_clearance',
 'blocked_shots':'outfielder_block','possession_lost':'poss_lost_all','errors_to_shot':'error_lead_to_shot',
 'errors_to_goal':'error_lead_to_goal','saves':'saves','goals_conceded':'goals_conceded',
 'yellow_cards':'yellow_card','red_cards':'red_card','fouls_committed':'fouls','fouls_suffered':'was_fouled',
 'xg':'expected_goals','xa':'expected_assists','xgot':'expected_goals_on_target',
 'keeper_xgot_conceded':'expected_goals_on_target_conceded'}
BUN_PLAYER={'challengesWon':'challenges_won','maximumSpeed':'maximum_speed_kmh','shotsAtGoal':'shots_at_goal','totalDistanceCovered':'distance_covered_km'}
BUN_TEAM={'distanceCovered':'distance_covered_km','sprints':'sprints','passes':'passes_reported','tacklesWon':'challenges_won_reported',
          'shotsOnTarget':'shots_on_target','shotsOffTarget':'shots_off_target','xGoals':'xg','passAccuracy':'pass_accuracy_pct','ballPossessionRatio':'possession_pct','cornerKicks':'corners','fouls':'fouls'}


def cached_sources():
    mapping=json.loads((PROJECT/'final_models/sources/path_map.json').read_text());result={}
    with read_db(PROJECT/'collected data/result/soccer_statistics.sqlite') as db:
        rows=db.execute("SELECT * FROM source_manifest WHERE status=200 AND (endpoint LIKE '%bundesliga%/stats.json%' OR endpoint LIKE 'https://ma-api.ligue1.fr/championship-match/%') ORDER BY retrieved_at_utc")
        for row in rows:
            r=dict(row);raw=r['raw_file'].replace('\\','/')
            for old,new in mapping.items():
                old,new=old.replace('\\','/'),new.replace('\\','/')
                if raw.startswith(old):raw=new+raw[len(old):];break
            if (PROJECT/raw).exists():
                result[r['endpoint']]=dict(request_id=r['request_id'],url=r['endpoint'],raw_file=raw,sha256=r['sha256'],retrieved_at_utc=r['retrieved_at_utc'],reused=True)
    return result


def retained(source):
    blob=(PROJECT/source['raw_file']).read_bytes();assert hashlib.sha256(blob).hexdigest()==source['sha256'],'Retained raw hash mismatch'
    return json.loads(blob)


def base(game,side):
    return dict(game_id=game['game_id'],official_game_id=game['official_game_id'],league=game['league'],date=game['date'],
                available_at_utc=game['available_time'],side=side,team_id=str(json.loads(game['native_team_ids_json'])[0 if side=='A' else 1]))


def ligue_expected_goals(raw,native):
    """Keep native values; distinguish positive measurements from old zero placeholders."""
    import math
    value=raw.get('expectedGoals');shots=raw.get('scoringAttempts')
    valid_number=isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)
    if value is None:status='not_supplied';normalized=None
    elif not valid_number or value<0:status='invalid_source_value';normalized=None
    elif value==0 and shots==0:status='explicit_zero_with_zero_shots';normalized=0.0
    elif value==0:status='ambiguous_zero_placeholder';normalized=None
    elif isinstance(shots,(int,float)) and 0<value<=shots:status='populated';normalized=float(value)
    else:status='shot_count_disagreement';normalized=None
    return dict(xg_raw=value,xg=normalized,xg_status=status,xg_pointer='/'+native+'/stats/expectedGoals')


def parse_ligue(game,data,source):
    assert data['id']==game['official_game_id'] and data['period']=='fullTime','Wrong or incomplete Ligue 1 match'
    assert pd.Timestamp(data['date']).date()==pd.Timestamp(game['start_time']).date(),'Ligue 1 date mismatch'
    players=[];team_rows=[]
    for side,native in [('A','away'),('B','home')]:
        team=data[native];common=base(game,side)
        assert team['clubId']==f"l1_championship_club_{data['season']}_{common['team_id']}",'Ligue 1 native club identity mismatch'
        if team['clubIdentity'].get('shortId') is not None:
            assert str(team['clubIdentity']['shortId'])==common['team_id'],'Ligue 1 side mismatch'
        score=team['score'];score=score.get('fullTime',score.get('total')) if isinstance(score,dict) else score
        assert score==game['score'+side],('Ligue 1 score mismatch',score,game['score'+side])
        pool=team['players'];pool=pool.values() if isinstance(pool,dict) else pool
        for player in pool:
            identity=player['playerIdentity'];raw=player.get('stats') or {};opta=identity.get('shortOptaId')
            pid=str(opta) if opta is not None else player['id']
            row=common|dict(official_player_id=pid,source_player_id=player['id'],opta_player_id=str(opta) if opta is not None else None,
                            id_namespace='opta' if opta is not None else 'ligue1_season_club_player',
                            player_name=' '.join([identity.get('firstName') or '',identity.get('lastName') or '']).strip() or None,
                            position=str(player['position']) if player.get('position') is not None else None,started=player.get('startedMatch'),played=player.get('playedMatch'),minutes=player.get('minutesPlayed'),
                            goals=player.get('goals'),assists=player.get('goalsAssists'),**{name:raw.get(field) for name,field in LIGUE_FIELDS.items()},
                            field_pointers={name:'/'+native+'/players/'+player['id']+'/stats/'+field for name,field in LIGUE_FIELDS.items()},
                            source=source,raw_stats=raw,minutes_basis='Official match player minutesPlayed')
            if row['minutes'] is not None:assert 0<=row['minutes']<=150
            for name in LIGUE_FIELDS:assert row[name] is None or isinstance(row[name],(int,float)),name
            players.append(row)
        raw=team.get('stats') or {}
        team_rows.append(common|dict(passes=raw.get('passes'),shots=raw.get('scoringAttempts'),shots_on_target=raw.get('ontargetScoringAttempts'),
                                      possession_pct=raw.get('possessionPercentage'),big_chances=raw.get('bigChances'),source=source,raw_stats=raw,
                                      **ligue_expected_goals(raw,native)))
    assert not pd.DataFrame(players).duplicated(['official_player_id','side']).any()
    return dict(players=players,teams=team_rows,sources=[source],
                caveat='Positive team expectedGoals values are retained. Zero with nonzero/unknown shots is an ambiguous placeholder and normalizes to NULL; explicit zero shots permits zero xG. Raw values remain. Distance/high-speed-run zero fields remain unverified. Sparse player-stat omissions remain NULL.')


def parse_bundesliga(game,stats,rankings,lineup,sources):
    assert isinstance(stats,dict) and isinstance(rankings,dict) and isinstance(lineup,dict),'Missing Bundesliga response object'
    rows={};teams=[];identity={};ids=list(map(str,json.loads(game['native_team_ids_json'])))
    for side,native in [('A','away'),('B','home')]:
        common=base(game,side);eleven=lineup[native]['startingEleven']['persons'];assert len(eleven)==11,'Incomplete official starting eleven'
        for group in ['startingEleven','bench']:
            for player in lineup[native].get(group,{}).get('persons',[]):
                pid=player['dflDatalibraryObjectId'];assert pid not in identity,'Duplicated official lineup ID'
                identity[pid]=(side,player)
        values={name:(stats.get(field) or {}).get(native+'Value') for field,name in BUN_TEAM.items()}
        for name,v in values.items():assert v is None or isinstance(v,(int,float)),name
        teams.append(common|values|dict(source=sources['stats'],source_update_utc=stats.get('lastUpdateDateTime')))
    for metric,field in BUN_PLAYER.items():
        for pid,item in (rankings.get('playerRankings',{}).get(metric) or {}).items():
            assert item['dflDatalibraryObjectId']==pid and pid in identity,'Player measurement absent from dated lineup'
            side,player=identity[pid];common=base(game,side);assert item['club']['dflDatalibraryClubId']==common['team_id'],'Ranking team/native game mismatch'
            if pid not in rows:
                rows[pid]=common|dict(official_player_id=pid,player_name=player['name'],position=player['role'],
                                      started=any(p['dflDatalibraryObjectId']==pid for p in lineup['away' if side=='A' else 'home']['startingEleven']['persons']),
                                      **dict.fromkeys(BUN_PLAYER.values()),pass_efficiency=None,field_evidence={},source=sources['rankings'])
            value=item.get('value');assert value is None or isinstance(value,(int,float))
            rows[pid][field]=value;rows[pid]['field_evidence'][field]=dict(pointer='/playerRankings/'+metric+'/'+pid+'/value',source=sources['rankings'])
    for native,side in [('away','A'),('home','B')]:
        for item in (stats.get('passEfficiency') or {}).get(native,[]):
            pid=item['dflDatalibraryObjectId'];assert pid in identity and identity[pid][0]==side
            if pid in rows:
                rows[pid]['pass_efficiency']=item['value'];rows[pid]['field_evidence']['pass_efficiency']=dict(source=sources['stats'],pointer='/passEfficiency/'+native,coverage='Only displayed top players; absent values are not zero.')
    assert rows,'No player measurements'
    return dict(players=list(rows.values()),teams=teams,sources=list(sources.values()),
                caveat='Physical values are per completed match. No playing minutes are inferred. Absent ranked statistics remain NULL; passes/challenges preserve official field definitions. Source update dates are retained, not claimed to prove original publication vintage.')


def main():
    p=argparse.ArgumentParser();p.add_argument('--league',choices=['bundesliga','ligue1'],required=True);p.add_argument('--all',action='store_true');p.add_argument('--workers',type=int,default=4);a=p.parse_args()
    league={'bundesliga':'Bundesliga','ligue1':'Ligue 1'}[a.league]
    with read_db(PREVIOUS/'expanded.sqlite') as c:games=[dict(r) for r in c.execute("SELECT * FROM soccer_games WHERE league=? AND date BETWEEN '2021-01-01' AND '2026-09-30' ORDER BY date,game_id",(league,))]
    cached=cached_sources();by_native={}
    for url,source in cached.items():
        if '/stats.json' in url:by_native[url.rsplit('/',2)[1]]=source
        else:by_native[url.rsplit('/',1)[1]]=source
    db=sqlite3.connect(ROOT_OUT/'soccer_additional.sqlite',timeout=60)
    db.executescript('CREATE TABLE IF NOT EXISTS games(league TEXT,game_id TEXT,body TEXT,PRIMARY KEY(league,game_id)); CREATE TABLE IF NOT EXISTS issues(league TEXT,game_id TEXT,body TEXT,PRIMARY KEY(league,game_id));')
    done={r[0] for r in db.execute("SELECT game_id FROM games WHERE league=? AND json_extract(body,'$.parser_version')=?",(league,PARSER_VERSION))}
    if not a.all:
        # Three dates span the historical window, plus the public validation game.
        games=[games[0],games[len(games)//2],games[-1]]+[g for g in games if g['official_game_id'] in ['DFL-MAT-J03YGU','l1_championship_match_71794']]
        games=list({g['game_id']:g for g in games}.values())
    tasks=[g for g in games if g['game_id'] not in done];client=OfficialClient(per_second=2);counts=collections.Counter();mark=10
    def fetch(g):
        sources=[]
        try:
            source=by_native.get(g['official_game_id'])
            if source:data=retained(source)
            elif a.league=='ligue1':
                data,source=client.get('https://ma-api.ligue1.fr/championship-match/'+g['official_game_id'],'Recover Ligue 1 per-player match actions '+g['official_game_id'])
            else:raise ValueError('No retained official match statistics URL; requires calendar route recovery')
            sources.append(source)
            if a.league=='ligue1':record=parse_ligue(g,data,source)
            else:
                base_url=source['url'].removesuffix('/stats.json');parts={};evidence={'stats':source}
                for field in ['rankings','lineup']:
                    parts[field],evidence[field]=client.get(base_url+'/'+field+'.json','Dated Bundesliga player '+field+': '+g['official_game_id'],kind='official_player_match_measurements');sources.append(evidence[field])
                record=parse_bundesliga(g,data,parts['rankings'],parts['lineup'],evidence)
            record.update(game_id=g['game_id'],league=league,official_game_id=g['official_game_id'],date=g['date'],collected_at_utc=stamp(),parser_version=PARSER_VERSION)
            return g['game_id'],record,None
        except Exception as exc:return g['game_id'],None,dict(reason=type(exc).__name__+': '+str(exc),sources=sources)
    progress_path=ROOT_OUT/(a.league+'_additional_progress.json')
    progress=dict(at_utc=stamp(),processed=0,total=len(tasks),percent=0 if tasks else 100,counts={},scope='full window' if a.all else 'pilot');dump(progress_path,progress);print(json.dumps(progress),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
        for n,(gid,row,error) in enumerate(pool.map(fetch,tasks),1):
            with db:
                if row:
                    db.execute('INSERT OR REPLACE INTO games VALUES (?,?,?)',(league,gid,json.dumps(row,allow_nan=False)))
                    db.execute('DELETE FROM issues WHERE league=? AND game_id=?',(league,gid));counts['games']+=1;counts['player_rows']+=len(row['players']);counts['team_rows']+=len(row['teams'])
                else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?,?)',(league,gid,json.dumps(error)));counts['issues']+=1
            if n*100>=mark*len(tasks) or n==len(tasks):
                progress=dict(at_utc=stamp(),processed=n,total=len(tasks),percent=round(100*n/len(tasks),1),counts=dict(counts),scope='full window' if a.all else 'pilot');dump(progress_path,progress);print(json.dumps(progress),flush=True);mark+=10
    db.close()


if __name__=='__main__':main()
