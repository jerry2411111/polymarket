"""Merge verified Maker records using explicit IDs and proof-backed zeros."""
import collections
import json
import math

import pandas as pd

from common import OUT, ROOT_OUT, dump, read_db, stamp
from laliga_maker_api import FIELDS

ADDITIVE = ['shots', 'shots_on_target', 'key_passes', 'passes', 'passes_completed',
            'final_third_passes_completed', 'interceptions', 'recoveries',
            'tackles_won', 'aerials_won', 'saves', 'goals_reported', 'assists_reported']


def records():
    validation = json.loads((ROOT_OUT/'laliga_maker_validation.json').read_bytes())
    assert validation['status'] == 'PASS'
    with read_db(ROOT_OUT/'laliga_maker.sqlite') as c:
        return [json.loads(b) for b, in c.execute('SELECT body FROM fixtures ORDER BY game_id')]


def prepared(dated_identity=False):
    games = records()
    # Compatibility mode reproduces the older UUID propagation assumption.
    # New source integrations use dated_identity=True: audits found club UUIDs
    # with conflicting native league identities across dated fixtures.
    links = collections.defaultdict(set)
    for game in games:
        for r in game['players']:
            if r['opta_player_id']:
                links[r['maker_player_id']].add(r['opta_player_id'])
    assert all(len(v) == 1 for v in links.values())
    rows, proofs, identity = [], [], []
    for game in games:
        for side in ['A', 'B']:
            roster = [r for r in game['players'] if r['side'] == side]
            active = [r for r in roster if r['played']]
            team = next(r for r in game['teams'] if r['side'] == side)
            # A side with any recorded lineup/entry/minute inconsistency does
            # not support a completeness proof. Its explicit values remain.
            complete = (not any(r['side'] == side for r in game['issues'])
                        and sum(r['started'] for r in active) == 11
                        and all(r['minutes_reported'] is not None for r in active))
            for field in ADDITIVE:
                known = [r[field] for r in active if r[field] is not None]
                total = team[field]
                assert all(v >= 0 and float(v).is_integer() for v in known)
                if not complete or total is None or math.fsum(known) != total:
                    continue
                for r in active:
                    if r[field] is None:
                        proofs.append(dict(game_id=game['game_id'], side=side,
                            maker_player_id=r['maker_player_id'], field=field,
                            raw_value=None, derived_value=0., team_total=total,
                            known_sum=math.fsum(known), participants=len(active),
                            source_sha256=game['source']['sha256']))
                        r[field] = 0.
            for r in roster:
                pid = r['opta_player_id']
                if pid is None and r['maker_player_id'] in links and not dated_identity:
                    pid = next(iter(links[r['maker_player_id']]))
                    basis = 'Same native UUID with explicit Opta image ID on another dated record'
                elif pid:
                    basis = 'Explicit Opta image ID on this dated record'
                else:
                    basis = 'Maker native UUID; no cross-provider identity asserted'
                native = pid or 'maker:'+r['maker_player_id']
                row = {k:r[k] for k in ['game_id','official_game_id','league','date',
                    'available_at_utc','side','team_id','player_name','started','played']}
                row.update({k:r.get(k) for k in FIELDS})
                row.update(official_player_id=native, minutes=r['minutes_reported'],
                    minutes_basis='Official Maker reported minutes, including provider rounding',
                    goals=r['goals_reported'], assists=r['assists_reported'],
                    position=None, player_type=None)
                if dated_identity:
                    row.update(maker_player_id=r['maker_player_id'],shirt_number=r['shirt_number'],
                               maker_lineup_pointer=r['lineup_pointer'])
                rows.append(row)
                identity.append(dict(game_id=r['game_id'],side=side,
                    maker_player_id=r['maker_player_id'],official_player_id=native,
                    basis=basis,source_sha256=r['source']['sha256']))
    pd.DataFrame(proofs).to_parquet(OUT/'maker_zero_proofs.parquet',index=False)
    pd.DataFrame(identity).to_parquet(OUT/'maker_identity_links.parquet',index=False)
    return games, pd.DataFrame(rows), dict(games=len(games),rows=len(rows),
        proof_backed_zeros=len(proofs), raw_nulls_unchanged=True,
        identity_basis=dict(collections.Counter(r['basis'] for r in identity)))


def merge_players(players,dated_identity=False):
    games, fresh, audit = prepared(dated_identity=dated_identity)
    if dated_identity:
        from laliga_dated_identity import reconcile
        fresh,identity_audit=reconcile(games,fresh,players,OUT)
        audit['dated_identity']=identity_audit
    cross = players[['league','official_player_id','player_id']].drop_duplicates()
    assert cross.groupby(['league','official_player_id']).player_id.nunique().max() == 1
    mapping = cross.set_index(['league','official_player_id']).player_id.to_dict()
    fresh['player_id'] = [mapping.get((r.league,r.official_player_id),
                                    'EU_LAL:'+r.official_player_id) for r in fresh.itertuples()]
    assert not fresh.duplicated(['game_id','side','player_id']).any()
    index=['game_id','side','official_player_id']
    old=players.set_index(index);new=fresh.set_index(index)
    overlap=old.index.intersection(new.index)
    for field in ['played','started']:
        a,b=old.loc[overlap,field],new.loc[overlap,field]
        assert (a.isna()|b.isna()|a.eq(b)).all(),field
    overlapping_games=set(fresh.game_id)&set(players.game_id)
    unmatched=old.loc[old.index.get_level_values('game_id').isin(overlapping_games)].drop(index=overlap)
    # Four older lineup-only records have no usable minutes. Preserve their
    # identities/fields, but they cannot produce a second performance record
    # for an unlinked Maker identity. Any known-minute conflict needs repair.
    if dated_identity:
        # Direct league participant records are authoritative for overlapping
        # games. Unlinked supplementary rows cannot introduce another copy of
        # an already recorded player. Retain the original known minutes.
        direct=set(identity_audit['direct_game_ids'])
        remaining=unmatched[~unmatched.index.get_level_values('game_id').isin(direct)]
        assert remaining.minutes.isna().all()
    else:assert unmatched.minutes.isna().all()
    joined=new.combine_first(old)
    for field in ['minutes','minutes_basis','position','player_type']:
        known=old[field].dropna()
        if field=='minutes_basis':known=old.loc[old.minutes.notna(),field].dropna()
        joined.loc[known.index,field]=known
    times=pd.concat([pd.to_datetime(old.available_at_utc,utc=True,format='mixed'),
                     pd.to_datetime(new.available_at_utc,utc=True,format='mixed')],axis=1)
    joined['available_at_utc']=times.max(axis=1)
    joined=joined.reset_index()
    assert not joined.duplicated(['game_id','side','player_id']).any()
    audit.update(overlap_games=len(overlapping_games),exact_overlap_players=len(overlap),
                 retained_unlinked_prior_rows_without_minutes=int(unmatched.minutes.isna().sum()),
                 retained_direct_prior_rows_with_minutes=int(unmatched.minutes.notna().sum()),
                 added_rows=len(joined)-len(players))
    audit['matched_existing_person_rows'] = sum((r.league,r.official_player_id) in mapping for r in fresh.itertuples())
    dump(OUT/'maker_merge_audit.json',dict(at_utc=stamp(),**audit))
    return joined, audit
