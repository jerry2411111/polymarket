"""Verify recovered passing facts directly against their retained official PDFs."""
import hashlib,json
from pathlib import Path
from common import PROJECT,PREVIOUS,ROOT_OUT,read_db,dump,stamp
from collect_uefa_passing import parse,report_url


def main():
    with read_db(PREVIOUS/'expanded.sqlite') as c:games={r['game_id']:dict(r) for r in c.execute("SELECT * FROM soccer_games WHERE league='UEFA Champions League'")}
    with read_db(ROOT_OUT/'uefa_passing.sqlite') as c:
        bodies=[json.loads(b) for b, in c.execute('SELECT body FROM reports')];issues=[dict(r) for r in c.execute('SELECT * FROM issues')]
    recovered=[rows for rows in bodies if rows[0].get('parser_version')==2];count=0;methods={}
    for rows in recovered:
        source=rows[0]['source'];raw=Path(source['raw_file']);raw=raw if raw.is_absolute() else PROJECT/raw
        blob=raw.read_bytes();assert hashlib.sha256(blob).hexdigest()==source['sha256']
        lineup_raw=Path(source['lineup_raw_file']).read_bytes();assert hashlib.sha256(lineup_raw).hexdigest()==source['lineup_sha256']
        game=games[rows[0]['game_id']];assert source['url']==report_url(game)
        fresh=parse(blob,json.loads(lineup_raw),game,source);assert fresh==rows
        assert len({(r['side'],r['official_player_id']) for r in rows})==len(rows)
        for row in rows:
            method=row['name_match_evidence']['method'];methods[method]=methods.get(method,0)+1
        count+=len(rows)
    dump(ROOT_OUT/'uefa_recovery_validation.json',dict(at_utc=stamp(),status='PASS',recovered_reports=len(recovered),recovered_player_rows=count,total_reports=len(bodies),
         total_player_rows=sum(map(len,bodies)),remaining_issues=len(issues),name_matching_methods=methods,
         checks='Raw PDF and lineup hashes, native game/team/jersey/player mapping, exact replay of every recovered field, official season directory. Documented aliases are ID-scoped and birth-date checked.'))
    print(json.dumps(dict(status='PASS',recovered_reports=len(recovered),recovered_player_rows=count,remaining_issues=len(issues))),flush=True)


if __name__=='__main__':main()
