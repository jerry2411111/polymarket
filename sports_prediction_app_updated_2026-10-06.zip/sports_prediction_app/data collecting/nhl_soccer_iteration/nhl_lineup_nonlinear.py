"""Fixed shallow nonlinear learner, with a dated-lineup feature ablation.

Select on 2024/25 proper probability scores. Prices never enter a model input.
The same-clock regulation model remains the comparator, not a searched loser cut.
"""
import argparse
import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, REPORTS, PREVIOUS, read_db, dump, stamp, file_sha256
import nhl_player_strength as roster
from nhl_lineup_model import FIELDS

LABEL = 'nhl_lineup_nonlinear'
WORK = ROOT_OUT / '_work' / LABEL
RESULT = ROOT_OUT / 'simulation_results' / LABEL
REFERENCE = ROOT_OUT / 'simulation_results/nhl_lineup_model'
NAMES = ['lineup_catboost_base', 'lineup_catboost_updated']


def initialize():
    import models
    WORK.mkdir(parents=True, exist_ok=True)
    RESULT.mkdir(parents=True, exist_ok=True)
    plan = dict(at_utc=stamp(),
        hypothesis='Projected identities are mostly correct, but linear strength updates did not improve probability quality. Test shallow nonlinear interactions of the existing player/team strengths and the four dated lineup updates.',
        candidate=dict(models.CANDIDATES['granular_catboost']),
        implementation='Existing CatBoost: depth2,300 iterations, learning_rate0.035,l2_leaf_reg15,seed42. Native missing handling; past-only purged temperature calibration. No additional parameter search.',
        variants=dict(zip(NAMES, ['Original player-strength inputs', 'Same inputs plus four dated lineup changes'])),
        reference='Saved same-clock control primary regulation/OT forecasts; original pre12 forecast and application remain unchanged.',
        years=[2024,2025], training='Expanding monthly from2021; every training and calibration result strictly before the relevant forecast boundary.',
        gate='Candidate must improve pooled logloss and Brier over same-clock primary;2025logloss must improve; pooled winner accuracy>=52%. Select lowest pooled logloss among qualifying variants. Report paired month-block uncertainty, not a multiple-testing-adjusted significance claim.',
        betting='After probability scores, diagnostic flat20 cash-only accounts on identical paired later quotes and unchanged secondary logistic confirmation. Both probabilities/price>=1.10, original single-side selection. Do not choose models on account returns.',
        diagnosis='Inspect fixed earlier losing cases, probability buckets, score changes and feature importance. No losing teams/months removed.',
        evaluation='No new2026evaluation unless gate passes;2026already inspected and remains retrospective.', app_changed=False)
    path=RESULT/'experiment_plan.json'
    if path.exists():
        assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else: dump(path,plan)
    return plan


def build():
    initialize()
    import features, nhl_identity_features
    original_path=ROOT_OUT/'nhl_roster_strength_features.parquet'
    projected_path=ROOT_OUT/'nhl_projected_strength_features.parquet'
    projected=pd.read_parquet(projected_path)
    proof=json.loads((REFERENCE/'publication_validation.json').read_bytes())
    assert file_sha256(projected_path)==proof['sha256']
    games,_,_,_=roster.load()
    g,o,p,_,stats,metrics,_=features.sources('nhl',include_preseason=True)
    needed=['game_id','side','available_at_utc','player_id','official_player_id','minutes','position','saves','shots_against']+metrics+['played']
    p=roster.apply_repairs(p[list(dict.fromkeys(needed))])
    base,_=nhl_identity_features.derive(g,o,p,stats,metrics,repaired=True,regulation_labels=games)
    original=pd.read_parquet(original_path)
    frame=base.merge(original[['game_id']+roster.FIELDS],on='game_id',validate='one_to_one')
    frame=frame.merge(projected[['game_id']+FIELDS],on='game_id',validate='one_to_one')
    frame['prediction_time']=frame.game_id.map(projected.set_index('game_id').prediction_time)
    assert frame.prediction_time.ge(base.prediction_time).all()
    assert frame.prediction_time.lt(frame.start_time).all()
    target=WORK/'nhl_features.parquet';frame.to_parquet(target,index=False)
    old=json.loads((REFERENCE/'feature_validation.json').read_bytes())
    # The published projection facts must reconstruct the previous matrix exactly.
    assert file_sha256(target)==old['feature_sha256'], 'Rebuilt matrix differs from previous dated-feature test'
    source=dict(at_utc=stamp(),status='PASS',rows=len(frame),columns=len(frame.columns),
                feature_sha256=file_sha256(target),previous_matrix_exact_replay=True,
                source_sha256={p.name:file_sha256(p) for p in [original_path,projected_path]},
                no_market_features=True)
    dump(RESULT/'feature_validation.json',source)
    print(json.dumps(source),flush=True)


def probability_metrics(frame):
    from sklearn.metrics import accuracy_score, f1_score, recall_score, log_loss
    rows=[]
    for variant,g in frame.groupby('variant'):
        for year,part in [('pooled',g)]+list(g.groupby(g.date.str[:4])):
            for subset,part2 in [('all',part),('updated',part[part[FIELDS[3]].eq(1)])]:
                if len(part2):
                    y=part2.target.to_numpy(int);prob=part2[['p0','p1']].to_numpy();pick=prob.argmax(axis=1)
                    recall=recall_score(y,pick,labels=[0,1],average=None,zero_division=0)
                    rows.append(dict(variant=variant,year=year,subset=subset,n=len(part2),
                        accuracy=accuracy_score(y,pick),logloss=log_loss(y,prob,labels=[0,1]),
                        brier=float(np.mean(np.sum((prob-np.eye(2)[y])**2,axis=1))),
                        macro_f1=f1_score(y,pick,labels=[0,1],average='macro',zero_division=0),
                        balanced_accuracy=float(recall.mean()),away_recall=float(recall[0]),home_recall=float(recall[1])))
    return pd.DataFrame(rows)


def train():
    import models
    initialize()
    proof=json.loads((RESULT/'feature_validation.json').read_bytes())
    assert file_sha256(WORK/'nhl_features.parquet')==proof['feature_sha256']
    frame=pd.read_parquet(WORK/'nhl_features.parquet')
    models.OUT=WORK
    for name in NAMES:
        models.CANDIDATES[name]=dict(models.CANDIDATES['granular_catboost'],exclude_columns=FIELDS if name==NAMES[0] else [])
    raw=models.run('nhl','development',NAMES)
    previous=pd.read_parquet(REFERENCE/'development_predictions.parquet')
    control=previous[previous.variant.eq('control')].copy()
    # Keep independent strong-logistic confirmation unchanged in both variants.
    secondary=control[['game_id','second_p0','second_p1']]
    raw=raw.merge(secondary,on='game_id',validate='many_to_one')
    raw=raw.merge(frame[['game_id',FIELDS[3]]],on='game_id',validate='many_to_one')
    for name,g in raw.groupby('variant'):
        assert set(g.game_id)==set(control.game_id)
        cols=['prediction_time','target','train_label_max','calibration_label_max']
        pd.testing.assert_frame_equal(g.set_index('game_id')[cols].sort_index(),control.set_index('game_id')[cols].sort_index(),check_dtype=False)
    joined=pd.concat([control,raw],ignore_index=True)
    assert joined.train_label_max.lt(joined.prediction_time).all()
    assert joined.calibration_label_max.lt(joined.prediction_time).all()
    assert joined.calibration_train_label_max.lt(joined.calibration_prediction_min).all()
    joined.to_parquet(RESULT/'development_predictions.parquet',index=False)
    metrics=probability_metrics(joined);metrics.to_csv(RESULT/'development_metrics.csv',index=False)
    design=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
    replays=0;importance=[]
    for name in NAMES:
        pkg=pickle.loads((WORK/'model_runs/nhl/development'/(name+'.pkl')).read_bytes())
        sample=raw[raw.variant.eq(name)&raw.fold.eq(pkg['boundary'].strftime('%Y-%m'))].head(12)
        x=design.loc[sample.game_id,pkg['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
        prediction=models.apply_calibration(pkg['model'].predict_proba(x),pkg['calibrator'])
        assert np.allclose(prediction,sample[['p0','p1']],atol=1e-12,rtol=0)
        assert not any(t in c.lower() for c in pkg['columns'] for t in ['price','odds','market'])
        if name==NAMES[0]:assert not set(FIELDS)&set(pkg['columns'])
        else:assert set(FIELDS).issubset(pkg['columns'])
        for col,value in zip(pkg['columns'],pkg['model'].feature_importances_):
            importance.append(dict(variant=name,feature=col,importance=float(value),fit_boundary=pkg['boundary'],meaning='CatBoost PredictionValuesChange; descriptive fitted importance, not causal'))
        replays+=len(sample)
    pd.DataFrame(importance).to_csv(RESULT/'feature_importance.csv',index=False)
    score=metrics[metrics.subset.eq('all')].set_index(['variant','year'])
    gates={}
    for name in NAMES:
        a=score.loc[(name,'pooled'),:];b=score.loc[('control','pooled'),:]
        gates[name]=bool(a.logloss<b.logloss and a.brier<b.brier and a.accuracy>=.52 and score.loc[(name,'2025'),'logloss']<score.loc[('control','2025'),'logloss'])
    eligible=[n for n in NAMES if gates[n]]
    selected=min(eligible,key=lambda n:score.loc[(n,'pooled'),'logloss']) if eligible else None
    dump(RESULT/'selection.json',dict(at_utc=stamp(),gates=gates,selected=selected,adopted=False,evaluation2026_run=False))
    diagnose(joined)
    import nhl_lineup_model as accounts
    old=accounts.RESULT
    try:
        accounts.RESULT=RESULT
        accounts.account_test(joined)
    finally: accounts.RESULT=old
    checks=dict(status='PASS',at_utc=stamp(),forecast_replays=replays,forecast_rows=len(joined),
                same_forecast_game_and_training_clocks=True,price_features_excluded=True,
                selected=selected,app_changed=False,evaluation2026_run=False)
    dump(RESULT/'model_validation.json',checks)
    print(json.dumps(checks),flush=True)


def diagnose(p):
    base=p[p.variant.eq('control')].set_index('game_id')
    cases=[];buckets=[];paired=[]
    rng=np.random.default_rng(731)
    for name,g in p.groupby('variant'):
        g=g.copy();y=g.target.to_numpy(int);prob=g[['p0','p1']].to_numpy()
        g['model_pick']=prob.argmax(axis=1);g['confidence']=prob.max(axis=1)
        g['correct']=g.model_pick.eq(g.target);g['log_loss']=-np.log(prob[np.arange(len(g)),y])
        g['confidence_bucket']=pd.cut(g.confidence,[.5,.55,.60,.65,.70,.80,1.],include_lowest=True)
        for (year,bucket),part in g.groupby([g.date.str[:4],'confidence_bucket'],observed=True):
            buckets.append(dict(variant=name,year=year,bucket=str(bucket),games=len(part),
                mean_confidence=part.confidence.mean(),win_rate=part.correct.mean(),logloss=part.log_loss.mean()))
        if name=='control': continue
        control=base.loc[g.game_id];yp=control.target.to_numpy(int)
        prior=-np.log(control[['p0','p1']].to_numpy()[np.arange(len(g)),yp])
        g['control_loss']=prior;g['loss_change']=g.log_loss-prior
        monthly=g.groupby(g.prediction_time.dt.strftime('%Y-%m')).loss_change.agg(['sum','count']).to_numpy()
        ix=rng.integers(0,len(monthly),(3000,len(monthly)));sample=monthly[ix]
        distribution=sample[:,:,0].sum(axis=1)/sample[:,:,1].sum(axis=1)
        paired.append(dict(variant=name,paired_loss_change=g.loss_change.mean(),
             month_block_95_interval=np.quantile(distribution,[.025,.975]).tolist(),multiple_testing_adjusted=False))
        # Retain adverse and improved cases for mechanism inspection; no case is removed.
        fields=['game_id','date','target','p0','p1','confidence','correct',FIELDS[3],'log_loss','control_loss','loss_change']
        cases.extend(g.nlargest(12,'loss_change')[fields].assign(variant=name,case_type='worse').to_dict('records'))
        cases.extend(g.nsmallest(12,'loss_change')[fields].assign(variant=name,case_type='better').to_dict('records'))
    pd.DataFrame(buckets).to_csv(RESULT/'confidence_buckets.csv',index=False)
    pd.DataFrame(cases).to_csv(RESULT/'largest_probability_errors.csv',index=False)
    dump(RESULT/'paired_loss.json',paired)


def diagnose_bets():
    bets=pd.read_parquet(RESULT/'development_bets.parquet')
    bets=bets[bets.variant.eq('control')&bets.year.eq(2025)].copy()
    bets['band']=pd.cut(bets.probability,[0,.4,.5,.6,.7,1],include_lowest=True)
    rows=[]
    for (provider,band),g in bets.groupby(['provider','band'],observed=True):
        rows.append(dict(provider=provider,year=2025,probability_band=str(band),bets=len(g),
            mean_forecast=g.probability.mean(),mean_price=g.price.mean(),win_rate=g.won.mean(),
            profit=g.profit.sum(),gross_losses=-g.loc[g.profit.lt(0),'profit'].sum(),gross_gains=g.loc[g.profit.gt(0),'profit'].sum()))
    result=pd.DataFrame(rows);result.to_csv(RESULT/'selected_bet_probability_diagnosis.csv',index=False)
    fields=['provider','game_id','date','teamA','teamB','side','probability','price','won','stake','profit','source_utc','entry_request_id','entry_pointer']
    cases=bets[~bets.won.astype(bool)].sort_values('probability',ascending=False).groupby('provider').head(8)[fields]
    cases.to_csv(RESULT/'highest_probability_losing_bets.csv',index=False)
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        quality=pd.read_sql_query('SELECT game_id,side,xg,xg_against,model_goals_saved,finishing_residual FROM nhl_team_shot_quality',db)
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games=pd.read_sql_query('SELECT game_id,scoreA,scoreB FROM nhl_games',db)
    quality['side']=quality.side.map({'A':0,'B':1})
    review=cases.merge(quality,on=['game_id','side'],how='left',validate='many_to_one').merge(games,on='game_id',validate='many_to_one')
    review['selected_team']=np.where(review.side.eq(0),review.teamA,review.teamB)
    review['diagnostic_only']=True
    review.to_csv(RESULT/'post_game_case_review.csv',index=False)
    return result


def finish():
    from final_pipeline import discard_work,cleanup,validate
    choice=json.loads((RESULT/'selection.json').read_bytes())
    proof=json.loads((RESULT/'model_validation.json').read_bytes());assert proof['status']=='PASS'
    assert choice['selected'] is None, 'Passing candidate needs an explicit evaluation action before final cleanup'
    metrics=pd.read_csv(RESULT/'development_metrics.csv');annual=pd.read_csv(RESULT/'development_annual.csv')
    bands=diagnose_bets()
    report=REPORTS/(LABEL+'.md')
    lines=['# NHL shallow nonlinear probability comparison','',
      'The same dated inputs and forecast clocks were tested with a fixed shallow CatBoost learner, with and without the four projected-lineup changes. Models expand monthly from2021.2024/25 chooses the model; prices are excluded from inputs. The control is the retained regulation/OT learner at the same information clocks.','',
      'Recipe: depth2,300iterations,learning_rate0.035,l2_leaf_reg15,seed42. Missing values are handled natively. Calibration uses purged earlier predictions; every source/training/calibration cutoff is checked. No parameter grid was run.','',
      '|Variant|Year|Games|Accuracy|Log loss|Brier|Macro F1|','|---|---|---:|---:|---:|---:|---:|']
    for r in metrics[metrics.subset.eq('all')].itertuples():
        lines.append(f'|{r.variant}|{r.year}|{r.n}|{100*r.accuracy:.2f}%|{r.logloss:.6f}|{r.brier:.6f}|{r.macro_f1:.4f}|')
    lines+=['','Selection rule: improve pooled log loss and Brier, improve2025log loss, and retain overall accuracy at least52%. Neither variant passed. New2026predictions were not run. Same-period monthly-block uncertainty and largest adverse/improved cases are in the accompanying results. These do not correct for the many historical research comparisons.','',
      'Accounts below are diagnostics using the unchanged rule: primary and independent strong-logistic probability/price>=1.10, one selected side,flat$20,annual$2,000cash-only balance, paired post-information quotes. This later-entry cohort is not the full pre12 baseline.2024price coverage is partial. Daily account Sharpe uses sqrt365.25; historical price points are not proof of executable fills.','',
      '|Provider|Year|Variant|Bets|Bet win rate|Return|Sharpe|Drawdown|','|---|---:|---|---:|---:|---:|---:|---:|']
    for r in annual.itertuples():
        fmt=lambda v: 'n/a' if pd.isna(v) else f'{v:.2f}'
        lines.append(f'|{r.provider}|{r.year}|{r.variant}|{r.funded_games}|{fmt(r.win_rate_pct)}%|{fmt(r.return_pct)}%|{fmt(r.sharpe)}|{fmt(r.max_drawdown_pct)}%|')
    lines+=['','No rejected fit or duplicate input matrix is retained. Published dated player facts, original responses, metrics, predictions, accounts and this reproducible script remain. The NBA/MLB application is unchanged. The Sharpe/return goal remains unmet; previously inspected2026results remain retrospective rolling evaluations.','',
      'Reproduce: nhl_lineup_nonlinear.py build; nhl_lineup_nonlinear.py train; nhl_lineup_nonlinear.py finish. Required input publication: nhl_roster_strength_features and nhl_projected_strength_features; prior clock-control predictions: simulation_results/nhl_lineup_model.']
    lines+=['','Further loss inspection: these bands describe purchased outcomes, not predicted winners on every game. They are diagnostics, not new filters. Small groups and provider differences prevent asserting a universal confidence cutoff. Highest-probability losing bets preserve names, quote clocks and raw source pointers.','',
      '|Provider|Purchased probability band|Bets|Mean forecast|Actual win rate|Profit USD|','|---|---|---:|---:|---:|---:|']
    for r in bands.itertuples():lines.append(f'|{r.provider}|{r.probability_band}|{r.bets}|{100*r.mean_forecast:.2f}%|{100*r.win_rate:.2f}%|{r.profit:.2f}|')
    review=pd.read_csv(RESULT/'post_game_case_review.csv')
    review=review[review.provider.eq('polymarket')].sort_values('probability',ascending=False).head(3)
    lines+=['','Post-game review of the three highest-probability losing Polymarket bets:','',
      '|Game|Bought team|Forecast|Final away:home score|Selected-team internal xG|Opponent internal xG|','|---|---|---:|---|---:|---:|']
    for r in review.itertuples():lines.append(f'|{r.game_id}|{r.selected_team}|{100*r.probability:.2f}%|{int(r.scoreA)}:{int(r.scoreB)}|{r.xg:.2f}|{r.xg_against:.2f}|')
    lines+=['','These are post-game diagnostics, excluded from predictors. The existing shot-quality model, fitted using prior-year NHL play-by-play, assigned the losing selected teams more total expected goals in these examples. Actual finishing and goals conceded differed substantially from those estimates. This is consistent with game-level finishing/goalkeeping variation; it does not prove luck, validate the pre-match probabilities, or explain every loss. Internal xG is not an official NHL statistic. Raw game and quote identities remain linked.']
    report.write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False)
    old=old[~old.source_result_file.str.startswith(LABEL+'/',na=False)]
    parts=[old]+[pd.read_csv(RESULT/f).assign(source_result_file=LABEL+'/'+f,sport='nhl') for f in ['development_metrics.csv','development_annual.csv']]
    pd.concat(parts,ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';decisions=json.loads(path.read_bytes())
    decisions[LABEL]=dict(plan=json.loads((RESULT/'experiment_plan.json').read_bytes()),selection=choice,validation=proof);dump(path,decisions)
    if WORK.exists():discard_work(WORK)
    cleanup();app=validate()
    receipt=dict(status='PASS',at_utc=stamp(),selection=choice,validation=proof,app_validation=app,temporary_work_removed=True,goal_achieved=False,report=str(report))
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    path=ROOT_OUT/'retention/retained_artifacts.json';manifest=json.loads(path.read_bytes())
    manifest['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    manifest.update(updated_utc=stamp(),retained_scripts=len(manifest['scripts']),latest_simulation_update=dict(result=str(RESULT.relative_to(ROOT_OUT)),adopted=False,report=str(report)));dump(path,manifest)
    path=ROOT_OUT/'research_continuation.json';state=json.loads(path.read_bytes())
    state.update(at_utc=stamp(),current_job=None,live_sessions=[],running_jobs=[],last_action='Completed fixed shallow CatBoost dated-player ablation on2024/25; rejected on earlier probability scores, retained case diagnostics and cash checks; trial work removed.',
      next_action='Inspect keeper-role and replacement-quality features for soccer; preserve NHL baseline and source repair queue. Do not repeatedly lower price or confidence thresholds after failed trials.',report=str(report))
    state.setdefault('research_state',{})[LABEL]=receipt;dump(path,state)
    print(json.dumps(receipt),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['build','train','finish']);a=ap.parse_args()
    {'build':build,'train':train,'finish':finish}[a.action]()
