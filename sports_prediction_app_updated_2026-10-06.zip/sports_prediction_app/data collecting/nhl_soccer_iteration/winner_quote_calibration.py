"""Past-only winner reliability conditional on its quoted price.

Outcome selection is immutable. The quoted-price-only control tests whether
the sports forecast contributes information rather than merely following odds.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, brier_score_loss

from common import ROOT_OUT, REPORTS, dump, stamp, file_sha256
from backtest import quote_inputs
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine

LABEL='winner_quote_calibration'
RESULT=ROOT_OUT/'simulation_results'/LABEL
SOURCES={'nhl':'feature_revisions/nhl_player_strength','soccer':'soccer_source_count_rates'}


def reliability(f):
    f=f.copy();parts=[];fits=[]
    for name,col in [('model','probability'),('price','price')]:
        p=f[col].clip(1e-8,1-1e-8);f[name+'_logit']=np.log(p/(1-p))
    for month,test in f.groupby(f.entry.dt.strftime('%Y-%m')):
        boundary=pd.Timestamp(month+'-01',tz='UTC')
        train=f[f.exit.lt(boundary)];counts=train.won.value_counts()
        ready=len(train)>=100 and len(counts)==2 and counts.min()>=10
        t=test.copy();t['reliability_ready']=ready
        t['reliability_label_max']=pd.Series(train.exit.max(),index=t.index,dtype='datetime64[ns, UTC]')
        for kind,cols in [('price_only',['price_logit']),('combined',['price_logit','model_logit'])]:
            coef=intercept=None
            if ready:
                model=LogisticRegression(C=1.,max_iter=1000).fit(train[cols],train.won.astype(int))
                t[kind+'_probability']=model.predict_proba(test[cols])[:,1]
                coef=model.coef_[0].tolist();intercept=float(model.intercept_[0])
                replay=1/(1+np.exp(-(test[cols].to_numpy()@np.array(coef)+intercept)))
                assert np.allclose(replay,t[kind+'_probability'],atol=1e-12,rtol=0)
            else:
                t[kind+'_probability']=t.price if kind=='price_only' else t.probability
            fits.append(dict(month=month,kind=kind,ready=bool(ready),train_rows=len(train),
                label_max=str(train.exit.max()),columns=json.dumps(cols),coefficients=json.dumps(coef),intercept=intercept))
        assert not len(train) or train.exit.max()<t.entry.min()
        parts.append(t)
    return pd.concat(parts,ignore_index=True),pd.DataFrame(fits)


def metrics(f):
    rows=[]
    for year,g in [('pooled',f)]+list(f.groupby(f.entry.dt.year)):
        # Compare identical warmed-up rows; cold starts have no fitted signal.
        g=g[g.reliability_ready]
        if not len(g):continue
        for kind,col in [('original','probability'),('price_only','price_only_probability'),('combined','combined_probability')]:
            q=g[col].to_numpy();y=g.won.to_numpy(int)
            rows.append(dict(year=str(year),variant=kind,games=len(g),logloss=log_loss(y,np.c_[1-q,q],labels=[0,1]),
                brier=brier_score_loss(y,q),mean_probability=q.mean(),actual_win_rate=y.mean()))
    return pd.DataFrame(rows)


def run():
    RESULT.mkdir(exist_ok=True);assert not (RESULT/'validation.json').exists()
    plan=dict(at_utc=stamp(),
        hypothesis='Confidence-only calibration failed. Winner reliability may depend on disagreement with the observed market. Fit the correctness of the unchanged model pick using two probability logits; compare with a price-only fit on identical earlier data.',
        estimator='Monthly expanding logistic C1. Predictors: logit(sports winner probability) and logit(winner price). Comparator: price logit alone. At least100 earlier settled quoted games and10 observations per label; no return fitting or parameter grid.',
        side='Original full-class argmax remains immutable. Corrected reliability sizes this same outcome, never an alternative.',
        gate='Combined must beat both original confidence and fitted price-only control on pooled2024/25logloss andBrier and2025logloss, on identical warmed-up rows.',
        staking='After probability gate, unchanged5 dollars per corrected confidence point above51,annual2000cash-only. Zero before calibration is ready. Provider qualifies for2026 if2025Sharpe improves versus original confidence and return is positive.',
        timing='Each reliability fit uses only prior monthly settled out-of-fit sports forecasts and prior pre12quotes. Providers independent. Training sources from2021; rolling sports forecasts from2024.',
        evaluation='2026 repeatedly inspected retrospective research, not a pristine holdout. No app changes or adoption.')
    dump(RESULT/'plan.json',plan)
    quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    development={};proper=[];fits=[];hashes={};choices={};account_choices={}
    for sport,folder in SOURCES.items():
        path=ROOT_OUT/'simulation_results'/folder/'development_predictions.parquet';hashes[str(path.relative_to(ROOT_OUT))]=file_sha256(path)
        p=pd.read_parquet(path);p=p[p.variant.eq('candidate')]
        assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
        f=transfer.normalize(sport,p,quotes,pick_growth=False)
        for provider,g in f.groupby('provider'):
            h,fit=reliability(g);s=metrics(h);key=dict(sport=sport,provider=provider)
            early=g[g.year.eq(2024)]
            if len(early):
                prefix,_=reliability(early)
                pd.testing.assert_frame_equal(prefix.set_index('game_id').sort_index(),h.set_index('game_id').loc[prefix.game_id].sort_index(),check_exact=True)
            proper.append(s.assign(**key));fits.append(fit.assign(**key));development[sport,provider]=h
            ix=s.set_index(['variant','year'])
            passed=all(ix.loc[('combined','pooled'),c]<ix.loc[(control,'pooled'),c] for control in ['original','price_only'] for c in ['logloss','brier'])
            passed &= all(ix.loc[('combined','2025'),'logloss']<ix.loc[(control,'2025'),'logloss'] for control in ['original','price_only'])
            choices[sport,provider]=bool(passed)
    pd.concat(proper).to_csv(RESULT/'development_probability_metrics.csv',index=False)
    pd.concat(fits).to_csv(RESULT/'development_coefficients.csv',index=False)
    pd.concat(development.values()).to_parquet(RESULT/'development_predictions.parquet',index=False)
    dump(RESULT/'probability_selection.json',dict(at_utc=stamp(),choices=[dict(sport=k[0],provider=k[1],passed=v) for k,v in choices.items()],used2026=False))
    annual=[];positions=[];days=[];checks=[]
    def accounts(sport,provider,h,stage):
        for variant in ['original','combined']:
            g=h[h.reliability_ready].copy()
            g['sizing_probability']=g.probability if variant=='original' else g.combined_probability
            g=g[g.sizing_probability.gt(.51)]
            for year in sorted(h.year.unique()):
                m,b,l,d=engine.simulate(g,int(year),'all_selected_outcomes','calibrated_dollars_cash_only',5.,2000.)
                key=dict(sport=sport,provider=provider,variant=variant,year=int(year),stage=stage)
                annual.append(key|m);checks.append(key|engine.validate(b,l,d,'calibrated_dollars_cash_only',5.,2000.))
                if len(b):
                    cols=['p0','p1']+(['p2'] if sport=='soccer' else [])
                    assert b.side.eq(b[cols].to_numpy().argmax(axis=1)).all()
                    assert b.reliability_label_max.lt(b.entry).all()
                    positions.append(b.assign(**key))
                days.append(d.assign(**key))
    for key,h in development.items():
        if choices[key]:accounts(*key,h,'development')
    if annual:
        for (sport,provider),g in pd.DataFrame(annual).groupby(['sport','provider']):
            ix=g.set_index(['variant','year']);old,new=ix.loc[('original',2025)],ix.loc[('combined',2025)]
            account_choices[sport,provider]=bool(new.return_pct>0 and new.sharpe>old.sharpe)
    dump(RESULT/'account_selection.json',dict(at_utc=stamp(),choices=[dict(sport=k[0],provider=k[1],passed=v) for k,v in account_choices.items()],used2026=False,adopted=False))
    evaluated=[];newfits=[]
    for sport,folder in SOURCES.items():
        if not any(v for k,v in account_choices.items() if k[0]==sport):continue
        path=ROOT_OUT/'simulation_results'/folder/'evaluation_predictions.parquet';hashes[str(path.relative_to(ROOT_OUT))]=file_sha256(path)
        p=pd.read_parquet(path);p=p[p.variant.eq('candidate')]
        assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
        f=transfer.normalize(sport,p,quotes,pick_growth=False)
        for provider,g in f.groupby('provider'):
            if not account_choices.get((sport,provider),False):continue
            old=development[sport,provider]
            h,fit=reliability(pd.concat([old,g],ignore_index=True))
            prior=h[h.year.lt(2026)].set_index('game_id').loc[old.game_id]
            assert np.array_equal(prior.combined_probability,old.combined_probability)
            h=h[h.year.eq(2026)];evaluated.append(h);newfits.append(fit.assign(sport=sport,provider=provider))
            accounts(sport,provider,h,'evaluation')
    if evaluated:
        pd.concat(evaluated).to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
        pd.concat(newfits).to_csv(RESULT/'evaluation_coefficients.csv',index=False)
    if annual:
        pd.DataFrame(annual).to_csv(RESULT/'annual.csv',index=False)
        if positions:pd.concat(positions).to_parquet(RESULT/'bets.parquet',index=False)
        pd.concat(days).to_parquet(RESULT/'daily.parquet',index=False)
    for name,sha in hashes.items():assert file_sha256(ROOT_OUT/name)==sha
    proof=dict(status='PASS',at_utc=stamp(),source_hashes=hashes,cash_checks=checks,all_bets_are_original_model_argmax=True,
        calibration_uses_only_earlier_settled_out_of_fit_forecasts=True,prefix_invariant=True,app_changed=False,adopted=False)
    dump(RESULT/'validation.json',proof)
    def table(f):
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in f.itertuples(index=False,name=None)])
    lines=['# Winner reliability with quoted-price context','',plan['hypothesis'],'',plan['estimator'],'',plan['side'],'',plan['gate'],'',table(pd.concat(proper)),'',
        'Probability choices: '+(RESULT/'probability_selection.json').read_text()+'','',
        'Betting choices: '+(RESULT/'account_selection.json').read_text()+'','']
    if annual:lines += [table(pd.DataFrame(annual)[['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'']
    lines += [plan['evaluation'],'',
        'The price-only control is fitted on precisely the same earlier rows. Selection requires incremental probability information from the sports forecast. A low corrected reliability produces a zero stake, not an opposite-side purchase. All raw class probabilities, native source references and quote clocks are preserved. No retained fitted model or app is replaced.','',
        'Account conventions: annual $2,000, cash only, original settlement availability, daily calendar returns including idle days, Sharpe annualized by sqrt(365.25). No costs added. Polymarket uses retained international historical token observations, not verified executable US asks; Kalshi uses retained YES ask closes. Reproduce winner_quote_calibration.py.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL]=dict(plan=plan,validation=proof,probability_selection=json.loads((RESULT/'probability_selection.json').read_bytes()),account_selection=json.loads((RESULT/'account_selection.json').read_bytes()));dump(path,d)
    if annual:
        path=ROOT_OUT/'simulation_results/experiment_results.csv';d=pd.read_csv(path,low_memory=False);key=LABEL+'/annual.csv'
        pd.concat([d[d.source_result_file.ne(key)],pd.DataFrame(annual).assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(pd.concat(proper).to_string(index=False),flush=True)
    print((RESULT/'probability_selection.json').read_text(),flush=True)
    if annual:print(pd.DataFrame(annual)[['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


if __name__=='__main__':run()
