"""Describe pre-2026 NHL forecast errors without selecting a trading rule.

All quality measurements use inputs/history available before each forecast.
Groups are explanatory, overlapping descriptions, not independent strategies.
No 2026 outcomes, new fitted forecast model, or adopted-model changes.
"""
import collections
import json
import math

import numpy as np
import pandas as pd

import models
from common import ROOT_OUT, PREVIOUS, read_db, dump, stamp, file_sha256
from final_pipeline import predictions, cleanup

DEST = ROOT_OUT / 'simulation_results/nhl_error_diagnosis'


def context(frame):
    """Earlier-season counts and last-history ages, not current-game players."""
    with read_db(PREVIOUS / 'expanded.sqlite') as db:
        games = pd.read_sql_query(
            "SELECT game_id,season,native_team_ids_json,available_time,start_time "
            "FROM nhl_games WHERE phase IN ('Regular Season','Playoffs')", db)
    games = games[games.game_id.isin(frame.game_id)].copy()
    assert set(games.game_id) == set(frame.game_id)
    for col in ['available_time', 'start_time']:
        games[col] = pd.to_datetime(games[col], utc=True, format='mixed')
    metadata = games.set_index('game_id')
    events = list(games.sort_values(['available_time', 'game_id']).itertuples())
    history = collections.defaultdict(list)
    counts = collections.Counter()
    cursor = 0
    rows = []
    for game in frame.sort_values(['prediction_time', 'game_id']).itertuples():
        while cursor < len(events) and events[cursor].available_time < game.prediction_time:
            old = events[cursor]
            cursor += 1
            for native in json.loads(old.native_team_ids_json):
                team = str(native)
                counts[old.season, team] += 1
                history[team].append(old.available_time)
        meta = metadata.loc[game.game_id]
        teams = list(map(str, json.loads(meta.native_team_ids_json)))
        prior_counts = [counts[meta.season, team] for team in teams]
        times = [history[team][-1] for team in teams if history[team]]
        assert all(at < game.prediction_time for at in times)
        rows.append(dict(game_id=game.game_id,
            season_min_prior_games=min(prior_counts),
            season_min_prior_games_group='0-10' if min(prior_counts) <= 10 else '11+',
            prior_history_age_days=max((game.prediction_time - at).total_seconds()/86400
                                       for at in times) if len(times) == 2 else np.nan))
    return pd.DataFrame(rows)


def roster_quality(frame):
    """Absolute earlier event coverage and five-game observed usage turnover."""
    from nhl_identity_features import history_keys
    from repair_nhl_player_exposure import apply as apply_repairs
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games=pd.read_sql_query('SELECT game_id,native_team_ids_json,date,prediction_time,available_time FROM nhl_games',db)
        players=pd.read_sql_query('SELECT game_id,side,official_player_id,position,played,minutes,available_at_utc FROM nhl_player_games',db)
    games=games[games.game_id.isin(frame.game_id)].copy()
    for c in ['prediction_time','available_time']:games[c]=pd.to_datetime(games[c],utc=True,format='mixed')
    players=apply_repairs(players[players.game_id.isin(games.game_id)])
    keys,_=history_keys(games,True)
    known=players[(players.played.eq(1)|players.minutes.gt(0))&players.position.ne('G')]
    groups={key:group for key,group in known.groupby(['game_id','side'])}
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        mapping=pd.read_sql_query('SELECT game_id,eligible_attempts,mapped_attempts FROM nhl_on_ice_source_links',db).set_index('game_id')
    queue=list(games.sort_values(['available_time','game_id']).itertuples())
    history=collections.defaultdict(lambda:collections.deque(maxlen=30))
    cursor=0;rows=[]
    for game in games.sort_values(['prediction_time','game_id']).itertuples():
        while cursor<len(queue) and queue[cursor].available_time<game.prediction_time:
            old=queue[cursor];cursor+=1
            for side in ['A','B']:
                group=groups.get((old.game_id,side),known.iloc[:0])
                assert pd.to_datetime(group.available_at_utc,utc=True,format='mixed').le(old.available_time).all()
                usage={str(r.official_player_id):float(r.minutes) for r in group.itertuples() if pd.notna(r.minutes) and r.minutes>0}
                coverage=(mapping.loc[old.game_id,'mapped_attempts']/mapping.loc[old.game_id,'eligible_attempts']) if old.game_id in mapping.index and mapping.loc[old.game_id,'eligible_attempts']>0 else None
                history[keys[old.game_id,side]].append(dict(at=old.available_time,usage=usage,
                    mapping=coverage,unknown_minutes=int(group.minutes.isna().sum()),observed_players=len(group)))
        sides=[];latest=[]
        for side in ['A','B']:
            h=list(history[keys[game.game_id,side]])
            def weights(recent):
                counts=collections.Counter()
                for item in recent:counts.update(item['usage'])
                total=sum(counts.values())
                return {pid:minutes/total for pid,minutes in counts.items()} if total>0 else {}
            now=weights(h[-5:]);before=weights(h[-10:-5])
            # Unknown minutes are not asserted to be nonparticipation or zero.
            complete=len(h)>=10 and not any(r['unknown_minutes'] or not r['observed_players'] for r in h[-10:])
            turnover=.5*sum(abs(now.get(pid,0)-before.get(pid,0)) for pid in now.keys()|before.keys()) if complete and now and before else np.nan
            values=[r['mapping'] for r in h if r['mapping'] is not None]
            sides.append(dict(turnover=turnover,mapping=np.mean(values) if values else np.nan,
                mapping_games=len(values),unknown_minutes=sum(r['unknown_minutes'] for r in h[-10:])))
            latest.extend(r['at'] for r in h)
        assert not latest or max(latest)<game.prediction_time
        a,b=sides
        rows.append(dict(game_id=game.game_id,prior_mapping_fraction_min=min(a['mapping'],b['mapping']) if np.isfinite([a['mapping'],b['mapping']]).all() else np.nan,
            prior_mapping_games_min=min(a['mapping_games'],b['mapping_games']),
            prior_roster_turnover_max=max(a['turnover'],b['turnover']) if np.isfinite([a['turnover'],b['turnover']]).all() else np.nan,
            prior_roster_unknown_minutes=a['unknown_minutes']+b['unknown_minutes'],
            history_quality_source_max_utc=max(latest) if latest else None))
    return pd.DataFrame(rows)


def wilson(wins, n):
    z = 1.959963984540054
    center = (wins/n + z*z/(2*n))/(1+z*z/n)
    half = z*math.sqrt((wins/n)*(1-wins/n)/n+z*z/(4*n*n))/(1+z*z/n)
    return center-half, center+half


def describe(group):
    y, p = group.won.astype(float), group.probability
    low, high = wilson(float(y.sum()), len(y))
    result = dict(observations=len(group), games=group.game_id.nunique(),
        mean_probability=float(p.mean()), win_rate=float(y.mean()),
        win_rate_wilson95_low=low, win_rate_wilson95_high=high,
        overconfidence_pp=float(100*(p-y).mean()),
        log_loss=float(-(y*np.log(p)+(1-y)*np.log(1-p)).mean()),
        brier=float(((y-p)**2).mean()))
    if 'price' in group:
        result.update(mean_price=float(group.price.mean()),
            model_expected_unit_return=float((p/group.price-1).mean()),
            observed_unit_return=float(group.unit_return.mean()))
    return result


def main():
    DEST.mkdir(exist_ok=True)
    plan = dict(at_utc=stamp(), years=[2024, 2025], type='Descriptive error diagnosis only',
        groups=dict(phase='Official phase', feature_missing='Any missing retained-model input',
                    input_tail='Maximum absolute training-standardized continuous input > 3; binary/ternary flags excluded',
                    season_min_prior_games_group='At most10 vs more10 earlier observed current-season games for either team',
                    historical_input_age='Oldest role/on-ice/team latest-source age >7 days',
                    prior_mapping_group='Minimum of two teams mean event mapping over prior30 games: below95% or at least95%',
                    prior_turnover_group='Maximum team change in observed skater minute shares, prior5 vs preceding5 games: above25% or at most25%; unknown minutes remain unknown'),
        selection='No group chosen as a rule; no 2026 outcomes read. No parameter search.',
        uncertainty='Wilson intervals for observed wins; overlapping groups and retrospective inspection prevent causal inference.',
        identity='Season counts use native team ID within the season. No cross-franchise pooling needed for this diagnostic.')
    dump(DEST / 'plan.json', plan)
    path = ROOT_OUT / 'retained_models/nhl/nhl_features.parquet'
    frame = pd.read_parquet(path)
    frame = pd.concat([frame, pd.get_dummies(frame.league, prefix='league', dtype=float)], axis=1)
    columns = models.columns(frame, models.CANDIDATES['granular_regulation_ot'])
    p = predictions('nhl', 'development')
    assert p.prediction_time.dt.year.isin([2024, 2025]).all()
    assert p.train_label_max.lt(p.prediction_time).all()
    selected_features = frame.set_index('game_id').loc[p.game_id].copy()
    quality = selected_features[['phase']].reset_index()
    quality['feature_missing'] = np.where(selected_features[columns].isna().any(axis=1), 'at_least_one', 'none')
    quality['missing_input_count'] = selected_features[columns].isna().sum(axis=1).to_numpy()
    quality['max_abs_training_z'] = np.nan
    driver_rows = []
    folds = []
    for fold, forecast in p.groupby('fold'):
        boundary = pd.Timestamp(fold+'-01', tz='UTC')
        train = frame[frame.available_time.lt(boundary)]
        assert len(train) == forecast.train_games.iloc[0]
        x = train[columns].astype(float)
        # Match preprocessing's population standard deviation; constant columns
        # use scale1. Missing values stay missing for this quality measurement.
        scale = x.std(ddof=0).replace(0, 1)
        current = selected_features.loc[forecast.game_id, columns].astype(float)
        # A rare playoff/binary flag is legitimate, not an extrapolated value.
        # Exclude low-cardinality inputs based only on the prior training set.
        continuous = x.columns[x.nunique().gt(3)]
        z = ((current[continuous]-x[continuous].mean())/scale[continuous]).abs()
        maxima = z.max(axis=1)
        quality.loc[quality.game_id.isin(forecast.game_id), 'max_abs_training_z'] = (
            quality.loc[quality.game_id.isin(forecast.game_id), 'game_id'].map(maxima))
        for gid, row in z.iterrows():
            for feature in row.index[row.gt(3)]:
                driver_rows.append(dict(game_id=gid, feature=feature, abs_training_z=float(row[feature])))
        folds.append(dict(fold=fold, games=len(forecast), training_games=len(train),
                          last_available=str(train.available_time.max())))
    assert quality.max_abs_training_z.notna().all()
    quality['input_tail'] = np.where(quality.max_abs_training_z.gt(3), '>3_sd', '<=3_sd')
    ages = []
    for c in ['source_max_available_utc','role_source_max_available_utc','onice_source_max_available_utc']:
        source = pd.to_datetime(selected_features[c], utc=True)
        assert source.isna().all() or (source.isna() | source.lt(selected_features.prediction_time)).all()
        ages.append((selected_features.prediction_time-source).dt.total_seconds()/86400)
    quality['max_latest_source_age_days'] = pd.concat(ages,axis=1).max(axis=1).to_numpy()
    quality['historical_input_age'] = np.where(quality.max_latest_source_age_days.gt(7), '>7_days', '<=7_days')
    quality = quality.merge(context(frame), on='game_id', validate='one_to_one')
    roster=roster_quality(frame)
    # Prefix replay tests that subsequent games cannot change earlier quality.
    cutoff=pd.Timestamp('2025-01-01',tz='UTC')
    prefix=roster_quality(frame[frame.prediction_time<cutoff])
    pd.testing.assert_frame_equal(prefix.set_index('game_id').sort_index(),
        roster.set_index('game_id').loc[prefix.game_id].sort_index(),check_exact=True)
    quality=quality.merge(roster,on='game_id',validate='one_to_one')
    quality['prior_mapping_group']=np.where(quality.prior_mapping_fraction_min.isna(),'unknown',
        np.where(quality.prior_mapping_fraction_min.lt(.95),'<95%','>=95%'))
    quality['prior_turnover_group']=np.where(quality.prior_roster_turnover_max.isna(),'unknown',
        np.where(quality.prior_roster_turnover_max.gt(.25),'>25%','<=25%'))
    pick = p.merge(quality,on='game_id',validate='one_to_one')
    pick['year'] = pick.prediction_time.dt.year
    pick['class_index'] = pick[['p0','p1']].to_numpy().argmax(axis=1)
    pick['probability'] = pick[['p0','p1']].max(axis=1)
    pick['won'] = pick.class_index.eq(pick.target)
    pick['provider'] = 'all_games'
    bets = pd.read_parquet(ROOT_OUT / 'simulation_results/current/bets.parquet')
    bets = bets[bets.sport.eq('nhl') & bets.year.isin([2024,2025]) & bets.recipe.eq('fixed')].copy()
    assert not bets.duplicated(['provider','year','game_id','class_index']).any()
    bets = bets.merge(quality,on='game_id',validate='many_to_one')
    assert len(bets) == 645
    # Verify that the frozen bet probability is the same retained forecast,
    # including when the bought outcome is not the model's predicted winner.
    ref = p.set_index('game_id')
    for row in bets.itertuples():
        assert row.probability == ref.loc[row.game_id, 'p'+str(row.class_index)]
        assert row.won == (row.class_index == ref.loc[row.game_id, 'target'])
    results = []
    dimensions = list(plan['groups'])
    for name, source in [('all_predicted_winners',pick),('funded_outcomes',bets)]:
        for (provider,year), part in source.groupby(['provider','year']):
            results.append(dict(population=name,provider=provider,year=year,dimension='all',group='all') | describe(part))
            for field in dimensions:
                for label, group in part.groupby(field,dropna=False):
                    results.append(dict(population=name,provider=provider,year=year,dimension=field,group=label) | describe(group))
    result = pd.DataFrame(results)
    result.to_csv(DEST / 'conditional_errors.csv', index=False)
    drivers = pd.DataFrame(driver_rows)
    drivers = drivers.merge(p[['game_id','prediction_time']],on='game_id',validate='many_to_one')
    drivers['year'] = drivers.prediction_time.dt.year
    grouped = drivers.groupby(['year','feature']).agg(games=('game_id','nunique'),
        mean_abs_z=('abs_training_z','mean'),max_abs_z=('abs_training_z','max')).reset_index()
    grouped.to_csv(DEST / 'outlying_inputs.csv',index=False)
    # Compact per-forecast diagnostic evidence, not a duplicate training matrix.
    quality.to_parquet(DEST / 'pregame_input_quality.parquet',index=False)
    validation = dict(at_utc=stamp(),status='PASS',feature_source_sha256=file_sha256(path),
        forecast_games=len(p),input_columns=len(columns),reconciled_bets=len(bets),
        past_only_folds=folds,source_timestamps_checked=True,evaluated2026=False,
        adopted_model_changed=False,group_metrics_not_causal=True,
        history_quality_prefix_invariant_rows=len(prefix))
    dump(DEST / 'validation.json',validation)
    records_path = ROOT_OUT / 'simulation_results/experiment_decisions.json'
    records = json.loads(records_path.read_bytes())
    records['nhl_error_diagnosis'] = dict(plan=plan,validation=validation)
    dump(records_path,records)
    cleanup()
    print(result[['population','provider','year','dimension','group','observations','mean_probability','win_rate','observed_unit_return']].to_string(index=False),flush=True)


if __name__ == '__main__':
    main()
