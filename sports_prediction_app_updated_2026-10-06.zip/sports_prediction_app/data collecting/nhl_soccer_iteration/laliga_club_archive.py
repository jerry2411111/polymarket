"""Recover La Liga archive identities via the public official FC Barcelona API.

Routes are supplied by the club's own current client JavaScript. No API key,
third-party dataset or present-day roster is used. Every page is retained.
"""
import argparse,collections,datetime as dt,json,re,sqlite3,unicodedata
from common import OfficialClient,PROJECT,PREVIOUS,ROOT_OUT,read_db,dump,stamp
from laliga_retained_facts import page_props

BASE='https://api-fcb.pulselive.com/football'
OfficialClient.HOSTS.update({'api-fcb.pulselive.com','www.fcbarcelona.com'})

def sid(v):
    assert float(v).is_integer();return str(int(v))

def label(v):
    v=''.join(c for c in unicodedata.normalize('NFKD',v).lower() if not unicodedata.combining(c))
    words=re.findall('[a-z0-9]+',v)
    return ' '.join(w for w in words if w not in {'fc','cf','rc','rcd','cd','sd','ca','sad','club','futbol','de','del','c','f','s','a','d'})

def games():
    with read_db(PREVIOUS/'expanded.sqlite') as c:
        return {r['game_id']:dict(r) for r in c.execute("SELECT * FROM soccer_games WHERE league='La Liga' AND date BETWEEN '2021-01-01' AND '2026-09-30'")}

def calendar_teams():
    mapping=json.loads((PROJECT/'final_models/sources/path_map.json').read_text());teams={}
    with read_db(PROJECT/'collected data/result/soccer_statistics.sqlite') as c:
        rows=[dict(r) for r in c.execute("SELECT * FROM source_manifest WHERE status=200 AND endpoint LIKE 'https://www.laliga.com/en-GB/laliga-easports/results/%'")]
    for s in rows:
        raw=s['raw_file'].replace('\\','/')
        for old,new in mapping.items():
            old,new=old.replace('\\','/'),new.replace('\\','/')
            if raw.startswith(old):raw=new+raw[len(old):];break
        path=PROJECT/raw
        if not path.exists():continue
        import hashlib
        b=path.read_bytes();assert hashlib.sha256(b).hexdigest()==s['sha256']
        for m in page_props(b).get('matches',[]):
            for side in ['home','away']:
                t=m[side+'_team'];tid=str(t['id']);row=teams.setdefault(tid,dict(names=set(),source=dict(url=s['endpoint'],raw_file=raw,sha256=s['sha256'])))
                row['names'].update(t[k] for k in ['name','nickname','boundname','shortname','slug'] if t.get(k))
    return teams

def get_pages(client,path,intent,page_size=100):
    rows=[];sources=[];page=0
    while True:
        url=BASE+path+('&' if '?' in path else '?')+f'page={page}&pageSize={page_size}'
        j,s=client.get(url,intent,kind='official_club_archive_index')
        if j is None and s['return_status'] in {'500','502','503','504'} and page_size>25:
            return get_pages(client,path,intent+' (smaller page after server error)',25)
        assert j is not None,(url,s['return_status'])
        p=j['pageInfo'];assert p['page']==page and len(j['content'])<=page_size
        rows.extend(j['content']);sources.append(s)
        if page+1>=p['numPages']:
            assert len(rows)==p['numEntries'];break
        page+=1
    assert len({sid(r['id']) for r in rows})==len(rows)
    return rows,sources

def discover():
    client=OfficialClient(per_second=2);wanted=games();native=calendar_teams()
    seasons,season_sources=get_pages(client,'/competitions/21/compseasons','Official La Liga historical season IDs')
    fixtures=[];sources=[];season_ids=[]
    for s in seasons:
        match=re.search(r'(20\d\d)/(20\d\d)',s['label'])
        if not match or not 2020<=int(match[1])<=2026:continue
        season_ids.append(sid(s['id']))
        rs,ss=get_pages(client,f'/fixtures?compSeasons={sid(s["id"])}&sort=asc&altIds=true&detail=2','Official La Liga fixture archive '+s['label'],25 if sid(s['id'])=='365' else 100)
        for r in rs:r['_index_sources']=ss
        fixtures.extend(rs);sources.extend(ss)
        print(json.dumps(dict(stage='laliga_club_index',season=s['label'],games=len(rs))),flush=True)
    clubteams={}
    for f in fixtures:
        for x in f['teams']:
            t=x['team'];tid=sid(t['id']);r=clubteams.setdefault(tid,dict(names=set(),opta=t['altIds']['opta']))
            assert r['opta']==t['altIds']['opta']
            r['names'].update(t[k] for k in ['name','shortName'] if t.get(k))
            r['names'].update(t.get('club',{}).get(k) for k in ['name','shortName'] if t.get('club',{}).get(k))
    cross={};ambiguous=[]
    for nid,n in native.items():
        keys={label(v) for v in n['names']}
        candidates=[cid for cid,r in clubteams.items() if keys&{label(v) for v in r['names']}]
        if len(candidates)==1:cross[nid]=candidates[0]
        else:ambiguous.append(dict(laliga_id=nid,names=sorted(n['names']),candidates=candidates))
    # Explicit club-name variants reviewed from the two retained official lists.
    # Every fixture still requires identical UTC kickoff, both native teams and score.
    aliases={'6':'443','26':'760','11':'464','49':'758','1':'764'}
    for n,c in aliases.items():
        assert n in native and c in clubteams
        cross[n]=c
    needed=set(t for g in wanted.values() for t in json.loads(g['native_team_ids_json']))
    problems=[v for v in ambiguous if v['laliga_id'] in needed and v['laliga_id'] not in aliases]
    audit=dict(at_utc=stamp(),team_crosswalk=[dict(laliga_id=n,club_id=c,opta_id=clubteams[c]['opta'],laliga_names=sorted(native[n]['names']),club_names=sorted(clubteams[c]['names']),source=native[n]['source']) for n,c in cross.items()],unmatched_teams=problems,club_teams={k:dict(names=sorted(v['names']),opta=v['opta']) for k,v in clubteams.items()},season_sources=season_sources,index_sources=sources)
    dump(ROOT_OUT/'laliga_club_identity_audit.json',audit)
    assert not problems,('Team identities require explicit evidence',problems)
    bykey=collections.defaultdict(list)
    for f in fixtures:
        if f.get('status')!='C' or len(f.get('teams',[]))!=2:continue
        ts=dt.datetime.fromtimestamp(f['kickoff']['millis']/1000,dt.UTC).isoformat()
        h,a=f['teams'];bykey[(ts,sid(h['team']['id']),sid(a['team']['id']))].append(f)
    matches=[];issues=[]
    for g in wanted.values():
        a,h=json.loads(g['native_team_ids_json']);ts=dt.datetime.fromisoformat(g['timestamp']).astimezone(dt.UTC).isoformat()
        candidates=bykey[(ts,cross[h],cross[a])]
        if len(candidates)!=1:issues.append(dict(game_id=g['game_id'],reason='No unique exact kickoff and native-team pair',candidates=len(candidates)));continue
        f=candidates[0];assert [t['score'] for t in f['teams']]==[g['scoreB'],g['scoreA']]
        assert sid(f['gameweek']['compSeason']['competition']['id'])=='21'
        matches.append(dict(game_id=g['game_id'],official_game_id=g['official_game_id'],club_fixture_id=sid(f['id']),opta_match_id=f['altIds']['opta'],date=g['date'],club_home_id=cross[h],club_away_id=cross[a],index_sources=f['_index_sources']))
    assert len({m['club_fixture_id'] for m in matches})==len(matches)
    dump(ROOT_OUT/'laliga_club_archive_index.json',dict(at_utc=stamp(),wanted_games=len(wanted),matched_games=len(matches),matches=matches,issues=issues,identity_audit='laliga_club_identity_audit.json'))
    print(json.dumps(dict(wanted=len(wanted),matched=len(matches),issues=issues[:10])),flush=True)

if __name__=='__main__':discover()
