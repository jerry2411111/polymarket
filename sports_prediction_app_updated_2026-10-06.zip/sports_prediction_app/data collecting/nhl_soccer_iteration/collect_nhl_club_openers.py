"""Official club supplements for omissions in the January2021 league article."""
import collections,json,re
import pandas as pd
from common import OfficialClient,dump,stamp
from collect_nhl_opening_rosters import RUN,StructuredArticle,namekey
from nhl_roster_aliases import read_source
FOLDER=RUN/'club_supplements'
CLUBS={'DAL':('Dallas Stars','https://www.nhl.com/stars/news/dallas-stars-announce-2020-21-opening-night-roster-320544814'),
       'BUF':('Buffalo Sabres','https://www.nhl.com/sabres/news/sharpen-up-january-14-2021-sabres-home-opener-is-tonight-320270572')}


def parse(code,blob):
    parser=StructuredArticle();parser.feed(blob.decode('utf8'))
    articles=[x for x in parser.items if isinstance(x,dict) and x.get('@type')=='NewsArticle'];assert len(articles)==1
    a=articles[0];body=a['articleBody'];rows=[];notes=[]
    if code=='DAL':
        categories={'Forwards':'active_roster','Defensemen':'active_roster','Goaltenders':'active_roster','Taxi Squad':'taxi_squad','Injured Non-Roster':'injured_non_roster','Non-Roster List':'non_roster'}
        for section,status in categories.items():
            m=re.search(r'##### \*\*'+re.escape(section)+r' \((\d+)\)\*\*(.*?)(?=#####|$)',body,re.S);assert m,section
            names=[v.strip() for v in m.group(2).split(',')];count=int(m.group(1))
            if count!=len(names):
                assert section=='Injured Non-Roster' and count==2 and len(names)==3 and 'three players on injured non-roster' in body
                notes.append(dict(section=section,heading_count=count,names_listed=len(names),reason='Introduction says three, heading two: preserve all three explicitly listed names.'))
            rows.extend(dict(player_name_raw=n,roster_status=status,section=section) for n in names)
        assert sum(r['roster_status']=='active_roster' for r in rows)==23 and len(rows)==33
    else:
        section=body[body.index('Of the 23 players on Buffalo'):]
        drafted=section[:section.index('Six were acquired in trades:')]
        names=re.findall(r'([A-Z][a-z]+ [A-Z][A-Za-z]+), 20\d{2}',drafted);assert len(names)==9
        traded=section.split('Six were acquired in trades:',1)[1].split('Eight were signed as free agents:',1)[0]
        signed=section.split('Eight were signed as free agents:',1)[1].split('Fifteen played in Buffalo',1)[0]
        tn=[v.strip() for v in traded.split(',')];sn=[v.strip() for v in signed.split(',')];assert len(tn)==6 and len(sn)==8
        for label,group in [('drafted',names),('traded',tn),('signed',sn)]:rows.extend(dict(player_name_raw=n,roster_status='active_roster',section='2020-21 roster notes/'+label) for n in group)
        taxi=re.search(r'assigning five players to the taxi squad: forwards (.+?) and (.+?), defensemen (.+?) and (.+?), and goaltender (.+?)\.',body);assert taxi
        rows.extend(dict(player_name_raw=n,roster_status='taxi_squad',section='Dated taxi squad transactions') for n in taxi.groups());assert len(rows)==28
    assert len({r['player_name_raw'] for r in rows})==len(rows)
    for r in rows:assert 2<=len(r['player_name_raw'].split())<=4
    at=max(pd.Timestamp(a['datePublished']),pd.Timestamp(a.get('dateModified',a['datePublished'])))
    return rows,dict(date_published=a['datePublished'],date_modified=a.get('dateModified'),available_at_utc=at.isoformat(),source_discrepancies=notes)


def collect(code):
    FOLDER.mkdir(exist_ok=True);team,url=CLUBS[code];c=OfficialClient(per_second=2)
    blob,source=c.get(url,'January2021 club opening roster supplement '+team,'nhl_club_opening_roster_release',document=True)
    raw,metadata=parse(code,blob)
    registry,teamsource=c.get('https://api.nhle.com/stats/rest/en/team','Verify native opening club identity','nhl_team_identity')
    info=[t for t in registry['data'] if t['fullName']==team];assert len(info)==1
    roster,identity=c.get(f'https://api-web.nhle.com/v1/roster/{code}/20202021','Verify native January2021 opening identities '+team,'nhl_season_roster_identity')
    candidates=collections.defaultdict(list)
    for group in ['forwards','defensemen','goalies']:
        for index,p in enumerate(roster[group]):
            full=p['firstName']['default']+' '+p['lastName']['default'];candidates[namekey(full)].append((p,full,'/'+group+'/'+str(index)))
    out=[]
    for r in raw:
        options=candidates[namekey(r['player_name_raw'])]
        row=dict(team_name=team,player_name_raw=r['player_name_raw'],roster_status=r['roster_status'],source_name_occurrence=1,season='20202021',team_id=str(info[0]['id']),
            official_player_id=None,player_name_api=None,position=None,identity_verified=False,identity_reason='Exact source name not unique in native season roster; further official identity evidence needed.',
            available_at_utc=metadata['available_at_utc'],release_source_json=json.dumps(source|dict(article_section=r['section']),sort_keys=True),
            identity_source_json=json.dumps(identity,sort_keys=True),identity_pointer=None,identity_candidates_json=json.dumps([str(p['id']) for p,_,_ in options]),identity_evidence_json=None)
        if len(options)==1:
            p,full,pointer=options[0];row.update(official_player_id=str(p['id']),player_name_api=full,position=p['positionCode'],identity_verified=True,
                identity_reason='Exact full name after mechanical accent/punctuation normalization in official same-club season roster.',identity_pointer=pointer)
        out.append(row)
    f=pd.DataFrame(out);name='20202021_'+code;f.to_parquet(FOLDER/(name+'.parquet'),index=False);f.to_csv(FOLDER/(name+'.csv'),index=False)
    dump(FOLDER/(name+'_source.json'),dict(club_code=code,release=source,identity=identity,team_source=teamsource,metadata=metadata))
    print(json.dumps(dict(club=code,rows=len(f),verified=int(f.identity_verified.sum()),unresolved=f[~f.identity_verified].player_name_raw.tolist())),flush=True)


def validate(code):
    name='20202021_'+code;s=json.loads((FOLDER/(name+'_source.json')).read_bytes());f=pd.read_parquet(FOLDER/(name+'.parquet'))
    expected,metadata=parse(code,read_source(s['release']))
    assert [(r['player_name_raw'],r['roster_status']) for r in expected]==list(zip(f.player_name_raw,f.roster_status))
    assert f.available_at_utc.eq(metadata['available_at_utc']).all()
    roster=json.loads(read_source(s['identity']));teams=json.loads(read_source(s['team_source']))['data']
    tid=[str(t['id']) for t in teams if t['fullName']==CLUBS[code][0]];assert len(tid)==1 and f.team_id.eq(tid[0]).all()
    for r in f[f.identity_verified].itertuples():
        group,index=r.identity_pointer.strip('/').split('/');p=roster[group][int(index)]
        assert str(p['id'])==r.official_player_id and namekey(p['firstName']['default']+' '+p['lastName']['default'])==namekey(r.player_name_raw) and p['positionCode']==r.position
    assert not f.duplicated(['team_id','player_name_raw']).any()
    result=dict(status='PASS',at_utc=stamp(),season='20202021',club_code=code,clubs=1,rows=len(f),verified_identities=int(f.identity_verified.sum()),
        unresolved_identity_rows=int((~f.identity_verified).sum()),available_at_utc=metadata['available_at_utc'],source_discrepancies=metadata['source_discrepancies'])
    dump(FOLDER/(name+'_validation.json'),result);print(json.dumps(result),flush=True)


if __name__=='__main__':
    for code in CLUBS:collect(code);validate(code)
