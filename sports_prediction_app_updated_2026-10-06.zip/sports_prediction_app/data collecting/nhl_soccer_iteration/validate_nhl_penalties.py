"""Replay every published NHL discipline statistic against original responses."""
import collections, json, math
import pandas as pd
from common import ROOT_OUT, PROJECT, PREVIOUS, read_db, dump, stamp, file_sha256


def main():
    from collect_nhl_penalties import PLAYER, TEAM, TABLES
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games={r['game_id']:dict(r) for r in db.execute("SELECT * FROM nhl_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30' AND phase IN ('Regular Season','Playoffs')")}
    counts=collections.Counter(); observed={kind:set() for kind in TABLES}; source_count=0
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        sources=[dict(r) for r in db.execute('SELECT * FROM nhl_penalty_sources ORDER BY request_number')]
        for n,source in enumerate(sources,1):
            ref=json.loads(source['source_json']);path=PROJECT/ref['raw_file']
            assert file_sha256(path)==ref['sha256']
            raw=json.loads(path.read_bytes());kind=source['kind'];mapping=PLAYER if kind=='skater' else TEAM
            rows=[dict(r) for r in db.execute('SELECT * FROM '+TABLES[kind]+' WHERE request_number=?',[source['request_number']])]
            assert len(rows)==source['returned_rows']==len(raw['data'])
            assert ref['return_status']=='200' and '/'+kind+'/penalties?' in ref['url']
            for row in rows:
                parts=row['source_pointer'].split('/');assert parts[1]=='data'
                item=raw['data'][int(parts[2])];game=games[row['game_id']]
                assert str(item['gameId'])==str(game['official_game_id'])==row['official_game_id']
                assert item['gameDate']==game['date']==row['date'] and item['gamesPlayed']==1
                assert item['homeRoad']==('R' if row['side']=='A' else 'H')
                assert row['team_id']==str(json.loads(game['native_team_ids_json'])[0 if row['side']=='A' else 1])
                assert pd.Timestamp(row['available_at_utc'])==pd.Timestamp(game['available_time'])>pd.Timestamp(game['start_time'])
                if kind=='skater':assert str(item['playerId'])==row['official_player_id']
                else:assert str(item['teamId'])==row['team_id']
                for native,column in mapping.items():
                    assert row[column]==item.get(native),(row['game_id'],column)
                    counts['raw_cells']+=1;counts['null_raw_cells']+=int(row[column] is None)
                assert row['net_penalties']==row['penalties_drawn']-row['penalties_taken']
                if kind=='skater':
                    for name in ['drawn','taken','net']:
                        count=row['net_penalties'] if name=='net' else row['penalties_'+name]
                        expected=count*3600/row['playing_seconds'] if row['playing_seconds'] and count is not None else None
                        actual=row['calculated_'+name+'_per60']
                        assert actual==expected or (actual is not None and expected is not None and math.isclose(actual,expected,abs_tol=1e-10))
                        counts['calculated_cells']+=1
                counts[kind+'_rows']+=1;observed[kind].add(row['game_id'])
            source_count+=1
            if n%11==0 or n==len(sources):print(json.dumps(dict(stage='source_replay',processed=n,total=len(sources),percent=round(100*n/len(sources),1))),flush=True)
        for kind,table in TABLES.items():
            assert observed[kind]==set(games),(kind,set(games)-observed[kind])
            assert counts[kind+'_rows']==db.execute('SELECT count(*) FROM '+table).fetchone()[0]
            key='game_id,official_player_id' if kind=='skater' else 'game_id,side'
            assert not db.execute('SELECT '+key+',count(*) FROM '+table+' GROUP BY '+key+' HAVING count(*)>1').fetchall()
        assert counts['team_rows']==len(games)*2
        issues={r[0]:r[1] for r in db.execute('SELECT field,count(*) FROM nhl_penalty_validation_issues GROUP BY field')}
        assert set(issues)<=set('raw_'+x+'_per60_versus_exact_count_rate' for x in ['drawn','taken','net'])
    result=dict(at_utc=stamp(),status='PASS',games=len(games),raw_responses=source_count,**dict(counts),
        earliest=min(g['date'] for g in games.values()),latest=max(g['date'] for g in games.values()),
        source_disagreement_counts=issues,scope='Collected regular-season/playoff games; official report excludes preseason. No penalty count is asserted equal to a power-play opportunity.',
        rate_policy='Preserve the official rate and the separate exact count*3600/seconds calculation. Counts and reported seconds agree; provider denominator rounding is a likely explanation for the rate differences, not a verified internal definition.',
        raw_history_vintage='Current official historical responses; retrieval UTC recorded, not proof of original contemporaneous publication.')
    dump(ROOT_OUT/'retention/nhl_penalties_validation.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
