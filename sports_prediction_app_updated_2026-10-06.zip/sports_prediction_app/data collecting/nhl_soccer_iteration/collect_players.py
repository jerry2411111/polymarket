"""Expand official per-match PL player statistics; raw values remain traceable."""
import argparse
import concurrent.futures
import hashlib
import json
import sqlite3
from pathlib import Path
import pandas as pd
from common import PROJECT,PREVIOUS,OUT,OfficialClient,read_db,dump,stamp

BASE='https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v1/matches/'
FIELDS={
 'minutes':'minsPlayed','started':'gameStarted','goals':'goals','assists':'goalAssist',
 'shots':'totalScoringAtt','shots_on_target':'ontargetScoringAtt','xg':'expectedGoals',
 'xa':'expectedAssists','xgot':'expectedGoalsOnTarget','key_passes':'totalAttAssist',
 'big_chances_created':'bigChanceCreated','big_chances_missed':'bigChanceMissed',
 'passes':'totalPass','passes_completed':'accuratePass','forward_passes':'fwdPass',
 'long_passes':'totalLongBalls','long_passes_completed':'accurateLongBalls',
 'final_third_passes':'totalFinalThirdPasses','final_third_passes_completed':'successfulFinalThirdPasses',
 'touches':'touches','touches_opponent_box':'touchesInOppBox','through_balls':'totalThroughBall',
 'accurate_through_balls':'accurateThroughBall','crosses':'totalCross','crosses_completed':'accurateCross',
 'dribbles':'totalContest','dribbles_completed':'wonContest','tackles':'totalTackle',
 'tackles_won':'wonTackle','interceptions':'interception','recoveries':'ballRecovery',
 'recoveries_attacking_third':'possWonAtt3rd','recoveries_defensive_third':'possWonDef3rd',
 'duels_won':'duelWon','duels_lost':'duelLost','aerials_won':'aerialWon','aerials_lost':'aerialLost',
 'clearances':'totalClearance','blocked_shots':'outfielderBlock','possession_lost':'possLostAll',
 'errors_to_shot':'errorLeadToShot','errors_to_goal':'errorLeadToGoal',
 'saves':'saves','goals_conceded':'goalsConceded','keeper_xgot_conceded':'expectedGoalsOnTargetConceded',
 'yellow_cards':'yellowCard','red_cards':'redCard','fouls_committed':'fouls','fouls_suffered':'wasFouled',
}

def cached_sources():
    mapping=json.loads((PROJECT/'final_models/sources/path_map.json').read_text());result={}
    with read_db(PROJECT/'collected data/result/player_depth.sqlite') as db:
        for r in db.execute("SELECT request_id,endpoint,raw_file,sha256,retrieved_at_utc FROM source_manifest WHERE status=200 AND endpoint LIKE '%prem%/players/%/stats'"):
            raw=r['raw_file'].replace('\\','/')
            for old,new in mapping.items():
                old,new=old.replace('\\','/'),new.replace('\\','/')
                if raw.startswith(old):raw=new+raw[len(old):];break
            p=PROJECT/raw
            if p.exists():result[r['endpoint']]=dict(request_id=r['request_id'],raw_file=raw,sha256=r['sha256'],retrieved_at_utc=r['retrieved_at_utc'],url=r['endpoint'])
    return result

def parse(data,task,source):
    meta=data.get('playerMetadata') or {}
    assert str(meta.get('id'))==str(task['player_id']),'Player ID mismatch'
    stats=data.get('stats');assert isinstance(stats,dict),'Missing statistics object'
    # A current-team profile can differ after a transfer. Historical lineup is
    # authoritative for team membership; never use meta.currentTeam here.
    row={k:task[k] for k in ['game_id','official_game_id','player_id','player_name','team_id','side','league','date','available_at_utc']}
    row.update({name:stats.get(native) for name,native in FIELDS.items()})
    for name in FIELDS:assert row[name] is None or isinstance(row[name],(int,float)),name
    if row['minutes'] is not None:assert 0<=row['minutes']<=150
    row['source']=source;row['raw_stats']=stats;return row

def run(start,end,limit,workers,cache_only=False,progress_name=None):
    assert progress_name is None or progress_name.replace('_','').isalnum()
    progress_file=OUT/((progress_name or ('player_cache_progress' if cache_only else 'player_collection_progress'))+'.json')
    client=OfficialClient();known=cached_sources()
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        lineups=pd.read_sql_query("SELECT l.*,g.official_game_id FROM soccer_expanded_lineups l JOIN soccer_games g USING(game_id) WHERE l.league='Premier League' AND l.date>=? AND l.date<=? ORDER BY l.date,l.game_id,l.started DESC,l.player_id",db,params=(start,end))
    db=sqlite3.connect(OUT/'player_detail.sqlite',timeout=60)
    db.executescript('''CREATE TABLE IF NOT EXISTS player_match_detail(game_id TEXT,player_id TEXT,body TEXT NOT NULL,PRIMARY KEY(game_id,player_id));
    CREATE TABLE IF NOT EXISTS acquisition_issues(game_id TEXT,player_id TEXT,reason TEXT,source_json TEXT,PRIMARY KEY(game_id,player_id));''')
    done=set(db.execute('SELECT game_id,player_id FROM player_match_detail'))
    if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='verified_nonappearances'").fetchone():
        done.update(db.execute('SELECT game_id,player_id FROM verified_nonappearances'))
    tasks=[r for r in lineups.to_dict('records') if (r['game_id'],r['player_id']) not in done]
    if cache_only:tasks=[r for r in tasks if BASE+str(r['official_game_id'])+'/players/'+str(r['player_id'])+'/stats' in known]
    if limit:tasks=tasks[:limit]
    print(json.dumps(dict(stage='player_collection_start',from_date=start,through_date=end,possible=len(lineups),already_normalized=len(done),pending=len(tasks),retained_responses=len(known))),flush=True)
    dump(progress_file,dict(stage='player_collection',from_date=start,through_date=end,processed=0,total=len(tasks),percent=0 if tasks else 100,counts={},at_utc=stamp()))
    def fetch(task):
        url=BASE+str(task['official_game_id'])+'/players/'+str(task['player_id'])+'/stats'
        source=known.get(url)
        try:
            if source:
                raw=(PROJECT/source['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==source['sha256'];body=json.loads(raw)
                source=source|dict(reused=True)
            else:
                body,source=client.get(url,task['date']+' Premier League player '+task['player_name']+' match '+str(task['official_game_id']))
                if body is None:raise ValueError('Official API status '+source['return_status'])
            return task,parse(body,task,source),None,source
        except Exception as e:return task,None,str(e),source
    counts={'normalized':0,'errors':0};milestone=10
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        for n,(task,row,error,source) in enumerate(pool.map(fetch,tasks),1):
            with db:
                if row:
                    db.execute('INSERT OR REPLACE INTO player_match_detail VALUES (?,?,?)',(task['game_id'],task['player_id'],json.dumps(row,allow_nan=False)))
                    db.execute('DELETE FROM acquisition_issues WHERE game_id=? AND player_id=?',(task['game_id'],task['player_id']));counts['normalized']+=1
                else:
                    db.execute('INSERT OR REPLACE INTO acquisition_issues VALUES (?,?,?,?)',(task['game_id'],task['player_id'],error,json.dumps(source)));counts['errors']+=1
            if n*100>=milestone*len(tasks) or n==len(tasks):
                progress=dict(stage='player_collection',processed=n,total=len(tasks),percent=round(100*n/len(tasks),1),counts=counts,latest_date=task['date'],at_utc=stamp())
                dump(progress_file,progress);print(json.dumps(progress),flush=True);milestone+=10
    count=db.execute('SELECT count(*) FROM player_match_detail').fetchone()[0];db.close()
    print(json.dumps(dict(stage='player_collection_done',stored_player_matches=count,counts=counts)),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--start',default='2021-01-01');p.add_argument('--end',default='2026-09-29');p.add_argument('--limit',type=int);p.add_argument('--workers',type=int,default=8);p.add_argument('--cache-only',action='store_true');p.add_argument('--progress-name');a=p.parse_args();run(a.start,a.end,a.limit,a.workers,a.cache_only,a.progress_name)
