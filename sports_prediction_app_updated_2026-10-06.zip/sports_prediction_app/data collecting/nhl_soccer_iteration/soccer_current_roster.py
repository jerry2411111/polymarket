"""Reconcile verified person identities and measure dated starting-lineup change."""
import argparse
import collections
import copy
import json
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, REPORTS, read_db, dump, stamp, file_sha256

LABEL = 'soccer_current_roster'
WORK = ROOT_OUT / '_work' / LABEL
RESULT = ROOT_OUT / 'simulation_results' / LABEL
REFERENCE = ROOT_OUT / 'simulation_results/soccer_source_count_rates'
TABLE = 'soccer_recent_starting_lineups'
FIELDS = ['f_ctx_starter_turnover_diff', 'f_ctx_starter_turnover_sum', 'f_ctx_strength_turnover_diff']


def prepare():
    import soccer_source_count_rates as source
    WORK.mkdir(parents=True, exist_ok=True)
    RESULT.mkdir(parents=True, exist_ok=True)
    dump(RESULT / 'research_plan.json', dict(at_utc=stamp(),
        previous_turn_classification='progress: qualification source published; whole-market, qualification, nonlinear and exposure-cap comparisons completed and rejected; corrected counts retained.',
        diagnosis='Current count-corrected model reconstructs source-namespaced player IDs without applying the already validated cross-competition static person links. This can fragment prior contribution histories.',
        source_change='Use only published source-ID/canonical-ID links backed by official full names and birth dates. Preserve original native IDs, all source values and all observation clocks.',
        next_feature='Observed starting-lineup usage turnover, last five versus preceding five fixtures within the same competition. Require eleven explicit starters in every contributing match. No forecast-match lineup or later appearance.',
        gate='Separate identity reconciliation from optional continuity features. Compare rolling2024/25probability scores before2026evaluation. Source truth is retained even if a model change does not improve returns.',
        app_changed=False, evaluation='2026has been repeatedly inspected; retrospective rolling evidence only.'))
    source.WORK = WORK
    source.RESULT = RESULT / 'source_replay'
    source.RESULT.mkdir(exist_ok=True)
    source.build()


def person_links(players):
    """Verify every published static person edge against original official bytes."""
    from soccer_identity_repair import read, pointer, identity, namekey
    folder = ROOT_OUT / 'soccer_identity_sources_v58'
    links = pd.read_parquet(ROOT_OUT / 'soccer_research_player_identity_links.parquet')
    evidence = pd.read_parquet(ROOT_OUT / 'soccer_research_player_identity_evidence.parquet')
    pd.testing.assert_frame_equal(links, pd.read_parquet(folder / 'identity_crosswalk.parquet'))
    pd.testing.assert_frame_equal(evidence, pd.read_parquet(folder / 'identity_evidence.parquet'))
    assert json.loads((folder / 'identity_validation.json').read_bytes())['status'] == 'PASS'
    cache, attributes = {}, collections.defaultdict(set)
    for r in evidence.itertuples():
        src = json.loads(r.source_json)
        if src['sha256'] not in cache: cache[src['sha256']] = read(src)[0]
        node = pointer(cache[src['sha256']], r.profile_pointer)
        native, names, birth = identity(r.identity_kind, node)
        if r.identity_kind != 'lal': assert native == r.official_player_id
        else: assert '/' + r.official_player_id + '/' in json.dumps(node['squads'])
        assert str(birth)[:10] == r.birth_date
        assert set(json.loads(r.full_names_json)) <= set(n for n in names if n)
        attributes[r.player_id].update((namekey(n), r.birth_date) for n in json.loads(r.full_names_json))
    edges = json.loads((folder / 'identity_edges.json').read_bytes())
    parent = {}
    def find(pid):
        while pid in parent: pid = parent[pid]
        return pid
    for e in edges:
        pair = e['normalized_full_name'], e['birth_date']
        assert pair in attributes[e['player_a']] and pair in attributes[e['player_b']]
        a, b = find(e['player_a']), find(e['player_b'])
        if a != b: parent[max(a, b)] = min(a, b)
    for r in links.itertuples(): assert find(r.source_player_id) == r.canonical_player_id
    mapping = dict(zip(links.source_player_id, links.canonical_player_id))
    linked = players.copy(); linked['source_model_player_id'] = linked.player_id
    linked['player_id'] = linked.player_id.map(lambda x: mapping.get(x, x))
    assert not linked.duplicated(['game_id', 'player_id']).any(), 'Conflicting participants require source repair'
    pd.testing.assert_frame_equal(linked.drop(columns=['player_id', 'source_model_player_id']), players.drop(columns='player_id'))
    proof = dict(status='PASS', at_utc=stamp(), raw_responses_verified=len(cache), official_profile_rows=len(evidence),
        linked_ids=len(links), identity_edges=len(edges), changed_rows=int(linked.player_id.ne(players.player_id).sum()),
        changed_games=int(linked.loc[linked.player_id.ne(players.player_id), 'game_id'].nunique()),
        unchanged_native_ids_values_and_clocks=True, same_game_identity_collisions=0,
        published_links_sha256=file_sha256(ROOT_OUT / 'soccer_research_player_identity_links.parquet'),
        limitation='Retrospective correction using static official identity attributes; does not import a later team, lineup or performance. Unlinked IDs remain distinct, not guessed.')
    dump(RESULT / 'identity_validation.json', proof)
    return linked


def pool_counts(games, players, keys):
    active = players[pd.to_numeric(players.minutes, errors='coerce').gt(0)]
    lookup = {k: list(h.player_id) for k, h in active.groupby(['game_id', 'side'])}
    history = collections.defaultdict(lambda: collections.deque(maxlen=5)); last_team = {}
    events = list(games.sort_values(['available_time', 'game_id']).itertuples()); cursor = 0; rows = []
    for r in games.sort_values(['prediction_time', 'game_id']).itertuples():
        while cursor < len(events) and events[cursor].available_time < r.prediction_time:
            old = events[cursor]; cursor += 1
            for side in ['A', 'B']:
                key = keys[old.game_id, side]; people = lookup.get((old.game_id, side), [])
                history[key].append(people)
                for pid in people: last_team[pid] = key
        counts = {}
        for side in ['A', 'B']:
            key = keys[r.game_id, side]
            counts[side] = len({pid for h in history[key] for pid in h if last_team[pid] == key})
        rows.append(dict(game_id=r.game_id, f_ctx_roster_players_diff=counts['B'] - counts['A']))
    return pd.DataFrame(rows).set_index('game_id')


def continuity(games, players, keys, overrides=None):
    """Only prior explicit starting elevens, compared inside one competition."""
    lookup = {}
    for key, f in players.groupby(['game_id', 'side'], sort=False):
        starters = f[f.started.eq(True)]
        complete = len(starters) == 11 and starters.player_id.nunique() == 11
        lookup[key] = dict(complete=complete, count=len(starters),
            players=sorted(starters.player_id.tolist()), natives=sorted(starters.official_player_id.astype(str).tolist()))
    history = collections.defaultdict(lambda: collections.deque(maxlen=10))
    events = list(games.sort_values(['available_time', 'game_id']).itertuples()); cursor = 0; rows = []
    for r in games.sort_values(['prediction_time', 'game_id']).itertuples():
        while cursor < len(events) and events[cursor].available_time < r.prediction_time:
            old = events[cursor]; cursor += 1
            for side in ['A', 'B']:
                lineup = lookup.get((old.game_id, side), dict(complete=False, count=0, players=[], natives=[]))
                history[old.league, keys[old.game_id, side]].append(dict(
                    game_id=old.game_id, official_game_id=old.official_game_id, side=side,
                    available_time=old.available_time.isoformat(), **lineup))
        for side in ['A', 'B']:
            key = keys[r.game_id, side]; h = list(history[r.league, key])
            if overrides:
                replaced=[]
                for past in h:
                    recovered=overrides.get((past['game_id'],past['side']))
                    if recovered and pd.Timestamp(recovered['available_time']) < r.prediction_time:
                        past=dict(past,**recovered)
                    replaced.append(past)
                h=replaced
            status = 'no_prior_games' if not h else ('fewer_than_ten_prior_games' if len(h) < 10 else
                     ('incomplete_prior_starting_eleven' if not all(x['complete'] for x in h) else 'ready'))
            now, before = collections.Counter(), collections.Counter()
            if status == 'ready':
                for past in h[-5:]: now.update(past['players'])
                for past in h[-10:-5]: before.update(past['players'])
                assert sum(now.values()) == sum(before.values()) == 55
                turnover = .5 * sum(abs(now[pid] - before[pid]) for pid in now.keys() | before.keys()) / 55
                assert 0 <= turnover <= 1
            else: turnover = np.nan
            latest = max(pd.Timestamp(x['available_time']) for x in h) if h else None
            assert latest is None or latest < r.prediction_time
            rows.append(dict(game_id=r.game_id, official_game_id=str(r.official_game_id), league=r.league, date=r.date,
                prediction_time=r.prediction_time.isoformat(), side=side, team_key=key,
                history_games=len(h), complete_lineup_games=sum(x['complete'] for x in h),
                starter_usage_turnover=turnover, evidence_status=status,
                recent_starter_counts_json=json.dumps(now, sort_keys=True) if status == 'ready' else None,
                preceding_starter_counts_json=json.dumps(before, sort_keys=True) if status == 'ready' else None,
                latest_source_utc=latest.isoformat() if latest is not None else None,
                source_lineups_json=json.dumps(h, sort_keys=True),
                source_reference='Official source game/player reports and validated player identity links; source_replay and identity_validation.json provide input hashes and native identity evidence.'))
    return pd.DataFrame(rows)


def build():
    import loss_case_revision as case
    import soccer_source_count_rates as counts
    from pl_sparse_statistics import merge_proved_zeros
    case.WORK = WORK
    games, _, original, _, keys, _ = case.load_sources()
    players, _ = merge_proved_zeros(original, audit_dir=RESULT / 'source_replay')
    linked = person_links(players)
    current = pd.read_parquet(WORK / 'squad/soccer_features.parquet').set_index('game_id')
    previous = json.loads((REFERENCE / 'feature_validation.json').read_bytes())
    assert file_sha256(WORK / 'squad/soccer_features.parquet') == previous['candidate_hash']
    recipe = copy.deepcopy(json.loads((REFERENCE / 'experiment_plan.json').read_bytes())['recipe'])
    parts = []
    for label, p in [('control', players), ('identity', linked)]:
        actions, _ = counts.derive(games, p, keys)
        physical, _ = case.coverage_features(games, p, keys)
        derived = actions.join(physical).join(pool_counts(games, p, keys))
        if label == 'control':
            assert np.allclose(derived, current.loc[derived.index, derived.columns], rtol=0, atol=1e-10, equal_nan=True)
        else:
            changed = current.copy(); changed[derived.columns] = derived.loc[current.index]
            assert changed.drop(columns=derived.columns).equals(current.drop(columns=derived.columns))
        parts.append(derived)
    cut = pd.Timestamp('2025-01-01', tz='UTC')
    early = games[games.prediction_time.lt(cut)]
    prefix_games = games[games.available_time.lt(cut) | games.game_id.isin(early.game_id)]
    prefix_players = linked[linked.game_id.isin(prefix_games.game_id)]
    prefix_actions, _ = counts.derive(prefix_games, prefix_players, keys)
    prefix_physical, _ = case.coverage_features(prefix_games, prefix_players, keys)
    prefix = prefix_actions.join(prefix_physical).join(pool_counts(prefix_games, prefix_players, keys))
    pd.testing.assert_frame_equal(prefix.loc[early.game_id], parts[1].loc[early.game_id], check_exact=True)
    history = continuity(games, linked, keys)
    hp = continuity(prefix_games, prefix_players, keys)
    index = ['game_id', 'side']
    pd.testing.assert_frame_equal(hp[hp.game_id.isin(early.game_id)].set_index(index).sort_index(),
        history[history.game_id.isin(early.game_id)].set_index(index).sort_index(), check_exact=True)
    pivot = history.pivot(index='game_id', columns='side', values='starter_usage_turnover').reindex(current.index)
    turnover = changed.copy()
    turnover[FIELDS[0]] = pivot.B - pivot.A
    turnover[FIELDS[1]] = pivot.B + pivot.A
    coef_a = (current.f_ctx_uefa_log_strength_sum - current.f_ctx_uefa_log_strength_diff) / 2
    coef_b = (current.f_ctx_uefa_log_strength_sum + current.f_ctx_uefa_log_strength_diff) / 2
    turnover[FIELDS[2]] = coef_b * pivot.B - coef_a * pivot.A
    for label, f in [('identity', changed), ('turnover', turnover)]:
        path = WORK / label / 'squad'; path.mkdir(parents=True, exist_ok=True)
        f.reset_index().to_parquet(path / 'soccer_features.parquet', index=False)
    history.to_parquet(ROOT_OUT / (TABLE + '.parquet'), index=False)
    history.to_csv(ROOT_OUT / (TABLE + '.csv'), index=False)
    history.groupby(['league', 'evidence_status']).size().rename('team_sides').reset_index().to_csv(RESULT / 'continuity_coverage.csv', index=False)
    changes = {c: int((~np.isclose(parts[0][c], parts[1][c], atol=1e-12, equal_nan=True)).sum()) for c in parts[1]}
    evidence = parts[1].add_prefix('linked_').join(parts[0].add_prefix('previous_')).reset_index()
    evidence.to_parquet(RESULT / 'identity_feature_evidence.parquet', index=False)
    dump(RESULT / 'experiment_plan.json', dict(at_utc=stamp(), recipe=recipe,
        variants={'identity': 'Same41inputs with verified person-ID reconciliation',
                  'turnover': 'Identity-corrected41inputs plus prior starter turnover difference/sum and interaction with log UEFA club strength'},
        new_columns=FIELDS, prior_window='Ten immediately preceding collected matches in the same competition; each must have exactly11explicit starters. Last5versuspreceding5, half L1 difference of55starter slots.',
        gate='Each variant must improve pooled2024/25logloss AND Brier and2025logloss versus corrected-count control. Turnover must also beat identity-only scores. No outcome-selected team exclusions or threshold search.',
        interpretation='Continuity describes past observed team composition, not a confirmed future starting lineup. Missing prior lineups remain unknown. Existing gaps are diagnosed, not assumed externally unavailable.',
        training='Monthly expanding2021+history, forecasts2024onward, earlier-only scaling and purged180day calibration.',
        evaluation='Repeatedly inspected2026is retrospective, never an untouched holdout.', app_changed=False))
    dump(RESULT / 'feature_validation.json', dict(status='PASS', at_utc=stamp(), games=len(games), player_rows=len(players),
        changed_columns=changes, original_seven_inputs_replayed=True, prefix_invariant_games=len(early),
        same_competition_turnover=True, turnover_ready_team_sides=int(history.evidence_status.eq('ready').sum()),
        final_table_sha256=file_sha256(ROOT_OUT / (TABLE + '.parquet')),
        feature_hashes={label: file_sha256(WORK / label / 'squad/soccer_features.parquet') for label in ['identity', 'turnover']}))
    print(json.dumps(dict(stage='built',changes=changes,ready_sides=int(history.evidence_status.eq('ready').sum()))), flush=True)


def recover_starters():
    """Use retained, validated club reports to repair incomplete starter sets."""
    from common import PROJECT
    import loss_case_revision as case
    from laliga_recovered_features import records as club_records
    from laliga_maker_features import records as maker_records
    case.WORK=WORK;games,_,players,_,keys,_=case.load_sources()
    links=pd.read_parquet(ROOT_OUT/'soccer_research_player_identity_links.parquet')
    mapping=dict(zip(links.source_player_id,links.canonical_player_id))
    cross=players[['league','official_player_id','player_id']].drop_duplicates()
    assert cross.groupby(['league','official_player_id']).player_id.nunique().max()==1
    cross=cross.set_index(['league','official_player_id']).player_id.to_dict()
    players=players.copy();players.player_id=players.player_id.map(lambda x:mapping.get(x,x))
    before=pd.read_parquet(ROOT_OUT/(TABLE+'.parquet'))
    lookup={(r['game_id'],r['side']):r for text in before.source_lineups_json for r in json.loads(text)}
    official=games.set_index('game_id')
    wanted={k for k,v in lookup.items() if not v['complete'] and official.loc[k[0],'league']=='La Liga'}
    overrides={};audit=[];seen=set()
    dump(RESULT/'starter_recovery_plan.json',dict(at_utc=stamp(),
        reason='Most incomplete windows are LaLiga; retained official club reports already contain additional starting lineups. Integrate verified facts before calling them unavailable.',
        rule='Only incomplete earlier starting elevens; exactly11explicit starters; unique nativeIDs; existing explicit starters must be a subset. Source-native team/game matches required. Later source clocks cannot enter an earlier forecast.',
        source='FCBarcelona official API republishes Opta; Elche official public JSON republishes LaLigaMaker. Backup/republished origin remains explicit.',
        model='Same44-input turnover recipe. Only prior starting-lineup coverage changes; identity-corrected statistical inputs unchanged.',
        selection='Earlier proper-score gate before2026; no source chosen by match outcome.',app_changed=False))
    club,_=club_records();maker=maker_records()
    for label,records in [('official_club_FCBarcelona_Opta',club),('official_club_Elche_LaLigaMaker',maker)]:
        for record in records:
            gid=record['game_id']
            if gid not in official.index:continue
            for side in ['A','B']:
                key=(gid,side)
                if key not in wanted or key in overrides:continue
                members=[r for r in record['players'] if r['side']==side and r.get('started') is True]
                reason=None
                native=[str(r.get('official_player_id') if label.startswith('official_club_FC') else r.get('opta_player_id')) for r in members]
                if len(members)!=11 or len(set(native))!=11:reason='incomplete_or_duplicate_starters'
                elif any(n in ['None',''] for n in native):reason='native_person_bridge_pending'
                elif not set(lookup[key]['natives']).issubset(native):reason='existing_explicit_starter_conflict'
                elif any(str(r['official_game_id'])!=str(official.loc[gid,'official_game_id']) for r in members):reason='native_game_conflict'
                elif any(str(r['team_id'])!=str(json.loads(official.loc[gid,'native_team_ids_json'])[0 if side=='A' else 1]) for r in members):reason='native_team_conflict'
                if reason:
                    audit.append(dict(game_id=gid,side=side,source_class=label,status=reason));continue
                sources={r['source']['sha256']:r['source'] for r in members}
                for digest,src in sources.items():
                    if digest not in seen:
                        assert file_sha256(PROJECT/src['raw_file'])==digest;seen.add(digest)
                clock=max([official.loc[gid,'available_time']]+[pd.Timestamp(r['available_at_utc']) for r in members])
                ids=[mapping.get(cross.get(('La Liga',n),'EU_LAL:'+n),cross.get(('La Liga',n),'EU_LAL:'+n)) for n in native]
                assert len(set(ids))==11
                overrides[key]=dict(complete=True,count=11,players=sorted(ids),natives=sorted(native),available_time=clock.isoformat(),
                    recovery_source_class=label,recovery_sources=list(sources.values()))
                audit.append(dict(game_id=gid,side=side,source_class=label,status='recovered',available_time=clock.isoformat()))
    updated=continuity(games,players,keys,overrides)
    cut=pd.Timestamp('2025-01-01',tz='UTC');early=games[games.prediction_time.lt(cut)]
    pg=games[games.available_time.lt(cut)|games.game_id.isin(early.game_id)]
    pp=players[players.game_id.isin(pg.game_id)]
    prefix=continuity(pg,pp,keys,{k:v for k,v in overrides.items() if pd.Timestamp(v['available_time'])<cut})
    index=['game_id','side']
    pd.testing.assert_frame_equal(prefix[prefix.game_id.isin(early.game_id)].set_index(index).sort_index(),updated[updated.game_id.isin(early.game_id)].set_index(index).sort_index(),check_exact=True)
    unchanged=before.evidence_status.eq('ready')
    assert np.allclose(before.loc[unchanged,'starter_usage_turnover'],updated.loc[unchanged,'starter_usage_turnover'],rtol=0,atol=0)
    assert updated.evidence_status.eq('ready').sum()>=before.evidence_status.eq('ready').sum()
    updated.to_parquet(ROOT_OUT/(TABLE+'.parquet'),index=False);updated.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    updated.groupby(['league','evidence_status']).size().rename('team_sides').reset_index().to_csv(RESULT/'continuity_coverage.csv',index=False)
    pd.DataFrame(audit).to_csv(RESULT/'starter_source_recovery.csv',index=False)
    frame=pd.read_parquet(WORK/'identity/squad/soccer_features.parquet').set_index('game_id')
    pivot=updated.pivot(index='game_id',columns='side',values='starter_usage_turnover').reindex(frame.index)
    frame[FIELDS[0]]=pivot.B-pivot.A;frame[FIELDS[1]]=pivot.B+pivot.A
    a=(frame.f_ctx_uefa_log_strength_sum-frame.f_ctx_uefa_log_strength_diff)/2
    b=(frame.f_ctx_uefa_log_strength_sum+frame.f_ctx_uefa_log_strength_diff)/2
    frame[FIELDS[2]]=b*pivot.B-a*pivot.A
    dest=WORK/'turnover_recovered/squad';dest.mkdir(parents=True,exist_ok=True)
    frame.reset_index().to_parquet(dest/'soccer_features.parquet',index=False)
    receipt=dict(status='PASS',at_utc=stamp(),requested_incomplete_sides=len(wanted),recovered_starter_sides=len(overrides),
        raw_sources_hashed=len(seen),previous_ready_sides=int(before.evidence_status.eq('ready').sum()),
        ready_sides=int(updated.evidence_status.eq('ready').sum()),new_ready_windows=int((updated.evidence_status.eq('ready')&~before.evidence_status.eq('ready')).sum()),
        existing_ready_values_unchanged=True,prefix_invariant_games=len(early),source_class='Official club APIs republishing Opta and LaLigaMaker',
        prior_table_sha256=json.loads((RESULT/'feature_validation.json').read_bytes())['final_table_sha256'],
        final_table_sha256=file_sha256(ROOT_OUT/(TABLE+'.parquet')),feature_sha256=file_sha256(dest/'soccer_features.parquet'))
    dump(RESULT/'starter_recovery_validation.json',receipt);print(json.dumps(receipt),flush=True)


def publish():
    import sqlite3
    proof = json.loads((RESULT / 'feature_validation.json').read_bytes())
    if (RESULT/'starter_recovery_validation.json').exists():proof=json.loads((RESULT/'starter_recovery_validation.json').read_bytes())
    native_recovery=ROOT_OUT/'retention/soccer_lineup_continuity_validation.json'
    if native_recovery.exists():proof=json.loads(native_recovery.read_bytes())
    path = ROOT_OUT / (TABLE + '.parquet')
    assert proof['status'] == 'PASS' and file_sha256(path) == proof['final_table_sha256']
    f = pd.read_parquet(path)
    definitions = {
        'game_id': ('Canonical forecast game identifier', 'identifier'),
        'official_game_id': ('Native league match identifier for the forecast game', 'identifier'),
        'league': ('Actual competition; starter histories stay within this competition', 'category'),
        'date': ('Official date of forecast match', 'YYYY-MM-DD'),
        'prediction_time': ('History cutoff, twelve hours before kickoff', 'UTC timestamp'),
        'side': ('A is away, B is home', 'category'),
        'team_key': ('Documented canonical club identifier', 'identifier'),
        'history_games': ('Number of immediately preceding collected matches, up to ten', 'games'),
        'complete_lineup_games': ('Prior matches with exactly eleven explicit distinct starters', 'games'),
        'starter_usage_turnover': ('Half the absolute difference of per-player starter shares, last five versus preceding five matches; null if either window is incomplete', 'fraction 0 to 1'),
        'evidence_status': ('Ready, no earlier games, fewer than ten earlier games, or incomplete prior starting eleven', 'category'),
        'recent_starter_counts_json': ('Stable player key to starts in the last five games; total55when ready. Original windows use canonical IDs; recovered whole-source windows use explicit opta:pID or maker:UUID keys, not unverified canonical joins', 'JSON'),
        'preceding_starter_counts_json': ('Stable player key to starts in the preceding five games; total55when ready. Same namespace as recent counts within each window; see source_reference', 'JSON'),
        'latest_source_utc': ('Latest earlier observation availability used; null without history', 'UTC timestamp'),
        'source_lineups_json': ('Ordered earlier game/native IDs,side,observationclock,explicitstarterIDs,completenessandidentitynamespace. Whole-source recoveries include raw API receipts and literal asset-ID evidence; current-game participants excluded', 'JSON'),
        'source_reference': ('Location and interpretation of raw-source and static person-identity evidence', 'text')}
    assert set(definitions) == set(f)
    with sqlite3.connect(ROOT_OUT / 'granular.sqlite') as db:
        f.to_sql(TABLE, db, if_exists='replace', index=False)
        db.execute('CREATE UNIQUE INDEX ' + TABLE + '_key ON ' + TABLE + '(game_id,side)')
        for name in ['table_catalog', 'column_catalog', 'missing_report']:
            db.execute('DELETE FROM ' + name + ' WHERE [table]=?', (TABLE,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)', (TABLE, len(f), len(f.columns)))
        for c in f:
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)', (TABLE, c, *definitions[c],
                'Official league reports; LaLiga gaps additionally use official FCBarcelona/Opta and Elche/LaLigaMaker republished reports, explicitly identified in source_lineups_json. Exact native identities and source clocks preserved.'))
            db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)', (TABLE, c, len(f), int(f[c].isna().sum()), 100 * f[c].isna().mean()))
        pd.testing.assert_frame_equal(f, pd.read_sql_query('SELECT * FROM ' + TABLE, db), check_dtype=False)
    from publish import main
    main()
    dump(RESULT / 'publication_validation.json', dict(status='PASS', at_utc=stamp(), table=TABLE,
        rows=len(f), columns=len(f.columns), sql_parquet_equal=True, source_sha256=proof['final_table_sha256']))


def train():
    import pickle
    import models
    import soccer_club_history_model as paired
    import soccer_tie_context as simulation
    from sklearn.metrics import log_loss
    assert not (RESULT / 'validation.json').exists()
    plan = json.loads((RESULT / 'experiment_plan.json').read_bytes())
    proof = json.loads((RESULT / 'feature_validation.json').read_bytes())
    saved = pd.read_parquet(REFERENCE / 'development_predictions.parquet')
    saved = saved[saved.variant.eq('candidate')].copy(); saved['variant'] = 'reference'
    development = [saved]; replays = 0
    for label in ['identity', 'turnover']:
        models.OUT = WORK / label / 'squad'
        assert file_sha256(models.OUT / 'soccer_features.parquet') == proof['feature_hashes'][label]
        recipe = copy.deepcopy(plan['recipe'])
        if label == 'turnover': recipe['preserve_unit_columns'] += FIELDS
        models.CANDIDATES[label] = recipe
        p = models.run('soccer', 'development', [label])
        fields = ['target', 'prediction_time', 'train_label_max', 'calibration_label_max']
        pd.testing.assert_frame_equal(p.set_index('game_id')[fields].sort_index(), saved.set_index('game_id')[fields].sort_index(), check_dtype=False)
        assert p.train_label_max.lt(p.prediction_time).all()
        assert p.calibration_label_max.lt(p.prediction_time).all()
        assert p.calibration_train_label_max.lt(p.calibration_prediction_min).all()
        package = pickle.loads((models.OUT / 'model_runs/soccer/development' / (label + '.pkl')).read_bytes())
        frame = pd.read_parquet(models.OUT / 'soccer_features.parquet')
        matrix = pd.concat([frame, pd.get_dummies(frame.league, prefix='league', dtype=float)], axis=1).set_index('game_id')
        sample = p[p.fold.eq(package['boundary'].strftime('%Y-%m'))]
        x = matrix.loc[sample.game_id, package['columns']].replace([np.inf, -np.inf], np.nan).astype(float)
        predicted = models.apply_calibration(package['model'].predict_proba(x), package['calibrator'])
        assert np.allclose(predicted, sample[['p0', 'p1', 'p2']], atol=1e-12, rtol=0)
        assert len(package['columns']) == (41 if label == 'identity' else 44)
        replays += len(sample); development.append(p)
    joined = pd.concat(development, ignore_index=True)
    joined.to_parquet(RESULT / 'development_predictions.parquet', index=False)
    models.metrics(joined).to_csv(RESULT / 'development_metrics.csv', index=False)
    scores = {}
    for variant, f in joined.groupby('variant'):
        p = f[['p0', 'p1', 'p2']].to_numpy(); y = f.target.to_numpy(int)
        last = f[f.prediction_time.dt.year.eq(2025)]
        scores[variant] = dict(log_loss=log_loss(y, p, labels=[0, 1, 2]),
            brier=float(np.mean(np.sum((p - np.eye(3)[y])**2, axis=1))),
            log_loss2025=log_loss(last.target, last[['p0', 'p1', 'p2']], labels=[0, 1, 2]))
    gates = {}
    for label in ['identity', 'turnover']:
        comparisons = ['reference'] + (['identity'] if label == 'turnover' else [])
        gates[label] = all(scores[label][m] < scores[ref][m] for ref in comparisons for m in ['log_loss', 'brier', 'log_loss2025'])
    dump(RESULT / 'selection.json', dict(at_utc=stamp(), gates=gates, scores=scores, adopted=False))
    paired.RESULT = RESULT
    for label in ['identity', 'turnover']:
        delta = paired.paired_comparison(joined[joined.variant.eq(label)], saved)
        dump(RESULT / (label + '_paired_comparison.json'), delta)
    evaluation = []
    for label in ['identity', 'turnover']:
        if not gates[label]: continue
        models.OUT = WORK / label / 'squad'
        dump(models.OUT / 'soccer_selection.json', dict(selected_candidates=[label]))
        evaluation.append(models.run('soccer', 'evaluation', [label]))
    if evaluation:
        ref = pd.read_parquet(REFERENCE / 'evaluation_predictions.parquet')
        ref = ref[ref.variant.eq('candidate')].copy(); ref['variant'] = 'reference'
        evaluation = pd.concat(evaluation + [ref], ignore_index=True)
        evaluation.to_parquet(RESULT / 'evaluation_predictions.parquet', index=False)
        models.metrics(evaluation).to_csv(RESULT / 'evaluation_metrics.csv', index=False)
    else: evaluation = None
    simulation.RESULT = RESULT; simulation.simulate(joined, evaluation)
    dump(RESULT / 'validation.json', dict(status='PASS', at_utc=stamp(), gates=gates,
        held_forward_forecasts_replayed=replays, source_and_training_clocks_verified=True,
        evaluated2026=any(gates.values()), adopted=False, app_changed=False))
    print(json.dumps(dict(gates=gates, scores=scores)), flush=True)


def finish():
    from final_pipeline import discard_work, cleanup, validate
    for name in ['identity_validation', 'feature_validation', 'publication_validation', 'validation', 'cash_validation']:
        assert json.loads((RESULT / (name + '.json')).read_bytes())['status'] == 'PASS'
    identity = json.loads((RESULT / 'identity_validation.json').read_bytes())
    proof = json.loads((RESULT / 'feature_validation.json').read_bytes())
    selection = json.loads((RESULT / 'selection.json').read_bytes())
    annual = pd.read_csv(RESULT / 'annual.csv')
    pending_starters()
    recovery_path=RESULT/'starter_recovery_validation.json'
    recovery=json.loads(recovery_path.read_bytes()) if recovery_path.exists() else None
    if recovery:
        assert recovery['status']=='PASS'
        assert json.loads((RESULT/'recovered_model_validation.json').read_bytes())['status']=='PASS'
    def table(f):
        def fmt(x): return f'{x:.6f}' if isinstance(x, (float, np.floating)) else str(x)
        return '\n'.join(['| ' + ' | '.join(f.columns) + ' |', '| ' + ' | '.join(['---'] * len(f.columns)) + ' |'] +
            ['| ' + ' | '.join(map(fmt, row)) + ' |' for row in f.itertuples(index=False, name=None)])
    lines = ['# Soccer player identity and recent starting lineups', '',
        'The current count-corrected model did not consume the existing verified links between source-specific player IDs. This splits some players\' past statistics and can count the same person twice in a club\'s recent pool. Static identity reconciliation is kept separate from an optional lineup-turnover feature.', '',
        f"Official evidence: {identity['linked_ids']} links, {identity['official_profile_rows']} profile records, {identity['raw_responses_verified']} original responses re-read and hashed. {identity['changed_rows']} current player records change research ID across {identity['changed_games']} games. Native IDs, values and observation clocks are unchanged; no same-game collision. Links use documented names and birth dates, never name-only matching. Unresolved identities remain separate.", '',
        'This is retrospective correction of immutable person identity. No later team membership, future appearance or career performance is used to predict an earlier game. The raw responses and their original IDs remain available.', '',
        '## Model inputs', '',
        'Identity-only reruns seven existing roster summaries using the same goals/assists/key-pass zero proofs and physical-stat coverage correction. Its 41-input logistic model, scaling and calibration are unchanged. Changed forecast-input row counts: ' + json.dumps(proof['changed_columns']) + '.', '',
        'The second variant adds three inputs: home-minus-away recent starter turnover, the sum, and the interaction between each side\'s turnover and its earlier log UEFA strength. Turnover is half the absolute change in per-player starting shares across two consecutive five-game windows. All ten matches must have eleven explicit starters. Histories stay within each competition to avoid interpreting unresolved cross-provider IDs as rotation. No current-game lineup is used.', '',
        f"The new SQL table {TABLE} contains {2 * proof['games']} team-date records; {(recovery['ready_sides'] if recovery else proof['turnover_ready_team_sides'])} have complete turnover evidence. Missing histories and incomplete prior lineups are separately labelled. Earlier-prefix replay covers {proof['prefix_invariant_games']} games. Every field, source, unit and missing percentage is in the refreshed catalog.", '',
        table(pd.read_csv(RESULT / 'continuity_coverage.csv')), '',
        '## Rolling comparisons', '',
        'Monthly training expands from 2021; forecasts begin in 2024. The trailing 180-day calibration window is purged from its model fit. Every training result precedes the forecast cutoff. Candidate selection requires lower pooled 2024/25 logloss and Brier and lower 2025 logloss; turnover must also beat identity-only. No betting return chooses the model. Gates: ' + json.dumps(selection['gates']) + '.', '',
        table(pd.DataFrame([dict(variant=k, **v) for k, v in selection['scores'].items()])), '',
        'Paired month-block comparisons are retained but are not adjusted for repeated research. 2026 is repeatedly inspected retrospective rolling evidence, not an untouched holdout.', '',
        '## Unchanged cash simulation', '',
        'Each year starts with $2,000. Stake $5 per positive probability-minus-price percentage point on one expected-log-growth-selected outcome. Use the closest preceding pre-12 quote, at most 24 hours old. Reuse cash only after official settlement; no assumed fees. Providers remain separate. Polymarket historical token observations are not verified executable US ask prices. Daily Sharpe includes idle calendar days and annualizes by sqrt(365.25).', '',
        table(annual[['provider', 'variant', 'year', 'funded_games', 'win_rate_pct', 'return_pct', 'sharpe', 'max_drawdown_pct']]), '',
        'No app change or automatic model adoption. Source corrections remain valid independently of performance. Reproduce soccer_current_roster.py prepare, build, publish, train, recover_starters, publish, train_recovered, finish. Original source evidence, final SQL facts and results are retained; temporary source matrices and trial fits are removed after checks.']
    if recovery:
        lines+=['','## Recovery of incomplete starter histories','',
            f"The first feature audit identified La Liga windows with incomplete earlier elevens. Existing verified FC Barcelona/Opta and Elche/LaLigaMaker official club responses supply {recovery['recovered_starter_sides']} additional complete native starting elevens, making {recovery['new_ready_windows']} further team-date windows usable. {recovery['raw_sources_hashed']} original responses were hashed again. Every existing complete turnover value stays unchanged. Native game/team IDs and earlier starters must agree; unresolved identities or conflicts remain documented, not declared unavailable.",'',
            'These are clearly labelled official club sources republishing match information, not claimed to be the direct league API. The final SQL table preserves the exact raw references and source class in source_lineups_json. A fourth model variant, turnover_recovered, changes only the starter-history coverage in the same 44-input recipe. It must beat the prior identity-only and turnover models as well as the original corrected-count control on earlier probability scores before any 2026 evaluation.', '',
            'pending_starter_sources.csv identifies each earlier incomplete match/side, affected forecast-window count and current recovery evidence. It distinguishes unresolved retained-source coverage from a recovered lineup whose source clock was too late for a particular forecast; it does not label either externally unavailable.']
    (REPORTS / (LABEL + '.md')).write_text('\n'.join(lines) + '\n', encoding='utf8')
    if WORK.exists(): discard_work(WORK)
    cleanup(); checks = validate()
    receipt = dict(status='PASS', at_utc=stamp(), selection=selection, app_validation=checks,
        temporary_work_removed=True, adopted=False, goal_achieved=False)
    dump(ROOT_OUT / 'retention' / (LABEL + '_completion.json'), receipt)
    path = ROOT_OUT / 'retention/retained_artifacts.json'; m = json.loads(path.read_bytes())
    m['scripts'] = {p.name: file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    with read_db(ROOT_OUT / 'granular.sqlite') as db:
        tables = db.execute('SELECT COUNT(*) FROM table_catalog').fetchone()[0]
        columns = db.execute('SELECT COUNT(*) FROM column_catalog').fetchone()[0]
    m.update(updated_utc=stamp(), retained_scripts=len(m['scripts']), final_tables=tables,
        current_sql_columns=columns, latest_simulation_update=receipt); dump(path, m)
    print(json.dumps(receipt), flush=True)


def pending_starters():
    table=pd.read_parquet(ROOT_OUT/(TABLE+'.parquet'));counts=collections.Counter();details={}
    for row in table.itertuples():
        if row.evidence_status!='incomplete_prior_starting_eleven':continue
        for earlier in json.loads(row.source_lineups_json):
            if earlier['complete']:continue
            key=earlier['game_id'],earlier['side'];counts[key]+=1;details[key]=earlier
    attempted=pd.read_csv(RESULT/'starter_source_recovery.csv')
    statuses={key:set(f.status) for key,f in attempted.groupby(['game_id','side'])}
    records=[]
    for key,count in sorted(counts.items()):
        known=statuses.get(key,set())
        reason='Recovered source exists but was not eligible at all affected forecast boundaries' if 'recovered' in known else (
            '; '.join(sorted(known)) if known else 'No complete comparable retained candidate identified; source recovery pending')
        records.append(dict(game_id=key[0],side=key[1],official_game_id=details[key]['official_game_id'],
            explicit_starters=details[key]['count'],affected_team_date_windows=count,recovery_status=reason,
            externally_unavailable=False))
    pd.DataFrame(records).to_csv(RESULT/'pending_starter_sources.csv',index=False)
    dump(RESULT/'pending_starter_summary.json',dict(at_utc=stamp(),incomplete_source_sides=len(records),
        affected_team_date_windows=int(table.evidence_status.eq('incomplete_prior_starting_eleven').sum()),
        source_side_window_links=sum(counts.values()),externally_unavailable_assertions=0))


def train_recovered():
    import pickle
    import models
    import soccer_tie_context as simulation
    from sklearn.metrics import log_loss
    assert not (RESULT/'recovered_model_validation.json').exists()
    source_proof=json.loads((RESULT/'starter_recovery_validation.json').read_bytes());assert source_proof['status']=='PASS'
    name='turnover_recovered';models.OUT=WORK/name/'squad'
    assert file_sha256(models.OUT/'soccer_features.parquet')==source_proof['feature_sha256']
    recipe=copy.deepcopy(json.loads((RESULT/'experiment_plan.json').read_bytes())['recipe']);recipe['preserve_unit_columns']+=FIELDS
    models.CANDIDATES[name]=recipe;p=models.run('soccer','development',[name])
    old=pd.read_parquet(RESULT/'development_predictions.parquet');ref=old[old.variant.eq('reference')]
    cols=['target','prediction_time','train_label_max','calibration_label_max']
    pd.testing.assert_frame_equal(p.set_index('game_id')[cols].sort_index(),ref.set_index('game_id')[cols].sort_index(),check_dtype=False)
    joined=pd.concat([old,p],ignore_index=True);joined.to_parquet(RESULT/'development_predictions.parquet',index=False)
    models.metrics(joined).to_csv(RESULT/'development_metrics.csv',index=False)
    y=p.target.to_numpy(int);pr=p[['p0','p1','p2']].to_numpy();last=p[p.prediction_time.dt.year.eq(2025)]
    scores=dict(log_loss=log_loss(y,pr,labels=[0,1,2]),brier=float(np.mean(np.sum((pr-np.eye(3)[y])**2,axis=1))),
        log_loss2025=log_loss(last.target,last[['p0','p1','p2']],labels=[0,1,2]))
    selection=json.loads((RESULT/'selection.json').read_bytes());selection['scores'][name]=scores
    passed=all(scores[m]<selection['scores'][variant][m] for variant in ['reference','identity','turnover'] for m in scores)
    selection['gates'][name]=bool(passed);selection['updated_utc']=stamp();dump(RESULT/'selection.json',selection)
    package=pickle.loads((models.OUT/'model_runs/soccer/development'/(name+'.pkl')).read_bytes())
    frame=pd.read_parquet(models.OUT/'soccer_features.parquet');matrix=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
    sample=p[p.fold.eq(package['boundary'].strftime('%Y-%m'))]
    prediction=models.apply_calibration(package['model'].predict_proba(matrix.loc[sample.game_id,package['columns']].astype(float)),package['calibrator'])
    assert np.allclose(prediction,sample[['p0','p1','p2']],atol=1e-12,rtol=0)
    assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
    evaluation=None
    if passed:
        dump(models.OUT/'soccer_selection.json',dict(selected_candidates=[name]));ev=models.run('soccer','evaluation',[name])
        base=pd.read_parquet(REFERENCE/'evaluation_predictions.parquet');base=base[base.variant.eq('candidate')].copy();base['variant']='reference'
        evaluation=pd.concat([base,ev],ignore_index=True);evaluation.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
        models.metrics(evaluation).to_csv(RESULT/'evaluation_metrics.csv',index=False)
    simulation.RESULT=RESULT;simulation.simulate(joined,evaluation)
    dump(RESULT/'recovered_model_validation.json',dict(status='PASS',at_utc=stamp(),gate_passed=bool(passed),forecast_replays=len(sample),
        source_and_forecast_clocks_checked=True,evaluated2026=bool(passed),app_changed=False,adopted=False))
    print(json.dumps(dict(gate_passed=bool(passed),scores=scores)),flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('stage', choices=['prepare', 'build', 'publish', 'train', 'recover_starters', 'train_recovered', 'finish'])
    globals()[parser.parse_args().stage]()
