"""Raw statistic cells and independently calculated per-player participation."""
import argparse,hashlib,html,json,re
import numpy as np
from common import ROOT_OUT,PROJECT,OfficialClient,read_db,dump,stamp
from collect_cup_player_workload import RUN
from collect_uefa_exposure import reconcile_aliases


def main(full=False):
    with read_db(RUN/'match_statistics.sqlite') as db:records=[json.loads(b) for b, in db.execute('SELECT body FROM games')]
    if not full:
        ids=set(json.loads((RUN/'pilot_plan.json').read_bytes())['games']);records=[g for g in records if g['game_validation']['game_id'] in ids];assert len(records)==len(ids)==7
    cache={};cells=people=appearances=reported_times=0;issues=[]
    def read(s):
        if s['sha256'] not in cache:
            b=(PROJECT/s['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==s['sha256'];cache[s['sha256']]=json.loads(b)
        return cache[s['sha256']]
    def pointer(d,path):
        for key in path.strip('/').split('/'):d=d[int(key)] if isinstance(d,list) else d[key]
        return d
    for game in records:
        gid=game['game_validation']['game_id'];sources=game['source_links'];match=read(sources['match'])[0];lineup=read(sources['lineup'])
        assert str(match['id'])==game['game_validation']['official_game_id']==str(lineup['matchId'])
        stats={}
        for actor in ['teams','players']:
            raw=read(sources[actor])
            for r in game[actor]:
                native=pointer(raw,r['source_pointer']);assert str(native['teamId'])==r['team_id']
                if actor=='players':assert str(native['playerId'])==r['official_player_id'];stats[r['official_player_id']]=r
                proof=json.loads(r['field_evidence_json'])
                for field,e in proof.items():
                    if r.get(field) is None or e.get('ambiguous'):continue
                    assert float(pointer(raw,e['pointer']))==r[field];cells+=1
                if r['played_seconds_including_stoppage'] is not None:
                    attrs=proof['played_time']['attributes']
                    if 'TotalSeconds' in attrs:expected_seconds=int(attrs['TotalSeconds'])
                    else:
                        numbers=list(map(int,re.findall(r'\d+',attrs['TotalMinutesAndSeconds'])));assert len(numbers) in [1,2] and numbers[-1]<60
                        expected_seconds=numbers[-1]+(60*numbers[0] if len(numbers)==2 else 0)
                    assert expected_seconds==r['played_seconds_including_stoppage'];reported_times+=1
        exp=game.get('workload_exposure')
        if not exp:issues.append(dict(game_id=gid,reason=game.get('workload_exposure_error','No exposure record')));continue
        events=[]
        for s in game['workload_events_sources']:events.extend(read(s))
        events,_=reconcile_aliases(events);total=exp['regulation_extra_minutes'];assert total in [90,120]
        bounds={'FIRST_HALF':(0,45),'SECOND_HALF':(45,90),'EXTRA_TIME_FIRST_HALF':(90,105),'EXTRA_TIME_SECOND_HALF':(105,120)}
        def clock(e):
            low,high=bounds[e['phase']];t=e['time']
            return float(high) if t.get('injuryMinute',0)>0 else float(np.clip((60*(t['minute']-1)+t['second'])/60,low,high))
        for r in exp['players']:
            side='awayTeam' if r['side']=='A' else 'homeTeam';section=lineup[side]
            source=[p['player'] for p in section[r['lineup_group']] if str(p['player']['id'])==r['official_player_id']];assert len(source)==1 and str(section['team']['id'])==r['team_id']
            if not r['exposure_complete']:issues.append(dict(game_id=gid,player_id=r['official_player_id'],reason='Exposure requires source/transition repair'));continue
            pid=r['official_player_id'];enters=[0.] if r['started'] else [];leaves=[]
            for e in events:
                if e.get('phase') not in bounds or e['type'] not in ['SUBSTITUTION','RED_CARD','RED_YELLOW_CARD']:continue
                primary=(e.get('primaryActor') or {}).get('person') or {};off=str(primary.get('id') or primary.get('person',{}).get('id'))
                if off==pid:leaves.append(clock(e))
                if e['type']=='SUBSTITUTION' and str(e['secondaryActor']['person']['id'])==pid:enters.append(clock(e))
            enters=sorted(set(enters));assert len(enters)<=1
            expected=0. if not enters else min([t for t in leaves if t>=enters[0]]+[float(total)])-enters[0]
            assert np.isclose(expected,r['minutes_regulation_extra'],rtol=0,atol=1e-10);people+=1
            if pid in stats:
                s=stats[pid]
                if s['matches_appearance'] is not None:
                    if bool(s['matches_appearance'])!=bool(r['appeared']):issues.append(dict(game_id=gid,player_id=pid,reason='Official appearance flag conflicts with event-derived participation'))
                    appearances+=1
                if s['played_seconds_including_stoppage'] is not None:
                    # Reported elapsed time includes stoppage; derived exposure
                    # excludes it. They should not be forced to exact equality.
                    if s['played_seconds_including_stoppage']/60+1e-7<expected:issues.append(dict(game_id=gid,player_id=pid,reason='Reported elapsed minutes shorter than event-derived exposure; inspect both definitions'))
    public=[]
    if not full:
        client=OfficialClient(per_second=2)
        examples=[('2029849','https://www.uefa.com/uefaeuropaleague/match/2029849--wolfsberg-vs-tottenham/','Wolfsberger 1-4 Tottenham'),
                  ('2033450','https://www.uefa.com/uefaeuropaleague/match/2033450--frankfurt-vs-rangers/','Frankfurt 1-1 Rangers'),
                  ('2039948','https://www.uefa.com/uefaconferenceleague/match/2039948--union-sg-vs-frankfurt/','Union SG 2-2 Frankfurt')]
        for native,url,label in examples:
            b,s=client.get(url,'Public UEFA fixture/result validation for historical player workload pilot','uefa_workload_public_verification',document=True)
            title=html.unescape(re.findall(r'<title[^>]*>(.*?)</title>',b.decode(),re.S)[0]);assert label in title
            g=next(g for g in records if g['game_validation']['official_game_id']==native);raw=g['game_validation']
            numbers=re.search(r'(\d+)-(\d+)',label);assert [int(numbers[1]),int(numbers[2])]==[raw['total_scores']['home'],raw['total_scores']['away']]
            public.append(dict(official_game_id=native,public_title=title,source=s,official_api_date=raw['date'],official_api_start_utc=raw['start_utc'],
                identity_and_full_match_score_agree=True,date_source='Official match API plus separate official calendar; public title contains no kickoff timestamp',
                scores=raw['total_scores'],regulation_scores=raw['regulation_scores']))
        dump(RUN/'public_verification.json',public)
        assert not issues,issues
    report=dict(status='PASS' if not issues else 'REPAIR_REQUIRED',at_utc=stamp(),pilot=not full,games=len(records),raw_sources=len(cache),raw_statistic_cells=cells,
        official_elapsed_time_checks=reported_times,independently_replayed_player_minutes=people,official_appearance_checks=appearances,issues=issues,
        public_examples=len(public),no_current_biography_club_or_age_inputs=True,source_seconds_and_derived_minutes_kept_separate=True)
    dump(RUN/('validation.json' if full else 'pilot_validation.json'),report)
    import collections
    print(json.dumps({k:v for k,v in report.items() if k!='issues'}|dict(issue_counts=dict(collections.Counter(x['reason'] for x in issues)))),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--full',action='store_true');a=p.parse_args();main(a.full)
