"""Past-only team/roster discipline features and a controlled rolling test."""
import argparse,collections,json,sqlite3
import numpy as np
import pandas as pd
from common import ROOT_OUT,read_db,dump,stamp,file_sha256
from nhl_player_strength import load
from nhl_identity_features import identity_evidence
from final_pipeline import discard_work

WORK=ROOT_OUT/'_work/nhl_penalties'
FIELDS=['f_gran_penalty_net_diff','f_gran_bench_penalty_diff','f_gran_roster_penalty_net_per60_diff']


def derive(games,players,rosters,keys,skaters,teams):
    games=games.sort_values(['prediction_time','game_id'])
    observed=players[(players.minutes.gt(0)|players.played.eq(1))&players.position.ne('G')]
    bygame={k:g for k,g in observed.groupby(['game_id','side'])};empty=observed.iloc[:0]
    stats={k:g.to_dict('records') for k,g in skaters.groupby('game_id')}
    ts={k:g.to_dict('records') for k,g in teams.groupby('game_id')}
    events=[(g.available_time,1,g.game_id,g) for g in games.itertuples()]
    for (_,team,at),g in rosters.groupby(['season','team_id','available_at_utc']):
        if g.identity_verified.eq(1).all() and g.official_player_id.notna().all() and g.position.notna().all():
            events.append((pd.Timestamp(at),0,str(team),g[g.position.ne('G')]))
    events.sort(key=lambda e:(e[0],e[1],e[2]));cursor=0
    pools=collections.defaultdict(lambda:collections.deque(maxlen=5))
    usage=collections.defaultdict(lambda:collections.deque(maxlen=5));known_minutes=[];lastteam={}
    player_stats=collections.defaultdict(lambda:collections.deque(maxlen=20))
    team_stats=collections.defaultdict(lambda:collections.deque(maxlen=20))
    identity_at=pd.Timestamp(identity_evidence()['conservative_available_at_utc'])
    rows=[]
    for g in games.itertuples():
        while cursor<len(events) and events[cursor][0]<g.prediction_time:
            at,kind,key,event=events[cursor];cursor+=1
            if kind==1:
                for r in stats.get(event.game_id,[]):
                    assert pd.Timestamp(r['available_at_utc'])==at
                    player_stats[str(r['official_player_id'])].append((r['net_penalties'],r['playing_seconds'],at))
                for r in ts.get(event.game_id,[]):
                    assert pd.Timestamp(r['available_at_utc'])==at
                    team_stats[keys[event.game_id,r['side']]].append((r['net_penalties'],r['bench_minor_penalties'],at))
                for side in ['A','B']:
                    team=keys[event.game_id,side];pool=[]
                    for p in bygame.get((event.game_id,side),empty).itertuples():
                        pid=str(p.official_player_id);lastteam[pid]=team
                        if pd.notna(p.minutes) and p.minutes>0:
                            weight=float(p.minutes);usage[pid].append(weight);known_minutes.append(weight)
                        else:weight=float(np.mean(usage[pid])) if usage[pid] else (float(np.median(known_minutes)) if known_minutes else None)
                        if weight is not None:pool.append((pid,weight))
                    if pool:pools[team].append((pool,at))
            else:
                team=key
                if team=='68':assert at>=identity_at;team='59'
                pool=[]
                for p in event.itertuples():
                    pid=str(p.official_player_id);lastteam[pid]=team
                    weight=float(np.mean(usage[pid])) if usage[pid] else (float(np.median(known_minutes)) if known_minutes else None)
                    if weight is not None:pool.append((pid,weight))
                pools[team].clear()
                if pool:pools[team].append((pool,at))
        values={};latest=[];coverage={};history_n={}
        for side in ['A','B']:
            team=keys[g.game_id,side];hist=team_stats[team];history_n[side]=len(hist)
            values[side]=[float(np.mean([r[i] for r in hist])) if hist else np.nan for i in [0,1]]
            latest.extend(r[2] for r in hist)
            weights=collections.Counter()
            for pool,at in pools[team]:
                latest.append(at)
                for pid,w in pool:
                    if lastteam.get(pid)==team:weights[pid]+=w
            numerator=0.;den=0.
            for pid,w in weights.items():
                hist=player_stats[pid];seconds=sum(r[1] for r in hist)
                if seconds>0:
                    numerator+=w*3600*sum(r[0] for r in hist)/seconds;den+=w
                    latest.extend(r[2] for r in hist)
            values[side].append(numerator/den if den>0 else np.nan)
            coverage[side]=den/sum(weights.values()) if weights else np.nan
        assert not latest or max(latest)<g.prediction_time
        row=dict(game_id=g.game_id,date=g.date,prediction_time=g.prediction_time,
            penalty_source_max_utc=max(latest) if latest else pd.NaT,
            teamA_penalty_history_games=history_n['A'],teamB_penalty_history_games=history_n['B'],
            teamA_roster_penalty_history_fraction=coverage['A'],teamB_roster_penalty_history_fraction=coverage['B'])
        row.update({name:values['B'][i]-values['A'][i] for i,name in enumerate(FIELDS)});rows.append(row)
    return pd.DataFrame(rows)


def publish(frame,validation):
    table='nhl_dated_penalty_features';path=ROOT_OUT/(table+'.parquet')
    descriptions={
      'game_id':('Canonical game identifier','identifier'), 'date':('Official game date','YYYY-MM-DD'),
      'prediction_time':('Pre-match feature cutoff','UTC timestamp'),
      'penalty_source_max_utc':('Latest earlier source availability used in team statistics, player statistics or roster weights','UTC timestamp'),
      FIELDS[0]:('Home minus away mean net penalties drawn-minus-taken over last 20 observed team games','penalties/game'),
      FIELDS[1]:('Home minus away mean bench minor penalties over last 20 observed team games','penalties/game'),
      FIELDS[2]:('Home minus away recent-roster-weighted net penalties per 60 player-minutes, each player using last 20 observed penalty games','penalties/60 player-minutes')}
    for side in ['A','B']:
        descriptions['team'+side+'_penalty_history_games']=('Earlier observed team games contributing to the rolling mean, maximum 20','games')
        descriptions['team'+side+'_roster_penalty_history_fraction']=('Fraction of expected roster usage with earlier penalty statistics; uncovered players are not assigned zero','fraction 0-1')
    frame.to_parquet(path,index=False);frame.to_csv(ROOT_OUT/(table+'.csv'),index=False)
    sql=frame.copy()
    for col in ['prediction_time','penalty_source_max_utc']:sql[col]=sql[col].map(lambda v:v.isoformat() if pd.notna(v) else None)
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        sql.to_sql(table,db,if_exists='replace',index=False)
        for cat in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+cat+' WHERE "table"=?',[table])
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',[table,len(frame),len(frame.columns)])
        for col in frame:
            meaning,unit=descriptions[col]
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',[table,col,meaning,unit,'Derived from official NHL penalty reports, earlier appearances, and dated opening rosters; nhl_penalty_features.py. No current-game lineup or odds inputs.'])
            missing=int(frame[col].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',[table,col,len(frame),missing,100*missing/len(frame)])
    validation['derived_data_sha256']=file_sha256(path);dump(ROOT_OUT/'retention/nhl_penalty_features_validation.json',validation)


def build(evaluate=False):
    assert not WORK.exists(),'Inspect unfinished work before a new run'
    WORK.mkdir(parents=True)
    try:
        assert json.loads((ROOT_OUT/'retention/nhl_penalties_validation.json').read_text())['status']=='PASS'
        games,players,rosters,keys=load()
        with read_db(ROOT_OUT/'granular.sqlite') as db:
            skaters=pd.read_sql_query('SELECT * FROM nhl_player_penalty_statistics',db)
            teams=pd.read_sql_query('SELECT * FROM nhl_team_penalty_statistics',db)
        extra=derive(games,players,rosters,keys,skaters,teams)
        early=games[games.prediction_time.lt(pd.Timestamp('2025-01-01',tz='UTC'))]
        prefix=derive(early,players[players.game_id.isin(early.game_id)],rosters[pd.to_datetime(rosters.available_at_utc,utc=True,format='mixed').lt(pd.Timestamp('2025-01-01',tz='UTC'))],keys,
            skaters[skaters.game_id.isin(early.game_id)],teams[teams.game_id.isin(early.game_id)])
        pd.testing.assert_frame_equal(prefix.set_index('game_id'),extra.set_index('game_id').loc[prefix.game_id],check_exact=True)
        validation=dict(at_utc=stamp(),status='PASS',games=len(extra),prefix_invariant_rows=len(prefix),new_features=len(FIELDS),
            source_cutoffs_checked=True,source_stats_scope='Regular season/playoffs; preseason forecasts use earlier observed discipline history when available, never assumed zero',
            roster='Last five earlier appearances plus verified dated opening roster, last-known-team filter; usage based only on earlier minutes',
            unknown_players='Excluded from weighted penalty mean with explicit coverage; no unknown penalty value becomes zero')
        publish(extra,validation);print(json.dumps(validation),flush=True)
        if not evaluate:return
        plan=dict(at_utc=stamp(),hypothesis='Player penalties drawn/taken and team bench discipline improve winner forecasts beyond power-play efficiency.',
            history_start='2021-01-01',forecast_start='2024-01-01',scope=['Regular Season','Playoffs','Preseason'],features=FIELDS,
            selection='Lower pooled2024/25 mean component logloss against same-cohort control; only then evaluate2026. Monthly selector sees earlier forecast errors only. No return-based tuning.',
            fixed_windows='20 earlier penalty-stat games per player/team; five earlier team appearances for expected roster usage. Not tuned.',
            stakes='Both retained model families require p/price>=1.10; pre12 nearest-prior quote age<=24h;1%NAV/bet;20%open-cost cap; annual$10000; no costs.',
            source_hashes={name:file_sha256(ROOT_OUT/name) for name in ['nhl_player_penalty_statistics.parquet','nhl_team_penalty_statistics.parquet','nhl_dated_penalty_features.parquet']},
            limitation='2026 repeatedly inspected retrospective; current historical stats revisions do not prove original publication vintage.')
        dump(WORK/'plan.json',plan)
        import features,nhl_identity_features
        from repair_nhl_player_exposure import apply as apply_repairs
        g,o,p,_,stats,metrics,_=features.sources('nhl',include_preseason=True)
        needed=['game_id','side','available_at_utc','player_id','official_player_id','minutes','position','saves','shots_against','played']+metrics
        p=apply_repairs(p[list(dict.fromkeys(needed))])
        base,_=nhl_identity_features.derive(g,o,p,stats,metrics,repaired=True,regulation_labels=games)
        frame=base.merge(extra.drop(columns=['date','prediction_time']),on='game_id',validate='one_to_one')
        frame.to_parquet(WORK/'nhl_features.parquet',index=False)
        validation['feature_sha256']=file_sha256(WORK/'nhl_features.parquet');dump(WORK/'feature_validation.json',validation)
        from evaluate_nhl_player_strength import main as compare
        compare(WORK,FIELDS,ROOT_OUT/'simulation_results/feature_revisions/nhl_penalties')
    finally:
        if WORK.exists():discard_work(WORK)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--evaluate',action='store_true');args=p.parse_args();build(args.evaluate)
