"""Isolated Nations League test of the selected soccer recipe; never deploys."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,hashlib,json,pickle,sqlite3,sys,urllib.parse,unicodedata,math,collections,gc,shutil,html
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

PROJECT=Path(r'C:\Users\Jerry\Desktop\Sports ML')
SOURCE=PROJECT/'data collecting/nhl_soccer_iteration'
sys.path.insert(0,str(SOURCE))
from common import ROOT_OUT,dump,stamp,file_sha256,OfficialClient
import features,models

LABEL='nations_strategy_review'
WORK=ROOT_OUT/'_work'/LABEL
RESULT=ROOT_OUT/'simulation_results'/LABEL
BASE=ROOT_OUT/'retained_models/us_strategy_baselines/soccer'
END=pd.Timestamp('2026-09-30',tz='UTC')
POINT_BASE=5.


def plan():
    WORK.mkdir(parents=True,exist_ok=True)
    path=WORK/'protocol.json'
    if path.exists():return
    dump(path,dict(at_utc=stamp(),hypothesis='Test the selected soccer recipe with Nations League as an additional competition; no hyperparameter search.',
        primary='p>0.51 and calibrated confidence>0.55, selected outcome YES only',
        models='Same selected C=.02 league-scaled logistic recipe; same 180-day earlier-only monthly calibration. Add Nations history and its own league indicator; preserve all club feature rows. Confidence gate uses the frozen September fit from earlier US club OOS examples.',
        history='409 official Nations games from2021 through2026-09-29; 56games in2026. Forecast2024 onward. Pool club and Nations training rows. National team form uses Nations matches; player form also uses earlier club performances through verified shared UEFA and canonical person IDs. Prior national appearances define the roster, never the current game final lineup.',
        missing='No invented xG, club coefficients, challenges or missing provider statistics. Training-only imputation; missingness reported.',
        temporal='Sports features frozen at T-12h. Every sports fitting/calibration label precedes the monthly boundary. Result settlement uses verified official result availability.',
        pricing='Official Polymarket US selected YES longPrice; quote must be at/after market creation and in the T-12h to entry window. No international quote substitution.',
        execution='Primary first qualifying 5-minute decision from T-12h; quote age at most60seconds for minute history. Full fill at observed ask is an explicit simulation assumption; historical depth/queue unavailable. T-1h snapshot is a separately reported fixed comparison, not selected by returns.',
        sizing='5*max(100p-51,0), initial$2000, soccer normal35%/hard45% of A=2000, borrowing unused sleeves allowed, cash only, hold through result. No leverage or allocation sweep.',
        costs='Report gross quote-fill result and a separately labeled .05 fee-coefficient sensitivity matching current app reserve formula; historical actual fees/fills not established.',
        diagnostics='Raw forecast accuracy/logloss/Brier by year; confidence gate vs p-only diagnostic, no strategy selection by these results.',
        research_only=True,app_deployment=False))


def normalized():
    g=pd.read_parquet(ROOT_OUT/'nations_league_games.parquet')
    team=pd.read_parquet(ROOT_OUT/'nations_match_team_statistics.parquet')
    p=pd.read_parquet(ROOT_OUT/'nations_league_player_match_statistics.parquet')
    action=pd.read_parquet(ROOT_OUT/'nations_match_player_statistics.parquet')
    for col in ('start_time','available_time'):g[col]=pd.to_datetime(g[col],utc=True,format='mixed')
    g['prediction_time']=g.start_time-pd.Timedelta(hours=12)
    g['target']=np.where(g.scoreA.eq(g.scoreB),2,g.scoreB.gt(g.scoreA).astype(int))
    assert g.game_id.is_unique and len(g)==409 and g.start_time.max()<END
    keys={(r.game_id,s):'NATION:'+getattr(r,'team'+s+'_id') for r in g.itertuples() for s in ('A','B')}
    # Native ID joins, preserving event-verified participation and regulation goals.
    idx=['game_id','side','official_player_id']
    action['official_player_id']=action.lineup_player_id.fillna(action.official_player_id)
    for frame in (p,action):frame['official_player_id']=frame.official_player_id.astype(str)
    assert not p.duplicated(idx).any() and not action.duplicated(idx).any()
    p=p.merge(action[idx+['key_passes','attempts_on_target','distance_covered','source_units_json','lineup_identity_verified']],on=idx,how='left',validate='one_to_one')
    assert p.loc[p.key_passes.notna()|p.attempts_on_target.notna(),'lineup_identity_verified'].eq(True).all()
    p['player_id']='NATION_PLAYER:'+p.official_player_id
    p['shots_on_target']=p.attempts_on_target
    for r in p[p.distance_covered.notna()].itertuples():assert json.loads(r.source_units_json)['distance_covered']=='KILOMETER'
    p['distance_covered_km']=p.distance_covered
    p['available_at_utc']=pd.to_datetime(p.available_at_utc,utc=True,format='mixed')
    latest=p.groupby('game_id').available_at_utc.max()
    labels=g.set_index('game_id').available_time.copy()
    g['available_time']=pd.concat([g.available_time,g.game_id.map(latest)],axis=1).max(axis=1)
    lookup=g.set_index('game_id')
    o=team[['game_id','side']].copy()
    assert len(o)==len(g)*2 and not o.duplicated(['game_id','side']).any()
    o['start_time']=o.game_id.map(lookup.start_time);o['available_time']=o.game_id.map(lookup.available_time)
    for field in ('score_for','score_against'):
        o[field]=[lookup.loc[r.game_id,'score'+(r.side if field=='score_for' else ('B' if r.side=='A' else 'A'))] for r in o.itertuples()]
    direct={'shots':'attempts','shots_on_target':'attempts_on_target','passes':'passes_attempted','passes_completed':'passes_completed',
            'long_passes':'passes_long_attempted','box_shots':'shot_in_penalty_area','big_chances':'big_chance'}
    for dest,raw in direct.items():o[dest]=pd.to_numeric(team[raw],errors='coerce')
    for name in ('quality_xg','quality_xg_against','finishing_residual'):o[name]=np.nan
    swapped=o[['game_id','side','shots','shots_on_target','passes']].copy();swapped['side']=swapped.side.map({'A':'B','B':'A'})
    swapped=swapped.rename(columns={c:c+'_opponent' for c in swapped if c not in ('game_id','side')})
    o=o.merge(swapped,on=['game_id','side'],validate='one_to_one')
    ratio=lambda a,b:a/b.where(b>0)
    derived={'shot_share':ratio(o.shots,o.shots+o.shots_opponent),'on_target_share':ratio(o.shots_on_target,o.shots_on_target+o.shots_on_target_opponent),
        'passing_completion':ratio(o.passes_completed,o.passes),'direct_passing_fraction':ratio(o.long_passes,o.passes),
        'box_attempt_fraction':ratio(o.box_shots,o.shots)}
    for k,v in derived.items():o['context8_'+k]=v
    stats=['score_for','score_against','quality_xg','quality_xg_against','finishing_residual','shots_on_target','big_chances']+['context8_'+k for k in derived]
    metrics=['goals','assists','key_passes','distance_covered_km']
    return g,o,p,keys,stats,metrics,labels


def add_club_player_form(f,g,p):
    """Use prior national roster weights with pooled verified player histories."""
    cache=PROJECT/'collected data/result/sports_live/soccer/history'
    fields=['goals','assists','key_passes','distance_covered_km','challenges_won','shots_at_goal']
    source=pd.read_pickle(cache/'players.pkl')
    cols=['game_id','league','official_player_id','player_id','minutes','available_at_utc']+fields
    club=source.reindex(columns=cols).copy();del source;gc.collect()
    club['official_player_id']=club.official_player_id.astype(str)
    cg=pd.read_pickle(cache/'games.pkl')
    club['available_at_utc']=pd.to_datetime(club.available_at_utc,utc=True,format='mixed')
    club['available_at_utc']=pd.concat([club.available_at_utc,club.game_id.map(cg.set_index('game_id').available_time)],axis=1).max(axis=1)
    cross=club[club.league.eq('UEFA Champions League')][['official_player_id','player_id']].drop_duplicates()
    assert cross.groupby('official_player_id').player_id.nunique().max()==1
    mapping=cross.set_index('official_player_id').player_id.to_dict()
    national=p.copy();national['player_id']=national.official_player_id.map(lambda pid:mapping.get(pid,'NATION_PLAYER:'+pid))
    # Evidence for other league links was already validated when this cache was built.
    assert json.loads((ROOT_OUT/'soccer_identity_sources_v58/identity_validation.json').read_bytes())['status']=='PASS'
    combined=pd.concat([club,national.reindex(columns=cols)],ignore_index=True)
    combined=combined[combined.minutes.gt(0)&combined.available_at_utc.lt(END)].copy()
    assert not combined.duplicated(['game_id','player_id']).any()
    histories={}
    for pid,group in combined.groupby('player_id',sort=False):
        group=group.sort_values(['available_at_utc','game_id'])
        histories[pid]=(group.available_at_utc.dt.as_unit('ns').astype('int64').to_numpy(),group[fields].to_numpy(float),group.minutes.to_numpy(float),group.league.ne('UEFA Nations League').to_numpy(),group.available_at_utc.tolist())
    nat=national[national.minutes.gt(0)].copy()
    games=g.set_index('game_id');nat['team']=[games.loc[r.game_id,'team'+r.side+'_id'] for r in nat.itertuples()]
    rows=[]
    for idx,row in f.iterrows():
        cut=row.prediction_time.value;prior=nat[nat.available_at_utc.lt(row.prediction_time)]
        latest_team=prior.sort_values('available_at_utc').groupby('player_id').team.last().to_dict()
        values={};source_times=[];linked=0;roster_total=0
        for side in ('A','B'):
            tid=games.loc[row.game_id,'team'+side+'_id'];team=prior[prior.team.eq(tid)]
            ids=team[['game_id','available_at_utc']].drop_duplicates().sort_values('available_at_utc').tail(5).game_id
            weights=team[team.game_id.isin(ids)].groupby('player_id').minutes.sum()
            weights={pid:w for pid,w in weights.items() if latest_team.get(pid)==tid}
            roster_total+=len(weights);rates={field:[] for field in fields}
            for pid,w in weights.items():
                dates,measurements,minutes,clubrows,source_dates=histories[pid]
                end=np.searchsorted(dates,cut,side='left');start=max(0,end-30)
                # Independent Timestamp comparison catches microsecond/nanosecond mismatches.
                expected=[j for j,source_date in enumerate(source_dates) if source_date<row.prediction_time][-30:]
                assert expected==list(range(start,end)), 'Player history must equal a direct earlier-only timestamp filter'
                if end==0:continue
                linked+=int(clubrows[start:end].any());source_times.append(int(dates[end-1]))
                for j,field in enumerate(fields):
                    v=measurements[start:end,j];mins=minutes[start:end];valid=np.isfinite(v)&np.isfinite(mins)&(mins>0)
                    if valid.any():rates[field].append((w,90*float(v[valid].sum())/float(mins[valid].sum())))
            values[side]={field:sum(w*v for w,v in observations)/sum(w for w,v in observations) if observations else np.nan for field,observations in rates.items()}
        for field in fields:f.loc[idx,'f_ctx_roster_'+field+'_rate_diff']=values['B'][field]-values['A'][field]
        maximum=pd.Timestamp(max(source_times),tz='UTC') if source_times else pd.NaT
        assert pd.isna(maximum) or maximum>=pd.Timestamp('2021-01-01',tz='UTC')
        assert pd.isna(maximum) or maximum<row.prediction_time
        if pd.notna(maximum) and (pd.isna(row.source_max_available_utc) or maximum>row.source_max_available_utc):f.loc[idx,'source_max_available_utc']=maximum
        rows.append(dict(game_id=row.game_id,cutoff=str(row.prediction_time),roster_players=roster_total,
                         players_with_prior_club_form=linked,max_player_source=str(maximum)))
    pd.DataFrame(rows).to_csv(WORK/'player_form_coverage.csv',index=False)
    dump(WORK/'player_link_validation.json',dict(status='PASS',club_appearances=len(club),unique_shared_uefa_players=len(set(p.official_player_id)&set(mapping)),
        no_future_rosters=True,no_name_only_joins=True,club_players_sha256=file_sha256(cache/'players.pkl'),
        canonical_links_sha256=file_sha256(ROOT_OUT/'soccer_research_player_identity_links.parquet'),
        note='Same UEFA native IDs bridge national to club records; existing verified static person links bridge club providers. National team membership and club membership remain distinct.'))
    return f


def prepare():
    plan();g,o,p,keys,stats,metrics,labels=normalized()
    f,audit=features.build('soccer',g,o,p,keys,stats,metrics)
    for col in list(f):
        if col.startswith('f_context8_') and col.endswith('_diff'):f[col.replace('f_context8_','f_ctx_')]=f[col]
    for field in ['quality_xg','quality_xg_against','finishing_residual','shots_on_target','big_chances','roster_goals_rate','roster_assists_rate','roster_key_passes_rate','roster_distance_covered_km_rate','roster_players']:
        f['f_ctx_'+field+'_diff']=f['f_'+field+'_diff']
    f=add_club_player_form(f,g,p)
    b=pickle.loads((BASE/'sports_model.pkl').read_bytes())
    for c in b['columns']:
        if c.startswith('league_'):f[c]=0.
        elif c not in f:f[c]=np.nan
    f['league_UEFA Nations League']=1.
    f['available_time']=f.game_id.map(labels)
    f=f.merge(g[['game_id','teamA','teamB','home_away']],on='game_id',validate='one_to_one')
    assert (f.source_max_available_utc.isna()|f.source_max_available_utc.lt(f.prediction_time)).all()
    past=g[g.start_time.lt(pd.Timestamp('2026-01-01',tz='UTC'))]
    prefix,_=features.build('soccer',past,o[o.game_id.isin(past.game_id)],p[p.game_id.isin(past.game_id)],keys,stats,metrics)
    numeric=[c for c in prefix if c.startswith('f_')]
    np.testing.assert_allclose(f.set_index('game_id').loc[prefix.game_id,numeric],prefix[numeric],equal_nan=True,rtol=0,atol=0)
    f.to_parquet(WORK/'features.parquet',index=False)
    sources=['nations_league_games.parquet','nations_match_team_statistics.parquet','nations_league_player_match_statistics.parquet','nations_match_player_statistics.parquet']
    dump(WORK/'feature_validation.json',dict(status='PASS',rows=len(f),prefix_rows=len(prefix),no_future_inputs=True,
        source_sha256={n:file_sha256(ROOT_OUT/n) for n in sources},
        baseline_sha256={n:file_sha256(BASE/n) for n in ['sports_model.pkl','soccer_features.parquet','confidence_model.pkl']},
        missing_2026_pct={c:round(100*f.loc[f.date.ge('2026'),c].isna().mean(),3) for c in b['columns'] if not c.startswith('league_')},
        neutral_venue_games=int(f.home_away.eq('Away;Away').sum()),
        limitations=['No club coefficients used for national teams','Unavailable physical/action inputs remain NaN','Designated B-side home convention follows selected recipe; neutral fixtures are flagged']))
    print(json.dumps(dict(stage='features',rows=len(f),prefix_checks=len(prefix))),flush=True)


def fit():
    plan();nation=pd.read_parquet(WORK/'features.parquet');club=pd.read_parquet(BASE/'soccer_features.parquet')
    b=pickle.loads((BASE/'sports_model.pkl').read_bytes());cols=b['columns']+['league_UEFA Nations League']
    club['league_UEFA Nations League']=0.
    allrows=pd.concat([club,nation],ignore_index=True)
    assert not allrows.game_id.duplicated().any()
    for c in ['prediction_time','available_time','start_time']:allrows[c]=pd.to_datetime(allrows[c],utc=True)
    output=[];audits=[]
    for fold,test in nation[nation.date.ge('2024')].groupby(nation.prediction_time.dt.strftime('%Y-%m')):
        cut=pd.Timestamp(fold,tz='UTC');prior=allrows[allrows.available_time.lt(cut)].sort_values(['prediction_time','game_id'])
        cal=prior[prior.prediction_time.ge(cut-pd.Timedelta(days=180))]
        train=prior[prior.available_time.lt(cal.prediction_time.min())]
        assert len(cal)>=60 and len(train)>=200
        X=lambda frame:frame[cols].replace([np.inf,-np.inf],np.nan).astype(float)
        with threadpool_limits(limits=2):
            old=models.make_model(b['recipe'],'soccer');models.fit_model(old,X(train),train,b['recipe'],cal.prediction_time.min())
            calibrator=models.calibration_fit(old.predict_proba(X(cal)),cal.target.astype(int))
            model=models.make_model(b['recipe'],'soccer');models.fit_model(model,X(prior),prior,b['recipe'],cut)
            prob=models.apply_calibration(model.predict_proba(X(test)),calibrator)
        assert np.isfinite(prob).all() and np.allclose(prob.sum(axis=1),1)
        z=test.copy();z[['p0','p1','p2']]=prob;z['selected']=prob.argmax(axis=1);z['p']=prob.max(axis=1)
        z['correct']=z.selected.eq(z.target);z['fold']=fold;z['train_label_max']=prior.available_time.max()
        assert z.train_label_max.lt(z.prediction_time).all() and train.available_time.max()<cal.prediction_time.min()
        output.append(z)
        row=dict(fold=fold,training=len(prior),nations_training=int(prior.league.eq('UEFA Nations League').sum()),
                 calibration=len(cal),test_games=len(test),train_label_max=str(prior.available_time.max()),
                 calibration_fit_label_max=str(train.available_time.max()),calibration_start=str(cal.prediction_time.min()))
        audits.append(row);print(json.dumps(row),flush=True)
    p=pd.concat(output,ignore_index=True);p.to_parquet(WORK/'predictions.parquet',index=False)
    dump(WORK/'fit_validation.json',dict(status='PASS',folds=audits,rows=len(p),test_tuning=False,models_retained=False))


def norm(x):return ''.join(c for c in unicodedata.normalize('NFKD',str(x)).lower() if c.isascii() and c.isalnum())


def contracts():
    p=pd.read_parquet(WORK/'predictions.parquet')
    events=json.loads((ROOT_OUT/'simulation_results/us_market_revision/events.json').read_bytes())
    aliases={'czechrepublic':'czechia','republicofireland':'ireland','turkey':'turkiye','moldova':'moldova'}
    canonical=lambda x:aliases.get(norm(x),norm(x))
    rows=[];unmatched=[]
    for g in p[p.date.ge('2026')].to_dict('records'):
        games=[e for e in events if 'unl' in e['tags'] and abs(pd.Timestamp(e['startTime'])-g['start_time'])<=pd.Timedelta(minutes=5)]
        pair={canonical(g['teamA']),canonical(g['teamB'])};found=[]
        for e in games:
            names={canonical(s['team']['name']) for m in e['markets'] for s in m.get('marketSides',[]) if s.get('team')}
            if names==pair:found.append(e)
        if len(found)!=1:unmatched.append(dict(game_id=g['game_id'],reason='No unique exact team/time US event',matches=len(found)));continue
        e=found[0];pick=int(g['selected']);selected=[]
        for m in e['markets']:
            if m['sportsMarketType']!='soccer_team_full_time_winner':continue
            if pd.Timestamp(m['gameStartTime'])!=g['start_time']:continue
            assert '90 minutes' in m['description'],m['slug']
            for side in m.get('marketSides',[]):
                if not side.get('long'):continue
                team=side.get('team')
                target=2 if not team and m['slug'].endswith('-draw') else next((i for i,s in enumerate('AB') if team and canonical(team['name'])==canonical(g['team'+s])),None)
                if target==pick:
                    assert float(side['price'])==int(pick==g['target']),'US final settlement differs from official regulation result'
                    selected.append(dict(game_id=g['game_id'],market_slug=m['slug'],market_id=str(m['id']),contract_id=str(side['id']),
                        selected=pick,event_id=e['id'],created_at=m['createdAt'],start=str(g['start_time']),source_request=e['source_request']))
        if len(selected)==1:rows.extend(selected)
        else:unmatched.append(dict(game_id=g['game_id'],reason='Selected outcome contract not unique',matches=len(selected)))
    pd.DataFrame(rows).to_parquet(WORK/'contracts.parquet',index=False)
    dump(WORK/'mapping_validation.json',dict(status='PASS',forecasts=int(p.date.ge('2026').sum()),matched=len(rows),unmatched=unmatched,settlements_checked=True))
    print(json.dumps(dict(stage='market_mapping',matched=len(rows),unmatched=len(unmatched))),flush=True)


class PriceClient(OfficialClient):
    HOSTS=OfficialClient.HOSTS|{'gateway.polymarket.us'}
    def connect(self):
        c=sqlite3.connect(WORK/'acquisition.sqlite',timeout=60);c.row_factory=sqlite3.Row;c.execute('PRAGMA journal_mode=WAL');return c


def prices():
    contracts();client=PriceClient(per_second=3);data=pd.read_parquet(WORK/'contracts.parquet');rows=[];audit=[]
    def fetch(c):
        start=pd.Timestamp(c['start']);lo=start-pd.Timedelta(hours=12)
        query={'symbol':c['market_slug'],'timestamp.startTimestamp':int(lo.timestamp()),'timestamp.endTimestamp':int(start.timestamp()),'fidelity':1}
        body,source=client.get('https://gateway.polymarket.us/v1/price-history?'+urllib.parse.urlencode(query),'Nations selected YES pregame history '+c['market_slug'],'polymarket_us')
        assert source['return_status']=='200' and isinstance(body.get('history'),list),source
        result=[];rejected=0
        for i,v in enumerate(body['history']):
            at=pd.Timestamp(v['timestamp'],unit='s',tz='UTC');q=float(v['longPrice']) if v.get('longPrice') is not None else np.nan
            if lo<=at<start and at>=pd.Timestamp(c['created_at']) and 0<q<1:
                result.append(dict(game_id=c['game_id'],market_slug=c['market_slug'],at=at,ask=q,
                    bid=1-float(v['shortPrice']) if v.get('shortPrice') is not None else np.nan,
                    request_number=source['request_number'],raw_pointer='/history/'+str(i)))
            else:rejected+=1
        return result,dict(game_id=c['game_id'],market_slug=c['market_slug'],raw_rows=len(body['history']),valid_rows=len(result),rejected_rows=rejected,source=source)
    with ThreadPoolExecutor(max_workers=3) as pool:
        for i,(points,record) in enumerate(pool.map(fetch,data.to_dict('records')),1):
            rows.extend(points);audit.append(record)
            if i%10==0 or i==len(data):print(json.dumps(dict(stage='prices',completed=i,total=len(data),points=len(rows))),flush=True)
    q=pd.DataFrame(rows);assert not q.duplicated(['game_id','at']).any()
    q.to_parquet(WORK/'prices.parquet',index=False);dump(WORK/'price_acquisition.json',audit)


def decisions():
    # Use the app's actual confidence feature formulas, including YES ask units.
    sys.path.append(str(PROJECT/'sports_app'))
    from live_trading import context_values,confidence_values
    from scipy.special import softmax
    p=pd.read_parquet(WORK/'predictions.parquet');q=pd.read_parquet(WORK/'prices.parquet')
    bundle=pickle.loads((BASE/'confidence_model.pkl').read_bytes())
    rows=[];audit=[]
    for g in p[p.date.ge('2026')].to_dict('records'):
        prices=q[q.game_id.eq(g['game_id'])].sort_values('at')
        if prices.empty:
            audit.append(dict(game_id=g['game_id'],quotes=0,reason='No matched US history'));continue
        assert pd.Timestamp(bundle['calibration_label_max'])<g['prediction_time']
        assert pd.Timestamp(bundle['boundary'])<=g['prediction_time']
        prediction=dict(probabilities=[g['p0'],g['p1'],g['p2']],selected='ABD'[int(g['selected'])])
        context=context_values(g);history=list(zip(prices['at'],prices.ask))
        inputs=[];records=[]
        for at in pd.date_range(g['prediction_time'],g['start_time'],freq='5min',inclusive='left'):
            observed=prices[prices['at'].le(at)]
            if observed.empty:continue
            last=observed.iloc[-1]
            if (at-last['at']).total_seconds()>60 or not 0<float(last.bid)<=float(last.ask)<1:continue
            values=confidence_values(prediction,dict(ask=last.ask,observed_at=last['at']),context,history,at)
            inputs.append({c:np.nan if values[c] is None else values[c] for c in bundle['columns']})
            records.append(dict(game_id=g['game_id'],at=at,start=g['start_time'],exit=g['available_time'],p=g['p'],
                ask=last.ask,bid=last.bid,quote_at=last['at'],selected=int(g['selected']),target=int(g['target']),correct=bool(g['correct']),
                teamA=g['teamA'],teamB=g['teamB'],home_away=g['home_away'],market_slug=last.market_slug))
        if not records:
            audit.append(dict(game_id=g['game_id'],quotes=len(prices),reason='No current valid book at decision times'));continue
        with threadpool_limits(limits=1):raw=bundle['model'].predict_proba(pd.DataFrame(inputs))
        confidence=softmax(np.log(np.clip(raw,1e-8,1))/float(bundle['temperature']),axis=1)[:,1]
        for r,c in zip(records,confidence):r['confidence']=float(c);r['qualifies']=bool(r['p']>.51 and c>.55)
        rows.extend(records)
        audit.append(dict(game_id=g['game_id'],quotes=len(prices),decision_times=len(records),p_pass=g['p']>.51,
                          qualifying_times=sum(r['qualifies'] for r in records),reason='Evaluated'))
    frame=pd.DataFrame(rows)
    assert frame['at'].lt(frame.start).all() and frame.quote_at.le(frame['at']).all()
    frame.to_parquet(WORK/'decisions.parquet',index=False)
    dump(WORK/'decision_validation.json',dict(status='PASS',records=len(frame),games=frame.game_id.nunique(),
        qualifying_games=frame[frame.qualifies].game_id.nunique(),confidence_training_end=str(bundle['training_label_max']),
        confidence_calibration_end=str(bundle['calibration_label_max']),audit=audit))
    print(json.dumps(dict(stage='decisions',games=frame.game_id.nunique(),qualified=frame[frame.qualifies].game_id.nunique())),flush=True)


def simulate_account(entries,coefficient):
    initial=2000.;cash=initial;opened=[];bets=[];ledger=[]
    def mark(at):
        cost=sum(b['cost'] for b in opened)
        assert cash>=-1e-7 and cost<=900+1e-7
        ledger.append(dict(at=at,cash=cash,open_cost=cost,equity=cash+cost))
    def settle(at):
        nonlocal cash,opened
        due=sorted([b for b in opened if b['exit']<=at],key=lambda b:(b['exit'],b['game_id']))
        for b in due:
            cash+=b['payout'];opened.remove(b);mark(b['exit'])
    def fee(n,q):
        return (math.ceil(coefficient*n*(q*(1-q) if q<=.5 else .25)*100)/100+.01) if coefficient and n else 0.
    mark(pd.Timestamp('2026-01-01',tz='UTC'))
    for at,batch in entries.groupby('at',sort=True):
        settle(at);requests=5*np.maximum(100*batch.p.to_numpy()-51,0)
        room=min(max(900-sum(b['cost'] for b in opened),0),cash)
        # Conservatively share cash including estimated fees at the same instant.
        needs=np.array([v*(1+coefficient*(q*(1-q) if q<=.5 else .25)/q)+(.01 if coefficient else 0) for v,q in zip(requests,batch.ask)])
        scale=min(1.,room/needs.sum()) if needs.sum() else 0.
        for (index,r),request,need in zip(batch.iterrows(),requests,needs):
            allowance=need*scale;n=math.floor(request*scale/r.ask)
            while n>0 and n*r.ask+fee(n,r.ask)>min(allowance,cash)+1e-8:n-=1
            if not n:continue
            cost=n*r.ask;charge=fee(n,r.ask);cash-=cost+charge
            b=dict(r,quantity=n,requested=request,cost=cost,fees=charge,payout=float(n if r.correct else 0),pnl=float(n if r.correct else 0)-cost-charge)
            opened.append(b);bets.append(b);mark(at)
    settle(END);assert not opened
    curve=pd.DataFrame(ledger).sort_values('at',kind='stable')
    calendar=pd.date_range(pd.Timestamp('2026-01-01',tz='UTC'),END-pd.Timedelta(days=1),freq='D')
    daily=curve.assign(day=curve['at'].dt.floor('D')).groupby('day').equity.last().reindex(calendar).ffill().fillna(initial)
    returns=daily.pct_change().fillna(0)
    std=returns.std(ddof=1);equity=curve.equity.to_numpy();drawdown=1-equity/np.maximum.accumulate(equity)
    values=pd.DataFrame(bets);wins=sum(bool(b['correct']) for b in bets)
    result=dict(bets=len(bets),wins=wins,win_rate_pct=100*wins/len(bets) if bets else None,
        initial_cash=initial,final_cash=cash,profit=cash-initial,return_pct=100*(cash/initial-1),
        max_drawdown_pct=100*float(drawdown.max()),calendar_sharpe=float(math.sqrt(365.25)*returns.mean()/std) if std>0 else None,
        fees=sum(b['fees'] for b in bets),purchase_cost=sum(b['cost'] for b in bets),
        max_open_cost=float(curve.open_cost.max()),active_entry_dates=values['at'].dt.date.nunique() if len(values) else 0,
        average_p=float(values.p.mean()) if len(values) else None,average_ask=float(values.ask.mean()) if len(values) else None,
        first_entry=str(values['at'].min()) if len(values) else None,last_entry=str(values['at'].max()) if len(values) else None,
        all_settled=True,cash_never_negative=True)
    assert abs(sum(b['pnl'] for b in bets)-(cash-initial))<1e-6
    return result,values,curve,pd.DataFrame(dict(at=calendar,equity=daily.to_numpy(),return_=returns.to_numpy()))


def simulate():
    decisions()
    from sklearn.metrics import log_loss
    pred=pd.read_parquet(WORK/'predictions.parquet');d=pd.read_parquet(WORK/'decisions.parquet')
    metrics=[]
    for year,g in pred.groupby(pred.date.str[:4]):
        prob=g[['p0','p1','p2']].to_numpy()
        metrics.append(dict(year=int(year),games=len(g),correct=int(g.correct.sum()),accuracy_pct=100*g.correct.mean(),
            log_loss=log_loss(g.target,prob,labels=[0,1,2]),brier=float(np.square(prob-np.eye(3)[g.target.astype(int)]).sum(axis=1).mean()),
            probability_above_51=int(g.p.gt(.51).sum())))
    pd.DataFrame(metrics).to_csv(WORK/'forecast_metrics.csv',index=False)
    eligible=d[d.qualifies].copy();first=eligible.sort_values(['at','game_id']).groupby('game_id',sort=False).head(1)
    pre1=eligible[(eligible.start-eligible['at']).eq(pd.Timedelta(hours=1))].copy()
    summaries=[];trades=[];curves=[];days=[]
    for strategy,entries in [('first_qualified_from_T12',first),('fixed_T1_reference',pre1)]:
        for cost,coefficient in [('gross',0.),('fee_sensitivity',.05)]:
            summary,b,l,c=simulate_account(entries,coefficient)
            meta=dict(strategy=strategy,cost_scenario=cost);summaries.append(meta|summary)
            if len(b):trades.append(b.assign(**meta))
            curves.append(l.assign(**meta));days.append(c.assign(**meta))
    pd.DataFrame(summaries).to_csv(WORK/'annual.csv',index=False)
    (pd.concat(trades,ignore_index=True) if trades else d.head(0).assign(quantity=[],cost=[],fees=[],payout=[],pnl=[],strategy=[],cost_scenario=[])).to_parquet(WORK/'bets.parquet',index=False)
    pd.concat(curves,ignore_index=True).to_parquet(WORK/'ledger.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(WORK/'daily.parquet',index=False)
    dump(WORK/'simulation_validation.json',dict(status='PASS',at_utc=stamp(),summary=summaries,
        cash_limits_checked=True,pnl_reconciled=True,allocation=2000,soccer_hard_cap=900,point_base=5,real_orders_sent=0))
    print(pd.DataFrame(summaries)[['strategy','cost_scenario','bets','wins','return_pct','max_drawdown_pct','calendar_sharpe']].to_string(index=False),flush=True)


def publish():
    """Replay source prices and accounting before retaining the completed study."""
    assert WORK.is_dir() and not RESULT.exists(), 'Inspect any existing publication before replacing it'
    p=pd.read_parquet(WORK/'predictions.parquet');q=pd.read_parquet(WORK/'prices.parquet')
    d=pd.read_parquet(WORK/'decisions.parquet');b=pd.read_parquet(WORK/'bets.parquet')
    ledger=pd.read_parquet(WORK/'ledger.parquet');annual=pd.read_csv(WORK/'annual.csv')
    mapped=pd.read_parquet(WORK/'contracts.parquet').set_index('game_id')
    evidence=json.loads((WORK/'feature_validation.json').read_bytes())
    for name,digest in evidence['source_sha256'].items():assert file_sha256(ROOT_OUT/name)==digest
    for name,digest in evidence['baseline_sha256'].items():assert file_sha256(BASE/name)==digest
    assert p.train_label_max.lt(p.prediction_time).all()
    assert (p.source_max_available_utc.isna()|p.source_max_available_utc.lt(p.prediction_time)).all()
    assert p[['p0','p1','p2']].gt(0).all().all() and np.allclose(p[['p0','p1','p2']].sum(axis=1),1)
    assert np.array_equal(p.selected,p[['p0','p1','p2']].to_numpy().argmax(axis=1))
    replayed=0
    for receipt in json.loads((WORK/'price_acquisition.json').read_bytes()):
        source=receipt['source'];raw=PROJECT/source['raw_file'];assert file_sha256(raw)==source['sha256']
        body=json.loads(raw.read_bytes());game=mapped.loc[receipt['game_id']]
        for row in q[q.game_id.eq(receipt['game_id'])].itertuples():
            original=body['history'][int(row.raw_pointer.rsplit('/',1)[1])]
            assert row.at==pd.Timestamp(original['timestamp'],unit='s',tz='UTC')
            assert row.ask==float(original['longPrice']) and abs(row.bid-(1-float(original['shortPrice'])))<1e-12
            assert pd.Timestamp(game.created_at)<=row.at<pd.Timestamp(game.start)
            replayed+=1
    assert replayed==len(q)
    joined=d.merge(q[['game_id','at','ask','bid']].rename(columns={'at':'quote_at','ask':'source_ask','bid':'source_bid'}),on=['game_id','quote_at'],validate='many_to_one')
    assert len(joined)==len(d) and np.array_equal(joined.ask,joined.source_ask) and np.array_equal(joined.bid,joined.source_bid)
    assert d.quote_at.le(d['at']).all() and (d['at']-d.quote_at).le(pd.Timedelta(seconds=60)).all()
    assert np.array_equal(d.qualifies,d.p.gt(.51)&d.confidence.gt(.55))
    assert b.p.gt(.51).all() and b.confidence.gt(.55).all() and b['at'].lt(b.start).all()
    assert b.exit.gt(b.start).all() and b.quote_at.le(b['at']).all()
    assert np.allclose(b.cost,b.quantity*b.ask) and np.allclose(b.payout,b.quantity*b.correct.astype(int))
    assert np.allclose(b.pnl,b.payout-b.cost-b.fees)
    for row in annual.to_dict('records'):
        trades=b[b.strategy.eq(row['strategy'])&b.cost_scenario.eq(row['cost_scenario'])]
        curve=ledger[ledger.strategy.eq(row['strategy'])&ledger.cost_scenario.eq(row['cost_scenario'])]
        assert len(trades)==row['bets'] and int(trades.correct.sum())==row['wins']
        assert trades.game_id.is_unique and abs(trades.pnl.sum()-row['profit'])<1e-7
        assert abs(curve.iloc[-1].cash-row['final_cash'])<1e-7 and curve.iloc[-1].open_cost==0
        assert curve.cash.ge(-1e-8).all() and curve.open_cost.le(900+1e-8).all()
        assert np.allclose(curve.cash+curve.open_cost,curve.equity)
        if row['strategy']=='first_qualified_from_T12':
            first=d[d.qualifies].groupby('game_id')['at'].min()
            assert all(r.at==first[r.game_id] for r in trades.itertuples())
        else:assert (trades.start-trades['at']).eq(pd.Timedelta(hours=1)).all()
    # Future history must not change the app confidence inputs at an earlier time.
    sys.path.append(str(PROJECT/'sports_app'))
    from live_trading import context_values,confidence_values
    prefix_checks=0
    for row in d.groupby('game_id').head(1).to_dict('records'):
        game=p[p.game_id.eq(row['game_id'])].iloc[0].to_dict();quotes=q[q.game_id.eq(row['game_id'])]
        history=list(zip(quotes['at'],quotes.ask));pred=dict(probabilities=[game['p0'],game['p1'],game['p2']],selected='ABD'[game['selected']])
        book=dict(ask=row['ask'],observed_at=row['quote_at']);ctx=context_values(game)
        assert confidence_values(pred,book,ctx,history,row['at'])==confidence_values(pred,book,ctx,[v for v in history if v[0]<=row['at']],row['at'])
        prefix_checks+=1
    diagnosed=p[p.game_id.isin(mapped.index)&p.p.gt(.51)]
    diagnostic=dict(matched_games=len(mapped),p_only_games=len(diagnosed),p_only_correct=int(diagnosed.correct.sum()),
        confidence_qualified_games=int(d[d.qualifies].game_id.nunique()))
    dump(WORK/'final_validation.json',dict(status='PASS',at_utc=stamp(),raw_price_points_replayed=replayed,
        confidence_prefix_checks=prefix_checks,baseline_files_unchanged=True,source_files_unchanged=True,
        forecast_cutoffs_verified=True,trade_accounting_replayed=True,diagnostic=diagnostic,adopted=False,real_orders_sent=0))
    # A completed experiment retains its outputs and evidence, not fitted trials or feature matrices.
    RESULT.mkdir(parents=True)
    for path in WORK.iterdir():
        if path.suffix in ('.json','.csv','.parquet') and path.name not in ('features.parquet','predictions.parquet'):
            shutil.copy2(path,RESULT/path.name)
            assert file_sha256(path)==file_sha256(RESULT/path.name)
    keep=[c for c in p if not c.startswith(('f_','league_'))]
    p[keep].to_parquet(RESULT/'predictions.parquet',index=False)
    with sqlite3.connect(WORK/'acquisition.sqlite') as source_db,sqlite3.connect(RESULT/'acquisition.sqlite') as target_db:source_db.backup(target_db)
    # sqlite3 context managers commit/rollback; they do not close Windows handles.
    source_db.close();target_db.close()
    primary=b[b.strategy.eq('first_qualified_from_T12')&b.cost_scenario.eq('gross')].copy()
    primary['pick']=[r.teamA if r.selected==0 else r.teamB if r.selected==1 else 'Draw' for r in primary.itertuples()]
    primary.to_csv(RESULT/'primary_bets.csv',index=False)
    report(annual,primary,diagnostic)
    catalog=[]
    descriptions={'at':'Decision/ledger UTC timestamp','quote_at':'Actual source observation timestamp','ask':'YES display price (normally best ask); assumed fill price',
        'bid':'Economic YES bid inferred as 1 - NO display price','p':'Sports model selected-outcome probability','confidence':'Frozen club-trained confidence score',
        'cost':'Contract purchase cost, excluding fees','fees':'Scenario cost estimate, not verified exchange fees','pnl':'Payout minus purchase cost and scenario fees',
        'equity':'Cash plus unsettled purchase cost; no intramatch mark to market','qualifies':'p > 0.51 and confidence > 0.55'}
    for path in sorted(RESULT.glob('*.parquet')):
        table=pd.read_parquet(path)
        for col in table:
            unit='UTC timestamp' if pd.api.types.is_datetime64_any_dtype(table[col]) else 'USD' if col in ('cost','fees','payout','pnl','cash','open_cost','equity','requested') else 'USD/share' if col in ('ask','bid') else 'probability' if col in ('p','p0','p1','p2','confidence') else 'count' if col=='quantity' else 'value or category'
            catalog.append(dict(table=path.stem,column=col,dtype=str(table[col].dtype),meaning=descriptions.get(col,col.replace('_',' ')),unit=unit,
                source='Research only; see protocol.json and price_acquisition.json',rows=len(table),missing=int(table[col].isna().sum())))
    pd.DataFrame(catalog).to_csv(RESULT/'catalog.csv',index=False)
    # Extend the research catalogs without modifying the underlying production SQL tables.
    catalog_root=PROJECT/'reports/nhl_soccer_iteration'
    for filename,cols in [('table_catalog.csv',['table','rows','columns']),('column_catalog.csv',['table','column','meaning','unit','source'])]:
        old=pd.read_csv(catalog_root/filename);old=old[~old.table.str.startswith(LABEL+'/')]
        if filename=='table_catalog.csv':
            extra=pd.DataFrame(catalog).groupby('table').agg(rows=('rows','first'),columns=('column','size')).reset_index()
        else:extra=pd.DataFrame(catalog)[cols].copy()
        extra['table']=LABEL+'/'+extra.table
        temporary=(catalog_root/filename).with_suffix('.tmp')
        pd.concat([old,extra],ignore_index=True).to_csv(temporary,index=False);temporary.replace(catalog_root/filename)
    dump(RESULT/'manifest.json',dict(status='PASS',at_utc=stamp(),code_sha256=file_sha256(SOURCE/'nations_strategy_review.py'),
        files={v.name:file_sha256(v) for v in RESULT.iterdir() if v.is_file()},
        adopted=False,models_retained=False,feature_matrices_retained=False))
    manifest=json.loads((RESULT/'manifest.json').read_bytes())
    assert all(file_sha256(RESULT/name)==digest for name,digest in manifest['files'].items())
    retention_path=ROOT_OUT/'retention/retained_artifacts.json';retained=json.loads(retention_path.read_bytes())
    retained['scripts']['nations_strategy_review.py']=file_sha256(SOURCE/'nations_strategy_review.py')
    retained['retained_scripts']=len(retained['scripts']);retained['updated_utc']=stamp()
    retained['latest_nations_strategy_review']=dict(status='PASS',result=str(RESULT.relative_to(ROOT_OUT)),adopted=False,
        manifest_sha256=file_sha256(RESULT/'manifest.json'),summary=annual.to_dict('records'))
    dump(retention_path,retained)
    from final_pipeline import discard_work
    discard_work(WORK)
    print(json.dumps(dict(stage='published',status='PASS',path=str(RESULT),raw_replays=replayed,temporary_work_removed=True)),flush=True)


def report(annual,primary,diagnostic):
    forecast=pd.read_csv(RESULT/'forecast_metrics.csv')
    coverage=pd.read_csv(RESULT/'player_form_coverage.csv');coverage=coverage[coverage.cutoff.str.startswith('2026-09')]
    linked=int(coverage.players_with_prior_club_form.sum());roster=int(coverage.roster_players.sum())
    notes=[
        'Completed retrospective study; Nations League has NOT been enabled in the live app. No actual orders were sent.',
        'Training pools the selected club soccer feature history with prior Nations League matches. The Nations competition indicator is added to the unchanged selected C=.02 logistic recipe. There was no parameter search or strategy selection using these results.',
        '409 official Nations matches (2021 through September 29, 2026); 241 chronological forecasts for 2024 onward. All fitting/calibration labels and feature source timestamps precede each forecast. Monthly earlier-only calibration uses the prior 180 days.',
        f'National team form uses national matches. Player form pools verified club/national histories, using prior national appearances for roster weights. {linked:,} of {roster:,} September roster-player occurrences have prior club form ({100*linked/roster:.1f}%). These are occurrences across matches, not unique people.',
        '2026 coverage: 56 forecasts, including four March matches and 52 September matches. Only the 52 September matches have matched Polymarket US price histories here. No US returns are claimed for 2024, 2025 or March 2026.',
        'Rules: buy the selected outcome YES if sports probability >51% and calibrated confidence >55%. Confidence comes from the frozen September club-trained model; it is not calibrated on national teams. There is no extra positive probability-minus-price gate in the current soccer strategy.',
        'Primary entry is the first qualifying five-minute decision from T-12 hours. Fixed T-1 hour is a predeclared comparison. Starting cash and allocation are $2,000; soccer target 35%, hard cap 45% ($900); base $5 per probability percentage point above 51%. Other sports are idle.',
        'Price-history longPrice is a YES display price, normally derived from the best ask. Bid is inferred as 1-shortPrice. The simulation assumes full fills at the observed display ask. Historical depth, queue, market-open status and actual fills are not established. It does not replay the app midpoint/ask split or cancel/replace execution. Minute history allows quotes up to 60 seconds old; the live book rule requires 30 seconds.',
        'Fee sensitivity uses coefficient 0.05 in the current conservative reserve formula, including rounding and a one-cent buffer. These are assumed costs, not reconstructed historical charged fees. Gross results exclude fees.',
        'Open positions are valued at purchase cost until the recorded official result availability. Cash release assumes settlement then; actual exchange payout delay is not reconstructed. Reported drawdown therefore is not intramatch mark-to-market drawdown.',
        'Calendar Sharpe is computed on January 1-September 29 daily returns with idle days included. Only three entry dates and seven primary bets contribute. The sample cannot establish stable performance or a reliable annualized return.',
        'Important missing inputs: national-team xG, club-strength coefficients and several action ratios are unavailable and use training-only imputation. National team-form history here consists of Nations League games, not all international friendlies/qualifiers. Neutral venues retain the existing designated-home convention. These are transfer-model limitations.',
        f"Gate diagnostic: {diagnostic['p_only_games']} of the 52 matched forecasts exceed 51% ({diagnostic['p_only_correct']} correct); {diagnostic['confidence_qualified_games']} pass both gates at some decision time. This diagnostic does not select a different strategy.",
        'Reproduce with the retained nations_strategy_review.py stages: prepare, fit, prices, simulate, publish. Existing publication must be reviewed before rerunning publish. Raw price response hashes, acquisition receipts, prediction/fold audits, full decision/ledger tables and source replay validation accompany this report.'
    ]
    display=annual[['strategy','cost_scenario','bets','wins','profit','return_pct','max_drawdown_pct','fees','max_open_cost']]
    bets=primary[['teamA','teamB','pick','at','p','confidence','ask','quantity','cost','correct','pnl']]
    (RESULT/'report.txt').write_text('UEFA Nations League strategy review\n\n'+display.to_string(index=False)+'\n\nForecast accuracy\n'+forecast.to_string(index=False)+'\n\n'+'\n\n'.join(notes)+'\n\nPrimary bets\n'+bets.to_string(index=False)+'\n',encoding='utf-8')
    content='<!doctype html><html lang="en"><meta charset="utf-8"><title>Nations League strategy review</title><style>body{max-width:1200px;margin:36px auto;padding:0 24px;font:16px/1.55 system-ui;color:#172238}table{border-collapse:collapse;font-size:13px;width:100%;margin:24px 0}td,th{padding:8px;border:1px solid #d4d9e1;text-align:right}th{background:#edf3fa}p{max-width:1050px}img{max-width:100%}</style><h1>UEFA Nations League strategy review</h1><p>Research only. Completed '+html.escape(stamp())+'</p>'+display.to_html(index=False,float_format=lambda x:f'{x:.4f}')+'<h2>Forecast diagnostics</h2>'+forecast.to_html(index=False,float_format=lambda x:f'{x:.4f}')+''.join('<p>'+html.escape(n)+'</p>' for n in notes)+'<h2>Primary bets</h2>'+bets.to_html(index=False,float_format=lambda x:f'{x:.4f}')+'<p><a href="primary_bets.csv">Trade CSV</a> | <a href="annual.csv">Scenario metrics</a> | <a href="final_validation.json">Validation</a> | <a href="catalog.csv">Data catalog</a></p></html>'
    (RESULT/'report.html').write_text(content,encoding='utf-8')


if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('stage',choices=['prepare','fit','prices','simulate','publish']);args=a.parse_args();globals()[args.stage]()
