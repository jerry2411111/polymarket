"""Reconcile omitted Ligue 1 counts against complete official participation.

Replay existing official responses only. Raw NULL stays NULL; inferred values
live in an independently verifiable proof table, never in the source cache.
"""
import argparse, collections, copy, hashlib, json, math
import pandas as pd
from common import ROOT_OUT, PREVIOUS, PROJECT, read_db, dump, stamp
from soccer_additional_facts import retained, LIGUE_FIELDS

RUN = ROOT_OUT/'ligue_counts_v37'
FIELDS = {'shots':'scoringAttempts', 'shots_on_target':'ontargetScoringAttempts',
          'passes':'passes', 'fouls_committed':'fouls'}


def records():
    with read_db(ROOT_OUT/'soccer_additional.sqlite') as c:
        rows = [json.loads(b) for b, in c.execute("SELECT body FROM games WHERE league='Ligue 1'")]
    return sorted(rows, key=lambda r:(r['date'], r['game_id']))


def participation(team):
    pool = team['players']; pool = list(pool.values()) if isinstance(pool,dict) else pool
    ids = {p['id'] for p in pool}
    starters = {p['id'] for p in pool if p.get('startedMatch') is True}
    played = {p['id'] for p in pool if p.get('playedMatch') is True}
    minutes = {p['id'] for p in pool if isinstance(p.get('minutesPlayed'), (int,float)) and p['minutesPlayed']>0}
    substitutions = team.get('substitutions')
    reasons = []
    if len(ids)!=len(pool): reasons.append('duplicate player IDs')
    if len(starters)!=11: reasons.append('not eleven explicit starters')
    if not isinstance(substitutions,list): reasons.append('substitution list absent'); substitutions=[]
    ons=[s.get('subOnId') for s in substitutions]; offs=[s.get('subOffId') for s in substitutions]
    expected=starters | set(ons)
    if len(set(ons))!=len(ons) or len(set(offs))!=len(offs): reasons.append('duplicate substitution actors')
    if set(ons)&starters or not set(offs)<=expected or not expected<=ids: reasons.append('invalid substitution actors')
    if played!=expected or not minutes<=expected: reasons.append('participants do not reconcile')
    # Reject explicit contradictions or absent participant flags, rather than
    # assuming an unreported substitute did not enter.
    if any(p.get('playedMatch') not in (True,False) or p.get('startedMatch') not in (True,False) for p in pool):
        reasons.append('missing participation flags')
    return [p for p in pool if p['id'] in expected], reasons


def count(v):
    return not isinstance(v,bool) and isinstance(v,(int,float)) and math.isfinite(v) and v>=0 and float(v).is_integer()


def main(pilot=False,run=None,aliases=None,selected_game_ids=None):
    output=RUN if run is None else run
    output.mkdir(exist_ok=True)
    rows=records()
    if selected_game_ids is not None:rows=[r for r in rows if r['game_id'] in selected_game_ids]
    elif pilot: rows=[rows[0],rows[len(rows)//2],rows[-1]]
    proofs=[];audits=[];issues=[];sources=[];mark=10
    for n,r in enumerate(rows,1):
        source=r['sources'][0];raw=retained(source)
        assert raw['id']==r['official_game_id'] and raw['period']=='fullTime'
        for side,native in [('A','away'),('B','home')]:
            team=raw[native];participation_team=team;used_aliases=[]
            if aliases:
                participation_team=copy.deepcopy(team)
                for sub in participation_team.get('substitutions',[]):
                    for role in ['subOnId','subOffId']:
                        key=(r['game_id'],side,sub.get(role))
                        if key in aliases:
                            replacement=aliases[key]
                            used_aliases.append(dict(original=sub[role],normalized=replacement,role=role))
                            sub[role]=replacement
            active,reasons=participation(participation_team)
            normalized={p['source_player_id']:p for p in r['players'] if p['side']==side}
            assert len(normalized)==len([p for p in r['players'] if p['side']==side])
            if reasons: issues.append(dict(game_id=r['game_id'],side=side,reasons=reasons))
            for field,team_field in FIELDS.items():
                original=LIGUE_FIELDS[field];total=(team.get('stats') or {}).get(team_field)
                known=[(p.get('stats') or {})[original] for p in active if (p.get('stats') or {}).get(original) is not None]
                missing=[p for p in active if (p.get('stats') or {}).get(original) is None]
                valid=count(total) and all(count(v) for v in known)
                summed=math.fsum(known) if valid else None
                supported=not reasons and valid and summed==total
                audits.append(dict(game_id=r['game_id'],date=r['date'],side=side,field=field,
                    participants=len(active),complete_participants=not reasons,known_players=len(known),
                    missing_players=len(missing),team_total=total,known_sum=summed,zero_inference_supported=supported))
                for p in active:
                    assert normalized[p['id']][field]==(p.get('stats') or {}).get(original)
                if not supported: continue
                for p in missing:
                    normalized_player=normalized[p['id']]
                    cell=dict(game_id=r['game_id'],official_game_id=r['official_game_id'],league='Ligue 1',
                        date=r['date'],side=side,official_player_id=normalized_player['official_player_id'],
                        source_player_id=p['id'],player_name=normalized_player['player_name'],
                        available_at_utc=normalized_player['available_at_utc'],field=field,raw_value=None,derived_value=0.,
                        team_total=total,known_sum=summed,participants=len(active),
                        team_pointer='/'+native+'/stats/'+team_field,
                        player_pointer='/'+native+'/players/'+p['id']+'/stats/'+original,
                        source_url=source['url'],source_raw_file=source['raw_file'],source_sha256=source['sha256'],
                        retrieved_at_utc=source.get('retrieved_at_utc'))
                    if aliases is not None:cell['participation_aliases_json']=json.dumps(used_aliases,sort_keys=True)
                    proofs.append(cell)
        sources.append(dict(game_id=r['game_id'],source=source))
        if n*100>=mark*len(rows) or n==len(rows):
            progress=dict(stage='ligue_count_reconciliation',processed=n,total=len(rows),percent=round(n*100/len(rows),1),proven_cells=len(proofs))
            print(json.dumps(progress),flush=True);mark+=10
    prefix='pilot_' if pilot else ''
    pd.DataFrame(proofs).to_parquet(output/(prefix+'zero_proofs.parquet'),index=False)
    pd.DataFrame(audits).to_parquet(output/(prefix+'count_reconciliation.parquet'),index=False)
    dump(output/(prefix+'participation_issues.json'),issues);dump(output/(prefix+'source_links.json'),sources)
    summary=dict(at_utc=stamp(),games=len(rows),proved_zero_cells=len(proofs),by_field=dict(collections.Counter(p['field'] for p in proofs)),
        participant_side_issues=len(issues),network_requests=0,raw_nulls_preserved=True,
        rule='Eleven explicit starters plus unique valid substitution actors exactly equal playedMatch participants; nonnegative integer player counts already equal official team total.')
    dump(output/(prefix+'count_summary.json'),summary);print(json.dumps(summary),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');a=parser.parse_args();main(a.pilot)
