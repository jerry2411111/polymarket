"""Test position-aware replacement rates without renormalizing absent players.

Official prior squad and game evidence only. Existing six feature columns,
learner and stake policy are fixed. Selection is on rolling 2024/25 forecasts.
"""
import argparse
import collections
import copy
import json
import numpy as np
import pandas as pd
from common import ROOT_OUT, PROJECT, REPORTS, read_db, dump, stamp, file_sha256
import soccer_squad_model as squad

LABEL = 'soccer_role_replacement'
WORK = ROOT_OUT/'_work'/LABEL
RESULT = ROOT_OUT/'simulation_results'/LABEL
REFERENCE = squad.REFERENCE
FIELDS = squad.FIELDS
PHYSICAL = squad.PHYSICAL
GROUPS = {'porteros':'GK', 'defensas':'D', 'centrocampistas':'M', 'delanteros':'F'}
ROLES = {'GK':'GK', 'G':'GK', 'GOALKEEPER':'GK', 'DEFENDER':'D', 'DEFENSE':'D',
         'MIDFIELDER':'M', 'MIDFIELD':'M', 'FORWARD':'F', 'ATTACK':'F'}


def observed_role(value):
    # Numeric source ordering and Starter/Substitute do not establish a role.
    return ROLES.get(str(value).upper())


def derive(g, p, keys, reports, names):
    alias_map, alias_records = squad.aliases()
    named = {rid:f.to_dict('records') for rid,f in names.groupby('report_id')}
    reports = reports.copy()
    reports['clock'] = pd.to_datetime(reports.available_after_utc, utc=True, format='mixed')
    eligible = reports[reports.available_by_pre12].sort_values(['clock','report_id']).drop_duplicates(['game_id','side'],keep='last')
    announcement = {(r.game_id,r.side):r for r in eligible.itertuples()}
    selected = set(eligible.game_id)
    clubs = {}
    for r in reports.itertuples():
        if (r.game_id,r.side) in keys:
            team = keys[r.game_id,r.side]
            assert r.uefa_club_id not in clubs or clubs[r.uefa_club_id] == team
            clubs[r.uefa_club_id] = team
    lookup = collections.defaultdict(list)
    columns = ['game_id','side','player_id','player_name','position','minutes','available_at_utc']+FIELDS
    for pl in p[columns].to_dict('records'):
        lookup[pl['game_id'],pl['side']].append(pl)
    hist = collections.defaultdict(lambda:collections.deque(maxlen=5))
    phist = collections.defaultdict(lambda:collections.deque(maxlen=30))
    team_ids = collections.defaultdict(set)
    last_team, roles = {}, {}
    numerator, denominator = collections.Counter(), collections.Counter()
    events = [(r.available_time,0,r.game_id,r) for r in g.itertuples()]
    events += [(r.clock,1,r.report_id,r) for r in reports.itertuples() if pd.notna(r.clock) and r.uefa_club_id in clubs]
    events.sort(key=lambda v:(v[0],v[1],v[2]))
    pos = 0
    out, audit, members, role_audit = [], [], [], []

    def identities(pid):
        return {z['player_name'] for z in phist[pid]} | set(alias_map.get(pid,[]))

    def match_names(team, roster):
        candidates = {pid:identities(pid) for pid in sorted(team_ids[team]) if last_team.get(pid)==team}
        matches = {pid:[] for pid in candidates}
        unique = set()
        for nm in roster:
            found = [pid for pid,nn in candidates.items() if any(squad.name_matches(nm['player_name_raw'],n) for n in nn)]
            for pid in found:
                matches[pid].append(nm['player_name_raw'])
            if len(found)==1:
                unique.add(found[0])
        return matches, unique

    for game in g.sort_values(['prediction_time','game_id']).itertuples():
        while pos<len(events) and (events[pos][0]<game.prediction_time or (events[pos][0]==game.prediction_time and events[pos][1]==1)):
            clock, kind, _, old = events[pos];pos+=1
            if kind==1:
                team=clubs[old.uefa_club_id]
                roster=named[old.report_id]
                candidates={pid:identities(pid) for pid in sorted(team_ids[team]) if last_team.get(pid)==team}
                for nm in roster:
                    role=GROUPS.get(nm['position_group'])
                    if not role:continue
                    found=[pid for pid,nn in candidates.items() if any(squad.name_matches(nm['player_name_raw'],n) for n in nn)]
                    if len(found)==1:
                        pid=found[0];roles[pid]=(role,clock,old.report_id)
                continue
            for side in ['A','B']:
                team=keys[old.game_id,side];observed=[]
                for pl in lookup[old.game_id,side]:
                    minutes=pl['minutes']
                    if minutes is None or not np.isfinite(minutes) or minutes<=0:continue
                    assert pd.Timestamp(pl['available_at_utc'])<=clock
                    pid=pl['player_id'];phist[pid].append(pl);last_team[pid]=team;team_ids[team].add(pid)
                    observed.append((pid,minutes))
                    role=observed_role(pl['position'])
                    if role:roles[pid]=(role,clock,old.game_id)
                    for field in PHYSICAL:
                        if pl[field] is not None and np.isfinite(pl[field]):
                            numerator[field]+=pl[field];denominator[field]+=minutes
                hist[team].append(observed)
        if game.game_id not in selected:continue
        values={};row={'game_id':game.game_id}
        for side in ['A','B']:
            team=keys[game.game_id,side];weights=collections.defaultdict(float)
            for old in hist[team]:
                for pid,minutes in old:
                    if last_team.get(pid)==team:weights[pid]+=minutes
            report=announcement.get((game.game_id,side));matched,unique=({},set())
            if report:
                matched,unique=match_names(team,named[report.report_id])
                assert report.clock<=game.prediction_time
            rates={};rate_clocks={}
            population=set(weights)|unique
            for pid in sorted(population):
                for field in FIELDS:
                    obs=[z for z in phist[pid] if z[field] is not None and np.isfinite(z[field])]
                    if obs:
                        rates[pid,field]=90*sum(z[field] for z in obs)/sum(z['minutes'] for z in obs)
                        rate_clocks[pid,field]=max(pd.Timestamp(z['available_at_utc']) for z in obs)
            capacities={pid:max(90*len(hist[team])-weights.get(pid,0),0.) for pid in unique}
            for pid,weight in sorted(weights.items()):
                if report:
                    role,role_clock,role_source=roles.get(pid,(None,None,None))
                    members.append(dict(game_id=game.game_id,side=side,player_id=pid,player_name=phist[pid][-1]['player_name'],
                        role=role,role_available_utc=role_clock,role_source=role_source,recent_minutes=weight,
                        in_announced_squad=bool(matched.get(pid)),report_id=report.report_id,
                        squad_available_utc=report.clock,cutoff_utc=game.prediction_time,
                        latest_stat_utc=max(pd.Timestamp(z['available_at_utc']) for z in phist[pid]),
                        matched_names_json=json.dumps(matched.get(pid,[]),ensure_ascii=False)))
            for field in FIELDS:
                base_rates={pid:rates[pid,field] for pid in weights if (pid,field) in rates}
                revised=base_rates.copy()
                for pid in sorted(base_rates):
                    if report is None or matched.get(pid):continue
                    role,role_clock,role_source=roles.get(pid,(None,None,None))
                    candidates=[q for q in sorted(unique) if role is not None and roles.get(q,(None,))[0]==role
                                and capacities[q]>0 and (q,field) in rates]
                    total_capacity=sum(capacities[q] for q in candidates)
                    status='replaced' if total_capacity else ('unknown_prior_role' if role is None else 'no_observed_same_role_reserve')
                    if total_capacity:
                        revised[pid]=sum(capacities[q]*rates[q,field] for q in candidates)/total_capacity
                    evidence=[dict(player_id=q,player_name=phist[q][-1]['player_name'],capacity=capacities[q],
                                   rate_per90=rates[q,field],stat_available_utc=rate_clocks[q,field].isoformat(),
                                   role=roles[q][0],role_available_utc=roles[q][1].isoformat(),role_source=roles[q][2]) for q in candidates]
                    assert not evidence or all(pd.Timestamp(z['stat_available_utc'])<game.prediction_time and pd.Timestamp(z['role_available_utc'])<=game.prediction_time for z in evidence)
                    role_audit.append(dict(game_id=game.game_id,side=side,field=field,player_id=pid,
                        player_name=phist[pid][-1]['player_name'],role=role,role_available_utc=role_clock,role_source=role_source,
                        recent_minutes=weights[pid],prior_rate_per90=base_rates[pid],replacement_rate_per90=revised[pid],
                        reserve_capacity=total_capacity,status=status,candidate_evidence_json=json.dumps(evidence,ensure_ascii=False),
                        report_id=report.report_id,report_available_utc=report.clock,cutoff_utc=game.prediction_time,
                        own_stat_available_utc=rate_clocks[pid,field]))
                for mode,rr in [('reference',base_rates),('candidate',revised)]:
                    total=sum(weights.values());covered=sum(weights[pid] for pid in rr)
                    prior=90*numerator[field]/denominator[field] if denominator[field] else np.nan
                    if field in PHYSICAL:
                        value=prior+sum(weights[pid]*(v-prior) for pid,v in rr.items())/total if total and np.isfinite(prior) else prior
                    else:
                        value=sum(weights[pid]*v for pid,v in rr.items())/covered if covered else np.nan
                    values[side,mode,field]=value
                    audit.append(dict(game_id=game.game_id,side=side,field=field,mode=mode,rate_per90=value,
                        roster_minutes=total,covered_minutes=covered,population_rate_per90=prior,
                        cutoff_utc=game.prediction_time,report_id=report.report_id if report else None))
        for mode in ['reference','candidate']:
            for field in FIELDS:row[mode+'_f_ctx_roster_'+field+'_rate_diff']=values['B',mode,field]-values['A',mode,field]
        out.append(row)
    return pd.DataFrame(out).set_index('game_id'),pd.DataFrame(audit),pd.DataFrame(members),pd.DataFrame(role_audit),alias_records


def build():
    import loss_case_revision as case
    from soccer_club_strength import coefficients
    RESULT.mkdir(exist_ok=True)
    assert not (RESULT/'validation.json').exists()
    recipe=copy.deepcopy(json.loads((REFERENCE/'experiment_plan.json').read_bytes())['recipe'])
    dump(RESULT/'experiment_plan.json',dict(at_utc=stamp(),recipe=recipe,
        hypothesis='Removing absent defenders and renormalizing remaining attackers can overstate squad quality. Preserve historical contribution weights; substitute available same-role prior reserve rates.',
        formula='Reserve rate weighted by max(90 * number of prior team games in last-five pool - that player recent minutes, 0). Replace only absent observed player field contributions; keep original total and observed-field denominators.',
        roles='Last earlier explicit text game role or uniquely named official squad role. Numeric ordering and Starter/Substitute are not roles. No later match lineups.',
        unknown='No earlier role or observed same-role reserve: keep reference contribution and document unresolved model input. No invented source values.',
        unchanged='Six existing rate columns only. Forty-one inputs, learner, regularization, preprocessing, prior population treatment, roster count, calendar training and price rule unchanged.',
        sources={t:file_sha256(ROOT_OUT/(t+'.parquet')) for t in ['soccer_squad_reports','soccer_squad_report_players']},
        gate='Lower rolling2024/25 multiclass logloss AND Brier on identical games; only then evaluate2026.',
        evaluation='2026 repeatedly inspected retrospective rolling evaluation, not pristine holdout.',app_changed=False))
    case.WORK=WORK;case.RESULT=RESULT
    if not (WORK/'sources_ready.json').exists():case.sources()
    if not (WORK/'features_ready.json').exists():case.build()
    g,_,p,_,keys,_=case.load_sources()
    reports=pd.read_parquet(ROOT_OUT/'soccer_squad_reports.parquet');names=pd.read_parquet(ROOT_OUT/'soccer_squad_report_players.parquet')
    proof=json.loads((ROOT_OUT/'simulation_results/soccer_squad_availability/validation.json').read_bytes())
    for t in proof['tables']:assert t['sha256']==file_sha256(ROOT_OUT/(t['table']+'.parquet'))
    frame=pd.read_parquet(WORK/'candidate/soccer_features.parquet').set_index('game_id')
    ranking=pd.read_parquet(ROOT_OUT/'soccer_uefa_club_coefficients.parquet')
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
        registry={(code,str(native)):json.loads(body) for code,native,body in db.execute('SELECT * FROM _eu_team_identity')}
    coef,_=coefficients(g,ranking,registry);frame=frame.join(coef,validate='one_to_one')
    derived,audit,members,replacements,alias_records=derive(g,p,keys,reports,names)
    columns=['f_ctx_roster_'+f+'_rate_diff' for f in FIELDS]
    for c in columns:assert np.allclose(derived['reference_'+c],frame.loc[derived.index,c],atol=1e-10,rtol=0,equal_nan=True),c
    changed=frame.copy()
    for c in columns:changed.loc[derived.index,c]=derived['candidate_'+c]
    assert changed.drop(columns=columns).equals(frame.drop(columns=columns))
    assert changed.loc[~changed.index.isin(derived.index)].equals(frame.loc[~frame.index.isin(derived.index)])
    cut=pd.Timestamp('2025-01-01',tz='UTC');early=g[g.prediction_time.lt(cut)]
    pg=g[g.available_time.lt(cut)|g.game_id.isin(early.game_id)]
    pr=reports[pd.to_datetime(reports.available_after_utc,utc=True,format='mixed').lt(cut)]
    prefix,_,_,_,_=derive(pg,p[p.game_id.isin(pg.game_id)],keys,pr,names[names.report_id.isin(pr.report_id)])
    common=prefix.index.intersection(derived.index);pd.testing.assert_frame_equal(prefix.loc[common],derived.loc[common],check_exact=True)
    assert members.latest_stat_utc.lt(members.cutoff_utc).all() and members.squad_available_utc.le(members.cutoff_utc).all()
    assert replacements.own_stat_available_utc.lt(replacements.cutoff_utc).all()
    assert replacements.role_available_utc.dropna().le(replacements.loc[replacements.role_available_utc.notna(),'cutoff_utc']).all()
    for name,f in [('squad',changed),('control',frame)]:
        folder=WORK/name;folder.mkdir(exist_ok=True);f.reset_index().to_parquet(folder/'soccer_features.parquet',index=False)
    for name,f in [('feature_changes',derived.reset_index()),('feature_evidence',audit),('player_membership',members),('replacement_evidence',replacements)]:
        f.to_parquet(RESULT/(name+'.parquet'),index=False)
    replacements.to_csv(RESULT/'replacement_evidence.csv',index=False)
    dump(RESULT/'feature_validation.json',dict(status='PASS',at_utc=stamp(),games=len(frame),squad_games=len(derived),
        changed_games=int((~np.isclose(derived[[c for c in derived if c.startswith('reference_')]],derived[[c for c in derived if c.startswith('candidate_')]],atol=1e-12,equal_nan=True)).any(axis=1).sum()),
        changed_columns=columns,prefix_replayed_games=len(common),source_rates_replayed=True,unchanged_other_features=True,
        input_sha256=file_sha256(WORK/'squad/soccer_features.parquet'),source_validation=proof,
        replacement_status=replacements.status.value_counts().to_dict(),documented_aliases=alias_records))
    print(json.dumps(dict(stage='features',games=len(frame),squads=len(derived),replacement_status=replacements.status.value_counts().to_dict())),flush=True)


def train():
    import models
    # Refit the identical control once to prove reconstructed source identity.
    recipe=json.loads((RESULT/'experiment_plan.json').read_bytes())['recipe']
    models.OUT=WORK/'control';models.CANDIDATES['role_control']=recipe
    control=models.run('soccer','development',['role_control']).set_index('game_id')
    old=pd.read_parquet(REFERENCE/'development_predictions.parquet');old=old[old.variant.eq('candidate')].set_index('game_id')
    assert set(control.index)==set(old.index)
    assert np.allclose(control.loc[old.index,['p0','p1','p2']],old[['p0','p1','p2']],atol=1e-12,rtol=0)
    dump(RESULT/'control_replay.json',dict(status='PASS',at_utc=stamp(),forecasts=len(old),maximum_probability_error=float(np.max(np.abs(control.loc[old.index,['p0','p1','p2']].to_numpy()-old[['p0','p1','p2']].to_numpy())))))
    # Reuse the established earlier-only gate, independent saved-fit replay,
    # chronological simulation and conditional 2026 evaluation without edits.
    squad.WORK=WORK;squad.RESULT=RESULT;squad.REFERENCE=REFERENCE
    squad.train()


def finish():
    from final_pipeline import discard_work,cleanup,validate
    for name in ['validation','cash_validation','feature_validation','control_replay']:
        assert json.loads((RESULT/(name+'.json')).read_bytes())['status']=='PASS'
    decision=json.loads((RESULT/'selection.json').read_bytes());feature=json.loads((RESULT/'feature_validation.json').read_bytes())
    p=pd.read_parquet(RESULT/'development_predictions.parquet');r=pd.read_parquet(RESULT/'replacement_evidence.parquet')
    evidence=pd.read_parquet(RESULT/'feature_evidence.parquet')
    idx=['game_id','side','field']
    base=evidence[evidence['mode'].eq('reference')].set_index(idx)
    new=evidence[evidence['mode'].eq('candidate')].set_index(idx)
    assert base[['roster_minutes','covered_minutes']].equals(new[['roster_minutes','covered_minutes']])
    contribution=r.assign(change=r.recent_minutes*(r.replacement_rate_per90-r.prior_rate_per90)).groupby(idx).change.sum()
    denom=pd.Series(np.where(base.index.get_level_values('field').isin(PHYSICAL),base.roster_minutes,base.covered_minutes),index=base.index)
    delta=(contribution.reindex(base.index).fillna(0)/denom).where(denom.gt(0),0)
    actual=new.rate_per90-base.rate_per90
    assert np.allclose(actual.fillna(0),delta,atol=1e-10,rtol=0)
    dump(RESULT/'contribution_replay.json',dict(status='PASS',at_utc=stamp(),team_field_rows=len(base),
        all_denominators_unchanged=True,all_feature_deltas_reproduced=True,maximum_error=float((actual.fillna(0)-delta).abs().max())))
    cases=p[p.game_id.isin(r.game_id)].copy()
    case_scores=[]
    for variant,f in cases.groupby('variant'):
        prob=f[['p0','p1','p2']].to_numpy();y=f.target.to_numpy(int)
        case_scores.append(dict(variant=variant,games=len(f),accuracy=float(np.mean(prob.argmax(axis=1)==y)),log_loss=float(-np.log(prob[np.arange(len(y)),y]).mean())))
    example=p[p.game_id.eq('UCL_20250129_LIV_PSV')][['variant','p0','p1','p2','target']]
    dump(RESULT/'loss_followup.json',dict(at_utc=stamp(),affected_earlier_scores=case_scores,liverpool_case=example.to_dict('records'),adopted=False))
    a=pd.read_csv(RESULT/'annual.csv')
    def table(f):
        def fmt(v):return f'{v:.6f}' if isinstance(v,(float,np.floating)) else str(v)
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(map(fmt,row))+' |' for row in f.itertuples(index=False,name=None)])
    scores=pd.DataFrame([dict(model=k,**v) for k,v in decision['scores'].items()])
    body=['# Soccer position-aware replacement test','',
        'An absent player is replaced within the earlier contribution weights rather than removed from the denominator. The same-role replacement rate uses available named players with earlier observed statistics, weighted by unused recent playing-time capacity. This is a modelling estimate, not an observed lineup or raw statistic. Unknown roles or unobserved replacements preserve the reference contribution and remain documented.','',
        'Official dated game roles and uniquely matched earlier squad roles are used. Numeric lineup ordering and Starter/Substitute labels are ignored. Every source clock precedes its prediction. The old 41-input probability model, monthly expanding history from 2021, purged calibration and stake rule are unchanged. Predictions start in 2024.','',
        f"Feature checks: {feature['games']} game rows; {feature['squad_games']} games with eligible announcements; {feature['changed_games']} changed; {feature['prefix_replayed_games']} earlier rows exactly reproduced after future sources were removed. Replacement field statuses: {feature['replacement_status']}. The reference independently reproduces all3,961 earlier forecasts. Coverage remains only the two collected club archives, not an all-club availability model.",'',
        '## Earlier-date selection','',table(scores),'',
        f"Earlier gate passed: {decision['passed']}. The gate requires lower multiclass logloss and Brier, not improved historical profit. Paired monthly-block diagnostics: {json.dumps(decision['paired'])}. These descriptive intervals do not correct for repeated experiments.",'',
        '## Diagnosed Liverpool at PSV example','',table(example),'',
        'This known loss motivated a representation correction, not an outcome-specific exclusion or a fitted absence penalty. All eligible announcements receive the same treatment. The candidate raises Liverpool probability in this example. Broad roles still combine attacking and defensive midfielders. Also, the same reserve-rate estimate is used for multiple absent players without a joint capacity allocation; it is not a feasible projected lineup. The next source audit additionally found sparse positive-only count coverage in some prior appearances. The independently proved zero-count integration is recorded in soccer_source_count_rates.md. This role candidate is rejected, not adopted as a corrected lineup model.','',
        table(pd.DataFrame(case_scores)),'','## Cash results','',
        'Each year begins with $2,000. The unchanged rule stakes $5 per positive probability-minus-price percentage point on one selected outcome; cash is reused only after official settlement. Pre12 uses the closest earlier observation, at most24hours old. Providers remain separate, no assumed fees. Sharpe uses daily calendar returns including idle days and sqrt(365.25) annualization. Polymarket is historical international token price, not proven executable US asks; Kalshi retains its recorded ask basis.','',
        table(a[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        '2026 may be evaluated only after the earlier probability gate passes. It remains repeatedly examined retrospective rolling research, not a pristine holdout. No candidate is automatically adopted.','',
        'Reproduce: soccer_role_replacement.py build, train, finish. Dated source collectors, original responses, source hashes, feature/replacement evidence, forecasts and simulations remain; temporary matrices and fits are removed after validation. The NBA/MLB app is unchanged.']
    REPORTS.mkdir(exist_ok=True);(REPORTS/(LABEL+'.md')).write_text('\n'.join(body)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL]=decision;dump(path,old)
    if WORK.exists():discard_work(WORK)
    cleanup();validate()
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),dict(status='PASS',at_utc=stamp(),selection=decision,app_changed=False,adopted=False,temporary_work_removed=True))
    print(a[['provider','variant','year','funded_games','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['build','train','finish']);args=parser.parse_args();globals()[args.stage]()
