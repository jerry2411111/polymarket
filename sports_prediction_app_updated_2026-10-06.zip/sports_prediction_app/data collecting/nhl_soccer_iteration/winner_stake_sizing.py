"""Current research policy: buy the model argmax; vary only stake size.

Prices determine shares and payouts, never the purchased outcome. Preserved
price-selected simulations are historical references, not the active rule.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, REPORTS, dump, stamp, file_sha256
from backtest import quote_inputs
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine

LABEL = 'winner_stake_sizing'
RESULT = ROOT_OUT / 'simulation_results' / LABEL
RULES = [
    ('flat20', 'all_selected_outcomes', 'flat20_cash_only', 20.),
    ('confidence20', 'winner_above51', 'dollars_cash_only', 20.),
    ('confidence5', 'winner_above51', 'dollars_cash_only', 5.),
]


def simulate_predictions(development, evaluation, result):
    """Reusable by subsequent model comparisons: no opposite-outcome branch."""
    result.mkdir(exist_ok=True)
    quote_path = result / 'winner_quote_quality.json'
    quotes = quote_inputs(quote_path, revision='closest_v62')
    transfer.RESULT = result
    forecasts = pd.concat([development, evaluation], ignore_index=True) if evaluation is not None else development.copy()
    rows, positions, days, checks, coverage, selection = [], [], [], [], [], []
    for (sport, variant), p in forecasts.groupby(['sport', 'variant']):
        assert p.game_id.is_unique
        assert p.train_label_max.lt(p.prediction_time).all()
        assert p.calibration_label_max.lt(p.prediction_time).all()
        pcols = ['p0','p1'] + (['p2'] if sport == 'soccer' else [])
        f = transfer.normalize(sport, p, quotes, pick_growth=False)
        assert f.side.eq(f[pcols].to_numpy().argmax(axis=1)).all()
        for provider, g in f.groupby('provider'):
            prior_summaries = []
            # Rules are fixed before running. Report every rule, and separately
            # record the 2025 choice before looking at its 2026 results.
            for year in sorted(p.prediction_time.dt.year.unique()):
                history = p[p.prediction_time.dt.year.eq(year)]
                quoted = g[g.year.eq(year)]
                coverage.append(dict(sport=sport, variant=variant, provider=provider, year=int(year),
                    forecast_games=len(history), quoted_winner_games=len(quoted),
                    missing_winner_quote_games=len(history)-len(quoted),
                    confidence_at_or_below51_games=int(quoted.probability.le(.51).sum()),
                    quoted_winner_accuracy_pct=100*quoted.won.mean()))
                for label, entry, sizing, amount in RULES:
                    m,b,l,d = engine.simulate(g, int(year), entry, sizing, amount, 2000.)
                    meta = dict(sport=sport, provider=provider, variant=variant, stake_rule=label, year=int(year))
                    row=meta|m;rows.append(row)
                    checks.append(meta|engine.validate(b,l,d,sizing,amount,2000.))
                    if len(b):
                        assert b.side.eq(b[pcols].to_numpy().argmax(axis=1)).all()
                        assert b.won.eq(b.side.eq(b.target)).all()
                        positions.append(b.assign(**meta))
                    days.append(d.assign(**meta))
                    if year==2025:prior_summaries.append(row)
                if year==2025:
                    valid=[r for r in prior_summaries if r['return_pct']>0 and pd.notna(r['sharpe'])]
                    choice=max(valid,key=lambda r:r['sharpe'])['stake_rule'] if valid else None
                    selection.append(dict(sport=sport,provider=provider,variant=variant,selected_on_year=2025,
                        stake_rule=choice,reason='Highest 2025 Sharpe among the three fixed rules with positive return' if choice else 'No positive-return 2025 rule; no claimed qualified strategy',
                        used2026=False,adopted=False))
                    dump(result/'winner_development_selection.json',dict(at_utc=stamp(),choices=selection))
            print(json.dumps(dict(stage='winner_staking',sport=sport,variant=variant,provider=provider)),flush=True)
    a=pd.DataFrame(rows);b=pd.concat(positions,ignore_index=True)
    a.to_csv(result/'winner_annual.csv',index=False)
    b.to_parquet(result/'winner_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(result/'winner_daily.parquet',index=False)
    pd.DataFrame(coverage).to_csv(result/'winner_coverage.csv',index=False)
    # Fixed confidence bands diagnose sizing without fitting a cutoff to losses.
    base=b[b.stake_rule.eq('flat20')].copy()
    base['confidence_band']=pd.cut(base.probability,[0,.5,.55,.6,.65,.7,.8,1.],include_lowest=True)
    diagnostic=base.groupby(['sport','provider','variant','year','confidence_band'],observed=True).agg(
        games=('game_id','size'),wins=('won','sum'),mean_probability=('probability','mean'),
        mean_price=('price','mean'),profit=('profit','sum'),mean_unit_return=('unit_return','mean')).reset_index()
    diagnostic['win_rate']=diagnostic.wins/diagnostic.games
    diagnostic.to_csv(result/'winner_confidence_diagnosis.csv',index=False)
    proof=dict(status='PASS',at_utc=stamp(),checks=checks,no_opposite_outcome_purchases=True,
        no_price_filter_or_price_based_side_selection=True,no_model_refit=True,
        winner_quote_missing_does_not_substitute_another_side=True,app_changed=False)
    dump(result/'winner_validation.json',proof)
    return a,proof


def main():
    RESULT.mkdir(exist_ok=True)
    assert not (RESULT/'winner_validation.json').exists(),'Preserve the completed comparison'
    policy=dict(at_utc=stamp(),authority='User: if the model predicts someone to win, bet on the winner and size the stake.',
        side='argmax of all calibrated class probabilities before looking at quotes; soccer includes draw only if the model predicts draw.',
        price_usage='Convert stake to shares and calculate payout; price cannot change the chosen outcome.',
        missing_quote='No bet when the predicted outcome has no usable quote; never substitute another outcome.',
        staking=dict(initial_cash=2000,user_baseline='20*max(100*p-51,0) dollars, fixed to starting account; p=0.58 means140dollars',
            comparisons=['flat20 dollars','5*max(100*p-51,0), the amount already selected in earlier NBA2025 research'],
            zero='Confidence rules stake zero at or below51%; flat20 control includes every quoted argmax.',
            funding='Cash only. Concurrent orders share available cash proportionally; no borrowing or unsettled-payout reuse.'),
        training='Unchanged monthly expanding 2021+ histories; forecasts from2024; earlier-only preprocessing and calibration.',
        development='Three previously specified stake rules, no new amount grid. Record2025choice before2026; show all outcomes.',
        evaluation='2026 repeatedly inspected retrospective rolling evidence, not a pristine holdout.',
        prices='Pre12 closest prior observation no older than24hours. Polymarket international historical token prices and Kalshi YES ask closes separately.',
        app_changed=False,older_value_selection='Preserved as reference only, superseded for further goal research.')
    dump(RESULT/'plan.json',policy)
    dump(ROOT_OUT/'research_betting_policy.json',policy)
    parts={stage:[] for stage in ['development','evaluation']};hashes={}
    for sport,folder in [('nhl','feature_revisions/nhl_player_strength'),('soccer','soccer_source_count_rates')]:
        for stage in parts:
            path=ROOT_OUT/'simulation_results'/folder/(stage+'_predictions.parquet')
            hashes[str(path.relative_to(ROOT_OUT))]=file_sha256(path)
            f=pd.read_parquet(path);parts[stage].append(f[f.variant.eq('candidate')])
    a,proof=simulate_predictions(pd.concat(parts['development'],ignore_index=True),pd.concat(parts['evaluation'],ignore_index=True),RESULT)
    for name,sha in hashes.items():assert file_sha256(ROOT_OUT/name)==sha
    proof['source_hashes']=hashes;dump(RESULT/'winner_validation.json',proof)
    def table(f):
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+[
            '| '+' | '.join(f'{v:.4f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in f.itertuples(index=False,name=None)])
    report=['# Predicted-winner stake sizing','',
        'Every purchase follows the highest model probability across all actual outcomes. Prices never choose the side, and missing winner quotes never cause a switch. Fixed-dollar confidence sizing uses the starting$2000account:58%means$140under the user$20rule or$35under the earlier$5comparison. Zero at or below51%; flat$20 buys every quoted winner. No model refit, fees or spread assumptions.','',
        table(a[['sport','provider','stake_rule','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        '2025stake choice is recorded before2026, with no qualified rule where all2025returns are negative.2026is repeatedly inspected retrospective evidence. Calendar-day Sharpe uses sqrt365.25 and includes idle days; settlements release cash only at recorded availability. International Polymarket token prices do not establish executableUSasks; Kalshi retainsYESaskclose. Original price-selected studies remain archived references. NBA/MLBapp unchanged.','',
        'Per-game bets, confidence-band attribution, missing-quote and zero-stake counts, daily accounts and independent cash validation are retained. Reproduce winner_stake_sizing.py.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(report)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/winner_annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL]=dict(plan=policy,decision=proof);dump(path,d)
    from final_pipeline import cleanup
    cleanup()
    path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(path.read_bytes());m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']));dump(path,m)
    path=ROOT_OUT/'research_continuation.json';d=json.loads(path.read_bytes());d['betting_policy']='research_betting_policy.json';d['latest_winner_staking']=dict(at_utc=stamp(),result=str(RESULT),validation='PASS',price_based_side_selection_superseded=True);dump(path,d)
    print(a[a.year.eq(2026)][['sport','provider','stake_rule','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


if __name__=='__main__':main()
