"""Past-only probability calibration of saved rolling NHL forecasts.

No new tree, team exclusion, price threshold search or 2026 selection.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit

from common import ROOT_OUT, REPORTS, dump, stamp, file_sha256
from nhl_lineup_nonlinear import probability_metrics

LABEL='nhl_rolling_calibration'
RESULT=ROOT_OUT/'simulation_results'/LABEL
SOURCE=ROOT_OUT/'simulation_results/nhl_lineup_model/development_predictions.parquet'


def transform(p,theta):
    p=np.clip(np.asarray(p,float),1e-8,1-1e-8)
    return expit(theta[0]*np.log(p)-theta[1]*np.log1p(-p)+theta[2])


def fit(p,y):
    p=np.clip(np.asarray(p,float),1e-8,1-1e-8);y=np.asarray(y,float)
    x=np.column_stack([np.log(p),-np.log1p(-p),np.ones(len(p))])
    identity=np.array([1.,1.,0.])
    def loss(theta):
        z=x@theta;delta=theta-identity
        return float(np.mean(np.logaddexp(0,z)-y*z)+.01*np.dot(delta,delta)),x.T@(expit(z)-y)/len(y)+.02*delta
    result=minimize(loss,identity,jac=True,method='L-BFGS-B',bounds=[(0,None),(0,None),(None,None)])
    assert result.success,result.message
    return result.x


def rolling(base):
    frames=[];audit=[]
    for fold,test in base.groupby(base.prediction_time.dt.strftime('%Y-%m')):
        cutoff=pd.Timestamp(fold+'-01',tz='UTC')
        past=base[base.available_time.lt(cutoff)].copy()
        theta=fit(past.p1,past.target) if len(past)>=500 else np.array([1.,1.,0.])
        out=test.copy();out['p1']=transform(test.p1,theta);out['p0']=1-out.p1;out['variant']='beta_calibrated'
        out['post_calibration_rows']=len(past)
        out['post_calibration_cutoff']=cutoff
        out['post_calibration_label_max']=past.available_time.max()
        assert out.prediction_time.ge(cutoff).all()
        if len(past):assert past.available_time.max()<out.prediction_time.min()
        frames.append(out)
        audit.append(dict(fold=fold,fit_cutoff=cutoff,earlier_forecasts=len(past),label_max=past.available_time.max(),
            a=float(theta[0]),b=float(theta[1]),c=float(theta[2]),identity_warmup=len(past)<500))
    return pd.concat(frames,ignore_index=True),pd.DataFrame(audit)


def main():
    RESULT.mkdir(parents=True,exist_ok=True)
    plan=dict(at_utc=stamp(),hypothesis='Weak winner-confidence bands and provider-dependent losing bets suggest probability quality needs attention; test an expanding, low-parameter monotone calibration, without deleting those bands.',
      reference='Saved same-clock regulation/OT control, with unchanged independent strong-logistic confirmation. Base predictions refit monthly from2021.',
      source_sha256=file_sha256(SOURCE),paper='https://proceedings.mlr.press/v54/kull17a.html',
      formula='q=expit(a*log(p)-b*log(1-p)+c), a>=0,b>=0; fixed0.01 squared penalty toward(1,1,0), an internal identity-shrinkage extension of beta calibration.',
      fitting='Fit on all stored earlier out-of-fit forecasts whose official results were available before the monthly cutoff. Forecast archive starts2024; use identity until500earlier records. This post-calibrator is not claimed to have2021forecast history.',
      gate='Improve2025pooled logloss AND Brier, with overall winner accuracy>=52%.2024is warmup/diagnostic. No2026access before gate.',
      betting='Same paired post-information quotes; p/price>=1.10 for primary and unchanged secondary, original one-side selection,flat20cash-only annual2000, separate providers. No tuning stake/hour/confidence.',
      evaluation='Previously inspected2026is retrospective, not a pristine holdout.',app_changed=False)
    path=RESULT/'experiment_plan.json'
    if path.exists():assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(path,plan)
    base=pd.read_parquet(SOURCE);base=base[base.variant.eq('control')].sort_values(['prediction_time','game_id']).reset_index(drop=True)
    assert base.prediction_time.dt.year.max()==2025
    assert base.train_label_max.lt(base.prediction_time).all()
    assert base.calibration_label_max.lt(base.prediction_time).all()
    candidate,calibration=rolling(base)
    early=base[base.prediction_time.lt(pd.Timestamp('2025-01-01',tz='UTC'))]
    prefix,_=rolling(early)
    pd.testing.assert_frame_equal(prefix.set_index('game_id'),candidate.set_index('game_id').loc[prefix.game_id],check_exact=True)
    grid=np.linspace(.001,.999,1000)
    assert np.allclose(transform(grid,[1,1,0]),grid,atol=1e-15,rtol=0)
    for row in calibration.itertuples():assert np.diff(transform(grid,[row.a,row.b,row.c])).min()>=0
    candidate.to_parquet(RESULT/'candidate_predictions.parquet',index=False)
    calibration.to_csv(RESULT/'calibration_audit.csv',index=False)
    joined=pd.concat([base,candidate],ignore_index=True)
    scores=probability_metrics(joined);scores.to_csv(RESULT/'development_metrics.csv',index=False)
    a=scores[(scores.variant=='beta_calibrated')&(scores.year=='2025')&(scores.subset=='all')].iloc[0]
    b=scores[(scores.variant=='control')&(scores.year=='2025')&(scores.subset=='all')].iloc[0]
    passed=bool(a.logloss<b.logloss and a.brier<b.brier and a.accuracy>=.52)
    dump(RESULT/'selection.json',dict(at_utc=stamp(),passed=passed,adopted=False,new2026evaluation=False))
    import nhl_lineup_model as cash
    old=cash.RESULT
    try:cash.RESULT=RESULT;annual=cash.account_test(joined)
    finally:cash.RESULT=old
    validation=dict(status='PASS',at_utc=stamp(),base_forecasts=len(base),prefix_invariant_forecasts=len(prefix),
        month_fits=int((~calibration.identity_warmup).sum()),identity_and_monotonicity_checks=True,
        future_labels_excluded=True,source_sha256=file_sha256(SOURCE),gate_passed=passed,app_changed=False)
    dump(RESULT/'validation.json',validation)
    report=REPORTS/(LABEL+'.md')
    lines=['# NHL rolling probability calibration','',
      'A fixed monotone beta map is fitted to earlier out-of-fit forecasts. The base regulation/OT model and independent logistic confirmation remain. It tests probability calibration rather than excluding a losing confidence band or choosing a different market hour.','',
      'Method: q=expit(a log(p)-b log(1-p)+c), a,b>=0; fixed0.01 squared regularization toward identity(1,1,0). Calibration uses all earlier settled forecast records; identity is used until500records exist. Base models train from2021, but this saved forecast archive begins2024. Rolling2025is the development comparison.','',
      'The beta-map family and its identity property follow [Kull et al.,2017](https://proceedings.mlr.press/v54/kull17a.html). The regularization, warmup and chronological design here are our research choices, not results asserted by that paper.','',
      '|Variant|Year|Games|Accuracy|Log loss|Brier|','|---|---|---:|---:|---:|---:|']
    for r in scores[scores.subset.eq('all')].itertuples():lines.append(f'|{r.variant}|{r.year}|{r.n}|{100*r.accuracy:.2f}%|{r.logloss:.6f}|{r.brier:.6f}|')
    lines+=['',f'Probability gate passed: {passed}. No2026evaluation or model adoption has occurred. All prior label clocks and1533prefix forecasts are replayed; the mapping is monotone and identity is numerically verified.','',
      'Accounts: same paired later-entry quotes, both model probabilities/price>=1.10,flat$20fromannual$2,000cash, hold to settlement, no added costs.2024pricecoverage is partial. These are not the full pre12baseline. Historical reference prices do not establish executable fills. Daily-return Sharpe uses sqrt365.25.','',
      '|Provider|Year|Variant|Bets|Win rate|Return|Sharpe|Drawdown|','|---|---:|---|---:|---:|---:|---:|---:|']
    for r in annual.itertuples():
        f=lambda v:'n/a' if pd.isna(v) else f'{v:.2f}'
        lines.append(f'|{r.provider}|{r.year}|{r.variant}|{r.funded_games}|{f(r.win_rate_pct)}%|{f(r.return_pct)}%|{f(r.sharpe)}|{f(r.max_drawdown_pct)}%|')
    lines+=['','The goal remains active and unmet. No confidence interval for a single losing case proves its cause. Published probabilities, dated sources, aggregate calibration and cash ledgers remain available for review. Reproduce: nhl_rolling_calibration.py.']
    report.write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);old=old[~old.source_result_file.str.startswith(LABEL+'/',na=False)]
    pd.concat([old]+[pd.read_csv(RESULT/f).assign(source_result_file=LABEL+'/'+f,sport='nhl') for f in ['development_metrics.csv','development_annual.csv']],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL]=dict(plan=plan,validation=validation);dump(path,d)
    print(json.dumps(dict(**validation,report=str(report))),flush=True)
    print(scores[scores.subset.eq('all')].to_string(index=False),flush=True)


if __name__=='__main__':main()
