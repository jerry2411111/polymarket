"""Test shallow interactions on the verified count-corrected soccer inputs.

The linear forecast attribution is explanatory, not a causal importance claim.
No losing fixture, competition or calendar period is excluded from selection.
"""
import argparse
import json
import pickle
import shutil
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, REPORTS, dump, stamp, file_sha256

LABEL = 'soccer_corrected_nonlinear'
WORK = ROOT_OUT / '_work' / LABEL
RESULT = ROOT_OUT / 'simulation_results' / LABEL
REFERENCE = ROOT_OUT / 'simulation_results/soccer_source_count_rates'
NAME = 'corrected_context_catboost_d2'


def build():
    import models
    RESULT.mkdir(parents=True, exist_ok=True)
    WORK.mkdir(parents=True, exist_ok=True)
    previous = json.loads((REFERENCE / 'feature_validation.json').read_bytes())
    reusable = ROOT_OUT / '_work/soccer_qualification/squad/soccer_features.parquet'
    destination = WORK / 'squad/soccer_features.parquet'
    destination.parent.mkdir(exist_ok=True)
    if reusable.exists():
        assert file_sha256(reusable) == previous['candidate_hash']
        shutil.copy2(reusable, destination)
    else:
        import soccer_source_count_rates as source
        source.WORK = WORK
        source.RESULT = RESULT / 'source_replay'
        source.RESULT.mkdir(exist_ok=True)
        source.build()
    assert file_sha256(destination) == previous['candidate_hash']
    recipe = dict(kind='catboost', features='context8', depth=2, iterations=300)
    dump(RESULT / 'experiment_plan.json', dict(at_utc=stamp(), recipe=recipe,
        diagnosis='December2025 linear-model losses show long-run Elo/UEFA strength can outweigh conflicting recent match statistics. Check interactions with identical corrected source inputs, not a losing-game exclusion.',
        implementation='Existing fixed shallow CatBoost recipe: depth2,300iterations,learning_rate0.035,l2_leaf_reg15,seed42. Native missing handling; no scale required by tree splits. No hyperparameter search.',
        inputs='Same41count-corrected features, no qualification flags and no market inputs.',
        temporal='Expanding monthly training from2021, predictions2024onward. Trailing180day purged calibration. Later labels never enter an earlier fit.',
        gate='Pooled2024/25logloss AND Brier must improve over corrected logistic, and2025logloss must improve. Model selection does not use betting returns.',
        accounts='Unchanged$5per positive probability-price percentage point; pre12latest prior quote <=24h old; one existing expected-log-growth outcome; cash-only annual$2000; no added costs.',
        evaluation='Repeatedly inspected2026is retrospective rolling research, not untouched holdout.', app_changed=False))
    models.CANDIDATES[NAME] = recipe
    frame = pd.read_parquet(destination)
    matrix = pd.concat([frame, pd.get_dummies(frame.league, prefix='league', dtype=float)], axis=1)
    columns = models.columns(matrix, recipe)
    assert len(columns) == 41
    assert not any(t in c.lower() for c in columns for t in ['price', 'odds', 'market'])
    dump(RESULT / 'feature_validation.json', dict(status='PASS', at_utc=stamp(), rows=len(frame),
        feature_sha256=file_sha256(destination), input_columns=columns, exact_corrected_source_replay=True))
    explain_linear()


def explain_linear():
    import models
    from scipy.special import softmax
    reusable = ROOT_OUT / '_work/soccer_qualification/squad/model_runs/soccer/development/qualified_count_control.pkl'
    if reusable.exists():
        package = pickle.loads(reusable.read_bytes())
    else:
        spec = json.loads((REFERENCE / 'experiment_plan.json').read_bytes())['recipe']
        models.OUT = WORK / 'squad'
        models.CANDIDATES['corrected_control_replay'] = spec
        models.run('soccer', 'development', ['corrected_control_replay'])
        package = pickle.loads((WORK / 'squad/model_runs/soccer/development/corrected_control_replay.pkl').read_bytes())
    frame = pd.read_parquet(WORK / 'squad/soccer_features.parquet')
    matrix = pd.concat([frame, pd.get_dummies(frame.league, prefix='league', dtype=float)], axis=1).set_index('game_id')
    prior = pd.read_parquet(REFERENCE / 'development_predictions.parquet')
    prior = prior[prior.variant.eq('candidate') & prior.fold.eq(package['boundary'].strftime('%Y-%m'))].set_index('game_id')
    x = matrix.loc[prior.index, package['columns']].replace([np.inf, -np.inf], np.nan).astype(float)
    pipeline = package['model']; transformed = pipeline[:-1].transform(x)
    classifier = pipeline[-1]; names = list(pipeline[-2].feature_names_in_)
    logits = transformed @ classifier.coef_.T + classifier.intercept_
    assert np.allclose(softmax(logits, axis=1), pipeline.predict_proba(x), rtol=0, atol=1e-12)
    calibrated = models.apply_calibration(softmax(logits, axis=1), package['calibrator'])
    assert np.allclose(calibrated, prior[['p0', 'p1', 'p2']], rtol=0, atol=1e-12)
    influence = np.abs(transformed[:, :, None] * classifier.coef_.T[None, :, :]).mean((0, 2))
    pd.DataFrame(dict(feature=names, mean_absolute_logit_contribution=influence)).sort_values(
        'mean_absolute_logit_contribution', ascending=False).to_csv(RESULT / 'linear_fold_influence.csv', index=False)
    losses = pd.read_csv(REFERENCE / 'largest_earlier_losses.csv')
    cases = losses[losses.game_id.isin(prior.index)].drop_duplicates('game_id')
    rows = []
    for case in cases.itertuples():
        gid = case.game_id; i = prior.index.get_loc(gid)
        chosen, actual = int(case.side), int(prior.loc[gid, 'target'])
        assert chosen != actual
        coefficient = classifier.coef_[chosen] - classifier.coef_[actual]
        contrast = transformed[i] * coefficient
        intercept = float(classifier.intercept_[chosen] - classifier.intercept_[actual])
        expected = float(np.log(pipeline.predict_proba(x.iloc[[i]])[0, chosen] /
                                pipeline.predict_proba(x.iloc[[i]])[0, actual]))
        assert np.isclose(contrast.sum() + intercept, expected, rtol=0, atol=1e-12)
        for k, name in enumerate(names):
            rows.append(dict(game_id=gid, chosen_side=chosen, actual_side=actual, feature=name,
                raw_value=float(x.loc[gid, name]) if name in x else None,
                transformed_value=float(transformed[i, k]), contrast_coefficient=float(coefficient[k]),
                chosen_vs_actual_logit=float(contrast[k]), contrast_intercept=intercept,
                chosen_probability=float(prior.loc[gid, ['p0', 'p1', 'p2']].iloc[chosen]),
                fit_boundary=package['boundary']))
    pd.DataFrame(rows).to_csv(RESULT / 'linear_loss_contributions.csv', index=False)
    dump(RESULT / 'linear_diagnosis_validation.json', dict(status='PASS', at_utc=stamp(),
        forecast_replays=len(prior), cases=len(cases), exact_logits_reconstructed=True,
        fold=str(package['boundary']), limitation='One held-forward December2025fold. Descriptive coefficient contributions, not causal importance or proof that any individual loss was preventable. Targets used only for retrospective explanations.'))


def train():
    import models
    import soccer_club_history_model as paired
    import soccer_tie_context as simulation
    from sklearn.metrics import log_loss
    assert not (RESULT / 'validation.json').exists()
    proof = json.loads((RESULT / 'feature_validation.json').read_bytes())
    assert file_sha256(WORK / 'squad/soccer_features.parquet') == proof['feature_sha256']
    recipe = json.loads((RESULT / 'experiment_plan.json').read_bytes())['recipe']
    models.OUT = WORK / 'squad'; models.CANDIDATES[NAME] = recipe
    candidate = models.run('soccer', 'development', [NAME]); candidate['variant'] = 'candidate'
    reference = pd.read_parquet(REFERENCE / 'development_predictions.parquet')
    reference = reference[reference.variant.eq('candidate')].copy(); reference['variant'] = 'reference'
    a = candidate.set_index('game_id'); b = reference.set_index('game_id')
    fields = ['target', 'prediction_time', 'train_label_max', 'calibration_label_max']
    pd.testing.assert_frame_equal(a[fields].sort_index(), b[fields].sort_index(), check_dtype=False)
    joined = pd.concat([candidate, reference], ignore_index=True)
    joined.to_parquet(RESULT / 'development_predictions.parquet', index=False)
    metrics = models.metrics(joined); metrics.to_csv(RESULT / 'development_metrics.csv', index=False)
    scores = {}
    for variant, f in joined.groupby('variant'):
        p = f[['p0', 'p1', 'p2']].to_numpy(); y = f.target.to_numpy(int)
        f2025 = f[f.date.str[:4].eq('2025')]
        scores[variant] = dict(log_loss=log_loss(y, p, labels=[0, 1, 2]),
            brier=float(np.mean(np.sum((p - np.eye(3)[y])**2, axis=1))),
            log_loss2025=log_loss(f2025.target, f2025[['p0', 'p1', 'p2']], labels=[0, 1, 2]))
    passed = all(scores['candidate'][m] < scores['reference'][m] for m in ['log_loss', 'brier', 'log_loss2025'])
    paired.RESULT = RESULT; delta = paired.paired_comparison(candidate, reference)
    dump(RESULT / 'selection.json', dict(at_utc=stamp(), passed=bool(passed), scores=scores, paired=delta, adopted=False))
    package = pickle.loads((WORK / 'squad/model_runs/soccer/development' / (NAME + '.pkl')).read_bytes())
    frame = pd.read_parquet(WORK / 'squad/soccer_features.parquet')
    matrix = pd.concat([frame, pd.get_dummies(frame.league, prefix='league', dtype=float)], axis=1).set_index('game_id')
    sample = candidate[candidate.fold.eq(package['boundary'].strftime('%Y-%m'))]
    xx = matrix.loc[sample.game_id, package['columns']].replace([np.inf, -np.inf], np.nan).astype(float)
    replay = models.apply_calibration(package['model'].predict_proba(xx), package['calibrator'])
    assert np.allclose(replay, sample[['p0', 'p1', 'p2']], atol=1e-12, rtol=0)
    assert candidate.train_label_max.lt(candidate.prediction_time).all()
    assert candidate.calibration_label_max.lt(candidate.prediction_time).all()
    assert candidate.calibration_train_label_max.lt(candidate.calibration_prediction_min).all()
    pd.DataFrame(dict(feature=package['columns'], importance=package['model'].feature_importances_)).to_csv(
        RESULT / 'nonlinear_feature_importance.csv', index=False)
    evaluation = None
    if passed:
        dump(WORK / 'squad/soccer_selection.json', dict(selected_candidates=[NAME]))
        test = models.run('soccer', 'evaluation', [NAME]); test['variant'] = 'candidate'
        ref = pd.read_parquet(REFERENCE / 'evaluation_predictions.parquet')
        ref = ref[ref.variant.eq('candidate')].copy(); ref['variant'] = 'reference'
        evaluation = pd.concat([test, ref], ignore_index=True)
        evaluation.to_parquet(RESULT / 'evaluation_predictions.parquet', index=False)
        models.metrics(evaluation).to_csv(RESULT / 'evaluation_metrics.csv', index=False)
    simulation.RESULT = RESULT; simulation.simulate(joined, evaluation)
    dump(RESULT / 'validation.json', dict(status='PASS', at_utc=stamp(), development_gate_passed=bool(passed),
        evaluated2026=bool(passed), inputs=len(package['columns']), forecast_replays=len(sample),
        same_game_source_and_training_clocks=True, adopted=False, app_changed=False))
    print(json.dumps(dict(passed=bool(passed), scores=scores)), flush=True)


def finish():
    from final_pipeline import discard_work, cleanup, validate
    for name in ['feature_validation', 'linear_diagnosis_validation', 'validation', 'cash_validation', 'risk_validation']:
        assert json.loads((RESULT / (name + '.json')).read_bytes())['status'] == 'PASS'
    selection = json.loads((RESULT / 'selection.json').read_bytes())
    annual = pd.read_csv(RESULT / 'annual.csv')
    def table(f):
        def fmt(v): return f'{v:.6f}' if isinstance(v, (float, np.floating)) else str(v)
        return '\n'.join(['| ' + ' | '.join(f.columns) + ' |', '| ' + ' | '.join(['---'] * len(f.columns)) + ' |'] +
            ['| ' + ' | '.join(map(fmt, row)) + ' |' for row in f.itertuples(index=False, name=None)])
    influence = pd.read_csv(RESULT / 'linear_fold_influence.csv').head(8)
    lines = ['# Soccer corrected-data nonlinear comparison', '',
        'The December 2025 logistic loss review identifies long-run strength dominating some conflicting recent match evidence. For example, Leverkusen at Augsburg has a large Elo and UEFA coefficient advantage despite weaker recent shot-quality evidence. These coefficient contributions describe the fitted forecast; they are not a claim that an individual loss was predictable or that strength has no value.', '',
        'The attribution reconstructs every held-forward forecast of that monthly fit and the exact chosen-versus-actual logit of diagnosed losses. Targets enter explanations only. Mean absolute contributions for that one fold:', '', table(influence), '',
        'One existing shallow CatBoost recipe tests nonlinear interactions on the identical 41 corrected inputs: depth 2, 300 iterations, learning_rate 0.035, l2_leaf_reg 15, seed 42. Trees use native missing handling. No price inputs, qualification additions, team exclusions or parameter grid. Expanding monthly history starts in 2021; forecasts start in 2024. Purged trailing 180-day temperature calibration uses earlier results only.', '',
        'The gate requires lower pooled 2024/25 logloss and Brier plus lower 2025 logloss. It does not select on return. Gate passed: ' + str(selection['passed']) + '.', '',
        table(pd.DataFrame([dict(variant=k, **v) for k, v in selection['scores'].items()])), '',
        'Paired diagnostic: ' + json.dumps(selection['paired']) + '. This interval is not adjusted for the accumulated research searches.', '',
        'Each account starts the year with $2,000. The existing rule stakes $5 per positive probability-minus-price percentage point on one expected-log-growth-selected outcome. Cash is reused only after official settlement. Pre-12 uses the closest earlier recorded quote no more than 24 hours old. No added cost assumptions; providers remain separate. Historical Polymarket token prices are not verified executable US asks. Daily calendar Sharpe includes idle days and annualizes by sqrt(365.25).', '',
        table(annual[['provider', 'variant', 'year', 'funded_games', 'win_rate_pct', 'return_pct', 'sharpe', 'max_drawdown_pct']]), '',
        '## Separate exposure diagnosis and revision', '',
        'Fixed dollar stakes can consume an increasing fraction of a losing account. The failed nonlinear model eventually spends all remaining Polymarket cash on Liverpool at Brighton on 19 May 2025. This is a funded-exposure failure as well as a forecast error. Probability-band attribution and exact terminal positions are saved, including the unequal funded cohorts after cash exhaustion. Unfunded later matches are not treated as observed trading wins or losses.', '',
        table(pd.read_csv(RESULT / 'exposure_diagnosis.csv')), '',
        'The next test keeps the better corrected logistic forecasts, sides and desired stakes. It applies the existing 20% total-open-purchase-cost limit from the research engine. Simultaneous orders share remaining permitted cash proportionately; no leverage or unsettled-profit reuse. This is a separately labelled risk revision, not a change to the original fixed-dollar baseline. There is no search over cap values.', '',
        'A provider proceeds to 2026 only if 2025 Sharpe rises, drawdown falls and return remains positive, with no worse 2024 Sharpe where data exist. Selection: ' + json.dumps(json.loads((RESULT / 'risk_selection.json').read_bytes())['choices']) + '.', '',
        table(pd.read_csv(RESULT / 'risk_annual.csv')[['provider', 'year', 'funded_games', 'win_rate_pct', 'return_pct', 'sharpe', 'max_drawdown_pct']]), '',
        'No adoption or NBA/MLB app change. Repeatedly inspected 2026 is retrospective rolling research, not a pristine holdout. Final corrected source facts and raw provenance remain, with model forecasts and cash evidence. Completed temporary fits and input copies are removed.', '',
        'Reproduce soccer_corrected_nonlinear.py build, train, risk, finish. Build verifies the prior corrected-source hash and reconstructs sources if the prior work matrix is absent. No new API collection is performed. Official source URLs and raw hashes are inherited from soccer_source_count_rates.py and the acquisition README.']
    (REPORTS / (LABEL + '.md')).write_text('\n'.join(lines) + '\n', encoding='utf8')
    if WORK.exists(): discard_work(WORK)
    cleanup(); check = validate()
    receipt = dict(status='PASS', at_utc=stamp(), selection=selection, app_validation=check,
        temporary_work_removed=True, adopted=False, goal_achieved=False)
    dump(ROOT_OUT / 'retention' / (LABEL + '_completion.json'), receipt)
    path = ROOT_OUT / 'retention/retained_artifacts.json'; manifest = json.loads(path.read_bytes())
    manifest['scripts'] = {p.name: file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    manifest.update(updated_utc=stamp(), retained_scripts=len(manifest['scripts']), latest_simulation_update=receipt)
    dump(path, manifest)
    print(annual[['provider', 'variant', 'year', 'funded_games', 'return_pct', 'sharpe', 'max_drawdown_pct']].to_string(index=False), flush=True)


def risk():
    """Separate a capital-exhaustion problem from rejected forecast changes."""
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    assert not json.loads((RESULT / 'selection.json').read_bytes())['passed']
    assert not (RESULT / 'risk_validation.json').exists()
    b = pd.read_parquet(RESULT / 'bets.parquet')
    b['stake_fraction'] = b.stake / b.entry_equity
    b['probability_band'] = pd.cut(b.probability, [0, .3, .4, .5, .6, .7, 1.], include_lowest=True)
    b.groupby(['provider', 'variant', 'year', 'probability_band'], observed=True).agg(
        bets=('won', 'size'), win_rate=('won', 'mean'), predicted_probability=('probability', 'mean'),
        price=('price', 'mean'), profit=('profit', 'sum'), stakes=('stake', 'sum')).reset_index().to_csv(
            RESULT / 'loss_probability_bands.csv', index=False)
    records = []
    for key, g in b.groupby(['provider', 'variant', 'year']):
        records.append(dict(zip(['provider', 'variant', 'year'], key)) | dict(
            bets=len(g), mean_probability=float(g.probability.mean()), win_rate=float(g.won.mean()),
            mean_price=float(g.price.mean()), maximum_single_bet_equity_pct=100 * float(g.stake_fraction.max()),
            bets_above_eighth_equity=int(g.stake_fraction.gt(.125).sum())))
    pd.DataFrame(records).to_csv(RESULT / 'exposure_diagnosis.csv', index=False)
    b.sort_values('stake_fraction', ascending=False).head(20).to_csv(RESULT / 'largest_relative_exposures.csv', index=False)
    dump(RESULT / 'risk_plan.json', dict(at_utc=stamp(),
        hypothesis='Cash-only fixed stakes can become an all-in stake after losses. Isolate the existing total-open20%limit using the better logistic probabilities.',
        model='Unchanged corrected41-input logistic, not rejected CatBoost.',
        rule='Same desired$5per positive probability-price percentage point; total open purchase cost<=20%of contemporaneous account equity on each new allocation. Cash only, simultaneous requests proportional.',
        gate='2025Sharpe improves, drawdown falls, return positive;2024Sharpe no worse where data exist. No cap-grid search.',
        evaluation='Only a qualifying provider is evaluated2026; already repeatedly inspected retrospective rolling evidence.', app_changed=False))
    quotes = quote_inputs(RESULT / 'risk_quote_quality.json', revision='closest_v62')
    transfer.RESULT = RESULT
    reference = pd.read_csv(REFERENCE / 'annual.csv')
    reference = reference[reference.variant.eq('candidate')]
    annual, bets, days, checks, choices = [], [], [], [], {}
    for stage in ['development', 'evaluation']:
        if stage == 'evaluation' and not any(choices.values()): break
        pred = pd.read_parquet(REFERENCE / (stage + '_predictions.parquet'))
        pred = pred[pred.variant.eq('candidate')]
        source = transfer.normalize('soccer', pred, quotes, pick_growth=True)
        original = pd.read_parquet(REFERENCE / 'bets.parquet')
        original = original[original.variant.eq('candidate')]
        for provider, f in source.groupby('provider'):
            if stage == 'evaluation' and not choices.get(provider): continue
            for year in sorted(f.year.unique()):
                old, ob, ol, od = engine.simulate(f, int(year), 'all_selected_outcomes', 'edge_dollars_cash_only', 5., 2000.)
                saved = original[original.provider.eq(provider) & original.year.eq(year)].set_index('game_id').sort_index()
                replay = ob.set_index('game_id').sort_index()
                assert saved.index.equals(replay.index)
                assert np.allclose(saved[['side', 'price', 'stake', 'profit']], replay[['side', 'price', 'stake', 'profit']], atol=1e-8, rtol=0)
                m, cb, cl, cd = engine.simulate(f, int(year), 'all_selected_outcomes', 'edge_dollars_cap20', 5., 2000.)
                key = dict(sport='soccer', provider=provider, year=int(year), rule='corrected_logistic_open20')
                annual.append(key | m)
                checks.append(key | engine.validate(cb, cl, cd, 'edge_dollars_cap20', 5., 2000.))
                assert (cl[cl.spent.gt(0)].open_cost <= .2 * cl[cl.spent.gt(0)].equity + 1e-7).all()
                common = replay.index.intersection(cb.game_id)
                newer = cb.set_index('game_id').loc[common]
                assert np.allclose(replay.loc[common, ['side', 'probability', 'price', 'proposed_stake']], newer[['side', 'probability', 'price', 'proposed_stake']], rtol=0, atol=1e-10)
                if len(cb): bets.append(cb.assign(**key))
                days.append(cd.assign(**key))
        if stage == 'development':
            rows = pd.DataFrame(annual)
            for provider, f in rows.groupby('provider'):
                new = f[f.year.eq(2025)].iloc[0]
                old = reference[reference.provider.eq(provider) & reference.year.eq(2025)].iloc[0]
                passed = new.sharpe > old.sharpe and new.return_pct > 0 and new.max_drawdown_pct < old.max_drawdown_pct
                for r in f[f.year.eq(2024)].itertuples():
                    saved = reference[reference.provider.eq(provider) & reference.year.eq(2024)].iloc[0]
                    passed = passed and r.sharpe >= saved.sharpe
                choices[provider] = bool(passed)
            dump(RESULT / 'risk_selection.json', dict(at_utc=stamp(), choices=choices, adopted=False))
    a = pd.DataFrame(annual); a.to_csv(RESULT / 'risk_annual.csv', index=False)
    pd.concat(bets, ignore_index=True).to_parquet(RESULT / 'risk_bets.parquet', index=False)
    pd.concat(days, ignore_index=True).to_parquet(RESULT / 'risk_daily.parquet', index=False)
    dump(RESULT / 'risk_validation.json', dict(status='PASS', at_utc=stamp(), choices=choices, checks=checks,
        reference_positions_replayed=True, side_price_probability_desired_stake_unchanged=True,
        open_limit_checked_at_every_funding_batch=True, adopted=False, app_changed=False))
    path = ROOT_OUT / 'simulation_results/experiment_results.csv'; old = pd.read_csv(path, low_memory=False)
    key = LABEL + '/risk_annual.csv'
    pd.concat([old[old.source_result_file.ne(key)], a.assign(source_result_file=key)], ignore_index=True).to_csv(path, index=False)
    path = ROOT_OUT / 'simulation_results/experiment_decisions.json'; old = json.loads(path.read_bytes())
    old[LABEL + '/risk'] = dict(plan=json.loads((RESULT / 'risk_plan.json').read_bytes()), choices=choices, adopted=False); dump(path, old)
    print(a[['provider', 'year', 'funded_games', 'return_pct', 'sharpe', 'max_drawdown_pct']].to_string(index=False), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('stage', choices=['build', 'train', 'risk', 'finish'])
    globals()[parser.parse_args().stage]()
