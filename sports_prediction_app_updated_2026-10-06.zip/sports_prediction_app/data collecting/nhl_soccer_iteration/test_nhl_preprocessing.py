"""Controlled rest-transform or historical-weighting tests, rolling evaluation.

Only the primary NHL model changes; the retained secondary probability check,
quote timing, buy threshold and cash-account rules are held fixed.
"""
import argparse
import json
import pickle

import numpy as np
import pandas as pd

import models
from backtest import quote_inputs, attach, select, simulate
from cash_validation import validate_cash
from common import ROOT_OUT, dump, stamp, file_sha256
from final_pipeline import discard_work, cleanup

RESULT = ROOT_OUT / 'simulation_results/nhl_log_rest'
WORK = ROOT_OUT / '_work/nhl_log_rest'
NAME = 'log_rest_regulation_ot'
REVISION = 'log_rest'


def transform(frame):
    out = frame.copy()
    away = (frame.f_rest_days_sum-frame.f_rest_days_diff)/2
    home = (frame.f_rest_days_sum+frame.f_rest_days_diff)/2
    assert (away.dropna() >= -1e-10).all() and (home.dropna() >= -1e-10).all()
    # Original observations remain unchanged. These are research-only model
    # inputs; one day is the fixed time unit, not a tuned clipping threshold.
    a, b = np.log1p(away.clip(lower=0)), np.log1p(home.clip(lower=0))
    out['f_rest_days_diff'] = b-a
    out['f_rest_days_sum'] = a+b
    unchanged = frame.columns.difference(['f_rest_days_diff','f_rest_days_sum'])
    pd.testing.assert_frame_equal(out[unchanged],frame[unchanged],check_exact=True)
    assert np.allclose(np.expm1((out.f_rest_days_sum-out.f_rest_days_diff)/2),away,equal_nan=True)
    assert np.allclose(np.expm1((out.f_rest_days_sum+out.f_rest_days_diff)/2),home,equal_nan=True)
    return out


def stage(frame, quotes, stage_name, years):
    forecast = models.run('nhl',stage_name,[NAME])
    forecast['variant'] = 'candidate'
    retained = pd.read_parquet(ROOT_OUT/'retained_models/nhl'/(stage_name+'_predictions.parquet'))
    control = retained[retained.variant.eq('granular_regulation_ot')].copy()
    control['variant'] = 'retained'
    assert forecast.game_id.tolist() == control.game_id.tolist()
    second = retained[retained.variant.eq('granular_logistic_strong')][['game_id','p0','p1']].rename(
        columns={'p0':'second_p0','p1':'second_p1'})
    p = pd.concat([forecast,control],ignore_index=True).merge(second,on='game_id',validate='many_to_one')
    assert p.train_label_max.lt(p.prediction_time).all()
    metric = models.metrics(p)
    metric.to_csv(RESULT/(stage_name+'_metrics.csv'),index=False)
    p.to_parquet(RESULT/(stage_name+'_predictions.parquet'),index=False)
    joined,audit = attach(p,quotes)
    dump(RESULT/(stage_name+'_matching.json'),audit)
    annual,trades,curves = [],[],[]
    for (provider,variant),group in joined.groupby(['provider','variant']):
        chosen = select(group,'expected_profit')
        second_p = np.where(chosen.quote_class.eq(0),chosen.second_p0,chosen.second_p1)
        chosen = chosen[second_p/chosen.entry_price>=1.10].copy()
        for year in years:
            summary,t,c = simulate(chosen,year)
            meta = dict(sport='nhl',provider=provider,variant=variant,recipe='fixed',year=year)
            annual.append(meta|summary)
            if len(t):trades.append(t.assign(**meta))
            curves.append(c.assign(**meta))
    annual = pd.DataFrame(annual)
    t,c = pd.concat(trades,ignore_index=True),pd.concat(curves,ignore_index=True)
    checked = validate_cash(t,c)
    annual.to_csv(RESULT/(stage_name+'_annual.csv'),index=False)
    t.to_parquet(RESULT/(stage_name+'_bets.parquet'),index=False)
    c.to_parquet(RESULT/(stage_name+'_daily.parquet'),index=False)
    # Baseline replay must agree with the previously retained results.
    original = pd.read_csv(ROOT_OUT/'simulation_results/current/annual.csv')
    for row in annual[annual.variant.eq('retained')].itertuples():
        ref = original[original.sport.eq('nhl')&original.provider.eq(row.provider)&original.year.eq(row.year)].iloc[0]
        for col in ['bets','return_pct','sharpe','max_drawdown_pct']:
            assert np.isclose(getattr(row,col),ref[col],equal_nan=True,rtol=0,atol=1e-10)
    # Replay the final monthly fit before deleting trial fits.
    package = pickle.loads((WORK/'model_runs/nhl'/stage_name/(NAME+'.pkl')).read_bytes())
    sample = forecast[forecast.fold.eq(package['boundary'].strftime('%Y-%m'))].head(20)
    data = pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
    x = data.loc[sample.game_id,package['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
    context=data.loc[sample.game_id,'prior_roster_turnover_max'] if REVISION=='roster_calibration' else None
    actual = models.apply_calibration(package['model'].predict_proba(x),package['calibrator'],context)
    assert np.allclose(actual,sample[['p0','p1']],rtol=0,atol=1e-12)
    assert all(col not in package['columns'] for col in ['target','scoreA','scoreB'])
    return p,metric,annual,dict(cash_days=checked,forecast_replays=len(sample),forecasts=len(forecast))


def loss_comparison(p):
    a = p[p.variant.eq('candidate')].set_index('game_id')
    b = p[p.variant.eq('retained')].set_index('game_id').loc[a.index]
    assert a.target.eq(b.target).all()
    y = a.target.to_numpy(int)
    loss = {name:-np.log(f[['p0','p1']].to_numpy()[np.arange(len(y)),y]) for name,f in [('candidate',a),('retained',b)]}
    delta = loss['candidate']-loss['retained']
    blocks = pd.DataFrame(dict(fold=a.fold,delta=delta)).groupby('fold').delta.agg(['sum','count'])
    samples = np.random.default_rng(731).integers(0,len(blocks),size=(3000,len(blocks)))
    means = blocks['sum'].to_numpy()[samples].sum(axis=1)/blocks['count'].to_numpy()[samples].sum(axis=1)
    return dict(candidate_logloss=float(loss['candidate'].mean()),retained_logloss=float(loss['retained'].mean()),
        paired_loss_change=float(delta.mean()),monthly_block95_interval=np.quantile(means,[.025,.975]).tolist(),
        multiple_testing_adjusted=False)


def main():
    assert not WORK.exists(),'Inspect unfinished work before another run'
    assert not (RESULT/'validation.json').exists(),'Preserve completed comparison; choose a new declared revision'
    if REVISION=='goalie_profile':
        from nhl_goalie_profile import build_features
        build_features()
    else:WORK.mkdir(parents=True)
    RESULT.mkdir(exist_ok=True)
    try:
        path = ROOT_OUT/'retained_models/nhl/nhl_features.parquet'
        original = pd.read_parquet(path)
        frame = transform(original) if REVISION=='log_rest' else original.copy()
        if REVISION=='goalie_profile':
            frame=pd.read_parquet(WORK/'nhl_features.parquet')
            feature_proof=json.loads((WORK/'feature_validation.json').read_bytes())
            assert feature_proof['status']=='PASS' and feature_proof['feature_sha256']==file_sha256(WORK/'nhl_features.parquet')
            pd.testing.assert_frame_equal(frame[original.columns],original,check_exact=True)
        if REVISION=='roster_calibration':
            from nhl_error_diagnosis import roster_quality
            quality=roster_quality(frame)
            earlier=frame[frame.prediction_time<pd.Timestamp('2025-01-01',tz='UTC')]
            prefix=roster_quality(earlier)
            pd.testing.assert_frame_equal(prefix.set_index('game_id').sort_index(),
                quality.set_index('game_id').loc[prefix.game_id].sort_index(),check_exact=True)
            frame=frame.merge(quality[['game_id','prior_roster_turnover_max']],on='game_id',validate='one_to_one')
        frame.to_parquet(WORK/'nhl_features.parquet',index=False)
        spec = models.CANDIDATES['granular_regulation_ot'].copy()
        if REVISION=='recent_history':spec['half_life_days']=365
        if REVISION=='observed_scale':spec['observed_scale']=True
        if REVISION=='roster_calibration':spec.update(calibration='roster_shrink',calibration_context='prior_roster_turnover_max')
        models.CANDIDATES[NAME] = spec
        models.OUT = WORK
        plan = dict(at_utc=stamp(),hypothesis='Rest has diminishing returns. Linear day counts up to120 per team create extreme season-opening inputs; transform individual rest days before taking their sum/difference.',
            changed_columns=['f_rest_days_diff','f_rest_days_sum'],formula='a=(sum-diff)/2; b=(sum+diff)/2; revised sum=log1p(a)+log1p(b), diff=log1p(b)-log1p(a)',
            data_role='Only model input preprocessing changes; source days unchanged; units natural logarithm of1+days.',
            spec=spec,source_sha256=file_sha256(path),history='2021+; monthly expanding fits from2024 with earlier purged180day calibration.',
            gate='Lower pooled2024/25 primary logloss AND higher weaker-year Polymarket Sharpe; at least30bets in eachyear. Only a passing gate permits2026 evaluation.',
            short2024_sample='PM prices onlyDecember5-31; not a full-year trading result.',
            fixed='Secondary logistic forecasts, closest prior pre12 quotes, both probability/price>=1.10,1%NAV bets,20%open-cost cap,no costs.',
            caveat='2026 has been repeatedly inspected; any evaluation is retrospective. No automatic adoption.')
        if REVISION=='recent_history':
            plan.update(hypothesis='Predictive relationships may drift across seasons. Retain all2021+ games but weight labels with one fixed365-day half-life, without changing source features, model family or betting rules.',
                changed_columns=[],formula='training weight=2**(-age_days/365); Poisson solver normalizes sample weights internally; overtime subfit normalizes its tied-game weights to mean1',
                data_role='Only model-fit sample weights change. Features, original rest-day inputs and raw observations unchanged.',
                diagnostic='2025 calibration weaker than2024; selected-bet error exceeds global error. This test is a hypothesis, not proof of the cause.')
        if REVISION=='roster_calibration':
            plan.update(hypothesis='Observed roster changes may reduce confidence in historical strength. Learn one nonnegative shrinkage coefficient on the same earlier purged calibration games, without filtering games or using current actual lineups.',
                changed_columns=[],formula='p_final=(1-alpha*turnover)*temperature_probability+alpha*turnover/2; alpha in[0,1], fitted with existing .01 quadratic calibration regularization.',
                data_role='New calibration context is maximum observed five-game skater minute-share change across teams; compared with the preceding five completed games. Unknown minutes retain null and receive ordinary temperature calibration.',
                model_predictors_unchanged=True,prefix_invariant_rows=len(prefix),calibration_only_input='prior_roster_turnover_max')
        if REVISION=='goalie_profile':
            plan.update(hypothesis='An opposing attack profile can reveal goalkeeper weaknesses not captured by an overall save-quality average. Add earlier-only region matchup residuals and coverage to the primary goal-count model.',
                changed_columns=feature_proof['added_inputs'],formula=feature_proof['definition'],
                data_role='Four added model inputs derived from validated official regulation nonempty shot events; research xG fitted on earlier years; both original model inputs and secondary forecast unchanged.',
                feature_validation=feature_proof)
        if REVISION=='observed_scale':
            plan.update(hypothesis='Estimate NHL input scale from observed earlier values, before median filling. Leave added missing indicators binary. This avoids penalizing the same physical variation differently solely because historical coverage differs.',
                changed_columns=[],formula='StandardScaler fitted on observed earlier values -> median imputer with missing indicators -> unchanged Poisson/OT learners. No second scaling after imputation.',
                data_role='Original34source inputs and secondary logistic forecast unchanged. Only primary goal-count/OT preprocessing changes. No threshold or hyperparameter search.')
        dump(RESULT/'plan.json',plan)
        quotes = quote_inputs(RESULT/'quote_quality.json',revision='closest_v62')
        p,m,a,checks = stage(frame,quotes,'development',[2024,2025])
        loss = loss_comparison(p)
        accounts = a[a.provider.eq('polymarket')].groupby('variant').agg(min_sharpe=('sharpe','min'),min_bets=('bets','min')).to_dict('index')
        passed = loss['candidate_logloss']<loss['retained_logloss'] and accounts['candidate']['min_sharpe']>accounts['retained']['min_sharpe'] and accounts['candidate']['min_bets']>=30
        decision = dict(at_utc=stamp(),status='PASS',development_gate_passed=bool(passed),loss=loss,accounts=accounts,
                        checks=checks,evaluated2026=False,adopted=False,transformation_roundtrip_verified=REVISION=='log_rest',
                        source_features_unchanged=REVISION in ['recent_history','roster_calibration','observed_scale'])
        dump(RESULT/'validation.json',decision)
        print(json.dumps(decision),flush=True)
        print(a.to_string(index=False),flush=True)
        if passed:
            dump(WORK/'nhl_selection.json',dict(selected_candidates=[NAME]))
            ep,em,ea,ec = stage(frame,quotes,'evaluation',[2026])
            decision.update(evaluated2026=True,evaluation_checks=ec,evaluation_loss=loss_comparison(ep))
            dump(RESULT/'validation.json',decision)
            print(ea.to_string(index=False),flush=True)
        ledger_path = ROOT_OUT/'simulation_results/experiment_results.csv'
        ledger = pd.read_csv(ledger_path,low_memory=False)
        for stage_name in ['development']+(['evaluation'] if passed else []):
            for kind in ['annual','metrics']:
                name=stage_name+'_'+kind+'.csv';key=RESULT.name+'/'+name
                ledger=ledger[~ledger.source_result_file.eq(key)]
                ledger=pd.concat([ledger,pd.read_csv(RESULT/name).assign(source_result_file=key)],ignore_index=True)
        ledger.to_csv(ledger_path,index=False)
        record_path=ROOT_OUT/'simulation_results/experiment_decisions.json'
        records=json.loads(record_path.read_bytes())
        records[RESULT.name]=dict(plan=plan,decision=decision)
        dump(record_path,records)
    finally:
        if WORK.exists():discard_work(WORK)
        cleanup()


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--revision',choices=['log_rest','recent_history','roster_calibration','goalie_profile','observed_scale'],default='log_rest')
    REVISION=parser.parse_args().revision
    if REVISION=='recent_history':
        RESULT=ROOT_OUT/'simulation_results/nhl_recent_history'
        WORK=ROOT_OUT/'_work/nhl_recent_history'
        NAME='recent_history_regulation_ot'
    elif REVISION=='roster_calibration':
        RESULT=ROOT_OUT/'simulation_results/nhl_roster_calibration'
        WORK=ROOT_OUT/'_work/nhl_roster_calibration'
        NAME='roster_calibration_regulation_ot'
    elif REVISION=='goalie_profile':
        RESULT=ROOT_OUT/'simulation_results/nhl_goalie_profile'
        WORK=ROOT_OUT/'_work/nhl_goalie_profile'
        NAME='goalie_profile_regulation_ot'
    elif REVISION=='observed_scale':
        RESULT=ROOT_OUT/'simulation_results/nhl_observed_scale'
        WORK=ROOT_OUT/'_work/nhl_observed_scale'
        NAME='observed_scale_regulation_ot'
    main()
