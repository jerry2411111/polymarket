"""Unique native identity under documented mechanical umlaut transcription."""
import json
import pandas as pd
from common import dump,stamp
from collect_nhl_opening_rosters import RUN,namekey
from nhl_roster_aliases import read_source,verify_proof


def main():
    changes=[]
    for path in sorted(RUN.glob('*/full.parquet')):
        f=pd.read_parquet(path)
        if 'identity_evidence_json' not in f:f['identity_evidence_json']=None
        for i,r in f[~f.identity_verified].iterrows():
            source=json.loads(r.identity_source_json);obj=json.loads(read_source(source))
            if not all(k in obj for k in ['forwards','defensemen','goalies']):continue
            possible=[]
            for group in ['forwards','defensemen','goalies']:
                for index,p in enumerate(obj[group]):
                    full=p['firstName']['default']+' '+p['lastName']['default']
                    converted=full.translate(str.maketrans({'\u00e4':'ae','\u00f6':'oe','\u00fc':'ue','\u00c4':'Ae','\u00d6':'Oe','\u00dc':'Ue'}))
                    if full!=converted and p.get('birthCountry')=='DEU' and namekey(converted)==namekey(r.player_name_raw):possible.append((p,full,'/'+group+'/'+str(index)))
            if len(possible)!=1:continue
            p,full,pointer=possible[0];pid=str(p['id'])
            proof=dict(type='german_umlaut_transliteration',source_name=r.player_name_raw,canonical_name=full,official_player_id=pid,
                identity_pointer=pointer,identity_source=source,rule='Mechanical ae/oe/ue expansion of explicit umlaut characters; unique exact native roster match; no spelling-distance/nickname inference.')
            assert verify_proof(proof)
            f.loc[i,['official_player_id','player_name_api','position','identity_verified','identity_reason','identity_pointer','identity_candidates_json','identity_evidence_json']]=[
                pid,full,p['positionCode'],True,proof['rule'],pointer,json.dumps([pid]),json.dumps(proof,sort_keys=True)]
            changes.append(dict(season=r.season,team_id=r.team_id,player_name_raw=r.player_name_raw,official_player_id=pid,proof=proof))
        f.to_parquet(path,index=False);f.to_csv(path.with_suffix('.csv'),index=False)
        cp=path.parent/'full_collection.json';collection=json.loads(cp.read_bytes())
        collection.update(verified=int(f.identity_verified.sum()),unmatched=int((~f.identity_verified).sum()),unmatched_pct=float(100*(~f.identity_verified).mean()))
        dump(cp,collection)
    ledger=RUN/'orthographic_repairs.json';old=json.loads(ledger.read_bytes()) if ledger.exists() else []
    dump(ledger,old+changes);print(json.dumps(dict(newly_repaired=len(changes),players=[r['player_name_raw'] for r in changes])),flush=True)


if __name__=='__main__':main()
