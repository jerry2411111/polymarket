"""Causal passing/cohesion, sample standings and draw-style features."""
import collections
import hashlib
import json
import math
import sqlite3
import numpy as np
import pandas as pd
from common import ROOT_OUT,OUT,PROJECT,PREVIOUS,read_db,dump,stamp
from features import LEAGUE_CODE

def number(x):
    try:return float(x) if math.isfinite(float(x)) else np.nan
    except (ValueError,TypeError):return np.nan

def ratio(a,b):return a/b if np.isfinite(a) and np.isfinite(b) and b>0 else np.nan

def main():
    folder=OUT if OUT!=ROOT_OUT else ROOT_OUT/'soccer_passing_v2';folder.mkdir(exist_ok=True)
    with read_db(PREVIOUS/'expanded.sqlite') as c:games=pd.read_sql_query('SELECT * FROM soccer_games',c)
    games=games[games.date.between('2021-01-01','2026-09-30')].copy()
    registry={}
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as c:
        for code,native,body in c.execute('SELECT * FROM _eu_team_identity'):registry[(code,str(native))]=json.loads(body)['team_id']
    keys={}
    for g in games.to_dict('records'):
        for side,native in zip(['A','B'],json.loads(g['native_team_ids_json'])):keys[(g['game_id'],side)]=registry.get((LEAGUE_CODE[g['league']],str(native)),g['league']+':'+str(native))
    with read_db(ROOT_OUT/'uefa_passing.sqlite') as c:uefa=[r for b, in c.execute('SELECT body FROM reports') for r in json.loads(b)]
    with read_db(ROOT_OUT/'player_detail.sqlite') as c:pl=[json.loads(b) for b, in c.execute('SELECT body FROM player_match_detail')]
    for r in pl:
        r['official_player_id']=str(r['player_id']);r['source_league']='Premier League'
    for r in uefa:r['source_league']='UEFA Champions League'
    players=pd.DataFrame(uefa+pl);players=players[players.game_id.isin(games.game_id)].copy()
    players['team_key']=[keys[(r.game_id,r.side)] for r in players.itertuples()]
    players['player_key']=players.source_league+':'+players.official_player_id.astype(str)
    # Reuse only documented native-player ID crosswalks; do not name-merge.
    with read_db(PREVIOUS/'expanded.sqlite') as c:cross=pd.read_sql_query('SELECT league,official_player_id,player_id FROM soccer_player_games',c).drop_duplicates()
    cross['key']=cross.league+':'+cross.official_player_id.astype(str)
    unique=cross.groupby('key').player_id.nunique();mapping=cross[cross.key.isin(unique[unique.eq(1)].index)].drop_duplicates('key').set_index('key').player_id.to_dict()
    players['player_key']=players.player_key.map(mapping).fillna(players.player_key)
    players['available_time']=pd.to_datetime(players.available_at_utc,utc=True,format='mixed')
    players['played']=pd.to_numeric(players.minutes,errors='coerce').gt(0)
    players=players[players.played].copy()
    # These source-specific player facts are directly SQL-queryable. Source
    # objects and raw sparse statistics stay in the acquisition database.
    fields=['game_id','side','team_key','player_key','official_player_id','player_name','league','date','available_time','minutes','source_league','passes','passes_completed','long_passes','long_passes_completed','passing_entropy','passer_concentration','passes_to_player_json']
    published=players.reindex(columns=fields).copy();published.available_time=published.available_time.astype(str)
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as c:published.to_sql('soccer_player_passing',c,if_exists='replace',index=False)
    published.to_parquet(ROOT_OUT/'soccer_player_passing.parquet',index=False)
    observations=[]
    for (gid,side),group in players.groupby(['game_id','side']):
        row=dict(game_id=gid,side=side,team_key=keys[(gid,side)],available_time=group.available_time.max(),players=group.to_dict('records'))
        def total(name):return pd.to_numeric(group[name],errors='coerce').sum(min_count=1) if name in group else np.nan
        pc,pa,lp=total('passes_completed'),total('passes'),total('long_passes')
        row['completion_fraction']=ratio(pc,pa);row['long_pass_fraction']=ratio(lp,pa)
        observed=pd.to_numeric(group.passes_completed,errors='coerce');observed=observed.dropna()
        row['passer_concentration']=sum((x/pc)**2 for x in observed) if pc>0 else np.nan
        row['leading_passer_share']=max(observed)/pc if pc>0 else np.nan
        entropy=[(number(r.get('passing_entropy')),number(r.get('passes_completed'))) for r in row['players']];entropy=[(e,w) for e,w in entropy if np.isfinite(e) and np.isfinite(w) and w>0]
        row['recipient_entropy']=sum(e*w for e,w in entropy)/sum(w for e,w in entropy) if entropy else np.nan
        matrix={str(r['official_player_id']):json.loads(r['passes_to_player_json']) for r in row['players'] if isinstance(r.get('passes_to_player_json'),str)}
        complete=bool(matrix) and all(v is not None for values in matrix.values() for v in values.values())
        denominator=sum(v for values in matrix.values() for v in values.values()) if complete else 0
        row['reciprocal_passing_fraction']=sum(min(v,matrix.get(b,{}).get(a,0)) for a,values in matrix.items() for b,v in values.items())/denominator if denominator>0 else np.nan
        row['observed_players']=len(group);observations.append(row)
    observed=pd.DataFrame(observations).sort_values('available_time');queue=observed.to_dict('records');at=0;history=collections.defaultdict(lambda:collections.deque(maxlen=30))
    for col in ['start_time','prediction_time','available_time']:games[col]=pd.to_datetime(games[col],utc=True,format='mixed')
    events=games.sort_values('available_time').to_dict('records');position=0;results=collections.defaultdict(lambda:collections.deque(maxlen=60));standings=collections.defaultdict(lambda:collections.defaultdict(lambda:[0,0,0.]));out=[]
    passing=['completion_fraction','long_pass_fraction','passer_concentration','leading_passer_share','recipient_entropy','reciprocal_passing_fraction']
    def mean(h,key):
        values=[number(r.get(key)) for r in h];values=[v for v in values if np.isfinite(v)];return float(np.mean(values)) if values else np.nan
    for g in games.sort_values('prediction_time').to_dict('records'):
        cutoff=g['prediction_time']
        while at<len(queue) and queue[at]['available_time']<cutoff:
            r=queue[at];at+=1;history[r['team_key']].append(r)
        while position<len(events) and events[position]['available_time']<cutoff:
            old=events[position];position+=1
            for side,own,other in [('A',old['scoreA'],old['scoreB']),('B',old['scoreB'],old['scoreA'])]:
                key=keys[(old['game_id'],side)];points=3 if own>other else (1 if own==other else 0)
                results[key].append(dict(available_time=old['available_time'],draw=float(own==other),low_total=float(own+other<=2),scored=own,conceded=other))
                tab=standings[(old['league'],old['season'])][key];tab[0]+=1;tab[1]+=points;tab[2]+=own-other
        sides=[];sources=[]
        for side in ['A','B']:
            key=keys[(g['game_id'],side)];h=list(history[key]);r={}
            for field in passing:
                for count in [8,30]:r['passing_'+field+'_'+str(count)]=mean(h[-count:],field)
            if h:sources.append(max(x['available_time'] for x in h))
            rh=list(results[key]);sources.extend(x['available_time'] for x in rh)
            for field in ['draw','low_total']:r[field+'_rate']=mean(rh,field)
            r['goals_for']=mean(rh,'scored');r['goals_against']=mean(rh,'conceded')
            tab=standings[(g['league'],g['season'])];n,points,margin=tab[key]
            r['season_games']=n;r['sample_points_per_game']=ratio(points,n);r['sample_margin_per_game']=ratio(margin,n)
            known=[v[1]/v[0] for v in tab.values() if v[0]>0]
            r['sample_points_percentile']=sum(x<r['sample_points_per_game'] for x in known)/len(known) if known and n>0 else np.nan
            r['sample_points_gap_to_leader']=max(known)-r['sample_points_per_game'] if known and n>0 else np.nan
            sides.append(r)
        row=dict(game_id=g['game_id'],passing_source_max_available_utc=max(sources) if sources else None)
        assert not sources or max(sources)<cutoff
        for field in sides[0]:
            row['f_context_'+field+'_diff']=sides[1][field]-sides[0][field];row['f_context_'+field+'_sum']=sides[1][field]+sides[0][field]
        ag=math.sqrt(sides[0]['goals_for']*sides[1]['goals_against']);bg=math.sqrt(sides[1]['goals_for']*sides[0]['goals_against'])
        row['f_context_goal_total_proxy']=ag+bg;row['f_context_goal_balance_abs']=abs(ag-bg);row['f_context_goal_balance_relative']=ratio(abs(ag-bg),ag+bg)
        out.append(row)
    base=pd.read_parquet(OUT/'soccer_features.parquet')
    # Preserve the base snapshot for a later collection refresh in this run.
    base=base.drop(columns=[c for c in base if c.startswith('f_context_') or c=='passing_source_max_available_utc'])
    frame=base.merge(pd.DataFrame(out),on='game_id',validate='one_to_one')
    frame.to_parquet(folder/'soccer_features.parquet',index=False)
    catalog=dict(created_at_utc=stamp(),games=len(frame),source_player_rows=len(players),uefa_player_rows=len(uefa),pl_player_rows=len(pl),features=len([c for c in frame if c.startswith('f_')]),player_source_rows_sha256=hashlib.sha256(published.to_json(orient='records').encode()).hexdigest(),future_input_violations=0,missing_pct={c:100*frame[c].isna().mean() for c in frame if c.startswith('f_')},description='Dated passing networks, observed-sample points and draw/low-score tendency. Sample rank is an internally computed statistic, not the official competition table. Histories pool the six competitions through documented club IDs.')
    dump(folder/'enrichment.json',catalog);print(json.dumps({k:v for k,v in catalog.items() if k not in ['missing_pct','description']}),flush=True)

if __name__=='__main__':main()
