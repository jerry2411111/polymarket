"""Test home context on the unchanged, corrected soccer argmax forecast."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from common import ROOT_OUT, REPORTS, dump, stamp, file_sha256
from backtest import quote_inputs
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine

LABEL='soccer_winner_home_context'
RESULT=ROOT_OUT/'simulation_results'/LABEL
SOURCE=ROOT_OUT/'simulation_results/soccer_laliga_current_history'


def main():
    RESULT.mkdir(exist_ok=True);assert not (RESULT/'validation.json').exists()
    plan=dict(at_utc=stamp(),
        diagnosis='Corrected2025Polymarket confidence5stakes earned2804.43on383home-winner picks versus30.95on205away-winner picks. Home-pick confidence65.07percent and winrate67.62percent; away confidence62.27percent and winrate60.49percent.',
        hypothesis='Home context may identify a better calibrated subset with more stable return. This is an earlier-result-informed filter, not a causal explanation.',
        rules='Unchanged model full three-class argmax; existing pre12quotes andfixed5*(100*p-51)stakes, p>51percent. Home-only means side1; never change an away or draw pick to home.',
        gate='Higher2025Sharpe withpositive return and no worse2024Sharpe when available, versus allwinner control. Freezeproviderchoice before2026. No other threshold or stake grid.',
        accounting='Annual2000cash; settlement-only reuse; no costs; all UTCcalendar days incl idle; Sharpe sqrt365.25; historicalPMtokenprices andKalshiYESaskcloses have their existing source meaning.',
        limitation='2026has already been inspected many times and remains retrospective research, not a pristine holdout.',app_changed=False)
    dump(RESULT/'plan.json',plan)
    quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    rows=[];bets=[];days=[];checks=[];choices={};hashes={}
    for stage in ['development','evaluation']:
        path=SOURCE/(stage+'_predictions.parquet');hashes[path.name]=file_sha256(path)
        p=pd.read_parquet(path);p=p[p.variant.eq('clock_identity')].copy()
        assert p.game_id.is_unique and p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
        f=transfer.normalize('soccer',p,quotes,pick_growth=False)
        for provider,g in f.groupby('provider'):
            variants=['control','home_only'] if stage=='development' or choices.get(provider,False) else ['control']
            for variant in variants:
                h=g if variant=='control' else g[g.side.eq(1)]
                for year in sorted(p.prediction_time.dt.year.unique()):
                    m,b,l,d=engine.simulate(h,int(year),'winner_above51','dollars_cash_only',5.,2000.)
                    key=dict(sport='soccer',provider=provider,variant=variant,year=int(year),stage=stage)
                    rows.append(key|m);checks.append(key|engine.validate(b,l,d,'dollars_cash_only',5.,2000.))
                    if len(b):
                        assert b.side.eq(b[['p0','p1','p2']].to_numpy().argmax(axis=1)).all()
                        if variant=='home_only':assert b.side.eq(1).all()
                        bets.append(b.assign(**key))
                    days.append(d.assign(**key))
        if stage=='development':
            a=pd.DataFrame(rows)
            for provider,g in a.groupby('provider'):
                ix=g.set_index(['variant','year']);c,h=ix.loc[('control',2025)],ix.loc[('home_only',2025)]
                early=ix.loc[('control',2024),'sharpe'];earlyh=ix.loc[('home_only',2024),'sharpe']
                choices[provider]=bool(h.sharpe>c.sharpe and h.return_pct>0 and (pd.isna(early) or earlyh>=early))
            dump(RESULT/'selection.json',dict(at_utc=stamp(),providers=choices,used2026=False,adopted=False))
    a=pd.DataFrame(rows);a.to_csv(RESULT/'annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/'bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'daily.parquet',index=False)
    old=pd.read_csv(ROOT_OUT/'simulation_results/winner_risk_revision/corrected_soccer_annual.csv')
    old=old[old.variant.eq('corrected_control')].set_index(['provider','year'])
    ctrl=a[a.variant.eq('control')].set_index(['provider','year']);common=old.index.intersection(ctrl.index)
    for field in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
        assert np.allclose(old.loc[common,field],ctrl.loc[common,field],rtol=0,atol=1e-9,equal_nan=True)
    proof=dict(status='PASS',at_utc=stamp(),checks=checks,source_hashes=hashes,prior_control_rows_replayed=len(common),
        all_purchases_are_model_argmax=True,app_changed=False,adopted=False)
    dump(RESULT/'validation.json',proof)
    cols=['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']
    table='\n'.join(['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']+['| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in r)+' |' for r in a[cols].itertuples(index=False,name=None)])
    (REPORTS/(LABEL+'.md')).write_text('\n\n'.join(['# Soccer home-winner filter',plan['diagnosis'],plan['hypothesis'],plan['rules'],plan['gate'],table,plan['accounting'],plan['limitation'],'Every bet remains the original three-class model argmax. Reproduce soccer_winner_home_context.py.'])+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL]=dict(plan=plan,selection=choices,validation=proof);dump(path,old)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(a[cols].to_string(index=False),flush=True);print(json.dumps(dict(choices=choices)),flush=True)


if __name__=='__main__':main()
