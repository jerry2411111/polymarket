"""Player on-ice chance counts, using verified shift identities and manpower.

Boundary ambiguity is rejected rather than resolved using the eventual result.
The output explicitly counts mapped events and does not call a partial sum a
complete official NHL statistic. xG remains an internal prior-year model.
"""
import argparse,collections,hashlib,json,sqlite3
import numpy as np
import pandas as pd
from common import ROOT_OUT,PREVIOUS,read_db,dump,stamp

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--native-id',nargs='*');parser.add_argument('--limit',type=int);args=parser.parse_args()
    with read_db(PREVIOUS/'expanded.sqlite') as c:players=pd.read_sql_query('SELECT game_id,official_player_id,position FROM nhl_player_games',c)
    positions={(r.game_id,str(r.official_player_id)):r.position for r in players.itertuples()}
    shot_path=ROOT_OUT/'nhl_shot_detail.parquet';shot_digest=hashlib.sha256(shot_path.read_bytes()).hexdigest()
    shots=pd.read_parquet(shot_path);sgroups={gid:g for gid,g in shots.groupby('game_id')}
    target=sqlite3.connect(ROOT_OUT/'nhl_on_ice.sqlite',timeout=60);target.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT); CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,reason TEXT);')
    done={r[0]:r[1] for r in target.execute("SELECT game_id,json_extract(body,'$.source_signature') FROM games")}
    # Repaired shifts and newly collected participant reports must invalidate
    # the prior derivation. Game ID alone is not a sufficient cache key.
    signatures={};tasks=[];report_db=ROOT_OUT/'nhl_event_players.sqlite'
    reports=read_db(report_db) if report_db.exists() else None
    selection='';parameters=[]
    if args.native_id:
        with read_db(PREVIOUS/'expanded.sqlite') as c:
            parameters=[r[0] for r in c.execute('SELECT game_id FROM nhl_games WHERE CAST(official_game_id AS TEXT) IN ('+','.join('?'*len(args.native_id))+')',args.native_id)]
        selection=' WHERE game_id IN ('+','.join('?'*len(parameters))+')'
    with read_db(ROOT_OUT/'nhl_shifts.sqlite') as c:
        for gid,body in c.execute('SELECT game_id,body FROM games'+selection,parameters):
            prior=reports.execute('SELECT body FROM games WHERE game_id=?',(gid,)).fetchone() if reports else None
            report_body=prior[0] if prior else ''
            signature=hashlib.sha256(('onice-v2\n'+shot_digest+'\n'+body+'\n'+report_body).encode()).hexdigest()
            if done.get(gid)!=signature:
                signatures[gid]=signature;tasks.append(gid)
    if args.limit:tasks=tasks[:args.limit]
    milestone=10;counts=collections.Counter();print(json.dumps(dict(stage='on_ice_refresh',games=len(tasks))),flush=True)
    for n,gid in enumerate(tasks,1):
        with read_db(ROOT_OUT/'nhl_shifts.sqlite') as c:shift_body=c.execute('SELECT body FROM games WHERE game_id=?',(gid,)).fetchone()[0]
        g=json.loads(shift_body)
        if gid not in sgroups:
            with target:target.execute('INSERT OR REPLACE INTO issues VALUES (?,?)',(gid,'No shot-event history'))
            continue
        s=sgroups[gid].copy();s=s[s.period_type.ne('SO')&s.defending_goalie_present.eq(1)].reset_index(drop=True)
        prior=reports.execute('SELECT body FROM games WHERE game_id=?',(gid,)).fetchone() if reports else None
        report=json.loads(prior[0]) if prior else None
        signatures[gid]=hashlib.sha256(('onice-v2\n'+shot_digest+'\n'+shift_body+'\n'+(prior[0] if prior else '')).encode()).hexdigest()
        sides={r['player_id']:r['side'] for r in g['rows']}
        if report:
            for r in report['rows']:
                for side,pids in r['participants'].items():
                    for pid in pids:
                        assert pid not in sides or sides[pid]==side
                        sides[pid]=side
                        if (gid,pid) in positions:assert (positions[(gid,pid)]=='G')==(r['positions'][pid]=='G')
                        else:positions[(gid,pid)]=r['positions'][pid]
        pids=sorted(sides);index={pid:i for i,pid in enumerate(pids)}
        member=np.zeros((len(pids),len(s)),dtype=bool);duration=collections.Counter();period_ends=collections.defaultdict(int)
        for r in g['rows']:
            if r['duration_seconds']<=0:continue
            mask=s.period.eq(r['period'])&s.seconds.ge(r['start_seconds'])&s.seconds.le(r['end_seconds'])
            member[index[r['player_id']],mask.to_numpy()]=True;duration[r['player_id']]+=r['duration_seconds'];period_ends[r['period']]=max(period_ends[r['period']],r['end_seconds'])
        report_used=np.zeros(len(s),dtype=bool);event_columns={int(v):i for i,v in enumerate(s.event_id)}
        if report:
            for r in report['rows']:
                if r['event_id'] not in event_columns:continue
                j=event_columns[r['event_id']];member[:,j]=False
                for group in r['participants'].values():
                    for pid in group:member[index[pid],j]=True
                report_used[j]=True
        isgoalie=np.array([positions[(gid,pid)]=='G' for pid in pids]);side=np.array([sides[pid] for pid in pids]);valid=np.ones(len(s),dtype=bool)
        for name in ['A','B']:
            skaters=member[(side==name)&~isgoalie].sum(axis=0);expected=np.where(s.side.eq(name),s.attackers,s.defenders)
            valid&=skaters==expected
        # A recorded shooter must appear in that side's on-ice set. This rejects
        # mixed line changes and clock disagreements at shift boundaries.
        for j,r in enumerate(s.itertuples()):
            pid=str(r.shooter_id)
            if pid not in index or not member[index[pid],j] or sides[pid]!=r.side:valid[j]=False
            if pd.notna(r.goalie_id):
                goalie=str(int(r.goalie_id))
                if goalie not in index or not member[index[goalie],j] or sides[goalie]==r.side:valid[j]=False
        xg=s.model_xg.to_numpy(float);known=np.isfinite(xg)&valid;goal=s.result.eq('goal').to_numpy();ice_seconds=sum(period_ends.values());out=[]
        for pid,i in index.items():
            if isgoalie[i] or duration[pid]<=0:continue
            on=member[i]&valid;own=s.side.eq(sides[pid]).to_numpy();rows=dict(game_id=gid,date=g['date'],side=sides[pid],official_player_id=pid,position=positions[(gid,pid)],available_at_utc=g['available_at_utc'],shift_seconds=duration[pid],game_seconds=ice_seconds,eligible_game_attempts=len(s),mapped_game_attempts=int(valid.sum()),mapped_game_fraction=float(valid.mean()) if len(s) else None)
            for label,eventside in [('for',own),('against',~own)]:
                mask=on&eventside;rows['mapped_attempts_'+label]=int(mask.sum());rows['mapped_goals_'+label]=int((mask&goal).sum());rows['modelled_attempts_'+label]=int((mask&known).sum());rows['mapped_model_xg_'+label]=float(xg[mask&known].sum()) if (mask&known).any() else None
                off=(~member[i])&known&eventside;rows['off_ice_model_xg_'+label]=float(xg[off].sum()) if off.any() else None
            out.append(rows)
        assert (valid[report_used]).all(),'Verified report participants failed downstream event checks'
        record=dict(game_id=gid,players=out,eligible_attempts=len(s),mapped_attempts=int(valid.sum()),unmapped_attempts=int((~valid).sum()),
                    mapped_with_official_report=int((valid&report_used).sum()),mapped_with_shift_intervals=int((valid&~report_used).sum()),
                    shift_sources=g['sources'],event_participant_sources=report['sources'] if report else [],shot_sources=sorted(set(s.source_raw_file)),
                    source_signature=signatures[gid],derivation='Exact official event participants where verified; shift intervals otherwise. Native identities must reproduce official manpower, shooter and known goalie. Unreconciled events remain excluded and documented; counts are partial mapped observations.')
        with target:
            target.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(gid,json.dumps(record,allow_nan=False)))
            target.execute('DELETE FROM issues WHERE game_id=?',(gid,))
        counts['games']+=1;counts['players']+=len(out);counts['eligible_attempts']+=len(s);counts['mapped_attempts']+=int(valid.sum())
        if n*100>=milestone*len(tasks) or n==len(tasks):
            result=dict(at_utc=stamp(),processed=n,total=len(tasks),percent=round(100*n/len(tasks),1),counts=dict(counts));dump(ROOT_OUT/'on_ice_progress.json',result);print(json.dumps(result),flush=True);milestone+=10
    target.close()
    if reports:reports.close()

if __name__=='__main__':main()
