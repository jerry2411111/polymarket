"""Time-weighted on-ice player contribution, with expanding dated fits.

Sparse monthly sufficient statistics avoid retaining millions of duplicate
training rows. They exactly encode exposure-weighted ridge least squares.
"""
import argparse,collections,json,pickle
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from scipy import sparse
from scipy.sparse.linalg import cg
from sklearn.linear_model import Ridge
from threadpoolctl import threadpool_limits
from common import ROOT_OUT,REPORTS,read_db,dump,stamp,file_sha256
import nhl_player_strength as roster
from nhl_duration_chances import WORK,RESULT,INTERVALS,COVERAGE

FIELDS=['f_gran_duration_attempt_rate','f_gran_duration_chance_rate']


class Ratings:
    def __init__(self,games,players):
        self.ids=sorted(set(players.loc[players.position.ne('G'),'official_player_id'].astype(str)))
        self.lookup={pid:i for i,pid in enumerate(self.ids)};self.p=len(self.ids);self.d=2*self.p+3
        self.stats={};self.audits=[];self.algebra=[];self.loaded=[]
        self.matrices={f:sparse.csr_matrix((self.d,self.d)) for f in FIELDS}
        self.responses={f:np.zeros(self.d) for f in FIELDS};self.games={f:set() for f in FIELDS};self.maximum={f:None for f in FIELDS}
        available=games.set_index('game_id').available_time.to_dict();allowed=set(available)
        columns=['game_id','duration_seconds','skaterA_ids_json','skaterB_ids_json','scoreA_before','scoreB_before','attemptsA','attemptsB','xgA','xgB','usable']
        total=0
        for batch in pq.ParquetFile(ROOT_OUT/(INTERVALS+'.parquet')).iter_batches(batch_size=20000,columns=columns):
            frame=batch.to_pandas();frame=frame[frame.usable&frame.game_id.isin(allowed)].copy()
            if not len(frame):continue
            frame['available']=pd.to_datetime(frame.game_id.map(available),utc=True);frame['month']=frame.available.dt.strftime('%Y-%m')
            for month,g in frame.groupby('month',sort=False):
                n=len(g);a=np.array([[self.lookup[p] for p in json.loads(s)] for s in g.skaterA_ids_json],int)
                b=np.array([[self.lookup[p] for p in json.loads(s)] for s in g.skaterB_ids_json],int)
                attack=np.vstack([a,b]);defence=np.vstack([b,a])+self.p
                rows=np.repeat(np.arange(2*n),5);dense=np.arange(2*n)
                margin=np.clip((g.scoreB_before-g.scoreA_before).to_numpy(float),-3,3)/3
                X=sparse.coo_matrix((np.r_[np.ones(20*n),-np.ones(n),np.ones(n),-margin,margin,np.ones(2*n)],
                    (np.r_[rows,rows,dense,dense,dense],np.r_[attack.ravel(),defence.ravel(),np.full(2*n,2*self.p),np.full(2*n,2*self.p+1),np.full(2*n,2*self.p+2)])),shape=(2*n,self.d)).tocsr()
                exposure=np.tile(g.duration_seconds.to_numpy(float)/3600,2)
                values=[np.r_[g.attemptsA.to_numpy(float),g.attemptsB.to_numpy(float)],np.r_[g.xgA.to_numpy(dtype=float,na_value=np.nan),g.xgB.to_numpy(dtype=float,na_value=np.nan)]]
                if month not in self.stats:self.stats[month]={}
                for field,y in zip(FIELDS,values):
                    mask=np.isfinite(y)
                    if not mask.any():continue
                    part=self.stats[month].setdefault(field,dict(G=sparse.csr_matrix((self.d,self.d)),b=np.zeros(self.d),games=set(),source_max=None,interval_rows=0,hours=0.,observed_count=0.))
                    xx=X[mask];w=exposure[mask]
                    if field not in {a['field'] for a in self.algebra}:
                        # Independent library fit on actual source counts and
                        # rates verifies the count/hour normal equations.
                        sample=np.unique(np.r_[np.arange(min(100,len(w))),np.arange(max(0,len(w)-100),len(w))])
                        sx=xx[sample];sw=w[sample];sy=y[mask][sample]
                        used=np.flatnonzero(np.asarray(abs(sx).sum(axis=0)).ravel()>0);without=used[used!=self.d-1]
                        direct=Ridge(alpha=20,solver='lsqr',tol=1e-12).fit(sx[:,without],sy/sw,sample_weight=sw)
                        gram=sx[:,used].T@sx[:,used].multiply(sw[:,None]);penalty=np.full(len(used),20.);penalty[used==self.d-1]=0
                        normal=gram+sparse.diags(penalty);rhs=np.asarray(sx[:,used].T@sy).ravel()
                        beta,info=cg(normal,rhs,rtol=1e-12,atol=1e-12,maxiter=5000);assert info==0
                        error=float(max(abs(direct.predict(sx[:,without])-sx[:,used]@beta)));assert error<1e-7
                        self.algebra.append(dict(field=field,real_source_directional_rows=len(sample),max_rate_prediction_difference=error,library='sklearn weighted Ridge against sparse count/exposure normal equations'))
                    # y is a count. e*(y/e)=y, avoiding huge numerical rates
                    # in one-second intervals while preserving the exact fit.
                    part['G']+=xx.T@xx.multiply(w[:,None]);part['b']+=np.asarray(xx.T@y[mask]).ravel()
                    rows_known=mask[:n]|mask[n:];part['games'].update(g.loc[rows_known,'game_id']);part['interval_rows']+=int(mask.sum())
                    latest=g.loc[rows_known,'available'].max();part['source_max']=max(part['source_max'],latest) if part['source_max'] is not None else latest
                    part['hours']+=float(w.sum());part['observed_count']+=float(y[mask].sum())
            total+=len(frame)
        self.summary=dict(usable_intervals=total,months=len(self.stats),native_skaters=self.p,algebra_validation=self.algebra,
            objective='sum(exposure_hours*(count/exposure_hours-X*beta)^2)+20*sum(nonintercept_beta^2)',
            design='Separate attacking and defending skater coefficients; signed home indicator, clipped own score margin and unpenalized intercept. Two directional observations per interval.',
            fields={field:dict(games=len(set().union(*(v[field]['games'] for v in self.stats.values() if field in v))),
                hours=sum(v[field]['hours'] for v in self.stats.values() if field in v),observed_count=sum(v[field]['observed_count'] for v in self.stats.values() if field in v)) for field in FIELDS})
        print(json.dumps(dict(stage='duration_sufficient_statistics',**self.summary)),flush=True)

    def fit(self,boundary,ids):
        month=boundary.strftime('%Y-%m')
        for key in sorted(self.stats):
            if key>=month or key in self.loaded:continue
            for field,part in self.stats[key].items():
                self.matrices[field]+=part['G'];self.responses[field]+=part['b'];self.games[field].update(part['games'])
                last=part['source_max'];self.maximum[field]=max(self.maximum[field],last) if self.maximum[field] is not None else last
            self.loaded.append(key)
        if len(self.games[FIELDS[0]])<100:return None,None
        fitted={'training_games':len(self.games[FIELDS[0]])};checks=[]
        for field in FIELDS:
            if len(self.games[field])<100:fitted[field]=None;continue
            assert self.maximum[field]<boundary
            gram=self.matrices[field];seen=np.flatnonzero(gram.diagonal()>0)
            penalties=np.full(len(seen),20.);penalties[seen==self.d-1]=0.
            A=gram[seen][:,seen]+sparse.diags(penalties);rhs=self.responses[field][seen]
            with threadpool_limits(limits=2):
                coef,info=cg(A,rhs,rtol=1e-11,atol=1e-10,maxiter=5000)
            error=float(np.max(abs(A@coef-rhs)));assert info==0 and error<1e-5
            allcoef=np.zeros(self.d);allcoef[seen]=coef
            net=allcoef[:self.p]-allcoef[self.p:2*self.p]
            fitted[field]=np.array([net[self.lookup[str(pid)]] if role=='skater' and str(pid) in self.lookup else 0. for role,pid in ids])
            checks.append(dict(field=field,games=len(self.games[field]),source_max=self.maximum[field],normal_equation_error=error,
                observed_parameters=len(seen),intercept=float(allcoef[-1]),home_coefficient=float(allcoef[-3]),score_context_coefficient=float(allcoef[-2])))
        audit=dict(fold=month,training_games=fitted['training_games'],checks=checks);self.audits.append(audit)
        return fitted,audit

    def predict(self,vector,fitted):
        return {f:float(vector@fitted[f]) if fitted[f] is not None else np.nan for f in FIELDS}


def build():
    check=json.loads((RESULT/'source_validation.json').read_bytes());assert check['status']=='PASS' and check['normalizer_version']=='interval-v2'
    for t in check['tables']:assert file_sha256(ROOT_OUT/(t['table']+'.parquet'))==t['sha256']
    plan=dict(at_utc=stamp(),hypothesis='Conditional opportunity shares omit pace. Time-weighted contributions can distinguish how frequently a lineup creates and concedes chances.',
        fields=FIELDS,history='2021onward; monthly expanding player/game fits;2024/25development before2026',
        player_model='Exposure-weighted Ridge20, separate attack/defence coefficients; two directional count/hour responses per verified interval. Signed home and pre-event score controls; no price input. Goal xG model uses prior years.',
        forecast_roster='Unchanged dated five-observation usage pool and opening-roster seeds. No actual future lineup. Net contribution is attack minus concession effect, weighted by expected usage.',
        comparison='Existing primary regulation-Poisson/overtime and secondary strong logistic, same complete all-phase cohort, plus only two time-weighted skater inputs.',
        selection='Both pooled2024/25primary logloss and mean component logloss must improve; no alpha/cutoff grid.2026retrospective, not untouched.',
        betting='Unchanged one selected outcome, both component p/price>=1.10; fixed$20from$2000, cash-only, pre12closest prior<=24h; providers separate.',
        source_limitations='Unusable intervals retainNULLcounts; unknown exposure not inferred. Rejection by event type is reported. Zone-start and deployment selection remain unmodelled, so associations are not causal.',
        source_hashes={t['table']:t['sha256'] for t in check['tables']})
    path=RESULT/'experiment_plan.json'
    if path.exists():assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(path,plan)
    games,players,rosters,keys=roster.load();rating=Ratings(games,players)
    extra,audit=roster.derive(games,players,rosters,keys,False,rating,FIELDS)
    dump(RESULT/'rating_fit_audit.json',rating.audits);dump(RESULT/'sufficient_statistics.json',rating.summary)
    del rating
    cutoff=pd.Timestamp('2025-01-01',tz='UTC');early=games[games.prediction_time.lt(cutoff)].copy();ep=players[players.game_id.isin(early.game_id)]
    provider=Ratings(early,ep)
    prefix,_=roster.derive(early,ep,rosters[pd.to_datetime(rosters.available_at_utc,utc=True,format='mixed').lt(cutoff)],keys,False,provider,FIELDS)
    pd.testing.assert_frame_equal(prefix.set_index('game_id'),extra.set_index('game_id').loc[prefix.game_id],check_exact=False,rtol=0,atol=1e-8)
    del provider,ep
    extra.to_parquet(WORK/'duration_features.parquet',index=False)
    import features,nhl_identity_features
    g,o,p,_,stats,metrics,_=features.sources('nhl',include_preseason=True)
    needed=['game_id','side','available_at_utc','player_id','official_player_id','minutes','position','saves','shots_against']+metrics
    p=roster.apply_repairs(p[list(dict.fromkeys(needed+['played']))]);base,_=nhl_identity_features.derive(g,o,p,stats,metrics,repaired=True,regulation_labels=games)
    prior=pd.read_parquet(ROOT_OUT/'nhl_roster_strength_features.parquet')[['game_id']+roster.FIELDS]
    frame=base.merge(prior,on='game_id',validate='one_to_one').merge(extra[['game_id']+FIELDS],on='game_id',validate='one_to_one')
    frame.to_parquet(WORK/'nhl_features.parquet',index=False)
    dump(RESULT/'feature_validation.json',dict(status='PASS',at_utc=stamp(),**audit,prefix_invariant_rows=len(prefix),source_cutoffs_checked=True,
        feature_sha256=file_sha256(WORK/'nhl_features.parquet'),fields=FIELDS))
    print(json.dumps(dict(stage='duration_features_ready',games=len(frame),prefix_invariant_rows=len(prefix))),flush=True)


def configure():
    import nhl_joint_player_model as trial
    trial.WORK=WORK;trial.RESULT=RESULT;trial.FIELDS=FIELDS
    trial.CONTROL={trial.PRIMARY:'duration_control_regulation_ot',trial.SECOND:'duration_control_logistic_strong'}
    return trial


def lineup_feasibility():
    """Source timing, not a backtest or assertion of confirmed starters."""
    from common import PREVIOUS
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        r=pd.read_sql_query('SELECT game_id,date,start_time,available_at_utc,available_by_pre12,source_issue_count FROM nhl_dated_lineup_reports',db)
        status=pd.read_sql_query('SELECT report_status,COUNT(*) AS rows FROM nhl_dated_lineup_players GROUP BY report_status',db)
    with read_db(PREVIOUS/'expanded.sqlite') as db:phases=pd.read_sql_query('SELECT game_id,phase FROM nhl_games',db)
    r=r.merge(phases,on='game_id',validate='one_to_one')
    for col in ['start_time','available_at_utc']:r[col]=pd.to_datetime(r[col],utc=True,format='mixed')
    r['before_start']=r.available_at_utc.lt(r.start_time);r['year']=r.date.str[:4]
    rows=r.groupby('year').agg(reports=('game_id','size'),available_pre12=('available_by_pre12','sum'),available_before_start=('before_start','sum')).reset_index()
    rows.to_csv(RESULT/'lineup_cutoff_feasibility.csv',index=False)
    r.groupby(['year','phase']).agg(reports=('game_id','size'),available_pre12=('available_by_pre12','sum'),available_before_start=('before_start','sum')).to_csv(RESULT/'lineup_cutoff_by_phase.csv')
    value=dict(at_utc=stamp(),evidence='Time and conditional-opportunity summaries both failed earlier probability-score gates; new time-weighted chance input correlates0.934with existing player xG-strength in pre2026history.',
        next='Investigate dated lineup/deployment information published afterpre12. Any new entry must use a market observation after the information publication/revision and before game start. Do not apply new information to a stale pre-announcement purchase.',
        article_status_counts=dict(zip(status.report_status,status.rows.astype(int))),not_yet_tested=True,
        scope='Availability counts only; projected lineups are not confirmed starters. Native identities, source issues, price coverage and earlier-only model selection remain required.')
    dump(RESULT/'next_direction.json',value)
    return rows


def finish():
    from final_pipeline import discard_work,cleanup,validate
    from pathlib import Path
    model=json.loads((RESULT/'model_validation.json').read_bytes());assert model['status']=='PASS'
    source=json.loads((RESULT/'source_validation.json').read_bytes());choice=json.loads((RESULT/'selection.json').read_bytes())
    configure().diagnose_losses();feasibility=lineup_feasibility()
    for t in source['tables']:assert file_sha256(ROOT_OUT/(t['table']+'.parquet'))==t['sha256']
    report=REPORTS/'nhl_duration_chances.md'
    coverage=pd.read_parquet(ROOT_OUT/(COVERAGE+'.parquet'))
    types=pd.read_csv(RESULT/'event_rejection_by_type.csv').pivot(index='result',columns='status',values='events').fillna(0)
    totals=types.sum(axis=1);types['uncounted_pct']=100*(totals-types.usable)/totals
    lines=['# NHL time-weighted player contribution test','',
        'The preceding opportunity-share test repeated much of the existing player-strength signal. This test adds the actual duration of verified on-ice lineups, distinguishing chance frequency per hour from conditional chance share. It retains the original match models, histories, price timing and betting rule.','',
        f"The source dataset contains {source['tables'][0]['rows']:,} disjoint regulation intervals across {len(coverage):,} games. {source['counted_attempts']:,} of {source['eligible_attempts']:,} eligible five-on-five attempts have verified exposure and complete interval numerators; {source['uncounted_pct']:.6f}% remain uncounted and explicitly recorded for repair. Outside-usable time includes legitimate special teams and empty nets as well as source conflicts, so it is not a missing-time percentage.",'',
        '|Attempt type|Eligible|Usable|Uncounted|','|---|---:|---:|---:|']
    for kind,r in types.iterrows():lines.append(f'|{kind}|{int(totals[kind])}|{int(r.usable)}|{r.uncounted_pct:.6f}%|')
    lines+=['',
        'Exact duplicate native shifts collapse to a single interval. Differing overlapping versions are flagged, and their possible exposure is excluded. Shot attribution requires exact native participants and pre-event score. A shot that cannot be assigned invalidates all possible neighboring interval numerators; those counts stayNULL, not0. An original goal progression replay and full SQL/Parquet comparison cover every published game/row.','',
        'An overly broad availability check was corrected before model fitting: an empty-net or shootout attempt without internal xG no longer erases known five-on-five values. Every collected2022-2026game has relevant five-on-five xG. Most2021games lack an earlier-year shot model; two late-December local-date games occur in2022UTC and correctly use the preceding-year fit.','',
        'Player estimation uses two directional observations per usable interval. Separate attacking and defending skater coefficients account for the other nine skaters; home orientation and pre-event score difference are controls. Regression weights are actual exposure hours. Ridge penalty20is fixed, the intercept is unpenalized, and sparse count/exposure equations are checked against a separate sklearn weighted regression on actual source rows. No market odds or future player statistics enter this layer.','',
        'Monthly player ratings use only completed source observations before the fitting boundary. The game model adds two expected-usage-weighted net ratings: attempts per hour and internally modelled goals per hour. Forecast rosters remain the dated five-observation pool/opening releases, not the actual later lineup. The full2021+history expands with time; preprocessing and calibration use past data only. Truncating all future history must reproduce earlier features.','',
        'This is an observational predictive model. Zone starts and deployment selection remain unmodelled, and rejected events are not missing at random by assumption. The event-type coverage audit is retained rather than claiming complete causal adjusted plus-minus.','',
        '|2024/25 selection metric|Same-cohort control|Time-weighted inputs|','|---|---:|---:|---:|']
    for metric in ['primary_logloss','component_logloss']:lines.append(f"|{metric}|{choice['scores']['control'][metric]:.9f}|{choice['scores']['candidate'][metric]:.9f}|")
    lines+=['',f"The earlier-period gate {'passed' if choice['passed'] else 'failed'}.2026candidate evaluation {'was permitted' if choice['passed'] else 'was not run'}. No new model is adopted into the app.",'',
        'The fixed comparator chooses one outcome by the original expected-log-growth ranking, then requires both forecast probabilities divided by purchase price to be at least1.10. It stakes$20from an annual$2,000 starting account, subject to available cash, at the latest prior pre12quote no more than24hours old. It holds to official settlement. Providers stay separate; no new cost or spread assumptions are added. Daily equity values unsettled positions at cost.','',
        '|Provider|Year|Model|Bets|Bet win rate|Return|Sharpe|Max drawdown|','|---|---:|---|---:|---:|---:|---:|---:|']
    account_frames=[]
    for stage in ['development','evaluation']:
        path=RESULT/(stage+'_annual.csv')
        if not path.exists():continue
        a=pd.read_csv(path);account_frames.append(a)
        for r in a.itertuples():lines.append(f'|{r.provider}|{r.year}|{r.variant}|{r.funded_games}|{r.win_rate_pct:.2f}%|{r.return_pct:.2f}%|{r.sharpe:.3f}|{r.max_drawdown_pct:.2f}%|')
    accounts=pd.concat(account_frames,ignore_index=True)
    target=accounts[accounts.variant.eq('candidate')&accounts.year.eq(2026)&accounts.sharpe.ge(3)&accounts.return_pct.gt(20)]
    lines+=['',
        'Earlier_high_confidence_losses.csv records the12highest-confidence2025Polymarket losing examples, their official results, source clocks and new probability changes. Loss groups, paired monthly uncertainty, feature correlations and coefficients support interpretation. No losing month/team is retrospectively removed.','',
        'The new time-weighted chance-rate feature correlates0.934with the existing skater xG-strength feature in pre2026history. It moves the losing Winnipeg preseason example only from80.89%to79.54%. This revision adds little independent strength information and does not directly observe match-specific deployment.','',
        'A different next direction is source timing:1,337stored2025lineup reports were available before game start, but only112by pre12. Thus1,225reports arrived later in the pre-match window. These are frequently projected lineups, not confirmations. lineup_cutoff_feasibility.csv and lineup_cutoff_by_phase.csv preserve the coverage. No later-entry strategy has yet been tested; prices must follow the newly used information, and all training/source clocks must remain earlier than the new decision.','',
        'The2026period has been repeatedly researched and is retrospective rolling evaluation, not a pristine test set. No parameter or cutoff search was performed within this experiment. The overall NHL/soccer goal remains active; a single profitable candidate would not establish completion for both sports.','',
        'Official sources: https://api-web.nhle.com/v1/gamecenter/{game_id}/play-by-play ; https://api.nhle.com/stats/rest/en/shiftcharts ; https://www.nhl.com/scores/htmlreports/{season}/PL{suffix}.HTM . Native URLs, original response files and hashes are linked in the coverage source_json and upstream event-player coverage table. Official report HTML supplies participant sets absent from the API.','',
        'Method reference: https://arxiv.org/abs/1201.0317 . That paper motivates exposure-weighted offensive/defensive player estimation with regularization; this experiment does not reproduce its complete zone-start and situation modelling.','',
        'Reproduce: nhl_duration_chances.py collect ; nhl_duration_chances.py publish ; nhl_duration_player_model.py build ; nhl_duration_player_model.py train ; nhl_duration_player_model.py finish . Final sources, normalized tables, forecasts and simulation evidence survive; temporary normalized caches, matrices and trial fits are removed only after validation.']
    report.write_text('\n'.join(lines)+'\n',encoding='utf8')
    decisions_path=ROOT_OUT/'simulation_results/experiment_decisions.json';decisions=json.loads(decisions_path.read_bytes())
    for path in RESULT.glob('*.json'):decisions[path.relative_to(ROOT_OUT/'simulation_results').as_posix()]=json.loads(path.read_bytes())
    dump(decisions_path,decisions)
    path=ROOT_OUT/'simulation_results/experiment_results.csv';all_results=pd.read_csv(path);prefix=RESULT.relative_to(ROOT_OUT/'simulation_results').as_posix()+'/'
    all_results=all_results[~all_results.source_result_file.str.startswith(prefix,na=False)];added=[]
    for pattern in ['*_annual.csv','*_metrics.csv']:
        for p in RESULT.glob(pattern):
            f=pd.read_csv(p);f['source_result_file']=prefix+p.name;f['sport']='nhl';added.append(f)
    pd.concat([all_results]+added,ignore_index=True).to_csv(path,index=False)
    if WORK.exists():discard_work(WORK)
    cleanup();app=validate()
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        tables=db.execute('SELECT COUNT(*) FROM table_catalog').fetchone()[0];columns=db.execute('SELECT COUNT(*) FROM column_catalog').fetchone()[0]
    mp=ROOT_OUT/'retention/retained_artifacts.json';manifest=json.loads(mp.read_bytes());code=Path(__file__).parent
    manifest['scripts']={p.name:file_sha256(p) for p in sorted(code.glob('*.py'))}
    manifest.update(updated_utc=stamp(),retained_scripts=len(manifest['scripts']),final_tables=tables,current_sql_columns=columns,
        latest_dataset_update=dict(tables=source['tables'],report=str(report)),latest_simulation_update=dict(result=str(RESULT.relative_to(ROOT_OUT)),adopted=False,report=str(report)))
    dump(mp,manifest)
    receipt=dict(status='PASS',at_utc=stamp(),source=source,model=model,selection=choice,app_validation=app,temporary_work_removed=True,
        retrospective_target_rows=target.to_dict('records'),goal_achieved=False,report=str(report))
    dump(ROOT_OUT/'retention/nhl_duration_completion.json',receipt)
    state_path=ROOT_OUT/'research_continuation.json';state=json.loads(state_path.read_bytes())
    state.update(at_utc=stamp(),current_job=None,live_sessions=[],running_jobs=[],last_action='Published and fully verified NHL time/exposure tables; completed dated duration-player model comparison and cash replay; trial work removed.',
        next_action='Duration-player features rejected on2024/25scores. Inspect verified match-specific lineup/deployment information afterpre12:2025has1337reports beforestart but112beforepre12. A separately timed test must use subsequent market observations and never call projected lineups confirmed. Preserve source repair queue and soccer role/replacement-quality work. No app change.',report=str(report),final_sql_tables=tables,final_sql_columns=columns)
    state.setdefault('research_state',{})['nhl_duration_chances']=receipt;dump(state_path,state)
    print(json.dumps(dict(status='PASS',gate=choice['passed'],retrospective_target_rows=len(target),report=str(report))),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['build','train','finish']);a=p.parse_args()
    {'build':build,'train':lambda:configure().train(),'finish':finish}[a.stage]()
