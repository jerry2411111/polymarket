"""Fixed price-advantage buffer and NHL two-model agreement after the loss audit.

No feature fitting, threshold sweep or 2026-selected policy. Five percentage
points is the previously used margin, now subtracted before dollar sizing.
"""
import argparse
import json
import numpy as np
import pandas as pd
from common import ROOT_OUT, dump, stamp, file_sha256
from final_pipeline import cleanup
import test_confidence_dollars as engine
import transfer_stake_sizing as transfer

SIM=ROOT_OUT/'simulation_results'
OUT=SIM/'uncertainty_buffer_staking'


def main():
    assert not (OUT/'validation.json').exists()
    OUT.mkdir(exist_ok=True)
    path=SIM/'probability_price_staking/bets.parquet'
    b=pd.read_parquet(path);b=b[b.sizing.eq('edge_dollars_cash_only')].copy()
    assert not b.duplicated(['sport','provider','year','game_id']).any()
    a=pd.read_csv(SIM/'probability_price_staking/annual.csv')
    assert a[a.sizing.eq('edge_dollars_cash_only')].unfunded_games.eq(0).all()
    selections=json.loads((SIM/'staking_model_selection/selection.json').read_bytes())
    transfer.RESULT=SIM/'transferred_account_staking'
    p=transfer.get_forecasts('nhl',selections['selections']['nhl']).set_index('game_id')
    nhl=b.sport.eq('nhl');idx=p.loc[b.loc[nhl,'game_id']]
    assert np.allclose(idx[['p0','p1']],b.loc[nhl,['p0','p1']],rtol=0,atol=1e-14)
    b.loc[nhl,'secondary_probability']=np.where(b.loc[nhl,'side'].eq(0),idx.second_p0,idx.second_p1)
    assert b.loc[nhl,'secondary_probability'].between(0,1).all()
    plan=dict(at_utc=stamp(),source_sha256=file_sha256(path),initial_cash=2000,dollars_per_edge_point=5,
        price_margin=.05,models_unchanged=True,chosen_outcome_unchanged=True,
        variants=['baseline:5*100*max(primary_probability-price,0)',
            'buffer5:5*100*max(primary_probability-.05-price,0)',
            'NHL consensus:5*100*max(min(primary_probability,secondary_probability)-price,0)',
            'NHL consensus_buffer5:5*100*max(min(primary_probability,secondary_probability)-.05-price,0)'],
        distinction='The reduced probability is a sizing allowance, not a new calibrated forecast or an actual confidence bound. Original primary and secondary probabilities remain saved.',
        purpose='Protect against modest forecast error, especially soccer50-60%overconfidence; NHL agreement checks whether model-specific overestimates create large stakes.',
        selection='Before evaluating2026, choose on2025higher Sharpe and lower maximum drawdown than baseline, with positive return. Keep all results.2026repeatedly inspected retrospective research.',
        cash='Fixed dollars, not compounded; same simultaneous available-cash constraint, no additional risk cap.',
        providers_separate=True,app_changed=False)
    dump(OUT/'plan.json',plan)
    rows=[];bets=[];days=[];checks=[];choices={}
    for year in [2025,2026]:
        for (sport,provider),g in b.groupby(['sport','provider']):
            for rule in ['baseline','buffer5']+(['consensus','consensus_buffer5'] if sport=='nhl' else []):
                f=g.copy();f['primary_probability']=f.probability
                if rule.startswith('consensus'):f['probability']=np.minimum(f.probability,f.secondary_probability)
                if rule.endswith('buffer5'):f['probability']=(f.probability-.05).clip(lower=0)
                f['sizing_probability']=f.probability;f['edge']=f.probability-f.price
                f=f[f.edge.gt(0)]
                m,positions,l,d=engine.simulate(f,year,'all_selected_outcomes','edge_dollars_cash_only',5.,2000.)
                key=dict(sport=sport,provider=provider,year=year,rule=rule)
                checks.append(key|engine.validate(positions,l,d,'edge_dollars_cash_only',5.,2000.))
                rows.append(key|m);bets.append(positions.assign(**key));days.append(d.assign(**key))
                if rule=='baseline':
                    prior=g[g.year.eq(year)].sort_values('game_id');current=positions.sort_values('game_id')
                    assert list(prior.game_id)==list(current.game_id)
                    assert np.allclose(prior[['stake','profit']],current[['stake','profit']],rtol=0,atol=1e-7)
        if year==2025:
            a=pd.DataFrame(rows)
            for key,g in a.groupby(['sport','provider']):
                original=g[g.rule.eq('baseline')].iloc[0]
                good=g[g.rule.ne('baseline')&g.return_pct.gt(0)&g.sharpe.gt(original.sharpe)&g.max_drawdown_pct.lt(original.max_drawdown_pct)]
                best=good.sort_values(['sharpe','rule'],ascending=[False,True]).iloc[0] if len(good) else None
                choices['/'.join(key)]=dict(rule=None if best is None else str(best.rule),selection_year=2025)
            dump(OUT/'frozen_choices.json',dict(at_utc=stamp(),choices=choices))
        print(json.dumps(dict(stage='uncertainty_buffer',finished_year=year)),flush=True)
    a=pd.DataFrame(rows);a['selected_on2025']=[r.rule==choices[r.sport+'/'+r.provider]['rule'] for r in a.itertuples()]
    a.to_csv(OUT/'annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(OUT/'bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(OUT/'daily.parquet',index=False)
    assert file_sha256(path)==plan['source_sha256']
    dump(OUT/'validation.json',dict(at_utc=stamp(),status='PASS',checks=checks,original_baseline_reproduced_exactly=True,
        providers_separate=True,no_new_model_fit=True,source_unchanged=True,app_changed=False,adopted=False))
    path=SIM/'experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=OUT.name+'/annual.csv'
    pd.concat([old[~old.source_result_file.eq(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=SIM/'experiment_decisions.json';old=json.loads(path.read_bytes());old[OUT.name]=dict(plan=plan,choices=choices,adopted=False);dump(path,old)
    cleanup()
    print(a[['sport','provider','year','rule','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct','selected_on2025']].to_string(index=False))


def fixed_stake_test(shares=False):
    """Separate forecast agreement/relative advantage from uncertain edge size."""
    assert (OUT/'validation.json').exists()
    prefix='fixed_shares' if shares else 'fixed_stake'
    assert not (OUT/(prefix+'_validation.json')).exists()
    saved=pd.read_parquet(OUT/'bets.parquet')
    f=saved[saved.rule.eq('baseline')].copy()
    source=pd.read_parquet(SIM/'probability_price_staking/bets.parquet')
    source=source[source.sizing.eq('edge_dollars_cash_only')]
    assert not f.duplicated(['sport','provider','year','game_id']).any()
    assert len(f)==len(source)
    plan=dict(at_utc=stamp(),reason='The loss audit shows stake size can reverse an otherwise profitable probability band. Use the pre-existing10%expected-return requirement with a flat$20stake instead of trusting edge size to scale stakes.',
        gate='NHL min(primary,secondary)/price-1>=.10; soccer primary/price-1>=.10. Require both NHL models to value the purchased outcome.',
        stake='Fixed$20(1%of starting$2000), cash only; compare same gate with existing$5per raw edge point. No cap or threshold tuning.',
        no_new_forecasts=True,selection='2025before2026;2026retrospective',app_changed=False)
    if shares:
        plan.update(reason='Low-price winners create payout concentration. Fixed share count controls dollar payouts instead of dollar cost.',
            stake='40shares per purchased outcome; costs40*price, exactly$20at a50cent price. Same available-cash constraints. This anchor is fixed, not fitted to returns.',
            variants=['All original positive-value selections','Existing10%relative-advantage gate, with NHL two-model agreement'])
    dump(OUT/(prefix+'_plan.json'),plan)
    records=[];bets=[];days=[];checks=[];chosen={}
    for year in [2025,2026]:
        for (sport,provider),g in f.groupby(['sport','provider']):
            probability=np.minimum(g.primary_probability,g.secondary_probability) if sport=='nhl' else g.primary_probability
            rules=['all_positive_edge_flat40shares','relative_advantage10_flat40shares'] if shares else ['relative_advantage10_edge_dollars','relative_advantage10_flat20']
            for rule in rules:
                data=g.copy() if rule.startswith('all_positive') else g[(probability/g.price-1).ge(.10)].copy()
                dpp=5.
                data['probability']=data.primary_probability
                sizing='flat40shares_cash_only' if shares else ('flat20_cash_only' if rule.endswith('flat20') else 'edge_dollars_cash_only')
                m,b,l,d=engine.simulate(data,year,'all_selected_outcomes',sizing,dpp,2000.)
                key=dict(sport=sport,provider=provider,year=year,rule=rule)
                checks.append(key|engine.validate(b,l,d,sizing,dpp,2000.))
                if rule.endswith('flat20'):
                    assert b.proposed_stake.eq(20.).all()
                if shares:
                    assert np.allclose(b.stake/b.price,40*b.allocation_scale)
                records.append(key|m);bets.append(b.assign(**key));days.append(d.assign(**key))
        if year==2025:
            a=pd.DataFrame(records)
            baseline=pd.read_csv(OUT/'annual.csv');baseline=baseline[baseline.year.eq(2025)&baseline.rule.eq('baseline')].set_index(['sport','provider'])
            for key,g in a.groupby(['sport','provider']):
                ref=baseline.loc[key]
                good=g[g.return_pct.gt(0)&g.sharpe.gt(ref.sharpe)&g.max_drawdown_pct.lt(ref.max_drawdown_pct)]
                best=good.sort_values(['sharpe','rule'],ascending=[False,True]).iloc[0] if len(good) else None
                chosen['/'.join(key)]=None if best is None else str(best.rule)
            dump(OUT/(prefix+'_choices.json'),dict(at_utc=stamp(),selected_on2025=chosen))
    a=pd.DataFrame(records);a.to_csv(OUT/(prefix+'_annual.csv'),index=False)
    pd.concat(bets,ignore_index=True).to_parquet(OUT/(prefix+'_bets.parquet'),index=False)
    pd.concat(days,ignore_index=True).to_parquet(OUT/(prefix+'_daily.parquet'),index=False)
    dump(OUT/(prefix+'_validation.json'),dict(at_utc=stamp(),status='PASS',checks=checks,source_probabilities_preserved=True,app_changed=False,adopted=False))
    path=SIM/'experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=OUT.name+'/'+prefix+'_annual.csv'
    pd.concat([old[~old.source_result_file.eq(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=SIM/'experiment_decisions.json';old=json.loads(path.read_bytes());old[OUT.name+'/'+prefix]=dict(plan=plan,choices=chosen,adopted=False);dump(path,old)
    cleanup()
    print(a[['sport','provider','year','rule','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].round(4).to_string(index=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--fixed',action='store_true');parser.add_argument('--shares',action='store_true');args=parser.parse_args()
    fixed_stake_test(shares=args.shares) if args.fixed or args.shares else main()
