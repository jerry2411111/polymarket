"""Verify the retained official player-identity evidence and links."""
import collections,json
import pandas as pd
from common import ROOT_OUT,PROJECT,dump,stamp
from soccer_identity_repair import RUN,read,pointer,identity,namekey

def check_identities(source_players=None):
    f=pd.read_parquet(RUN/'identity_evidence.parquet');cache={};attributes=collections.defaultdict(list)
    for r in f.itertuples():
        s=json.loads(r.source_json)
        if s['sha256'] not in cache:cache[s['sha256']]=read(s)[0]
        node=pointer(cache[s['sha256']],r.profile_pointer);pid,names,dob=identity(r.identity_kind,node)
        if r.identity_kind!='lal':assert pid==r.official_player_id
        else:assert '/'+r.official_player_id+'/' in json.dumps(node['squads'])
        assert str(dob)[:10]==r.birth_date and set(json.loads(r.full_names_json))<=set(n for n in names if n)
        attributes[r.player_id].extend((namekey(n),r.birth_date) for n in json.loads(r.full_names_json))
    edges=json.loads((RUN/'identity_edges.json').read_bytes())
    for e in edges:
        pair=(e['normalized_full_name'],e['birth_date']);assert pair in attributes[e['player_a']] and pair in attributes[e['player_b']]
    old=pd.read_parquet(source_players or ROOT_OUT/'player_pool_diagnosis_v53/players.parquet');linked=pd.read_parquet(RUN/'players_relinked.parquet')
    assert not linked.duplicated(['game_id','player_id']).any()
    pd.testing.assert_frame_equal(linked.drop(columns=['player_id','source_model_player_id']),old.drop(columns='player_id'),check_exact=True)
    result=dict(status='PASS',at_utc=stamp(),raw_responses_verified=len(cache),native_profile_rows=len(f),identity_edges_checked=len(edges),
        no_name_only_merges=True,source_values_and_clocks_exact=True,participant_rows=len(linked))
    dump(RUN/'identity_validation.json',result);return result

if __name__=="__main__":print(json.dumps(check_identities()))
