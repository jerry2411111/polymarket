"""Date-batched expansion of verified official NHL lineup archive routes."""
import argparse,concurrent.futures,json,time,traceback
from pathlib import Path
import pandas as pd
from common import ROOT_OUT,OfficialClient,dump,stamp
from collect_dated_lineup_survey import RUN as PILOT,parse,urls,source_games
from nhl_roster_aliases import read_source

ROOT=ROOT_OUT/'dated_lineup_archive_v72'


def main():
    p=argparse.ArgumentParser();p.add_argument('--year',type=int,required=True,choices=range(2021,2027));p.add_argument('--repair',action='store_true');p.add_argument('--source-index',type=str);args=p.parse_args()
    assert json.loads((PILOT/'validation.json').read_bytes())['status']=='PASS'
    out=ROOT/str(args.year);out.mkdir(parents=True,exist_ok=True)
    # Legacy articles use native numeric suffixes. Do not issue thousands of
    # known-invalid generic routes; require a separately documented URL index.
    source_index=json.loads(Path(args.source_index).read_bytes()) if args.source_index else {}
    if args.year<=2023 and not source_index:raise ValueError('Legacy NHL years require --source-index: official-game-ID to documented official article URLs. Generic modern routes do not establish historical absence.')
    if args.repair:assert (out/'summary.json').exists(),'Repair only after the acquisition batch is terminal'
    g=source_games()
    g=g[g.date.str.startswith(str(args.year))][['game_id','official_game_id','date','teamA','teamB','native_team_ids_json','start_time','prediction_time']].sort_values(['start_time','game_id'])
    assert not g.duplicated(['date','teamA','teamB']).any(),'Do not guess between duplicate same-date fixtures'
    g.to_parquet(out/'requested_games.parquet',index=False);calendar_total=len(g)
    if source_index:
        # A search index is not exhaustive: preserve already verified routes
        # when repairing the remaining unlocated games.
        acquired=set()
        for gid in g.game_id:
            record=out/(gid+'.json')
            if record.exists() and json.loads(record.read_bytes()).get('source'):acquired.add(gid)
        located=g.game_id.isin(source_index)|g.game_id.isin(acquired)
        missing=g[~located].copy();missing.to_csv(out/'pending_article_discovery.csv',index=False)
        g=g[located].copy()
        assert len(g),'No indexed official game IDs belong to the requested calendar'
    plan=out/'plan.json'
    if not plan.exists():dump(plan,dict(at_utc=stamp(),year=args.year,games=len(g),selection='All observed official regular-season/playoff games in this calendar year, independent of market presence, results and forecasts.',
        interpretation='Projected lineups/injuries are dated statements, not confirmed current starters. Latest modification governs availability. For pre12 only earlier reports may enter; any injury-history feature must resolve later documented appearances and preserve report age.',
        scope='Whole requested history remains2021-2026; this is one calendar-year acquisition batch. Unlocated routes are repair work, not proof of unavailable data.',
        source_policy='Official APIs omit publication-dated projected lines and injury lists. Official news HTML only for these omitted fields; native content_tags/gameid validates every match; no current-game result is a predictor.',rate_per_second=2,workers=2))
    client=OfficialClient(per_second=2)
    if args.repair:
        metadata=json.loads(plan.read_bytes());metadata['source_identity_repair_policy']=dict(at_utc=stamp(),rule='If native game tag is absent, require exact canonical URL team order and month/day, matching two lineup headings, publication local date within preceding day/current date, and a unique official schedule pair on that date. Nonempty conflicting game tags remain rejected. No model or outcome selection changed.');dump(plan,metadata)
    def one(game):
        game=game|dict(_allow_unique_schedule_match=True)
        path=out/(game['game_id']+'.json')
        if path.exists():
            old=json.loads(path.read_bytes())
            if old.get('source') or (not args.repair and not source_index):return old
            for attempt in old['attempts']:
                if attempt['source']['return_status']!='200':continue
                data,reason=parse(read_source(attempt['source']),game)
                if data:
                    r=dict(game_id=game['game_id'],**data,source=attempt['source'],attempts=old['attempts'],repair_at_utc=stamp());dump(path,r);return r
        pilot=PILOT/(game['game_id']+'.json')
        if pilot.exists():
            r=json.loads(pilot.read_bytes())
            if r.get('source'):
                data,reason=parse(read_source(r['source']),game)
                if data:dump(path,r);return r
        attempts=[];r=None
        for url in source_index.get(game['game_id'],urls(game)):
            blob,source=client.get(url,str(args.year)+' complete calendar NHL projected-lineup/injury archive; verify native game tag','nhl_dated_lineup_archive',document=True)
            data,reason=parse(blob,game) if blob else (None,'HTTP_'+source['return_status'])
            attempts.append(dict(source=source,parse_status=reason))
            if data:r=dict(game_id=game['game_id'],**data,source=source);break
        if r is None:r=dict(game_id=game['game_id'],players=[],groups=[],parse_status='needs_source_or_parser_repair')
        r['attempts']=attempts;dump(path,r);return r
    done=[];errors=[];last=0;started=time.monotonic()
    dump(out/'progress.json',dict(state='running',at_utc=stamp(),year=args.year,completed=0,total=len(g),calendar_total=calendar_total,article_discovery_pending=calendar_total-len(g)))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures={pool.submit(one,r):r for r in g.to_dict('records')}
        for future in concurrent.futures.as_completed(futures):
            try:r=future.result()
            except Exception as exc:
                game=futures[future]
                problem=dict(game_id=game['game_id'],at_utc=stamp(),exception_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
                errors.append(problem);dump(out/'collection_errors.json',errors)
                r=dict(game_id=game['game_id'],players=[],groups=[],attempts=[],parse_status='collector_exception_requires_retry',collector_error=problem)
                # Preserve any previously recorded source response unchanged.
                record=out/(game['game_id']+'.json')
                if not record.exists():dump(record,r)
                print(json.dumps(dict(stage='collector_exception',game_id=game['game_id'],exception_type=type(exc).__name__,error=str(exc))),flush=True)
            done.append(r);pct=int(len(done)*100/len(g))//10*10
            status=dict(state='running',at_utc=stamp(),year=args.year,completed=len(done),total=len(g),calendar_total=calendar_total,article_discovery_pending=calendar_total-len(g),progress_pct=pct,
                parsed=sum(bool(x.get('source')) for x in done),needs_repair=sum(not bool(x.get('source')) for x in done),collector_errors=len(errors),elapsed_seconds=time.monotonic()-started)
            dump(out/'progress.json',status)
            if pct>last:last=pct;print(json.dumps(status),flush=True)
    manifest=[]
    for r in done:
        manifest.append(dict(game_id=r['game_id'],parsed=bool(r.get('source')),available_by_pre12=r.get('available_by_pre12'),player_entries=len(r['players']),
            source_json=json.dumps(r.get('source'),sort_keys=True),attempts_json=json.dumps(r['attempts'],sort_keys=True)))
    f=pd.DataFrame(manifest).sort_values('game_id');f.to_parquet(out/'manifest.parquet',index=False);f.to_csv(out/'manifest.csv',index=False)
    status.update(state='calendar batch acquired; repairs and identity validation pending',pre12_reports=int(f.available_by_pre12.fillna(False).sum()),player_entries=int(f.player_entries.sum()))
    dump(out/'summary.json',status);dump(out/'progress.json',status);print(json.dumps(status),flush=True)


if __name__=='__main__':main()
