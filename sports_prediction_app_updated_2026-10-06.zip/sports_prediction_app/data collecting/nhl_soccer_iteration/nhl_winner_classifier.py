"""Compare NHL's already fitted classifiers for the winner-only objective."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import log_loss,accuracy_score,brier_score_loss

from common import ROOT_OUT,REPORTS,dump,stamp,file_sha256
from backtest import quote_inputs
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine

LABEL='nhl_winner_classifier'
RESULT=ROOT_OUT/'simulation_results'/LABEL
SOURCE=ROOT_OUT/'simulation_results/feature_revisions/nhl_player_strength'


def probability_metrics(p):
    rows=[]
    for variant,g in p.groupby('variant'):
        for year,f in [('pooled',g)]+list(g.groupby(g.prediction_time.dt.year)):
            rows.append(dict(variant=variant,year=str(year),games=len(f),accuracy=accuracy_score(f.target,f[['p0','p1']].to_numpy().argmax(axis=1)),
                logloss=log_loss(f.target,f.p1),brier=brier_score_loss(f.target,f.p1)))
    return pd.DataFrame(rows)


def inputs(stage):
    p=pd.read_parquet(SOURCE/(stage+'_predictions.parquet'));p=p[p.variant.eq('candidate')].copy()
    assert p.game_id.is_unique and p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
    assert np.allclose(p.second_p0+p.second_p1,1,atol=1e-12,rtol=0)
    a=p.copy();a['variant']='goal_model'
    b=p.copy();b['variant']='logistic';b[['p0','p1']]=b[['second_p0','second_p1']].to_numpy()
    return pd.concat([a,b],ignore_index=True)


def run():
    RESULT.mkdir(exist_ok=True);assert not (RESULT/'validation.json').exists()
    plan=dict(at_utc=stamp(),
        hypothesis='The prior model preference emphasized probability logloss. The user now requires betting the predicted winner. The already fitted logistic classifier has higher pooled2024/25 winner accuracy, while the goal model has lower pooled logloss. Test the existing classifier for this revised decision objective.',
        model_gate='Logistic must have higher pooled2024/25 accuracy and no lower2025 accuracy than the goal model. Report logloss andBrier explicitly; no claim that higher accuracy proves better probability calibration.',
        stake_rules='Existing flat20,confidence5,confidence5with60percentfloor. No new thresholds, amount tuning, price filters or opposite-side purchases.',
        account_selection='Choose the highest2025Sharpe positive-return rule separately per model/provider before2026. Evaluate selected rules only, plus the already recorded goal-model controls on identical rules for attribution.',
        timing='Unchanged expanding2021+training, monthly predictions from2024, earlier-only preprocessing/calibration. Same closest-prior pre12prices at most24hoursold. Annual2000cash,hold through official settlement.',
        evaluation='2026 is repeatedly inspected retrospective research. No new base-model fit or app change; current retained models remain intact.')
    dump(RESULT/'plan.json',plan)
    development=inputs('development');s=probability_metrics(development);s.to_csv(RESULT/'development_probability_metrics.csv',index=False)
    ix=s.set_index(['variant','year'])
    model_gate=bool(ix.loc[('logistic','pooled'),'accuracy']>ix.loc[('goal_model','pooled'),'accuracy'] and
        ix.loc[('logistic','2025'),'accuracy']>=ix.loc[('goal_model','2025'),'accuracy'])
    dump(RESULT/'model_selection.json',dict(at_utc=stamp(),passed=model_gate,objective='Winner classification accuracy',used2026=False,adopted=False))
    quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    annual=[];bets=[];days=[];checks=[];choices={};hashes={}
    hashes['development_predictions.parquet']=file_sha256(SOURCE/'development_predictions.parquet')
    def accounts(p,stage):
        for variant,f in p.groupby('variant'):
            if variant=='logistic' and not model_gate:continue
            linked=transfer.normalize('nhl',f,quotes,pick_growth=False)
            for provider,g in linked.groupby('provider'):
                rules=['flat20','confidence5','confidence5_floor60'] if stage=='development' else [choices[variant,provider]]
                for rule in rules:
                    if rule is None:continue
                    h=g if rule!='confidence5_floor60' else g[g.probability.gt(.60)]
                    sizing='flat20_cash_only' if rule=='flat20' else 'dollars_cash_only'
                    selection='all_selected_outcomes' if rule=='flat20' else 'winner_above51'
                    for year in sorted(f.prediction_time.dt.year.unique()):
                        m,b,l,d=engine.simulate(h,int(year),selection,sizing,5.,2000.)
                        key=dict(sport='nhl',provider=provider,variant=variant,stake_rule=rule,year=int(year),stage=stage)
                        annual.append(key|m);checks.append(key|engine.validate(b,l,d,sizing,5.,2000.))
                        if len(b):
                            assert b.side.eq(b[['p0','p1']].to_numpy().argmax(axis=1)).all()
                            bets.append(b.assign(**key))
                        days.append(d.assign(**key))
    accounts(development,'development')
    a=pd.DataFrame(annual)
    for (variant,provider),g in a[a.year.eq(2025)].groupby(['variant','provider']):
        ranked=g[g.return_pct.gt(0)].sort_values(['sharpe','stake_rule'],ascending=[False,True])
        choices[variant,provider]=None if not len(ranked) else str(ranked.iloc[0].stake_rule)
    dump(RESULT/'stake_selection.json',dict(at_utc=stamp(),choices=[dict(variant=k[0],provider=k[1],stake_rule=v) for k,v in choices.items()],used2026=False,adopted=False))
    evaluation=inputs('evaluation');probability_metrics(evaluation).to_csv(RESULT/'evaluation_probability_metrics.csv',index=False)
    hashes['evaluation_predictions.parquet']=file_sha256(SOURCE/'evaluation_predictions.parquet')
    accounts(evaluation,'evaluation')
    a=pd.DataFrame(annual)
    # Replay the unchanged goal-model controls against previously published
    # winner-only accounts rather than accepting a plausible-looking result.
    reference=pd.read_csv(ROOT_OUT/'simulation_results/winner_stake_sizing/winner_annual.csv')
    reference=reference[reference.sport.eq('nhl')].set_index(['provider','stake_rule','year'])
    plain=a[a.variant.eq('goal_model')&a.stake_rule.ne('confidence5_floor60')].set_index(['provider','stake_rule','year'])
    floor=pd.read_csv(ROOT_OUT/'simulation_results/winner_risk_revision/floor_annual.csv')
    floor=floor[floor.sport.eq('nhl')&floor.variant.eq('development_floor')].set_index(['provider','year'])
    control=a[a.variant.eq('goal_model')&a.stake_rule.eq('confidence5_floor60')].set_index(['provider','year'])
    for c in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
        assert np.allclose(plain[c],reference.loc[plain.index,c],rtol=0,atol=1e-9,equal_nan=True)
        assert np.allclose(control[c],floor.loc[control.index,c],rtol=0,atol=1e-9,equal_nan=True)
    a.to_csv(RESULT/'annual.csv',index=False);pd.concat(bets).to_parquet(RESULT/'bets.parquet',index=False);pd.concat(days).to_parquet(RESULT/'daily.parquet',index=False)
    for name,sha in hashes.items():assert file_sha256(SOURCE/name)==sha
    proof=dict(status='PASS',at_utc=stamp(),source_hashes=hashes,checks=checks,original_controls_replayed=True,
        model_gate=model_gate,every_bet_is_its_model_argmax=True,no_base_model_refit=True,app_changed=False,adopted=False)
    dump(RESULT/'validation.json',proof)
    def table(f):
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in f.itertuples(index=False,name=None)])
    cols=['provider','variant','stake_rule','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']
    lines=['# NHL predicted-winner classifier comparison','',plan['hypothesis'],'',plan['model_gate'],'',table(s),'',
        plan['stake_rules'],'',plan['account_selection'],'',table(a[cols]),'',table(pd.read_csv(RESULT/'evaluation_probability_metrics.csv')),'',
        'Model-choice and stake-choice receipts are saved before evaluation. Classification accuracy is distinct from conditional funded-bet accuracy and from probability calibration. The existing two models are compared without retraining or changing historical inputs. Every purchased outcome is that model\'s full-class argmax before quotes are examined.','',
        'Accounting: annual $2,000, no borrowing or early reuse of settlements, no added costs. Calendar-day Sharpe includes idle days with sqrt(365.25) annualization; open positions carried at cost. Polymarket observations are historical international token prices, not established US executable asks; Kalshi retains YES ask closes.','',plan['evaluation'],'','Reproduce nhl_winner_classifier.py.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL]=dict(plan=plan,validation=proof,stake_selection=json.loads((RESULT/'stake_selection.json').read_bytes()));dump(path,d)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(a[cols].to_string(index=False),flush=True);print(pd.read_csv(RESULT/'evaluation_probability_metrics.csv').to_string(index=False),flush=True)


def market_agreement():
    """Require a greater-than-half market price on the unchanged model winner."""
    assert (RESULT/'validation.json').exists() and not (RESULT/'agreement_validation.json').exists()
    plan=dict(at_utc=stamp(),
        diagnosis='The price-discount entry study excludes377profitable2025winner bets while lower-priced model winners are less reliable. Test agreement rather than a discount: the existing model confidence exceeds60%, and the same outcome\'s price must exceed50%.',
        threshold='50% is the structural binary majority boundary, not an optimized threshold. This does not claim the two token prices were observed synchronously or that price equals executable probability.',
        invariant='Original logistic argmax; existing confidence5stake andpre12 entry. No side substitution, model refit, or probability/amount search.',
        gate='Higher2025Sharpe and positive return versus the same model/confidence-floor control. Save provider choices before2026. Report2024anddrawdown separately.',
        evaluation='2026 repeatedly inspected retrospective research; no fresh holdout claim.',app_changed=False)
    dump(RESULT/'agreement_plan.json',plan)
    quotes=quote_inputs(RESULT/'agreement_quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    rows=[];positions=[];days=[];checks=[];choices={}
    for stage in ['development','evaluation']:
        p=inputs(stage);p=p[p.variant.eq('logistic')]
        f=transfer.normalize('nhl',p,quotes,pick_growth=False);f=f[f.probability.gt(.60)]
        for provider,g in f.groupby('provider'):
            if stage=='evaluation' and not choices.get(provider,False):continue
            for variant in ['floor_control','market_agreement']:
                h=g if variant=='floor_control' else g[g.price.gt(.5)]
                for year in sorted(p.prediction_time.dt.year.unique()):
                    m,b,l,d=engine.simulate(h,int(year),'all_selected_outcomes','dollars_cash_only',5.,2000.)
                    key=dict(sport='nhl',provider=provider,variant=variant,year=int(year),stage=stage)
                    rows.append(key|m);checks.append(key|engine.validate(b,l,d,'dollars_cash_only',5.,2000.))
                    if len(b):
                        assert b.side.eq(b[['p0','p1']].to_numpy().argmax(axis=1)).all()
                        if variant=='market_agreement':assert b.price.gt(.5).all()
                        positions.append(b.assign(**key))
                    days.append(d.assign(**key))
        if stage=='development':
            for provider,g in pd.DataFrame(rows).groupby('provider'):
                ix=g.set_index(['variant','year']);a,b=ix.loc[('market_agreement',2025)],ix.loc[('floor_control',2025)]
                choices[provider]=bool(a.sharpe>b.sharpe and a.return_pct>0)
            dump(RESULT/'agreement_selection.json',dict(at_utc=stamp(),choices=choices,used2026=False,adopted=False))
    a=pd.DataFrame(rows);a.to_csv(RESULT/'agreement_annual.csv',index=False)
    pd.concat(positions).to_parquet(RESULT/'agreement_bets.parquet',index=False);pd.concat(days).to_parquet(RESULT/'agreement_daily.parquet',index=False)
    old=pd.read_csv(RESULT/'annual.csv');old=old[old.variant.eq('logistic')&old.stake_rule.eq('confidence5_floor60')].set_index(['provider','year'])
    control=a[a.variant.eq('floor_control')].set_index(['provider','year']);common=control.index.intersection(old.index)
    for c in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
        assert np.allclose(control.loc[common,c],old.loc[common,c],rtol=0,atol=1e-9,equal_nan=True)
    proof=dict(status='PASS',at_utc=stamp(),checks=checks,available_baselines_replayed=True,all_bets_are_model_argmax=True,app_changed=False,adopted=False)
    dump(RESULT/'agreement_validation.json',proof)
    cols=['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']
    table='\n'.join(['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']+['| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in a[cols].itertuples(index=False,name=None)])
    with (REPORTS/(LABEL+'.md')).open('a',encoding='utf8') as out:out.write('\nMarket-agreement follow-up: '+plan['diagnosis']+' '+plan['threshold']+' '+plan['gate']+'\n\n'+table+'\n')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';d=pd.read_csv(path,low_memory=False);key=LABEL+'/agreement_annual.csv'
    pd.concat([d[d.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL+'/market_agreement']=dict(plan=plan,selection=json.loads((RESULT/'agreement_selection.json').read_bytes()),validation=proof);dump(path,d)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(a[cols].to_string(index=False),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',nargs='?',choices=['run','market_agreement'],default='run')
    globals()[p.parse_args().stage]()
