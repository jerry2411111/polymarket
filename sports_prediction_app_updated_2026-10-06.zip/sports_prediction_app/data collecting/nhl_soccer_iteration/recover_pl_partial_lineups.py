"""Acquire player statistics for real fixtures rejected by a lineup-only parser.

Separate storage keeps the v26 input snapshot immutable. A lineup containing
twelve position-labelled players is not enough reason to discard all stats.
Actual starter/appearance reconciliation follows acquisition; no flags guessed.
"""
import collections
import concurrent.futures
import json
import sqlite3

from common import ROOT_OUT,OfficialClient,dump,stamp
from collect_players import BASE,parse
from pl_sparse_statistics import RUN,load,original

DB=ROOT_OUT/'pl_lineup_recovery.sqlite'


def main():
    games,_,sources=load()
    issues=json.loads((RUN/'pl_count_issues.json').read_bytes())
    wanted={r['game_id'] for r in issues if r.get('observed_starters')==0}
    tasks=[];links=[]
    for gid in sorted(wanted):
        g=games[gid];url='https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v3/matches/'+str(g['official_game_id'])+'/lineups'
        body,path=original(sources[url]);links.append(dict(game_id=gid,source=sources[url],raw_file=path))
        for side,key,native in zip(['A','B'],['away_team','home_team'],json.loads(g['native_team_ids_json'])):
            team=body[key];assert str(team['teamId'])==str(native)
            assert len({str(p['id']) for p in team['players']})==len(team['players'])
            for p in team['players']:
                tasks.append(dict(game_id=gid,official_game_id=g['official_game_id'],player_id=str(p['id']),
                    player_name=p.get('knownName') or ' '.join(str(p.get(k,'')) for k in ['firstName','lastName']),
                    team_id=str(native),side=side,league='Premier League',date=g['date'],available_at_utc=g['available_time']))
    db=sqlite3.connect(DB,timeout=60)
    db.executescript('CREATE TABLE IF NOT EXISTS player_match_detail(game_id TEXT,player_id TEXT,body TEXT NOT NULL,PRIMARY KEY(game_id,player_id)); CREATE TABLE IF NOT EXISTS issues(game_id TEXT,player_id TEXT,body TEXT NOT NULL,PRIMARY KEY(game_id,player_id));')
    done=set(db.execute('SELECT game_id,player_id FROM player_match_detail'))
    tasks=[t for t in tasks if (t['game_id'],t['player_id']) not in done]
    client=OfficialClient(4);counts=collections.Counter();mark=10
    def fetch(t):
        body,source=client.get(BASE+str(t['official_game_id'])+'/players/'+str(t['player_id'])+'/stats',
            'Recover player statistics despite historical lineup-count anomaly: '+t['game_id']+' player '+t['player_id'],
            'official_player_statistics')
        try:
            assert body is not None,'HTTP '+source['return_status']
            return t,parse(body,t,source),None
        except (AssertionError,KeyError,ValueError,TypeError) as e:
            return t,None,dict(reason=str(e),source=source,task=t)
    print(json.dumps(dict(stage='partial_lineup_recovery',games=len(wanted),tasks=len(tasks))),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for n,(t,row,issue) in enumerate(pool.map(fetch,tasks),1):
            with db:
                if row:
                    db.execute('INSERT OR REPLACE INTO player_match_detail VALUES (?,?,?)',(t['game_id'],t['player_id'],json.dumps(row)))
                    db.execute('DELETE FROM issues WHERE game_id=? AND player_id=?',(t['game_id'],t['player_id']));counts['acquired']+=1
                else:
                    db.execute('INSERT OR REPLACE INTO issues VALUES (?,?,?)',(t['game_id'],t['player_id'],json.dumps(issue)));counts['requires_reconciliation']+=1
            if n*100>=mark*len(tasks) or n==len(tasks):
                progress=dict(at_utc=stamp(),stage='partial_lineup_recovery',processed=n,total=len(tasks),percent=round(n*100/len(tasks),1),counts=dict(counts))
                dump(ROOT_OUT/'pl_lineup_recovery_progress.json',progress);print(json.dumps(progress),flush=True);mark+=10
    dump(ROOT_OUT/'pl_lineup_recovery_sources.json',links);db.close()


if __name__=='__main__':main()
