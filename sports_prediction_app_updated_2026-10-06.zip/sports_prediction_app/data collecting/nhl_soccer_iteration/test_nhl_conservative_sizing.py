"""One fixed sizing ablation on retained NHL forecasts and corrected prices.

Keep the same selected outcomes. Cap quarter-Kelly at the baseline1% position,
using the smaller of the two model probabilities without an extra margin.
"""
import argparse,json
import numpy as np
import pandas as pd
from common import ROOT_OUT,dump,stamp
from final_pipeline import predictions
from backtest import quote_inputs,attach,select,simulate
from cash_validation import validate_cash

DEST=ROOT_OUT/'simulation_results/nhl_conservative_sizing'
RECIPE='conservative_quarter_kelly'


def verify_risk_stakes(trades):
    """Reconstruct pre-entry NAV and variance from the two payout states."""
    checked=0
    for _,t in trades[trades.recipe.eq('capped_equal_risk')].groupby(['provider','year']):
        for at,rows in t.groupby('decision_time'):
            prior=t[t.decision_time.lt(at)]
            paid=prior[prior.settlement_time.le(at)]
            cash=10000-prior.stake.sum()+paid.payout.sum()
            opened=prior[prior.settlement_time.gt(at)].stake.sum();nav=cash+opened
            p=rows.probability.to_numpy();q=rows.price.to_numpy()
            mean=p/q-1
            variance=p*(1/q-1-mean)**2+(1-p)*(-1-mean)**2
            wanted=.01*nav*np.minimum(1,1/np.sqrt(np.maximum(variance,1e-24)))
            room=max(0,min(cash,.20*nav-opened));scale=min(1,room/wanted.sum())
            assert np.allclose(rows.stake.to_numpy(),wanted*scale,rtol=0,atol=1e-7)
            checked+=len(rows)
    return checked


def evaluate(stage,quotes):
    p=predictions('nhl',stage);joined,audit=attach(p,quotes);dump(DEST/(stage+'_matching.json'),audit)
    annual=[];trades=[];curves=[]
    for provider,group in joined.groupby('provider'):
        f=select(group,'expected_profit')
        secondary=np.where(f.quote_class.eq(0),f.second_p0,f.second_p1)
        f=f[secondary/f.entry_price>=1.10].copy()
        f['sizing_probability']=np.minimum(f.probability,np.where(f.quote_class.eq(0),f.second_p0,f.second_p1))
        for recipe in ['fixed',RECIPE]:
            for year in ([2024,2025] if stage=='development' else [2026]):
                sizing={'fixed':'fixed','conservative_quarter_kelly':'margin_quarter_kelly','capped_equal_risk':'capped_equal_risk'}[recipe]
                summary,t,c=simulate(f,year,sizing=sizing)
                meta=dict(sport='nhl',provider=provider,recipe=recipe,year=year);annual.append(meta|summary)
                if len(t):trades.append(t.assign(**meta))
                curves.append(c.assign(**meta))
    a=pd.DataFrame(annual);t=pd.concat(trades,ignore_index=True);c=pd.concat(curves,ignore_index=True)
    checked=validate_cash(t,c)
    if RECIPE=='capped_equal_risk':
        stake_checks=verify_risk_stakes(t)
        dump(DEST/(stage+'_stake_validation.json'),dict(status='PASS',at_utc=stamp(),independently_replayed_stakes=stake_checks,
            method='Reconstruct each pre-entry NAV and calculate variance directly over win/loss payoff states.'))
    baseline=pd.read_csv(ROOT_OUT/'simulation_results/current/annual.csv')
    baseline=baseline[baseline.sport.eq('nhl')&baseline.recipe.eq('fixed')].set_index(['provider','year'])
    for row in a[a.recipe.eq('fixed')].itertuples():
        expected=baseline.loc[(row.provider,row.year)]
        assert row.bets==expected.bets
        for name in ['return_pct','sharpe','max_drawdown_pct']:
            assert np.isclose(getattr(row,name),expected[name],rtol=0,atol=1e-8,equal_nan=True)
    a.to_csv(DEST/(stage+'_annual.csv'),index=False);t.to_parquet(DEST/(stage+'_bets.parquet'),index=False);c.to_parquet(DEST/(stage+'_daily.parquet'),index=False)
    return a,checked


def main():
    DEST.mkdir(exist_ok=True)
    plan=dict(at_utc=stamp(),hypothesis='Keep the same forecast-qualified outcomes, but reduce the capital given to a weak estimated edge; no new entry threshold or probability fit.',
        formula='stake/NAV = min(0.01, 0.25*(min(primary_p,secondary_p)-price)/(1-price))',
        baseline='Fixed1% NAV; both forecast p/price>=1.10; closest-prior pre12 quote age<=24h;20%aggregate open-cost cap; annual$10000reset; holdofficialsettlement; no costs; providers separate.',
        distinction='Earlier v19 allowed12.5% Kelly positions and used old quotes; v76 divided the conservative probability by1.10 before sizing. This test keeps the corrected quotes, caps positions at1%, and adds no second margin.',
        gate='Candidate must improve minimum2024/2025Polymarket annualSharpe AND mean annualreturn, with at least30bets peryear, before evaluating2026. No sweep.2024pricecoverage onlyDec5-Dec31.',
        limitation='2026has been repeatedly researched; any evaluation is retrospective. Sizing cannot create forecasting information.')
    dump(DEST/'plan.json',plan)
    if RECIPE=='capped_equal_risk':
        plan.update(hypothesis='Selected outcomes have different binary payoff variance. Equalize estimated per-bet risk subject to the existing1%stake cap; keep model, entry rule and outcome selection unchanged.',
            formula='stake/NAV = 0.01 * min(1, price/sqrt(primary_p*(1-primary_p))); aggregate open-cost cap20% remains.',
            distinction='No fitted parameter or new entry threshold. Use the primary retained forecast for variance. Risk budget is the existing1%equity stake. Zero variance uses the capped limiting value.',
            limitation='Model-implied variance need not equal realized risk; correlations are not modeled. No claim of guaranteed Sharpe improvement. 2026 remains retrospective.')
        dump(DEST/'plan.json',plan)
    quotes=quote_inputs(DEST/'quote_quality.json',revision='closest_v62')
    annual,days=evaluate('development',quotes)
    values={}
    for recipe,g in annual[annual.provider.eq('polymarket')].groupby('recipe'):
        values[recipe]=dict(minimum_sharpe=float(g.sharpe.min()),mean_return=float(g.return_pct.mean()),minimum_bets=int(g.bets.min()))
    candidate,base=values[RECIPE],values['fixed']
    passed=candidate['minimum_sharpe']>base['minimum_sharpe'] and candidate['mean_return']>base['mean_return'] and candidate['minimum_bets']>=30
    if passed:
        extra,n=evaluate('evaluation',quotes);annual=pd.concat([annual,extra],ignore_index=True);days+=n
    dump(DEST/'validation.json',dict(status='PASS',at_utc=stamp(),passed_pre2026_gate=bool(passed),comparison=values,independent_cash_days=days,evaluated2026=bool(passed),goal_achieved=False))
    print(json.dumps(dict(passed_pre2026_gate=bool(passed),independent_cash_days=days)),flush=True)
    print(annual[['provider','recipe','year','bets','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    # Consolidate the outcome without retaining a trial model or feature copy.
    decisions_path=ROOT_OUT/'simulation_results/experiment_decisions.json'
    decisions=json.loads(decisions_path.read_bytes())
    decisions[str(DEST.relative_to(ROOT_OUT/'simulation_results'))+'/plan.json']=plan
    decisions[str(DEST.relative_to(ROOT_OUT/'simulation_results'))+'/validation.json']=json.loads((DEST/'validation.json').read_bytes())
    dump(decisions_path,decisions)
    ledger_path=ROOT_OUT/'simulation_results/experiment_results.csv'
    ledger=pd.read_csv(ledger_path,low_memory=False)
    for stage in ['development']+(['evaluation'] if passed else []):
        path=DEST/(stage+'_annual.csv')
        key=str(path.relative_to(ROOT_OUT/'simulation_results')).replace('\\','/')
        ledger=ledger[~ledger.source_result_file.eq(key)]
        ledger=pd.concat([ledger,pd.read_csv(path).assign(source_result_file=key,stage=stage)],ignore_index=True)
    ledger.to_csv(ledger_path,index=False)
    from final_pipeline import cleanup
    cleanup()


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--recipe',choices=['conservative_quarter_kelly','capped_equal_risk'],default=RECIPE);args=p.parse_args()
    RECIPE=args.recipe
    if RECIPE=='capped_equal_risk':DEST=ROOT_OUT/'simulation_results/nhl_equal_risk'
    main()
