"""Recover La Liga starting-keeper observations from dated official club data.

The role is derived from the official client's supported formation grids, then
corroborated against explicit G roles on the same dated Opta identities. Never
infer a substitute's position from saves or a current biography.
"""
import collections
import hashlib
import json
import re

import pandas as pd

from common import ROOT_OUT, PROJECT, read_db, dump, stamp, file_sha256

FOLDER=ROOT_OUT/'soccer_keeper_v81/laliga'


def definition():
    references=json.loads((FOLDER/'maker_client_evidence.json').read_bytes())
    source=next(r['source'] for r in references if '/8168.' in r['source']['url'])
    raw=(PROJECT/source['raw_file']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==source['sha256']
    text=raw.decode('utf8')
    assert 'gridArea:`n${n?.formationPlace||e+1}`' in text
    grids={name:json.loads(value) for name,value in re.findall(r'(\d+):P\((\[[^\]]+\])\)',text)}
    assert grids
    for name,grid in grids.items():
        cells=[line.split() for line in grid]
        positions=[(i,j) for i,line in enumerate(cells) for j,c in enumerate(line) if c=='n1']
        assert positions and all(j==0 for i,j in positions),(name,positions)
        assert all(c in ['.','n1'] for line in cells for c in line[:1])
        assert {c for line in cells for c in line if c!='.'}=={'n'+str(i) for i in range(1,12)}
    return source,grids


def recover(existing):
    source,grids=definition()
    with read_db(ROOT_OUT/'laliga_maker.sqlite') as db:
        records=[json.loads(b) for b, in db.execute('SELECT body FROM fixtures ORDER BY game_id')]
    checked=json.loads((ROOT_OUT/'laliga_maker_validation.json').read_bytes())
    assert checked['status']=='PASS'
    assert set(checked['validated_game_ids'])=={r['game_id'] for r in records}
    covered={(r['game_id'],r['side']) for r in existing if r['league']=='La Liga'}
    known={(r['game_id'],r['side'],r['official_player_id']):r for r in existing if r['league']=='La Liga'}
    links=collections.defaultdict(dict)
    for game in records:
        for p in game['players']:
            if p['opta_player_id']:
                links[p['maker_player_id']][p['opta_player_id']]=dict(source=p['source'],lineup_pointer=p['lineup_pointer'],
                    maker_player_id=p['maker_player_id'],opta_player_id=p['opta_player_id'])
    assert all(len(values)==1 for values in links.values())
    output=[];issues=[];corroboration=[];checked_games=0
    for game in records:
        metadata=game['match'];raw_source=game['source']
        blob=(PROJECT/raw_source['raw_file']).read_bytes()
        assert hashlib.sha256(blob).hexdigest()==raw_source['sha256']
        raw=json.loads(blob);native=raw['game'];checked_games+=1
        assert native['id']==metadata['maker_game_id']
        assert pd.Timestamp(native['time'])==pd.Timestamp(metadata['start_time'])
        assert [native['awayScore'],native['homeScore']]==[metadata['scoreA'],metadata['scoreB']]
        for side,prefix in [('A','away'),('B','home')]:
            lineup=raw['lineups'][prefix+'Team']
            candidates=[(i,p) for i,p in enumerate(lineup) if p.get('starting') and not p.get('manager') and p.get('formationPlace')==1]
            assert len(candidates)==1,(game['game_id'],side,'ambiguous starting goalkeeper formation slot')
            i,person=candidates[0];pid=person['player']['id']
            stored=next(p for p in game['players'] if p['side']==side and p['maker_player_id']==pid)
            link=next(iter(links[pid].values())) if pid in links else None
            opta=link['opta_player_id'] if link else None
            key=(game['game_id'],side,opta)
            if key in known:
                role=json.loads(known[key]['role_evidence_json'])
                assert role['raw_value']=='G' and '/lineup/' in role['pointer']
                corroboration.append(dict(game_id=game['game_id'],side=side,maker_player_id=pid,opta_player_id=opta,
                    formation_source=raw_source,explicit_role_source=role['source'],explicit_role_pointer=role['pointer']))
            if (game['game_id'],side) in covered:continue
            formation=native[prefix+'Formation']
            if formation not in grids:
                issues.append(dict(game_id=game['game_id'],side=side,reason='Formation has no supported official grid',formation=formation));continue
            assert native[prefix+'Team']['id']==metadata['fixture'][prefix+'Team']['id']
            stat=stored['raw_stats'];minutes=stat.get('minsPlayed')
            if minutes is None or minutes<=0:
                issues.append(dict(game_id=game['game_id'],side=side,maker_player_id=pid,reason='Starting role known but official minutes not reported',source=raw_source));continue
            assert minutes<=110 and stored['source_pointer']
            values={f:stat.get(field) for f,field in [('saves','saves'),('goals_conceded','goalsConceded'),('keeper_xgot_conceded','expectedGoalsOnTargetConceded')]}
            assert all(v is None or v>=0 for v in values.values())
            role=dict(source=raw_source,pointer=stored['lineup_pointer']+'/formationPlace',raw_value=1,
                role_basis='Starting slot1 occupies goalkeeper position in this supported official formation grid',
                definition_source=source,formation=formation,formation_grid=grids[formation],
                maker_player_id=pid,maker_game_id=native['id'],maker_team_id=native[prefix+'Team']['id'],
                verified_start_utc=metadata['start_time'],fixture_index_source=metadata['index_source'],
                identity_link=link,source_provider='Elche CF / La Liga Maker official club API')
            evidence={f:dict(pointer=stored['source_pointer']+'/'+field,raw_value=values[f],basis='reported' if field in stat else 'not reported')
                for f,field in [('saves','saves'),('goals_conceded','goalsConceded'),('keeper_xgot_conceded','expectedGoalsOnTargetConceded')]}
            output.append(dict(game_id=game['game_id'],official_game_id=metadata['official_game_id'],league='La Liga',date=metadata['date'],
                side=side,team_id=metadata['team'+side+'_id'],official_player_id=opta or pid,
                id_namespace='opta_player_asset' if opta else 'laliga_maker_uuid',player_name=person['player']['name'],
                available_at_utc=metadata['available_at_utc'],minutes=minutes,source=raw_source,
                role_evidence=role,field_evidence=evidence,**values))
    assert len(corroboration)>=500,'Insufficient independent dated role evidence'
    assert not pd.DataFrame(output).duplicated(['game_id','side','official_player_id']).any()
    dump(FOLDER/'maker_role_validation.json',dict(at_utc=stamp(),status='PASS',derived_not_literal_role=True,
        definition_source=source,supported_formations=len(grids),source_games_checked=checked_games,
        dated_explicit_G_matches=len(corroboration),corroboration=corroboration,recovered_rows=len(output),
        unresolved_rows=issues,source_database_sha256=file_sha256(ROOT_OUT/'laliga_maker.sqlite'),
        current_biographies_used=False,role_inferred_from_saves=False))
    print(json.dumps(dict(stage='maker_keeper_recovery',recovered_rows=len(output),
        dated_role_agreements=len(corroboration),unresolved=len(issues))),flush=True)
    return output
