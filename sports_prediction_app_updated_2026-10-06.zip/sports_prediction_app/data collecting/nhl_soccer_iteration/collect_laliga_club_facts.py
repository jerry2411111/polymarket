"""Raw-first official club archive facts; historical affiliation is from lineups."""
import argparse,collections,concurrent.futures,datetime as dt,json,sqlite3
from common import ROOT_OUT,OfficialClient,read_db,dump,stamp
from laliga_club_archive import BASE,games,sid
from soccer_additional_facts import LIGUE_FIELDS

VERSION=4

def raw_stats(rows):
    result={}
    for r in rows:
        assert r['name'] not in result,'Duplicate source statistic'
        v=r.get('value');assert v is None or isinstance(v,(int,float))
        result[r['name']]=v
    return result

def parse(g,index,fixture,stats,fs,ss,commentary=None,comment_source=None,corrections=None):
    assert sid(fixture['id'])==index['club_fixture_id']==sid(stats['entity']['id'])
    assert fixture['status']=='C' and fixture['phase']=='F'
    assert not fixture.get('extraTime') and not fixture.get('shootout')
    assert fixture['altIds']['opta']==index['opta_match_id']
    assert dt.datetime.fromtimestamp(fixture['kickoff']['millis']/1000,dt.UTC)==dt.datetime.fromisoformat(g['timestamp'])
    assert [sid(x['team']['id']) for x in fixture['teams']]==[index['club_home_id'],index['club_away_id']]
    assert [x['score'] for x in fixture['teams']]==[g['scoreB'],g['scoreA']]
    assert [x['score'] for x in stats['entity']['teams']]==[g['scoreB'],g['scoreA']]
    side_ids={index['club_home_id']:'B',index['club_away_id']:'A'}
    native=dict(zip(['A','B'],json.loads(g['native_team_ids_json'])))
    players=[];teams=[];byid={};issues=[]
    assert {sid(x['teamId']) for x in fixture['teamLists']}==set(side_ids)
    for li in fixture['teamLists']:
        team=sid(li['teamId']);side=side_ids[team]
        common=dict(game_id=g['game_id'],official_game_id=g['official_game_id'],league='La Liga',date=g['date'],available_at_utc=g['available_time'],side=side,team_id=native[side],club_team_id=team,club_fixture_id=index['club_fixture_id'])
        assert len(li['lineup'])==11
        for group in ['lineup','substitutes']:
            for person in li[group]:
                pid=sid(person['id']);opta=person['altIds']['opta'];assert opta.startswith('p') and opta[1:].isdigit()
                assert pid not in byid and not any(r['official_player_id']==opta for r in players)
                row=common|dict(official_player_id=opta,club_player_id=pid,id_namespace='opta_player_asset',player_name=person['name']['display'],position=person.get('matchPosition'),started=group=='lineup',played=True if group=='lineup' else None,minutes=None,goals=None,assists=None,own_goals=None,
                    minutes_basis='Official club event clock, regulation only, excludes half stoppage time.',source=fs,lineup_pointer=f'/teamLists/{len(teams)}/{group}',source_class='official_club_API',source_provider='FC Barcelona / Opta')
                byid[pid]=row;players.append(row)
        raw=raw_stats(stats['data'].get(team,{}).get('M',[]))
        assert raw,'Team full-match statistics absent'
        teams.append(common|{k:raw.get(v) for k,v in LIGUE_FIELDS.items()}|dict(possession_pct=raw.get('possession_percentage'),raw_stats=raw,source=ss,source_class='official_club_API',source_provider='FC Barcelona / Opta'))
    events=fixture['events'];phases={(str(e.get('phase')),e.get('type')) for e in events}
    corrections=corrections or {}
    # A final result alone cannot establish a complete transition feed.
    complete=all((p,k) in phases for p in ['1','2'] for k in ['PS','PE'])
    if not complete:issues.append(dict(field='minutes',reason='Missing regulation phase boundary in official event feed'))
    counted=collections.Counter();goals=collections.Counter();assists=collections.Counter();own=collections.Counter();assist_complete=True;goal_complete=True
    previous={'A':0,'B':0};subs=collections.defaultdict(list);reds=[];excluded=[];departures={}
    if commentary is not None:
        assert sid(commentary['fixture']['id'])==index['club_fixture_id']
        assert commentary['events']['pageInfo']['numPages']<=1
        for e in commentary['events']['content']:
            if e.get('type')=='player retired' and 'had used all subs' in e.get('text',''):
                assert len(e.get('playerIds',[]))==1
                departures[sid(e['playerIds'][0])]=e
    for i,e in enumerate(events):
        phase=str(e.get('phase'))
        if phase not in ['1','2']:continue
        typ=e['type'];desc=e.get('description');pid=sid(e['personId']) if e.get('personId') is not None else None
        try:
            if typ in ['G','O','P']:
                assert pid in byid,'Goal actor not in dated lineup'
                now={'A':e['score']['awayScore'],'B':e['score']['homeScore']};changes={s:now[s]-previous[s] for s in ['A','B']}
                winners=[s for s in ['A','B'] if changes[s]==1];assert len(winners)==1 and sum(changes.values())==1 and min(changes.values())==0,'Non-unit goal score transition'
                side=winners[0];counted[side]+=1;previous=now
                if byid[pid]['side']==side:
                    assert typ!='O';goals[pid]+=1
                    if 'assistId' not in e:assist_complete=False
                    elif e['assistId'] is not None:
                        aid=sid(e['assistId']);assert aid in byid and byid[aid]['side']==side;assists[aid]+=1
                else:assert typ=='O';own[pid]+=1
            elif typ=='S':
                assert desc in ['ON','OFF'] and (pid in byid or (pid is None and desc=='ON'))
                subs[(str(e['id']),phase,sid(e['teamId']))].append((i,e))
            elif typ=='B' and desc in ['R','YR']:
                if pid not in byid:
                    eid=str(e['id']);fix=corrections.get(eid)
                    if fix:
                        assert sid(e['teamId'])==fix['club_team_id'] and e['clock']['secs']==fix['clock_secs']
                        excluded.append(dict(event=i,reason=fix['reason'],evidence=fix))
                    elif phase=='2' and e['clock']['secs']>=5400:
                        excluded.append(dict(event=i,reason='Unidentified dismissal at or after regulation minute 90; zero remaining regulation minutes. Actor identity is unresolved.'))
                    else:
                        issues.append(dict(field='minutes',event=i,reason='Dismissed actor not in dated player lineup; staff identity needs evidence'));complete=False
                else:reds.append((i,e))
        except (AssertionError,KeyError,ValueError) as exc:
            issues.append(dict(field='goals' if typ in ['G','O','P'] else 'minutes',event=i,reason=str(exc)))
            if typ in ['G','O','P']:goal_complete=False;assist_complete=False
            else:complete=False
    goal_complete=goal_complete and all(counted[s]==g['score'+s] for s in ['A','B'])
    if not goal_complete:issues.append(dict(field='goals',reason='Event goals do not reconcile with official score',counted=dict(counted)))
    def when(e):
        s=e['clock']['secs'];assert isinstance(s,(int,float)) and s>=0
        if str(e['phase'])=='1':return min(s,2700.)/60
        assert s>=2700;return min(s,5400.)/60
    transitions=[]
    try:
        for key,pair in subs.items():
            assert len(pair)==2 and {e['description'] for _,e in pair}=={'ON','OFF'},'Unpaired substitution'
            on=next(e for _,e in pair if e['description']=='ON');off=next(e for _,e in pair if e['description']=='OFF')
            offid=sid(off['personId']);assert when(on)==when(off)
            if on.get('personId') is None:
                assert offid in departures,'Missing incoming actor requires explicit injury-with-no-substitute evidence'
                comment=departures[offid];assert abs(comment['time']['secs']-off['clock']['secs'])<=60
                transitions.append((when(off),min(i for i,_ in pair),'injury_departure',offid,None))
            else:
                onid=sid(on['personId']);assert byid[onid]['side']==byid[offid]['side']
                transitions.append((when(on),min(i for i,_ in pair),'sub',offid,onid))
        for i,e in reds:transitions.append((when(e),i,'red',sid(e['personId']),None))
        active={p:0. for p,r in byid.items() if r['started']};played=set(active);minutes=collections.Counter();lost=collections.Counter()
        for at,i,kind,off,on in sorted(transitions):
            if kind=='red' and off not in active:
                excluded.append(dict(event=i,reason='Dated roster player is not active on pitch; bench dismissal'));continue
            assert off in active and (on is None or on not in played),'Contradictory active-player transition'
            assert at>=active[off];minutes[off]+=at-active.pop(off)
            if on:active[on]=at;played.add(on)
            else:lost[byid[off]['side']]+=90-at
        for pid,at in active.items():minutes[pid]+=90-at
        for side in ['A','B']:
            assert abs(sum(minutes[p] for p,r in byid.items() if r['side']==side)-(990-lost[side]))<1e-6
        assert all(0<=m<=90 for m in minutes.values())
    except (AssertionError,KeyError,ValueError) as exc:complete=False;issues.append(dict(field='minutes',reason=str(exc)))
    for pid,r in byid.items():
        if complete:r['played']=pid in played;r['minutes']=float(minutes[pid])
        if goal_complete:r['goals']=goals[pid];r['own_goals']=own[pid]
        if goal_complete and assist_complete:r['assists']=assists[pid]
    for r in players:
        r['available_at_utc']=max([r['available_at_utc']]+[v['available_at_utc'] for v in corrections.values()])
    return dict(game_id=g['game_id'],official_game_id=g['official_game_id'],league='La Liga',date=g['date'],players=players,teams=teams,issues=issues,excluded_staff_events=excluded,minutes_complete=complete,goal_counts_reconcile=goal_complete,sources=[fs,ss]+([comment_source] if comment_source else [])+[v['source'] for v in corrections.values()],club_archive_index=index,parser_version=VERSION,parser='official_club_pulse',source_class='official_club_API',confirmed_injury_departures=departures,corrections=corrections,caveat='Club API republishes Opta facts. Original raw responses retained. Missing statistics are not converted to zero. Derived goals require complete score reconciliation; derived minutes require phase, transition and team-minute reconciliation.')

def connect():
    c=sqlite3.connect(ROOT_OUT/'laliga_club.sqlite',timeout=60)
    c.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT NOT NULL);CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,body TEXT NOT NULL);')
    return c

def run(all_games=False,limit=3,workers=4):
    index=json.loads((ROOT_OUT/'laliga_club_archive_index.json').read_text());wanted=games();db=connect();done={r[0] for r in db.execute('SELECT game_id FROM games')}
    with read_db(ROOT_OUT/'soccer_additional.sqlite') as c:existing={r[0] for r in c.execute("SELECT game_id FROM games WHERE league='La Liga'")}
    tasks=[m for m in index['matches'] if '49' in [m['club_home_id'],m['club_away_id']] and m['game_id'] not in done and (all_games or m['game_id'] not in existing)]
    tasks.sort(key=lambda m:(m['date'],m['game_id']))
    if limit and tasks:tasks=[tasks[i] for i in sorted(set(round(i*(len(tasks)-1)/max(1,limit-1)) for i in range(min(limit,len(tasks)))))]
    client=OfficialClient(per_second=3);counts=collections.Counter();mark=10
    def fetch(m):
        source=[]
        try:
            fid=m['club_fixture_id'];f,fs=client.get(BASE+f'/fixtures/{fid}?pageSize=1&altIds=true&detail=2','Dated La Liga lineup, substitutions and result '+m['game_id'],kind='official_club_match');source.append(fs);assert f is not None,fs['return_status']
            s,ss=client.get(BASE+f'/stats/match/{fid}?altIds=true','La Liga team passing, shooting and defensive statistics '+m['game_id'],kind='official_club_team_statistics');source.append(ss);assert s is not None,ss['return_status']
            return m,parse(wanted[m['game_id']],m,f,s,fs,ss),None
        except (AssertionError,KeyError,ValueError,TypeError) as exc:return m,None,dict(reason=type(exc).__name__+': '+str(exc),sources=source)
    dump(ROOT_OUT/'laliga_club_progress.json',dict(at_utc=stamp(),processed=0,total=len(tasks),percent=0 if tasks else 100,counts={}))
    print(json.dumps(dict(stage='laliga_club_facts',tasks=len(tasks),matched=len(index['matches']),previously_collected=len(done))),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        for n,(m,row,error) in enumerate(pool.map(fetch,tasks),1):
            with db:
                if row:
                    db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(m['game_id'],json.dumps(row,allow_nan=False)));db.execute('DELETE FROM issues WHERE game_id=?',(m['game_id'],));counts['games']+=1;counts['players']+=len(row['players']);counts['minutes_complete']+=row['minutes_complete'];counts['goals_complete']+=row['goal_counts_reconcile'];counts['derivation_issues']+=bool(row['issues'])
                else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?)',(m['game_id'],json.dumps(error)));counts['acquisition_issues']+=1
            if n*100>=mark*len(tasks) or n==len(tasks):
                progress=dict(at_utc=stamp(),processed=n,total=len(tasks),percent=round(n*100/len(tasks),1),counts=dict(counts));dump(ROOT_OUT/'laliga_club_progress.json',progress);print(json.dumps(progress),flush=True);mark+=10
    db.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--all',action='store_true');p.add_argument('--limit',type=int,default=3);p.add_argument('--workers',type=int,default=4);a=p.parse_args();run(a.all,a.limit,a.workers)
