"""Resolve official full-name aliases via dated sweater/team/native-ID evidence.

The roster release alone establishes dated membership. Later identity evidence
can connect a static ID, but contributes no later performance or team status.
"""
import collections,hashlib,json,re
import pandas as pd
from common import ROOT_OUT,PROJECT,PREVIOUS,OfficialClient,read_db,dump,stamp
from collect_nhl_opening_rosters import RUN,namekey
from validate_shifts import text


def read_source(source):
    blob=(PROJECT/source['raw_file']).read_bytes()
    assert hashlib.sha256(blob).hexdigest()==source['sha256'] and source['return_status']=='200'
    return blob


def report_headings(blob):
    return [text(m) for m in re.findall(r'<td[^>]*class="playerHeading[^\"]*"[^>]*>(.*?)</td>',blob.decode('utf8',errors='replace'),re.S)]


def name_from_heading(heading):
    number,label=heading.split(' ',1);parts=label.split(',')
    assert number.isdigit() and len(parts)==2
    return int(number),parts[1].strip()+' '+parts[0].strip()


def candidates():
    path=RUN/'report_alias_candidates.json'
    if path.exists():return json.loads(path.read_bytes())
    result=collections.defaultdict(list);seen=set();headers={};games=0
    with read_db(ROOT_OUT/'nhl_shifts.sqlite') as db:
        for (body,) in db.execute("SELECT body FROM games WHERE body LIKE '%official_report_after_insufficient_api%'"):
            game=json.loads(body);sources={s['request_number']:s for s in game['sources']};games+=1
            for row in game['rows']:
                if row.get('source_kind')!='official_html_time_on_ice':continue
                rid=row['request_number'];source=sources[rid];pointer=re.match(r'playerHeading\[(\d+)\]',row['pointer'])
                assert pointer;index=int(pointer.group(1));key=(rid,index)
                if key in seen:continue
                seen.add(key)
                if rid not in headers:headers[rid]=report_headings(read_source(source))
                number,name=name_from_heading(headers[rid][index])
                proof=dict(official_player_id=row['player_id'],game_id=game['game_id'],official_game_id=str(game['official_game_id']),
                    side=row['side'],team_id=row['team_id'],sweater_number=number,report_name=name,
                    report_header_index=index,report_source=source)
                # Only retain a few independent games for a given name/ID.
                existing=result[namekey(name)]
                if sum(p['official_player_id']==proof['official_player_id'] for p in existing)<3:existing.append(proof)
    out=dict(result);dump(path,out);dump(RUN/'report_alias_candidate_summary.json',dict(at_utc=stamp(),report_games=games,names=len(out),headers=len(seen)))
    return out


def verify_proof(proof):
    if proof.get('type')=='german_umlaut_transliteration':
        obj=json.loads(read_source(proof['identity_source']))
        matches=[]
        for group in ['forwards','defensemen','goalies']:
            for index,p in enumerate(obj[group]):
                full=p['firstName']['default']+' '+p['lastName']['default']
                converted=full.translate(str.maketrans({'\u00e4':'ae','\u00f6':'oe','\u00fc':'ue','\u00c4':'Ae','\u00d6':'Oe','\u00dc':'Ue'}))
                if full!=converted and p.get('birthCountry')=='DEU' and namekey(converted)==namekey(proof['source_name']):matches.append((p,full,'/'+group+'/'+str(index)))
        assert len(matches)==1
        p,full,pointer=matches[0]
        assert str(p['id'])==proof['official_player_id'] and full==proof['canonical_name'] and pointer==proof['identity_pointer']
        return True
    native=proof['official_game_id'];year=int(native[:4]);code='TV' if proof['side']=='A' else 'TH'
    assert proof['report_source']['url']==f'https://www.nhl.com/scores/htmlreports/{year}{year+1}/{code}{native[4:]}.HTM'
    headers=report_headings(read_source(proof['report_source']))
    number,name=name_from_heading(headers[proof['report_header_index']])
    assert number==proof['sweater_number'] and name==proof['report_name']
    box=json.loads(read_source(proof['box_source']))
    assert str(box['id'])==proof['official_game_id']
    side='awayTeam' if proof['side']=='A' else 'homeTeam'
    assert str(box[side]['id'])==str(proof['team_id'])
    people=[p for group in box['playerByGameStats'][side].values() if isinstance(group,list) for p in group
            if p.get('sweaterNumber')==number]
    assert len(people)==1 and str(people[0]['playerId'])==proof['official_player_id']
    assert people[0]['position']==proof['position']
    # Full-name spelling comes from the official report; its unique sweater
    # on the exact dated team/game links to native playerId in official JSON.
    return True


def repair():
    catalog=candidates();client=OfficialClient(per_second=2);proofs={};attempts=[];changes=[]
    for path in sorted(RUN.glob('*/full.parquet')):
        frame=pd.read_parquet(path)
        if 'identity_evidence_json' not in frame:frame['identity_evidence_json']=None
        duplicated=frame.duplicated(['team_name','player_name_raw'],keep=False)
        for idx,row in frame[~frame.identity_verified&~duplicated].iterrows():
            if len(json.loads(row.identity_candidates_json))>1:continue
            key=namekey(row.player_name_raw)
            options=catalog.get(key,[]);pids={p['official_player_id'] for p in options}
            if len(pids)!=1:continue
            if key not in proofs:
                for option in options:
                    box,source=client.get('https://api-web.nhle.com/v1/gamecenter/'+option['official_game_id']+'/boxscore',
                        'Verify official roster name alias with exact game/team/sweater: '+row.player_name_raw,'nhl_roster_alias_identity')
                    if box is None:continue
                    proof=option|dict(box_source=source)
                    side='awayTeam' if proof['side']=='A' else 'homeTeam'
                    people=[p for group in box['playerByGameStats'][side].values() if isinstance(group,list) for p in group
                            if str(p['playerId'])==proof['official_player_id']]
                    if len(people)!=1:continue
                    proof['position']=people[0]['position']
                    try:verify_proof(proof)
                    except AssertionError as e:
                        attempts.append(dict(name=row.player_name_raw,game_id=option['game_id'],reason='Dated sweater/identity discrepancy',proof=proof));continue
                    proofs[key]=proof;break
            if key not in proofs:continue
            proof=proofs[key];pid=proof['official_player_id']
            identity,source=client.get(f'https://api-web.nhle.com/v1/player/{pid}/landing','Confirm stable native identity after official alias evidence: '+row.player_name_raw,'nhl_player_identity')
            assert identity is not None and str(identity['playerId'])==pid
            before={c:(None if pd.isna(row[c]) else row[c]) for c in ['official_player_id','player_name_api','position','identity_verified','identity_reason','identity_pointer']}
            frame.loc[idx,['official_player_id','player_name_api','position','identity_verified','identity_reason','identity_source_json','identity_pointer','identity_candidates_json','identity_evidence_json']]=[
                pid,identity['firstName']['default']+' '+identity['lastName']['default'],identity['position'],True,
                'Exact full name in official time-on-ice report, matched to unique native ID by same-game team and sweater number in official boxscore. Static identity only; historical membership comes from opening release.',
                json.dumps(source,sort_keys=True),'/',json.dumps([pid]),json.dumps(proof,sort_keys=True)]
            changes.append(dict(season=row.season,team_id=row.team_id,player_name_raw=row.player_name_raw,source_name_occurrence=int(row.source_name_occurrence),before=before,official_player_id=pid,proof=proof))
        frame.to_parquet(path,index=False);frame.to_csv(path.with_suffix('.csv'),index=False)
        collection=json.loads((path.parent/'full_collection.json').read_bytes())
        collection.update(verified=int(frame.identity_verified.sum()),unmatched=int((~frame.identity_verified).sum()),unmatched_pct=float(100*(~frame.identity_verified).mean()),alias_repaired_at_utc=stamp())
        dump(path.parent/'full_collection.json',collection)
    old=json.loads((RUN/'alias_repairs.json').read_bytes()) if (RUN/'alias_repairs.json').exists() else []
    dump(RUN/'alias_repairs.json',old+changes);dump(RUN/'alias_discrepancies.json',attempts)
    print(json.dumps(dict(newly_repaired=len(changes),verified_alias_names=len(proofs),discrepancies=len(attempts))),flush=True)


if __name__=='__main__':repair()
