"""Buy the fixed model winner at pre12; exit at first observed pre1 quote."""
import json
import argparse
import concurrent.futures
import sqlite3
import urllib.parse
from pathlib import Path
import numpy as np
import pandas as pd
from common import ROOT_OUT, PROJECT, REPORTS, dump, stamp, file_sha256
from backtest import quote_inputs
from nhl_winner_classifier import inputs
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine

LABEL='nhl_winner_prestart_exit'
RESULT=ROOT_OUT/'simulation_results'/LABEL


def population(stage):
    p=inputs(stage);p=p[p.variant.eq('logistic')]
    transfer.RESULT=RESULT;quotes=quote_inputs(RESULT/(stage+'_quote_quality.json'),revision='closest_v62')
    f=transfer.normalize('nhl',p,quotes,pick_growth=False)
    return f[f.provider.eq('polymarket')&f.probability.gt(.60)&f.price.gt(.5)]


def collect():
    assert json.loads((RESULT/'selection.json').read_bytes())['passed']
    assert (RESULT/'development_validation.json').exists()
    from refresh_hourly_prices import Client
    from nhl_winner_patient_entry import DOCS
    f=population('evaluation');client=Client(per_second=4)
    dump(RESULT/'evaluation_collection_plan.json',dict(at_utc=stamp(),docs=DOCS,documentation_read_utc=stamp(),
        requested_games=len(f),source='https://clob.polymarket.com/prices-history',fidelity_minutes=60,
        per_second=4,workers=3,scope='Existing fixedwinnerpre12toactualstartwindow;nohistoricunboundeddownload.',
        selection_sha256=file_sha256(RESULT/'selection.json'),used2026pricesforselection=False))
    def acquire(r):
        params=dict(market=r['entry_contract_id'],startTs=int(r['entry'].timestamp()),endTs=int(r['start'].timestamp())-1,fidelity=60)
        url='https://clob.polymarket.com/prices-history?'+urllib.parse.urlencode(params)
        body,src=client.get(url,'NHL fixed-winner pre-start exit evaluation: '+r['game_id'],kind='GET pre-match hourly prices')
        return dict(game_id=r['game_id'],provider='polymarket',token_id=r['entry_contract_id'],side=int(r['side']),
            prediction_time=r['entry'].isoformat(),start_time=r['start'].isoformat(),source=src,
            status='ok' if isinstance(body,dict) and isinstance(body.get('history'),list) else 'request_or_schema_failure',
            raw_rows=len(body['history']) if isinstance(body,dict) and isinstance(body.get('history'),list) else None)
    records=[];milestone=10
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for r in pool.map(acquire,f.to_dict('records')):
            records.append(r);pct=100*len(records)/len(f)
            if pct>=milestone or len(records)==len(f):
                dump(RESULT/'evaluation_requests.json',records)
                print(json.dumps(dict(stage='evaluation_collection',percent=milestone,complete=len(records),total=len(f),failed=sum(r['status']!='ok' for r in records))),flush=True);milestone+=10
    assert all(r['status']=='ok' for r in records),'Retry request/schema failures before evaluating'
    import nhl_winner_patient_entry as patient
    patient.RESULT=RESULT;found,coverage=patient.paths('evaluation',f)
    dump(RESULT/'evaluation_acquisition.json',dict(status='PASS',at_utc=stamp(),requested_games=len(f),
        covered_windows=int(coverage.covered.sum()),response_rows=sum(r['raw_rows'] for r in records),
        unresolved_windows=int((~coverage.covered).sum()),raw_hashes_and_values_verified=True))


def recover():
    """Resolve unavailable hourly sale observations with bounded finer history."""
    from refresh_hourly_prices import Client
    cov=pd.read_csv(RESULT/'evaluation_coverage.csv');missing=set(cov.loc[~cov.covered,'game_id'])
    f=population('evaluation');f=f[f.game_id.isin(missing)];assert len(f)==len(missing)
    client=Client(per_second=4);rows=[];points=[]
    dump(RESULT/'coverage_recovery_plan.json',dict(at_utc=stamp(),requested_games=len(f),
        reason='23gamewindows have no hourlypre1point; this is acquisitioncoverage, notproofpricesdidnotexist.',
        request='OfficialCLOBfidelity1,onlythefinalpregamehour. Sourcefallback only; nofilterusingpricemovementorresults.',
        earlier_result='Preserve131gameinitialcomparison; do not report it ascomplete154gameevaluation.',
        docs=['https://docs.polymarket.com/api-reference/markets/get-prices-history']))
    for r in f.to_dict('records'):
        target=r['start']-pd.Timedelta(hours=1)
        params=dict(market=r['entry_contract_id'],startTs=int(target.timestamp()),endTs=int(r['start'].timestamp())-1,fidelity=1)
        url='https://clob.polymarket.com/prices-history?'+urllib.parse.urlencode(params)
        body,src=client.get(url,'Recover unavailable NHL pre1 exit observations: '+r['game_id'],kind='GET bounded pre-match minute prices')
        assert isinstance(body,dict) and isinstance(body.get('history'),list),'Resolvefailedrequest beforeevaluating'
        assert file_sha256(PROJECT/src['raw_file'])==src['sha256']
        kept=[]
        for i,x in enumerate(body['history']):
            at=pd.Timestamp(x['t'],unit='s',tz='UTC');price=float(x['p']);assert np.isfinite(price) and 0<=price<=1
            if target<=at<r['start']:
                point=dict(game_id=r['game_id'],provider='polymarket',token_id=r['entry_contract_id'],side=int(r['side']),
                    prediction_time=r['entry'],start_time=r['start'],timestamp_utc=at,price=price,fidelity_minutes=1,
                    source_pointer='/history/'+str(i)+'/p',source_json=json.dumps(src,sort_keys=True))
                kept.append(point);points.append(point)
        rows.append(dict(game_id=r['game_id'],requested_target_utc=target,source=src,raw_rows=len(body['history']),
            pre1_observations=len(kept),recovered=bool(kept),status='recovered' if kept else 'official_minute_response_has_no_pre1_observations'))
        dump(RESULT/'coverage_recovery_requests.json',rows)
        print(json.dumps(dict(stage='coverage_recovery',complete=len(rows),total=len(f),recovered=sum(r['recovered'] for r in rows))),flush=True)
    pd.DataFrame(points).to_parquet(RESULT/'coverage_recovery_observations.parquet',index=False)
    dump(RESULT/'coverage_recovery_validation.json',dict(status='PASS',at_utc=stamp(),requested_games=len(f),
        recovered_games=sum(r['recovered'] for r in rows),observations=len(points),unresolved_games=sum(not r['recovered'] for r in rows),raw_hashes_verified=True))


def main(stage='development',repaired=False):
    label='evaluation_recovered' if repaired else stage
    RESULT.mkdir(exist_ok=True);assert not (RESULT/(label+'_validation.json')).exists()
    if stage=='evaluation':
        assert json.loads((RESULT/'selection.json').read_bytes())['passed']
        assert json.loads((RESULT/'evaluation_acquisition.json').read_bytes())['status']=='PASS'
    plan=dict(at_utc=stamp(),
        hypothesis='Current winner model earns positive settlement returns but remains volatile. Test whether its selected favourites appreciate before play, avoiding the binary settlement outcome. This is a new exit mechanism, not a switch to a cheaper opposing side.',
        entry='Existinglogisticargmax,confidence>60percent,ownquote>50percent,pre12,stake5*(100*p-51).',
        exit='Onefixedschedule:beginexit atstartminus1hour;use FIRST observedhourly price at orafterthat time and strictlybeforestart. No bestfutureprice,targethit,orhourgrid. Rawpointtimestamp is sale time, withno backward fill.',
        coverage='Usealreadyvalidatedhourlysourcepaths. Reportanygamewithoutanobservationinpre1window; pairedholdcontrol includesidenticalcoveredgames. No forward interpolation.',
        gate='Higher2025Sharpe andpositive return versusidenticalholdcohort;2024reportedseparately. Freeze beforeany2026collection/evaluation.',
        source='OfficialinternationalPolymarketCLOB hourlyhistory. Buy andsale observations are historicaltokenprices,not verifiedexecutablebid/askorUSprices.',
        accounting='Annual2000cash,independentledger,nofeesorspreads,calendardailyreturns. win_rate_pct refers eventualselectedteamwins;profitable_bets_pct refers actualsaleprofit.',
        limitation='2026 repeatedly inspected retrospective research; futureevaluation not a pristineholdout.',app_changed=False)
    if stage=='development':dump(RESULT/'plan.json',plan)
    else:plan=json.loads((RESULT/'plan.json').read_bytes())
    f=population(stage)
    path=ROOT_OUT/'nhl_winner_price_observations.parquet' if stage=='development' else RESULT/'evaluation_observations.parquet'
    points=pd.read_parquet(path)
    if repaired:
        assert stage=='evaluation' and json.loads((RESULT/'coverage_recovery_validation.json').read_bytes())['unresolved_games']==0
        points=pd.concat([points,pd.read_parquet(RESULT/'coverage_recovery_observations.parquet')],ignore_index=True)
    points['timestamp_utc']=pd.to_datetime(points.timestamp_utc,utc=True,format='mixed')
    groups={gid:g.sort_values('timestamp_utc') for gid,g in points.groupby('game_id')}
    positions=[];coverage=[];raws={}
    for row in f.to_dict('records'):
        gid=row['game_id'];g=groups.get(gid);chosen=None;target=row['start']-pd.Timedelta(hours=1)
        if g is not None:
            assert g.side.eq(row['side']).all() and g.token_id.astype(str).eq(str(row['entry_contract_id'])).all()
            possible=g[g.timestamp_utc.ge(target)&g.timestamp_utc.lt(row['start'])]
            if len(possible):chosen=possible.iloc[0]
        coverage.append(dict(game_id=gid,exit_target_utc=target,covered=chosen is not None,
            exit_source_utc=chosen.timestamp_utc if chosen is not None else None,
            status='first_observed_pre1_price' if chosen is not None else 'unresolved_pre1_observation'))
        if chosen is None:continue
        source=json.loads(chosen.source_json);rawfile=PROJECT/source['raw_file']
        if str(rawfile) not in raws:
            assert file_sha256(rawfile)==source['sha256'];raws[str(rawfile)]=json.loads(rawfile.read_bytes())
        index=int(chosen.source_pointer.split('/')[2]);raw=raws[str(rawfile)]['history'][index]
        assert raw['p']==chosen.price and pd.Timestamp(raw['t'],unit='s',tz='UTC')==chosen.timestamp_utc
        positions.append(row|dict(original_settlement_utc=row['exit'],exit=chosen.timestamp_utc,
            payout_per_share=float(chosen.price),exit_source_utc=chosen.timestamp_utc,exit_source_json=chosen.source_json,
            exit_source_pointer=chosen.source_pointer,exit_rule='first_pre1_observation'))
    exits=pd.DataFrame(positions);cov=pd.DataFrame(coverage);cov.to_csv(RESULT/(label+'_coverage.csv'),index=False)
    covered=f[f.game_id.isin(exits.game_id)]
    rows=[];bets=[];days=[];checks=[]
    for variant,g in [('full_hold_reference',f),('paired_hold_control',covered),('pre1_exit',exits)]:
        for year in ([2024,2025] if stage=='development' else [2026]):
            m,b,l,d=engine.simulate(g,year,'all_selected_outcomes','dollars_cash_only',5.,2000.)
            m['profitable_bets_pct']=100*float(b.profit.gt(0).mean()) if len(b) else None
            m['unchanged_price_pct']=100*float(b.profit.abs().lt(1e-10).mean()) if len(b) else None
            key=dict(sport='nhl',provider='polymarket',variant=variant,year=year,stage=label)
            rows.append(key|m);checks.append(key|engine.validate(b,l,d,'dollars_cash_only',5.,2000.))
            if len(b):
                assert b.side.eq(b[['p0','p1']].to_numpy().argmax(axis=1)).all()
                if variant=='pre1_exit':
                    assert b.exit.eq(b.exit_source_utc).all() and b.exit.lt(b.start).all()
                    assert b.exit.ge(b.start-pd.Timedelta(hours=1)).all()
                bets.append(b.assign(**key))
            days.append(d.assign(**key))
    a=pd.DataFrame(rows);a.to_csv(RESULT/(label+'_annual.csv'),index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/(label+'_bets.parquet'),index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/(label+'_daily.parquet'),index=False)
    if stage=='development':
        ix=a.set_index(['variant','year']);c,n=ix.loc[('paired_hold_control',2025)],ix.loc[('pre1_exit',2025)]
        passed=bool(n.sharpe>c.sharpe and n.return_pct>0)
        dump(RESULT/'selection.json',dict(at_utc=stamp(),passed=passed,used2026=False,adopted=False))
    else:passed=json.loads((RESULT/'selection.json').read_bytes())['passed']
    old=pd.read_csv(ROOT_OUT/'simulation_results/nhl_winner_classifier/agreement_annual.csv')
    old=old[old.provider.eq('polymarket')&old.variant.eq('market_agreement')].set_index('year')
    ctrl=a[a.variant.eq('full_hold_reference')].set_index('year')
    for field in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
        assert np.allclose(old.loc[ctrl.index,field],ctrl[field],rtol=0,atol=1e-9,equal_nan=True)
    proof=dict(status='PASS',at_utc=stamp(),games=len(f),covered_games=int(cov.covered.sum()),unresolved_games=int((~cov.covered).sum()),
        raw_responses_verified=len(raws),checks=checks,control_reproduced=True,source_parquet_sha256=file_sha256(path),
        exit_observation_selected_by_clock_only=True,all_bets_model_argmax=True,app_changed=False,adopted=False)
    proof['finer_source_recovery']=repaired
    if repaired:proof['recovery_parquet_sha256']=file_sha256(RESULT/'coverage_recovery_observations.parquet')
    dump(RESULT/(label+'_validation.json'),proof)
    cols=['variant','year','funded_games','win_rate_pct','profitable_bets_pct','return_pct','sharpe','max_drawdown_pct']
    table='\n'.join(['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']+['| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in a[cols].itertuples(index=False,name=None)])
    mode='w' if stage=='development' else 'a'
    with (REPORTS/(LABEL+'.md')).open(mode,encoding='utf8') as out:
        out.write('\n\n'.join(['# NHL predicted-winner pre-start sale: '+label,json.dumps(plan,indent=2),table,
            json.dumps({k:v for k,v in proof.items() if k!='checks'},indent=2),'Earlier selection: '+str(passed)+'.'])+'\n')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/'+label+'_annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL+'/'+label]=dict(plan=plan,selection=passed,validation=proof);dump(path,old)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(a[cols].to_string(index=False),flush=True);print(json.dumps(dict(passed=passed,unresolved_games=int((~cov.covered).sum()))),flush=True)


def publish():
    assert json.loads((RESULT/'evaluation_validation.json').read_bytes())['status']=='PASS'
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        for suffix in ['observations','coverage']:
            table='nhl_winner_price_'+suffix
            old=pd.read_parquet(ROOT_OUT/(table+'.parquet'));new=pd.read_parquet(RESULT/('evaluation_'+suffix+'.parquet'))
            if suffix=='observations':
                new=pd.concat([new,pd.read_parquet(RESULT/'coverage_recovery_observations.parquet')],ignore_index=True)
            else:
                extra=pd.read_parquet(RESULT/'coverage_recovery_observations.parquet')
                allpoints=pd.concat([pd.read_parquet(RESULT/'evaluation_observations.parquet'),extra],ignore_index=True)
                recovered={r['game_id']:r['source'] for r in json.loads((RESULT/'coverage_recovery_requests.json').read_bytes())}
                for i,row in new.iterrows():
                    g=allpoints[allpoints.game_id.eq(row.game_id)].drop_duplicates('timestamp_utc').sort_values('timestamp_utc')
                    a,b=pd.Timestamp(row.prediction_time),pd.Timestamp(row.start_time)
                    gap=float(np.diff([a.timestamp()]+[pd.Timestamp(t).timestamp() for t in g.timestamp_utc]+[b.timestamp()]).max()/3600)
                    covered=bool(len(g) and gap<=2)
                    new.loc[i,'observation_count']=len(g);new.loc[i,'max_gap_hours']=gap;new.loc[i,'covered']=covered
                    new.loc[i,'coverage_status']='covered_hourly_window' if covered else 'sparse_hourly_window' if len(g) else 'empty_response'
                    if row.game_id in recovered:
                        src=json.loads(row.source_json);src['additional_responses']=[recovered[row.game_id]];new.loc[i,'source_json']=json.dumps(src,sort_keys=True)
            for c in new:
                if isinstance(new[c].dtype,pd.DatetimeTZDtype):new[c]=new[c].map(lambda v:v.isoformat())
                if new[c].dtype=='bool':new[c]=new[c].astype(int)
            keys=['game_id','timestamp_utc'] if suffix=='observations' else ['game_id']
            frame=pd.concat([old,new],ignore_index=True).drop_duplicates(keys)
            assert len(frame)==len(old)+len(new),'Do not silently replace existing source observations'
            frame.to_sql(table,db,if_exists='replace',index=False)
            pd.testing.assert_frame_equal(frame,pd.read_sql_query('SELECT * FROM '+table,db),check_dtype=False)
            frame.to_parquet(ROOT_OUT/(table+'.parquet'),index=False);frame.to_csv(ROOT_OUT/(table+'.csv'),index=False)
            db.execute('UPDATE table_catalog SET rows=? WHERE "table"=?',(len(frame),table))
            db.execute('DELETE FROM missing_report WHERE "table"=?',(table,))
            for c in frame:db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(table,c,len(frame),int(frame[c].isna().sum()),100*frame[c].isna().mean()))
    from publish import main as catalog
    catalog()
    for suffix in ['observations','coverage']:
        path=(RESULT/('evaluation_'+suffix+'.parquet')).resolve();assert path.parent==RESULT.resolve();path.unlink()
    path=(RESULT/'coverage_recovery_observations.parquet').resolve();assert path.parent==RESULT.resolve();path.unlink()
    dump(RESULT/'publication.json',dict(status='PASS',at_utc=stamp(),published_to_existing_price_tables=True,temporary_normalized_duplicates_removed=True))


def original_stake(stage='development'):
    """User's original20dollars/point, without tuning the slope on later returns."""
    assert not (RESULT/('original_stake_'+stage+'_validation.json')).exists()
    if stage=='development':
        dump(RESULT/'original_stake_plan.json',dict(at_utc=stamp(),
            rationale='Theuseroriginallyspecified20dollars perpercentagepoint above51percent onstarting2000cash. That amount had unacceptable settlementrisk; testitunchangedwiththe earlierqualifiedpre1sale.',
            parameter_source='User58percentexample:140dollars,keptfixedasaccountchanges. No additionalamount grid.',
            gate='Original20pointamount must reachSharpe>=3andreturn>20percent on2025 before2026comparison. This gate tests the actualrequestedtarget; it neednotbeat5pointSharpe.',
            fixed='Samepre12modelwinner,confidence>60,ownprice>50,firstpre1sale,nocosts,cashonly,simultaneousordersscaleproportionally. Reportallcashconstraints and2024sensitivity.',
            evaluation='Selectionbefore2026pre1accountresults;2026isneverthelessrepeatedlyinspectedretrospectiveresearch.',app_changed=False))
    else:assert json.loads((RESULT/'original_stake_selection.json').read_bytes())['passed']
    saved=pd.read_parquet(RESULT/(stage+'_bets.parquet'));f=saved[saved.variant.eq('pre1_exit')].copy()
    assert f.game_id.is_unique
    coverage=pd.read_csv(RESULT/(stage+'_coverage.csv'));assert len(f)==int(coverage.covered.sum()),'Reconstruct all eligibility if control had unfunded bets'
    rows=[];bets=[];days=[];checks=[]
    for year in ([2024,2025] if stage=='development' else [2026]):
        m,b,l,d=engine.simulate(f,year,'all_selected_outcomes','dollars_cash_only',20.,2000.)
        m['profitable_bets_pct']=100*float(b.profit.gt(0).mean()) if len(b) else None
        key=dict(sport='nhl',provider='polymarket',variant='pre1_original20',year=year,stage=stage)
        rows.append(key|m);checks.append(key|engine.validate(b,l,d,'dollars_cash_only',20.,2000.))
        assert b.side.eq(b[['p0','p1']].to_numpy().argmax(axis=1)).all()
        bets.append(b.assign(**key));days.append(d.assign(**key))
    a=pd.DataFrame(rows);a.to_csv(RESULT/('original_stake_'+stage+'_annual.csv'),index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/('original_stake_'+stage+'_bets.parquet'),index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/('original_stake_'+stage+'_daily.parquet'),index=False)
    if stage=='development':
        r=a[a.year.eq(2025)].iloc[0];passed=bool(r.sharpe>=3 and r.return_pct>20)
        dump(RESULT/'original_stake_selection.json',dict(at_utc=stamp(),passed=passed,used2026=False,adopted=False))
    proof=dict(status='PASS',at_utc=stamp(),checks=checks,original_dollar_slope=20,app_changed=False,adopted=False)
    dump(RESULT/('original_stake_'+stage+'_validation.json'),proof)
    cols=['year','funded_games','win_rate_pct','profitable_bets_pct','return_pct','sharpe','max_drawdown_pct','scaled_batches','unfunded_games']
    table='\n'.join(['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']+['| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in a[cols].itertuples(index=False,name=None)])
    with (REPORTS/(LABEL+'.md')).open('a',encoding='utf8') as out:out.write('\nOriginaluser20dollarstake: '+stage+'\n\n'+table+'\n')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/original_stake_'+stage+'_annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL+'/original_stake/'+stage]=dict(plan=json.loads((RESULT/'original_stake_plan.json').read_bytes()),selection=json.loads((RESULT/'original_stake_selection.json').read_bytes()),validation=proof);dump(path,old)
    print(a[cols].to_string(index=False),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',nargs='?',default='development',choices=['development','collect','evaluation','publish','stake_development','stake_evaluation','recover','evaluation_recovered','stake_evaluation_recovered'])
    a=p.parse_args().action
    if a in ['development','evaluation']:main(a)
    elif a=='evaluation_recovered':main('evaluation',repaired=True)
    elif a.startswith('stake_'):original_stake(a.removeprefix('stake_'))
    else:globals()[a]()
