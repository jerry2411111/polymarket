"""One-outcome versus same-budget positive-edge diversification.

No fitted allocation parameter. Forecasts are the validated count-corrected
expanding soccer model. Multi-leg orders require coincident quote clocks; an
underround is not asserted to be executable arbitrage. The single-side control
must reproduce the prior saved cash accounts before a comparison is accepted.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, PREVIOUS, REPORTS, dump, stamp, file_sha256, read_db
import test_confidence_dollars as engine

LABEL = 'soccer_outcome_allocation'
RESULT = ROOT_OUT/'simulation_results'/LABEL
SOURCE = ROOT_OUT/'simulation_results/soccer_paired_price_signal'


def initialize():
    RESULT.mkdir(exist_ok=True)
    plan = dict(at_utc=stamp(),
        hypothesis='A one-outcome choice discards other positively valued outcomes. Their mutually exclusive payoffs may reduce risk when sharing the unchanged match budget.',
        model='Unchanged count-corrected41-input soccer logistic; monthly expanding2021+history, forecasts2024+. No rejected continuity or nonlinear model used.',
        control='One maximum expected-log-growth outcome; match budget=500*max(p_selected-price_selected,0), annual2000cash-only, pre12closest-prior prices age<=24h, official settlement.',
        alternative='For at least2positive p-price outcomes with identical source clocks AND identical availability clocks, split that SAME match budget in proportion to max(p_i-price_i,0). Otherwise retain the original one-side order.',
        underround='If sum(all3prices)<1-1e-12 retain single-side control; do not simulate a new multi-leg arbitrage from historical token prices.',
        gate='Provider2025Sharpe higher, return>20%, drawdown no worse than control.2024 small quoted sample reported separately, no post-hoc gate revision. Only qualifying providers enter2026.',
        evaluation='2026 is repeatedly inspected retrospective rolling research, not untouched OOS.',
        no_parameter_search=True, no_new_price_or_probability_fit=True,
        interpretation='No assumed costs/spreads; Polymarket historical token prices are not verified executable USasks. Kalshi uses recorded YESask closes.',
        source_sha256=file_sha256(SOURCE/'development_predictions.parquet'), app_changed=False)
    path=RESULT/'plan.json'
    if path.exists():
        assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(path,plan)
    return plan


def inputs(stage):
    plan=initialize()
    assert file_sha256(SOURCE/'development_predictions.parquet')==plan['source_sha256']
    if stage=='development':
        f=pd.read_parquet(SOURCE/'development_predictions.parquet')
    else:
        # Reuse the audited source join, not its rejected probability mixture.
        import soccer_paired_price_signal as paired
        paired.RESULT=RESULT
        f,_=paired.load('evaluation')
        f=f[f.prediction_time.dt.year.eq(2026)].copy()
    assert not f.duplicated(['provider','game_id']).any()
    original=ROOT_OUT/'simulation_results/soccer_source_count_rates'
    p=pd.read_parquet(original/(stage+'_predictions.parquet'))
    p=p[p.variant.eq('candidate')].set_index('game_id')
    expected=p.loc[f.game_id]
    assert np.allclose(f[['p0','p1','p2']],expected[['p0','p1','p2']],rtol=0,atol=1e-12)
    assert np.array_equal(f.target,expected.target)
    assert f.train_label_max.lt(f.prediction_time).all()
    assert f.calibration_label_max.lt(f.prediction_time).all()
    for i in range(3):
        assert f['price'+str(i)].between(0,1,inclusive='neither').all()
        assert f['entry_source_utc'+str(i)].le(f.prediction_time).all()
        assert f['entry_available_utc'+str(i)].le(f.prediction_time).all()
        assert f['entry_age_hours'+str(i)].between(0,24).all()
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        meta=pd.read_sql_query('SELECT game_id,teamA,teamB,scoreA,scoreB,target FROM soccer_games',db).set_index('game_id')
    assert np.array_equal(meta.loc[f.game_id,'target'],f.target)
    for c in ['teamA','teamB','scoreA','scoreB']:f[c]=f.game_id.map(meta[c])
    return f


def allocation(p,q,synchronized):
    """All arguments are pre-entry values; never consult the outcome."""
    edge=np.maximum(p-q,0.)
    fraction=.25*edge/(1-q)
    utility=p*np.log1p(fraction*(1/q-1))+(1-p)*np.log1p(-fraction)
    side=int(np.argmax(utility))
    if utility[side]<=0:return None
    base=np.zeros(3);base[side]=1.
    split=(edge>0).sum()>=2 and synchronized and q.sum()>=1-1e-12
    weights=edge/edge.sum() if split else base.copy()
    budget=500*edge[side]
    return side,base,weights,budget,split


def orders(f):
    rows=[];diagnostics=[];unchanged=0
    for r in f.to_dict('records'):
        p=np.array([r['p'+str(i)] for i in range(3)])
        q=np.array([r['price'+str(i)] for i in range(3)])
        assert np.isclose(p.sum(),1,rtol=0,atol=1e-10)
        synchronized=(len({r['entry_source_utc'+str(i)] for i in range(3)})==1 and
                      len({r['entry_available_utc'+str(i)] for i in range(3)})==1)
        selected=allocation(p,q,synchronized)
        if selected is None:continue
        side,base,weights,budget,split=selected
        y=int(r['target']);edge=np.maximum(p-q,0.)
        if not split:unchanged+=1
        record={k:r[k] for k in ['provider','game_id','official_game_id','league','teamA','teamB','scoreA','scoreB','prediction_time','available_time','target']}
        record.update(year=r['prediction_time'].year,selected_side=side,selected_probability=p[side],
            selected_price=q[side],selected_won=side==y,positive_sides=int((edge>0).sum()),synchronized=synchronized,
            price_sum=float(q.sum()),split=bool(split),budget=budget,
            discarded_positive_outcome_won=bool(side!=y and edge[y]>0))
        for name,w in [('single',base),('split',weights)]:
            payoff=w/q
            record[name+'_expected_return']=float(p@payoff-1)
            record[name+'_expected_variance']=float(p@(payoff**2)-(p@payoff)**2)
            record[name+'_unconstrained_profit']=float(budget*(payoff[y]-1))
            record[name+'_weights']=json.dumps(w.tolist())
            for i in np.flatnonzero(w>0):
                # The existing cash engine needs a unique open-position key.
                # Preserve actual game_id separately; restore it on publication.
                multiplier=float(budget*w[i]/(500*edge[i]))
                assert 0<multiplier<=1+1e-12
                multiplier=min(1.,multiplier)
                row={k:r[k] for k in ['provider','sport','league','official_game_id','teamA','teamB','scoreA','scoreB','target','p0','p1','p2','train_label_max','calibration_label_max']}
                row.update(variant=name,match_id=r['game_id'],game_id=r['game_id']+'::outcome'+str(i),
                    side=int(i),price=float(q[i]),probability=float(p[i]),edge=float(p[i]-q[i]),
                    won=bool(i==y),year=r['prediction_time'].year,entry=r['prediction_time'],exit=r['available_time'],
                    start=r['start_time'],date=r['date'],source_utc=r['entry_source_utc'+str(i)],
                    available_utc=r['entry_available_utc'+str(i)],quote_age_hours=r['entry_age_hours'+str(i)],
                    price_basis=r['price_basis'+str(i)],entry_request_id=r['entry_request_id'+str(i)],
                    entry_pointer=r['entry_pointer'+str(i)],entry_contract_id=r['entry_contract_id'+str(i)],
                    availability_stake_multiplier=multiplier,match_budget=budget,within_match_weight=float(w[i]),
                    split=bool(split),selected_side=side,fit_id=r['fold'])
                rows.append(row)
        diagnostics.append(record)
    legs=pd.DataFrame(rows);cases=pd.DataFrame(diagnostics)
    assert not legs.duplicated(['provider','variant','game_id']).any()
    proposed=500*legs.edge*legs.availability_stake_multiplier
    check=legs.assign(proposed=proposed).groupby(['provider','variant','match_id']).agg(proposed=('proposed','sum'),budget=('match_budget','first'),weights=('within_match_weight','sum'))
    assert np.allclose(check.proposed,check.budget,rtol=0,atol=1e-10)
    assert np.allclose(check.weights,1,rtol=0,atol=1e-12)
    totals=check.proposed.unstack('variant');assert np.allclose(totals.single,totals.split,rtol=0,atol=1e-10)
    assert (legs.edge>0).all()
    return legs,cases,dict(games=len(cases),unchanged_single_orders=unchanged,equal_match_budgets_checked=len(check))


def simulate(f,stage,providers=None):
    legs,cases,proof=orders(f)
    annual=[];positions=[];daily=[];checks=[]
    for (provider,variant),g in legs.groupby(['provider','variant']):
        if providers is not None and provider not in providers:continue
        for year in sorted(g.year.unique()):
            m,b,l,d=engine.simulate(g,int(year),'all_selected_outcomes','availability_edge_cash_only',5.,2000.)
            key=dict(provider=provider,variant=variant,year=int(year),sport='soccer')
            checks.append(key|engine.validate(b,l,d,'availability_edge_cash_only',5.,2000.))
            assert np.allclose(b.stake,b.match_budget*b.within_match_weight*b.allocation_scale,rtol=0,atol=1e-9)
            assert b.source_utc.le(b.entry).all() and b.available_utc.le(b.entry).all()
            grouped=b.groupby('match_id').agg(profit=('profit','sum'),stake=('stake','sum'),budget=('match_budget','first'),scale=('allocation_scale','first'))
            assert np.allclose(grouped.stake,grouped.budget*grouped.scale,rtol=0,atol=1e-9)
            m['funded_legs']=m.pop('funded_games');m['funded_games']=len(grouped)
            m['eligible_legs']=m.pop('eligible_games');m['eligible_games']=g[g.year.eq(year)].match_id.nunique()
            m['leg_win_rate_pct']=m.pop('win_rate_pct')
            m['profitable_games_pct']=100*float(grouped.profit.gt(0).mean())
            m['multiple_outcome_games']=int(b.groupby('match_id').size().gt(1).sum())
            annual.append(key|m)
            b=b.rename(columns={'game_id':'position_id','match_id':'game_id'})
            positions.append(b.assign(**key));daily.append(d.assign(**key))
    a=pd.DataFrame(annual);b=pd.concat(positions,ignore_index=True)
    cases.to_parquet(RESULT/(stage+'_cases.parquet'),index=False)
    cases[~cases.selected_won].to_csv(RESULT/(stage+'_losing_cases.csv'),index=False)
    a.to_csv(RESULT/(stage+'_annual.csv'),index=False)
    b.to_parquet(RESULT/(stage+'_positions.parquet'),index=False)
    pd.concat(daily,ignore_index=True).to_parquet(RESULT/(stage+'_daily.parquet'),index=False)
    summary=cases.groupby(['provider','year','split']).agg(games=('game_id','size'),selected_wins=('selected_won','sum'),
        alternative_positive_wins=('discarded_positive_outcome_won','sum'),single_profit=('single_unconstrained_profit','sum'),
        split_profit=('split_unconstrained_profit','sum'),single_expected_variance=('single_expected_variance','mean'),
        split_expected_variance=('split_expected_variance','mean'),mean_selected_probability=('selected_probability','mean')).reset_index()
    summary.to_csv(RESULT/(stage+'_diagnosis.csv'),index=False)
    # Independence from future labels is checked with the real input rows.
    poisoned=f.copy();poisoned['target']=(poisoned.target+1)%3
    x,_,_=orders(poisoned)
    cols=['provider','variant','game_id','side','price','probability','availability_stake_multiplier','match_budget','within_match_weight']
    pd.testing.assert_frame_equal(legs[cols],x[cols],check_exact=True)
    proof.update(status='PASS',at_utc=stamp(),cash_checks=checks,future_target_poisoned=True,
        negative_covariance_handled_by_actual_mutually_exclusive_payoffs=True,app_changed=False)
    dump(RESULT/(stage+'_validation.json'),proof)
    return a


def run():
    assert not (RESULT/'selection.json').exists(),'Preserve completed decision'
    f=inputs('development');a=simulate(f,'development')
    # Compare identical complete-three-price cohort to independently saved
    # reference accounts. This also detects missing games and side reversals.
    old=pd.read_csv(ROOT_OUT/'simulation_results/soccer_corrected_nonlinear/annual.csv')
    old=old[old.variant.eq('reference')].set_index(['provider','year'])
    control=a[a.variant.eq('single')].set_index(['provider','year'])
    fields=['funded_games','return_pct','sharpe','max_drawdown_pct','final_equity']
    assert set(control.index)==set(old.index)
    assert np.allclose(control[fields],old.loc[control.index,fields],rtol=0,atol=1e-9,equal_nan=True)
    choices={}
    for provider,g in a[a.year.eq(2025)].groupby('provider'):
        z=g.set_index('variant');x,y=z.loc['split'],z.loc['single']
        choices[provider]=bool(x.sharpe>y.sharpe and x.return_pct>20 and x.max_drawdown_pct<=y.max_drawdown_pct)
    dump(RESULT/'selection.json',dict(at_utc=stamp(),choices=choices,control_annual_rows_reproduced=len(control),adopted=False))
    if any(choices.values()):
        simulate(inputs('evaluation'),'evaluation',[k for k,v in choices.items() if v])
    print(a[['provider','variant','year','funded_games','funded_legs','profitable_games_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print(json.dumps(choices),flush=True)


def finish():
    from final_pipeline import cleanup,validate
    assert json.loads((RESULT/'development_validation.json').read_bytes())['status']=='PASS'
    selection=json.loads((RESULT/'selection.json').read_bytes())
    plan=json.loads((RESULT/'plan.json').read_bytes())
    def table(f):
        def fmt(v):return f'{v:.6f}' if isinstance(v,(float,np.floating)) else str(v)
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(map(fmt,row))+' |' for row in f.itertuples(index=False,name=None)])
    lines=['# Soccer allocation across underpriced outcomes','',
        'The single-outcome rule can lose even when another outcome that was also forecast as underpriced wins. This comparison shares the original match budget among positive probability-minus-price gaps. No extra capital or probability model is fitted. Each alternative order uses an actual recorded price, with the same source and availability timestamps for all three outcomes. Underrounds and unmatched clocks retain the single-side control.','',
        'For each game: retain the prior selected outcome and its budget B=500*(p_selected-price_selected). In an eligible split, outcome i receives B*max(p_i-price_i,0)/sum_j(max(p_j-price_j,0)). Zero-edge and negative-edge outcomes receive nothing. Final profit sums actual side payouts; one losing leg does not by itself make the game unprofitable.','',
        'The forecasts use monthly expanding history from2021 with earlier-only scaling/calibration and predictions from2024. The existing pre12 and24hourquote-age ceiling remain unchanged. Each provider has its own annual$2000cash account. A funded leg has a separate position ID; canonical game IDs remain unchanged in outputs. Available cash is shared proportionately among simultaneous orders and cannot use unsettled proceeds.','',
        'The original control replays all saved annual accounts. Proposed match budgets match exactly; label poisoning leaves every order weight unchanged; independently reconstructed cash and daily equity match. Selection was specified before comparison: improve2025Sharpe, return above20%, drawdown no worse.2024 is a separately reported incomplete price sample. Selection: '+json.dumps(selection)+'.','']
    annual=[]
    for stage in ['development','evaluation']:
        if not (RESULT/(stage+'_annual.csv')).exists():continue
        a=pd.read_csv(RESULT/(stage+'_annual.csv'));annual.append(a.assign(source_result_file=LABEL+'/'+stage+'_annual.csv'))
        lines +=[stage.capitalize(),'',table(a[['provider','variant','year','funded_games','funded_legs','profitable_games_pct','return_pct','sharpe','max_drawdown_pct']]),'',
            table(pd.read_csv(RESULT/(stage+'_diagnosis.csv'))),'']
    lines+=['The profitable-game percentage describes positive net profit across all legs, not classification accuracy. Calendar daily Sharpe includes idle days and uses sqrt(365.25). Open contracts remain at purchase cost until settlement; this is settlement-account Sharpe rather than intraday mark-to-market risk. No costs are assumed. Polymarket historical token observations do not prove executable USasks; Kalshi prices retain the recordedYESaskbasis.2026 is repeatedly inspected retrospective rolling research, not a fresh holdout. No app deployment or model adoption.','',
        'Reproduce soccer_outcome_allocation.py run then finish. Original sources and official documentation remain in the collection README and per-leg raw request IDs, contract IDs, JSON pointers and source timestamps. No new acquisition or duplicate fitted model is created.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False)
    pd.concat([old[~old.source_result_file.str.startswith(LABEL+'/',na=False)]]+annual,ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL]=dict(plan=plan,selection=selection);dump(path,old)
    cleanup();check=validate();receipt=dict(status='PASS',at_utc=stamp(),selection=selection,app_validation=check,goal_achieved=False)
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(path.read_bytes());m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']),latest_simulation_update=receipt);dump(path,m)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['run','finish'])
    globals()[parser.parse_args().stage]()
