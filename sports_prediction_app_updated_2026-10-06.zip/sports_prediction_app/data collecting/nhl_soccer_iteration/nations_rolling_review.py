"""Daily walk-forward Nations League study. Isolated research; no deployment."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
import sys,json,pickle,sqlite3,argparse,urllib.parse,math,shutil,html,collections
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

PROJECT=Path(r'C:\Users\Jerry\Desktop\Sports ML')
SOURCE=PROJECT/'data collecting/nhl_soccer_iteration'
sys.path.insert(0,str(SOURCE))
from common import ROOT_OUT,OfficialClient,dump,stamp,file_sha256
import nations_strategy_review as original
import features,models

LABEL='nations_rolling_review'
WORK=ROOT_OUT/'_work'/LABEL
RESULT=ROOT_OUT/'simulation_results'/LABEL
BASE=original.BASE
DATA=WORK/'data'
END=pd.Timestamp('2026-10-06',tz='UTC')
ARMS=['expanding_daily','rolling_24m_daily']
TABLES=['nations_league_games','nations_match_team_statistics','nations_league_player_match_statistics','nations_match_player_statistics']

def flat(records):
    return pd.DataFrame([{k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()} for r in records])

class Client(OfficialClient):
    HOSTS=OfficialClient.HOSTS|{'gateway.polymarket.us'}
    def connect(self):
        c=sqlite3.connect(WORK/'acquisition.sqlite',timeout=60);c.row_factory=sqlite3.Row;c.execute('PRAGMA journal_mode=WAL');return c

def plan():
    WORK.mkdir(parents=True,exist_ok=True);DATA.mkdir(exist_ok=True)
    if (WORK/'protocol.json').exists():return
    dump(WORK/'protocol.json',dict(at_utc=stamp(),study='Daily rolling Nations League extension',
        forecast_period='2022-01-01 through 2026-10-05, completed official matches only',
        primary='Expanding earlier-only club+national training; refit once per match date before its earliest T-12h forecast',
        comparison='Identical model using only prior 24 calendar months of training matches; fixed before viewing results; not selected by return',
        calibration='180-day chronological sports calibration with outcome-label purge; same selected C=.02 recipe',
        confidence='Daily fit of unchanged C=.02 confidence recipe on earlier club OOS price examples only; last60 eligible examples calibrate, train labels precede first calibration entry; no Nations labels enter confidence fitting',
        controls='Always designated home; smoothed prior Nations class-frequency forecast; retained monthly study overlap comparison',
        trading='Selected outcome YES; p>.51 and confidence>.55. First qualifying5-minute entry inT12..start. $2000 starting cash, soccerhardcap$900, $5*max(100p-51,0). FixedT1 separately reported.',
        costs='Gross plus .05 conservative fee sensitivity. Whole shares; cash only; assume full fill at historical display ask. No orderbook depth or queue replay.',
        data='Earlier national results and club-linked player form only. National roster based on previous appearances. Preserve prior study data and live app.',
        evaluation='Annual and match-date/window metrics, forward chronological accounts without per-date resets, 50-match rolling accuracy, Brier/logloss, drawdown at cost, date-block bootstrap uncertainty',
        expansion='Add independently verified October UEFA results/actions and US markets. September already inspected; October is a later retrospective extension, not a prospective holdout.',
        future_peeking_tests='Assert temporal purges; reproduce predictions after poisoning future labels/features and dropping all future rows for representative folds; verify price raw hashes/pointers and ledger accounting',
        old_price_coverage='Audit international Polymarket/Kalshi separately; do not substitute them for US prices or back-apply a2026confidence fit to earlier years',
        retained_source_sha256={n:file_sha256(ROOT_OUT/(n+'.parquet')) for n in TABLES},
        baseline_sha256={n:file_sha256(BASE/n) for n in ['soccer_features.parquet','sports_model.pkl','confidence_model.pkl','confidence_inputs.parquet']},
        app_deployment=False,parameter_search=False))

def collect():
    plan();client=Client(per_second=3)
    from collect_nations_league import normalize,fetch_details
    from collect_uefa_matchstats import fetch_verified
    calendar=[];receipts=[];seen=set()
    for offset in range(0,1000,50):
        params=dict(competitionId=2014,seasonYear=2027,fromDate='2026-09-30',toDate='2026-10-05',order='ASC',limit=50,offset=offset)
        body,source=client.get('https://match.uefa.com/v5/matches?'+urllib.parse.urlencode(params),'October Nations rolling extension official results','official_schedule')
        assert isinstance(body,list),source
        receipts.append(source)
        for i,match in enumerate(body):
            assert match['id'] not in seen;seen.add(match['id'])
            if match['status']=='FINISHED':
                game=normalize(match,source,i);assert '2026-09-30'<=game['date']<='2026-10-05'
                assert game['scoreA'] is not None and game['scoreB'] is not None
                calendar.append(game)
        if len(body)<50:break
    else:raise AssertionError('Calendar pagination incomplete')
    dump(WORK/'extension_calendar.json',calendar);dump(WORK/'calendar_acquisition.json',receipts)
    print(json.dumps(dict(stage='new_calendar',games=len(calendar))),flush=True)
    cache=WORK/'extension_records.json';saved=json.loads(cache.read_bytes()) if cache.exists() else {}
    def fetch(game):
        _,lineup,error,sources=fetch_details(client,game)
        if error:return game,None,error
        _,actions,error,action_sources=fetch_verified(game,client)
        if error:return game,None,error
        return game,dict(lineup=lineup,actions=actions),None
    tasks=[g for g in calendar if g['game_id'] not in saved];errors=[]
    with ThreadPoolExecutor(max_workers=3) as pool:
        for i,(game,record,error) in enumerate(pool.map(fetch,tasks),1):
            if error:errors.append(dict(game_id=game['game_id'],reason=error))
            else:saved[game['game_id']]=record
            dump(cache,saved)
            if i%5==0 or i==len(tasks):print(json.dumps(dict(stage='new_details',completed=i,total=len(tasks),errors=len(errors))),flush=True)
    dump(WORK/'collection_issues.json',errors)
    assert not errors,errors
    games=[]
    for g in calendar:
        z={k:v for k,v in g.items() if k not in ('source','score_evidence')}
        z.update(source_request_id=g['source']['request_number'],source_url=g['source']['url'],source_raw_file=g['source']['raw_file'],source_sha256=g['source']['sha256'],score_evidence_json=json.dumps(g['score_evidence']))
        games.append(z)
    extra={TABLES[0]:flat(games),TABLES[1]:flat([r for x in saved.values() for r in x['actions']['teams']]),
        TABLES[2]:flat([r for x in saved.values() for r in x['lineup']['players']]),TABLES[3]:flat([r for x in saved.values() for r in x['actions']['players']])}
    audit=[]
    for name,new in extra.items():
        old=pd.read_parquet(ROOT_OUT/(name+'.parquet'));assert set(old.game_id).isdisjoint(new.game_id)
        for col in new.columns.intersection(old.columns):
            if pd.api.types.is_numeric_dtype(old[col]) and not pd.api.types.is_bool_dtype(old[col]):
                new[col]=pd.to_numeric(new[col].map(lambda v:int(v) if isinstance(v,bool) else v),errors='raise')
        frame=pd.concat([old,new],ignore_index=True);frame.to_parquet(DATA/(name+'.parquet'),index=False)
        new.to_parquet(WORK/('extension_'+name+'.parquet'),index=False)
        audit.append(dict(table=name,existing=len(old),new=len(new),total=len(frame)))
    dump(WORK/'collection_validation.json',dict(status='PASS',tables=audit,new_games=len(games),all_results_have_details=True))
    # Refresh only Nations League US markets, with fully exhausted pagination.
    events=[];pages=[];seen=set()
    for offset in range(0,2000,100):
        query=dict(limit=100,offset=offset,closed='true',tag_slug='unl')
        body,source=client.get('https://gateway.polymarket.us/v1/events?'+urllib.parse.urlencode(query),'Completed Nations League US events for rolling extension','polymarket_us')
        assert isinstance(body,dict) and isinstance(body.get('events'),list),source
        page=body['events'];pages.append(dict(source=source,rows=len(page)))
        for e in page:
            assert e['id'] not in seen;seen.add(e['id'])
            assert 'unl' in [t['slug'] for t in e['tags']]
            e['source']=source;events.append(e)
        if len(page)<100:break
    else:raise AssertionError('US Nations pagination incomplete')
    dump(WORK/'events.json',events);dump(WORK/'discovery.json',pages)
    print(json.dumps(dict(stage='collection_complete',new_games=len(games),us_events=len(events))),flush=True)

def normalized():
    g=pd.read_parquet(DATA/'nations_league_games.parquet')
    team=pd.read_parquet(DATA/'nations_match_team_statistics.parquet')
    p=pd.read_parquet(DATA/'nations_league_player_match_statistics.parquet')
    action=pd.read_parquet(DATA/'nations_match_player_statistics.parquet')
    for col in ('start_time','available_time'):g[col]=pd.to_datetime(g[col],utc=True,format='mixed')
    g['prediction_time']=g.start_time-pd.Timedelta(hours=12)
    g['target']=np.where(g.scoreA.eq(g.scoreB),2,g.scoreB.gt(g.scoreA).astype(int))
    assert g.game_id.is_unique and g.start_time.max()<END
    keys={(r.game_id,s):'NATION:'+getattr(r,'team'+s+'_id') for r in g.itertuples() for s in ('A','B')}
    # Native ID joins, preserving event-verified participation and regulation goals.
    idx=['game_id','side','official_player_id']
    action['official_player_id']=action.lineup_player_id.fillna(action.official_player_id)
    for frame in (p,action):frame['official_player_id']=frame.official_player_id.astype(str)
    assert not p.duplicated(idx).any() and not action.duplicated(idx).any()
    p=p.merge(action[idx+['key_passes','attempts_on_target','distance_covered','source_units_json','lineup_identity_verified']],on=idx,how='left',validate='one_to_one')
    assert p.loc[p.key_passes.notna()|p.attempts_on_target.notna(),'lineup_identity_verified'].eq(True).all()
    p['player_id']='NATION_PLAYER:'+p.official_player_id
    p['shots_on_target']=p.attempts_on_target
    for r in p[p.distance_covered.notna()].itertuples():assert json.loads(r.source_units_json)['distance_covered']=='KILOMETER'
    p['distance_covered_km']=p.distance_covered
    p['available_at_utc']=pd.to_datetime(p.available_at_utc,utc=True,format='mixed')
    latest=p.groupby('game_id').available_at_utc.max()
    labels=g.set_index('game_id').available_time.copy()
    g['available_time']=pd.concat([g.available_time,g.game_id.map(latest)],axis=1).max(axis=1)
    lookup=g.set_index('game_id')
    o=team[['game_id','side']].copy()
    assert len(o)==len(g)*2 and not o.duplicated(['game_id','side']).any()
    o['start_time']=o.game_id.map(lookup.start_time);o['available_time']=o.game_id.map(lookup.available_time)
    for field in ('score_for','score_against'):
        o[field]=[lookup.loc[r.game_id,'score'+(r.side if field=='score_for' else ('B' if r.side=='A' else 'A'))] for r in o.itertuples()]
    direct={'shots':'attempts','shots_on_target':'attempts_on_target','passes':'passes_attempted','passes_completed':'passes_completed',
            'long_passes':'passes_long_attempted','box_shots':'shot_in_penalty_area','big_chances':'big_chance'}
    for dest,raw in direct.items():o[dest]=pd.to_numeric(team[raw],errors='coerce')
    for name in ('quality_xg','quality_xg_against','finishing_residual'):o[name]=np.nan
    swapped=o[['game_id','side','shots','shots_on_target','passes']].copy();swapped['side']=swapped.side.map({'A':'B','B':'A'})
    swapped=swapped.rename(columns={c:c+'_opponent' for c in swapped if c not in ('game_id','side')})
    o=o.merge(swapped,on=['game_id','side'],validate='one_to_one')
    ratio=lambda a,b:a/b.where(b>0)
    derived={'shot_share':ratio(o.shots,o.shots+o.shots_opponent),'on_target_share':ratio(o.shots_on_target,o.shots_on_target+o.shots_on_target_opponent),
        'passing_completion':ratio(o.passes_completed,o.passes),'direct_passing_fraction':ratio(o.long_passes,o.passes),
        'box_attempt_fraction':ratio(o.box_shots,o.shots)}
    for k,v in derived.items():o['context8_'+k]=v
    stats=['score_for','score_against','quality_xg','quality_xg_against','finishing_residual','shots_on_target','big_chances']+['context8_'+k for k in derived]
    metrics=['goals','assists','key_passes','distance_covered_km']
    return g,o,p,keys,stats,metrics,labels



def prepare():
    plan();original.WORK=WORK;original.END=END;g,o,p,keys,stats,metrics,labels=normalized()
    f,audit=features.build('soccer',g,o,p,keys,stats,metrics)
    for col in list(f):
        if col.startswith('f_context8_') and col.endswith('_diff'):f[col.replace('f_context8_','f_ctx_')]=f[col]
    for field in ['quality_xg','quality_xg_against','finishing_residual','shots_on_target','big_chances','roster_goals_rate','roster_assists_rate','roster_key_passes_rate','roster_distance_covered_km_rate','roster_players']:
        f['f_ctx_'+field+'_diff']=f['f_'+field+'_diff']
    f=original.add_club_player_form(f,g,p)
    b=pickle.loads((BASE/'sports_model.pkl').read_bytes())
    for c in b['columns']:
        if c.startswith('league_'):f[c]=0.
        elif c not in f:f[c]=np.nan
    f['league_UEFA Nations League']=1.
    f['available_time']=f.game_id.map(labels)
    f=f.merge(g[['game_id','teamA','teamB','home_away']],on='game_id',validate='one_to_one')
    assert (f.source_max_available_utc.isna()|f.source_max_available_utc.lt(f.prediction_time)).all()
    past=g[g.start_time.lt(pd.Timestamp('2026-01-01',tz='UTC'))]
    prefix,_=features.build('soccer',past,o[o.game_id.isin(past.game_id)],p[p.game_id.isin(past.game_id)],keys,stats,metrics)
    numeric=[c for c in prefix if c.startswith('f_')]
    np.testing.assert_allclose(f.set_index('game_id').loc[prefix.game_id,numeric],prefix[numeric],equal_nan=True,rtol=0,atol=0)
    f.to_parquet(WORK/'features.parquet',index=False)
    sources=['nations_league_games.parquet','nations_match_team_statistics.parquet','nations_league_player_match_statistics.parquet','nations_match_player_statistics.parquet']
    dump(WORK/'feature_validation.json',dict(status='PASS',rows=len(f),prefix_rows=len(prefix),no_future_inputs=True,
        source_sha256={n:file_sha256(DATA/n) for n in sources},
        baseline_sha256={n:file_sha256(BASE/n) for n in ['sports_model.pkl','soccer_features.parquet','confidence_model.pkl']},
        missing_2026_pct={c:round(100*f.loc[f.date.ge('2026'),c].isna().mean(),3) for c in b['columns'] if not c.startswith('league_')},
        neutral_venue_games=int(f.home_away.eq('Away;Away').sum()),
        limitations=['No club coefficients used for national teams','Unavailable physical/action inputs remain NaN','Designated B-side home convention follows selected recipe; neutral fixtures are flagged']))
    print(json.dumps(dict(stage='features',rows=len(f),prefix_checks=len(prefix))),flush=True)



def fit_fold(allrows,test,cut,arm,bundle):
    prior=allrows[allrows.available_time.lt(cut)&allrows.prediction_time.lt(cut)].sort_values(['prediction_time','game_id'])
    if arm=='rolling_24m_daily':prior=prior[prior.prediction_time.ge(cut-pd.DateOffset(months=24))]
    cal=prior[prior.prediction_time.ge(cut-pd.Timedelta(days=180))]
    train=prior[prior.available_time.lt(cal.prediction_time.min())]
    assert len(cal)>=60 and len(train)>=200 and train.target.nunique()==3
    columns=bundle['columns']+['league_UEFA Nations League']
    X=lambda f:f[columns].replace([np.inf,-np.inf],np.nan).astype(float)
    with threadpool_limits(limits=2):
        early=models.make_model(bundle['recipe'],'soccer');models.fit_model(early,X(train),train,bundle['recipe'],cal.prediction_time.min())
        calibration=models.calibration_fit(early.predict_proba(X(cal)),cal.target.astype(int))
        final=models.make_model(bundle['recipe'],'soccer');models.fit_model(final,X(prior),prior,bundle['recipe'],cut)
        prob=models.apply_calibration(final.predict_proba(X(test)),calibration)
    assert np.isfinite(prob).all() and np.allclose(prob.sum(axis=1),1)
    meta=dict(arm=arm,cutoff=cut,train_games=len(prior),nations_train=int(prior.league.eq('UEFA Nations League').sum()),
        cal_games=len(cal),test_games=len(test),train_min=prior.prediction_time.min(),train_label_max=prior.available_time.max(),
        cal_label_max=cal.available_time.max(),cal_start=cal.prediction_time.min(),cal_train_label_max=train.available_time.max())
    assert meta['train_label_max']<cut and meta['cal_train_label_max']<meta['cal_start']
    return prob,meta

def fit():
    plan();nation=pd.read_parquet(WORK/'features.parquet');club=pd.read_parquet(BASE/'soccer_features.parquet')
    club['league_UEFA Nations League']=0.;allrows=pd.concat([club,nation],ignore_index=True)
    for c in ('prediction_time','available_time','start_time'):allrows[c]=pd.to_datetime(allrows[c],utc=True)
    assert allrows.game_id.is_unique
    bundle=pickle.loads((BASE/'sports_model.pkl').read_bytes());parts=[];audits=[];checks=[]
    cohort=nation[nation.date.ge('2022')];dates=sorted(cohort.date.unique())
    for i,(day,test) in enumerate(cohort.groupby('date'),1):
        cut=test.prediction_time.min()
        prior=nation[nation.available_time.lt(cut)]
        freq=(prior.target.value_counts().reindex([0,1,2],fill_value=0).to_numpy()+1)/(len(prior)+3)
        for arm in ARMS:
            prob,meta=fit_fold(allrows,test,cut,arm,bundle)
            z=test.copy();z[['p0','p1','p2']]=prob;z['selected']=prob.argmax(axis=1);z['p']=prob.max(axis=1);z['correct']=z.selected.eq(z.target)
            for k in ('arm','cutoff','train_label_max','cal_label_max'):z[k]=meta[k]
            z[['prior_p0','prior_p1','prior_p2']]=np.tile(freq,(len(z),1));parts.append(z);audits.append(meta)
            # Refit representative historical and extension days with all future labels poisoned.
            if day in {dates[0],next(d for d in dates if d>='2024'),next(d for d in dates if d>='2026-09'),next(d for d in dates if d>='2026-10')}:
                poisoned=allrows.copy();future=poisoned.available_time.ge(cut)
                poisoned.loc[future,'target']=(poisoned.loc[future,'target']+1)%3
                columns=bundle['columns']+['league_UEFA Nations League'];poisoned.loc[future,columns]=999.
                # Test inputs are separately frozen at their own forecast cutoffs.
                other,_=fit_fold(poisoned,test,cut,arm,bundle)
                prefix,_=fit_fold(allrows[allrows.available_time.lt(cut)],test,cut,arm,bundle)
                np.testing.assert_allclose(prob,other,rtol=0,atol=1e-12);np.testing.assert_allclose(prob,prefix,rtol=0,atol=1e-12)
                checks.append(dict(arm=arm,date=day,games=len(test),future_poison_equal=True,prefix_equal=True))
        if i%5==0 or i==len(dates):print(json.dumps(dict(stage='daily_fits',dates=i,total=len(dates),through=day)),flush=True)
    result=pd.concat(parts,ignore_index=True);result.to_parquet(WORK/'predictions.parquet',index=False)
    pd.DataFrame(audits).to_csv(WORK/'folds.csv',index=False)
    dump(WORK/'fit_validation.json',dict(status='PASS',dates=len(dates),fits=len(audits),forecasts=len(result),unique_games=result.game_id.nunique(),
        temporal_checks=True,representative_future_poison_checks=checks,hyperparameters_tuned=False,models_retained=False))
    monthly=[]
    for month,test in nation[nation.date.ge('2024')].groupby(nation.prediction_time.dt.strftime('%Y-%m')):
        prob,_=fit_fold(allrows,test,pd.Timestamp(month,tz='UTC'),'expanding_daily',bundle)
        z=test[['game_id','target','date']].copy();z['correct']=prob.argmax(axis=1)==z.target.to_numpy();z[['p0','p1','p2']]=prob;monthly.append(z)
    pd.concat(monthly,ignore_index=True).to_parquet(WORK/'corrected_monthly_predictions.parquet',index=False)

def prices():
    client=Client(per_second=3);games=pd.read_parquet(DATA/(TABLES[0]+'.parquet'))
    events=json.loads((WORK/'events.json').read_bytes());contracts=[];missing=[]
    aliases={'czechrepublic':'czechia','republicofireland':'ireland','turkey':'turkiye'}
    norm=lambda s:aliases.get(original.norm(s),original.norm(s))
    for g in games[games.date.ge('2026')].to_dict('records'):
        candidates=[];start=pd.Timestamp(g['start_time'])
        for event in events:
            if pd.Timestamp(event['startTime'])!=start:continue
            names={norm(s['team']['name']) for m in event['markets'] for s in m.get('marketSides',[]) if s.get('team')}
            if names=={norm(g['teamA']),norm(g['teamB'])}:candidates.append(event)
        if len(candidates)!=1:missing.append(dict(game_id=g['game_id'],date=g['date'],reason='No unique exact team/time US match'));continue
        event=candidates[0];sides=[]
        for market in event['markets']:
            if market.get('sportsMarketType')!='soccer_team_full_time_winner':continue
            assert pd.Timestamp(market['gameStartTime'])==start and '90 minutes' in market['description']
            for side in market['marketSides']:
                if not side.get('long'):continue
                team=side.get('team');label=2 if not team and market['slug'].endswith('-draw') else next((i for i,s in enumerate('AB') if team and norm(team['name'])==norm(g['team'+s])),None)
                if label is None:continue
                target=2 if g['scoreA']==g['scoreB'] else int(g['scoreB']>g['scoreA'])
                assert float(side['price'])==int(target==label),'US settlement mismatch'
                sides.append(label);contracts.append(dict(game_id=g['game_id'],side=label,market_slug=market['slug'],market_id=str(market['id']),
                    created_at=market['createdAt'],start=start,source=event['source'],event_id=event['id']))
        assert sorted(sides)==[0,1,2],(event['slug'],sides)
    c=pd.DataFrame(contracts);flat(contracts).to_parquet(WORK/'contracts.parquet',index=False)
    dump(WORK/'mapping_validation.json',dict(status='PASS',matched_games=c.game_id.nunique(),contracts=len(c),missing=missing))
    prior=ROOT_OUT/'simulation_results/nations_strategy_review'
    reused={r['market_slug']:r for r in json.loads((prior/'price_acquisition.json').read_bytes())}
    def fetch(contract):
        start=contract['start'];lo=start-pd.Timedelta(hours=12);slug=contract['market_slug']
        if slug in reused:
            source=reused[slug]['source'];raw=PROJECT/source['raw_file'];assert file_sha256(raw)==source['sha256'];body=json.loads(raw.read_bytes());origin='prior_study'
        else:
            query={'symbol':slug,'timestamp.startTimestamp':int(lo.timestamp()),'timestamp.endTimestamp':int(start.timestamp()),'fidelity':1}
            body,source=client.get('https://gateway.polymarket.us/v1/price-history?'+urllib.parse.urlencode(query),'Rolling Nations all-outcome pregame US history '+slug,'polymarket_us');origin=LABEL
        assert isinstance(body,dict) and isinstance(body.get('history'),list),source
        points=[]
        for i,row in enumerate(body['history']):
            at=pd.Timestamp(row['timestamp'],unit='s',tz='UTC');ask=row.get('longPrice');short=row.get('shortPrice')
            if ask is None or short is None:continue
            ask=float(ask);bid=1-float(short)
            if lo<=at<start and at>=pd.Timestamp(contract['created_at']) and 0<bid<=ask<1:
                points.append(dict(game_id=contract['game_id'],side=contract['side'],at=at,ask=ask,bid=bid,market_slug=slug,
                    source_sha256=source['sha256'],raw_pointer='/history/'+str(i)))
        return points,dict(game_id=contract['game_id'],side=contract['side'],market_slug=slug,raw_rows=len(body['history']),valid_rows=len(points),source=source,origin=origin)
    allpoints=[];audit=[]
    with ThreadPoolExecutor(max_workers=3) as pool:
        for i,(points,receipt) in enumerate(pool.map(fetch,c.to_dict('records')),1):
            allpoints.extend(points);audit.append(receipt)
            if i%30==0 or i==len(c):print(json.dumps(dict(stage='us_prices',contracts=i,total=len(c),points=len(allpoints))),flush=True)
    q=pd.DataFrame(allpoints);assert not q.duplicated(['game_id','side','at']).any()
    q.to_parquet(WORK/'prices.parquet',index=False);dump(WORK/'price_acquisition.json',audit)

def decisions():
    from sklearn.base import clone
    from scipy.special import softmax
    sys.path.append(str(PROJECT/'sports_app'))
    from live_trading import context_values,confidence_values
    p=pd.read_parquet(WORK/'predictions.parquet');quotes=pd.read_parquet(WORK/'prices.parquet')
    histories={k:g.sort_values('at') for k,g in quotes.groupby(['game_id','side'])}
    bundle=pickle.loads((BASE/'confidence_model.pkl').read_bytes());inputs=pd.read_parquet(BASE/'confidence_inputs.parquet')
    columns=bundle['columns'];out=[];audit=[];checks=0
    for day,games in p[p.game_id.isin(quotes.game_id)].groupby('date'):
        cut=games.prediction_time.min();prior=inputs[inputs.exit.lt(cut)].sort_values('entry')
        cal=prior.tail(60);train=prior.iloc[:-60];train=train[train.exit.lt(cal.entry.min())]
        assert len(train)>=120 and train.correct.nunique()==2 and len(cal)==60
        assert train.exit.max()<cal.entry.min() and cal.exit.max()<cut
        with threadpool_limits(limits=1):
            model=clone(bundle['model']).fit(train[columns],train.correct)
            temperature=models.temperature_fit(model.predict_proba(cal[columns]),cal.correct)
        rows=[];frames=[]
        for g in games.to_dict('records'):
            history=histories.get((g['game_id'],g['selected']))
            if history is None:continue
            points=list(zip(history['at'],history.ask));times=history['at'].dt.as_unit('ns').astype('int64').to_numpy()
            prediction=dict(probabilities=[g['p0'],g['p1'],g['p2']],selected='ABD'[g['selected']]);ctx=context_values(g)
            for at in pd.date_range(g['prediction_time'],g['start_time'],freq='5min',inclusive='left'):
                loc=np.searchsorted(times,at.value,side='right')-1
                if loc<0:continue
                q=history.iloc[loc]
                assert q['at']<=at and (loc+1==len(history) or history.iloc[loc+1]['at']>at)
                if (at-q['at']).total_seconds()>60:continue
                book=dict(ask=q.ask,observed_at=q['at'])
                values=confidence_values(prediction,book,ctx,points,at)
                if at==g['prediction_time']:
                    assert values==confidence_values(prediction,book,ctx,[x for x in points if x[0]<=at],at);checks+=1
                frames.append({c:np.nan if values[c] is None else values[c] for c in columns})
                rows.append(dict(arm=g['arm'],game_id=g['game_id'],date=g['date'],at=at,start=g['start_time'],exit=g['available_time'],
                    p=g['p'],selected=g['selected'],target=int(g['target']),correct=bool(g['correct']),ask=q.ask,bid=q.bid,quote_at=q['at'],
                    market_slug=q.market_slug,source_sha256=q.source_sha256,raw_pointer=q.raw_pointer,teamA=g['teamA'],teamB=g['teamB']))
        with threadpool_limits(limits=1):raw=model.predict_proba(pd.DataFrame(frames,columns=columns))
        scores=softmax(np.log(np.clip(raw,1e-8,1))/temperature,axis=1)[:,1]
        for row,value in zip(rows,scores):row['confidence']=float(value);row['qualifies']=bool(row['p']>.51 and value>.55)
        out.extend(rows);audit.append(dict(date=day,cutoff=str(cut),training=len(train),calibration=len(cal),training_label_max=str(train.exit.max()),
            calibration_start=str(cal.entry.min()),calibration_label_max=str(cal.exit.max()),temperature=float(temperature),decision_rows=len(rows)))
    d=pd.DataFrame(out);assert d['at'].lt(d.start).all() and d.quote_at.le(d['at']).all()
    d.to_parquet(WORK/'decisions.parquet',index=False)
    dump(WORK/'confidence_validation.json',dict(status='PASS',folds=audit,prefix_checks=checks,earlier_club_only=True))
    print(json.dumps(dict(stage='decisions',rows=len(d),qualified_games=d[d.qualifies].groupby('arm').game_id.nunique().to_dict())),flush=True)

def scores(frame):
    from sklearn.metrics import log_loss
    prob=frame[['p0','p1','p2']].to_numpy();truth=frame.target.to_numpy(int)
    return dict(games=len(frame),wins=int(frame.correct.sum()),accuracy_pct=100*frame.correct.mean(),
        log_loss=log_loss(truth,prob,labels=[0,1,2]),brier=float(((prob-np.eye(3)[truth])**2).sum(axis=1).mean()),
        home_baseline_pct=100*frame.target.eq(1).mean(),draw_games=int(frame.target.eq(2).sum()),draw_picks=int(frame.selected.eq(2).sum()),
        p_above_51=int(frame.p.gt(.51).sum()),p_above_51_correct=int(frame[frame.p.gt(.51)].correct.sum()))

def analyze():
    decisions();p=pd.read_parquet(WORK/'predictions.parquet');d=pd.read_parquet(WORK/'decisions.parquet')
    annual=[];windows=[];dates=[];rolling=[];calibration=[];prior_metrics=[]
    for arm,g in p.groupby('arm'):
        annual.append(dict(arm=arm,year='ALL')|scores(g))
        for year,f in g.groupby(g.date.str[:4]):annual.append(dict(arm=arm,year=year)|scores(f))
        for period,f in g.groupby(g.date.str[:7]):windows.append(dict(arm=arm,period=period)|scores(f))
        for day,f in g.groupby('date'):dates.append(dict(arm=arm,date=day)|scores(f))
        z=g.sort_values(['prediction_time','game_id']);r=z[['game_id','date','arm']].copy()
        r['last50_accuracy_pct']=100*z.correct.astype(float).rolling(50,min_periods=50).mean().to_numpy();rolling.append(r)
        for interval,f in g.groupby(pd.cut(g.p,bins=[0,.4,.5,.6,.7,.8,.9,1],include_lowest=True),observed=True):
            calibration.append(dict(arm=arm,bin=str(interval),games=len(f),mean_p=f.p.mean(),observed_win_rate=f.correct.mean()))
    base=p[p.arm.eq(ARMS[0])].copy()
    base[['p0','p1','p2']]=base[['prior_p0','prior_p1','prior_p2']].to_numpy();base['selected']=base[['p0','p1','p2']].to_numpy().argmax(axis=1)
    base['p']=base[['p0','p1','p2']].max(axis=1);base['correct']=base.selected.eq(base.target)
    for year,g in [('ALL',base)]+list(base.groupby(base.date.str[:4])):prior_metrics.append(dict(year=year,arm='prior_nations_frequency')|scores(g))
    for name,rows in [('forecast_annual',annual),('forecast_windows',windows),('forecast_dates',dates),('calibration',calibration),('prior_baseline',prior_metrics)]:pd.DataFrame(rows).to_csv(WORK/(name+'.csv'),index=False)
    pd.concat(rolling,ignore_index=True).to_csv(WORK/'rolling50.csv',index=False)
    # Paired date-block bootstrap: retain dependence among matches on one date.
    rng=np.random.default_rng(37);blocks=[]
    for day,g in p.groupby('date'):
        a=g[g.arm.eq(ARMS[0])];b=g[g.arm.eq(ARMS[1])]
        assert set(a.game_id)==set(b.game_id)
        blocks.append([len(a),int(a.correct.sum()),int(b.correct.sum()),int(a.target.eq(1).sum())])
    blocks=np.asarray(blocks);sums=blocks[rng.integers(0,len(blocks),size=(5000,len(blocks)))].sum(axis=1)
    stats=100*sums[:,1:]/sums[:,:1]
    dump(WORK/'uncertainty.json',dict(method='5000 paired match-date block bootstrap resamples; descriptive retrospective uncertainty, not independent future validation',
        expanding_accuracy_95_pct=np.quantile(stats[:,0],[.025,.975]).tolist(),rolling24m_accuracy_95_pct=np.quantile(stats[:,1],[.025,.975]).tolist(),
        expanding_minus_rolling_pp_95=np.quantile(stats[:,0]-stats[:,1],[.025,.975]).tolist(),
        expanding_minus_home_pp_95=np.quantile(stats[:,0]-stats[:,2],[.025,.975]).tolist()))
    summaries=[];trades=[];ledgers=[];daily=[];month_results=[]
    original.END=END
    for arm,g in d.groupby('arm'):
        valid=g[g.qualifies];first=valid.sort_values(['at','game_id']).groupby('game_id',sort=False).head(1)
        reference=valid[(valid.start-valid['at']).eq(pd.Timedelta(hours=1))]
        for timing,entries in [('first_T12',first),('fixed_T1',reference)]:
            for cost,coefficient in [('gross',0.),('fee_estimate',.05)]:
                summary,b,l,c=original.simulate_account(entries,coefficient)
                meta=dict(arm=arm,timing=timing,cost_scenario=cost);summaries.append(meta|summary)
                if len(b):
                    trades.append(b.assign(**meta))
                    for month,f in b.groupby(b['at'].dt.strftime('%Y-%m')):
                        month_results.append(meta|dict(month=month,bets=len(f),wins=int(f.correct.sum()),profit=float(f.pnl.sum()),fees=float(f.fees.sum()),purchase_cost=float(f.cost.sum())))
                ledgers.append(l.assign(**meta));daily.append(c.assign(**meta))
    pd.DataFrame(summaries).to_csv(WORK/'trading_summary.csv',index=False);pd.DataFrame(month_results).to_csv(WORK/'trading_months.csv',index=False)
    pd.concat(trades,ignore_index=True).to_parquet(WORK/'bets.parquet',index=False)
    pd.concat(ledgers,ignore_index=True).to_parquet(WORK/'ledger.parquet',index=False);pd.concat(daily,ignore_index=True).to_parquet(WORK/'daily.parquet',index=False)
    # Coverage of older exchanges is evidence about available data, not US fills.
    coverage=[]
    for provider in ('polymarket','kalshi'):
        q=pd.read_parquet(ROOT_OUT/('nations_'+provider+'_pre_match.parquet'))
        for year,g in q.groupby(q.date.str[:4]):
            cols=[s+'_pre_12_p' for s in ('teamA','teamB','draw')]
            coverage.append(dict(provider=provider,year=year,mapped_games=len(g),complete_T12_quotes=int(g[cols].notna().all(axis=1).sum()),
                usable_for_US_strategy=False,reason='Different exchange; no contemporaneous US confidence training for earlier years'))
    pd.DataFrame(coverage).to_csv(WORK/'other_exchange_coverage.csv',index=False)
    old=pd.read_parquet(WORK/'corrected_monthly_predictions.parquet')
    joined=p.merge(old[['game_id','correct','p0','p1','p2']].rename(columns={c:'monthly_'+c for c in ['correct','p0','p1','p2']}),on='game_id',validate='many_to_one')
    pd.DataFrame([dict(arm=arm,games=len(g),daily_accuracy_pct=100*g.correct.mean(),corrected_monthly_accuracy_pct=100*g.monthly_correct.mean()) for arm,g in joined.groupby('arm')]).to_csv(WORK/'monthly_overlap.csv',index=False)
    print(pd.DataFrame(annual).query("year=='ALL'").to_string(index=False),flush=True)
    print(pd.DataFrame(summaries)[['arm','timing','cost_scenario','bets','wins','profit','return_pct','max_drawdown_pct']].to_string(index=False),flush=True)

def validate():
    protocol=json.loads((WORK/'protocol.json').read_bytes())
    for name,digest in protocol['retained_source_sha256'].items():assert file_sha256(ROOT_OUT/(name+'.parquet'))==digest
    for name,digest in protocol['baseline_sha256'].items():assert file_sha256(BASE/name)==digest
    p=pd.read_parquet(WORK/'predictions.parquet');q=pd.read_parquet(WORK/'prices.parquet');d=pd.read_parquet(WORK/'decisions.parquet')
    b=pd.read_parquet(WORK/'bets.parquet');ledger=pd.read_parquet(WORK/'ledger.parquet');summary=pd.read_csv(WORK/'trading_summary.csv')
    coverage=pd.read_csv(WORK/'player_form_coverage.csv')
    valid=coverage.max_player_source.ne('NaT')&coverage.max_player_source.notna()
    sources=pd.to_datetime(coverage.loc[valid,'max_player_source'],utc=True,format='mixed');cuts=pd.to_datetime(coverage.loc[valid,'cutoff'],utc=True,format='mixed')
    assert sources.lt(cuts).all() and sources.ge(pd.Timestamp('2021-01-01',tz='UTC')).all()
    assert not p.duplicated(['arm','game_id']).any() and p.train_label_max.lt(p.cutoff).all() and p.cutoff.le(p.prediction_time).all()
    assert p.cal_label_max.lt(p.cutoff).all() and (p.source_max_available_utc.isna()|p.source_max_available_utc.lt(p.prediction_time)).all()
    assert np.allclose(p[['p0','p1','p2']].sum(axis=1),1) and np.isfinite(p[['p0','p1','p2']]).all().all()
    replayed=0
    for receipt in json.loads((WORK/'price_acquisition.json').read_bytes()):
        source=receipt['source'];path=PROJECT/source['raw_file'];assert file_sha256(path)==source['sha256'];raw=json.loads(path.read_bytes())
        for row in q[q.market_slug.eq(receipt['market_slug'])].itertuples():
            point=raw['history'][int(row.raw_pointer.rsplit('/',1)[1])]
            assert row.at==pd.Timestamp(point['timestamp'],unit='s',tz='UTC') and row.ask==float(point['longPrice'])
            assert abs(row.bid-(1-float(point['shortPrice'])))<1e-12;replayed+=1
    assert replayed==len(q)
    joined=d.merge(q[['game_id','side','at','ask','bid']].rename(columns={'side':'selected','at':'quote_at','ask':'raw_ask','bid':'raw_bid'}),on=['game_id','selected','quote_at'],validate='many_to_one')
    assert len(joined)==len(d) and np.array_equal(joined.ask,joined.raw_ask) and np.array_equal(joined.bid,joined.raw_bid)
    assert (d['at']-d.quote_at).between(pd.Timedelta(0),pd.Timedelta(seconds=60)).all() and d['at'].lt(d.start).all()
    assert np.array_equal(d.qualifies,d.p.gt(.51)&d.confidence.gt(.55))
    assert b.p.gt(.51).all() and b.confidence.gt(.55).all() and np.allclose(b.cost,b.quantity*b.ask)
    assert np.allclose(b.payout,b.quantity*b.correct.astype(int)) and np.allclose(b.pnl,b.payout-b.cost-b.fees)
    for row in summary.to_dict('records'):
        chosen=b[b.arm.eq(row['arm'])&b.timing.eq(row['timing'])&b.cost_scenario.eq(row['cost_scenario'])]
        curve=ledger[ledger.arm.eq(row['arm'])&ledger.timing.eq(row['timing'])&ledger.cost_scenario.eq(row['cost_scenario'])]
        assert len(chosen)==row['bets'] and chosen.game_id.is_unique and chosen.correct.sum()==row['wins']
        assert abs(chosen.pnl.sum()-row['profit'])<1e-7 and abs(curve.iloc[-1].cash-row['final_cash'])<1e-7
        assert curve.cash.ge(-1e-8).all() and curve.open_cost.le(900+1e-8).all() and curve.iloc[-1].open_cost==0
        assert np.allclose(curve.equity,curve.cash+curve.open_cost)
        eligible=d[d.arm.eq(row['arm'])&d.qualifies]
        if row['timing']=='first_T12':
            first=eligible.groupby('game_id')['at'].min();assert all(r.at==first[r.game_id] for r in chosen.itertuples())
        else:assert (chosen.start-chosen['at']).eq(pd.Timedelta(hours=1)).all()
    # All new official calendar responses replay to the same regulation result and IDs.
    from collect_nations_league import normalize
    new=json.loads((WORK/'extension_calendar.json').read_bytes())
    for game in new:
        source=game['source'];path=PROJECT/source['raw_file'];assert file_sha256(path)==source['sha256']
        idx=int(game['pointer'].strip('/'));match=json.loads(path.read_bytes())[idx]
        assert normalize(match,source,idx)==game
    receipts=0
    def replay_sources(value):
        nonlocal receipts
        if isinstance(value,dict):
            if value.get('raw_file') and value.get('sha256'):
                assert file_sha256(PROJECT/value['raw_file'])==value['sha256'];receipts+=1
            for child in value.values():replay_sources(child)
        elif isinstance(value,list):
            for child in value:replay_sources(child)
    replay_sources(json.loads((WORK/'extension_records.json').read_bytes()))
    dump(WORK/'final_validation.json',dict(status='PASS',at_utc=stamp(),unique_forecast_games=p.game_id.nunique(),forecasts=len(p),
        daily_model_fits=len(pd.read_csv(WORK/'folds.csv')),us_games=q.game_id.nunique(),price_points_replayed=replayed,new_official_games_replayed=len(new),
        additional_raw_receipts_checked=receipts,player_history_direct_timestamp_filter=True,player_source_dates_in_valid_era=True,
        earlier_reports_invalidated='nations_strategy_review/erratum.json',baseline_models_unchanged=True,prior_source_tables_unchanged=True,
        original_report_replaced_by_corrected_comparisons=True,trade_accounting_checked=True,real_orders_sent=0,adopted=False))

def publish():
    validate();assert not RESULT.exists(),'Review existing publication before replacing it'
    RESULT.mkdir(parents=True)
    for path in WORK.iterdir():
        if path.is_file() and path.suffix in ('.json','.csv','.parquet') and path.name not in ('features.parquet','predictions.parquet'):
            shutil.copy2(path,RESULT/path.name);assert file_sha256(path)==file_sha256(RESULT/path.name)
    p=pd.read_parquet(WORK/'predictions.parquet');keep=[c for c in p if not c.startswith(('f_','league_'))]
    p[keep].to_parquet(RESULT/'predictions.parquet',index=False)
    with closing(sqlite3.connect(WORK/'acquisition.sqlite')) as a,closing(sqlite3.connect(RESULT/'acquisition.sqlite')) as b:a.backup(b)
    report()
    catalog=[]
    meanings={'p':'Selected sports-outcome probability','confidence':'Earlier-only club-trained confidence score',
        'at':'Decision or account event time','quote_at':'Actual source price observation time','ask':'Historical YES display price, assumed fill price',
        'bid':'YES economic bid calculated as 1 minus NO display price','equity':'Cash plus unsettled purchase cost; not marked to market',
        'source_max_available_utc':'Latest actual sports source availability before forecast','cutoff':'Daily model fitting boundary',
        'profit':'Scenario payout minus purchase cost and estimated fees','fees':'Scenario estimate, not actual historical fees'}
    for path in RESULT.glob('*.parquet'):
        table=pd.read_parquet(path)
        for col in table:
            catalog.append(dict(table=path.stem,column=col,dtype=str(table[col].dtype),rows=len(table),missing=int(table[col].isna().sum()),
                meaning=meanings.get(col,col.replace('_',' ')),unit='UTC timestamp' if pd.api.types.is_datetime64_any_dtype(table[col]) else 'USD' if col in ('pnl','cost','fees','cash','equity','open_cost','payout') else 'value or category',source='Research only; protocol and source acquisition receipts'))
    pd.DataFrame(catalog).to_csv(RESULT/'catalog.csv',index=False)
    catalog_root=PROJECT/'reports/nhl_soccer_iteration'
    for name in ('table_catalog.csv','column_catalog.csv'):
        old=pd.read_csv(catalog_root/name);old=old[~old.table.str.startswith(LABEL+'/')]
        new=pd.DataFrame(catalog)
        if name=='table_catalog.csv':new=new.groupby('table').agg(rows=('rows','first'),columns=('column','size')).reset_index()
        else:new=new[['table','column','meaning','unit','source']]
        new['table']=LABEL+'/'+new.table;tmp=(catalog_root/name).with_suffix('.tmp')
        pd.concat([old,new],ignore_index=True).to_csv(tmp,index=False);tmp.replace(catalog_root/name)
    manifest=dict(status='PASS',at_utc=stamp(),code_sha256={name:file_sha256(SOURCE/name) for name in ['nations_rolling_review.py','nations_strategy_review.py']},
        files={p.name:file_sha256(p) for p in RESULT.iterdir() if p.is_file()},models_retained=False,adopted=False)
    dump(RESULT/'manifest.json',manifest)
    assert all(file_sha256(RESULT/name)==digest for name,digest in manifest['files'].items())
    path=ROOT_OUT/'retention/retained_artifacts.json';retained=json.loads(path.read_bytes());retained['scripts'].update(manifest['code_sha256'])
    retained['retained_scripts']=len(retained['scripts']);retained['updated_utc']=stamp()
    retained['latest_nations_rolling_review']=dict(status='PASS',manifest_sha256=file_sha256(RESULT/'manifest.json'),path=str(RESULT.relative_to(ROOT_OUT)),adopted=False)
    dump(path,retained)
    from final_pipeline import discard_work
    discard_work(WORK)
    print(json.dumps(dict(status='PASS',report=str(RESULT/'report.html'),completed_work_removed=True)),flush=True)

def report():
    annual=pd.read_csv(RESULT/'forecast_annual.csv');summary=pd.read_csv(RESULT/'trading_summary.csv');months=pd.read_csv(RESULT/'trading_months.csv')
    windows=pd.read_csv(RESULT/'forecast_windows.csv');base=pd.read_csv(RESULT/'prior_baseline.csv');overlap=pd.read_csv(RESULT/'monthly_overlap.csv')
    uncertainty=json.loads((RESULT/'uncertainty.json').read_bytes());v=json.loads((RESULT/'final_validation.json').read_bytes())
    notes=[
        'CORRECTION: The previous nations_strategy_review report is invalid. Its player-history search compared microsecond integers with nanosecond cutoffs and admitted future player statistics. The earlier 7-bet profit result is withdrawn. This study explicitly normalizes to nanoseconds and checks every player lookup against a direct Timestamp filter. No live model used this Nations research code.',
        '451 verified Nations matches are available, including 42 added October matches. Evaluate 447 unique matches from March 2022 through October 5, 2026, using the four 2021 matches as possible prior history. Two variants produce 894 forecasts over 64 daily fitting boundaries. The variants do not double the independent sample.',
        'The primary variant uses all earlier club and national feature rows; the fixed comparator uses the previous 24 calendar months. Both refit before the earliest T-12-hour forecast on each match date. All fitting and calibration labels precede that boundary. Calibration uses the last 180 days with its training labels purged before the calibration period. Model recipe and thresholds are unchanged; no search for the best result.',
        'National match form uses earlier Nations matches. Player form uses earlier club and national appearances through verified person links; roster weights use only prior national appearances. Missing xG/action ratios and club-strength fields remain missing and use training-only imputation. Other international friendlies/qualifiers are not national form inputs here. Club model feature history ends September 20, 2026.',
        'US quote coverage is 94 completed September/October matches. Four March 2026 games have no exact US match. Older international Polymarket/Kalshi files are cataloged separately and never substituted for US prices. No US trading returns are claimed for 2022-2025 or unpriced matches.',
        'The confidence model uses the same recipe, refitted at each US match-date boundary using earlier club out-of-sample examples, with the last 60 examples for calibration and label purging. Nations outcomes do not train this confidence gate. This remains a transfer model, not a nationally calibrated confidence model.',
        'Buy selected-outcome YES only when p>51% and confidence>55%. Primary timing is first qualifying five-minute decision from T-12 hours; T-1 hour is a fixed reference. Starting cash/allocation $2,000, soccer hard cap $900, budget $5*max(100p-51,0). Cash carries across dates and months without resetting. Separate accounts are used for each declared variant/scenario.',
        'Fills are assumed at historical YES display asks, which are normally book-derived asks. Historical queue, depth, open/closed status and actual order fills are not reconstructed. The app midpoint/ask split and five-minute cancel/replace are not replayed. Minute histories allow at most 60 seconds of quote age versus the live 30-second rule.',
        'Gross results exclude fees. Fee-estimate scenarios use the conservative coefficient .05 reserve formula, rounded up with a one-cent buffer. These are not verified historical fees. Settlement uses official result availability and assumes immediate cash release; exchange payout delay is unknown. Open equity is held at purchase cost, so drawdown excludes intramatch mark-to-market movements.',
        'September has already been inspected. October is a later retrospective extension, not a prospective holdout. The current recipe was selected in earlier research; rolling chronology does not remove that selection history. Date-block bootstrap intervals describe uncertainty in this dataset and do not establish future performance.',
        'The corrected monthly baseline is refitted on corrected player inputs. It is not the invalid prior report. Always-home accuracy and a Laplace-smoothed earlier Nations class-frequency baseline provide simple controls.',
        'The source replay checks include '+str(v['price_points_replayed'])+' raw price observations and '+str(v['new_official_games_replayed'])+' new official fixture records. Representative fits reproduce after future labels/features are poisoned and after future rows are removed. Every selected player history matches a direct earlier-only Timestamp filter.',
        'No Nations League deployment or real order submission was performed. Reproduce with nations_rolling_review.py stages collect, prepare, fit, prices, analyze, publish; reviewed existing publications must not be overwritten. Canonical source evidence and the completed study remain; temporary model fits and duplicate input matrices are discarded.'
    ]
    simple=summary[summary.timing.eq('first_T12')][['arm','cost_scenario','bets','wins','profit','return_pct','max_drawdown_pct','fees']]
    displayed=annual[['arm','year','games','wins','accuracy_pct','log_loss','brier','home_baseline_pct']]
    tables=[('Rolling forecast results',displayed),('Primary trading simulation',simple),('Trading by month',months[months.timing.eq('first_T12')]),
        ('Match windows',windows[['arm','period','games','accuracy_pct','log_loss','home_baseline_pct']]),('Simple prior-frequency control',base[['year','games','accuracy_pct','log_loss','brier']]),
        ('Corrected monthly comparison',overlap),('All timing and fee scenarios',summary)]
    text='UEFA Nations League daily rolling study\n\n'+'\n\n'.join(notes)+'\n\nUncertainty\n'+json.dumps(uncertainty,indent=2)+'\n\n'
    text+='\n\n'.join(title+'\n'+frame.to_string(index=False) for title,frame in tables)
    (RESULT/'report.txt').write_text(text,encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    rolling=pd.read_csv(RESULT/'rolling50.csv');daily=pd.read_parquet(RESULT/'daily.parquet')
    fig,axes=plt.subplots(2,1,figsize=(11,8),layout='constrained')
    for arm in ARMS:
        r=rolling[rolling.arm.eq(arm)];axes[0].plot(pd.to_datetime(r.date),r.last50_accuracy_pct,label=arm)
        c=daily[daily.arm.eq(arm)&daily.timing.eq('first_T12')&daily.cost_scenario.eq('fee_estimate')&daily['at'].ge(pd.Timestamp('2026-09-23',tz='UTC'))]
        axes[1].plot(c['at'],c.equity,label=arm)
    axes[0].set(title='Accuracy over the last 50 chronological matches',ylabel='Percent correct')
    axes[1].set(title='US quote-fill simulation with estimated fees; open positions valued at cost',ylabel='Account USD')
    for ax in axes:ax.legend();ax.grid(alpha=.25)
    fig.savefig(RESULT/'rolling_results.png',dpi=160);plt.close(fig)
    body='<!doctype html><html lang="en"><meta charset="utf-8"><title>Nations rolling study</title><style>body{max-width:1250px;margin:30px auto;padding:0 20px;font:16px/1.5 system-ui;color:#172238}table{border-collapse:collapse;font-size:13px;margin:20px 0}td,th{padding:8px;border:1px solid #d4d9e1;text-align:right}th{background:#edf3fa}.table{overflow:auto}img{max-width:100%}.correction{background:#fff0da;padding:16px;border-left:5px solid #b45309}</style><h1>Nations League daily rolling study</h1><p>Completed '+html.escape(stamp())+'</p><p class="correction">'+html.escape(notes[0])+'</p>'
    body+='<img src="rolling_results.png" alt="Rolling accuracy and account equity">'+''.join('<h2>'+title+'</h2><div class="table">'+frame.to_html(index=False,float_format=lambda x:f'{x:.4f}')+'</div>' for title,frame in tables)
    body+='<h2>Validation and limitations</h2>'+''.join('<p>'+html.escape(n)+'</p>' for n in notes[1:])+'<pre>'+html.escape(json.dumps(uncertainty,indent=2))+'</pre><p><a href="bets.parquet">Trade data</a> | <a href="trading_summary.csv">Trading CSV</a> | <a href="forecast_annual.csv">Forecast CSV</a> | <a href="final_validation.json">Validation</a> | <a href="catalog.csv">Data catalog</a></p></html>'
    (RESULT/'report.html').write_text(body,encoding='utf-8')

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('stage',choices=['collect','prepare','fit','prices','analyze','validate','publish']);args=a.parse_args();globals()[args.stage]()
