"""Compare actual shift API rows against the NHL public time-on-ice report."""
import hashlib,html,json,re,unicodedata
from common import ROOT_OUT,PROJECT,OfficialClient,read_db,dump

def text(value):return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]+>',' ',value))).strip()
def key(value):return re.sub('[^a-z]','',unicodedata.normalize('NFKD',value).encode('ascii','ignore').decode().lower())
def seconds(value):a,b=map(int,value.split(':'));return 60*a+b

def main():
    with read_db(ROOT_OUT/'nhl_shifts.sqlite') as c:games=[json.loads(b) for b, in c.execute('SELECT body FROM games LIMIT 3')]
    client=OfficialClient();results=[]
    for g in games:
        native=g['official_game_id'];season=int(native[:4]);url=f'https://www.nhl.com/scores/htmlreports/{season}{season+1}/TH{native[4:]}.HTM'
        body,source=client.get(url,'Validate NHL shift intervals against official public report '+native,kind='official_shift_report',document=True)
        assert body,source['return_status'];markup=body.decode('utf8',errors='replace');names={};allraw={}
        for s in g['sources']:
            raw=(PROJECT/s['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==s['sha256']
            for r in json.loads(raw)['data']:
                names[key(r['lastName']+', '+r['firstName'])]=str(r['playerId']);allraw[r['id']]=r
        for r in g['rows']:
            raw=allraw[r['shift_id']]
            assert seconds(raw['startTime'])==r['start_seconds'] and seconds(raw['endTime'])==r['end_seconds']
            assert seconds(raw['duration'])==r.get('source_duration_seconds',r['duration_seconds'])
            assert r['end_seconds']-r['start_seconds']==r['duration_seconds']
        headings=list(re.finditer(r'<td[^>]*class="playerHeading[^\"]*"[^>]*>(.*?)</td>',markup,re.S))
        examples=[];unmatched=[];conflicts=[]
        for i,m in enumerate(headings):
            name=re.sub(r'^\d+\s+','',text(m.group(1)));pid=names.get(key(name))
            if pid is None:unmatched.append(name);continue
            section=markup[m.end():headings[i+1].start() if i+1<len(headings) else len(markup)];reported=[]
            for tr in re.findall(r'<tr class="\s*(?:oddColor|evenColor)[^\"]*"[^>]*>(.*?)</tr>',section,re.S):
                cells=[text(x) for x in re.findall(r'<td[^>]*>(.*?)</td>',tr,re.S)]
                if len(cells)<5 or not cells[0].isdigit() or not cells[1].isdigit() or '/' not in cells[2]:continue
                reported.append((int(cells[0]),int(cells[1]),seconds(cells[2].split('/')[0].strip()),seconds(cells[3].split('/')[0].strip()),seconds(cells[4])))
            observed=[(r['shift_number'],r['period'],r['start_seconds'],r['end_seconds'],r['duration_seconds']) for r in g['rows'] if r['player_id']==pid]
            if sorted(reported)!=sorted(observed):conflicts.append(dict(player_id=pid,name=name,report_rows=len(reported),api_rows=len(observed)))
            else:examples.append(dict(player_id=pid,name=name,matched_shifts=len(observed)))
        assert len(examples)>=3,'Fewer than three exact player examples in official public report'
        results.append(dict(game_id=g['game_id'],date=g['date'],raw_normalized_rows_checked=len(g['rows']),public_verification_url=url,public_source=source,exact_player_matches=examples,unmatched_names=unmatched,public_report_conflicts=conflicts,boxscore_duration_discrepancies=g['time_on_ice_discrepancies']))
    dump(ROOT_OUT/'nhl_shift_validation.json',results)
    print(json.dumps([dict(game_id=r['game_id'],raw_rows=r['raw_normalized_rows_checked'],exact_players=len(r['exact_player_matches']),public_conflicts=len(r['public_report_conflicts'])) for r in results]),flush=True)

if __name__=='__main__':main()
