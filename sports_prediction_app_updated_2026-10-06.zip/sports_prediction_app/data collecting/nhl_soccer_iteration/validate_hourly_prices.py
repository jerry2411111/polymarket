"""Raw-value validation and unchanged-forecast comparison of closer quotes."""
import argparse,hashlib,json
import numpy as np
import pandas as pd
from common import ROOT_OUT,PROJECT,REPORTS,dump,stamp
from backtest import attach,select,simulate,quote_inputs
from forecast_pairing import paired_predictions
from cash_validation import validate_cash

RUN=ROOT_OUT/'hourly_prices_v61'


def validate(folder):
    f=pd.read_parquet(folder/'quotes.parquet');plan=json.loads((folder/'plan.json').read_bytes());assert len(f)==plan['rows']
    rawrows=0;maxage=[]
    for r in f.itertuples():
        meta=json.loads(r.source_json);assert meta['return_status']=='200';raw=(PROJECT/meta['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==meta['sha256']
        data=json.loads(raw);assert isinstance(data['history'],list);points=data['history'];rawrows+=len(points);assert len(points)==r.history_rows
        assert all(isinstance(x.get('t'),(int,float)) and isinstance(x.get('p'),(int,float)) and np.isfinite(x['p']) and 0<=x['p']<=1 for x in points)
        cut=r.decision_utc;usable=[(x['t'],i,x) for i,x in enumerate(points) if cut-pd.Timedelta(hours=24)<=pd.Timestamp(x['t'],unit='s',tz='UTC')<=cut]
        if not usable:assert r.status=='empty_before_cutoff' and not r.replace_old;continue
        t,i,p=max(usable);assert len({x['p'] for x in points if x['t']==t})==1
        at=pd.Timestamp(t,unit='s',tz='UTC');assert r.status=='recovered' and p['p']==r.new_price and at==r.new_source_utc==r.new_available_utc
        assert r.new_pointer=='/history/'+str(i)+'/p' and r.replace_old==(at>r.entry_available_utc)
        assert np.isclose((cut-at).total_seconds()/3600,r.new_age_hours);maxage.append(r.new_age_hours)
    report=dict(status='PASS',at_utc=stamp(),outcomes=len(f),raw_price_points=rawrows,closer_observations=int(f.replace_old.sum()),changed_prices=int((f.replace_old&f.new_price.ne(f.entry_price)).sum()),max_recovered_age_hours=max(maxage) if maxage else None,all_eligible_timestamps_at_or_before_cutoff=True,original_data_unchanged=True)
    dump(folder/'raw_validation.json',report);return f


def overlay(old,updates):
    q=old.copy();q['hourly_overlay']=False
    q=q.set_index(['provider','game_id','class_index','decision_utc']);updates=updates[updates.replace_old].set_index(['provider','game_id','class_index','decision_utc'])
    assert updates.index.is_unique and updates.index.isin(q.index).all()
    for c,source in [('entry_price','new_price'),('entry_source_utc','new_source_utc'),('entry_available_utc','new_available_utc'),('entry_age_hours','new_age_hours'),('entry_pointer','new_pointer')]:q.loc[updates.index,c]=updates[source]
    q.loc[updates.index,'entry_request_id']=updates.source_json.map(lambda x:'nhl_soccer_iteration:'+str(json.loads(x)['request_number']))
    q.loc[updates.index,'price_basis']='polymarket_clob_hourly_historical_price';q.loc[updates.index,'decimal_odds']=1/updates.new_price.replace(0,np.nan);q.loc[updates.index,'hourly_overlay']=True
    return q.reset_index()


def evaluate(updates,folder,year,month):
    old=quote_inputs(folder/'old_quote_quality.json');new=overlay(old,updates);new.to_parquet(folder/'quote_overlay.parquet',index=False)
    summary=[];bets=[];curves=[]
    for sport in ['nhl','soccer']:
        stage='evaluation' if year==2026 else 'development'
        source=ROOT_OUT/'retained_models'/sport/(stage+'_predictions.parquet');p=pd.read_parquet(source)
        p=paired_predictions(p,'retained') if sport=='nhl' else p[p.variant.eq('context_league')]
        if month:p=p[p.prediction_time.dt.month.eq(month)]
        for version,q in [('original_quotes',old),('closer_hourly_quotes',new)]:
            joined,audit=attach(p,q);dump(folder/(sport+'_'+version+'_matching.json'),audit)
            for provider,g in joined.groupby('provider'):
                chosen=select(g,'expected_profit' if sport=='nhl' else 'edge_any')
                if sport=='nhl':
                    second=np.array([r['second_p'+str(int(r['quote_class']))] for r in chosen.to_dict('records')]);chosen=chosen[second/chosen.entry_price.to_numpy()>=1.10]
                s,t,c=simulate(chosen,year);meta=dict(sport=sport,provider=provider,recipe=version)
                summary.append(meta|s)
                if len(t):bets.append(t.assign(**meta,year=year))
                curves.append(c.assign(**meta,year=year))
    annual=pd.DataFrame(summary);b=pd.concat(bets,ignore_index=True);d=pd.concat(curves,ignore_index=True)
    checks=validate_cash(b,d)
    annual.to_csv(folder/'annual_comparison.csv',index=False);b.to_parquet(folder/'comparison_bets.parquet',index=False);d.to_parquet(folder/'comparison_daily.parquet',index=False)
    annual.to_csv(REPORTS/(folder.parent.name+'_comparison_'+folder.name+'.csv'),index=False)
    # The overlay must not change another provider or an unrequested year.
    keys=['provider','game_id','class_index','decision_utc'];untouched=~new.hourly_overlay
    a=new[untouched].set_index(keys).sort_index();b=old.set_index(keys).loc[a.index]
    pd.testing.assert_frame_equal(a.drop(columns='hourly_overlay'),b,check_exact=True)
    coverage=[]
    for sport,g in updates.groupby('sport'):
        coverage.append(dict(sport=sport,year=year,month=month,outcomes=len(g),recovered=int(g.status.eq('recovered').sum()),closer=int(g.replace_old.sum()),price_changes=int((g.replace_old&g.new_price.ne(g.entry_price)).sum()),old_mean_age_hours=float(g.entry_age_hours.mean()),new_mean_age_hours=float(np.where(g.replace_old,g.new_age_hours,g.entry_age_hours).mean())))
    pd.DataFrame(coverage).to_csv(folder/'coverage.csv',index=False)
    dump(folder/'validation.json',dict(status='PASS',at_utc=stamp(),daily_cash_checks=checks,original_forecasts_stakes_and_rules_unchanged=True,other_provider_and_untouched_quotes_exact=True,period=folder.name,no_model_selection=True,target_claimed=False))
    complete=json.loads((folder/'complete.json').read_bytes());complete['state']='hourly recovery, raw validation and fixed-model comparison complete';dump(folder/'complete.json',complete)
    print(pd.DataFrame(coverage).to_string(index=False),flush=True);print(annual.to_string(index=False),flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--year',type=int,required=True);parser.add_argument('--month',type=int);args=parser.parse_args();label=str(args.year)+(f'-{args.month:02}' if args.month else '')
    folder=RUN/label;updates=validate(folder);evaluate(updates,folder,args.year,args.month)


if __name__=='__main__':main()
