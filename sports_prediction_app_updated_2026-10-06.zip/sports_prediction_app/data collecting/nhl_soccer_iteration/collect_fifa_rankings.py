"""Official dated FIFA points; the public page supplies schedule IDs, not ranks."""
import datetime as dt
import hashlib
import json
import re
import sqlite3
from urllib.parse import urlencode

import pandas as pd
from common import OfficialClient, PROJECT, ROOT_OUT, dump, read_db, stamp

PAGE = 'https://inside.fifa.com/fifa-rankings/world-ranking/men'
API = 'https://api.fifa.com/api/v3/fifarankings/rankings/rankingsbyschedule'


def main():
    client = OfficialClient(per_second=2)
    client.HOSTS = client.HOSTS | {'inside.fifa.com', 'api.fifa.com'}
    html, schedule_source = client.get(PAGE, 'Official FIFA publication dates and historical ranking schedule IDs', 'official_documentation', document=True)
    assert html is not None
    data = json.loads(re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', html.decode('utf8')).group(1))
    config = data['props']['pageProps']['pageData']['ranking']
    dates = sorted([d for year in config['dates'] for d in year['dates'] if '2021-01-01' <= d['iso'][:10] <= '2026-09-30'], key=lambda d: d['iso'])
    assert len({d['id'] for d in dates}) == len(dates)
    teams = {}
    with read_db(ROOT_OUT / 'nations_league.sqlite') as db:
        games = pd.read_sql_query('SELECT * FROM nations_league_games', db)
    cache = {}
    for g in games.to_dict('records'):
        if g['source_raw_file'] not in cache:
            blob = (PROJECT / g['source_raw_file']).read_bytes()
            assert hashlib.sha256(blob).hexdigest() == g['source_sha256']
            cache[g['source_raw_file']] = json.loads(blob)
        raw = cache[g['source_raw_file']][int(g['pointer'].strip('/'))]
        for side, key in [('A', 'awayTeam'), ('B', 'homeTeam')]:
            team = raw[key]
            native = 'UEFA_NATIONAL:' + str(team['id'])
            identity = dict(team_id=native, team_name=g['team' + side], country_code=team['countryCode'])
            if native in teams:
                assert teams[native] == identity
            teams[native] = identity
    countries = {r['country_code']: r for r in teams.values()}
    assert len(countries) == len(teams)
    rows, proof = [], []
    milestone = 10
    for i, date in enumerate(dates, 1):
        url = API + '?' + urlencode(dict(rankingScheduleId=date['id'], language='en'))
        body, source = client.get(url, 'Official published FIFA national-team ranking ' + date['iso'][:10], 'official_team_rankings')
        assert isinstance(body, dict) and isinstance(body.get('Results'), list), source
        assert not body.get('ContinuationToken') and not body.get('ContinuationHash'), 'Unexhausted official ranking response; do not publish a partial date'
        rankings = body['Results']
        assert len(rankings) > 150 and len({r['IdTeam'] for r in rankings}) == len(rankings)
        matched = set()
        for index, raw in enumerate(rankings):
            if raw['IdCountry'] not in countries:
                continue
            assert raw['ConfederationName'] == 'UEFA' and raw['Gender'] == 1
            identity = countries[raw['IdCountry']]
            assert raw['Rank'] > 0 and raw['TotalPoints'] > 0
            # Date-only historical releases do not establish midnight availability.
            # Use the following UTC day for every publication, conservatively.
            available = (dt.date.fromisoformat(date['iso'][:10]) + dt.timedelta(days=1)).isoformat() + 'T00:00:00+00:00'
            row = identity | dict(fifa_team_id=str(raw['IdTeam']), fifa_team_name=raw['TeamName'][0]['Description'],
                publication_date=date['iso'][:10], available_at_utc=available, ranking_schedule_id=date['id'],
                world_rank=raw['Rank'], ranking_points=raw['TotalPoints'],
                source_request_id=source['request_number'], source_url=url, source_raw_file=source['raw_file'], source_sha256=source['sha256'],
                raw_pointer='/Results/' + str(index), schedule_source_request_id=schedule_source['request_number'])
            rows.append(row)
            matched.add(identity['team_id'])
        assert matched == set(teams), (date, sorted(set(teams) - matched))
        proof.append(dict(schedule=date, source=source, total_ranked_teams=len(rankings), matched_teams=len(matched)))
        if i * 100 >= milestone * len(dates):
            print(json.dumps(dict(stage='fifa_rankings', complete_pct=i * 100 // len(dates), schedules=i, total=len(dates))), flush=True)
            milestone = i * 100 // len(dates) // 10 * 10 + 10
    frame = pd.DataFrame(rows)
    assert not frame.duplicated(['team_id', 'publication_date']).any()
    with sqlite3.connect(ROOT_OUT / 'nations_league.sqlite') as db:
        frame.to_sql('nations_fifa_rankings', db, if_exists='replace', index=False)
        db.execute('CREATE INDEX IF NOT EXISTS nations_fifa_asof ON nations_fifa_rankings(team_id,available_at_utc)')
    frame.to_csv(ROOT_OUT / 'nations_fifa_rankings.csv', index=False)
    frame.to_parquet(ROOT_OUT / 'nations_fifa_rankings.parquet', index=False)
    dump(ROOT_OUT / 'nations_fifa_acquisition.json', dict(at_utc=stamp(), rows=len(frame), teams=len(teams), schedules=len(dates),
        first_publication=frame.publication_date.min(), last_publication=frame.publication_date.max(), schedule_source=schedule_source,
        requests=proof, identity_policy='Exact official FIFA/UEFA country code; retain both native IDs and both source names. No fuzzy name matching.',
        publication_policy='Use day after official publication date, never the date encoded in the opaque schedule ID.',
        source_note='Official public FIFA API route observed from its ranking page; no formal API schema was available. Actual ranking rows come only from API JSON.'))
    print(json.dumps(dict(rows=len(frame), teams=len(teams), schedules=len(dates))), flush=True)


if __name__ == '__main__':
    main()
