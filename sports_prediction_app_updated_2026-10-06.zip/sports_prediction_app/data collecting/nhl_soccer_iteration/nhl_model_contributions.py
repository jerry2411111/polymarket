"""Replay prior-only NHL fits and explain log expected-goal ratio by input group.

Contributions explain a fitted model, not causal player effects. No new model,
trading rule or2026selection is performed.
"""
import collections
import json
import numpy as np
import pandas as pd
from scipy.stats import skellam
from threadpoolctl import threadpool_limits

import models
from common import ROOT_OUT,dump,stamp,file_sha256


def category(field):
    if field.startswith('missingindicator_'):return 'observation_indicators'
    if any(s in field for s in ['rest_days','back_to_back','games_7d','workload']):return 'rest_and_workload'
    if 'goalie' in field:return 'goalkeeper_history'
    if 'onice' in field:return 'on_ice_player_history'
    if 'role_' in field:return 'individual_skater_history'
    if 'f_gran_' in field:return 'team_chance_and_special_teams'
    return 'team_strength_and_scores'


def component_errors(frame,bets):
    """Exact error decomposition, with no selected-score threshold or new fit."""
    data=frame.copy()
    data['class_index']=data[['p0','p1']].to_numpy().argmax(axis=1)
    data['provider']='all_forecasts';data['scope']='predicted_winner'
    selected=bets.merge(frame,on=['game_id','year'],validate='many_to_one',suffixes=('_bet',''))
    selected['scope']='funded_outcome'
    rows=[]
    for (provider,year,scope),g in pd.concat([data,selected],ignore_index=True).groupby(['provider','year','scope']):
        home=g.class_index.eq(1)
        won=g.target.eq(g.class_index).astype(float)
        predicted=np.where(home,g.p1,g.p0)
        regulation_p=np.where(home,g.regulation_home_p,g.regulation_away_p)
        ot_conditional_p=np.where(home,g.home_overtime_p,1-g.home_overtime_p)
        extra_p=g.regulation_tie_p*ot_conditional_p
        tied=g.regulation_scoreA.eq(g.regulation_scoreB)
        regulation_won=np.where(home,g.regulation_scoreB>g.regulation_scoreA,g.regulation_scoreA>g.regulation_scoreB).astype(float)
        extra_won=(tied&won.eq(1)).astype(float)
        calibration=predicted-regulation_p-extra_p
        reg_error=regulation_p-regulation_won;extra_error=extra_p-extra_won
        assert np.allclose(reg_error+extra_error+calibration,predicted-won,rtol=0,atol=1e-12)
        rows.append(dict(provider=provider,year=int(year),scope=scope,games=len(g),
            mean_probability=float(np.mean(predicted)),win_rate=float(won.mean()),
            total_probability_error=float(np.mean(predicted-won)),
            regulation_win_error=float(np.mean(reg_error)),overtime_win_error=float(extra_error.mean()),
            calibration_adjustment=float(np.mean(calibration)),predicted_tie_rate=float(g.regulation_tie_p.mean()),
            observed_tie_rate=float(tied.mean()),
            mean_overtime_skill_adjustment=float((g.regulation_tie_p*(ot_conditional_p-.5)).mean()),
            max_absolute_overtime_skill_adjustment=float(abs(g.regulation_tie_p*(ot_conditional_p-.5)).max()),
            selected_expected_goals=float(np.where(home,g.expected_home_goals,g.expected_away_goals).mean()),
            selected_observed_goals=float(np.where(home,g.regulation_scoreB,g.regulation_scoreA).mean()),
            opponent_expected_goals=float(np.where(home,g.expected_away_goals,g.expected_home_goals).mean()),
            opponent_observed_goals=float(np.where(home,g.regulation_scoreA,g.regulation_scoreB).mean())))
    return pd.DataFrame(rows)


def main():
    folder=ROOT_OUT/'simulation_results/nhl_model_contributions';folder.mkdir(exist_ok=True)
    source=ROOT_OUT/'retained_models/nhl/nhl_features.parquet';data=pd.read_parquet(source)
    data=pd.concat([data,pd.get_dummies(data.league,prefix='league',dtype=float)],axis=1)
    forecasts=pd.read_parquet(ROOT_OUT/'retained_models/nhl/development_predictions.parquet')
    forecasts=forecasts[forecasts.variant.eq('granular_regulation_ot')]
    spec=models.CANDIDATES['granular_regulation_ot'];cols=models.columns(data,spec)
    output=[];largest=[];folds=[]
    for fold,p in forecasts.groupby('fold'):
        boundary=pd.Timestamp(fold+'-01',tz='UTC');train=data[data.available_time.lt(boundary)]
        test=data.set_index('game_id').loc[p.game_id];assert train.available_time.max()<test.prediction_time.min()
        fitted=models.make_model(spec,'nhl')
        with threadpool_limits(limits=4):models.fit_model(fitted,train[cols],train,spec,boundary)
        calibrator=dict(kind='temperature',temperature=float(p.temperature.iloc[0]),bias=json.loads(p.calibration_bias_json.iloc[0]))
        replay=models.apply_calibration(fitted.predict_proba(test[cols]),calibrator)
        assert np.allclose(replay,p[['p0','p1']],rtol=0,atol=1e-12)
        a,b=fitted.models;za=a[:-1].transform(test[cols]);zb=b[:-1].transform(test[cols])
        assert np.allclose(za,zb,rtol=0,atol=0)
        names=list(a[0].get_feature_names_out(cols));contrib=za*(b[-1].coef_-a[-1].coef_)
        intercept=float(b[-1].intercept_-a[-1].intercept_)
        rate_a,rate_b=a.predict(test[cols]),b.predict(test[cols])
        assert np.allclose(contrib.sum(axis=1)+intercept,np.log(rate_b/rate_a),rtol=0,atol=1e-12)
        clipped_a,clipped_b=np.clip(rate_a,.05,15),np.clip(rate_b,.05,15)
        tie=skellam.pmf(0,clipped_a,clipped_b)
        away=skellam.sf(0,clipped_a,clipped_b);home=skellam.cdf(-1,clipped_a,clipped_b)
        ot=fitted.overtime_model.predict_proba(test[fitted.ot_columns])[:,1] if fitted.overtime_model is not None else np.full(len(test),.5)
        uncalibrated=np.column_stack([away+tie*(1-ot),home+tie*ot])
        assert np.allclose(uncalibrated,fitted.predict_proba(test[cols]),rtol=0,atol=1e-12)
        assert test[['regulation_scoreA','regulation_scoreB']].notna().all().all()
        groups=collections.defaultdict(list)
        for j,c in enumerate(names):groups[category(c)].append(j)
        for i,r in enumerate(p.itertuples()):
            row=dict(game_id=r.game_id,fold=fold,year=r.prediction_time.year,target=r.target,p0=r.p0,p1=r.p1,
                expected_away_goals=rate_a[i],expected_home_goals=rate_b[i],intercept=intercept,
                regulation_away_p=away[i],regulation_home_p=home[i],regulation_tie_p=tie[i],home_overtime_p=ot[i],
                regulation_scoreA=test.iloc[i].regulation_scoreA,regulation_scoreB=test.iloc[i].regulation_scoreB)
            for group,js in groups.items():row[group]=float(contrib[i,js].sum())
            output.append(row)
            order=np.argsort(abs(contrib[i]))[-3:][::-1]
            for j in order:largest.append(dict(game_id=r.game_id,year=r.prediction_time.year,field=names[j],contribution=float(contrib[i,j])))
        folds.append(dict(fold=fold,training_games=len(train),replayed_forecasts=len(p)))
        print(json.dumps(dict(stage='nhl_contribution_replay',fold=fold,forecasts=len(p))),flush=True)
    frame=pd.DataFrame(output);frame.to_parquet(folder/'forecast_contributions.parquet',index=False)
    pd.DataFrame(largest).to_csv(folder/'largest_contributions.csv',index=False)
    bets=pd.read_parquet(ROOT_OUT/'simulation_results/current/bets.parquet')
    bets=bets[bets.sport.eq('nhl')&bets.year.isin([2024,2025])&bets.recipe.eq('fixed')]
    joined=bets.merge(frame.drop(columns=['year','target','p0','p1']),on='game_id',validate='many_to_one')
    groups=list(groups)
    records=[]
    for (provider,year),g in joined.groupby(['provider','year']):
        direction=np.where(g.class_index.eq(1),1.,-1.)
        for group in groups:
            value=g[group]*direction
            for label,mask in [('supports_bought_side',value>0),('opposes_bought_side',value<0)]:
                part=g[mask]
                if not len(part):continue
                records.append(dict(provider=provider,year=int(year),group=group,direction=label,bets=len(part),
                    mean_contribution=float(value[mask].mean()),mean_probability=float(part.probability.mean()),
                    win_rate=float(part.won.mean()),mean_unit_return=float(part.unit_return.mean()),
                    mean_price=float(part.price.mean())))
    summary=pd.DataFrame(records);summary.to_csv(folder/'conditional_contributions.csv',index=False)
    components=component_errors(frame,bets)
    components.to_csv(folder/'scoring_component_errors.csv',index=False)
    report=dict(at_utc=stamp(),status='PASS',source_sha256=file_sha256(source),forecasts=len(frame),
        bets=len(joined),folds=folds,log_intensity_identity_checked=True,forecast_replays=len(frame),
        used2026=False,causal_interpretation=False,adopted=False,probability_component_identity_checked=True,
        component_summary_rows=len(components))
    dump(folder/'validation.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
