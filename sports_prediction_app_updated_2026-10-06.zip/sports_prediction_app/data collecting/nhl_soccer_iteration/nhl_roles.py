"""Add goalie workload, role-specific roster quality and long/short form."""
import collections
import json
import math
import numpy as np
import pandas as pd
from common import ROOT_OUT,PREVIOUS,read_db,dump

def val(x):
    try:return float(x) if math.isfinite(float(x)) else np.nan
    except (ValueError,TypeError):return np.nan

def main(base=None, games=None, history_keys=None, save=True):
    folder=ROOT_OUT/'nhl_roles_v2'
    if save:folder.mkdir(exist_ok=True)
    if base is None:base=pd.read_parquet(ROOT_OUT/'nhl_features.parquet')
    with read_db(PREVIOUS/'expanded.sqlite') as c:
        if games is None:games=pd.read_sql_query("SELECT * FROM nhl_games WHERE phase IN ('Regular Season','Playoffs')",c)
        else:games=games.copy()
        players=pd.read_sql_query('SELECT * FROM nhl_player_games',c)
        teams=pd.read_sql_query('SELECT * FROM nhl_team_observations',c)
    with read_db(ROOT_OUT/'granular.sqlite') as c:
        goalies=pd.read_sql_query('SELECT * FROM nhl_goalie_game_quality',c)
        shooters=pd.read_sql_query('SELECT * FROM nhl_shooter_game_quality',c)
        q=pd.read_sql_query('SELECT * FROM nhl_team_shot_quality',c)
    keys=['game_id','side','official_player_id']
    goalies=goalies.rename(columns={'defending_side':'side','goalie_id':'official_player_id','goals_against':'shot_event_goals_against'})
    shooters=shooters.rename(columns={'player_id':'official_player_id','goals':'shot_event_goals'})
    for f in [players,goalies,shooters]:f.official_player_id=f.official_player_id.astype(str)
    players=players.merge(goalies,on=keys,how='left',validate='one_to_one').merge(shooters,on=keys,how='left',validate='one_to_one')
    players['goals_saved_above_model']=players.model_xg_against-players.shot_event_goals_against
    teams=teams.merge(q,on=['game_id','side'],how='left',validate='one_to_one')
    for col in ['available_time','prediction_time','start_time']:games[col]=pd.to_datetime(games[col],utc=True)
    pmap=collections.defaultdict(list)
    for r in players.to_dict('records'):pmap[(r['game_id'],r['side'])].append(r)
    tmap={(r['game_id'],r['side']):r for r in teams.to_dict('records')}
    history=collections.defaultdict(lambda:collections.deque(maxlen=82));ph=collections.defaultdict(lambda:collections.deque(maxlen=60));lastteam={};pos=0
    past=games.sort_values('available_time').to_dict('records');rows=[];currentseason={}
    teamstats=['score_for','score_against','shots_for','shots_against','sat_fraction_5v5','xg','xg_against','finishing_residual','model_goals_saved']
    def mean(h,field):
        values=[val(x.get(field)) for x in h];values=[x for x in values if np.isfinite(x)]
        return np.mean(values) if values else np.nan
    def player_rate(h,field,shrink=0):
        observations=[(val(r.get(field)),val(r.get('minutes'))) for r in h]
        observations=[(x,m) for x,m in observations if np.isfinite(x) and np.isfinite(m) and m>0]
        if not observations:return np.nan
        return 60*sum(x for x,m in observations)/(shrink+sum(m for x,m in observations))
    for g in games.sort_values('prediction_time').to_dict('records'):
        cutoff=g['prediction_time']
        while pos<len(past) and past[pos]['available_time']<cutoff:
            old=past[pos];pos+=1;ids=json.loads(old['native_team_ids_json'])
            for side,teamid in zip(['A','B'],ids):
                key=history_keys[(old['game_id'],side)] if history_keys is not None else str(teamid)
                r=dict(tmap[(old['game_id'],side)],available_time=old['available_time'],start_time=old['start_time'],season=old['season'])
                r['players']=[];r['player_minutes']={}
                for p in pmap[(old['game_id'],side)]:
                    if val(p.get('minutes'))>0:
                        p=dict(p,available_time=old['available_time'],start_time=old['start_time']);ph[p['player_id']].append(p);lastteam[p['player_id']]=key;r['players'].append(p['player_id']);r['player_minutes'][p['player_id']]=float(p['minutes'])
                history[key].append(r)
        ids=json.loads(g['native_team_ids_json']);sides=[];sources=[]
        for side,key in zip(['A','B'],map(str,ids)):
            if history_keys is not None:key=history_keys[(g['game_id'],side)]
            h=list(history[key]);f={}
            for stat in teamstats:
                f[stat+'_long']=mean(h,stat);f[stat+'_recent']=mean(h[-8:],stat)
                f[stat+'_change']=f[stat+'_recent']-f[stat+'_long']
            recentids={pid for r in h[-5:] for pid in r['players'] if lastteam[pid]==key}
            roles=collections.defaultdict(list)
            for pid in sorted(recentids):
                playerhistory=list(ph[pid]);last=playerhistory[-1];role='goalie' if last['position']=='G' else ('defence' if last['position']=='D' else 'forward')
                recent_minutes=sum(r['player_minutes'].get(pid,0) for r in h[-5:])
                roles[role].append((pid,recent_minutes,playerhistory));sources.extend(r['available_time'] for r in playerhistory)
            for role in ['forward','defence','goalie']:
                people=roles[role]
                fields=['model_xg','goals','assists','shots_on_target','blocked_shots'] if role!='goalie' else ['goals_saved_above_model','shots_against']
                for field in fields:
                    for span in [10,60]:
                        rates=[(m,player_rate(hh[-span:],field,shrink=120 if field=='goals_saved_above_model' else 0)) for pid,m,hh in people]
                        rates=[(m,x) for m,x in rates if np.isfinite(x) and m>0]
                        f[role+'_'+field+'_per60_'+str(span)]=sum(m*x for m,x in rates)/sum(m for m,x in rates) if rates else np.nan
                f[role+'_observed_players']=len(people)
            # No future starter is assumed. The most-used recent goalie and the
            # observed alternatives are represented separately.
            goalies=sorted(roles['goalie'],key=lambda x:x[1],reverse=True)
            f['leading_goalie_rest_days']=(g['start_time']-goalies[0][2][-1]['start_time']).total_seconds()/86400 if goalies else np.nan
            f['alternative_goalie_gsax_per60']=player_rate(goalies[1][2],'goals_saved_above_model',120) if len(goalies)>1 else np.nan
            f['same_season_games']=sum(r['season']==g['season'] for r in h)
            f['back_to_back']=float(bool(h) and (g['start_time']-h[-1]['start_time']).total_seconds()<36*3600)
            if h:sources.extend(r['available_time'] for r in h)
            sides.append(f)
        r=dict(game_id=g['game_id'],role_source_max_available_utc=max(sources) if sources else None)
        assert not sources or max(sources)<cutoff
        for field in sides[0]:
            r['f_role_'+field+'_diff']=sides[1][field]-sides[0][field]
            # Shooting pace/goal variance depends on both sides' levels.
            if field.endswith('_long') or 'goalie' in field:r['f_role_'+field+'_sum']=sides[1][field]+sides[0][field]
        rows.append(r)
    added=pd.DataFrame(rows);output=base.merge(added,on='game_id',validate='one_to_one')
    if not save:return output
    output.to_parquet(folder/'nhl_features.parquet',index=False)
    dump(folder/'enrichment.json',dict(games=len(output),added_features=len([c for c in added if c.startswith('f_')]),total_features=len([c for c in output if c.startswith('f_')]),missing_pct={c:100*output[c].isna().mean() for c in added if c.startswith('f_')},description='Observed recent roster, position-specific per-60 rates, model xG finishing/goalie residuals, recent/long form and goalie rest. No future starter or confirmed future lineup.'))
    print(json.dumps(dict(games=len(output),added_features=len(added.columns)-2,total_features=len([c for c in output if c.startswith('f_')]))),flush=True)
    return output

if __name__=='__main__':main()
