"""Integrate verified La Liga sources into the current corrected-count branch.

Archive the old control exactly. Historical kickoff corrections and source
identity fixes are factual repairs, never contingent on trading returns.
"""
import argparse
import copy
import json
import sqlite3
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, PROJECT, REPORTS, read_db, dump, stamp, file_sha256

LABEL='soccer_laliga_current_history'
WORK=ROOT_OUT/'_work'/LABEL
RESULT=ROOT_OUT/'simulation_results'/LABEL
REFERENCE=ROOT_OUT/'simulation_results/soccer_source_count_rates'


def prepare():
    import soccer_source_count_rates as counts
    WORK.mkdir(parents=True,exist_ok=True);RESULT.mkdir(exist_ok=True)
    assert not (WORK/'sources_ready.json').exists(),'Resume an existing stage rather than rebuild it'
    plan=dict(at_utc=stamp(),
        previous_turn='Progress: recovered208native lineup windows, tested and rejected continuity and allocation variants; app and baselines preserved.',
        finding='Current corrected-count sources omit already validated FCBarcelona/Opta and Elche/LaLigaMaker player observations. The current optional club branch also owns12verified kickoff corrections, so those corrections are omitted by the ordinary source rebuild.',
        source_priority='Correct documented kickoff/availability independently of whether adding player statistics improves a model. Preserve old control for comparison; do not discard known source corrections on a return gate.',
        experiment='Reproduce original count-corrected41-input control. Apply known static person links and verified clocks, then separately integrate recovered player statistics with the same41-input recipe. No new betting thresholds or parameter grid.',
        gate='Player-stat extension must improve pooled2024/25logloss andBrier and2025logloss versus factual-repair control.2026is repeatedly inspected retrospective rolling research.',
        raw_sources='Official FCBarcelona public API republishes Opta; official Elche public match JSON republishes LaLigaMaker. Existing verified original responses are rehashed; native IDs and source clocks preserved.',
        documentation=['https://www.fcbarcelona.com/en/football/first-team/schedule','https://api-fcb.pulselive.com/football/fixtures/{native_fixture_id}',
                       'https://www.elchecf.es/_next/static/chunks/pages/_app-bbcca07184f495da.js','https://www.elchecf.es/_next/static/chunks/8168.2083131325c4ec44.js'],
        app_changed=False)
    dump(RESULT/'plan.json',plan)
    counts.WORK=WORK;counts.RESULT=WORK/'count_replay';counts.RESULT.mkdir(exist_ok=True)
    counts.build()
    proof=json.loads((REFERENCE/'feature_validation.json').read_bytes())
    assert file_sha256(WORK/'squad/soccer_features.parquet')==proof['candidate_hash']
    dump(RESULT/'control_reconstruction.json',dict(status='PASS',at_utc=stamp(),
        feature_sha256=proof['candidate_hash'],source_player_hash=file_sha256(WORK/'players.pkl')))


def verify_recovered():
    from validate_laliga_club import raw
    from laliga_recovered_features import records
    from laliga_club_players import parse as parse_player
    from laliga_maker_features import records as maker_records
    from validate_laliga_maker import pointer
    from laliga_maker_api import FIELDS
    games,people=records();lookup={(g['game_id'],r['official_player_id']):r for g in games for r in g['players']}
    sources={};cells=0
    def read(src,json_body=True):
        if src['sha256'] not in sources:sources[src['sha256']]=raw(src)
        return json.loads(sources[src['sha256']]) if json_body else sources[src['sha256']]
    for g in games:
        for src in g['sources']:read(src,False)
        assert g['minutes_complete'] and g['goal_counts_reconcile']
    for r in people:
        src=r['source'];again=parse_player(read(src),lookup[r['game_id'],r['official_player_id']],src)
        again['available_at_utc']=r['available_at_utc'];assert again==r
    makers=maker_records()
    for g in makers:
        body=read(g['source']);match=g['match']
        assert body['game']['id']==match['maker_game_id']
        assert pd.Timestamp(body['game']['time'])==pd.Timestamp(match['start_time'])
        assert [body['game']['awayScore'],body['game']['homeScore']]==[match['scoreA'],match['scoreB']]
        for r in g['players']+g['teams']:
            values=pointer(body,r['source_pointer']) if r['source_pointer'] else {};values=values or {}
            assert values==r['raw_stats']
            for field,native in FIELDS.items():assert r[field]==values.get(native);cells+=1
            if 'maker_player_id' in r:
                lineup=pointer(body,r['lineup_pointer'])
                assert lineup['player']['id']==r['maker_player_id'] and bool(lineup['starting'])==r['started']
    proof=dict(status='PASS',at_utc=stamp(),club_games=len(games),club_player_statistics=len(people),
        maker_games=len(makers),maker_cells=cells,original_responses_hashed=len(sources),
        club_database_sha256=file_sha256(ROOT_OUT/'laliga_club.sqlite'),maker_database_sha256=file_sha256(ROOT_OUT/'laliga_maker.sqlite'))
    dump(RESULT/'recovered_raw_validation.json',proof);print(json.dumps(proof),flush=True)


def repair_maker():
    """Fix proved native master-ID substitution joins; retain original bytes."""
    from laliga_maker_api import parse
    from validate_laliga_maker import pointer,main as validate
    from validate_laliga_club import raw
    receipt=RESULT/'maker_participation_repair.json'
    assert not receipt.exists(),'Inspect the completed repair before repeating it'
    path=ROOT_OUT/'laliga_maker.sqlite';before=file_sha256(path)
    with read_db(path) as db:records=[json.loads(b) for b, in db.execute('SELECT body FROM fixtures ORDER BY game_id')]
    updates=[];changes=[]
    for old in records:
        body=json.loads(raw(old['source']));new=parse(body,old['match'],old['source'])
        assert {k:v for k,v in old.items() if k not in ['players','issues']}=={k:v for k,v in new.items() if k not in ['players','issues']}
        assert len(old['players'])==len(new['players'])
        for a,b in zip(old['players'],new['players']):
            assert {k:v for k,v in a.items() if k!='played'}=={k:v for k,v in b.items() if k!='played'}
            if a['played']==b['played']:continue
            assert a['played'] is False and b['played'] is True
            lu=pointer(body,a['lineup_pointer']);master=lu['player']['playerMaster']
            events=[e for e in body['events']['data'] if e.get('type',{}).get('type')=='PlayerOn' and
                (e.get('team') or {}).get('id')==a['maker_team_id'] and (e.get('relatedPlayer') or {}).get('id')==master]
            assert master==a['master_player_id'] and events
            changes.append(dict(game_id=old['game_id'],side=a['side'],maker_player_id=a['maker_player_id'],
                master_player_id=master,player_name=a['player_name'],previous_played=False,corrected_played=True,
                lineup_pointer=a['lineup_pointer'],event_ids=json.dumps([e['id'] for e in events]),
                source_url=a['source']['url'],source_raw_file=a['source']['raw_file'],source_sha256=a['source']['sha256']))
        if new!=old:updates.append((json.dumps(new,allow_nan=False),new['game_id']))
    assert changes and updates
    pd.DataFrame(changes).to_csv(RESULT/'maker_participation_repairs.csv',index=False)
    with sqlite3.connect(path) as db:db.executemany('UPDATE fixtures SET body=? WHERE game_id=?',updates)
    validate()
    dump(receipt,dict(status='PASS',at_utc=stamp(),reparsed_games=len(records),changed_games=len(updates),
        corrected_player_appearances=len(changes),previous_database_sha256=before,corrected_database_sha256=file_sha256(path),
        only_played_and_issue_diagnostics_changed=True,raw_responses_unchanged=True,all_changes_proven_by_native_master_relation=True))
    publish_maker()
    # Refresh the raw-normalized replay receipt after the controlled change.
    verify_recovered()
    print(receipt.read_text(),flush=True)


def publish_maker():
    """Refresh the existing final source tables from all validated records."""
    from laliga_maker_features import records
    games=records();frames={}
    def flatten(row):
        r={k:v for k,v in row.items() if k not in ['source','raw_stats']};src=row['source']
        r.update(source_url=src['url'],source_raw_file=src['raw_file'],source_sha256=src['sha256'],
            retrieved_at_utc=src['retrieved_at_utc'],source_request_number=src['request_number'])
        if 'raw_stats' in row:r['raw_stats_json']=json.dumps(row['raw_stats'],sort_keys=True)
        return r
    for key,name in [('players','player_match_statistics'),('teams','team_match_statistics'),('managers','manager_appearances')]:
        frames['laliga_maker_'+name]=pd.DataFrame([flatten(r) for g in games for r in g[key]])
    links=[]
    for g in games:
        links.append(flatten(dict(game_id=g['game_id'],maker_game_id=g['match']['maker_game_id'],date=g['date'],
            match_identity_json=json.dumps(g['match'],sort_keys=True),issues_json=json.dumps(g['issues'],sort_keys=True),source=g['source'])))
    frames['laliga_maker_source_links']=pd.DataFrame(links)
    counts={}
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        for table,frame in frames.items():
            schema=pd.read_sql_query('SELECT * FROM column_catalog WHERE "table"=?',db,params=(table,))
            columns=[r[1] for r in db.execute('PRAGMA table_info('+table+')')]
            assert set(columns)==set(schema['column'])
            frame=frame.reindex(columns=columns)
            for col in frame:
                if frame[col].dtype=='bool':frame[col]=frame[col].astype(int)
            frame.to_sql(table,db,if_exists='replace',index=False)
            frame.to_parquet(ROOT_OUT/(table+'.parquet'),index=False);frame.to_csv(ROOT_OUT/(table+'.csv'),index=False)
            db.execute('UPDATE table_catalog SET rows=?,columns=? WHERE "table"=?',(len(frame),len(frame.columns),table))
            db.execute('DELETE FROM missing_report WHERE "table"=?',(table,))
            for c in frame:db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(table,c,len(frame),int(frame[c].isna().sum()),100*frame[c].isna().mean()))
            pd.testing.assert_frame_equal(frame,pd.read_sql_query('SELECT * FROM '+table,db),check_dtype=False)
            counts[table]=len(frame)
        db.execute('UPDATE column_catalog SET meaning=? WHERE "table"=? AND "column"=?',
            ('Participation evidenced by an explicit starter flag, reported minutes/substitution count, or PlayerOn event linked through the literal native player ID or its unique playerMaster ID. False records no such evidence in this response.','laliga_maker_player_match_statistics','played'))
    from publish import main
    main();dump(RESULT/'maker_publication.json',dict(status='PASS',at_utc=stamp(),rows=counts,schemas_preserved=True,all_current_validated_matches_published=True))


def clock_repairs(g,o,p,labels):
    import laliga_recovered_features as recovered
    recovered.OUT=WORK
    cg,co,cp=recovered.correct_clocks(g,o,p)
    cl=labels.copy();repairs=json.loads((ROOT_OUT/'laliga_clock_audit.json').read_bytes())['records'];rows=[]
    for r in repairs:
        gid=r['game_id'];mask=cl.game_id.eq(gid);assert mask.sum()==1
        old=cl.loc[mask,'available_time'].iloc[0]
        # Existing report availability must not be shortened to a generic floor.
        actual=max(old,pd.Timestamp(r['verified_start_utc'])+pd.Timedelta(hours=6))
        cl.loc[mask,'available_time']=actual
        rows.append(dict(game_id=gid,official_game_id=r['official_game_id'],date=r['date'],
            previous_start_utc=r['prior_start_utc'],corrected_start_utc=r['verified_start_utc'],
            previous_result_available_utc=old.isoformat(),corrected_result_available_utc=actual.isoformat(),
            reason=r['reason'],source_json=json.dumps({k:r[k] for k in ['source_url','source_raw_file','source_sha256','retrieved_at_utc','league_calendar_evidence']},sort_keys=True)))
    for before,after,fields in [(g,cg,['game_id','official_game_id','scoreA','scoreB','target']),
                                (p,cp,[c for c in p if c!='available_at_utc'])]:
        pd.testing.assert_frame_equal(before[fields],after[fields],check_exact=True)
    audit=pd.DataFrame(rows);audit.to_csv(RESULT/'clock_corrections.csv',index=False)
    assert pd.to_datetime(audit.corrected_result_available_utc,utc=True,format='mixed').ge(pd.to_datetime(audit.previous_result_available_utc,utc=True,format='mixed')).all()
    return cg,co,cp,cl,audit


def publish_clocks(f):
    table='soccer_kickoff_corrections'
    meanings={
        'game_id':('Canonical game whose historical kickoff was corrected','identifier'),
        'official_game_id':('Direct La Liga native match identifier','identifier'),
        'date':('Official game calendar date','YYYY-MM-DD'),
        'previous_start_utc':('Previous model input kickoff; some source date-only values had been parsed as midnight','UTC timestamp'),
        'corrected_start_utc':('Verified kickoff from the complete official club fixture response','UTC timestamp'),
        'previous_result_available_utc':('Previously modeled result availability before this correction','UTC timestamp'),
        'corrected_result_available_utc':('Conservative result availability, never earlier than the previous clock or six hours after verified kickoff; not an asserted exact publication time','UTC timestamp'),
        'reason':('Documented source discrepancy and reason for correction','text'),
        'source_json':('Original official club and league URLs, raw paths, hashes and retrieval evidence','JSON')}
    assert set(f)==set(meanings)
    f.to_parquet(ROOT_OUT/(table+'.parquet'),index=False);f.to_csv(ROOT_OUT/(table+'.csv'),index=False)
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        f.to_sql(table,db,if_exists='replace',index=False);db.execute('CREATE UNIQUE INDEX '+table+'_game ON '+table+'(game_id)')
        for name in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+name+' WHERE "table"=?',(table,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(table,len(f),len(f.columns)))
        for c in f:
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(table,c,*meanings[c],'Official FCBarcelona API republishes Opta; paired direct La Liga calendar response is retained as the original discrepancy. Raw observations unchanged.'))
            db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(table,c,len(f),int(f[c].isna().sum()),100*f[c].isna().mean()))
        pd.testing.assert_frame_equal(f,pd.read_sql_query('SELECT * FROM '+table,db),check_dtype=False)
    dump(ROOT_OUT/'retention/soccer_kickoff_corrections_validation.json',dict(status='PASS',at_utc=stamp(),rows=len(f),output_sha256=file_sha256(ROOT_OUT/(table+'.parquet'))))
    from publish import main
    main()


def model_frame(g,o,p,labels,keys,meta):
    import features
    import loss_case_revision as case
    from soccer_clock_recovery import aliases
    from soccer_club_history_model import summaries,FIELDS as score_fields
    from soccer_club_strength import coefficients
    needed=['game_id','side','player_id','minutes','available_at_utc','saves','shots_against']+meta['metrics']
    compact=p[list(dict.fromkeys(c for c in needed if c in p))]
    base,checks=features.build('soccer',g,o,compact,keys,meta['stats'],meta['metrics'])
    base['observation_available_time']=base.available_time
    base['available_time']=base.game_id.map(labels.set_index('game_id').available_time)
    base=aliases(base).set_index('game_id')
    extra=pd.read_parquet(ROOT_OUT/'soccer_additional_club_results.parquet').rename(columns={'regulation_scoreA':'scoreA','regulation_scoreB':'scoreB'})
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
        registry={(code,str(native)):json.loads(body) for code,native,body in db.execute('SELECT * FROM _eu_team_identity')}
    keys=dict(keys)
    for row in extra.itertuples():
        for side in ['A','B']:
            native=str(getattr(row,'team'+side+'_id'));keys[row.game_id,side]=registry.get(('UCL',native),{}).get('team_id','UEFA Champions League:'+native)
    for col in ['start_time','available_time']:extra[col]=pd.to_datetime(extra[col],utc=True,format='mixed')
    base[score_fields]=summaries(g,pd.concat([g,extra],ignore_index=True),keys).loc[base.index,score_fields]
    adjusted,audit=case.coverage_features(g,p,keys);base[adjusted.columns]=adjusted.loc[base.index]
    coef,evidence=coefficients(g,pd.read_parquet(ROOT_OUT/'soccer_uefa_club_coefficients.parquet'),registry)
    base=base.join(coef,validate='one_to_one')
    return base,audit


def build():
    import loss_case_revision as case
    import soccer_current_roster as identity
    import laliga_recovered_features as club
    import laliga_maker_features as maker
    from pl_sparse_statistics import merge_proved_zeros
    from soccer_source_count_rates import derive
    assert (RESULT/'control_reconstruction.json').exists() and not (RESULT/'feature_validation.json').exists()
    raw_proof=RESULT/'recovered_raw_validation.json'
    if raw_proof.exists():
        proof=json.loads(raw_proof.read_bytes());assert proof['status']=='PASS'
        for file in ['club','maker']:assert proof[file+'_database_sha256']==file_sha256(ROOT_OUT/('laliga_'+file+'.sqlite'))
    else:verify_recovered()
    case.WORK=WORK
    g,o,p,labels,keys,meta=case.load_sources()
    original=pd.read_parquet(WORK/'squad/soccer_features.parquet').set_index('game_id')
    p,zero_proof=merge_proved_zeros(p,audit_dir=WORK/'count_replay')
    cg,co,cp,cl,clock_audit=clock_repairs(g,o,p,labels);publish_clocks(clock_audit)
    for module in [club,maker]:module.OUT=WORK
    fresh,club_audit=club.merge_club_players(cp)
    fresh,maker_audit=maker.merge_players(fresh,dated_identity=True)
    for name in ['maker_dated_identity_evidence.parquet','maker_dated_identity_pending.csv','maker_dated_identity_validation.json','maker_dated_participation_reconciliation.csv']:
        (RESULT/name).write_bytes((WORK/name).read_bytes())
    assert not fresh.duplicated(['game_id','side','player_id']).any()
    assert set(fresh.game_id).issubset(set(cg.game_id))
    # Keep native source information immutable when reconciling person identity.
    identity.RESULT=RESULT;linked=identity.person_links(cp)
    first_proof=json.loads((RESULT/'identity_validation.json').read_bytes())
    enriched=identity.person_links(fresh)
    dump(RESULT/'identity_control_validation.json',first_proof)
    variants={'clock_identity':linked,'player_enriched':enriched};frames={};coverage=[];audits={}
    for label,players in variants.items():
        gg=cg.copy();oo=co.copy()
        latest=pd.to_datetime(players.available_at_utc,utc=True,format='mixed').groupby(players.game_id).max()
        gg['available_time']=pd.concat([gg.available_time,gg.game_id.map(latest)],axis=1).max(axis=1)
        oo['available_time']=oo.game_id.map(gg.set_index('game_id').available_time)
        print(json.dumps(dict(stage='build',variant=label,games=len(gg),player_rows=len(players))),flush=True)
        frame,audit=model_frame(gg,oo,players,cl,keys,meta)
        path=WORK/label;path.mkdir(exist_ok=True);frame.reset_index().to_parquet(path/'soccer_features.parquet',index=False)
        frames[label]=frame;audits[label]=audit
        # Retain a compact, source-timed explanation of affected input rates.
        actions,evidence=derive(gg,players,keys)
        assert np.allclose(actions,frame.loc[actions.index,actions.columns],atol=1e-10,rtol=0,equal_nan=True)
        evidence['variant']=label;coverage.append(evidence)
        cut=pd.Timestamp('2025-01-01',tz='UTC');early=gg[gg.prediction_time.lt(cut)]
        pg=gg[gg.available_time.lt(cut)|gg.game_id.isin(early.game_id)]
        pp=players[players.game_id.isin(pg.game_id)]
        prefix,_=derive(pg,pp,keys)
        pd.testing.assert_frame_equal(prefix.loc[early.game_id],actions.loc[early.game_id],check_exact=True)
        physical,_=case.coverage_features(pg,pp,keys)
        pd.testing.assert_frame_equal(physical.loc[early.game_id],frame.loc[early.game_id,physical.columns],check_exact=True)
        assert (frame.source_max_available_utc.isna()|frame.source_max_available_utc.lt(frame.prediction_time)).all()
    pd.concat(coverage,ignore_index=True).to_parquet(RESULT/'rate_evidence.parquet',index=False)
    pd.concat([a.assign(variant=k) for k,a in audits.items()],ignore_index=True).to_parquet(RESULT/'physical_coverage_evidence.parquet',index=False)
    # Baseline identity-only evidence isolates subsequent clock differences.
    evidence=pd.read_parquet(ROOT_OUT/'simulation_results/soccer_current_roster/identity_feature_evidence.parquet').set_index('game_id')
    identity_frame=original.copy();columns=[c.removeprefix('linked_') for c in evidence if c.startswith('linked_')]
    for c in columns:
        assert np.allclose(original.loc[evidence.index,c],evidence['previous_'+c],atol=1e-10,rtol=0,equal_nan=True)
        identity_frame[c]=evidence['linked_'+c]
    import models
    recipe=json.loads((REFERENCE/'experiment_plan.json').read_bytes())['recipe']
    cols=[c for c in models.columns(frames['clock_identity'],recipe) if not c.startswith('league_')]
    changes=[]
    for name,a,b in [('clock_repair',identity_frame,frames['clock_identity']),('player_recovery',frames['clock_identity'],frames['player_enriched'])]:
        b=b.loc[a.index]
        for c in cols:
            changed=~np.isclose(a[c],b[c],atol=1e-10,rtol=0,equal_nan=True)
            changes.append(dict(stage=name,column=c,changed_rows=int(changed.sum()),rows=len(a)))
    pd.DataFrame(changes).to_csv(RESULT/'input_changes.csv',index=False)
    control=frames['clock_identity'];candidate=frames['player_enriched']
    for c in ['target','start_time','prediction_time','available_time']:
        assert np.array_equal(control[c],candidate.loc[control.index,c]),c
    dump(RESULT/'experiment_plan.json',dict(json.loads((RESULT/'plan.json').read_bytes()),recipe=recipe,
        evaluation_policy='Corrected-clock/identity control receives2024-2026rolling replay as a factual repair, irrespective of returns. Player extension reaches2026only if2024/25proper-scoregatepasses.'))
    proof=dict(status='PASS',at_utc=stamp(),rows=len(original),model_numeric_columns=len(cols),
        original_player_rows=len(p),corrected_player_rows=len(linked),enriched_player_rows=len(enriched),
        pl_zero_merge=zero_proof,club_merge=club_audit,maker_merge=maker_audit,
        clock_repairs=len(clock_audit),source_values_ids_clocks_preserved=True,
        prefix_invariant_rows=len(early),frame_hashes={k:file_sha256(WORK/k/'soccer_features.parquet') for k in frames})
    dump(RESULT/'feature_validation.json',proof);print(json.dumps(proof),flush=True)


def train():
    import pickle
    import models
    from sklearn.metrics import log_loss
    import winner_stake_sizing as simulation
    assert (RESULT/'feature_validation.json').exists() and not (RESULT/'model_validation.json').exists()
    # A dated join must not imply that a mutable club UUID is a timeless
    # cross-source person identity. Independently include explicit older asset
    # IDs in this diagnostic; the verified per-fixture joins stay unchanged.
    from laliga_dated_identity import uuid_conflicts
    from laliga_maker_features import records
    evidence=RESULT/'maker_dated_identity_evidence.parquet'
    identity_hash=file_sha256(evidence)
    conflicts=uuid_conflicts(records(),pd.read_parquet(evidence))
    audit=json.loads((RESULT/'maker_dated_identity_validation.json').read_bytes())
    audit.update(mutable_or_reused_uuid_native_conflicts=conflicts,
        conflict_diagnostic_updated_utc=stamp(),dated_join_evidence_sha256=identity_hash)
    dump(RESULT/'maker_dated_identity_validation.json',audit)
    data=json.loads((RESULT/'feature_validation.json').read_bytes())
    data['maker_merge']['dated_identity']=audit;dump(RESULT/'feature_validation.json',data)
    dump(RESULT/'maker_uuid_conflict_evidence.json',dict(status='PASS',at_utc=stamp(),conflicts=conflicts,count=len(conflicts),
        dated_join_evidence_sha256=identity_hash,policy='Cross-date UUID links are not propagated; only documented dated fixture identities are merged. Diagnostic expansion does not change feature matrices.'))
    assert file_sha256(evidence)==identity_hash
    plan=json.loads((RESULT/'experiment_plan.json').read_bytes());parts=[];replays=0
    old=pd.read_parquet(REFERENCE/'development_predictions.parquet')
    old=old[old.variant.eq('candidate')].copy();old['variant']='archived_count_control'
    parts.append(old)
    for name,folder in [('archived_replay','squad'),('clock_identity','clock_identity'),('player_enriched','player_enriched')]:
        models.OUT=WORK/folder;models.CANDIDATES[name]=copy.deepcopy(plan['recipe'])
        dev=models.run('soccer','development',[name])
        if name=='archived_replay':
            a=dev.set_index('game_id');b=old.set_index('game_id').loc[a.index]
            assert np.allclose(a[['p0','p1','p2']],b[['p0','p1','p2']],atol=1e-12,rtol=0)
            for c in ['target','prediction_time','train_label_max','calibration_label_max']:assert np.array_equal(a[c],b[c])
        else:parts.append(dev)
        package=pickle.loads((models.OUT/'model_runs/soccer/development'/(name+'.pkl')).read_bytes())
        frame=pd.read_parquet(models.OUT/'soccer_features.parquet');frame=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
        sample=dev[dev.fold.eq(package['boundary'].strftime('%Y-%m'))]
        got=models.apply_calibration(package['model'].predict_proba(frame.loc[sample.game_id,package['columns']].astype(float)),package['calibrator'])
        assert np.allclose(got,sample[['p0','p1','p2']],rtol=0,atol=1e-12);replays+=len(sample)
        assert len(package['columns'])==41
        assert dev.train_label_max.lt(dev.prediction_time).all() and dev.calibration_label_max.lt(dev.prediction_time).all()
        assert dev.calibration_train_label_max.lt(dev.calibration_prediction_min).all()
    joined=pd.concat(parts,ignore_index=True);joined.to_parquet(RESULT/'development_predictions.parquet',index=False)
    models.metrics(joined).to_csv(RESULT/'development_metrics.csv',index=False)
    scores={}
    for variant,f in joined.groupby('variant'):
        p=f[['p0','p1','p2']].to_numpy();y=f.target.to_numpy(int);last=f[f.prediction_time.dt.year.eq(2025)]
        scores[variant]=dict(logloss=log_loss(y,p,labels=[0,1,2]),brier=float(np.mean(np.sum((p-np.eye(3)[y])**2,axis=1))),
                            logloss2025=log_loss(last.target,last[['p0','p1','p2']],labels=[0,1,2]))
    passed=all(scores['player_enriched'][c]<scores['clock_identity'][c] for c in scores['clock_identity'])
    selection=dict(at_utc=stamp(),passed=bool(passed),scores=scores,adopted=False,
        factual_correction='Verified kickoff and static person identities are corrected regardless of model scores. Old forecasts are archived comparisons, not a reason to retain incorrect facts.')
    dump(RESULT/'selection.json',selection)
    evaluation=[]
    base=pd.read_parquet(REFERENCE/'evaluation_predictions.parquet');base=base[base.variant.eq('candidate')].copy();base['variant']='archived_count_control';evaluation.append(base)
    for name in ['clock_identity']+(['player_enriched'] if passed else []):
        models.OUT=WORK/name;models.CANDIDATES[name]=copy.deepcopy(plan['recipe'])
        dump(models.OUT/'soccer_selection.json',dict(selected_candidates=[name],
            reason='Factual source-clock/person correction' if name=='clock_identity' else 'Earlier proper-score gate passed'))
        ev=models.run('soccer','evaluation',[name]);evaluation.append(ev)
        assert ev.train_label_max.lt(ev.prediction_time).all() and ev.calibration_label_max.lt(ev.prediction_time).all()
    test=pd.concat(evaluation,ignore_index=True);test.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
    models.metrics(test).to_csv(RESULT/'evaluation_metrics.csv',index=False)
    simulation.simulate_predictions(joined,test,RESULT)
    dump(RESULT/'model_validation.json',dict(status='PASS',at_utc=stamp(),archived_control_forecasts_reproduced=len(old),
        latest_fit_forecasts_replayed=replays,earlier_training_and_calibration_checked=True,player_extension_passed=bool(passed),
        corrected_control2026_replayed=True,player_extension2026_evaluated=bool(passed),app_changed=False))
    print(json.dumps(selection),flush=True)


def finish():
    from final_pipeline import cleanup,validate,discard_work
    proof=json.loads((RESULT/'model_validation.json').read_bytes());assert proof['status']=='PASS'
    sources=json.loads((RESULT/'recovered_raw_validation.json').read_bytes());data=json.loads((RESULT/'feature_validation.json').read_bytes())
    selection=json.loads((RESULT/'selection.json').read_bytes())
    old_conflicts=pd.read_csv(RESULT/'maker_appearance_conflicts.csv')
    repairs=pd.read_csv(RESULT/'maker_participation_repairs.csv')
    links=pd.read_parquet(RESULT/'maker_dated_identity_evidence.parquet')
    linked=repairs.merge(links[['game_id','side','maker_player_id','league_official_player_id']],
        on=['game_id','side','maker_player_id'],how='left',validate='one_to_one')
    resolved=old_conflicts.merge(linked,on=['game_id','side'],how='left',suffixes=('','_repair'))
    resolved=resolved[resolved.official_player_id.eq(resolved.league_official_player_id)]
    keys=['game_id','side','official_player_id']
    assert not resolved.duplicated(keys).any()
    assert set(resolved.set_index(keys).index)==set(old_conflicts.set_index(keys).index)
    assert resolved.previous_played.eq(False).all() and resolved.corrected_played.eq(True).all()
    resolved.to_csv(RESULT/'appearance_conflict_resolutions.csv',index=False)
    dump(RESULT/'appearance_conflict_status.json',dict(status='RESOLVED',at_utc=stamp(),rows=len(old_conflicts),
        resolution='Each original participation conflict is linked by the dated native identity to a verified PlayerOn master-ID repair.',
        resolution_evidence='appearance_conflict_resolutions.csv',original_conflict_ledger_preserved=True))
    def table(f):
        def fmt(v):return f'{v:.6f}' if isinstance(v,(float,np.floating)) else str(v)
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(map(fmt,row))+' |' for row in f.itertuples(index=False,name=None)])
    lines=['# Soccer La Liga source integration','',
        'The current corrected-count model omitted two already collected official club sources. FC Barcelona republishes Opta; Elche republishes LaLigaMaker. This study preserves the direct league facts and original responses, reconciles native player identities, and incorporates the verified earlier player observations. Backup sources remain explicitly identified in the source tables.','',
        'The source audit also found that twelve documented kickoff corrections were only applied inside the optional club-data branch. The ordinary research rebuild retained their older clocks, including eleven date-only values represented as midnight. Kickoff and pre12 cutoffs are corrected together; result availability never moves earlier. All twelve have no retained pre12 quotes, so no old-cutoff price is reused as a new quote. Their prior histories can still influence other matches. This is a factual repair, independent of prediction or trading performance.','',
        'Raw replay: '+json.dumps(sources)+'. Static full-name/birth-date person links are checked against their original official sources. Maker joins use explicit same-fixture native IDs or a unique dated full-name/nickname, team, shirt and starter match. No cross-date UUID propagation or fuzzy name-only matching is used. Seven UUIDs have conflicting cross-date native identities. The dated join proves 17,393 links and retains 470 unresolved supplementary rows in the source database and pending ledger; complete direct league participant records are preserved. Eight appearances are independently established by complete direct-league substitution sequences where Maker supplies no entry evidence. Complete-participant and team-total proofs may establish normalized zero counts, while raw nulls remain unchanged.','',
        'Three comparisons are distinct: archived corrected-count model, corrected clocks plus verified person identities, and those same repairs with additional La Liga player statistics. The learner stays the same41-input logistic recipe, monthly expanding history from2021, predictions from2024, earlier-only scaling and purged calibration. Team observation inputs stay fixed; recovered player actions/playing time alter observed player histories. The source correction is evaluated through2026 regardless of return; the optional player extension must first improve pooled2024/25logloss andBrier plus2025logloss versus the repaired control.','',
        'Source rows: '+str(data['original_player_rows'])+' before recovery; '+str(data['enriched_player_rows'])+' after recovery. Every raw game identity and score, source field, preserved timestamp, per90 numerator/denominator and person link remains traceable. Removing later observations reproduces earlier derived action and physical inputs.','',
        table(pd.read_csv(RESULT/'input_changes.csv')),'',
        table(pd.read_csv(RESULT/'development_metrics.csv')),'',
        'Decision: '+json.dumps(selection)+'.','',
        table(pd.read_csv(RESULT/'evaluation_metrics.csv')),'',
        table(pd.read_csv(RESULT/'winner_annual.csv')[['provider','variant','stake_rule','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        'The revised user instruction requires buying only the model highest-probability outcome. Price cannot change the side. Each provider starts at$2000annually; the user baseline stakes$20per probability point above51%, with the existing$5rule and fixed$20control shown separately. Pre12closest-prior quotes are at most24hoursold; cash returns only after recorded settlement. No fees or spread assumptions. Daily calendar Sharpe includes idle days and uses sqrt365.25. Open contracts remain at cost until settlement. Historical Polymarket token observations do not establish executable USasks; Kalshi retains recordedYESaskcloses.2026 remains repeatedly inspected retrospective evidence, not a pristine holdout.','',
        'The final SQL table soccer_kickoff_corrections records each previous/corrected clock and its official source. Raw club/player statistics already live in their separately labelled source tables. The catalog includes meanings, units, provenance and per-column missing percentages. Completed temporary source copies, duplicate matrices and fitted trial packages are removed; original sources, final facts, forecasts and simulation evidence remain. The NBA/MLB app is unchanged.','',
        'Reproduce soccer_laliga_current_history.py prepare, build, train, finish. Current documented public interfaces: https://www.fcbarcelona.com/en/football/first-team/schedule ; https://api-fcb.pulselive.com/football/fixtures/{native_fixture_id} ; https://www.elchecf.es/_next/static/chunks/pages/_app-bbcca07184f495da.js ; https://www.elchecf.es/_next/static/chunks/8168.2083131325c4ec44.js . Exact dated request URLs, nativeIDs, raw paths and hashes remain in each source record. No new API acquisition is required for this integration.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';prior=pd.read_csv(path,low_memory=False);key=LABEL+'/winner_annual.csv'
    pd.concat([prior[prior.source_result_file.ne(key)],pd.read_csv(RESULT/'winner_annual.csv').assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';prior=json.loads(path.read_bytes())
    prior[LABEL]=dict(plan=json.loads((RESULT/'experiment_plan.json').read_bytes()),selection=selection,validation=proof);dump(path,prior)
    if WORK.exists():discard_work(WORK)
    cleanup();check=validate();receipt=dict(status='PASS',at_utc=stamp(),data_validation=data,model_validation=proof,app_validation=check,goal_achieved=False)
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(path.read_bytes());m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']),latest_source_integration=receipt);dump(path,m)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['prepare','repair_maker','build','train','finish']);globals()[p.parse_args().stage]()
