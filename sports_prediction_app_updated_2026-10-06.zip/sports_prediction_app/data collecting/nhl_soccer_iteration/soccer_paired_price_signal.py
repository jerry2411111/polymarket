"""Compare corrected soccer forecasts with three-outcome market controls.

One expanding mixture weight; complete actual three-price cohorts before side
selection. Purchase prices keep their provider semantics and raw provenance.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from sklearn.metrics import accuracy_score, log_loss
from common import ROOT_OUT,REPORTS,dump,stamp,file_sha256
from backtest import quote_inputs,attach
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine

LABEL='soccer_paired_price_signal'
RESULT=ROOT_OUT/'simulation_results'/LABEL
SOURCE=ROOT_OUT/'simulation_results/soccer_source_count_rates'


def initialize():
    RESULT.mkdir(exist_ok=True)
    assert json.loads((SOURCE/'validation.json').read_bytes())['status']=='PASS'
    plan=dict(at_utc=stamp(),model_source=str(SOURCE.relative_to(ROOT_OUT)),
        source_sha256=file_sha256(SOURCE/'development_predictions.parquet'),
        source_correction='Use current count-corrected41-input soccer forecasts, not the older branch that omitted proved sparse zeros.',
        cohort='All three actual home/away/draw quotes required before outcome selection. Exact official native game IDs and team orientation; each source/availability clock <= pre12; age<=24h. Do not manufacture missing draw prices.',
        market='q_i=actual_price_i/sum(three_actual_prices), as a probability control only. All purchases use actual source prices.',
        formula='probability_i = w*sports_i + (1-w)*q_i; single w in[0,1] minimizes multiclass logloss on all earlier settled paired games, separately by provider.',
        training='Monthly expanding out-of-fit forecast archive from2024; underlying sports fits expand from2021. At least100prior paired games and10of each class; all label availability strictly before monthly boundary.',
        gate='2025mixture logloss must beat both sports and price-only controls, Brier must beat sports, accuracy>=52%. Then fixed-stake strategy must improve same-cohort2025Sharpe versus sports with positive return before2026evaluation.',
        bet='Fixed$20from$2000annual cash. One positive expected-log-growth outcome by existing quarter-Kelly ranking only; stake remains$20. Same pre12, source prices and official settlement; providers separate.',
        diagnostics='Show provider/year/league scores, price sums, quote ages, purchased-class probability error. No return-selected hour, cutoff or coefficient grid.',
        evaluation='2026 repeatedly inspected retrospective rolling evidence, not pristine OOS.',app_changed=False)
    path=RESULT/'plan.json'
    if path.exists():assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(path,plan)
    return plan


def load(stage):
    plan=initialize()
    assert file_sha256(SOURCE/'development_predictions.parquet')==plan['source_sha256']
    paths=[SOURCE/'development_predictions.parquet']
    if stage=='evaluation':paths.append(SOURCE/'evaluation_predictions.parquet')
    p=pd.concat([pd.read_parquet(x) for x in paths],ignore_index=True);p=p[p.variant.eq('candidate')].copy()
    assert not p.game_id.duplicated().any()
    q=quote_inputs(RESULT/(stage+'_quote_quality.json'),revision='closest_v62')
    years=[2024,2025] if stage=='development' else [2024,2025,2026]
    q=q[q.sport.eq('soccer')&q.decision_utc.dt.year.isin(years)]
    f,check=attach(p,q);dump(RESULT/(stage+'_matching.json'),check)
    f=f[f.usable_price&f.entry_age_hours.le(24)&f.quote_class.isin([0,1,2])]
    assert not f.duplicated(['provider','game_id','quote_class']).any()
    rows=[];lookup=p.set_index('game_id')
    for (provider,gid),h in f.groupby(['provider','game_id']):
        if set(h.quote_class)!={0,1,2}:continue
        h=h.set_index('quote_class');row=lookup.loc[gid].to_dict();row.update(provider=provider,game_id=gid)
        for i in [0,1,2]:
            z=h.loc[i];row['price'+str(i)]=float(z.entry_price)
            for col in ['entry_source_utc','entry_available_utc','entry_request_id','entry_pointer','entry_contract_id','price_basis','entry_age_hours']:
                row[col+str(i)]=z[col]
        row['price_sum']=sum(row['price'+str(i)] for i in range(3))
        for i in range(3):row['market_p'+str(i)]=row['price'+str(i)]/row['price_sum']
        row['quote_clock_range_hours']=(h.entry_source_utc.max()-h.entry_source_utc.min()).total_seconds()/3600
        rows.append(row)
    cohort=pd.DataFrame(rows).sort_values(['prediction_time','provider','game_id']).reset_index(drop=True)
    assert cohort.train_label_max.lt(cohort.prediction_time).all() and cohort.calibration_label_max.lt(cohort.prediction_time).all()
    coverage=[]
    for provider in ['polymarket','kalshi']:
        for year in years:
            full=p[p.prediction_time.dt.year.eq(year)];pair=cohort[cohort.provider.eq(provider)&cohort.prediction_time.dt.year.eq(year)]
            coverage.append(dict(provider=provider,year=year,total_forecasts=len(full),complete_three_quote_games=len(pair),
                missing_complete_quote_pct=100*(1-len(pair)/len(full)),first_entry=str(pair.prediction_time.min()),last_entry=str(pair.prediction_time.max())))
    pd.DataFrame(coverage).to_csv(RESULT/(stage+'_coverage.csv'),index=False)
    return cohort,q


def rolling(cohort):
    rows=[];fits=[]
    for provider,g in cohort.groupby('provider'):
        for fold,h in g.groupby(g.prediction_time.dt.strftime('%Y-%m')):
            boundary=pd.Timestamp(fold+'-01',tz='UTC');past=g[g.available_time.lt(boundary)]
            counts=past.target.value_counts();ready=len(past)>=100 and len(counts)==3 and counts.min()>=10
            w=1.
            if ready:
                y=past.target.to_numpy(int);idx=np.arange(len(past))
                sports=past[['p0','p1','p2']].to_numpy()[idx,y]
                market=past[['market_p0','market_p1','market_p2']].to_numpy()[idx,y]
                def loss(weight):return float(-np.log(weight*sports+(1-weight)*market).mean())
                opt=minimize_scalar(loss,bounds=(0,1),method='bounded');assert opt.success
                _,w=min((loss(v),v) for v in [0.,float(opt.x),1.])
            z=h.copy();z['sports_weight']=w;z['fit_ready']=ready
            for i in range(3):z['blend_p'+str(i)]=w*z['p'+str(i)]+(1-w)*z['market_p'+str(i)]
            z['price_fit_boundary']=boundary;z['price_fit_latest_label']=past.available_time.max()
            rows.append(z);fits.append(dict(provider=provider,fold=fold,ready=bool(ready),prior_games=len(past),forecast_games=len(h),sports_weight=w,
                latest_label=None if past.empty else str(past.available_time.max())))
    result=pd.concat(rows,ignore_index=True)
    for col in ['price_fit_boundary','price_fit_latest_label']:
        result[col]=pd.to_datetime(result[col],utc=True,format='mixed').astype('datetime64[ns, UTC]')
    assert np.allclose(result[['blend_p0','blend_p1','blend_p2']].sum(axis=1),1,atol=1e-12)
    ready=result[result.fit_ready];assert ready.price_fit_latest_label.lt(ready.price_fit_boundary).all()
    return result,pd.DataFrame(fits)


def metrics(data):
    rows=[];data=data[data.fit_ready].copy();data['year']=data.prediction_time.dt.year
    for groups in [['provider','year'],['provider','year','league']]:
        for key,f in data.groupby(groups):
            meta=dict(zip(groups,key));y=f.target.to_numpy(int)
            for variant,cols in [('sports',['p0','p1','p2']),('market',['market_p0','market_p1','market_p2']),('blend',['blend_p0','blend_p1','blend_p2'])]:
                p=f[cols].to_numpy();pred=p.argmax(axis=1)
                rows.append(meta|dict(league=meta.get('league','ALL'),variant=variant,games=len(f),accuracy=accuracy_score(y,pred),
                    log_loss=log_loss(y,p,labels=[0,1,2]),brier=float(np.mean(np.sum((p-np.eye(3)[y])**2,axis=1))),
                    mean_draw_forecast=float(p[:,2].mean()),draw_frequency=float(np.mean(y==2)),
                    mean_price_sum=float(f.price_sum.mean()),median_quote_clock_range_hours=float(f.quote_clock_range_hours.median())))
    return pd.DataFrame(rows)


def simulate(data,quotes,stage):
    rows=[];bets=[];days=[];checks=[];transfer.RESULT=RESULT
    for variant in ['sports','blend']:
        p=data[data.fit_ready].copy()
        if variant=='blend':p[['p0','p1','p2']]=p[['blend_p0','blend_p1','blend_p2']].to_numpy()
        source=transfer.normalize('soccer',p,quotes,pick_growth=True)
        for provider,g in source.groupby('provider'):
            for year in sorted(g.year.unique()):
                m,b,l,d=engine.simulate(g,int(year),'all_selected_outcomes','flat20_cash_only',5.,2000.)
                key=dict(sport='soccer',provider=provider,year=int(year),variant=variant)
                rows.append(key|m);checks.append(key|engine.validate(b,l,d,'flat20_cash_only',5.,2000.))
                if len(b):bets.append(b.assign(**key))
                days.append(d.assign(**key))
    a=pd.DataFrame(rows);a.to_csv(RESULT/(stage+'_annual.csv'),index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/(stage+'_bets.parquet'),index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/(stage+'_daily.parquet'),index=False)
    dump(RESULT/(stage+'_cash_validation.json'),dict(status='PASS',at_utc=stamp(),checks=checks))
    return a


def diagnose(data,stage):
    # Expose all preselection class errors; do not optimize a bin cutoff.
    rows=[];data=data[data.fit_ready].copy()
    for r in data.itertuples():
        for i in range(3):
            rows.append(dict(provider=r.provider,game_id=r.game_id,year=r.prediction_time.year,league=r.league,outcome=i,
                sports=getattr(r,'p'+str(i)),market=getattr(r,'market_p'+str(i)),blend=getattr(r,'blend_p'+str(i)),
                price=getattr(r,'price'+str(i)),won=int(r.target==i)))
    f=pd.DataFrame(rows);f['sports_price_gap']=f.sports-f.price
    f['gap_group']=pd.cut(f.sports_price_gap,[-np.inf,0,.05,.1,np.inf],include_lowest=True).astype(str)
    summary=f.groupby(['provider','year','outcome','gap_group']).agg(outcomes=('game_id','size'),win_rate=('won','mean'),
        mean_sports_probability=('sports','mean'),mean_market_probability=('market','mean'),mean_blend_probability=('blend','mean'),mean_price=('price','mean')).reset_index()
    summary.to_csv(RESULT/(stage+'_class_reliability.csv'),index=False)
    f.to_parquet(RESULT/(stage+'_outcome_diagnostics.parquet'),index=False)


def development():
    cohort,q=load('development');p,fits=rolling(cohort)
    prefix,_=rolling(cohort[cohort.prediction_time.lt(pd.Timestamp('2025-01-01',tz='UTC'))])
    idx=['provider','game_id'];cols=['sports_weight','fit_ready','blend_p0','blend_p1','blend_p2','price_fit_latest_label']
    pd.testing.assert_frame_equal(prefix.set_index(idx)[cols].sort_index(),p.set_index(idx).loc[prefix.set_index(idx).index,cols].sort_index(),check_exact=True)
    p.to_parquet(RESULT/'development_predictions.parquet',index=False);fits.to_csv(RESULT/'development_fits.csv',index=False)
    m=metrics(p);m.to_csv(RESULT/'development_metrics.csv',index=False);a=simulate(p,q,'development');diagnose(p,'development')
    choices={}
    for provider,g in m[m.year.eq(2025)&m.league.eq('ALL')].groupby('provider'):
        score=g.set_index('variant');cash=a[a.provider.eq(provider)&a.year.eq(2025)].set_index('variant')
        pg=bool(score.loc['blend','log_loss']<min(score.loc['sports','log_loss'],score.loc['market','log_loss']) and
            score.loc['blend','brier']<score.loc['sports','brier'] and score.loc['blend','accuracy']>=.52)
        sg=bool(set(cash.index)>={'sports','blend'} and cash.loc['blend','return_pct']>0 and cash.loc['blend','sharpe']>cash.loc['sports','sharpe'])
        choices[provider]=dict(probability_gate=pg,strategy_gate=sg,evaluate2026=pg and sg)
    dump(RESULT/'selection.json',dict(at_utc=stamp(),choices=choices,adopted=False))
    dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),prefix_rows=len(prefix),paired_games=len(p),
        all_three_actual_prices=True,normalized_prices_not_used_as_purchase_prices=True,source_and_training_clocks_checked=True,adopted=False))
    print(m[m.league.eq('ALL')].to_string(index=False),flush=True)
    print(a[['provider','year','variant','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print(json.dumps(choices),flush=True)


def evaluation():
    choice=json.loads((RESULT/'selection.json').read_bytes());providers=[k for k,v in choice['choices'].items() if v['evaluate2026']]
    assert providers,'No provider passed both earlier gates'
    cohort,q=load('evaluation');cohort=cohort[cohort.provider.isin(providers)]
    p,fits=rolling(cohort);old=pd.read_parquet(RESULT/'development_predictions.parquet');old=old[old.provider.isin(providers)]
    idx=['provider','game_id'];cols=['sports_weight','blend_p0','blend_p1','blend_p2','fit_ready','price_fit_latest_label']
    pd.testing.assert_frame_equal(old.set_index(idx)[cols].sort_index(),p.set_index(idx).loc[old.set_index(idx).index,cols].sort_index(),check_exact=True)
    test=p[p.prediction_time.dt.year.eq(2026)].copy();test.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
    fits.to_csv(RESULT/'evaluation_fits.csv',index=False);m=metrics(test);m.to_csv(RESULT/'evaluation_metrics.csv',index=False)
    a=simulate(test,q,'evaluation');diagnose(test,'evaluation')
    dump(RESULT/'evaluation_validation.json',dict(status='PASS',at_utc=stamp(),earlier_rows_unchanged=len(old),adopted=False))
    print(m[m.league.eq('ALL')].to_string(index=False),flush=True);print(a.to_string(index=False),flush=True)


def finish():
    from final_pipeline import cleanup,validate
    assert json.loads((RESULT/'validation.json').read_bytes())['status']=='PASS'
    choice=json.loads((RESULT/'selection.json').read_bytes())
    stages=['development']+(['evaluation'] if (RESULT/'evaluation_validation.json').exists() else [])
    for s in stages:assert json.loads((RESULT/(s+'_cash_validation.json')).read_bytes())['status']=='PASS'
    def table(f):
        def fmt(x):return f'{x:.6f}' if isinstance(x,(float,np.floating)) else str(x)
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(map(fmt,row))+' |' for row in f.itertuples(index=False,name=None)])
    lines=['# Soccer probabilities against complete three-outcome prices','',
        'This study uses the count-corrected41-input soccer forecast. Whole games enter the comparison before any side is selected, and all three actual home/away/draw quotes must be available. A missing quote is not inferred from the other two. IDs, official results, orientation, pre12 source/availability times and24hourmaximum observation age are checked.','',
        'The market control divides each source price by the sum of all three. That normalization is for probability comparison only; every simulation purchase retains the original price. Provider meanings and quote-time differences remain visible. These historical observations do not establish executable fills.','',
        'A single convex weight combines sports and market probabilities. Each provider and month minimizes multiclass logloss on earlier settled out-of-fit forecasts, requiring100prior games and10of each class. The archive begins2024; underlying sports models train on expanding2021+history. Truncating future data must reproduce earlier weights and forecasts exactly. No new model features, hour or threshold search.','',
        'The2025probability gate requires lower logloss than both controls, lower Brier than sports and at least52%classification accuracy. A separate strategy gate requires higher2025Sharpe than sports with positive return on the same ready cohort. Choices: '+json.dumps(choice['choices'])+'.','']
    collected=[]
    for stage in stages:
        m=pd.read_csv(RESULT/(stage+'_metrics.csv'));a=pd.read_csv(RESULT/(stage+'_annual.csv'))
        coverage=pd.read_csv(RESULT/(stage+'_coverage.csv'))
        lines+=['## '+stage,'',table(coverage),'',table(m[m.league.eq('ALL')][['provider','year','variant','games','accuracy','log_loss','brier','mean_price_sum']]),'',
            table(a[['provider','year','variant','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'']
        for name in ['metrics','annual']:collected.append(pd.read_csv(RESULT/(stage+'_'+name+'.csv')).assign(source_result_file=LABEL+'/'+stage+'_'+name+'.csv',sport='soccer'))
    lines+=['Fixed stakes are$20from$2,000annual starting cash. One outcome is chosen by the existing positive expected-log-growth ranking, without using that ranking to scale the stake. Cash is available only after official settlement; idle days remain in daily Sharpe, annualized by sqrt(365.25). No added fees or spread assumptions.','',
        'Per-league metrics and unfiltered class reliability are included in CSV files. Those diagnostic groups do not select excluded leagues or new confidence cutoffs. No new2026comparison is run unless both earlier gates pass. Repeatedly inspected2026is retrospective evidence, not pristine OOS. No app deployment or automatic model adoption.','',
        'Reproduce: soccer_paired_price_signal.py development; evaluation only if qualified; finish. Original source documentation is in README.md. Complete forecasts preserve each raw request ID, token/ticker, price pointer and timestamp. No duplicate trial matrices or fitted trial packages are created.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False)
    pd.concat([old[~old.source_result_file.str.startswith(LABEL+'/',na=False)]]+collected,ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL]=dict(plan=json.loads((RESULT/'plan.json').read_bytes()),selection=choice,adopted=False);dump(path,old)
    cleanup();check=validate();receipt=dict(status='PASS',at_utc=stamp(),selection=choice,app_validation=check,adopted=False,goal_achieved=False)
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(path.read_bytes());m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']),latest_simulation_update=receipt);dump(path,m)
    print(json.dumps(receipt),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['development','evaluation','finish']);args=parser.parse_args();globals()[args.stage]()
