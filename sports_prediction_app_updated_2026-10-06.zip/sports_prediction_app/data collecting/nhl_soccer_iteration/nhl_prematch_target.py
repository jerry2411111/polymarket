"""Keep early value entries; test observed later pre-match model-price exits."""
import json
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, PROJECT, REPORTS, dump, stamp, file_sha256
import test_confidence_dollars as engine

SOURCE=ROOT_OUT/'simulation_results/nhl_lineup_entry'
RESULT=ROOT_OUT/'simulation_results/nhl_prematch_target'


def observed_exit_points():
    proof=json.loads((SOURCE/'development_validation.json').read_bytes());assert proof['status']=='PASS'
    points=pd.read_parquet(SOURCE/'development_points.parquet').copy()
    cache={};values=[]
    for r in points.to_dict('records'):
        meta=json.loads(r['source_json'])
        if meta['request_number'] not in cache:
            path=PROJECT/meta['raw_file'];assert file_sha256(path)==meta['sha256']
            cache[meta['request_number']]=json.loads(path.read_bytes())
        body=cache[meta['request_number']]
        pointer=r['pointer']
        if r['provider']=='kalshi':
            idx=int(pointer.split('/')[2]);row=body['candlesticks'][idx]
            bid=row.get('yes_bid') or {};key='close_dollars' if 'close_dollars' in bid else 'close'
            raw=bid.get(key)
            if raw is None:
                r['exit_reference_price']=None
            else:
                value=float(raw)/100 if key=='close' and isinstance(raw,int) else float(raw)
                assert 0<=value<=1 and value<=r['price']+1e-12
                r['exit_reference_price']=value
            r['exit_pointer']=f'/candlesticks/{idx}/yes_bid/{key}'
            r['exit_price_basis']='kalshi_recorded_yes_bid_close'
        else:
            value=body
            for part in pointer.strip('/').split('/'):
                value=value[int(part)] if isinstance(value,list) else value[part]
            assert float(value)==r['price']
            r['exit_reference_price']=r['price'];r['exit_pointer']=pointer
            r['exit_price_basis']=r['price_basis']
        assert r['information_time']<=r['source_utc']<=r['available_utc']<pd.Timestamp(r['start_time'])
        values.append(r)
    result=pd.DataFrame(values)
    result.to_parquet(RESULT/'observed_exit_prices.parquet',index=False)
    return result


def main():
    RESULT.mkdir(parents=True,exist_ok=True)
    plan=dict(at_utc=stamp(),hypothesis='Later entry missed profitable early purchases. Keep original pre12 positions and take an observed pre-match gain when the original model probability is reached.',
        models='Unchanged saved expanding-history2021+ NHL primary regulation/OT and secondary logistic forecasts; no market predictors or refits.',
        entry='Exact same original pre12 selected outcome, both p/price>=1.10, flat20 dollars, annual2000cash. At most one position per game.',
        exit='First eligible observed price >= original primary probability, after the original report-information boundary and before game start. If never observed, hold to official settlement. No intrabar interpolation, idealized exact-target fill or force-exit time.',
        price='Polymarket original historical point reference; no proof of executable fill. Kalshi uses the actually recorded YES bid close for sale and existing YES ask close for purchase. No invented spread, fee or cost.',
        scope='2024/25 same games as earlier post-publication quote cohort. This initial test does not claim complete monitoring on all NHL games; expand source coverage only if earlier evidence supports it.',
        selection='By provider require2025positive return and higher Sharpe than identical hold entries; return must exceed20percent before2026qualification. Also report return sacrificed and2024partial sample. No target/stop/stake grid.',
        sharpe='Annualized actual daily account returns sqrt365.25; open positions at cost. Profitable trades and correct final-winner forecasts are distinct.',
        limitations='2026 is repeatedly researched; any later2026test is retrospective. Historical sample coverage and observed quote quality are explicit.',
        app_changed=False)
    path=RESULT/'experiment_plan.json'
    if path.exists():assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(path,plan)
    points=observed_exit_points()
    allbets=pd.read_parquet(SOURCE/'bets.parquet')
    baseline=allbets[allbets.variant.eq('matched_pre12')].copy()
    fields=['sport','provider','game_id','date','start','entry','exit','p0','p1','target','side','probability','price',
            'source_utc','available_utc','quote_age_hours','price_basis','fit_id','entry_request_id','entry_pointer',
            'entry_contract_id','teamA','teamB','won','edge','year','secondary_probability']
    baseline=baseline[fields].copy()
    assert not baseline.duplicated(['provider','game_id']).any()
    groups={key:g.sort_values(['available_utc','source_utc']) for key,g in points.groupby(['provider','game_id','class_index'])}
    changed=[];triggers=[]
    for r in baseline.to_dict('records'):
        # Only these entry-time values determine the threshold; the outcome
        # is used solely for the unchanged settlement fallback.
        observed=groups[(r['provider'],r['game_id'],int(r['side']))]
        eligible=observed[observed.available_utc.gt(r['entry']) &
            observed.exit_reference_price.between(0,1,inclusive='neither') &
            observed.exit_reference_price.ge(r['probability'])]
        out=r|dict(official_settlement_time=r['exit'],payout_per_share=float(r['won']),
                   early_exit=False,exit_request_number=None,exit_pointer=None,exit_source_json=None,
                   exit_price_basis='official_result_settlement')
        if len(eligible):
            x=eligible.iloc[0]
            assert x.available_utc<r['start'] and x.available_utc>=x.source_utc
            assert str(x.entry_contract_id)==str(r['entry_contract_id'])
            out.update(exit=x.available_utc,payout_per_share=float(x.exit_reference_price),early_exit=True,
                exit_request_number=int(x.request_number),exit_pointer=x.exit_pointer,
                exit_source_json=x.source_json,exit_price_basis=x.exit_price_basis)
            assert out['payout_per_share']/r['price']>=1.10-1e-12
        changed.append(out)
        triggers.append(dict(provider=r['provider'],game_id=r['game_id'],year=int(r['year']),side=int(r['side']),
            entry_price=r['price'],model_probability=r['probability'],monitored_points=len(observed),
            valid_sale_points=int(observed.exit_reference_price.between(0,1,inclusive='neither').sum()),
            first_monitored_time=observed.available_utc.min(),last_monitored_time=observed.available_utc.max(),
            early_exit=out['early_exit'],exit_time=out['exit'],payout_per_share=out['payout_per_share'],
            exit_request_number=out['exit_request_number'],exit_pointer=out['exit_pointer']))
    revised=pd.DataFrame(changed)
    pd.DataFrame(triggers).to_csv(RESULT/'exit_trigger_audit.csv',index=False)
    annual=[];bets=[];daily=[];checks=[]
    for variant,f in [('hold',baseline),('model_probability_exit',revised)]:
        for provider in ['polymarket','kalshi']:
            for year in [2024,2025]:
                g=f[f.provider.eq(provider)]
                m,b,l,d=engine.simulate(g,year,'all_selected_outcomes','flat20_cash_only',5.,2000.)
                key=dict(sport='nhl',provider=provider,year=year,variant=variant)
                checks.append(key|engine.validate(b,l,d,'flat20_cash_only',5.,2000.))
                m['profitable_bet_rate_pct']=100*float(b.profit.gt(0).mean()) if len(b) else None
                m['early_exits']=int(b.early_exit.sum()) if len(b) and 'early_exit' in b else 0
                annual.append(key|m)
                if len(b):bets.append(b.assign(**key))
                daily.append(d.assign(**key))
    a=pd.DataFrame(annual);b=pd.concat(bets,ignore_index=True)
    a.to_csv(RESULT/'annual.csv',index=False);b.to_parquet(RESULT/'bets.parquet',index=False)
    pd.concat(daily,ignore_index=True).to_parquet(RESULT/'daily.parquet',index=False)
    hold=b[b.variant.eq('hold')].sort_values(['provider','game_id'])
    ref=allbets[allbets.variant.eq('matched_pre12')].sort_values(['provider','game_id'])
    assert hold[['provider','game_id']].values.tolist()==ref[['provider','game_id']].values.tolist()
    assert np.allclose(hold[['stake','price','probability','profit']],ref[['stake','price','probability','profit']],atol=1e-8,rtol=0)
    new=b[b.variant.eq('model_probability_exit')].sort_values(['provider','game_id'])
    assert new[['provider','game_id','won']].values.tolist()==hold[['provider','game_id','won']].values.tolist()
    assert np.allclose(new[['stake','price','probability']],hold[['stake','price','probability']],atol=1e-12,rtol=0)
    # Independently reconcile each early sale to the first actually observed
    # qualifying raw price and the shares funded by the original purchase.
    early=new[new.early_exit.eq(True)]
    for r in early.itertuples():
        g=groups[(r.provider,r.game_id,int(r.side))]
        hits=g[g.available_utc.gt(r.entry)&g.exit_reference_price.between(0,1,inclusive='neither')&g.exit_reference_price.ge(r.probability)]
        x=hits.iloc[0]
        assert r.exit==x.available_utc and r.payout_per_share==x.exit_reference_price
        assert np.isclose(r.payout,r.stake/r.price*x.exit_reference_price,atol=1e-10,rtol=0)
    realized=b.assign(realized_profit=np.where(b.unsettled_at_end,0.,b.profit))
    realized.groupby(['provider','year','variant','early_exit'],dropna=False).agg(
        bets=('game_id','size'),correct_final_winners=('won','sum'),profit=('realized_profit','sum')).to_csv(RESULT/'profit_attribution.csv')
    choices=[]
    for provider in ['polymarket','kalshi']:
        g=a[a.provider.eq(provider)&a.year.eq(2025)].set_index('variant')
        before,after=g.loc['hold'],g.loc['model_probability_exit']
        choices.append(dict(provider=provider,passed=bool(after.return_pct>20 and after.sharpe>before.sharpe),
            hold_return_pct=before.return_pct,exit_return_pct=after.return_pct,
            hold_sharpe=before.sharpe,exit_sharpe=after.sharpe))
    proof=dict(status='PASS',at_utc=stamp(),choices=choices,cash_checks=checks,
        original_hold_positions_replayed=True,same_funded_positions_and_stakes=True,raw_first_exit_checks=len(early),
        no_interpolated_hits=True,no_future_model_inputs=True,model_refitted=False,
        evaluation2026_run=False,app_changed=False,adopted=False)
    dump(RESULT/'validation.json',proof)
    finish(a,proof)
    print(a[['provider','year','variant','funded_games','early_exits','profitable_bet_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


def finish(annual,proof):
    from final_pipeline import cleanup,validate
    report=REPORTS/'nhl_prematch_target.md'
    lines=['# NHL early purchase and pre-match model-price exit','',
        'Waiting to buy after lineup publication missed profitable early positions. This test preserves those original pre12 purchases and changes only the exit. It retains the existing rolling forecasts, one selected outcome per game and fixed$20 stake from an annual$2,000 cash account.','',
        'After the recorded publication boundary, sell at the first actually observed pre-match price at or above the original primary model probability. Otherwise hold to official result settlement. There is no searched profit target, forced-close time, interpolation or assumed exact-target fill. Polymarket uses its recorded historical price reference, not a verified executable sale quote. Kalshi uses actual recorded YES bid close for the sale and existing YES ask close for the purchase; no spread is invented.','',
        'This initial comparison uses the same games with verified later quote coverage. It does not claim complete monitoring across all NHL games. No new forecasts or2026evaluation were produced. The model is trained on expanding2021+history; all its inputs and calibration labels predate the original pre12 forecast.','',
        '|Provider|Year|Exit rule|Bets|Early exits|Profitable bets|Return|Sharpe|Max drawdown|',
        '|---|---:|---|---:|---:|---:|---:|---:|---:|']
    for r in annual.itertuples():
        fmt=lambda v,s='':'—' if pd.isna(v) else f'{v:.2f}{s}'
        lines.append(f'|{r.provider}|{r.year}|{r.variant}|{r.funded_games}|{r.early_exits}|{fmt(r.profitable_bet_rate_pct,"%")}|{fmt(r.return_pct,"%")}|{fmt(r.sharpe)}|{fmt(r.max_drawdown_pct,"%")}|')
    lines += ['', 'Profitable-bet rate differs from correct final-winner classification: an early sale can profit even when the selected team later loses. Annual returns include only cash released within that account year; unsettled positions remain valued at cost. Daily Sharpe uses sqrt(365.25); source price, exit and cash checks cover every funded position.','',
        'The fixed qualification rule requires a2025return above20% and improved Sharpe against identical hold entries before any2026test. Decisions: '+json.dumps(proof['choices']), '',
        'The2024price period is partial.2026has been repeatedly researched and is not pristine OOS. No production model or app is changed. A successful subset study must still be extended to the original full game scope; it does not by itself achieve the NHL/soccer goal.','',
        'Source documentation and raw acquisition: nhl_lineup_entry/source_plan.json and its README section. Every sale pointer is retained in observed_exit_prices.parquet and exit_trigger_audit.csv. Reproduce with nhl_prematch_target.py.']
    report.write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key='nhl_prematch_target/annual.csv'
    pd.concat([old[~old.source_result_file.eq(key)],annual.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';decisions=json.loads(path.read_bytes())
    decisions['nhl_prematch_target']=dict(plan=json.loads((RESULT/'experiment_plan.json').read_bytes()),validation=proof);dump(path,decisions)
    cleanup();app=validate()
    path=ROOT_OUT/'retention/retained_artifacts.json';manifest=json.loads(path.read_bytes())
    manifest['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    manifest.update(updated_utc=stamp(),retained_scripts=len(manifest['scripts']),
        latest_simulation_update=dict(result=str(RESULT.relative_to(ROOT_OUT)),adopted=False,report=str(report)))
    dump(path,manifest)
    receipt=dict(status='PASS',at_utc=stamp(),validation=proof,app_validation=app,goal_achieved=False,report=str(report))
    dump(ROOT_OUT/'retention/nhl_prematch_target_completion.json',receipt)
    path=ROOT_OUT/'research_continuation.json';state=json.loads(path.read_bytes())
    state.update(at_utc=stamp(),current_job=None,live_sessions=[],running_jobs=[],
        last_action='Rejected projected-lineup strength update on earlier probability scores; published101SQLtables. Completed unchanged-entry observed pre-match model-probability exit comparison with raw sale/cash replay.',
        next_action='Inspect pre-match exit qualification, exposure and lost/gained dollars. Extend price coverage to the full original NHL cohort before any broad claim if supported; otherwise use evidence to change direction. Soccer role/replacement-quality work remains pending.',report=str(report))
    state.setdefault('research_state',{})['nhl_prematch_target']=receipt;dump(path,state)


if __name__=='__main__':main()
