"""NHL mean/variance stake direction; fixed forecast and entry controls."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, PREVIOUS, REPORTS, dump, stamp, file_sha256, read_db
from nhl_sports_combination import source
import test_confidence_dollars as engine

LABEL='nhl_edge_variance'
RESULT=ROOT_OUT/'simulation_results'/LABEL


def initialize():
    RESULT.mkdir(exist_ok=True)
    plan=dict(at_utc=stamp(),
        hypothesis='Flat stakes disregard different expected profits and payoff variances. Use their ratio rather than equal risk or growth sizing, with no new probability fit or outcome filter.',
        rule='Keep original single selected side and min(primary,secondary)/price>=1.10. Let p=min(primary,secondary),q=price;mu=p/q-1;variance=p*(1-p)/q^2;score=mu/variance.',
        scale='At each provider/month, divide score by the mean score of earlier qualified entries. Stake=20*score/prior_mean, capped at250dollars(1/8of starting2000); first observed month preserves20. Normalization uses no winners or realized returns.',
        account='Separate provider annual2000cash-only accounts, original pre12prior quote age<=24h, actual official settlement. Capital cannot be reused before settlement. No fees or spreads assumed.',
        history='Underlying models use expanding2021+history; prediction archive begins2024. Scale uses only prior entry-time observations, not later settlement outcomes.',
        gate='2025Sharpe improves, return>20%, drawdown no worse.2024partial price sample is reported, not used to retrospectively alter the rule. Only qualified providers reach2026.',
        evaluation='2026 is repeatedly inspected retrospective rolling evidence, not pristine OOS.',
        source_paper='https://web.stanford.edu/~boyd/papers/pdf/cvx_portfolio.pdf',
        distinction='Independent-return mean/variance direction, not a jointly optimized covariance portfolio. Forecast uncertainty and correlations can invalidate model-implied risk. No parameter sweep.',
        app_changed=False)
    path=RESULT/'plan.json'
    if path.exists():assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(path,plan)
    return plan


def inputs(evaluation=False):
    from backtest import quote_inputs
    import transfer_stake_sizing as transfer
    p=source(evaluation)
    transfer.RESULT=RESULT
    quotes=quote_inputs(RESULT/('evaluation_quote_quality.json' if evaluation else 'development_quote_quality.json'),revision='closest_v62')
    f=transfer.normalize('nhl',p,quotes,True)
    ix=p.set_index('game_id').loc[f.game_id]
    f['secondary_probability']=np.where(f.side.eq(0),ix.second_p0,ix.second_p1)
    f['sizing_probability']=np.minimum(f.probability,f.secondary_probability)
    f=f[f.sizing_probability/f.price>=1.10].copy()
    f['expected_unit_profit']=f.sizing_probability/f.price-1
    f['expected_unit_variance']=f.sizing_probability*(1-f.sizing_probability)/(f.price**2)
    f['risk_score']=f.expected_unit_profit/f.expected_unit_variance
    assert f.risk_score.gt(0).all() and np.isfinite(f.risk_score).all()
    return f


def weights(f,by_phase=False):
    rows=[];fits=[]
    for group,g in f.groupby(['provider','phase'] if by_phase else ['provider']):
        provider=group[0];phase=group[1] if by_phase else 'ALL'
        for fold,h in g.groupby(g.entry.dt.strftime('%Y-%m')):
            boundary=pd.Timestamp(fold+'-01',tz='UTC');past=g[g.entry.lt(boundary)]
            denominator=float(past.risk_score.mean()) if len(past) else None
            z=h.copy();z['risk_score_multiplier']=z.risk_score/denominator if denominator else 1.
            z['normalization_boundary']=boundary;z['normalization_last_entry']=past.entry.max()
            z['normalization_count']=len(past);z['prior_mean_score']=denominator
            assert not len(past) or past.entry.max()<h.entry.min()
            rows.append(z);fits.append(dict(provider=provider,phase=phase,fold=fold,prior_entries=len(past),mean_score=denominator,
                last_prior_entry=None if not len(past) else str(past.entry.max())))
    out=pd.concat(rows,ignore_index=True)
    out['prior_mean_score']=pd.to_numeric(out.prior_mean_score).astype(float)
    for c in ['normalization_boundary','normalization_last_entry']:
        out[c]=pd.to_datetime(out[c],utc=True,format='mixed').astype('datetime64[ns, UTC]')
    # Compute variance independently from the two payout states.
    p=out.sizing_probability;q=out.price;mu=out.expected_unit_profit
    variance=p*(1/q-1-mu)**2+(1-p)*(-1-mu)**2
    assert np.allclose(variance,out.expected_unit_variance,rtol=0,atol=1e-12)
    assert np.allclose((p/q-1)/variance,out.risk_score,rtol=0,atol=1e-12)
    return out,pd.DataFrame(fits)


def simulate(f,stage,providers=None,candidate='edge_variance'):
    rows=[];bets=[];daily=[];checks=[]
    for provider,g in f.groupby('provider'):
        if providers is not None and provider not in providers:continue
        for year in sorted(g.year.unique()):
            for variant,sizing in [('flat20','flat20_cash_only'),(candidate,'mean_variance_cash_only')]:
                m,b,l,d=engine.simulate(g,int(year),'all_selected_outcomes',sizing,5.,2000.,per_bet_cap_dollars=250.)
                key=dict(sport='nhl',provider=provider,variant=variant,year=int(year))
                checks.append(key|engine.validate(b,l,d,sizing,5.,2000.,per_bet_cap_dollars=250.))
                rows.append(key|m);daily.append(d.assign(**key))
                if len(b):bets.append(b.assign(**key))
    a=pd.DataFrame(rows);b=pd.concat(bets,ignore_index=True)
    a.to_csv(RESULT/(stage+'_annual.csv'),index=False)
    b.to_parquet(RESULT/(stage+'_bets.parquet'),index=False)
    pd.concat(daily,ignore_index=True).to_parquet(RESULT/(stage+'_daily.parquet'),index=False)
    # Diagnose both winners and losers, without selecting a post-hoc band.
    b['allocation_group']=np.where(b.risk_score_multiplier>1,'above_prior_mean','at_or_below_prior_mean')
    b['predicted_profit']=b.stake*b.expected_unit_profit
    grouped=b.groupby(['provider','year','variant','allocation_group']).agg(bets=('game_id','size'),wins=('won','sum'),
        mean_probability=('sizing_probability','mean'),mean_price=('price','mean'),total_staked=('stake','sum'),
        predicted_profit=('predicted_profit','sum'),actual_profit=('profit','sum'),maximum_stake=('stake','max')).reset_index()
    grouped.to_csv(RESULT/(stage+'_attribution.csv'),index=False)
    paired=b.pivot(index=['provider','year','game_id'],columns='variant',values='profit').dropna().reset_index()
    paired['profit_change']=paired[candidate]-paired.flat20
    meta=b[b.variant.eq(candidate)].drop_duplicates(['provider','year','game_id'])
    paired=paired.merge(meta[['provider','year','game_id','teamA','teamB','side','target','probability','sizing_probability','price','entry','exit','stake','source_utc','entry_request_id','entry_contract_id','risk_score_multiplier']],on=['provider','year','game_id'],validate='one_to_one')
    paired.sort_values('profit_change').to_csv(RESULT/(stage+'_case_changes.csv'),index=False)
    # With annual resets this verifies all retained account mechanics on the
    # exact same baseline cohort, not only similar aggregate returns.
    development=stage.endswith('development')
    path=ROOT_OUT/'simulation_results/nhl_sports_combination/margin_annual.csv' if development else ROOT_OUT/'simulation_results/nhl_paired_price_signal/reference_evaluation_annual.csv'
    prior=pd.read_csv(path)
    prior=prior[prior.variant.eq('relative10' if development else 'sports')]
    base=a[a.variant.eq('flat20')].set_index(['provider','year'])
    prior=prior.set_index(['provider','year']);overlap=base.index.intersection(prior.index)
    cols=['funded_games','return_pct','sharpe','max_drawdown_pct','final_equity']
    assert np.allclose(base.loc[overlap,cols],prior.loc[overlap,cols],rtol=0,atol=1e-9,equal_nan=True)
    dump(RESULT/(stage+'_validation.json'),dict(status='PASS',at_utc=stamp(),cash_checks=checks,
        baseline_accounts_replayed=len(overlap),all_variances_independently_recomputed=True,app_changed=False))
    return a


def run():
    initialize();assert not (RESULT/'selection.json').exists()
    raw=inputs();f,fits=weights(raw)
    prefix,_=weights(raw[raw.entry.lt(pd.Timestamp('2025-01-01',tz='UTC'))])
    ix=['provider','game_id'];cols=['risk_score_multiplier','normalization_last_entry','prior_mean_score']
    pd.testing.assert_frame_equal(prefix.set_index(ix)[cols].sort_index(),f.set_index(ix).loc[prefix.set_index(ix).index,cols].sort_index(),check_exact=True)
    poisoned=raw.copy();poisoned['won']=~poisoned.won;poisoned['target']=1-poisoned.target
    alt,_=weights(poisoned)
    pd.testing.assert_frame_equal(f[cols],alt[cols],check_exact=True)
    f.to_parquet(RESULT/'development_orders.parquet',index=False);fits.to_csv(RESULT/'development_normalization.csv',index=False)
    a=simulate(f,'development');choices={}
    for provider,g in a[a.year.eq(2025)].groupby('provider'):
        h=g.set_index('variant');x,y=h.loc['edge_variance'],h.loc['flat20']
        choices[provider]=bool(x.sharpe>y.sharpe and x.return_pct>20 and x.max_drawdown_pct<=y.max_drawdown_pct)
    dump(RESULT/'selection.json',dict(at_utc=stamp(),choices=choices,adopted=False,prefix_orders_reproduced=len(prefix),label_poison_invariant=True))
    if any(choices.values()):
        both,normalizers=weights(inputs(True));earlier=both[both.entry.dt.year.lt(2026)]
        pd.testing.assert_frame_equal(earlier.set_index(ix)[cols].sort_index(),f.set_index(ix)[cols].sort_index(),check_exact=True)
        recent=both[both.entry.dt.year.eq(2026)].copy();recent.to_parquet(RESULT/'evaluation_orders.parquet',index=False)
        normalizers.to_csv(RESULT/'evaluation_normalization.csv',index=False)
        ev=simulate(recent,'evaluation',[k for k,v in choices.items() if v]);a=pd.concat([a,ev],ignore_index=True)
    print(a[['provider','variant','year','funded_games','win_rate_pct','mean_stake','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print(json.dumps(choices),flush=True)


def phase():
    """Correct pooling of normalization contexts, without fitting returns."""
    assert not any(json.loads((RESULT/'selection.json').read_bytes())['choices'].values())
    assert not (RESULT/'phase_selection.json').exists()
    dump(RESULT/'phase_plan.json',dict(at_utc=stamp(),
        diagnosis='The global historical mean score magnifies fresh preseason advantages versus typical regular-season scores: e.g. Winnipeg2025-09-21stake173.61instead20. Test phase-consistent normalization, never remove the losing games.',
        revision='Only normalization changes: compute earlier mean score separately for each official phase(Preseason,Regular Season,Playoffs) and provider. A phase with no earlier priced entries retains20until its next monthly boundary. Forecasts, selected sides and all other stake/account rules unchanged.',
        gate='Same original2025gate: higherSharpe,return>20%,drawdown no worse than flat20. Original rejected pooled-scale result remains. No phase excluded; no parameter sweep.',
        evaluation='2026 only for qualified providers; retrospective repeated research.',app_changed=False))
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        meta=pd.read_sql_query('SELECT game_id,official_game_id,phase FROM nhl_games',db).set_index('game_id')
    assert meta.index.is_unique
    codes=meta.official_game_id.astype(str).str[4:6]
    known=codes.isin(['01','02','03'])
    assert np.array_equal(codes[known].map({'01':'Preseason','02':'Regular Season','03':'Playoffs'}),meta.loc[known,'phase'])
    def prepare(evaluation=False):
        raw=inputs(evaluation);raw['phase']=raw.game_id.map(meta.phase);assert raw.phase.notna().all()
        assert set(raw.phase).issubset({'Preseason','Regular Season','Playoffs'})
        return raw
    raw=prepare();f,fits=weights(raw,True)
    prefix,_=weights(raw[raw.entry.lt(pd.Timestamp('2025-01-01',tz='UTC'))],True)
    cols=['risk_score_multiplier','normalization_last_entry','prior_mean_score','phase'];ix=['provider','game_id']
    pd.testing.assert_frame_equal(prefix.set_index(ix)[cols].sort_index(),f.set_index(ix).loc[prefix.set_index(ix).index,cols].sort_index(),check_exact=True)
    poisoned=raw.copy();poisoned['won']=~poisoned.won;poisoned['target']=1-poisoned.target
    alt,_=weights(poisoned,True);pd.testing.assert_frame_equal(f[cols],alt[cols],check_exact=True)
    f.to_parquet(RESULT/'phase_development_orders.parquet',index=False);fits.to_csv(RESULT/'phase_development_normalization.csv',index=False)
    a=simulate(f,'phase_development',candidate='edge_variance_phase');choices={}
    for provider,g in a[a.year.eq(2025)].groupby('provider'):
        h=g.set_index('variant');x,y=h.loc['edge_variance_phase'],h.loc['flat20']
        choices[provider]=bool(x.sharpe>y.sharpe and x.return_pct>20 and x.max_drawdown_pct<=y.max_drawdown_pct)
    dump(RESULT/'phase_selection.json',dict(at_utc=stamp(),choices=choices,adopted=False,
        prefix_orders_reproduced=len(prefix),label_poison_invariant=True,official_phase_codes_verified=int(known.sum())))
    if any(choices.values()):
        both,normalizers=weights(prepare(True),True);earlier=both[both.entry.dt.year.lt(2026)]
        pd.testing.assert_frame_equal(earlier.set_index(ix)[cols].sort_index(),f.set_index(ix)[cols].sort_index(),check_exact=True)
        recent=both[both.entry.dt.year.eq(2026)].copy();recent.to_parquet(RESULT/'phase_evaluation_orders.parquet',index=False)
        normalizers.to_csv(RESULT/'phase_evaluation_normalization.csv',index=False)
        ev=simulate(recent,'phase_evaluation',[k for k,v in choices.items() if v],candidate='edge_variance_phase');a=pd.concat([a,ev],ignore_index=True)
    print(a[['provider','variant','year','funded_games','win_rate_pct','mean_stake','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print(json.dumps(choices),flush=True)


def finish():
    from final_pipeline import cleanup,validate
    selection=json.loads((RESULT/'selection.json').read_bytes());plan=json.loads((RESULT/'plan.json').read_bytes())
    assert json.loads((RESULT/'development_validation.json').read_bytes())['status']=='PASS'
    def table(f):
        def fmt(v):return f'{v:.6f}' if isinstance(v,(float,np.floating)) else str(v)
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(map(fmt,row))+' |' for row in f.itertuples(index=False,name=None)])
    lines=['# NHL expected profit relative to payoff variance','',
        'The existing rolling sports forecasts and eligible outcomes are unchanged. For purchase price q and the lower model probability p, a one-dollar position returns 1/q-1 on a win and -1 on a loss. Therefore mean return mu=p/q-1 and variance=p*(1-p)/q^2. The independent-return mean/variance allocation direction is proportional to mu/variance. This is not a fitted guarantee of returns and does not model correlations among games.','',
        'Stake=20*(mu/variance)/(mean earlier mu/variance), with a fixed$250ceiling from the previous1/8starting-account rule. The normalization is updated monthly using earlier eligible entries only, separately for each provider; it never uses winners or returns. With no earlier entries, stake stays$20. The exact prior mean, last included entry and every proposed/funded stake are saved. Accounts start each year with$2000; available cash scales simultaneous orders proportionately and is reused only after official settlement.','',
        'This tests expected profit and variance together. Previous equal-risk sizing considered only volatility; Kelly sizing pursued growth. Source: [Boyd et al., Multi-Period Trading via Convex Optimization](https://web.stanford.edu/~boyd/papers/pdf/cvx_portfolio.pdf), risk-return optimization discussion. The binary-payoff formula above is directly derived for this study.','',
        'Selection: '+json.dumps(selection)+'. The specified2025gate requires higherSharpe, return above20%, and no greater drawdown.2024 only has a partial price sample. The original probability models expand from2021 and predict from2024. Baseline accounts, independent two-state variance, earlier-prefix equality, poisoned-label invariance and independent cash/daily equity are checked.','']
    annual=[]
    if (RESULT/'phase_selection.json').exists():
        lines+=['','The phase-normalization follow-up keeps every forecast and eligible side. It computes the historical mean score within each official phase, with the same first-observed-phase fallback to$20. This addresses context pooling rather than retrospectively excluding preseason losses. Its separate plan and failed original result are both retained. Phase decision: '+json.dumps(json.loads((RESULT/'phase_selection.json').read_bytes()))+'.','']
    for stage in ['development','evaluation','phase_development','phase_evaluation']:
        path=RESULT/(stage+'_annual.csv')
        if not path.exists():continue
        assert json.loads((RESULT/(stage+'_validation.json')).read_bytes())['status']=='PASS'
        a=pd.read_csv(path);annual.append(a.assign(source_result_file=LABEL+'/'+stage+'_annual.csv'))
        lines+=[stage.capitalize(),'',table(a[['provider','variant','year','funded_games','win_rate_pct','mean_stake','return_pct','sharpe','max_drawdown_pct']]),'',
            table(pd.read_csv(RESULT/(stage+'_attribution.csv'))),'']
    lines+=['Daily calendar Sharpe includes idle days and annualizes bysqrt(365.25); unresolved positions remain at purchase cost, not intraday mark-to-market. There are no assumed costs. Historical Polymarket token prices are not verified executable USasks. Kalshi uses recordedYESaskcloses.2026 is repeatedly inspected retrospective rolling research, not a pristine holdout. No app or retained-model change.','',
        'Reproduce nhl_edge_variance.py run, phase, then finish. Exact prices, request IDs, contract IDs, raw pointers, source clocks and per-case changes remain in the simulation evidence. No new data acquisition or fitted model package.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False)
    pd.concat([old[~old.source_result_file.str.startswith(LABEL+'/',na=False)]]+annual,ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL]=dict(plan=plan,selection=selection)
    if (RESULT/'phase_selection.json').exists():old[LABEL].update(phase_plan=json.loads((RESULT/'phase_plan.json').read_bytes()),phase_selection=json.loads((RESULT/'phase_selection.json').read_bytes()))
    dump(path,old)
    cleanup();check=validate();receipt=dict(status='PASS',at_utc=stamp(),selection=selection,app_validation=check,goal_achieved=False)
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(path.read_bytes());m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']),latest_simulation_update=receipt);dump(path,m)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['run','phase','finish']);globals()[p.parse_args().stage]()
