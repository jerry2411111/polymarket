"""Reproduce the NHL winner classifier and diagnose dated confidence changes.

All forecasts use expanding, earlier-only source histories. Temporary feature
matrices and fitted artifacts are discarded after validated result publication.
"""
import argparse
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import expit, logit
from sklearn.metrics import accuracy_score, log_loss, brier_score_loss
from threadpoolctl import threadpool_limits

from common import ROOT_OUT, REPORTS, dump, stamp, file_sha256
import models
import nhl_player_strength as roster

LABEL = 'nhl_winner_stability'
RESULT = ROOT_OUT/'simulation_results'/LABEL
WORK = ROOT_OUT/'_work'/LABEL
SOURCE = ROOT_OUT/'simulation_results/feature_revisions/nhl_player_strength'
CONTROL = 'granular_logistic_strong'


def build():
    import features, nhl_identity_features
    RESULT.mkdir(exist_ok=True); WORK.mkdir(parents=True, exist_ok=True)
    assert not (RESULT/'feature_validation.json').exists()
    plan = dict(at_utc=stamp(),
        diagnosis='Same-calendar January-September logistic winner accuracy fell from59.7percent in2025 to55.6percent in2026, alongside fewer high-confidence forecasts. Distinguish base-model changes from temperature calibration before revising exposure.',
        invariant='All purchases must be the chosen model full-class argmax before entry quotes. No price-selected alternative side. No app changes.',
        model='Existing37-input strong logistic classifier; same expanding2021+history, monthly refits, earlier-only preprocessing and180daypurged calibration.',
        first_step='Reconstruct original features and reproduce all saved secondary probabilities. Retain actual secondary calibration metadata and raw probability reconstructed by invertible temperature correction.',
        selection='No proposed parameter or model change selected from2026. Diagnosis is descriptive retrospective evidence, not a fresh holdout.',
        app_changed=False)
    dump(RESULT/'plan.json',plan)
    games,unused,unused_rosters,keys=roster.load();del unused,unused_rosters,keys
    g,o,p,_,stats,metrics,_=features.sources('nhl',include_preseason=True)
    needed=['game_id','side','available_at_utc','player_id','official_player_id','minutes','position','saves','shots_against','played']+metrics
    p=roster.apply_repairs(p[list(dict.fromkeys(needed))])
    base,_=nhl_identity_features.derive(g,o,p,stats,metrics,repaired=True,regulation_labels=games)
    path=ROOT_OUT/'nhl_roster_strength_features.parquet'
    proof=json.loads((ROOT_OUT/'retention/nhl_roster_strength_validation.json').read_bytes())
    assert file_sha256(path)==proof['derived_data_sha256']
    extra=pd.read_parquet(path).drop(columns=['date','prediction_time'])
    f=base.merge(extra,on='game_id',validate='one_to_one')
    assert len(f)==8540 and f.game_id.is_unique
    for c in ['source_max_available_utc','role_source_max_available_utc','onice_source_max_available_utc','player_rating_source_max_utc']:
        assert (f[c].isna()|f[c].lt(f.prediction_time)).all()
    f.to_parquet(WORK/'nhl_features.parquet',index=False)
    fields=models.columns(f.assign(league_NHL=1.),models.CANDIDATES[CONTROL]);assert len(fields)==37
    dump(RESULT/'feature_validation.json',dict(status='PASS',at_utc=stamp(),games=len(f),fields=fields,
        source_clocks_checked=True,feature_sha256=file_sha256(WORK/'nhl_features.parquet'),strength_sha256=file_sha256(path)))
    print(json.dumps(dict(stage='features',status='PASS',games=len(f),inputs=len(fields))),flush=True)


def reproduce():
    models.OUT=WORK
    dump(WORK/'nhl_selection.json',dict(selected_candidates=[CONTROL]))
    frames=[]
    for stage in ['development','evaluation']:
        p=models.run('nhl',stage,[CONTROL])
        source=pd.read_parquet(SOURCE/(stage+'_predictions.parquet'));source=source[source.variant.eq('candidate')].set_index('game_id').loc[p.game_id]
        assert np.array_equal(p.target,source.target)
        assert np.allclose(p[['p0','p1']],source[['second_p0','second_p1']],rtol=0,atol=1e-12)
        assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
        p['raw_p1']=expit(logit(p.p1)*p.temperature)
        assert np.allclose(expit(logit(p.raw_p1)/p.temperature),p.p1,rtol=0,atol=1e-12)
        p['stage']=stage;frames.append(p)
    f=pd.concat(frames,ignore_index=True)
    f['raw_confidence']=np.maximum(f.raw_p1,1-f.raw_p1)
    f['confidence']=f[['p0','p1']].max(axis=1)
    f['correct']=(f.p1.gt(.5).astype(int)==f.target)
    phases=pd.read_parquet(WORK/'nhl_features.parquet').set_index('game_id').phase
    f['phase']=f.game_id.map(phases);assert f.phase.notna().all()
    f.to_parquet(RESULT/'reproduced_forecasts.parquet',index=False)
    monthly=f.groupby('fold').agg(games=('game_id','size'),temperature=('temperature','first'),
        raw_confidence=('raw_confidence','mean'),calibrated_confidence=('confidence','mean'),
        raw_above60=('raw_confidence',lambda x:int(x.gt(.60).sum())),calibrated_above60=('confidence',lambda x:int(x.gt(.60).sum())),
        accuracy=('correct','mean'),calibration_games=('calibration_games','first'),train_games=('train_games','first')).reset_index()
    monthly.to_csv(RESULT/'monthly_confidence.csv',index=False)
    rows=[]
    for label,g in [('all',f),('January-September',f[f.prediction_time.dt.month.le(9)])]:
        for (year,phase),h in g.groupby([g.prediction_time.dt.year,'phase']):
            rows.append(dict(window=label,year=int(year),phase=phase,games=len(h),accuracy=h.correct.mean(),
                raw_confidence=h.raw_confidence.mean(),calibrated_confidence=h.confidence.mean(),
                raw_logloss=log_loss(h.target,h.raw_p1,labels=[0,1]),calibrated_logloss=log_loss(h.target,h.p1,labels=[0,1]),
                raw_above60=int(h.raw_confidence.gt(.60).sum()),calibrated_above60=int(h.confidence.gt(.60).sum())))
    pd.DataFrame(rows).to_csv(RESULT/'calendar_phase_diagnosis.csv',index=False)
    dump(RESULT/'replay_validation.json',dict(status='PASS',at_utc=stamp(),exact_saved_forecasts=len(f),
        max_tolerance=1e-12,secondary_metadata_reconstructed=True,raw_probability_inversion_checked=True,
        earlier_training_and_calibration=True,app_changed=False))
    print(monthly.to_string(index=False),flush=True)


def probability_metrics(p):
    rows=[]
    for variant,g in p.groupby('variant'):
        for year,h in [('pooled',g)]+list(g.groupby(g.prediction_time.dt.year)):
            rows.append(dict(variant=variant,year=str(year),games=len(h),
                accuracy=accuracy_score(h.target,h[['p0','p1']].to_numpy().argmax(axis=1)),
                logloss=log_loss(h.target,h.p1),brier=brier_score_loss(h.target,h.p1)))
    return pd.DataFrame(rows)


def alternatives():
    assert (RESULT/'replay_validation.json').exists() and not (RESULT/'alternative_selection.json').exists()
    plan=dict(at_utc=stamp(),
        diagnosis='Existing180daytemperature rose from1.0978inJanuary2025 to1.6526inJanuary2026. Januarymeanrawconfidence59.97to58.33percent;calibratedconfidence59.14to55.13percent. Temperature preservesbinaryargmax,so it does not cause lower winneraccuracy.',
        candidate_phase='Keep exact same expanding base classifier; estimate one temperature separately for each official phase using all earlier settled out-of-fit raw forecasts. Generate2022/23warmupforecasts from earlier2021+labels. Require80samephaseexamples and10ofeachoutcome; otherwise use earlierallphaseexamples. Sameexistingboundedtemperatureestimator andregularization; no grid.',
        candidate_recent='Existingstronglogistic,C.02,37inputs,all2021+history;traininglabels weightedby2**(-age_days/365),meanweightnormalizedto1to preserve regularizationstrength. Existing180daypurgedcalibration. Fixed365dayhalf-life fromexistingresearch,notfiton2026.',
        model_gate='Lower pooled2024/25logloss andBrier; no lowerpooledwinneraccuracy; no worse2025logloss. No cash or2026outcome selects the forecast.',
        betting_gate='For qualifyingforecasts only: unchangedp>60percent,ownquote>50percent,confidence5stake. Requirehigher2025Sharpe,positive return,no worse2024Sharpewhereavailable. No rule grid.',
        evaluation='Onlyearlierqualifiedmodels/providers get2026evaluation. All2026resultsare retrospective research,not a pristineholdout.',app_changed=False)
    dump(RESULT/'alternative_plan.json',plan)
    data=pd.read_parquet(WORK/'nhl_features.parquet').sort_values(['prediction_time','game_id']).reset_index(drop=True)
    data=pd.concat([data,pd.get_dummies(data.league,prefix='league',dtype=float)],axis=1)
    data['fold']=data.prediction_time.dt.strftime('%Y-%m');spec=models.CANDIDATES[CONTROL]
    cols=models.columns(data,spec);X=lambda f:f[cols].replace([np.inf,-np.inf],np.nan).astype(float)
    prior_forecasts=[]
    for fold in sorted(data.loc[data.prediction_time.dt.year.isin([2022,2023]),'fold'].unique()):
        cut=pd.Timestamp(fold+'-01',tz='UTC');train=data[data.available_time.lt(cut)];test=data[data.fold.eq(fold)]
        assert len(train)>=500 and train.available_time.max()<test.prediction_time.min()
        with threadpool_limits(limits=4):
            model=models.make_model(spec,'nhl');models.fit_model(model,X(train),train,spec,cut);raw=model.predict_proba(X(test))
        p=test[models.META+['phase','fold']].copy();p['raw_p1']=raw[:,1];p['train_label_max']=train.available_time.max()
        prior_forecasts.append(p)
    original=pd.read_parquet(RESULT/'reproduced_forecasts.parquet')
    warm=pd.concat(prior_forecasts,ignore_index=True);warm.to_parquet(RESULT/'calibration_warmup_forecasts.parquet',index=False)
    assert warm.train_label_max.lt(warm.prediction_time).all()
    phase_audit=[]
    def phase_transform(stage):
        source=original[original.stage.eq(stage)].copy();frames=[]
        known=pd.concat([warm,original[original.stage.eq('development')]],ignore_index=True)
        if stage=='evaluation':known=pd.concat([warm,original],ignore_index=True)
        for (fold,phase),g in source.groupby(['fold','phase']):
            cut=pd.Timestamp(fold+'-01',tz='UTC');past=known[known.available_time.lt(cut)]
            chosen=past[past.phase.eq(phase)];fallback=len(chosen)<80 or chosen.target.value_counts().reindex([0,1],fill_value=0).min()<10
            if fallback:chosen=past
            assert len(chosen)>=80 and chosen.available_time.max()<g.prediction_time.min()
            raw=np.c_[1-chosen.raw_p1,chosen.raw_p1];temperature=models.temperature_fit(raw,chosen.target.astype(int))
            out=g.copy();out['p1']=expit(logit(out.raw_p1)/temperature);out['p0']=1-out.p1
            out['temperature']=temperature;out['variant']='expanding_phase_calibration';out['calibration_label_max']=chosen.available_time.max()
            out['calibration_games']=len(chosen);out['calibration_kind']='expanding_out_of_fit_same_phase'
            assert np.array_equal(out[['p0','p1']].to_numpy().argmax(axis=1),g[['p0','p1']].to_numpy().argmax(axis=1))
            phase_audit.append(dict(stage=stage,fold=fold,phase=phase,examples=len(chosen),temperature=temperature,
                fallback_all_phases=bool(fallback),latest_label=chosen.available_time.max()))
            frames.append(out)
        return pd.concat(frames,ignore_index=True)
    phase=phase_transform('development')
    recent_name='winner_logistic_recent'
    recent_work=WORK/'recent';recent_work.mkdir(exist_ok=True)
    shutil.copy2(WORK/'nhl_features.parquet',recent_work/'nhl_features.parquet')
    models.CANDIDATES[recent_name]=dict(spec,half_life_days=365,normalize_sample_weight=True);models.OUT=recent_work
    recent=models.run('nhl','development',[recent_name]);recent['stage']='development'
    control=original[original.stage.eq('development')].copy();control['variant']='control'
    development=pd.concat([control,phase,recent],ignore_index=True)
    s=probability_metrics(development);s.to_csv(RESULT/'alternative_development_metrics.csv',index=False)
    ix=s.set_index(['variant','year']);cp=ix.loc[('control','pooled')];cy=ix.loc[('control','2025')]
    decisions={}
    for name in ['expanding_phase_calibration',recent_name]:
        a,b=ix.loc[(name,'pooled')],ix.loc[(name,'2025')]
        decisions[name]=bool(a.logloss<cp.logloss and a.brier<cp.brier and a.accuracy>=cp.accuracy and b.logloss<=cy.logloss)
    development.to_parquet(RESULT/'alternative_development_predictions.parquet',index=False)
    dump(RESULT/'alternative_selection.json',dict(at_utc=stamp(),models=decisions,used2026=False,adopted=False))
    from backtest import quote_inputs
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    transfer.RESULT=RESULT;quotes=quote_inputs(RESULT/'alternative_quote_quality.json',revision='closest_v62')
    rows=[];positions=[];days=[];checks=[];bet_choices={}
    def accounts(pred,stage):
        for variant,p in pred.groupby('variant'):
            if variant!='control' and not decisions.get(variant,False):continue
            f=transfer.normalize('nhl',p,quotes,pick_growth=False);f=f[f.probability.gt(.60)&f.price.gt(.50)]
            for provider,g in f.groupby('provider'):
                if stage=='evaluation' and variant!='control' and not bet_choices.get((variant,provider),False):continue
                for year in sorted(p.prediction_time.dt.year.unique()):
                    m,b,l,d=engine.simulate(g,int(year),'all_selected_outcomes','dollars_cash_only',5.,2000.)
                    key=dict(sport='nhl',variant=variant,provider=provider,year=int(year),stage=stage)
                    rows.append(key|m);checks.append(key|engine.validate(b,l,d,'dollars_cash_only',5.,2000.))
                    if len(b):
                        assert b.side.eq(b[['p0','p1']].to_numpy().argmax(axis=1)).all();positions.append(b.assign(**key))
                    days.append(d.assign(**key))
    accounts(development,'development')
    annual=pd.DataFrame(rows)
    for provider,g in annual.groupby('provider'):
        ix=g.set_index(['variant','year']);c=ix.loc[('control',2025)]
        for name,passed in decisions.items():
            if not passed:continue
            a=ix.loc[(name,2025)];early=ix.loc[('control',2024),'sharpe'];ae=ix.loc[(name,2024),'sharpe']
            bet_choices[name,provider]=bool(a.sharpe>c.sharpe and a.return_pct>0 and (pd.isna(early) or ae>=early))
    dump(RESULT/'alternative_betting_selection.json',dict(at_utc=stamp(),choices=[dict(variant=k[0],provider=k[1],qualified=v) for k,v in bet_choices.items()],used2026=False,adopted=False))
    evaluation=[]
    for name in decisions:
        if not any(passed for (variant,provider),passed in bet_choices.items() if variant==name):continue
        if name=='expanding_phase_calibration':p=phase_transform('evaluation')
        else:
            dump(recent_work/'nhl_selection.json',dict(selected_candidates=[recent_name]));p=models.run('nhl','evaluation',[recent_name]);p['stage']='evaluation'
        evaluation.append(p)
    if evaluation:
        control=original[original.stage.eq('evaluation')].copy();control['variant']='control';evaluation.append(control)
        evaluation=pd.concat(evaluation,ignore_index=True);evaluation.to_parquet(RESULT/'alternative_evaluation_predictions.parquet',index=False)
        probability_metrics(evaluation).to_csv(RESULT/'alternative_evaluation_metrics.csv',index=False);accounts(evaluation,'evaluation')
    pd.DataFrame(phase_audit).to_csv(RESULT/'phase_calibration_audit.csv',index=False)
    a=pd.DataFrame(rows);a.to_csv(RESULT/'alternative_annual.csv',index=False)
    pd.concat(positions,ignore_index=True).to_parquet(RESULT/'alternative_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'alternative_daily.parquet',index=False)
    old=pd.read_csv(ROOT_OUT/'simulation_results/nhl_winner_classifier/agreement_annual.csv')
    old=old[old.variant.eq('market_agreement')].set_index(['provider','year'])
    ctrl=a[a.variant.eq('control')].set_index(['provider','year']);common=old.index.intersection(ctrl.index)
    for field in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
        assert np.allclose(old.loc[common,field],ctrl.loc[common,field],rtol=0,atol=1e-9,equal_nan=True)
    dump(RESULT/'alternative_validation.json',dict(status='PASS',at_utc=stamp(),warmup_forecasts=len(warm),
        cash_checks=checks,control_replays=len(common),phase_argmax_unchanged=True,earlier_only_clocks=True,app_changed=False,adopted=False))
    print(s.to_string(index=False),flush=True)
    print(json.dumps(dict(model_choices=decisions)),flush=True)
    print(a[['variant','provider','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


def families():
    assert not (RESULT/'family_selection.json').exists()
    recipes={'winner_shallow_tree':dict(models.CANDIDATES['granular_catboost']),
             'winner_sparse_logistic':dict(models.CANDIDATES['elastic_net'],features='granular')}
    plan=dict(at_utc=stamp(),
        hypothesis='Calibration or recentlabelweighting didnotimproveearlierprobabilityscores. Test nonlinearplayer/teamrelations andsuppressionofredundantpredictors usingthesame37datedinputs.',
        recipes=recipes,parameters='Twoexistingrepositoryrecipes:depth2CatBoost300iterations andelasticnetC.1l1ratio.5. No parametergrid or2026-basedchoice.',
        model_gate='Higherpooled2024/25winneraccuracy andlowerpooledlogloss;2025accuracy>=control. Amongpassingmodelsselectlowestpooledlogloss,thenhigheraccuracy;freeze beforebetting.',
        betting='Samepre12modelwinnerp>60percent,ownprice>50percent,5dollarsperpointabove51,holdsettlement. Requirehigher2025Sharpepositive return andno worse2024Sharpewhereavailablebefore2026.',
        chronology='All2021+expandingmonthlytraining,earlierpurgedcalibration andtraining-onlyimputation/scaling.',
        evaluation='2026retrospectiveresearch,not pristineholdout. No app change orautomaticadoption.')
    dump(RESULT/'family_plan.json',plan)
    work=WORK/'family';work.mkdir(exist_ok=True);shutil.copy2(WORK/'nhl_features.parquet',work/'nhl_features.parquet')
    models.OUT=work;models.CANDIDATES.update(recipes)
    new=models.run('nhl','development',list(recipes))
    original=pd.read_parquet(RESULT/'reproduced_forecasts.parquet')
    control=original[original.stage.eq('development')].copy();control['variant']='control'
    p=pd.concat([control,new],ignore_index=True);p.to_parquet(RESULT/'family_development_predictions.parquet',index=False)
    s=probability_metrics(p);s.to_csv(RESULT/'family_development_metrics.csv',index=False)
    ix=s.set_index(['variant','year']);baseline=ix.loc[('control','pooled')];baseyear=ix.loc[('control','2025')]
    passed={name:bool(ix.loc[(name,'pooled'),'accuracy']>baseline.accuracy and ix.loc[(name,'pooled'),'logloss']<baseline.logloss and
        ix.loc[(name,'2025'),'accuracy']>=baseyear.accuracy) for name in recipes}
    candidates=s[s.year.eq('pooled')&s.variant.isin([k for k,v in passed.items() if v])].sort_values(['logloss','accuracy'],ascending=[True,False])
    chosen=None if not len(candidates) else candidates.iloc[0].variant
    dump(RESULT/'family_selection.json',dict(at_utc=stamp(),qualified=passed,chosen=chosen,used2026=False,adopted=False))
    # Verify fitted artifact output rather than only trusting saved result files.
    import pickle
    frame=pd.read_parquet(work/'nhl_features.parquet');frame=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
    replay=0
    for name in recipes:
        bundle=pickle.loads((work/'model_runs/nhl/development'/(name+'.pkl')).read_bytes())
        sample=new[new.variant.eq(name)&new.fold.eq(bundle['boundary'].strftime('%Y-%m'))].head(12)
        x=frame.loc[sample.game_id,bundle['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
        actual=models.apply_calibration(bundle['model'].predict_proba(x),bundle['calibrator'])
        assert np.allclose(actual,sample[['p0','p1']],rtol=0,atol=1e-12);replay+=len(sample)
    assert new.train_label_max.lt(new.prediction_time).all() and new.calibration_label_max.lt(new.prediction_time).all()
    # A model failing the probability gate is not mined for a profitable subset.
    if chosen is not None:
        from backtest import quote_inputs
        import transfer_stake_sizing as transfer
        import test_confidence_dollars as engine
        transfer.RESULT=RESULT;quotes=quote_inputs(RESULT/'family_quote_quality.json',revision='closest_v62')
        rows=[];bets=[];days=[];checks=[];bet_choices={}
        def accounts(pred,stage):
            for variant,g in pred.groupby('variant'):
                f=transfer.normalize('nhl',g,quotes,pick_growth=False);f=f[f.probability.gt(.60)&f.price.gt(.5)]
                for provider,h in f.groupby('provider'):
                    if stage=='evaluation' and variant!='control' and not bet_choices.get(provider,False):continue
                    for year in sorted(g.prediction_time.dt.year.unique()):
                        m,b,l,d=engine.simulate(h,int(year),'all_selected_outcomes','dollars_cash_only',5.,2000.)
                        key=dict(sport='nhl',variant=variant,provider=provider,year=int(year),stage=stage)
                        rows.append(key|m);checks.append(key|engine.validate(b,l,d,'dollars_cash_only',5.,2000.))
                        if len(b):
                            assert b.side.eq(b[['p0','p1']].to_numpy().argmax(axis=1)).all();bets.append(b.assign(**key))
                        days.append(d.assign(**key))
        accounts(p[p.variant.isin(['control',chosen])],'development')
        for provider,g in pd.DataFrame(rows).groupby('provider'):
            ix=g.set_index(['variant','year']);a,b=ix.loc[(chosen,2025)],ix.loc[('control',2025)]
            e=ix.loc[('control',2024),'sharpe'];ce=ix.loc[(chosen,2024),'sharpe']
            bet_choices[provider]=bool(a.sharpe>b.sharpe and a.return_pct>0 and (pd.isna(e) or ce>=e))
        dump(RESULT/'family_betting_selection.json',dict(at_utc=stamp(),providers=bet_choices,used2026=False,adopted=False))
        if any(bet_choices.values()):
            dump(work/'nhl_selection.json',dict(selected_candidates=[chosen]));evaluation=models.run('nhl','evaluation',[chosen])
            c=original[original.stage.eq('evaluation')].copy();c['variant']='control';evaluation=pd.concat([c,evaluation],ignore_index=True)
            evaluation.to_parquet(RESULT/'family_evaluation_predictions.parquet',index=False)
            probability_metrics(evaluation).to_csv(RESULT/'family_evaluation_metrics.csv',index=False);accounts(evaluation,'evaluation')
        a=pd.DataFrame(rows);a.to_csv(RESULT/'family_annual.csv',index=False)
        pd.concat(bets,ignore_index=True).to_parquet(RESULT/'family_bets.parquet',index=False);pd.concat(days,ignore_index=True).to_parquet(RESULT/'family_daily.parquet',index=False)
        dump(RESULT/'family_cash_validation.json',dict(status='PASS',checks=checks))
        print(a[['variant','provider','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    dump(RESULT/'family_validation.json',dict(status='PASS',at_utc=stamp(),forecasts=len(new),fitted_artifact_replays=replay,
        earlier_training_and_calibration_clocks=True,app_changed=False,adopted=False))
    print(s.to_string(index=False),flush=True);print(json.dumps(dict(qualified=passed,chosen=chosen)),flush=True)


def predictive_followup():
    """Separate forecast-quality selection from an unchanged strategy benchmark."""
    assert not (RESULT/'predictive_followup_validation.json').exists()
    selection=json.loads((RESULT/'family_selection.json').read_bytes());chosen=selection['chosen'];assert chosen is not None
    original_betting=json.loads((RESULT/'family_betting_selection.json').read_bytes())
    dump(RESULT/'predictive_followup_plan.json',dict(at_utc=stamp(),chosen=chosen,
        authority='Userexplicitlyrequires selectingbestpredictivepower first,then evaluatingwinnerbetting. Earlierfamilyeconomicgate failed and remainsunchanged;evaluateindependentlyprobability-selectedclassifier underunchangedreferencepolicy.',
        selection='Selectedbefore2026:pooled2024/25accuracy58.4475versus58.2518,logloss0.667526versus0.667921. Smallimprovement,notproof ofstatisticalsuperiority.',
        fixed='No newparameter,feature,probabilitythresholdoramount. Existingp>60,ownprice>50,pre12,confidence5andholdsettlement;reportprovidersseparately.',
        previous_betting_gate=original_betting,app_changed=False,adopted=False,
        evaluation='2026retrospective rollingresearch; no freshholdoutclaim.'))
    plan=json.loads((RESULT/'family_plan.json').read_bytes());models.CANDIDATES[chosen]=plan['recipes'][chosen]
    work=WORK/'family';models.OUT=work;dump(work/'nhl_selection.json',dict(selected_candidates=[chosen]))
    p=models.run('nhl','evaluation',[chosen]);p.to_parquet(RESULT/'predictive_followup_forecasts.parquet',index=False)
    probability_metrics(p).to_csv(RESULT/'predictive_followup_metrics.csv',index=False)
    from backtest import quote_inputs
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    transfer.RESULT=RESULT;quotes=quote_inputs(RESULT/'predictive_followup_quote_quality.json',revision='closest_v62')
    f=transfer.normalize('nhl',p,quotes,pick_growth=False);f=f[f.probability.gt(.60)&f.price.gt(.5)]
    rows=[];bets=[];days=[];checks=[]
    for provider,g in f.groupby('provider'):
        m,b,l,d=engine.simulate(g,2026,'all_selected_outcomes','dollars_cash_only',5.,2000.)
        key=dict(sport='nhl',provider=provider,variant=chosen,year=2026,stage='evaluation')
        rows.append(key|m);checks.append(key|engine.validate(b,l,d,'dollars_cash_only',5.,2000.))
        assert b.side.eq(b[['p0','p1']].to_numpy().argmax(axis=1)).all();bets.append(b.assign(**key));days.append(d.assign(**key))
    a=pd.DataFrame(rows);a.to_csv(RESULT/'predictive_followup_annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/'predictive_followup_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'predictive_followup_daily.parquet',index=False)
    import pickle
    bundle=pickle.loads((work/'model_runs/nhl/evaluation'/(chosen+'.pkl')).read_bytes())
    data=pd.read_parquet(work/'nhl_features.parquet');data=pd.concat([data,pd.get_dummies(data.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
    sample=p[p.fold.eq(bundle['boundary'].strftime('%Y-%m'))].head(12)
    x=data.loc[sample.game_id,bundle['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
    actual=models.apply_calibration(bundle['model'].predict_proba(x),bundle['calibrator'])
    assert np.allclose(actual,sample[['p0','p1']],rtol=0,atol=1e-12)
    assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
    dump(RESULT/'predictive_followup_validation.json',dict(status='PASS',at_utc=stamp(),cash_checks=checks,
        fitted_artifact_replays=len(sample),forecasts=len(p),earlier_only_training=True,app_changed=False,adopted=False))
    print(probability_metrics(p).to_string(index=False),flush=True)
    print(a[['provider','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


def finish():
    assert (RESULT/'family_validation.json').exists() and (RESULT/'alternative_validation.json').exists()
    parts=['# NHL winner-model stability','',
        'The existing model was reproduced exactly on3894savedforecasts. Temperature calibration does not change the binary predictedwinner. Much of the confidence decline is shrinkage following weak late2025outcomes; lowerwinneraccuracy is a separate base-classification problem. This is a diagnostic decomposition,not a claim that calibration caused market returns.','']
    def table(f):
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in f.itertuples(index=False,name=None)])
    for name in ['alternative_development_metrics.csv','family_development_metrics.csv','alternative_annual.csv','family_annual.csv','predictive_followup_metrics.csv','predictive_followup_annual.csv']:
        if not (RESULT/name).exists():continue
        frame=pd.read_csv(RESULT/name)
        if 'funded_games' in frame:
            frame=frame[['variant','provider','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]
        parts += [name,'',table(frame),'']
    parts += ['Expanding phase calibration and recent weighting failed earlier probability-score gates. Shallow CatBoost also failed. Elastic-net logistic modestly improved earlier winneraccuracy andprobabilityscores, but its originalconfidencepolicy failed the separateeconomicgate. The explicitpredictivefollowup evaluates that alreadyselectedclassifier under the unchangedpolicy, without rewriting the failedgate orselecting on2026.','',
        'All fits use2021+expandinghistory,monthlyforecastsfrom2024,earlier-onlyimputation/scaling andpurgedcalibration. Eachcashpurchase is thecompleteclassargmaxbeforeentryquotes. Returnusesannual2000cash,no borrowing,nofeesorspreads,officialsettlementtime;Sharpe usesactualUTCcalendardailyreturnsincludingidle days,sqrt365.25. PMhistoricaltokenpricesare not verifiedUSexecutableasks;KalshiYESaskclosesremainseparate.2026isrepeatedlyinspectedretrospectiveresearch.','',
        'Reproduce nhl_winner_stability.py build,reproduce,alternatives,families,predictive_followup,finish. Rejectedtemporaryfits andfeaturematrices are removedaftervalidation. NBA/MLBapp andretainedmodels unchanged.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(parts)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';allresults=pd.read_csv(path,low_memory=False)
    for name in ['alternative_annual.csv','family_annual.csv','predictive_followup_annual.csv']:
        if not (RESULT/name).exists():continue
        key=LABEL+'/'+name;allresults=pd.concat([allresults[allresults.source_result_file.ne(key)],pd.read_csv(RESULT/name).assign(source_result_file=key)],ignore_index=True)
    allresults.to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';records=json.loads(path.read_bytes())
    records[LABEL]={p.stem:json.loads(p.read_bytes()) for p in RESULT.glob('*.json') if any(t in p.name for t in ['plan','selection','validation'])};dump(path,records)
    comparison=[]
    files=[('NHL previous classifier','nhl_winner_classifier/agreement_annual.csv','market_agreement'),
           ('NHL sparse classifier',LABEL+'/predictive_followup_annual.csv','winner_sparse_logistic'),
           ('NHL pre-start exit, $5 per point','nhl_winner_prestart_exit/evaluation_recovered_annual.csv','pre1_exit'),
           ('NHL pre-start exit, $20 per point','nhl_winner_prestart_exit/original_stake_evaluation_recovered_annual.csv','pre1_original20'),
           ('Soccer previous winner control','soccer_winner_home_context/annual.csv','control'),
           ('Soccer home-winner filter','soccer_winner_home_context/annual.csv','home_only')]
    for label,file,variant in files:
        frame=pd.read_csv(ROOT_OUT/'simulation_results'/file)
        frame=frame[frame.provider.eq('polymarket')&frame.year.eq(2026)&frame.variant.eq(variant)]
        assert len(frame)==1;row=frame.iloc[0]
        comparison.append(dict(version=label,bets=int(row.funded_games),winner_accuracy_pct=row.win_rate_pct,
            profitable_positions_pct=row.get('profitable_bets_pct',row.win_rate_pct),return_pct=row.return_pct,
            sharpe=row.sharpe,max_drawdown_pct=row.max_drawdown_pct))
    compare=pd.DataFrame(comparison);compare.to_csv(RESULT/'current_comparison.csv',index=False)
    narrative=['# Winner-only alternatives: completed comparison','',
        'Every purchase in this comparison is the model\'s highest-probability outcome. Entry prices never substitute a different outcome. A filter can skip a game. Soccer retains its true three-way class probabilities.','',
        'The current user-revised target remains unmet: none of the new alternatives achieved both Sharpe above 2.5 and account return above 20% in the 2026 evaluation. Prior frozen experimental gates remain unchanged. All 2026 results are through September 29 and are retrospective rolling research; this period has been inspected repeatedly.','',
        table(compare),'',
        'Each calendar year starts with $2,000. The confidence stake is $5 times the number of percentage points above 51%; the separately labelled $20 version uses the user\'s original fixed-dollar amount. Stakes do not rise automatically with equity. Accounts never borrow or spend unsettled payouts; simultaneous orders share available cash. No fees or spread assumptions were added. Sharpe uses actual daily account returns, includes idle calendar days, and annualizes with sqrt(365.25).','',
        'The NHL hold reference uses the strong logistic classifier, a pre-12 forecast above 60%, and a price above 50% on that same predicted outcome. The soccer control buys the three-way argmax above 51%; the home filter buys only when that argmax is the home team. The home filter never converts an away prediction into a home purchase.','',
        'Findings and decisions:','',
        '- Soccer\'s home-winner filter improved 2025 Sharpe from 2.54 to 3.02, with a 140.22% return. In 2026 it produced Sharpe 0.98 and return 31.37%. The earlier improvement did not reproduce at the target level.','- Fixed $20 position caps and 1% equity positions reduced some drawdowns but reduced earlier Sharpe for both sports. Neither qualified for a new 2026 candidate evaluation.','- Reproducing 3,894 NHL forecasts exposed the actual secondary-classifier calibration metadata. January calibration temperature rose from 1.10 in 2025 to 1.65 in 2026, softening confidence. Temperature cannot change the binary winner, so it does not explain the separate decline in winner accuracy.','- Expanding phase-specific calibration, recent-history weighting, and shallow CatBoost did not improve the declared earlier-year probability criteria. Elastic-net feature selection slightly improved pooled winner accuracy from 58.25% to 58.45%, but the unchanged betting rule worsened in 2026. The sparse model\'s full 2026 accuracy was 55.68%; its funded subset won 67.74%.','- NHL pre-start selling initially looked strongest: buy the predicted winner at pre-12, sell at the first observation in the final hour before play. In 2025 the $5 slope gave Sharpe 4.44 and return 20.62%; the original $20 slope gave 4.59 and 82.08%. The small 2024 sample lost money. With complete 2026 exit coverage, both slopes lost money; neither is adopted.','',
        'Exit-data recovery: 154 bounded official hourly requests initially lacked the required final-hour observation in 23 games. All 23 were recovered through bounded official minute-history requests. The final comparison includes all 154 games, preserves the incomplete initial result as an audit record, and uses raw timestamps and values. Whole-window hourly continuity is separate from final-hour exit coverage and is not claimed complete.','',
        'Winner accuracy and profitable positions differ for early sales: the 154 selected teams eventually won 68.83% of their games, but only 37.66% of the pre-start sales had positive price returns. There is no purchase of the opposite team.','',
        'Prices are official international Polymarket historical token observations, not US prices or verified executable buy/sell offers. The official history endpoint is documented at https://docs.polymarket.com/api-reference/markets/get-prices-history and its rate limits at https://docs.polymarket.com/api-reference/rate-limits. Kalshi results are retained separately in the detailed CSVs.','',
        'Training uses expanding 2021+ history and monthly forecasts from 2024, with earlier-only preprocessing and purged calibration. Each selection decision is recorded before its later candidate evaluation. The NBA/MLB application was not changed. Final source data, raw responses, forecasts, simulation ledgers and reproducible scripts are kept; temporary trial fits and input matrices are deleted after validation.','',
        'Reproduction scripts: soccer_winner_home_context.py; winner_position_concentration.py; nhl_winner_stability.py; nhl_winner_prestart_exit.py. Detailed results are in the same-named simulation_results folders.']
    (REPORTS/'winner_only_alternatives.md').write_text('\n'.join(narrative)+'\n',encoding='utf8')
    state=json.loads((ROOT_OUT/'research_continuation.json').read_bytes())
    state.update(updated_utc=stamp(),live_sessions=[],running_jobs=[],report='reports/nhl_soccer_iteration/winner_only_alternatives.md',
        next_action='Winner-only target is still unmet. Keep corrected soccer clock_identity and the NHL exact classifier references. Latest sparse classifier has a small earlier predictive advantage but worse unchanged2026betting. Avoid repeating completed cap,homefilter,phasecalibration,recentweighting,shallowtree,andpre1sale trials. Any further economic selection must use earlier dates; 2026 is retrospective,not a freshholdout. Consider acquisition/model changes only with a specific earlier-error diagnosis,not a2026thresholdgrid.')
    state['latest_completed_winner_revision']=dict(at_utc=stamp(),results=compare.to_dict('records'),
        nhl_forecasts_reproduced=3894,new_source_requests=177,exit_coverage_recovered=23,final_exit_games=154,
        target_achieved=False,app_changed=False,report='reports/nhl_soccer_iteration/winner_only_alternatives.md')
    dump(ROOT_OUT/'research_continuation.json',state)
    from final_pipeline import discard_work,cleanup
    if WORK.exists():discard_work(WORK)
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    dump(RESULT/'completion.json',dict(status='PASS',at_utc=stamp(),temporary_fits_and_matrices_removed=not WORK.exists(),goal_achieved=False,app_changed=False))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['build','reproduce','alternatives','families','predictive_followup','finish']);globals()[p.parse_args().stage]()
