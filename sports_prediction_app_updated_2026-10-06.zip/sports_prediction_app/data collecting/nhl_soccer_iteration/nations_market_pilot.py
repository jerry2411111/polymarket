"""Small real Polymarket/official-UEFA join and causal price-history pilot."""
import argparse,collections,datetime as dt,json,re,sqlite3,unicodedata
from urllib.parse import urlencode
import pandas as pd
from common import OfficialClient,ROOT_OUT,REPORTS,PROJECT,dump,stamp
from collect_nations_league import connect

def norm(x):return ''.join(c for c in unicodedata.normalize('NFKD',x).casefold() if c.isalnum())
def array(x):return json.loads(x) if isinstance(x,str) else x
def utc(x):return dt.datetime.fromisoformat(x.replace('Z','+00:00'))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--all',action='store_true');args=ap.parse_args()
    client=OfficialClient(per_second=2);client.HOSTS.update(['gamma-api.polymarket.com','data-api.polymarket.com'])
    db=connect();games=[json.loads(b) for b, in db.execute('SELECT body FROM calendar')]
    events=[];sources={};seen=set();pages=[]
    for page in range(100 if args.all else 1):
        params=dict(tag_id=100816,closed='true',limit=100,offset=page*100,order='id',ascending='true')
        data,source=client.get('https://gamma-api.polymarket.com/events?'+urlencode(params),'Nations League historical discovery page '+str(page+1),'polymarket_discovery')
        assert isinstance(data,list)
        ids=[str(e['id']) for e in data];assert len(ids)==len(set(ids)) and not seen.intersection(ids),'Repeated discovery page'
        seen.update(ids);events.extend(data);pages.append(dict(source=source,rows=len(data)))
        sources.update({str(e['id']):(source,i) for i,e in enumerate(data)})
        if len(data)<100:break
    else:
        if args.all:raise AssertionError('Discovery pagination not exhausted')
    candidates=[];rejected=[]
    for e in events:
        source,event_index=sources[str(e['id'])]
        title=re.sub(r'^UEFA Nations League:\s*','',e['title']);names=re.split(r'\s+vs\.?\s+',title)
        if len(names)!=2 or ' - ' in title:continue
        for g in games:
            if {norm(n) for n in names}!={norm(g['teamA']),norm(g['teamB'])}:continue
            contracts={};reasons=[]
            for market_index,m in enumerate(e.get('markets',[])):
                if m.get('sportsMarketType') not in [None,'moneyline']:continue
                if not m.get('gameStartTime'):continue
                market_start=utc(m['gameStartTime'])
                if market_start.date().isoformat()!=g['date'] or abs((market_start-utc(g['start_time'])).total_seconds())>3600:continue
                description=m.get('description','').lower()
                if '90 minutes' not in description and '90-minute' not in description:continue
                outcomes=array(m.get('outcomes',[]));tokens=array(m.get('clobTokenIds',[]));prices=array(m.get('outcomePrices',[]))
                if outcomes!=['Yes','No'] or len(tokens)!=2 or len(prices)!=2:continue
                question=m.get('question','');who=re.match(r'^Will (.+?) (?:win|beat)\b',question,re.I)
                label=who[1] if who else m.get('groupItemTitle','')
                side='D' if 'draw' in question.lower() else next((s for s in ['A','B'] if norm(label)==norm(g['team'+s])),None)
                if side is None:continue
                if side in contracts:reasons.append('Multiple full-game contracts for one outcome');continue
                expected=int(g['scoreA']==g['scoreB']) if side=='D' else int((g['scoreA']>g['scoreB']) if side=='A' else (g['scoreB']>g['scoreA']))
                if float(prices[0])!=expected:reasons.append('Market resolution does not match official regulation result');continue
                contracts[side]=dict(provider='polymarket',game_id=g['game_id'],event_id=str(e['id']),market_id=str(m['id']),token_id=str(tokens[0]),
                    side=side,outcome='Draw' if side=='D' else g['team'+side],raw_outcomes=outcomes,raw_tokens=tokens,yes_index=0,
                    resolved_value=float(prices[0]),official_result=expected,public_url='https://polymarket.com/event/'+e['slug'],
                    market_question=question,rules=m['description'],market_start_utc=market_start.isoformat(),source=source,
                    raw_market_pointer='/'+str(event_index)+'/markets/'+str(market_index))
            if len(contracts)==3 and not reasons:candidates.append((g,contracts))
            elif reasons:rejected.append(dict(event_id=e['id'],game_id=g['game_id'],reasons=reasons))
    years={}
    for g,c in sorted(candidates,key=lambda x:x[0]['date']):years.setdefault(g['date'][:4],(g,c))
    selected=sorted(candidates,key=lambda x:x[0]['date']) if args.all else list(years.values())[:3]
    if len(selected)<3:selected=sorted(candidates,key=lambda x:x[0]['date'])[:3]
    assert len(selected)>=3,'Fewer than three independently matched completed pilot games'
    assert len({g['game_id'] for g,_ in selected})==len(selected),'Multiple provider events require explicit deduplication'
    quote_rows=[];wide=[];contracts=[];history=[];excluded=0;milestone=10
    print(json.dumps(dict(stage='nations_market_history_start',games=len(selected),events=len(events),all_discovery=args.all)),flush=True)
    for n,(g,cs) in enumerate(selected,1):
        start=int(utc(g['start_time']).timestamp());row={k:g[k] for k in ['game_id','date','league','season','location','home_away','final']}
        row.update(match=g['teamA']+'/'+g['teamB'],game_type='Soccer',timestamp=g['start_time'],teamA_final_score=g['scoreA'],teamB_final_score=g['scoreB'])
        for side,contract in cs.items():
            contracts.append(contract);params=dict(token_id=contract['token_id'],start=start-7*86400,end=start,limit=1000);points=[];seen=set()
            # Reuse already acquired real automatic-resolution responses. New
            # windows request hourly density first, then an explicitly recorded
            # fallback if that tier has expired.
            automatic_url='https://data-api.polymarket.com/v2/prices-history?'+urlencode(params)
            with client.connect() as cache:
                retained=cache.execute("SELECT 1 FROM request_audit WHERE url=? AND return_status='200' LIMIT 1",(automatic_url,)).fetchone()
            if not retained:params['bucket_seconds']=3600
            for page in range(20):
                data,s=client.get('https://data-api.polymarket.com/v2/prices-history?'+urlencode(params),g['date']+' Nations League historical probability '+contract['outcome'],'polymarket_history')
                assert isinstance(data,dict) and isinstance(data.get('data'),list)
                if page==0 and not data['data'] and 'bucket_seconds' in params:
                    params.pop('bucket_seconds')
                    data,s=client.get('https://data-api.polymarket.com/v2/prices-history?'+urlencode(params),g['date']+' Nations League retained coarse probability '+contract['outcome'],'polymarket_history')
                    assert isinstance(data,dict) and isinstance(data.get('data'),list)
                for i,x in enumerate(data['data']):
                    assert isinstance(x['timestamp'],int) and 0<=x['price']<=1 and x['resolution_seconds']>=0
                    # The documented settlement point may be clamped into a
                    # historical request window. It is never a pregame quote.
                    item={k:contract[k] for k in ['provider','game_id','event_id','market_id','token_id','side','outcome']}|dict(timestamp_utc=dt.datetime.fromtimestamp(x['timestamp'],dt.UTC).isoformat(),price=x['price'],
                        implied_probability=x['price'],resolution_seconds=x['resolution_seconds'],price_source=s,raw_pointer='/data/'+str(i))
                    history.append(item)
                    if x['resolution_seconds']==0:excluded+=1;continue
                    available=x['timestamp']+x['resolution_seconds']
                    if available<=start:points.append((available,x,s,i))
                cursor=data.get('pagination',{}).get('next_cursor')
                if not cursor:assert not data.get('pagination',{}).get('has_more');break
                assert cursor not in seen;seen.add(cursor);params['cursor']=cursor
            else:raise AssertionError('History pagination not exhausted')
            label={'A':'teamA','B':'teamB','D':'draw'}[side]
            for h in [0,12,24,36,48]:
                target=start-h*3600;eligible=[p for p in points if p[0]<=target and (p[0]<start if h==0 else True)]
                chosen=max(eligible,key=lambda p:(p[0],p[1]['timestamp'])) if eligible else None
                price=chosen[1]['price'] if chosen else None
                row[f'{label}_pre_{h}_p']=price;row[f'{label}_pre_{h}_odd']=1/price if price is not None and price>0 else None
                quote_rows.append(dict(game_id=g['game_id'],side=side,hours_before=h,token_id=contract['token_id'],
                    target_utc=dt.datetime.fromtimestamp(target,dt.UTC).isoformat(),price=price,
                    observation_utc=dt.datetime.fromtimestamp(chosen[1]['timestamp'],dt.UTC).isoformat() if chosen else None,
                    available_at_utc=dt.datetime.fromtimestamp(chosen[0],dt.UTC).isoformat() if chosen else None,
                    age_hours=(target-chosen[0])/3600 if chosen else None,resolution_seconds=chosen[1]['resolution_seconds'] if chosen else None,
                    request_number=chosen[2]['request_number'] if chosen else None,pointer='/data/'+str(chosen[3]) if chosen else None,
                    reason=None if chosen else 'No retained non-settlement observation completed by target'))
        wide.append(row)
        if n*100>=milestone*len(selected) or n==len(selected):
            progress=dict(at_utc=stamp(),processed=n,total=len(selected),percent=100*n/len(selected),through_date=g['date'],history_rows=len(history),quote_slots=len(quote_rows))
            dump(ROOT_OUT/'nations_market_progress.json',progress);print(json.dumps(progress),flush=True);milestone+=10
    from publish import flat
    raw_history_count=len(history)
    used={(r['request_number'],r['pointer']) for r in quote_rows if r['price'] is not None}
    # All source observations remain in raw JSON. Research output retains the
    # exact observations used by lookbacks, without duplicating market rules
    # and metadata thousands of times per token.
    history=[r for r in history if (r['price_source']['request_number'],r['raw_pointer']) in used]
    for name,records in [('nations_polymarket_contracts',contracts),('nations_polymarket_prices',history),('nations_polymarket_quote_audit',quote_rows),('nations_polymarket_pre_match',wide)]:
        f=flat(records);f.to_sql(name,db,if_exists='replace',index=False);f.to_parquet(ROOT_OUT/(name+'.parquet'),index=False);f.to_csv(ROOT_OUT/(name+'.csv'),index=False)
    report=dict(at_utc=stamp(),status='PASS',scope='All closed events returned by the Nations League tag; exact team/date/90-minute outcome matching' if args.all else 'Three-game pilot from one discovery page; not complete market coverage',discovery_pages=pages,discovery_events=len(events),matched_candidates=len(candidates),
        selected_games=[{k:g[k] for k in ['game_id','date','teamA','teamB','scoreA','scoreB']} for g,_ in selected],
        outcome_contracts=len(contracts),raw_history_rows=raw_history_count,normalized_selected_observations=len(history),settlement_points_excluded=excluded,
        quote_slots=len(quote_rows),missing_slots=sum(r['price'] is None for r in quote_rows),rejected=rejected,
        price_basis='Historical token-price series, not verified executable bid/ask. Use the latest fully completed source window at/before the target. Raw prices and settlement points retained separately.')
    dump(ROOT_OUT/('nations_market_validation.json' if args.all else 'nations_market_pilot_validation.json'),report);db.close();print(json.dumps({k:v for k,v in report.items() if k not in ['discovery_pages','selected_games']}),flush=True)


if __name__=='__main__':main()
