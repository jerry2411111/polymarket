"""Official US Polymarket acquisition; never substitutes international prices."""
import argparse,json,sqlite3,urllib.parse,re,unicodedata,collections
from pathlib import Path
import pandas as pd
from concurrent.futures import ThreadPoolExecutor
from common import OfficialClient,ROOT_OUT,PROJECT,dump,stamp

RESULT=ROOT_OUT/'simulation_results/us_market_revision'
RESULT.mkdir(parents=True,exist_ok=True)
BASE='https://gateway.polymarket.us'
DOCS=['https://docs.polymarket.us/api-reference/price-history/get-price-history',
      'https://docs.polymarket.us/api-reference/events/get-events',
      'https://docs.polymarket.us/concepts/market-data',
      'https://docs.polymarket.us/api-reference/sports/get-all-leagues']

class Client(OfficialClient):
    HOSTS=OfficialClient.HOSTS|{'gateway.polymarket.us','docs.polymarket.us'}
    def connect(self):
        c=sqlite3.connect(RESULT/'acquisition.sqlite',timeout=60)
        c.row_factory=sqlite3.Row;c.execute('PRAGMA journal_mode=WAL');return c

def get(client,path,params=None,intent='US market data'):
    url=BASE+path+('?' + urllib.parse.urlencode(params,doseq=True) if params else '')
    body,meta=client.get(url,intent,kind='polymarket_us')
    if meta['return_status']!='200':raise RuntimeError(str(meta))
    return body,meta

def probe():
    c=Client(per_second=3)
    for url in DOCS:
        d,m=c.get(url+'.md','Read current official US API documentation',document=True,kind='api_documentation')
        if d:(RESULT/(url.rsplit('/',1)[1]+'.md')).write_bytes(d)
    d,m=get(c,'/v2/leagues',intent='Discover exact official US league slugs')
    dump(RESULT/'leagues.json',d)
    print([(x['name'],x['slug']) for x in d['leagues'] if x.get('sportId') in (2,4)],flush=True)
    for tag in ['nhl','soccer']:
        d,m=get(c,'/v1/events',dict(limit=2,offset=0,closed='true',tag_slug=tag),intent='Pilot completed '+tag+' event discovery')
        dump(RESULT/(tag+'_pilot.json'),d)
        print(tag,'events',len(d.get('events',[])),flush=True)
        for e in d.get('events',[])[:2]:
            print(json.dumps({k:e.get(k) for k in ['id','slug','title','startTime','closed']}),flush=True)

def discover():
    c=Client(per_second=3);events=[];audit=[]
    for tag in ['nhl','soccer']:
        seen=set()
        for offset in range(0,20000,100):
            d,m=get(c,'/v1/events',dict(limit=100,offset=offset,closed='true',tag_slug=tag),intent='All completed '+tag+' US events, offset '+str(offset))
            page=d['events'];audit.append(dict(tag=tag,offset=offset,rows=len(page),request_number=m['request_number']))
            for e in page:
                assert str(e['id']) not in seen,'Repeated pagination';seen.add(str(e['id']))
                tags=[t['slug'] for t in e.get('tags',[])];assert tag in tags,(tag,tags)
                z={k:e.get(k) for k in ['id','slug','title','startTime','eventDate','closed','createdAt','finishedTimestamp','competitors']}
                z.update(sport='nhl' if tag=='nhl' else 'soccer',tags=tags,source_request=m['request_number'],markets=[])
                for market in e.get('markets',[]):
                    typ=market.get('sportsMarketType','')
                    if typ not in ['moneyline','drawable_outcome','hockey_team_full_game_winner','soccer_team_full_time_winner']:continue
                    z['markets'].append({k:market.get(k) for k in ['id','slug','question','sportsMarketType','sportsMarketTypeV2','marketSides','createdAt','gameStartTime','closed','outcomes','description']})
                events.append(z)
            print('US discovery',tag,offset,len(page),flush=True)
            if len(page)<100:break
        else:raise ValueError('Discovery bound reached before exhaustion')
    dump(RESULT/'events.json',events);dump(RESULT/'discovery.json',audit)

def norm(name):
    s=unicodedata.normalize('NFKD',str(name or '')).encode('ascii','ignore').decode().lower().replace('&','and').replace('.','')
    s=re.sub(r'club de futbol|futbol club|union deportiva|club deportivo|calcio|\bsad\b',' ',s)
    s=re.sub(r'\b(fc|cf|ac|as|ssc|us|rc|rcd|ca|ud|cd|club|1|04|05|1846|1848|1899|1909|1910)\b',' ',s)
    return re.sub('[^a-z0-9]','',s)

ALIASES={
    'Internazionale':'Inter Milan','Inter':'Inter Milan','Paris Saint-Germain':'Paris Saint Germain',
    'Man City':'Manchester City','Man United':'Manchester United','Bayern MÃ¼nchen':'Bayern Munich',
    'Borussia MÃ¶nchengladbach':'Borussia Monchengladbach','1. FC KÃ¶ln':'FC Cologne',
    '1. FC Heidenheim 1846':'Heidenheim','FC Bayern MÃ¼nchen':'Bayern Munich',
    'Athletic Club':'Athletic Bilbao','AtlÃ©tico de Madrid':'Atletico Madrid',
    'Real Betis BalompiÃ©':'Real Betis','Real Sociedad de FÃºtbol':'Real Sociedad',
    'Deportivo AlavÃ©s':'Alaves','RCD Espanyol de Barcelona':'Espanyol',
    'RC Celta de Vigo':'Celta Vigo','CA Osasuna':'Osasuna','RCD Mallorca':'Mallorca',
    'Leeds United':'Leeds','Newcastle United':'Newcastle','Tottenham Hotspur':'Tottenham',
    'Wolverhampton Wanderers':'Wolves','Brighton and Hove Albion':'Brighton',
    'Sporting CP':'Sporting Clube de Portugal','Club Atletico de Madrid':'AtlÃ©tico de Madrid',
    'BV Borussia 09 Dortmund':'Borussia Dortmund','SC Freiburg':'Sport-Club Freiburg',
    'Inter Milan':'FC Internazionale Milano','SS Lazio':'S.S. Lazio',
    'Celta de Vigo':'Real Club Celta de Vigo SAD','Le Havre':'Havre Athletic Club',
    'Lille':'LOSC Lille','Lyon':'Olympique Lyonnais','Marseille':'Olympique de Marseille',
    'Monaco':'AS Monaco','Rennes':'Stade Rennais FC','Strasbourg':'RC Strasbourg Alsace',
    'Brest':'Stade Brestois 29','Paris SG':'Paris Saint-Germain',
    'CA Osasuna':'Club AtlÃ©tico Osasuna','RCD Mallorca':'Real Club Deportivo Mallorca SAD',
    'Real Madrid':'Real Madrid C.F.',
}

def predictions():
    nhl=pd.read_parquet(ROOT_OUT/'simulation_results/nhl_winner_stability/reproduced_forecasts.parquet')
    parts=[pd.read_parquet(ROOT_OUT/'simulation_results/soccer_laliga_current_history'/(s+'_predictions.parquet')) for s in ['development','evaluation']]
    soccer=pd.concat(parts,ignore_index=True);soccer=soccer[soccer.variant.eq('clock_identity')].copy()
    assert nhl.game_id.is_unique and soccer.game_id.is_unique
    return pd.concat([nhl,soccer],ignore_index=True)

def match():
    p=predictions();games=pd.read_parquet(ROOT_OUT/'games.parquet')
    # The forecast table owns verified kickoff corrections. Official games own names/results.
    p=p.merge(games[['game_id','teamA','teamB','scoreA','scoreB']],on='game_id',validate='one_to_one')
    names=set(p.teamA)|set(p.teamB);lookup=collections.defaultdict(set)
    for name in names:
        lookup[norm(name)].add(name)
        lookup[norm(re.sub(r'^(FC |AC |AS |SSC |RC |RCD |CA |UD |CF |VfL |VfB )| (FC|CF)$','',name))].add(name)
    for a,b in ALIASES.items():
        union=lookup[norm(a)]|lookup[norm(b)]
        if len(union)==1:lookup[norm(a)]=union;lookup[norm(b)]=union
    rows=[];unmatched=[]
    for e in json.loads((RESULT/'events.json').read_text()):
        if not e.get('startTime') or not e['markets']:continue
        start=pd.Timestamp(e['startTime']);sport=e['sport']
        if start.year<2024:continue
        if sport=='soccer' and not set(e['tags'])&{'epl','ucl','lal','bun','sea','lg1','lig1','ligue1','unl','uefa'}:continue
        possible=p[p.sport.eq(sport)&(pd.to_datetime(p.start_time,utc=True)-start).abs().le(pd.Timedelta(hours=1))]
        event_names=set()
        for m in e['markets']:
            for side in m.get('marketSides',[]):
                t=side.get('team') or {}
                for field in ['name','alias','safeName']:event_names.update(lookup.get(norm(t.get(field)),set()))
        found=possible[possible.teamA.isin(event_names)&possible.teamB.isin(event_names)]
        if len(found)!=1:
            unmatched.append(dict(event_id=e['id'],slug=e['slug'],sport=sport,start=e['startTime'],reason='No unique dated forecast/team pair',candidate_games=len(found),team_names=sorted(event_names)));continue
        g=found.iloc[0].to_dict();used=set()
        for m in e['markets']:
            sides=m.get('marketSides',[])
            if len(sides)!=2 or {s.get('long') for s in sides}!={True,False}:continue
            if sport=='nhl' and m['slug'].removeprefix('aec-')!=e['slug'].removeprefix('aec-'):continue
            for side in sides:
                if sport=='soccer' and not side['long']:continue # NO of one team is not another team.
                t=side.get('team') or {};ident=set()
                for field in ['name','alias','safeName']:ident.update(lookup.get(norm(t.get(field)),set()))
                outcome=0 if g['teamA'] in ident else 1 if g['teamB'] in ident else 2 if sport=='soccer' and m['slug'].endswith('-draw') and not t else None
                if outcome is None:continue
                assert outcome not in used,(e['id'],outcome);used.add(outcome)
                rows.append(dict(game_id=g['game_id'],sport=sport,league=g['league'],date=g['date'],start_time=g['start_time'],available_time=g['available_time'],target=int(g['target']),
                    teamA=g['teamA'],teamB=g['teamB'],provider='polymarket_us',event_id=str(e['id']),market_id=str(m['id']),market_slug=m['slug'],contract_id=str(side['id']),side=outcome,long=side['long'],
                    market_created_at=m['createdAt'],market_start=e['startTime'],metadata_request_number=e['source_request']))
    f=pd.DataFrame(rows);assert not f.duplicated(['game_id','side']).any()
    f.to_parquet(RESULT/'contracts.parquet',index=False);dump(RESULT/'unmatched.json',unmatched)
    print('Matched US contracts',f.groupby('sport').agg(games=('game_id','nunique'),contracts=('market_id','nunique')).to_dict(),flush=True)
    print('Unmatched',len(unmatched),flush=True)

def history():
    c=Client(per_second=4);f=pd.read_parquet(RESULT/'contracts.parquet');rows=[];audit=[]
    groups=list(f.groupby('market_slug'));last=-1
    def fetch(item):
        slug,g=item
        start=pd.Timestamp(g.iloc[0].start_time);lo=start-pd.Timedelta(hours=12)
        d,m=get(c,'/v1/price-history',{'symbol':slug,'timestamp.startTimestamp':int(lo.timestamp()),'timestamp.endTimestamp':int(start.timestamp()),'fidelity':1},intent='US pregame 12-hour observations '+slug)
        points=d.get('history',[])
        if not points:
            check,other=get(c,'/v1/price-history',dict(symbol=slug,fixedInterval='INTERVAL_ALL',fidelity=180),intent='Verify empty custom-range history '+slug)
            detail=dict(market_slug=slug,rows=0,request_number=m['request_number'],full_profile_rows=len(check.get('history',[])),diagnostic_request=other['request_number'])
        else:detail=dict(market_slug=slug,rows=len(points),request_number=m['request_number'])
        return slug,g,points,m,detail
    import pyarrow as pa
    import pyarrow.parquet as pq
    executor=ThreadPoolExecutor(max_workers=4);writer=None;total=0
    temporary=RESULT/'us_price_points.parquet.tmp'
    for i,(slug,g,points,m,detail) in enumerate(executor.map(fetch,groups)):
        audit.append(detail);start=pd.Timestamp(g.iloc[0].start_time);lo=start-pd.Timedelta(hours=12)
        z=pd.DataFrame(points)
        if len(z):
            z['raw_pointer']=['/history/'+str(j) for j in range(len(z))]
            z['timestamp']=pd.to_datetime(z.timestamp,unit='s',utc=True)
            z=z[z.timestamp.ge(lo)&z.timestamp.lt(start)]
            for contract in g.to_dict('records'):
                field='longPrice' if contract['long'] else 'shortPrice'
                q=pd.to_numeric(z[field],errors='coerce')
                part=z.loc[q.gt(0)&q.lt(1),['timestamp','raw_pointer']].copy()
                part['price']=q.loc[part.index].astype(float)
                for key in ['game_id','sport','side','provider','market_id','contract_id','market_created_at']:part[key]=contract[key]
                part['request_number']=int(m['request_number']);part['raw_field']=field
                if len(part):
                    table=pa.Table.from_pandas(part,preserve_index=False)
                    if writer is None:writer=pq.ParquetWriter(temporary,table.schema,compression='zstd')
                    writer.write_table(table);total+=len(part)
        pct=int(10*(i+1)/len(groups))
        if pct!=last:
            print('US history',pct*10,'%',i+1,'/',len(groups),'points',total,flush=True);last=pct
    if writer:writer.close();temporary.replace(RESULT/'us_price_points.parquet')
    else:pd.DataFrame(columns=['game_id','sport','side','provider','market_id','contract_id','market_created_at','timestamp','price','request_number','raw_pointer','raw_field']).to_parquet(RESULT/'us_price_points.parquet',index=False)
    dump(RESULT/'history_acquisition.json',audit)
    executor.shutdown()

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('stage',choices=['probe','discover','match','history']);args=a.parse_args()
    globals()[args.stage]()

