"""Shared paths, raw-first official retrieval and immutable research provenance."""
from pathlib import Path
from contextlib import closing
import datetime as dt
import hashlib
import http.client
import json
import os
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

PROJECT = Path(__file__).resolve().parents[2]
PREVIOUS = PROJECT/'collected data/result/soccer_nhl_granular'
ROOT_OUT = PROJECT/'collected data/result/nhl_soccer_iteration'
RUN_LABEL=os.environ.get('SPORTS_RESEARCH_RUN','')
assert not RUN_LABEL or (RUN_LABEL.replace('_','').isalnum() and len(RUN_LABEL)<80)
OUT = ROOT_OUT/RUN_LABEL if RUN_LABEL else ROOT_OUT
RAW = PROJECT/'collected data/raw/nhl_soccer_iteration'
REPORTS = PROJECT/'reports/nhl_soccer_iteration'
for path in [OUT, RAW, REPORTS]:path.mkdir(parents=True, exist_ok=True)

def stamp():return dt.datetime.now(dt.UTC).isoformat()
def file_sha256(path):
    """Hash large source databases without allocating the entire file in RAM."""
    digest=hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda:handle.read(4*1024*1024),b''):digest.update(block)
    return digest.hexdigest()
def dump(path, value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,allow_nan=False,default=str),encoding='utf8');tmp.replace(path)
def read_db(path):
    c=sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;return c

class OfficialClient:
    HOSTS={'www.premierleague.com','sdp-prem-prod.premier-league-prod.pulselive.com','api-web.nhle.com','api.nhle.com','www.nhl.com','www.uefa.com','match.uefa.com','stats.uefa.com','compstats.uefa.com','matchstats.uefa.com','seriea-api.prd.sdp.deltatre.digital','bundesliga-web-prod.europe-west1.firebasedatabase.app','www.laliga.com','ma-api.ligue1.fr'}
    def __init__(self, per_second=4, timeout_seconds=35):
        assert 0<timeout_seconds<=120
        self.rate=per_second;self.timeout_seconds=timeout_seconds;self.lock=threading.Lock();self.next_at={};self.local=threading.local()
        with closing(self.connect()) as c:
            c.executescript('''CREATE TABLE IF NOT EXISTS request_audit(
            request_number INTEGER PRIMARY KEY AUTOINCREMENT,request_type TEXT,intent TEXT,return_status TEXT,
            url TEXT,retrieved_at_utc TEXT,raw_file TEXT,sha256 TEXT,error TEXT);
            CREATE INDEX IF NOT EXISTS requests_url ON request_audit(url);
            CREATE VIEW IF NOT EXISTS request_log AS SELECT request_number,request_type,intent,return_status FROM request_audit;''')
    def connect(self):
        c=sqlite3.connect(OUT/'acquisition.sqlite',timeout=60);c.row_factory=sqlite3.Row;c.execute('PRAGMA journal_mode=WAL');return c
    def get(self,url,intent,kind='official_player_statistics',document=False,refresh=False):
        u=urllib.parse.urlsplit(url);assert u.scheme=='https' and u.hostname in self.HOSTS
        c=self.connect()
        try:
            old=c.execute("SELECT * FROM request_audit WHERE url=? AND return_status='200' AND raw_file IS NOT NULL AND sha256 IS NOT NULL ORDER BY request_number DESC LIMIT 1",(url,)).fetchone()
            if old and not refresh:
                b=(PROJECT/old['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==old['sha256']
                return b if document else json.loads(b),dict(old)
            for attempt in range(4):
                with self.lock:
                    when=max(time.monotonic(),self.next_at.get(u.hostname,0));self.next_at[u.hostname]=when+1/self.rate
                time.sleep(max(0,when-time.monotonic()))
                body=None;status='NETWORK_ERROR';error=None;retry_after=None
                try:
                    request=urllib.request.Request(url,headers={'User-Agent':'SportsPredictionResearch/1.0','Accept':'application/json,text/html;q=0.8'})
                    with urllib.request.urlopen(request,timeout=self.timeout_seconds) as response:
                        body=response.read()
                        status=str(response.status)
                except urllib.error.HTTPError as exc:
                    status=str(exc.code);error=str(exc);retry_after=exc.headers.get('Retry-After')
                    try:body=exc.read()
                    except (OSError,TimeoutError,http.client.HTTPException) as read_error:
                        # A failed HTTP error-body read must still be logged
                        # and retried under the original HTTP status.
                        body=getattr(read_error,'partial',None)
                        error+='; error response body read failed: '+str(read_error)
                except (OSError,TimeoutError,urllib.error.URLError,http.client.HTTPException) as exc:
                    status='NETWORK_ERROR';error=str(exc)
                at=stamp();digest=None;raw=None
                if body is not None:
                    digest=hashlib.sha256(body).hexdigest();file=RAW/(digest+('.html' if document else '.json'))
                    if not file.exists():file.write_bytes(body)
                    raw=file.relative_to(PROJECT).as_posix()
                with c:
                    rid=c.execute('INSERT INTO request_audit(request_type,intent,return_status,url,retrieved_at_utc,raw_file,sha256,error) VALUES (?,?,?,?,?,?,?,?)',(kind,intent,status,url,at,raw,digest,error)).lastrowid
                meta=dict(request_number=rid,request_type=kind,intent=intent,return_status=status,url=url,retrieved_at_utc=at,raw_file=raw,sha256=digest,error=error)
                if status=='200':return body if document else json.loads(body),meta
                if status not in {'429','500','502','503','504','NETWORK_ERROR'} or attempt==3:return None,meta
                delay=max(2**attempt,float(retry_after or 0)) if not retry_after or retry_after.isdigit() else 30
                with self.lock:self.next_at[u.hostname]=max(self.next_at.get(u.hostname,0),time.monotonic()+delay)
            raise AssertionError('unreachable')
        finally:c.close()
