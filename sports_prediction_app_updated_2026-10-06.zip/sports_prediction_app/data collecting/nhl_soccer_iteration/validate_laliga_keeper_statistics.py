"""Independent native-identity and raw-cell replay of official La Liga keepers."""
import argparse
import collections
import hashlib
import json
import urllib.parse
import pandas as pd
from common import ROOT_OUT,PROJECT,read_db,dump,stamp,file_sha256,OfficialClient
from collect_laliga_keeper_statistics import FOLDER,PILOT

PUBLIC = {
    'HIST_LAL_16391': dict(date='2021-05-11',scoreA=3,scoreB=3,
        url='https://www.fcbarcelona.com/en/football/first-team/news/2138978/-3-3',
        observation='Levante 3-3 Barcelona; dated official report names Ter Stegen. Keeper saves are checked against API, not asserted visible in report.'),
    'HIST_LAL_22290': dict(date='2022-03-20',scoreA=4,scoreB=0,
        url='https://www.fcbarcelona.com/en/football/first-team/news/2544426/-0-4real-madrid-0-4-barca-the-clasico-is-blaugrana',
        observation='Real Madrid 0-4 Barcelona; official report names Courtois and Ter Stegen.'),
    'HIST_LAL_87884': dict(date='2024-05-24',scoreA=0,scoreB=7,
        url='https://www.gironafc.cat/en/matches/season-2023-2024-laliga-ea-sports-38-girona-fc-vs-granada-cf',
        observation='Girona 7-0 Granada; official starting lineup names Gazzaniga and Marc Martinez. Displayed saves not used to override raw API.'),
}


def main(pilot=False):
    with read_db(FOLDER/'statistics.sqlite') as db:records=[json.loads(b) for b, in db.execute('SELECT body FROM games')]
    from common import PREVIOUS
    with read_db(PREVIOUS/'expanded.sqlite') as db:games={r['game_id']:dict(r) for r in db.execute("SELECT * FROM soccer_games WHERE league='La Liga'")}
    cache={};sources=set();cells=0;rows=0;seen=set();public=[]
    def raw(ref):
        path=PROJECT/ref['raw_file'];digest=ref['sha256']
        if digest not in cache:
            blob=path.read_bytes();assert hashlib.sha256(blob).hexdigest()==digest
            if len(cache)>30:cache.clear()
            cache[digest]=json.loads(blob);sources.add(digest)
        return cache[digest]
    def pointer(data,path):
        for k in path.strip('/').split('/'):data=data[int(k)] if isinstance(data,list) else data[k]
        return data
    if pilot:
        records=[r for r in records if r['game_id'] in PILOT];assert len(records)==3
    for r in records:
        if not r.get('fixture_source') or r['fixture_source']['return_status']!='200':
            assert not r['players'];continue
        f=raw(r['fixture_source']);idx=r['index'];g=games[r['game_id']]
        if any(i['reason']=='fixture_schema_or_identity_error' for i in r['issues']):
            assert not r['players'];continue
        assert str(int(f['id']))==idx['club_fixture_id']
        assert f['altIds']['opta']==idx['opta_match_id']
        assert f['status']=='C' and f['phase']=='F'
        assert pd.Timestamp(f['kickoff']['millis'],unit='ms',tz='UTC')==pd.Timestamp(g['timestamp'])
        assert [str(int(t['team']['id'])) for t in f['teams']]==[idx['club_home_id'],idx['club_away_id']]
        assert [t['score'] for t in f['teams']]==[g['scoreB'],g['scoreA']]
        for p in r['players']:
            role=p['role_evidence'];assert raw(role['source'])==f
            actor=pointer(f,role['pointer'].rsplit('/',1)[0]);assert actor['matchPosition']=='G'
            assert actor['altIds']['opta']==p['official_player_id']
            assert str(int(actor['id']))==role['club_player_id']
            section=f['teamLists'][int(role['pointer'].split('/')[2])]
            assert str(int(section['teamId']))==idx['club_away_id' if p['side']=='A' else 'club_home_id']
            assert p['team_id']==str(json.loads(g['native_team_ids_json'])[0 if p['side']=='A' else 1])
            s=raw(p['source']);assert s['entity']['altIds']['opta']==p['official_player_id'] and str(int(s['entity']['id']))==role['club_player_id']
            url=urllib.parse.urlsplit(p['source']['url']);assert urllib.parse.parse_qs(url.query)['fixtures']==[idx['club_fixture_id']]
            assert url.path.endswith('/stats/player/'+role['club_player_id'])
            mapping={'minutes':'mins_played','saves':'saves','goals_conceded':'goals_conceded','keeper_xgot_conceded':'expected_goals_on_target_conceded'}
            for field,native in mapping.items():
                entries=[cell['value'] for cell in s['stats'] if cell['name']==native];assert len(entries)<=1
                expected=entries[0] if entries else None
                assert expected==p[field]
                proof=p['field_evidence'][field];assert proof['raw_value']==expected
                if proof['pointer']:assert pointer(s,proof['pointer'])==expected
                else:assert not entries
                cells+=1
            assert 0<p['minutes']<=110
            assert pd.Timestamp(p['available_at_utc'])==pd.Timestamp(g['available_time'])>pd.Timestamp(g['timestamp'])
            key=(p['game_id'],p['side'],p['official_player_id']);assert key not in seen;seen.add(key);rows+=1
        if pilot:
            assert {p['side'] for p in r['players']}=={'A','B'}
            check=PUBLIC[r['game_id']]
            assert all(g[k]==check[k] for k in ['date','scoreA','scoreB'])
            public.append(dict(game_id=r['game_id'],teamA=g['teamA'],teamB=g['teamB'],start_time=g['timestamp'],
                               **check,endpoint=r['fixture_source']['url'],retrieved_at_utc=r['fixture_source']['retrieved_at_utc'],
                               players=[{k:p[k] for k in ['official_player_id','player_name','side','minutes','saves','goals_conceded','keeper_xgot_conceded']} for p in r['players']],
                               matches=True,discrepancy=None,verification_scope='Public date, identities and final score; UTC kickoff and numeric cells independently replayed against official source API.'))
    if pilot:
        # These three pages were manually inspected; keep their original bytes.
        OfficialClient.HOSTS.update(['www.fcbarcelona.com','www.gironafc.cat'])
        c=OfficialClient(per_second=2)
        for row in public:
            body,source=c.get(row['url'],'Manual public validation of official La Liga result '+row['game_id'],'official_keeper_public_validation',document=True)
            assert body is not None,source['return_status'];row['public_source']=source
        dump(FOLDER/'public_validation.json',dict(at_utc=stamp(),manual_review=True,examples=public))
    result=dict(at_utc=stamp(),status='PASS',games=len(records),keeper_rows=rows,raw_cells=cells,raw_responses=len(sources),
                source_sha256=file_sha256(FOLDER/'statistics.sqlite'),zero_imputation=False,
                unknown_fields_preserved=True,past_only_availability=True,public_examples=3 if pilot else None)
    dump(FOLDER/('pilot_validation.json' if pilot else 'validation.json'),result);print(json.dumps(result),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');main(p.parse_args().pilot)
