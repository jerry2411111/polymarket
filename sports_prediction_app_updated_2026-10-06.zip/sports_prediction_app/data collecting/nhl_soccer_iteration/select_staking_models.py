"""Select the strongest saved, audited forecasts before comparing stake rules.

All candidates are compared on identical2024/25 games and decision timestamps.
No market prices, account returns or2026 outcomes select the forecast model.
"""
import json
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score
from common import ROOT_OUT, dump, stamp, file_sha256
from research_loop import prior_baseline

RESULT = ROOT_OUT/'simulation_results/staking_model_selection'


def candidates(sport):
    reference_path=ROOT_OUT/'retained_models'/sport/'development_predictions.parquet'
    reference=pd.read_parquet(reference_path)
    for name,g in reference.groupby('variant'):
        yield dict(name='retained/'+name,source=reference_path,variant=name,component='primary'),g
    for path in sorted((ROOT_OUT/'simulation_results').rglob('development_predictions.parquet')):
        p=pd.read_parquet(path)
        if 'sport' not in p or set(p.sport)!={sport}:continue
        if not (path.parent/'validation.json').exists():continue
        audit=json.loads((path.parent/'validation.json').read_bytes())
        if audit.get('status') not in [None,'PASS']:continue
        for name,g in p.groupby('variant'):
            if name in ['retained','baseline']:continue
            source_name=path.parent.relative_to(ROOT_OUT/'simulation_results').as_posix()
            components=['primary','secondary','mean'] if {'second_p0','second_p1'}.issubset(g.columns) else ['primary']
            for component in components:
                if component!='primary' and not g[['second_p0','second_p1']].notna().all().all():continue
                out=g.copy()
                if component=='secondary':out[['p0','p1']]=g[['second_p0','second_p1']].to_numpy()
                elif component=='mean':out[['p0','p1']]=(g[['p0','p1']].to_numpy()+g[['second_p0','second_p1']].to_numpy())/2
                yield dict(name=source_name+'/'+name+'/'+component,source=path,variant=name,component=component),out


def main():
    assert not (RESULT/'selection.json').exists(),'Preserve completed model selection'
    RESULT.mkdir(exist_ok=True)
    plan=dict(at_utc=stamp(),reason='User requests best predictive models followed by staking tests, with overall accuracy at least52%, not a52%bet filter.',
        candidate_scope='All retained and completed audited saved development forecast files; exclude files without validation. Include each existing paired primary/secondary and their unweighted mean.',
        selection='Lowest pooled2024/25 log loss on identical retained-reference fixtures, subject to pooled argmax accuracy>=52% and beating expanding class-frequency logloss in eachyear. Ties by Brier then name.',
        no_return_selection=True,no_2026_read=True,no_new_model_fit=True,
        scope_limit='Best among this reproducible saved candidate pool; no claim of a globally optimal model. Repeated development comparisons carry selection uncertainty.',
        historical_decisions='Old combined trading/model gates remain as originally recorded. Selection for new staking tests does not replace app or retained baselines.')
    dump(RESULT/'plan.json',plan)
    metrics=[];exclusions=[];selections={};sources={}
    for sport in ['nhl','soccer']:
        original=pd.read_parquet(ROOT_OUT/'retained_models'/sport/'development_predictions.parquet')
        reference=original.drop_duplicates('game_id').set_index('game_id').sort_index()
        base=prior_baseline(sport,reference.reset_index()).loc[reference.index]
        k=3 if sport=='soccer' else 2;fields=['p'+str(i) for i in range(k)]
        y=reference.target.to_numpy(int);frequency=base[fields].to_numpy()
        reference_loss=-np.log(frequency[np.arange(len(y)),y])
        catalog={}
        for meta,p in candidates(sport):
            p=p.set_index('game_id')
            if p.index.duplicated().any() or not reference.index.isin(p.index).all():
                exclusions.append(dict(sport=sport,model=meta['name'],reason='Does not cover unique complete comparison cohort'));continue
            all_count=len(p);p=p.loc[reference.index]
            assert p.target.eq(reference.target).all() and p.prediction_time.eq(reference.prediction_time).all()
            assert p.train_label_max.lt(p.prediction_time).all()
            assert p.calibration_label_max.lt(p.prediction_time).all()
            probability=p[fields].to_numpy();assert np.isfinite(probability).all() and np.allclose(probability.sum(axis=1),1)
            loss=-np.log(probability[np.arange(len(y)),y]);pick=probability.argmax(axis=1)
            key=meta['name'];catalog[key]=meta
            source=str(meta['source'].relative_to(ROOT_OUT));sources[source]=file_sha256(meta['source'])
            for year in [2024,2025,'pooled']:
                mask=np.ones(len(p),bool) if year=='pooled' else p.prediction_time.dt.year.eq(year).to_numpy()
                metrics.append(dict(sport=sport,model=key,year=str(year),games=int(mask.sum()),full_source_games=all_count,
                    logloss=float(loss[mask].mean()),frequency_logloss=float(reference_loss[mask].mean()),
                    accuracy=float(np.mean(pick[mask]==y[mask])),
                    brier=float(np.mean(np.square(probability[mask]-np.eye(k)[y[mask]]).sum(axis=1))),
                    macro_f1=float(f1_score(y[mask],pick[mask],labels=range(k),average='macro',zero_division=0))))
        frame=pd.DataFrame(metrics);frame=frame[frame.sport.eq(sport)]
        eligible=[]
        for name,g in frame.groupby('model'):
            pooled=g[g.year.eq('pooled')].iloc[0]
            annual=g[~g.year.eq('pooled')]
            if pooled.accuracy>=.52 and annual.logloss.lt(annual.frequency_logloss).all():eligible.append(pooled)
        assert eligible,'No candidate meets declared forecast-skill requirements'
        selected=pd.DataFrame(eligible).sort_values(['logloss','brier','model']).iloc[0]
        meta=catalog[selected.model]
        selections[sport]=dict(model=selected.model,source=str(meta['source'].relative_to(ROOT_OUT)),
            source_sha256=sources[str(meta['source'].relative_to(ROOT_OUT))],variant=meta['variant'],component=meta['component'],
            comparison_games=int(selected.games),full_source_games=int(selected.full_source_games),
            development_logloss=float(selected.logloss),development_accuracy=float(selected.accuracy),
            candidate_forecasts_compared=len(catalog),adopted_in_app=False,retained_baseline_unchanged=True)
    pd.DataFrame(metrics).to_csv(RESULT/'model_metrics.csv',index=False)
    dump(RESULT/'selection.json',dict(at_utc=stamp(),status='PASS',selections=selections,
        excluded_candidates=exclusions,source_sha256=sources,no_2026_read=True,no_prices_or_returns_read=True))
    print(json.dumps(selections),flush=True)


if __name__=='__main__':main()
