"""Dated official Serie A rosters and recorded player events, 2021 onward.

Event counts describe the retained feed, not a claim that every on-ball action
is provided. Minutes exclude stoppage time and require a coherent substitution
history. Raw lineups and feeds remain independently reproducible.
"""
import argparse
import collections
import concurrent.futures
import hashlib
import json
import sqlite3
from pathlib import Path
import pandas as pd
from common import PROJECT,ROOT_OUT,PREVIOUS,OfficialClient,read_db,dump,stamp

def cached():
    paths=json.loads((PROJECT/'final_models/sources/path_map.json').read_text())
    found={}
    for filename in ['soccer_statistics.sqlite','player_depth.sqlite']:
        with read_db(PROJECT/'collected data/result'/filename) as c:
            for raw in c.execute("SELECT * FROM source_manifest WHERE status=200 AND endpoint LIKE '%seriea-api.%'"):
                r=dict(raw);path=r['raw_file'].replace('\\','/')
                for old,new in paths.items():
                    old,new=old.replace('\\','/'),new.replace('\\','/')
                    if path.startswith(old):path=new+path[len(old):];break
                if (PROJECT/path).exists():r['raw_file']=path;found[r['endpoint']]=r
    return found

def read_source(r):
    body=(PROJECT/r['raw_file']).read_bytes();assert hashlib.sha256(body).hexdigest()==r['sha256']
    return json.loads(body)

def parse(game,lineup,feed,sources,require_full_lineup=True):
    assert str(lineup['matchId'])==str(feed['matchId'])==game['official_game_id']
    assert feed['status']=='FINISHED' and feed['pagination']['isLastPage']
    native=json.loads(game['native_team_ids_json']);rows={};side_index={}
    for side,letter,team in zip(['away','home'],['A','B'],native):
        group=lineup[side];assert group['teamId']==team
        assert len(group['fielded'])==11 if require_full_lineup else 0<len(group['fielded'])<=11
        for started,players in [(1,group['fielded']),(0,group['benched'])]:
            for p in players:
                pid=p['playerId'];assert pid not in rows;side_index[pid]=side
                # Official report says statistics become final 24h after the
                # game. Use a conservative extra day after recorded completion.
                available=(pd.Timestamp(game['available_time'])+pd.Timedelta(days=1)).isoformat()
                rows[pid]=dict(game_id=game['game_id'],official_game_id=game['official_game_id'],league=game['league'],date=game['date'],side=letter,team_id=team,official_player_id=pid,player_name=p.get('shirtName') or p.get('shortName'),role=p.get('roleLabel'),started=started,available_at_utc=available,minutes=None,minutes_basis='Regulation-clock participation, excluding stoppage; coherent official lineup substitutions required',recorded_goals=0,recorded_assists=0,recorded_shots=0,recorded_yellow_cards=0,recorded_red_cards=0,event_pointers=[],source=sources,lineup_events=p.get('events',[]))
    assert set(rows)
    ids=[e['eventId'] for e in feed['events']];repeated_ids=[k for k,v in collections.Counter(ids).items() if v>1]
    credited=collections.Counter();seen=set()
    for i,e in enumerate(feed['events']):
        typ=e['type']
        if not (typ.startswith('attempt-') or typ in ['goal','penalty-goal','own-goal','yellow-card','red-card','second-yellow-card']):continue
        for side in ['away','home']:
            part=e.get(side)
            if not part or not part.get('player'):continue
            phase=e.get('phase') or part.get('phase')
            if phase not in ['FirstHalf','SecondHalf','FIRST_HALF','SECOND_HALF']:continue
            p=part['player'];pid=p.get('playerId')
            if pid not in rows:continue
            # In old feeds an own goal is nested under the benefited side,
            # while its embedded player/team still identifies the defender.
            assert side_index[pid]==side or typ=='own-goal','Unexpected event/lineup team disagreement'
            event_key=(e['eventId'],pid,phase,part.get('time',e.get('time')))
            category='shot' if typ.startswith('attempt-') else typ
            if (category,event_key) in seen:continue
            seen.add((category,event_key))
            r=rows[pid];field=None
            if typ in ['goal','penalty-goal']:field='recorded_goals';credited[side]+=1
            elif typ=='own-goal':credited['home' if side_index[pid]=='away' else 'away']+=1
            elif typ=='yellow-card':field='recorded_yellow_cards'
            elif typ in ['red-card','second-yellow-card']:field='recorded_red_cards'
            if field:r[field]+=1;r['event_pointers'].append('/events/'+str(i))
            if typ.startswith('attempt-') or typ in ['goal','penalty-goal']:r['recorded_shots']+=1
            aid=p.get('assistPlayerId')
            if typ in ['goal','penalty-goal'] and aid in rows:
                assert side_index[aid]==side;rows[aid]['recorded_assists']+=1
    # If the feed cannot reproduce the official score, its goal counts are
    # retained as observed counts but explicitly flagged, never used as totals.
    reconciled=[credited['away'],credited['home']]==[game['scoreA'],game['scoreB']]
    for r in rows.values():
        r['parser_version']=4;r['repeated_raw_event_ids']=repeated_ids
        if not require_full_lineup:
            r['lineup_complete']=all(len(lineup[s]['fielded'])==11 for s in ['away','home'])
            r['lineup_scope']='Only published native players; absent lineup entries are not inferred'
        start=0 if r['started'] else None;end=90;issues=[]
        for e in r['lineup_events']:
            if e.get('phase') not in ['FIRST_HALF','SECOND_HALF','FirstHalf','SecondHalf']:continue
            typ=e['type'];minute=e.get('time')
            if typ not in ['substitution-in','substitution-out','red-card','second-yellow-card']:continue
            if not isinstance(minute,(int,float)):issues.append('Missing substitution/card minute');continue
            minute=max(0,min(90,minute))
            if typ=='substitution-in':
                if start is not None:issues.append('Duplicate entry')
                start=minute
            else:end=min(end,minute)
        if start is not None and end>=start and not issues:r['minutes']=end-start
        r['goal_counts_reconcile']=reconciled;r['minutes_issues']=issues
        r['did_play']=bool(r['started'] or start is not None)
        if not r['did_play']:r['minutes']=0
        r['count_basis']='Count of explicit matching player events in official feed; omitted actions are not asserted absent from the real match'
    return list(rows.values())

def main():
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int);p.add_argument('--workers',type=int,default=6);a=p.parse_args()
    cache=cached();client=OfficialClient(per_second=3)
    with read_db(PREVIOUS/'expanded.sqlite') as c:games=[dict(r) for r in c.execute("SELECT * FROM soccer_games WHERE league='Serie A' AND date BETWEEN '2021-01-01' AND '2026-09-30' ORDER BY date,game_id")]
    db=sqlite3.connect(ROOT_OUT/'seriea_players.sqlite',timeout=60)
    db.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT); CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,reason TEXT);')
    done={r[0] for r in db.execute("SELECT game_id FROM games WHERE json_extract(body,'$[0].parser_version')=4")};tasks=[];no_feed=[]
    by_native={url.rsplit('/matches/',1)[1].rsplit('/',1)[0]:url for url in cache if '/matches/' in url and url.endswith('/feed')}
    from urllib.parse import quote
    for g in games:
        if g['game_id'] in done:continue
        url=by_native.get(quote(g['official_game_id'],safe=''))
        if not url:no_feed.append(g['game_id']);continue
        tasks.append((g,url))
    if a.limit:tasks=tasks[:a.limit]
    dump(ROOT_OUT/'seriea_collection_scope.json',dict(games=len(games),pending=len(tasks),no_retained_feed=no_feed,window=['2021-01-01','2026-09-30']))
    def fetch(task):
        g,url=task
        try:
            source=cache[url];feed=read_source(source);lineup_url=url[:-4]+'lineups'
            if lineup_url in cache:ls=cache[lineup_url];lineup=read_source(ls)
            else:lineup,ls=client.get(lineup_url,g['date']+' '+g['teamA']+' / '+g['teamB']+' official dated lineup',kind='official_lineup')
            if not lineup:raise ValueError('Missing official lineup: '+ls['return_status'])
            return g['game_id'],parse(g,lineup,feed,dict(lineup=ls,feed=source)),None
        except Exception as exc:return g['game_id'],None,type(exc).__name__+': '+str(exc)
    milestone=10;counts=collections.Counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
        for n,(gid,rows,error) in enumerate(pool.map(fetch,tasks),1):
            with db:
                if rows:
                    db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(gid,json.dumps(rows,allow_nan=False)));db.execute('DELETE FROM issues WHERE game_id=?',(gid,));counts['games']+=1;counts['players']+=len(rows)
                else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?)',(gid,error));counts['issues']+=1
            if n*100>=milestone*len(tasks) or n==len(tasks):
                progress=dict(at_utc=stamp(),processed=n,total=len(tasks),percent=round(100*n/len(tasks),1),counts=dict(counts));dump(ROOT_OUT/'seriea_collection_progress.json',progress);print(json.dumps(progress),flush=True);milestone+=10
    db.close()

if __name__=='__main__':main()
