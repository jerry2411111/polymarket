"""Preserve statistics IDs while linking strictly verified dated lineup aliases."""
import copy,json,sqlite3
import pandas as pd
from common import OfficialClient,read_db,dump,stamp
from cup_identity_repair import RUN,PRIOR
from uefa_native_identity import identity_matches,original


def main():
    reference=json.loads((RUN/'current_identity_api_reference.json').read_bytes());assert reference['endpoint_declaration']=='v2/players'
    with read_db(PRIOR/'match_statistics.sqlite') as db:records=[json.loads(body) for body, in db.execute('SELECT body FROM games')]
    ids=sorted({p['official_player_id'] for r in records for p in r['players'] if not p['lineup_identity_verified']})
    OfficialClient.HOSTS.add('comp.uefa.com');client=OfficialClient(per_second=2);profiles={};sources={}
    for n,pid in enumerate(ids,1):
        body,s=client.get('https://comp.uefa.com/v2/players?playerIds='+pid,'Recover exact native identity for dated cup statistics player '+pid,'official_player_identity')
        sources[pid]=s
        if isinstance(body,list) and len(body)==1 and str(body[0]['id'])==pid:profiles[pid]=body[0]
        if n%3==0 or n==len(ids):print(json.dumps(dict(stage='cup_native_identity',processed=n,total=len(ids))),flush=True)
    repaired=copy.deepcopy(records);proofs=[];pending=[]
    for g in repaired:
        lineup=original(g['source_links']['lineup']);gid=g['game_validation']['game_id']
        existing={p['official_player_id'] for p in g['players']}
        for p in g['players']:
            old=p['official_player_id'];p['lineup_player_id']=old if p['lineup_identity_verified'] else None;p['identity_evidence_json']=None
            if p['lineup_identity_verified']:continue
            label='awayTeam' if p['side']=='A' else 'homeTeam';team=lineup[label];assert str(team['team']['id'])==p['team_id']
            profile=profiles.get(old);matched=[(group,i,v['player']) for group in ['field','bench'] for i,v in enumerate(team[group]) if profile and identity_matches(profile,v['player'])]
            info=dict(game_id=gid,side=p['side'],team_id=p['team_id'],statistics_player_id=old,profile_source=sources[old],lineup_source=g['source_links']['lineup'])
            if len(matched)!=1:pending.append(info|dict(reason='No unique exact name,birthdate,gender,nationality match on same dated team'));continue
            group,i,node=matched[0];native=str(node['id'])
            if native in existing:pending.append(info|dict(reason='Both native statistics identities exist; no automatic merge',proposed_id=native));continue
            proof=info|dict(lineup_player_id=native,profile_pointer='/0',lineup_pointer=f'/{label}/{group}/{i}/player',
                method='Unique exact registered name,birthdate,gender,nationality on same dated team; inferred alias supported by official identity records',
                full_name=node.get('internationalName') or node['translations']['name']['EN'],birth_date=node['birthDate'],gender=node['gender'],country_code=node['countryCode'])
            # Independent raw replay of the exact attributes, not a source name shortcut.
            raw=original(sources[old])[0];assert str(raw['id'])==old
            assert raw['birthDate']==node['birthDate'] and raw['gender']==node['gender']
            left={raw.get('internationalName'),raw.get('translations',{}).get('name',{}).get('EN')}-{None};right={node.get('internationalName'),node.get('translations',{}).get('name',{}).get('EN')}-{None}
            assert {s.strip().casefold() for s in left}&{s.strip().casefold() for s in right}
            assert (raw.get('countryCode')==node.get('countryCode') and raw.get('countryCode')) or (raw.get('nationalTeamId')==node.get('nationalTeamId') and raw.get('nationalTeamId'))
            proofs.append(proof);p.update(lineup_player_id=native,lineup_identity_verified=True,player_name=proof['full_name'],lineup_group=group,position=node.get('fieldPosition'),identity_evidence_json=json.dumps(proof,sort_keys=True))
        linked=[p['lineup_player_id'] for p in g['players'] if p['lineup_player_id']];assert len(linked)==len(set(linked)),gid
    old=pd.DataFrame([p for g in records for p in g['players']]);new=pd.DataFrame([p for g in repaired for p in g['players']])
    immutable=[c for c in old if c not in ['lineup_identity_verified','player_name','lineup_group','position']]
    pd.testing.assert_frame_equal(new[immutable],old[immutable],check_exact=True)
    with sqlite3.connect(RUN/'cup_statistics.sqlite') as db:
        db.execute('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT)')
        db.executemany('INSERT OR REPLACE INTO games VALUES (?,?)',[(g['game_validation']['game_id'],json.dumps(g,allow_nan=False)) for g in repaired])
    new.to_parquet(RUN/'cup_players_repaired.parquet',index=False)
    dump(RUN/'native_identity_proofs.json',dict(proofs=proofs,pending=pending,profile_sources=sources,reference=reference))
    report=dict(status='PASS',at_utc=stamp(),profiles=len(ids),returned_profiles=len(profiles),resolved_rows=len(proofs),pending_rows=len(pending),
        pending_pct=100*len(pending)/len(new),raw_numeric_values_and_native_statistics_ids_unchanged=True,profile_attributes_and_dated_team_independently_checked=True)
    dump(RUN/'native_identity_validation.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
