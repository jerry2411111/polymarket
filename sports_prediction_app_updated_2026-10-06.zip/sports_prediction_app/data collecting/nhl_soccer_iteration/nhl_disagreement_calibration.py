"""Diagnose NHL losses and test one earlier-only disagreement calibration.

Groups describe failures; they are not hindsight eligibility filters. Underlying
2021+ rolling forecasts remain fixed. Rejected probability maps are not deployed.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit, logit
from sklearn.metrics import log_loss, brier_score_loss, accuracy_score

from common import ROOT_OUT, PREVIOUS, REPORTS, read_db, dump, stamp, file_sha256
from nhl_sports_combination import source

LABEL = 'nhl_disagreement_calibration'
RESULT = ROOT_OUT/'simulation_results'/LABEL


def mapping(p, second, alpha):
    """Preserve sides and winner; damp log odds when models disagree."""
    a = logit(np.clip(np.asarray(p, float), 1e-10, 1-1e-10))
    b = logit(np.clip(np.asarray(second, float), 1e-10, 1-1e-10))
    return expit(a/(1+alpha*np.abs(a-b)))


def fit(train):
    a = logit(train.p1.to_numpy())
    d = np.abs(a-logit(train.second_p1.to_numpy()))
    y = train.target.to_numpy(float)
    def objective(theta):
        z = a/(1+theta[0]*d)
        derivative = -a*d/(1+theta[0]*d)**2
        return float(np.mean(np.logaddexp(0, z)-y*z)), np.array([np.mean((expit(z)-y)*derivative)])
    result = minimize(objective, [0.], method='L-BFGS-B', jac=True,
                      bounds=[(0, None)], options={'ftol': 1e-12, 'gtol': 1e-9})
    assert result.success, result.message
    alpha = float(result.x[0])
    assert alpha >= 0 and np.isfinite(alpha)
    assert objective([alpha])[0] <= objective([0.])[0]+1e-12
    return alpha


def rolling(p):
    parts, fits = [], []
    for fold, test in p.groupby(p.prediction_time.dt.strftime('%Y-%m')):
        cutoff = pd.Timestamp(fold+'-01', tz='UTC')
        train = p[p.available_time.lt(cutoff)]
        counts = train.target.value_counts()
        ready = len(train) >= 100 and len(counts) == 2 and counts.min() >= 10
        alpha = fit(train) if ready else 0.
        f = test.copy()
        f['corrected_p1'] = mapping(f.p1, f.second_p1, alpha)
        f['disagreement_alpha'] = alpha
        f['correction_ready'] = ready
        f['correction_cutoff'] = cutoff
        f['correction_label_max'] = train.available_time.max()
        assert not len(train) or train.available_time.max() < f.prediction_time.min()
        assert np.array_equal(f.corrected_p1.ge(.5), f.p1.ge(.5))
        parts.append(f)
        fits.append(dict(fold=fold,prior_games=len(train),ready=bool(ready),alpha=alpha,
                         last_label=None if train.empty else str(train.available_time.max())))
    output = pd.concat(parts, ignore_index=True)
    for c in ['correction_cutoff','correction_label_max']:
        output[c] = pd.to_datetime(output[c], utc=True, format='mixed').astype('datetime64[ns, UTC]')
    return output, pd.DataFrame(fits)


def diagnose(p):
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        g = pd.read_sql_query('SELECT game_id,official_game_id,teamA,teamB,phase,season,scoreA,scoreB,target,source_request_id,source_pointer FROM nhl_games', db)
    assert g.game_id.is_unique and p.official_game_id.is_unique
    meta = g.set_index('game_id').loc[p.game_id]
    assert np.array_equal(meta.target, p.target)
    assert np.array_equal(meta.official_game_id.astype(str), p.official_game_id.astype(str))
    assert np.array_equal(meta.target, meta.scoreB.gt(meta.scoreA).astype(int))
    a = p.copy()
    a['year'] = a.prediction_time.dt.year
    a['disagreement_band'] = pd.cut((a.p1-a.second_p1).abs(), [0,.01,.03,.05,1], include_lowest=True).astype(str)
    a['confidence'] = np.maximum(a.p0,a.p1)
    a['correct'] = a.p1.ge(.5).eq(a.target)
    a['brier'] = (a.p1-a.target)**2
    summary = a.groupby(['year','disagreement_band']).agg(games=('game_id','size'),
        mean_winner_probability=('confidence','mean'),winner_accuracy=('correct','mean'),brier=('brier','mean')).reset_index()
    summary.to_csv(RESULT/'model_disagreement_diagnosis.csv',index=False)
    path = ROOT_OUT/'simulation_results/nhl_sports_combination/margin_bets.parquet'
    b = pd.read_parquet(path)
    b = b[b.variant.eq('relative10')].copy()
    b = b.merge(g.drop(columns=['target','teamA','teamB']),on='game_id',validate='many_to_one')
    assert np.array_equal(b.won,b.side.eq(b.target))
    b['selected_team'] = np.where(b.side.eq(0),b.teamA,b.teamB)
    b['official_winner'] = np.where(b.target.eq(0),b.teamA,b.teamB)
    b['public_verification_url'] = 'https://www.nhl.com/gamecenter/'+b.official_game_id.astype(str)
    b['model_disagreement'] = (b.probability-b.secondary_probability).abs()
    b['disagreement_band'] = pd.cut(b.model_disagreement,[0,.01,.03,.05,1],include_lowest=True).astype(str)
    b['probability_band'] = pd.cut(b.probability,[0,.4,.5,.6,.7,1],include_lowest=True).astype(str)
    b['loss_cause_status'] = 'Observed forecast error; phase/disagreement are diagnostics, not proven causes'
    b[~b.won].sort_values(['provider','year','probability'],ascending=[True,True,False]).to_csv(RESULT/'losing_cases.csv',index=False)
    groups = []
    for field in ['phase','disagreement_band','probability_band']:
        for key,f in b.groupby(['provider','year',field], observed=True):
            groups.append(dict(provider=key[0],year=int(key[1]),group=field,value=key[2],bets=len(f),
                wins=int(f.won.sum()),win_rate=float(f.won.mean()),mean_model_probability=float(f.probability.mean()),
                mean_secondary_probability=float(f.secondary_probability.mean()),mean_price=float(f.price.mean()),
                losing_stakes=float(f.loc[~f.won,'stake'].sum()),net_profit=float(f.profit.sum()),
                predicted_profit=float((f.stake*(f.probability/f.price-1)).sum())))
    pd.DataFrame(groups).to_csv(RESULT/'bet_loss_groups.csv',index=False)
    return dict(official_scores_checked=len(p),losing_cases=int((~b.won).sum()),
                source_file=str(path.relative_to(ROOT_OUT)),source_sha256=file_sha256(path))


def metrics(p):
    rows=[]
    for name,col in [('reference','p1'),('disagreement','corrected_p1')]:
        for year,f in [('pooled',p)]+list(p.groupby(p.prediction_time.dt.year)):
            pr=f[col].to_numpy();y=f.target.to_numpy()
            rows.append(dict(variant=name,year=year,games=len(f),accuracy=accuracy_score(y,pr>=.5),
                logloss=log_loss(y,np.c_[1-pr,pr],labels=[0,1]),brier=brier_score_loss(y,pr)))
    return pd.DataFrame(rows)


def accounts(p,stage,providers=None,candidate_name='disagreement'):
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    transfer.RESULT=RESULT
    quotes=quote_inputs(RESULT/(stage+'_quote_quality.json'),revision='closest_v62')
    annual=[];bets=[];days=[];checks=[]
    for variant in ['reference',candidate_name]:
        f=p.copy()
        if variant==candidate_name:
            f['p1']=f.corrected_p1;f['p0']=1-f.p1
        normalized=transfer.normalize('nhl',f,quotes,True)
        ix=f.set_index('game_id').loc[normalized.game_id]
        normalized['secondary_probability']=np.where(normalized.side.eq(0),ix.second_p0,ix.second_p1)
        normalized=normalized[np.minimum(normalized.probability,normalized.secondary_probability)/normalized.price>=1.10]
        for provider,part in normalized.groupby('provider'):
            if providers is not None and provider not in providers:continue
            for year in sorted(p.prediction_time.dt.year.unique()):
                m,b,l,d=engine.simulate(part,int(year),'all_selected_outcomes','flat20_cash_only',5.,2000.)
                key=dict(sport='nhl',provider=provider,variant=variant,year=int(year))
                annual.append(key|m);checks.append(key|engine.validate(b,l,d,'flat20_cash_only',5.,2000.))
                if len(b):bets.append(b.assign(**key))
                days.append(d.assign(**key))
    a=pd.DataFrame(annual)
    a.to_csv(RESULT/(stage+'_annual.csv'),index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/(stage+'_bets.parquet'),index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/(stage+'_daily.parquet'),index=False)
    dump(RESULT/(stage+'_cash_validation.json'),dict(status='PASS',checks=checks))
    # Fixed-dollar positions common to both variants must preserve their cash flows.
    positions=pd.concat(bets,ignore_index=True)
    for _,part in positions.groupby(['provider','year']):
        x=part[part.variant.eq('reference')].set_index(['game_id','side'])
        y=part[part.variant.eq(candidate_name)].set_index(['game_id','side'])
        common=x.index.intersection(y.index)
        assert np.allclose(x.loc[common,['price','stake','profit']],y.loc[common,['price','stake','profit']],rtol=0,atol=1e-10)
    return a


def run():
    RESULT.mkdir(exist_ok=True)
    assert not (RESULT/'validation.json').exists()
    plan=dict(at_utc=stamp(),hypothesis='Large model disagreement accompanied weak2025forecasts and losses, but not2024. Test whether an earlier-only learned correction captures this without deleting losing groups.',
        formula='q=expit(logit(p)/(1+alpha*abs(logit(p)-logit(secondary)))); alpha>=0; one coefficient, no threshold grid.',
        fit='Monthly expanding all earlier settled out-of-fit forecasts. Minimize binary logloss, no market inputs. Identity until100earlier games and10of each class. Underlying sports models expand from2021; saved forecast archive starts2024.',
        unchanged='Primary winner cannot change. Original secondary probability, pre12closest-prior quote<=24h,10%relative advantage in both forecasts,one side,$20fixedstake,annual$2000cash-only.',
        gate='Lower pooled2024/25logloss andBrier; lower2025logloss; winner accuracy>=52%. Then2025providerSharpe higher,positive return,no worse drawdown;2024Sharpe no worse where defined.',
        evaluation='Only qualifying provider enters new2026evaluation. Repeatedly inspected2026is retrospective rolling research, not untouched holdout.',app_changed=False)
    dump(RESULT/'plan.json',plan)
    raw=source();diagnosis=diagnose(raw)
    p,fits=rolling(raw)
    prefix,_=rolling(raw[raw.prediction_time.dt.year.eq(2024)])
    pd.testing.assert_frame_equal(prefix.set_index('game_id').sort_index(),p.set_index('game_id').loc[prefix.game_id].sort_index(),check_exact=True)
    grid=np.linspace(.01,.99,99)
    assert np.allclose(mapping(grid,1-grid,0),grid,rtol=0,atol=1e-15)
    assert np.allclose(mapping(grid,grid,10),grid,rtol=0,atol=1e-15)
    assert np.allclose(mapping(grid,1-grid,2)+mapping(1-grid,grid,2),1,rtol=0,atol=1e-15)
    p.to_parquet(RESULT/'development_predictions.parquet',index=False)
    fits.to_csv(RESULT/'rolling_fits.csv',index=False)
    m=metrics(p);m.to_csv(RESULT/'development_metrics.csv',index=False)
    x=m.set_index(['variant','year'])
    probability_gate=bool(all(x.loc[('disagreement','pooled'),c]<x.loc[('reference','pooled'),c] for c in ['logloss','brier']) and
        x.loc[('disagreement',2025),'logloss']<x.loc[('reference',2025),'logloss'] and x.loc[('disagreement','pooled'),'accuracy']>=.52)
    # Earlier accounts explain economic consequences even if the model gate fails.
    a=accounts(p,'development');choices={}
    original=pd.read_csv(ROOT_OUT/'simulation_results/nhl_sports_combination/margin_annual.csv')
    for provider,g in a.groupby('provider'):
        s=g.set_index(['variant','year']);v,b=s.loc[('disagreement',2025)],s.loc[('reference',2025)]
        allowed=probability_gate and v.sharpe>b.sharpe and v.return_pct>0 and v.max_drawdown_pct<=b.max_drawdown_pct
        if pd.notna(s.loc[('reference',2024),'sharpe']):
            allowed &= s.loc[('disagreement',2024),'sharpe']>=s.loc[('reference',2024),'sharpe']
        choices[provider]=bool(allowed)
        for r in g[g.variant.eq('reference')].itertuples():
            ref=original[original.variant.eq('relative10')&original.provider.eq(provider)&original.year.eq(r.year)].iloc[0]
            for field in ['funded_games','return_pct','sharpe','max_drawdown_pct']:
                assert np.isclose(getattr(r,field),ref[field],rtol=0,atol=1e-10,equal_nan=True)
    selection=dict(at_utc=stamp(),probability_gate=probability_gate,providers=choices,adopted=False)
    dump(RESULT/'selection.json',selection)
    if any(choices.values()):
        allp,_=rolling(source(True));earlier=allp[allp.prediction_time.dt.year.lt(2026)]
        pd.testing.assert_frame_equal(earlier.set_index('game_id').sort_index(),p.set_index('game_id').sort_index(),check_exact=True)
        ev=allp[allp.prediction_time.dt.year.eq(2026)]
        ev.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
        metrics(ev).to_csv(RESULT/'evaluation_metrics.csv',index=False)
        accounts(ev,'evaluation',[k for k,v in choices.items() if v])
    dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),diagnosis=diagnosis,selection=selection,
        earlier_prefix_replays=len(prefix),identity_symmetry_and_same_model_winner_verified=True,
        source_clock_and_cash_checks=True,original_accounts_reproduced=True,evaluated2026=any(choices.values()),app_changed=False))
    print(m.to_string(index=False),flush=True)
    print(a[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print(json.dumps(selection),flush=True)


def finish():
    proof=json.loads((RESULT/'validation.json').read_bytes());assert proof['status']=='PASS'
    def table(f):
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(str(v) for v in row)+' |' for row in f.itertuples(index=False,name=None)])
    lines=['# NHL losing-case diagnosis and disagreement correction','',
        'The saved loss ledger identifies every losing development bet, the two model probabilities, actual purchase price/time, teams, season phase, official final score/winner, native game ID, source request and public verification URL. Losing cases are not claimed to reveal a causal explanation individually. Net profit and losing stakes are both reported: a low-win-rate group can still make money at low purchase prices.','',
        'High-confidence misses concentrate in preseason, but preseason made positive net profit in the2025Polymarket sample. Removing all preseason or low-probability games after observing losses would not establish a robust improvement. Large forecast disagreement is associated with weak2025accuracy, while2024does not show the same relationship.','',
        table(pd.read_csv(RESULT/'model_disagreement_diagnosis.csv')),'',
        'Test one coefficient that reduces log-odds confidence as the two models disagree: q=expit(logit(p)/(1+alpha*abs(logit(p)-logit(secondary)))), alpha>=0. Fit monthly to all earlier settled saved forecasts by logloss, with identity until100earlier games and10of each result. No price or return is used to fit it. Base models train on expanding2021+history; saved correction-training forecasts start2024. It preserves the primary winner and coherent complementary probabilities.','',
        table(pd.read_csv(RESULT/'development_metrics.csv')),'',
        'Unchanged accounts: one outcome, both primary and secondary probability/price>=1.10, pre12closest preceding observed price at most24hoursold,$20stake,annual$2000cash. Providers stay separate; no added costs. Polymarket historical token prices are not verified executable US asks; Kalshi uses retainedYESaskcloses. Sharpe uses actual calendar daily cash-account returns andsqrt365.25, including idle days.','',
        table(pd.read_csv(RESULT/'development_annual.csv')[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        'Selection: '+json.dumps(proof['selection'])+'. Every fitted coefficient was zero: earlier settled forecasts did not support this disagreement correction. Forecasts and account results therefore stayed unchanged. The2025disagreement pattern alone is insufficient to justify an earlier-known exclusion rule. Removing all2025observations reproduces every2024corrected forecast exactly. Original baseline accounts replay; common positions preserve prices,stakesandprofits. No model or app adoption. Repeatedly inspected2026is retrospective research.','',
        'Reproduce nhl_disagreement_calibration.py run then finish. Result forecasts, calibration coefficients, diagnostics, cash results and decisions are retained; no new source dataset or rejected model package is duplicated.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False)
    parts=[]
    for stage in ['development','evaluation']:
        file=RESULT/(stage+'_annual.csv')
        if file.exists():parts.append(pd.read_csv(file).assign(source_result_file=LABEL+'/'+file.name))
    pd.concat([old[~old.source_result_file.str.startswith(LABEL+'/',na=False)]]+parts,ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes())
    d[LABEL]=dict(plan=json.loads((RESULT/'plan.json').read_bytes()),validation=proof);dump(path,d)
    from final_pipeline import cleanup,validate
    cleanup();check=validate()
    receipt=dict(status='PASS',at_utc=stamp(),validation=proof,app_validation=check,adopted=False,goal_achieved=False)
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(path.read_bytes())
    m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']),latest_simulation_update=receipt);dump(path,m)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['run','finish'])
    globals()[parser.parse_args().stage]()
