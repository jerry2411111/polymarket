"""Preserve and correct header-only success labels after interrupted body reads."""
import json
from common import ROOT_OUT,OfficialClient,dump,stamp


def main():
    client=OfficialClient();path=ROOT_OUT/'request_body_status_corrections.json'
    previous=json.loads(path.read_bytes()) if path.exists() else dict(corrections=[])
    with client.connect() as c:
        rows=[dict(r) for r in c.execute("SELECT * FROM request_audit WHERE return_status='200' AND raw_file IS NULL AND sha256 IS NULL AND error IS NOT NULL")]
        for r in rows:
            previous['corrections'].append(dict(original=r,corrected_status='NETWORK_ERROR',reason='HTTP headers arrived, but reading the response body failed; no usable raw response was saved.',corrected_at_utc=stamp()))
        # Save the original audit records before making the targeted correction.
        dump(path,previous)
        with c:
            for r in rows:c.execute("UPDATE request_audit SET return_status='NETWORK_ERROR' WHERE request_number=? AND return_status='200' AND raw_file IS NULL AND sha256 IS NULL",(r['request_number'],))
    print(json.dumps(dict(corrected=len(rows),original_records_preserved=path.name)),flush=True)


if __name__=='__main__':main()
