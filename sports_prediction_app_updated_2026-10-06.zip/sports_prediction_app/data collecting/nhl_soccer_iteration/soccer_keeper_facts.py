"""Dated goalkeeper observations; roles must have native official evidence.

These are observations, not current-game forecast lineups. Raw gaps stay null.
No saves/(saves+goals) statistic is labelled official save percentage.
"""
import argparse,collections,hashlib,json,sqlite3
from pathlib import Path
import pandas as pd
from common import ROOT_OUT,PROJECT,PREVIOUS,read_db,dump,stamp
from discover_soccer_keeper_sources import RUN

FIELDS=['saves','goals_conceded','keeper_xgot_conceded']

def observation_path():
    staged=RUN/'keeper_observations.parquet'
    return staged if staged.exists() else ROOT_OUT/'soccer_goalkeeper_game_observations.parquet'


def main():
    rows=[];issues=[];role_sources=[]
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games={r['game_id']:dict(r) for r in db.execute('SELECT * FROM soccer_games')}
    def add(p,pid,minutes,source,role,values,evidence,namespace):
        gid=p['game_id'];game=games.get(gid)
        if game is None:issues.append(dict(game_id=gid,reason='No native main-calendar match; retain in source scope'));return
        assert p['side'] in ['A','B']
        assert str(p['team_id'])==str(json.loads(game['native_team_ids_json'])[0 if p['side']=='A' else 1])
        if minutes is None or minutes<=0:return
        assert 0<minutes<=150
        for value in values.values():assert value is None or value>=0
        raw_values={f:values[f] for f in FIELDS}
        for f in FIELDS:
            if isinstance(evidence.get(f),dict) and 'raw_value' in evidence[f]:raw_values[f]=evidence[f]['raw_value']
        # A verified team clean sheet entails zero conceded by every goalkeeper
        # who appeared; no unreported substitution or player role is guessed.
        opponent=game['scoreB' if p['side']=='A' else 'scoreA']
        if values['goals_conceded'] is None and opponent==0:
            evidence['goals_conceded']=dict(raw_value=raw_values['goals_conceded'],basis='official team clean sheet',
                official_game_id=game['official_game_id'],calendar_request_id=game.get('calendar_request_id') or game.get('source_request_id'),calendar_pointer=game.get('calendar_pointer'),opponent_final_score=0)
            values['goals_conceded']=0.
        rows.append(dict(game_id=gid,official_game_id=str(game['official_game_id']),league=game['league'],date=game['date'],side=p['side'],team_id=str(p['team_id']),
            official_player_id=str(pid),id_namespace=namespace,player_name=p.get('player_name'),minutes=float(minutes),
            available_at_utc=str(p['available_at_utc']),**values,**{'raw_'+f:v for f,v in raw_values.items()},source_json=json.dumps(source,sort_keys=True),
            role_evidence_json=json.dumps(role,sort_keys=True),field_evidence_json=json.dumps(evidence,sort_keys=True)))

    # Read dated PL lineup positions; the current player metadata team's name
    # and current biography position never establish historical participation.
    from pl_sparse_statistics import load,original
    plgames,players,sources=load();bygame=collections.defaultdict(list)
    proofdir=ROOT_OUT/'sparse_player_v26';assert json.loads((proofdir/'pl_zero_validation.json').read_bytes())['status']=='PASS'
    zero=pd.read_parquet(proofdir/'pl_zero_proofs.parquet');zero=zero[zero.field.eq('saves')]
    zeros={(r['game_id'],r['side'],str(r['official_player_id'])):r for r in zero.to_dict('records')}
    with read_db(ROOT_OUT/'pl_lineup_recovery.sqlite') as db:
        players.extend(json.loads(b) for b, in db.execute('SELECT body FROM player_match_detail'))
    for p in players:bygame[p['game_id']].append(p)
    for gid,g in plgames.items():
        url='https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v3/matches/'+str(g['official_game_id'])+'/lineups'
        if url not in sources:issues.append(dict(game_id=gid,reason='PL dated role response requires recovery'));continue
        lineup,path=original(sources[url]);byid={(p['side'],str(p['player_id'])):p for p in bygame[gid]}
        for side,key in [('A','away_team'),('B','home_team')]:
            for i,person in enumerate(lineup[key]['players']):
                if person.get('position')!='Goalkeeper':continue
                pid=str(person['id']);p=byid.get((side,pid))
                if p is None:issues.append(dict(game_id=gid,side=side,player_id=pid,reason='Dated PL goalkeeper needs individual statistic response'));continue
                source=sources[url]|dict(raw_file=path)
                role=dict(source=source,pointer='/'+key+'/players/'+str(i)+'/position',raw_value='Goalkeeper',native_player_id=pid)
                values={f:p.get(f) for f in FIELDS}
                from collect_players import FIELDS as MAP
                evidence={f:dict(pointer='/stats/'+MAP[f],raw_value=p.get(f),basis='reported') for f in FIELDS}
                proof_key=(gid,side,pid)
                if values['saves'] is None and proof_key in zeros:
                    values['saves']=0.;evidence['saves']=dict(raw_value=None,basis='complete official team/player total reconciliation',zero_proof=zeros[proof_key])
                add(p,pid,p.get('minutes'),p['source'],role,values,evidence,'premier_league_opta')
        role_sources.append(dict(game_id=gid,source=sources[url],raw_file=path))

    # The numeric role is defined explicitly in the current official client.
    references=[]
    for file in ['official_client_keeper_references.json','nested_client_keeper_references.json']:
        d=json.loads((RUN/file).read_bytes());references.extend(d.get('clients',[]))
    ref=next(x['source'] for x in references if '2m0vd0-uwdned.js' in x['source']['url'])
    b=(PROJECT/ref['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==ref['sha256']
    assert 'GOALKEEPER:1,DEFENDER:2,MIDFIELDER:3,STRIKER:4' in b.decode()
    with read_db(ROOT_OUT/'soccer_additional.sqlite') as db:
        records=[json.loads(b) for b, in db.execute("SELECT body FROM games WHERE league='Ligue 1'")]
    for game in records:
        for p in game['players']:
            if p.get('position')!='1':continue
            values={f:p.get(f) for f in FIELDS}
            role=dict(source=p['source'],pointer='/'+('away' if p['side']=='A' else 'home')+'/players/'+p['source_player_id']+'/position',raw_value=1,definition_source=ref)
            evidence={f:dict(pointer=p['field_pointers'][f],raw_value=p.get(f),basis='reported') for f in FIELDS}
            add(p,p['official_player_id'],p.get('minutes'),p['source'],role,values,evidence,'ligue1_'+p['id_namespace'])

    # Published UEFA facts already retain native identity repairs and raw cells.
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        records=[dict(r) for r in db.execute("SELECT * FROM uefa_match_player_statistics WHERE position='GOALKEEPER' AND lineup_identity_verified=1")]
        teams={(r['game_id'],r['side']):dict(r) for r in db.execute('SELECT * FROM uefa_match_team_statistics')}
    for p in records:
        values=dict(saves=p['saves'],goals_conceded=p['goals_conceded'],keeper_xgot_conceded=None)
        evidence=json.loads(p['field_evidence_json']);source=dict(raw_file=p['source_raw_file'],sha256=p['source_sha256'],request_number=p['source_request'])
        for f in FIELDS:
            evidence[f]=dict(evidence.get(f) or {},raw_value=values[f],basis='reported')
        team=teams.get((p['game_id'],p['side']))
        if values['saves'] is None and team is not None and team['saves']==0:
            values['saves']=0.;evidence['saves']=dict(raw_value=None,basis='explicit official team saves zero',source=dict(raw_file=team['source_raw_file'],sha256=team['source_sha256']),
                field_evidence=json.loads(team['field_evidence_json']).get('saves'))
        role=dict(published_table='uefa_match_player_statistics',verified_native_lineup_player_id=p['lineup_player_id'] or p['official_player_id'],raw_value='GOALKEEPER',identity_evidence=p['identity_evidence_json'])
        add(p,p['lineup_player_id'] or p['official_player_id'],p['minutes_played_official'],source,role,values,
            {f:evidence.get(f) for f in FIELDS},'uefa_fame')

    from collect_seriea_keeper_statistics import FOLDER
    with read_db(FOLDER/'statistics.sqlite') as db:records=[json.loads(b) for b, in db.execute('SELECT body FROM games')]
    for game in records:
        assert game['parser_version'] in [2,3]
        for p in game['players']:
            values=dict(saves=p['saves'],goals_conceded=p['goals_conceded'],keeper_xgot_conceded=p['xgot_faced_raw'])
            evidence=json.loads(p['field_pointers_json'])
            proof=dict(saves=dict(pointers=evidence['saves'],raw_value=p['saves'],basis='reported'),
                goals_conceded=dict(pointers=evidence['goals_conceded_raw'],raw_value=p['goals_conceded_raw'],basis=p['goals_conceded_basis'],final_result_source=json.loads(p['result_source_json'])),
                keeper_xgot_conceded=dict(pointers=evidence['xgot_faced_raw'],raw_value=p['xgot_faced_raw'],basis='reported'))
            role=dict(source=json.loads(p['lineup_source_json']),pointer=p['lineup_pointer']+'/roleLabel',raw_value='Goalkeeper')
            repair=next((i['proof'] for i in game['issues'] if i['kind']=='keeper_starter_source_repair' and i['player_id']==p['official_player_id']),None)
            if repair:role['starter_correction']=repair
            add(p,p['official_player_id'],p['minutes_regulation'],json.loads(p['source_json']),role,values,proof,'seriea_native')
    # Official club API republishes Opta. Fixture role and statistic IDs are
    # independently validated before any rows enter the unified publication.
    from collect_laliga_keeper_statistics import FOLDER as LALIGA
    from common import file_sha256
    if (LALIGA/'statistics.sqlite').exists():
        check=json.loads((LALIGA/'validation.json').read_bytes())
        assert check['status']=='PASS' and check['source_sha256']==file_sha256(LALIGA/'statistics.sqlite')
        with read_db(LALIGA/'statistics.sqlite') as db:records=[json.loads(b) for b, in db.execute('SELECT body FROM games')]
        for record in records:
            for p in record['players']:
                add(p,p['official_player_id'],p['minutes'],p['source'],p['role_evidence'],
                    {f:p[f] for f in FIELDS},{f:p['field_evidence'][f] for f in FIELDS},'opta_player_asset')
    from maker_keeper_recovery import recover
    for p in recover(rows):
        add(p,p['official_player_id'],p['minutes'],p['source'],p['role_evidence'],
            {f:p[f] for f in FIELDS},{f:p['field_evidence'][f] for f in FIELDS},p['id_namespace'])
    from laliga_direct_keeper_recovery import recover as recover_direct
    for p in recover_direct(rows):
        add(p,p['official_player_id'],p['minutes'],p['source'],p['role_evidence'],
            {f:p[f] for f in FIELDS},{f:p['field_evidence'][f] for f in FIELDS},p['id_namespace'])
    from laliga_direct_keeper_recovery import repair_native_identities
    repair_native_identities(rows)
    from soccer_keeper_quality import repair_clean_sheets
    repair_clean_sheets(rows,games)
    frame=pd.DataFrame(rows);assert not frame.duplicated(['game_id','side','id_namespace','official_player_id']).any()
    frame=frame.sort_values(['date','game_id','side','official_player_id']).reset_index(drop=True)
    frame.to_parquet(RUN/'keeper_observations.parquet',index=False)
    coverage=[]
    for (league,year),p in frame.groupby(['league',frame.date.str[:4]]):
        coverage.append(dict(league=league,year=year,games=p.game_id.nunique(),keeper_appearances=len(p),**{f+'_observed':int(p[f].notna().sum()) for f in FIELDS},
            **{f+'_missing_pct':100*p[f].isna().mean() for f in FIELDS}))
    pd.DataFrame(coverage).to_csv(RUN/'keeper_field_coverage.csv',index=False);dump(RUN/'keeper_role_source_issues.json',issues)
    dump(RUN/'pl_keeper_role_sources.json',role_sources)
    result=dict(at_utc=stamp(),rows=len(frame),games=frame.game_id.nunique(),leagues=frame.league.value_counts().to_dict(),issues=len(issues),
        state='Normalized source observations; independent replay pending before model use',market_inputs_used=False,current_game_lineups_for_prediction=False,
        scope='PL explicitly role-labelled starting keepers; positive official keeper minutes for other sources. La Liga includes dated club API roles and fixture-specific reported minutes. Unlabelled substitute roles and remaining league/source gaps still require recovery.')
    dump(RUN/'keeper_normalization.json',result);print(json.dumps(result),flush=True);print(pd.DataFrame(coverage).to_string(index=False),flush=True)

def publish_validated():
    validation=json.loads((RUN/'keeper_validation.json').read_text())
    source=observation_path()
    assert validation['status']=='PASS' and validation['source_sha256']==hashlib.sha256(source.read_bytes()).hexdigest()
    frame=pd.read_parquet(source);assert len(frame)==validation['rows']
    table='soccer_goalkeeper_game_observations'
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        metadata=list(db.execute('SELECT "column",meaning,unit,source FROM column_catalog WHERE "table"=?',[table]))
        assert {r[0] for r in metadata}==set(frame.columns)
        frame.to_sql(table,db,if_exists='replace',index=False,chunksize=1000)
        for cat in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+cat+' WHERE "table"=?',[table])
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',[table,len(frame),len(frame.columns)])
        for column,meaning,unit,origin in metadata:
            if 'verified official calendar' not in origin:
                origin=origin.replace('Serie A match ranking API plus dated lineup/final feed','Serie A match ranking API plus dated lineup/final feed or verified official calendar; explicit club-report starter corrections retain later publication cutoffs')
            if 'FC Barcelona' not in origin:
                origin+='; La Liga: FC Barcelona official club API republishes Opta, with dated lineup roles and fixture-filtered individual statistics.'
            if 'Elche' not in origin:
                origin+=' Elche official club JSON API supplements absent La Liga keeper sides; role derived from dated starting formation with official client grid and explicit-G corroboration.'
            if 'uninterrupted' not in origin:
                origin+=' La Liga league reports supplement same-game native keeper roles with full-match exposure; team saves/conceded are derived individual values only after uninterrupted participation including stoppage time is verified.'
            if column=='role_evidence_json':meaning='Dated official goalkeeper role, raw pointer, and any documented starter correction with publication cutoff.'
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',[table,column,meaning,unit,origin])
            n=int(frame[column].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',[table,column,len(frame),n,100*n/len(frame)])
    frame.to_parquet(ROOT_OUT/(table+'.parquet'),index=False);frame.to_csv(ROOT_OUT/(table+'.csv'),index=False)
    print(json.dumps(dict(published=table,rows=len(frame),games=frame.game_id.nunique())),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--publish',action='store_true');a=p.parse_args()
    if a.publish:publish_validated()
    else:main()
