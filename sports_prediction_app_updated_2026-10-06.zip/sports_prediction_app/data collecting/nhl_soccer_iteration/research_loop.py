"""Inspect existing rolling forecasts before any further fit or strategy search.

Model selection uses probability scores only, never trading returns. Historical
combined-gate decisions remain unchanged. This records the user's new workflow.
"""
import argparse
import json
import numpy as np
import pandas as pd
from sklearn.metrics import log_loss,roc_auc_score,average_precision_score,f1_score
from common import ROOT_OUT,dump,stamp

RESULT=ROOT_OUT/'simulation_results/research_loop'


def prior_baseline(sport,predictions):
    data=pd.read_parquet(ROOT_OUT/'retained_models'/sport/(sport+'_features.parquet'))
    k=3 if sport=='soccer' else 2
    out=[]
    for (fold,league),g in predictions.groupby(['fold','league']):
        boundary=pd.Timestamp(fold+'-01',tz='UTC')
        earlier=data[data.available_time.lt(boundary)&data.league.eq(league)]
        assert len(earlier)>=1 and earlier.available_time.max()<g.prediction_time.min()
        # One fixed pseudo-observation per class avoids log(0); no tuned rate.
        count=earlier.target.value_counts().reindex(range(k),fill_value=0).to_numpy()+1
        row=g[['game_id','fold','league','target','prediction_time']].copy()
        for j in range(k):row['p'+str(j)]=count[j]/count.sum()
        out.append(row)
    return pd.concat(out,ignore_index=True).set_index('game_id')


def inspect():
    RESULT.mkdir(exist_ok=True)
    plan=dict(at_utc=stamp(),history_from='2021-01-01',development_years=[2024,2025],
        forecast_selection='Compare existing matched rolling predictions by pooled log loss; report Brier, per-target skill, calibration and class discrimination. No return or Sharpe selects the forecast model.',
        skill_check='Compare with competition-specific expanding prior class frequencies, fitted before each forecast month. Require lower log loss in each development year before proceeding to betting.',
        targets={'nhl':['away_win','home_win','regulation_tie_pending_label_audit'],
                 'soccer':['away_win_90','home_win_90','draw_90','extra_time_pending_label_audit']},
        iteration=['Audit labels and matched forecast results.','If probability skill is weak, revise one source/feature/model hypothesis.',
                   'Otherwise freeze forecast recipe and inspect a simple betting rule.',
                   'If betting fails, decompose selected-bet probability error, price alignment and allocation.',
                   'Return to model revision only for demonstrated probability weakness; otherwise revise betting.'],
        selection_scope='Retained models and the latest source/scaling candidates with comparable completed prediction files; not an assertion about every historical experiment.',
        unknown_extra_time='Do not infer from a draw. League rules, tie leg and official phase evidence are required. First-leg aggregate winner metadata can include the subsequent second leg and is forbidden as a pregame input.',
        previous_decisions='Earlier combined probability/trading acceptance decisions stay unchanged; this is a newly requested selection procedure.',
        repeated_research='2026 has already been inspected repeatedly; future tests on it are retrospective, not independent confirmation.',
        retention='Keep source data, reproduction code, adopted models and consolidated simulations. Delete unadopted fits and duplicate trial matrices.',
        app_changed=False)
    dump(RESULT/'plan.json',plan)
    comparisons=[];targets=[];selections={}
    for sport in ['nhl','soccer']:
        k=3 if sport=='soccer' else 2;cols=['p'+str(i) for i in range(k)]
        base=pd.read_parquet(ROOT_OUT/'retained_models'/sport/'development_predictions.parquet')
        variants={name:g.copy() for name,g in base.groupby('variant')}
        extras=(['nhl_goalie_profile','nhl_observed_scale'] if sport=='nhl' else
                ['feature_revisions/soccer_observed_scale','feature_revisions/soccer_pooled_scale','feature_revisions/soccer_without_sparse_keypasses'])
        for name in extras:
            p=pd.read_parquet(ROOT_OUT/'simulation_results'/name/'development_predictions.parquet')
            variants[name]=p[p.variant.eq('candidate')].copy()
        reference=next(iter(variants.values())).set_index('game_id').sort_index()
        baseline=prior_baseline(sport,reference.reset_index()).loc[reference.index]
        y=reference.target.to_numpy(int);frequency=baseline[cols].to_numpy()
        base_loss=-np.log(frequency[np.arange(len(y)),y])
        for name,p in variants.items():
            assert set(p.game_id)==set(reference.index)
            p=p.set_index('game_id').loc[reference.index]
            assert p.target.eq(reference.target).all() and p.prediction_time.eq(reference.prediction_time).all()
            assert p.train_label_max.lt(p.prediction_time).all()
            prob=p[cols].to_numpy();loss=-np.log(prob[np.arange(len(y)),y])
            for year in [2024,2025,'pooled']:
                mask=np.ones(len(p),dtype=bool) if year=='pooled' else p.prediction_time.dt.year.eq(year).to_numpy()
                q=prob[mask];actual=y[mask];null=frequency[mask]
                comparisons.append(dict(sport=sport,model=name,year=str(year),games=int(mask.sum()),
                    logloss=float(loss[mask].mean()),frequency_logloss=float(base_loss[mask].mean()),
                    logloss_skill=float(1-loss[mask].mean()/base_loss[mask].mean()),
                    brier=float(np.square(q-np.eye(k)[actual]).sum(axis=1).mean()),
                    accuracy=float((q.argmax(axis=1)==actual).mean()),
                    macro_f1=float(f1_score(actual,q.argmax(axis=1),average='macro',labels=range(k),zero_division=0))))
                for j,label in enumerate(['away_win','home_win','draw_90'][:k]):
                    yy=(actual==j).astype(int);pj=q[:,j];bj=null[:,j]
                    targets.append(dict(sport=sport,model=name,year=str(year),target=label,games=len(yy),
                        positives=int(yy.sum()),mean_probability=float(pj.mean()),observed_rate=float(yy.mean()),
                        brier=float(np.square(pj-yy).mean()),frequency_brier=float(np.square(bj-yy).mean()),
                        binary_logloss=float(log_loss(yy,pj,labels=[0,1])),
                        frequency_binary_logloss=float(log_loss(yy,bj,labels=[0,1])),
                        binary_logloss_skill=float(1-log_loss(yy,pj,labels=[0,1])/log_loss(yy,bj,labels=[0,1])),
                        auc=float(roc_auc_score(yy,pj)),average_precision=float(average_precision_score(yy,pj))))
        score=pd.DataFrame(comparisons);score=score[score.sport.eq(sport)]
        best=score[score.year.eq('pooled')].sort_values(['logloss','brier','model']).iloc[0]
        annual=score[score.model.eq(best.model)&~score.year.eq('pooled')]
        selected_targets=pd.DataFrame(targets)
        selected_targets=selected_targets[selected_targets.sport.eq(sport)&selected_targets.model.eq(best.model)&selected_targets.year.eq('pooled')]
        selections[sport]=dict(model=best.model,pooled_logloss=float(best.logloss),
            skill_vs_expanding_frequency=float(best.logloss_skill),
            beats_frequency_each_year=bool(annual.logloss.lt(annual.frequency_logloss).all()),
            next_stage='inspect_betting' if annual.logloss.lt(annual.frequency_logloss).all() else 'revise_model',
            weak_targets=selected_targets.loc[selected_targets.binary_logloss.ge(selected_targets.frequency_binary_logloss),'target'].tolist(),
            adopted=False,new2026_evaluation=False)
    pd.DataFrame(comparisons).to_csv(RESULT/'model_comparison.csv',index=False)
    pd.DataFrame(targets).to_csv(RESULT/'target_metrics.csv',index=False)
    decision=dict(at_utc=stamp(),status='PASS',selections=selections,
        no_refits=True,no_strategy_search=True,no2026_read=True,matched_game_ids=True,past_only_frequency_baseline=True)
    dump(RESULT/'selection.json',decision);print(json.dumps(decision),flush=True)


def test_win_outcomes():
    from backtest import quote_inputs,attach,select,simulate
    from cash_validation import validate_cash
    from final_pipeline import cleanup
    selected=json.loads((RESULT/'selection.json').read_bytes())['selections']['soccer']
    assert selected['next_stage']=='inspect_betting'
    source=ROOT_OUT/'simulation_results'/selected['model']
    result=ROOT_OUT/'simulation_results/soccer_win_outcomes';result.mkdir(exist_ok=True)
    assert not (result/'validation.json').exists(),'Preserve completed comparison'
    plan=dict(at_utc=stamp(),model=selected['model'],development=[2024,2025],
        hypothesis='Selected soccer model has strong relative home/away probability skill but very weak draw discrimination. Test team-win opportunities alone, without changing forecast probabilities or tuning price thresholds.',
        compared=['all_outcomes','team_wins_only'],
        fixed='pre12 closest prior quotes age<=24h; p-price>=.05;1%NAV each outcome;20%open-cost cap; hold to official result; no costs; providers separated.',
        changes='Exclude class2 draw outcomes only. Both away and home outcomes may still qualify independently.',
        gate='2024/25 Polymarket weaker-year Sharpe and mean annual return both improve, with at least30bets/year. If this fails keep control; never optimize a2026threshold.',
        no_model_refits=True,no2026_evaluation=True,app_changed=False)
    dump(result/'plan.json',plan)
    p=pd.read_parquet(source/'development_predictions.parquet');p=p[p.variant.eq('candidate')].copy()
    q=quote_inputs(result/'quote_quality.json',revision='closest_v62');joined,audit=attach(p,q)
    dump(result/'matching.json',audit)
    summaries=[];trades=[];curves=[]
    for provider,g in joined.groupby('provider'):
        qualified=select(g,'edge_any')
        for rule in ['all_outcomes','team_wins_only']:
            subset=qualified if rule=='all_outcomes' else qualified[qualified.quote_class.ne(2)]
            for year in [2024,2025]:
                summary,t,c=simulate(subset,year)
                meta=dict(sport='soccer',provider=provider,variant=rule,recipe='fixed',year=year)
                summaries.append(meta|summary)
                if len(t):trades.append(t.assign(**meta))
                curves.append(c.assign(**meta))
    annual=pd.DataFrame(summaries);bets=pd.concat(trades,ignore_index=True);daily=pd.concat(curves,ignore_index=True)
    cash=validate_cash(bets,daily)
    previous=pd.read_csv(source/'development_annual.csv')
    for row in annual[annual.variant.eq('all_outcomes')].itertuples():
        ref=previous[previous.variant.eq('candidate')&previous.provider.eq(row.provider)&previous.year.eq(row.year)].iloc[0]
        for field in ['bets','return_pct','sharpe','max_drawdown_pct']:
            assert np.isclose(getattr(row,field),ref[field],rtol=0,atol=1e-10,equal_nan=True)
    compared={}
    for name,g in annual[annual.provider.eq('polymarket')].groupby('variant'):
        compared[name]=dict(min_sharpe=float(g.sharpe.min()),mean_annual_return=float(g.return_pct.mean()),minimum_bets=int(g.bets.min()))
    a,b=compared['team_wins_only'],compared['all_outcomes']
    passed=a['min_sharpe']>b['min_sharpe'] and a['mean_annual_return']>b['mean_annual_return'] and a['minimum_bets']>=30
    annual.to_csv(result/'development_annual.csv',index=False)
    bets.to_parquet(result/'development_bets.parquet',index=False);daily.to_parquet(result/'development_daily.parquet',index=False)
    diagnostic=bets.groupby(['provider','year','variant','class_index']).agg(bets=('game_id','size'),mean_probability=('probability','mean'),win_rate=('won','mean'),mean_price=('price','mean'),mean_unit_return=('unit_return','mean')).reset_index()
    diagnostic.to_csv(result/'outcome_diagnosis.csv',index=False)
    decision=dict(at_utc=stamp(),status='PASS',trading_gate_passed=bool(passed),comparison=compared,cash_days=cash,
        forecasts_unchanged=True,original_account_replayed=True,adopted=False,evaluated2026=False,
        next_step='forward_evaluate_fixed_rule' if passed else 'retain_rule_and_inspect_selected_probability_error')
    dump(result/'validation.json',decision)
    root=ROOT_OUT/'simulation_results';path=root/'experiment_results.csv';ledger=pd.read_csv(path,low_memory=False)
    key='soccer_win_outcomes/development_annual.csv'
    ledger=pd.concat([ledger[~ledger.source_result_file.eq(key)],annual.assign(source_result_file=key)],ignore_index=True);ledger.to_csv(path,index=False)
    path=root/'experiment_decisions.json';decisions=json.loads(path.read_bytes());decisions['soccer_win_outcomes']=dict(plan=plan,decision=decision);dump(path,decisions)
    print(annual.to_string(index=False),flush=True);print(json.dumps(decision),flush=True)
    cleanup()


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--test-win-outcomes',action='store_true');args=parser.parse_args()
    inspect()
    if args.test_win_outcomes:test_win_outcomes()
