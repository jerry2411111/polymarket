"""Verify native player joins and publishable dated projected-lineup facts."""
import html,json,re
import pandas as pd
from common import ROOT_OUT,PREVIOUS,OfficialClient,read_db,dump,stamp
from collect_dated_lineup_survey import RUN,parse
from collect_nhl_opening_rosters import namekey
from nhl_roster_aliases import read_source,candidates,verify_proof


def main(run=RUN,archive=False):
    c=OfficialClient(per_second=2)
    reports=pd.read_parquet(run/'reports.parquet')
    if archive:
        checked=json.loads((run/'raw_validation.json').read_bytes());assert checked['status']=='PASS_RAW_AND_GAME_LINKS'
        games=pd.read_parquet(run/'requested_games.parquet');assert not games.duplicated(['date','teamA','teamB']).any()
        games=games[games.game_id.isin(reports.game_id)]
    else:
        games=pd.read_parquet(run/'selected_games.parquet');assert reports.parse_status.eq('parsed').all()
    games=games.set_index('game_id');assert set(games.index)==set(reports.game_id)
    fetched={}
    def get(url,intent,kind):
        if url not in fetched:fetched[url]=c.get(url,intent,kind)
        return fetched[url]
    teams,ts=c.get('https://api.nhle.com/stats/rest/en/team','Native club IDs for dated projected lineup reports','nhl_team_identity')
    teams={str(t['id']):t for t in teams['data']}
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        history=pd.read_sql_query('SELECT DISTINCT official_player_id,player_name,team_id FROM nhl_player_games',db)
    names={};team_names={}
    for r in history.itertuples():
        names.setdefault(namekey(r.player_name),set()).add(str(r.official_player_id))
        team_names.setdefault((str(r.team_id),namekey(r.player_name)),set()).add(str(r.official_player_id))
    # Previously independently verified exact dated-roster aliases can be reused
    # as static identity only; their membership/status is never carried over.
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        roster_tables=[x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%opening%roster%'")]
        aliases=[]
        for t in roster_tables:
            f=pd.read_sql_query('SELECT * FROM "'+t+'"',db)
            if {'player_name_raw','official_player_id','identity_verified','team_id'}<=set(f):aliases.extend(f[f.identity_verified.eq(1)].to_dict('records'))
    alias_index={}
    for r in aliases:alias_index.setdefault((str(r['team_id']),namekey(r['player_name_raw'])),[]).append(r)
    report_names=candidates();report_proofs={}
    out=[];raw_checks=0;last=0
    for ix,r in enumerate(reports.to_dict('records'),1):
        game=games.loc[r['game_id']].to_dict()|dict(_allow_unique_schedule_match=archive);source=json.loads(r['source_json']);blob=read_source(source);data,reason=parse(blob,game);assert reason=='parsed'
        raw_checks+=1;anchors={}
        for pid,text in re.findall(r'<a[^>]+href="(?:https://www.nhl.com)?/player/[^"/]+-(\d+)"[^>]*>(.*?)</a>',blob.decode(),re.S):
            full=html.unescape(re.sub('<[^>]+>','',text));anchors.setdefault(namekey(full),set()).add(pid)
        ids=list(map(str,json.loads(r['native_team_ids_json'])));yr=int(str(game['official_game_id'])[:4]);season=str(yr)+str(yr+1)
        registry={}
        for side,tid in zip(['A','B'],ids):
            roster,rs=get(f'https://api-web.nhle.com/v1/roster/{teams[tid]["triCode"]}/{season}','Verify native names for historical projected lineup '+r['game_id']+' '+side,'nhl_season_roster_identity')
            assert roster is not None,(r['game_id'],side)
            idx={}
            for group in ['forwards','defensemen','goalies']:
                for n,p in enumerate(roster[group]):
                    full=p['firstName']['default']+' '+p['lastName']['default'];idx.setdefault(namekey(full),[]).append((str(p['id']),full,'/'+group+'/'+str(n)))
            registry[side]=(tid,idx,rs)
        for p in data['players']:
            tid,idx,rs=registry[p['side']];key=namekey(p['player_name_raw']);matches=idx.get(key,[]);links=anchors.get(key,set());pid=None;full=None;proof=None;method=None
            if len(links)==1:
                pid=next(iter(links));full=p['player_name_raw'];proof=dict(kind='article_native_link',source=source,pointer='/player/*-'+pid);method='Native player link with exact source name in same report'
            elif len(matches)==1:
                pid,full,pointer=matches[0];proof=dict(kind='roster_exact',source=rs,pointer=pointer);method='Exact name after mechanical accent/punctuation normalization in same club season roster'
            else:
                aliases=alias_index.get((tid,key),[]);alias_ids={str(x['official_player_id']) for x in aliases}
                if len(alias_ids)==1:
                    a=aliases[0];pid=str(a['official_player_id']);full=a.get('player_name_api') or p['player_name_raw'];proof=dict(kind='validated_opening_alias',evidence=a);method='Previously independently verified official opening-roster static identity; no membership/status imported'
                else:
                    possible=team_names.get((tid,key),names.get(key,set()))
                    if len(possible)==1:
                        candidate=next(iter(possible));person,ps=get('https://api-web.nhle.com/v1/player/'+candidate+'/landing','Verify static identity for dated report '+p['player_name_raw'],'nhl_player_identity')
                        if person and str(person['playerId'])==candidate:
                            actual=person['firstName']['default']+' '+person['lastName']['default']
                            if namekey(actual)==key:pid=candidate;full=actual;proof=dict(kind='landing_exact',source=ps,pointer='/');method='Unique exact full name in official native player profile; current affiliation and statistics excluded'
            out.append(dict(game_id=r['game_id'],official_game_id=str(game['official_game_id']),team_id=tid,team_name=r['team'+p['side']],season=season,
                published_at_utc=r['published_at_utc'],modified_at_utc=r['modified_at_utc'],available_at_utc=r['available_at_utc'],available_by_pre12=r['available_by_pre12'],
                **p,official_player_id=pid,player_name=full,identity_verified=pid is not None,identity_method=method,identity_proof_json=json.dumps(proof,sort_keys=True) if proof else None,source_json=r['source_json']))
            if pid is None:
                # Official report full name + unique same-game sweater is
                # additional static identity evidence, never a future lineup.
                options=report_names.get(key,[])
                if len({x['official_player_id'] for x in options})>1:options=[x for x in options if str(x['team_id'])==tid]
                if len({x['official_player_id'] for x in options})==1:
                    if (tid,key) not in report_proofs:
                        for option in options:
                            box,bs=get('https://api-web.nhle.com/v1/gamecenter/'+option['official_game_id']+'/boxscore','Static full-name identity through unique official same-game sweater for '+p['player_name_raw'],'nhl_roster_alias_identity')
                            if box is None:continue
                            side='awayTeam' if option['side']=='A' else 'homeTeam'
                            persons=[person for group in box['playerByGameStats'][side].values() if isinstance(group,list) for person in group if str(person['playerId'])==option['official_player_id']]
                            if len(persons)!=1:continue
                            evidence=option|dict(box_source=bs,position=persons[0]['position'])
                            try:verify_proof(evidence)
                            except AssertionError:continue
                            report_proofs[(tid,key)]=evidence;break
                    if (tid,key) in report_proofs:
                        evidence=report_proofs[(tid,key)];pid=evidence['official_player_id']
                        out[-1].update(official_player_id=pid,player_name=evidence['report_name'].title(),identity_verified=True,
                            identity_method='Exact official full-name report and unique same-game team/sweater/native ID. Static identity only; no later performance or availability imported.',
                            identity_proof_json=json.dumps(dict(kind='dated_full_name_sweater',evidence=evidence),sort_keys=True))
        pct=int(100*ix/len(reports))//10*10
        if pct>last:last=pct;print(json.dumps(dict(stage='identity',percent=pct,reports=ix,rows=len(out),verified=sum(x['identity_verified'] for x in out))),flush=True)
    f=pd.DataFrame(out)
    # Duplicate or contradictory statements remain source facts, not silently
    # collapsed model features.
    f['identity_or_status_conflict']=False
    matched=f[f.identity_verified]
    for _,group in matched.groupby(['game_id','side','official_player_id']):
        if len(group)>1:f.loc[group.index,'identity_or_status_conflict']=True
    f.to_parquet(run/'verified_players.parquet',index=False);f.to_csv(run/'verified_players.csv',index=False)
    f[~f.identity_verified|f.identity_or_status_conflict].to_csv(run/'identity_review.csv',index=False)
    write_summary(run,reports,f,raw_checks)


def write_summary(run,reports,f,raw_checks):
    clocks=pd.to_datetime(reports.available_at_utc,utc=True,format='ISO8601');starts=pd.to_datetime(reports.start_time,utc=True,format='ISO8601')
    timing=[]
    for n in [12,6,3,0]:
        n_available=int((clocks<=starts-pd.Timedelta(hours=n)).sum());timing.append(dict(pre_hours=n,reports=len(reports),available=n_available,unavailable_at_cutoff=len(reports)-n_available,unavailable_at_cutoff_pct=100*(len(reports)-n_available)/len(reports)))
    pd.DataFrame(timing).to_csv(run/'timing_coverage.csv',index=False)
    dump(run/'identity_summary.json',dict(at_utc=stamp(),raw_reports_replayed=raw_checks,player_rows=len(f),verified_ids=int(f.identity_verified.sum()),
        unresolved_ids=int((~f.identity_verified).sum()),unresolved_pct=100*(~f.identity_verified).mean(),conflicting_rows=int(f.identity_or_status_conflict.sum()),
        timing=timing,not_yet_model_inputs=True))
    print(json.dumps(json.loads((run/'identity_summary.json').read_bytes())),flush=True)


if __name__=='__main__':main()
