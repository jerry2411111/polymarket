"""Fill absent keeper sides using two dated official reports of the same game.

The club's supported formation establishes the role. The league's complete
substitution/dismissal record establishes full-match exposure. Team totals are
derived player values only after that proof; they are never labelled raw player
statistics. No role is inferred from shirt number or the presence of saves.
"""
import collections
import hashlib
import json
import re

import pandas as pd

from common import ROOT_OUT, PROJECT, PREVIOUS, read_db, dump, stamp, file_sha256
from laliga_retained_facts import page_props, parse, namekey
from maker_keeper_recovery import definition

FOLDER = ROOT_OUT / 'soccer_keeper_v81/laliga'


def full_match(page, parsed, person):
    """Do not let regulation minutes hide a substitution at 90+ minutes."""
    if not parsed['minutes_complete'] or not parsed['goal_counts_reconcile']:
        return False, 'Official event sequence does not fully reconcile'
    if not person['started'] or person['minutes'] != 90:
        return False, 'Keeper did not have verified full regulation exposure'
    names = set()
    native = 'away' if person['side'] == 'A' else 'home'
    lineup = next(p for p in page['data']['lineups'][native]['starts']
                  if str(p['id']) == person['source_lineup_id'])
    p = lineup['person']
    for label in [p.get('name'), p.get('nickname'),
                  ' '.join([p.get('firstname') or '', p.get('lastname') or ''])]:
        if label:
            names.add(namekey(label))
    for event in page['events']:
        kind = event['match_event_kind']['collection']
        label = event['match_event_kind']['name']
        actor = None
        if kind == 'substitution':
            actor = event.get('lineup_off')
        elif kind == 'booking' and label in ['Second Yellow', 'Straight Red']:
            actor = event.get('lineup')
        else:
            continue
        # Missing actors/periods cannot establish uninterrupted participation.
        if not actor or event.get('period') not in ['FirstHalf', 'SecondHalf']:
            return False, 'Substitution/dismissal actor or regulation period incomplete'
        if str(actor['team']['id']) == str(person['team_id']):
            if namekey(actor['person']['name']) in names:
                return False, 'Keeper left or was dismissed, including stoppage time'
    return True, None


def recover(existing):
    definition_source, grids = definition()
    with read_db(PREVIOUS / 'expanded.sqlite') as db:
        games = {r['game_id']: dict(r) for r in db.execute(
            "SELECT * FROM soccer_games WHERE league='La Liga'")}
    with read_db(ROOT_OUT / 'laliga_maker.sqlite') as db:
        maker = {r['game_id']: r for r in
                 [json.loads(b) for b, in db.execute('SELECT body FROM fixtures')]}
    checked = json.loads((ROOT_OUT / 'laliga_maker_validation.json').read_bytes())
    assert checked['status'] == 'PASS'
    assert set(checked['validated_game_ids']) == set(maker)
    with read_db(ROOT_OUT / 'soccer_additional.sqlite') as db:
        records = [json.loads(b) for b, in db.execute(
            "SELECT body FROM games WHERE league='La Liga' ORDER BY game_id")]
    covered = {(r['game_id'], r['side']) for r in existing if r['league'] == 'La Liga'}
    links = collections.defaultdict(dict)
    for g in maker.values():
        for p in g['players']:
            if p['opta_player_id']:
                links[p['maker_player_id']][p['opta_player_id']] = dict(
                    source=p['source'], lineup_pointer=p['lineup_pointer'],
                    maker_player_id=p['maker_player_id'], opta_player_id=p['opta_player_id'])
    assert all(len(v) == 1 for v in links.values())
    rows, issues = [], []
    for record in records:
        gid = record['game_id']
        absent = [s for s in ['A', 'B'] if (gid, s) not in covered]
        if not absent:
            continue
        if gid not in maker:
            issues.extend(dict(game_id=gid, side=s,
                reason='Dated goalkeeper-role source still requires recovery') for s in absent)
            continue
        mg = maker[gid]; meta = mg['match']; source = record['sources'][0]
        blob = (PROJECT / source['raw_file']).read_bytes()
        assert hashlib.sha256(blob).hexdigest() == source['sha256']
        page = page_props(blob)
        parsed = parse(games[gid], page, source, allow_stoppage_clock=True)
        mb = (PROJECT / mg['source']['raw_file']).read_bytes()
        assert hashlib.sha256(mb).hexdigest() == mg['source']['sha256']
        raw = json.loads(mb)
        assert raw['game']['id'] == meta['maker_game_id']
        assert [raw['game']['awayScore'], raw['game']['homeScore']] == [games[gid]['scoreA'], games[gid]['scoreB']]
        for side in absent:
            native = 'away' if side == 'A' else 'home'
            people = [(i, p) for i, p in enumerate(raw['lineups'][native+'Team'])
                      if p.get('starting') and not p.get('manager') and p.get('formationPlace') == 1]
            assert len(people) == 1
            i, keeper = people[0]; maker_id = keeper['player']['id']
            formation = raw['game'][native+'Formation']
            if formation not in grids:
                issues.append(dict(game_id=gid, side=side, reason='Formation definition requires recovery'))
                continue
            link = next(iter(links[maker_id].values())) if maker_id in links else None
            if link is None:
                # Exact full-name agreement is used only within the already
                # matched dated team lineup, with a unique native Opta asset ID.
                # Club slugs are deliberately ignored: some are inconsistent.
                label = namekey(keeper['player']['name'])
                matches = [(j, p) for j, p in enumerate(page['data']['lineups'][native]['starts'])
                           if namekey(p['person']['name']) == label]
                if len(matches) != 1:
                    issues.append(dict(game_id=gid, side=side, reason='Unique exact dated full-name identity requires recovery'))
                    continue
                li, actor = matches[0]
                native_ids = set(re.findall(r'/(p\d+)/', str(actor.get('photos', {}))))
                if len(native_ids) != 1:
                    issues.append(dict(game_id=gid, side=side, reason='League native player identity requires recovery'))
                    continue
                pid = next(iter(native_ids))
                link = dict(basis='unique exact full name in same dated official team lineup',
                    source=source, lineup_pointer='/props/pageProps/data/lineups/'+native+'/starts/'+str(li),
                    maker_player_id=maker_id, opta_player_id=pid, maker_name=keeper['player']['name'],
                    league_name=actor['person']['name'])
            pid = link['opta_player_id']
            people = [p for p in parsed['players'] if p['side'] == side and p['official_player_id'] == pid]
            if len(people) != 1:
                issues.append(dict(game_id=gid, side=side, reason='Native Opta identity absent from league lineup'))
                continue
            person = people[0]
            valid, reason = full_match(page, parsed, person)
            if not valid:
                issues.append(dict(game_id=gid, side=side, official_player_id=pid, reason=reason))
                continue
            assert str(person['team_id']) == str(meta['team'+side+'_id'])
            raw_stats = page['data']['stats'].get(native) or {}
            saves = raw_stats.get('saves')
            if saves is not None:
                assert isinstance(saves, (int, float)) and saves >= 0 and saves == int(saves)
            against = games[gid]['scoreB' if side == 'A' else 'scoreA']
            pointer = '/props/pageProps/data/lineups/'+native+'/starts'
            idx = next(i for i, p in enumerate(page['data']['lineups'][native]['starts'])
                       if str(p['id']) == person['source_lineup_id'])
            role = dict(source=mg['source'], pointer='/lineups/'+native+'Team/'+str(i)+'/formationPlace',
                raw_value=1, role_basis='Same-game native Opta identity; supported official club formation grid',
                definition_source=definition_source, formation=formation, formation_grid=grids[formation],
                maker_player_id=maker_id, maker_game_id=meta['maker_game_id'],
                maker_team_id=raw['game'][native+'Team']['id'], verified_start_utc=meta['start_time'],
                fixture_index_source=meta['index_source'], identity_link=link,
                direct_league_full_match=True, league_lineup_pointer=pointer+'/'+str(idx),
                minutes_basis='Complete official regulation events and no keeper exit, including stoppage time',
                source_provider='La Liga official match report with same-game Elche official role evidence')
            recovered_clocks=parsed.get('regulation_clock_recoveries',[])
            if recovered_clocks: role['regulation_clock_recoveries']=recovered_clocks
            evidence = dict(
                saves=dict(raw_value=None, basis='verified full-match goalkeeper assigned official team total' if saves is not None else 'not reported',
                    team_pointer='/props/pageProps/data/stats/'+native+'/saves', team_raw_value=saves),
                goals_conceded=dict(raw_value=None, basis='verified full-match goalkeeper assigned official team total',
                    team_pointer='/props/pageProps/match/'+('home' if side == 'A' else 'away')+'_score', team_raw_value=against),
                keeper_xgot_conceded=dict(raw_value=None, basis='not reported'))
            availability=[pd.Timestamp(person['available_at_utc']),pd.Timestamp(meta['available_at_utc'])]
            if recovered_clocks:
                availability += [pd.Timestamp(e['date_source']) for e in page['events'] if e.get('date_source')]
            rows.append(dict(game_id=gid, side=side, team_id=person['team_id'], official_player_id=pid,
                id_namespace='opta_player_asset', player_name=person['player_name'], minutes=90.,
                available_at_utc=max(availability).isoformat(),
                source=source, role_evidence=role, field_evidence=evidence,
                saves=saves, goals_conceded=against, keeper_xgot_conceded=None))
    assert not pd.DataFrame(rows).duplicated(['game_id', 'side', 'official_player_id']).any() if rows else True
    report = dict(at_utc=stamp(), status='PASS', recovered_rows=len(rows), pending_sides=issues,
        source_database_sha256=file_sha256(ROOT_OUT/'soccer_additional.sqlite'),
        maker_database_sha256=file_sha256(ROOT_OUT/'laliga_maker.sqlite'),
        raw_player_values_preserved_as_null=True, full_match_team_totals_labelled_derived=True)
    dump(FOLDER/'direct_keeper_recovery.json', report)
    print(json.dumps(dict(stage='laliga_direct_keeper_recovery', recovered_rows=len(rows), pending_sides=len(issues))), flush=True)
    return rows


def crosscheck_team_totals():
    """Compare independent reported keeper saves with league team saves."""
    keepers = pd.read_parquet(ROOT_OUT/'soccer_goalkeeper_game_observations.parquet')
    keepers = keepers[keepers.league.eq('La Liga') & keepers.raw_saves.notna()]
    known = keepers.set_index(['game_id','side','official_player_id']).to_dict('index')
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games = {r['game_id']:dict(r) for r in db.execute("SELECT * FROM soccer_games WHERE league='La Liga'")}
    checks = []
    with read_db(ROOT_OUT/'soccer_additional.sqlite') as db:
        for b, in db.execute("SELECT body FROM games WHERE league='La Liga'"):
            record = json.loads(b); gid = record['game_id']
            if not any((gid,p['side'],p['official_player_id']) in known for p in record['players'] if p['started']):
                continue
            source = record['sources'][0]; blob = (PROJECT/source['raw_file']).read_bytes()
            assert hashlib.sha256(blob).hexdigest() == source['sha256']
            page = page_props(blob); parsed = parse(games[gid], page, source)
            for p in parsed['players']:
                key = (gid,p['side'],p['official_player_id'])
                if key not in known or not full_match(page,parsed,p)[0]:
                    continue
                value = (page['data']['stats'].get('away' if p['side']=='A' else 'home') or {}).get('saves')
                if value is None:
                    continue
                checks.append(dict(game_id=gid,side=p['side'],player_id=p['official_player_id'],
                    individual_saves=known[key]['raw_saves'],team_saves=value,match=value==known[key]['raw_saves'],
                    team_source=source,individual_source=json.loads(known[key]['source_json'])))
    report = dict(at_utc=stamp(),checked=len(checks),matches=sum(r['match'] for r in checks),
        disagreements=[r for r in checks if not r['match']],records=checks)
    dump(FOLDER/'full_keeper_team_saves_crosscheck.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='records'}),flush=True)


def repair_native_identities(rows):
    """Resolve club-only IDs from the same dated league lineup, without later games."""
    pending=[r for r in rows if r['id_namespace']=='laliga_maker_uuid']
    with read_db(ROOT_OUT/'soccer_additional.sqlite') as db:
        reports={r['game_id']:r for r in [json.loads(b) for b, in db.execute("SELECT body FROM games WHERE league='La Liga'")]}
    corrected=[];issues=[]
    for row in pending:
        gid=row['game_id'];native='away' if row['side']=='A' else 'home'
        if gid not in reports:
            issues.append(dict(game_id=gid,side=row['side'],reason='Same-game league lineup still needs recovery'));continue
        record=reports[gid];source=record['sources'][0];blob=(PROJECT/source['raw_file']).read_bytes()
        assert hashlib.sha256(blob).hexdigest()==source['sha256']
        page=page_props(blob);match=page['match']
        assert str(match['id'])==row['official_game_id'] and match['status']=='FullTime'
        assert str(match[native+'_team']['id'])==row['team_id']
        role=json.loads(row['role_evidence_json']);old_id=row['official_player_id']
        raw=(PROJECT/role['source']['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==role['source']['sha256']
        maker=json.loads(raw);person=maker
        for bit in role['pointer'].rsplit('/',1)[0].strip('/').split('/'):
            person=person[int(bit)] if isinstance(person,list) else person[bit]
        assert person['player']['id']==old_id and person['starting'] and person['formationPlace']==1
        assert [match['away_score'],match['home_score']]==[maker['game']['awayScore'],maker['game']['homeScore']]
        found=[(i,p) for i,p in enumerate(page['data']['lineups'][native]['starts'])
               if namekey(p['person']['name'])==namekey(person['player']['name'])]
        if len(found)!=1:
            issues.append(dict(game_id=gid,side=row['side'],reason='No unique exact full-name league identity'));continue
        i,p=found[0];ids=set(re.findall(r'/(p\d+)/',str(p.get('photos',{}))))
        if len(ids)!=1:
            issues.append(dict(game_id=gid,side=row['side'],reason='Native player asset ID absent'));continue
        pid=next(iter(ids));assert p['status']=='start'
        link=dict(basis='unique exact full name in same dated official team lineup',source=source,
            lineup_pointer='/props/pageProps/data/lineups/'+native+'/starts/'+str(i),maker_player_id=old_id,
            opta_player_id=pid,maker_name=person['player']['name'],league_name=p['person']['name'])
        role['identity_link']=link;role['raw_player_id_preserved']=old_id
        row['role_evidence_json']=json.dumps(role,sort_keys=True)
        row['official_player_id']=pid;row['id_namespace']='opta_player_asset'
        corrected.append(dict(game_id=gid,side=row['side'],maker_player_id=old_id,opta_player_id=pid,proof=link))
    report=dict(at_utc=stamp(),status='PASS',checked=len(pending),corrected=len(corrected),records=corrected,
        pending=issues,same_game_identity_only=True,performance_values_changed=False)
    dump(FOLDER/'native_identity_repairs.json',report)
    print(json.dumps({k:v for k,v in report.items() if k not in ['records','pending']}),flush=True)


def finish_clock_recovery():
    """Describe and verify the incremental keeper publication, without refitting."""
    from common import REPORTS
    final=ROOT_OUT/'soccer_goalkeeper_game_observations.parquet'
    validation=json.loads((FOLDER.parent/'keeper_validation.json').read_bytes())
    assert validation['status']=='PASS' and validation['source_sha256']==file_sha256(final)
    delta=json.loads((FOLDER/'recovery_publication_delta.json').read_bytes())
    assert delta['new_sha256']==file_sha256(final) and delta['unchanged_old_rows']
    frame=pd.read_parquet(final)
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        actual=pd.read_sql_query('SELECT * FROM soccer_goalkeeper_game_observations',db)
    pd.testing.assert_frame_equal(frame,actual,check_dtype=False,check_exact=True)
    report=REPORTS/'soccer_stoppage_clock_recovery.md'
    lines=['# Soccer goalkeeper history recovery','',
      f"Recovered {delta['recovered_rows']} goalkeeper appearances from four dated La Liga matches. All {delta['old_rows']:,} previously published records are unchanged. The table now contains {len(frame):,} rows across {frame.game_id.nunique():,} games.",'',
      'The official report supplied a stoppage-time clock and elapsed minute but omitted separate minute/second fields for a red card. The previous global minutes check rejected the match. A first-half 45+N or second-half 90+N event maps exactly to 45 or 90 in this dataset\'s regulation-only minutes. The parser accepts this only when the clock, period and elapsed-minute fields agree. It does not invent seconds for ordinary playing time.','',
      'Native same-game goalkeeper roles remain supported by official club formation data and identity evidence. Complete substitution/red-card sequences, including stoppage time, must show that the goalkeeper stayed on the pitch. Only then are official team saves and conceded goals assigned as derived goalkeeper values. Raw player-statistic values remain null. Later source corrections delay availability for future performance queries.','',
      '|Game|Goalkeeper|Saves|Conceded|Available after UTC|','|---|---|---:|---:|---|']
    for r in delta['rows']:
        lines.append(f"|{r['game_id']}|{r['player_name']}|{r['saves']:.0f}|{r['goals_conceded']:.0f}|{r['available_at_utc']}|")
    lines+=['',
      'Validation covered four original source cases and eight negative controls. Ordinary minutes or contradictory clocks still fail. Independent raw replay checked 17,890 native roles and 53,670 raw cells. SQL and Parquet agree. This update affects goalkeeper observations; improved forecasts have not been claimed.','',
      'The remaining direct-report recovery queue contains 522 sides needing dated goalkeeper-role evidence, two needing native identities, and one without verified full-match goalkeeper exposure. These are pending recovery cases, not declarations that their data cannot be obtained.','',
      'Current official La Liga client inspection defines position 0 as manager and uses starter status to separate starters. It does not define position 1 as goalkeeper. Lineup ordering alone was not used to assign roles. Current documentation URLs, original responses and hashes are in current_league_role_discovery.json and each record\'s role_evidence_json. The subscription-key route was not bypassed.','',
      'Reproduce with soccer_keeper_facts.py, validate_soccer_keeper_facts.py, soccer_keeper_facts.py --publish, and publish.py. Then run laliga_direct_keeper_recovery.py --finish-clock-recovery. Clock recovery is an opt-in parser option; general player-history parsing remains unchanged. The direct keeper collector applies it only to the verified keeper derivation.','',
      'Official match sources:','']
    sources=json.loads((FOLDER/'event_repair_diagnosis.json').read_bytes())
    for row in sources['rows']:lines.append(f"- [{row['game_id']}]({row['source']['url']})")
    report.write_text('\n'.join(lines)+'\n',encoding='utf8')
    from final_pipeline import cleanup
    cleanup()
    receipt=dict(status='PASS',at_utc=stamp(),table='soccer_goalkeeper_game_observations',
      rows=len(frame),recovered_rows=delta['recovered_rows'],previous_rows_unchanged=True,sql_parquet_equal=True,
      sha256=file_sha256(final),duplicate_staged_file_removed=not (FOLDER.parent/'keeper_observations.parquet').exists(),
      report=str(report),new_model_result_claimed=False)
    dump(ROOT_OUT/'retention/soccer_stoppage_clock_recovery_completion.json',receipt)
    print(json.dumps(receipt),flush=True)


if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--crosscheck',action='store_true');parser.add_argument('--finish-clock-recovery',action='store_true');args=parser.parse_args()
    if args.finish_clock_recovery:
        finish_clock_recovery()
    elif args.crosscheck:
        crosscheck_team_totals()
    else:
        parser.error('Use soccer_keeper_facts.py for normalization, or --crosscheck for independent save totals')
