"""Resolve documented source-entry aliases through exact official Opta IDs."""
import argparse,hashlib,json
from common import ROOT_OUT,PROJECT,dump,stamp
from ligue_sparse_statistics import RUN as BASE,main as reconcile

RUN=ROOT_OUT/'ligue_alias_v38'


def pointer(body,path):
    for part in path.strip('/').split('/'):
        part=part.replace('~1','/').replace('~0','~')
        body=body[int(part)] if isinstance(body,list) else body[part]
    return body


def verified_aliases():
    cache={};evidence=[];aliases={}
    def raw(source):
        digest=source['sha256']
        if digest not in cache:
            blob=(PROJECT/source['raw_file']).read_bytes()
            assert hashlib.sha256(blob).hexdigest()==digest
            cache[digest]=json.loads(blob)
        return cache[digest]
    queue=json.loads((BASE/'actor_identity_repair_queue.json').read_bytes())
    for row in queue:
        if row['status']!='exact_native_alias_candidate':continue
        source=raw(row['source']);old=row['original_actor_id'];new=row['candidate_player_ids'][0]
        assert pointer(source,row['actor_pointer'])==old
        native='away' if row['side']=='A' else 'home';pool=source[native]['players']
        pool=list(pool.values()) if isinstance(pool,dict) else pool
        assert old not in {p['id'] for p in pool}
        pid=row['native_ids_observed'][0]
        matches=[p for p in pool if str(p['playerIdentity'].get('shortOptaId'))==pid]
        assert len(matches)==1 and matches[0]['id']==new and matches[0]['playedMatch'] is True
        for e in row['same_native_id_evidence']:
            earlier=raw(e['source']);assert str(pointer(earlier,e['pointer']))==pid
            player=pointer(earlier,e['pointer'].rsplit('/playerIdentity/',1)[0])
            assert player['id']==old
        key=(row['game_id'],row['side'],old)
        assert key not in aliases or aliases[key]==new
        aliases[key]=new;evidence.append(row)
    RUN.mkdir(exist_ok=True)
    dump(RUN/'verified_actor_aliases.json',evidence)
    dump(RUN/'alias_validation.json',dict(status='PASS',at_utc=stamp(),actor_references=len(evidence),
        unique_alias_keys=len(aliases),raw_hashes=len(cache),names_used=False,raw_values_changed=False,
        limitation='Cross-response identity evidence is retrospective; it repairs immutable person identity, not a future statistic or proof of original publication vintage.'))
    return aliases


def main(pilot=False):
    aliases=verified_aliases();games=sorted({key[0] for key in aliases})
    selected={games[0],games[len(games)//2],games[-1]} if pilot else None
    reconcile(pilot=pilot,run=RUN,aliases=aliases,selected_game_ids=selected)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');a=p.parse_args();main(a.pilot)
