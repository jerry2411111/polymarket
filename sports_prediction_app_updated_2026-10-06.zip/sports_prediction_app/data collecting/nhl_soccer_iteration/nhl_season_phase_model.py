"""Give the NHL goal model an explicit, known-before-game preseason context."""
import argparse
import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score,log_loss,brier_score_loss
from scipy.optimize import minimize
from scipy.special import expit,logit
from threadpoolctl import threadpool_limits

from common import ROOT_OUT,PREVIOUS,REPORTS,read_db,dump,stamp,file_sha256
import nhl_player_strength as roster
import models

LABEL='nhl_season_phase_model'
RESULT=ROOT_OUT/'simulation_results'/LABEL
WORK=ROOT_OUT/'_work'/LABEL
CONTROL='phase_control_regulation_ot'
CANDIDATE='phase_context_regulation_ot'
FIELDS=['f_gran_preseason','f_gran_preseason_elo','f_gran_preseason_skater_strength','f_gran_preseason_goalie_strength']


def initialize():
    RESULT.mkdir(exist_ok=True);WORK.mkdir(parents=True,exist_ok=True)
    plan=dict(at_utc=stamp(),hypothesis='The all-phase NHL model has a playoff indicator but no preseason indicator. High-confidence development misses include preseason, when historical team/player strengths may translate differently. Add phase context rather than exclude these games.',
        fields=FIELDS,source='Official native NHL game ID encodes gameType01preseason; cross-check stored official phase. Team/player strengths retain original earlier-only sources and native IDs.',
        features='Preseason indicator plus its interactions with Elo difference, jointly fitted skater goal strength and goalie goal strength. Original37inputs become41; counts are verified after reconstruction. No new external facts or current-game participants.',
        model='Original regulation-goal Poisson+learned overtime model,alpha1,purged180daytemperature; same expanding2021+history/monthly2024+forecasts. Independent logistic confirmation unchanged.',
        gate='Lower pooled2024/25logloss andBrier; lower2025overalllogloss and preseasonlogloss; overallwinneraccuracy>=52%. Then provider2025higherSharpe,positive return,no worse drawdown,2024Sharpe no worse where defined.',
        strategy='Same pre12closest-prior quote<=24h; both modelprobabilities/price>=1.10;one outcome,flat20dollars,annual2000cash-only. No hour,threshold,stake or regularization grid.',
        evaluation='Only earlier-qualified providers are evaluated on2026. Repeatedly inspected2026is retrospective rolling research.',app_changed=False)
    path=RESULT/'plan.json'
    if path.exists():assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(path,plan)
    return plan


def build():
    initialize();assert not (RESULT/'feature_validation.json').exists()
    import features,nhl_identity_features
    games,unused,unused_rosters,keys=roster.load();del unused,unused_rosters,keys
    g,o,p,_,stats,metrics,_=features.sources('nhl',include_preseason=True)
    needed=['game_id','side','available_at_utc','player_id','official_player_id','minutes','position','saves','shots_against','played']+metrics
    p=roster.apply_repairs(p[list(dict.fromkeys(needed))])
    base,_=nhl_identity_features.derive(g,o,p,stats,metrics,repaired=True,regulation_labels=games)
    del g,o,p
    path=ROOT_OUT/'nhl_roster_strength_features.parquet'
    proof=json.loads((ROOT_OUT/'retention/nhl_roster_strength_validation.json').read_bytes())
    assert file_sha256(path)==proof['derived_data_sha256']
    extra=pd.read_parquet(path).drop(columns=['date','prediction_time'])
    f=base.merge(extra,on='game_id',validate='one_to_one')
    assert len(f)==8540 and f.game_id.is_unique
    native=f.official_game_id.astype(str).str[4:6].eq('01')
    assert native.equals(f.phase.eq('Preseason'))
    f[FIELDS[0]]=native.astype(float)
    for field,original in zip(FIELDS[1:],['f_elo_diff']+roster.FIELDS[:2]):
        f[field]=f[original].where(native,0.)
        assert f.loc[~native,field].eq(0).all()
        assert f.loc[native,field].equals(f.loc[native,original])
    for c in ['source_max_available_utc','role_source_max_available_utc','onice_source_max_available_utc','player_rating_source_max_utc']:
        assert (f[c].isna()|f[c].lt(f.prediction_time)).all()
    f.to_parquet(WORK/'nhl_features.parquet',index=False)
    original=models.CANDIDATES['granular_regulation_ot']
    control=dict(original,exclude_columns=FIELDS)
    counts=f.groupby([f.prediction_time.dt.year,'phase']).size().rename('games').reset_index()
    counts.to_csv(RESULT/'phase_coverage.csv',index=False)
    report=dict(status='PASS',at_utc=stamp(),games=len(f),preseason_games=int(native.sum()),
        original_inputs=len(models.columns(f.assign(league_NHL=1.),control)),candidate_inputs=len(models.columns(f.assign(league_NHL=1.),original)),
        source_clock_checks=True,phase_native_id_check=True,changed_existing_inputs=False,
        feature_sha256=file_sha256(WORK/'nhl_features.parquet'),strength_source_sha256=file_sha256(path))
    dump(RESULT/'feature_validation.json',report);print(json.dumps(report),flush=True)


def setup():
    models.OUT=WORK
    original=models.CANDIDATES['granular_regulation_ot']
    models.CANDIDATES[CONTROL]=dict(original,exclude_columns=FIELDS)
    models.CANDIDATES[CANDIDATE]=dict(original)


def diagnose_goalies():
    """Post-game diagnosis only: prior most-used goalie versus actual usage.

    Current appearances never enter a predictor or betting rule. The recent
    goalie is a reproducible history proxy, not an asserted announced starter.
    """
    import collections
    from nhl_identity_features import history_keys
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games=pd.read_sql_query("SELECT * FROM nhl_games WHERE date BETWEEN '2021-01-01' AND '2025-12-31'",db)
        players=pd.read_sql_query("SELECT game_id,side,official_player_id,player_name,played,started,minutes,request_ids_json,source_pointer FROM nhl_player_games WHERE position='G'",db)
    for col in ['prediction_time','available_time','start_time']:
        games[col]=pd.to_datetime(games[col],utc=True,format='mixed')
    keys,_=history_keys(games,True)
    players=roster.apply_repairs(players[players.game_id.isin(games.game_id)])
    groups={k:v.to_dict('records') for k,v in players.groupby(['game_id','side'])}
    bets=pd.read_parquet(ROOT_OUT/'simulation_results/nhl_sports_combination/margin_bets.parquet')
    bets=bets[bets.variant.eq('relative10')].copy()
    selected=set(bets.game_id)
    history=collections.defaultdict(lambda:collections.deque(maxlen=5))
    events=list(games.sort_values(['available_time','game_id']).itertuples());cursor=0;rows=[]
    for game in games.sort_values(['prediction_time','game_id']).itertuples():
        while cursor<len(events) and events[cursor].available_time<game.prediction_time:
            old=events[cursor];cursor+=1
            for side in ['A','B']:
                history[keys[old.game_id,side]].append((old,groups.get((old.game_id,side),[])))
        if game.game_id not in selected:continue
        for side in ['A','B']:
            h=list(history[keys[game.game_id,side]]);minutes=collections.Counter();names={};sources=[]
            complete=bool(h)
            for old,people in h:
                complete &= bool(people) and all(pd.notna(x['minutes']) for x in people)
                for person in people:
                    names[str(person['official_player_id'])]=person['player_name']
                    if pd.notna(person['minutes']) and person['minutes']>0:
                        minutes[str(person['official_player_id'])]+=person['minutes']
                sources.append(old.available_time)
            assert not sources or max(sources)<game.prediction_time
            leading=sorted(minutes,key=lambda k:(-minutes[k],k))[0] if complete and minutes else None
            current=groups.get((game.game_id,side),[])
            actual=[x for x in current if x['played']==1 or (pd.notna(x['minutes']) and x['minutes']>0)]
            all_known=bool(current) and all(pd.notna(x['played']) or (pd.notna(x['minutes']) and x['minutes']>0) for x in current)
            used_ids={str(x['official_player_id']) for x in actual}
            present=leading in used_ids if leading is not None and all_known else None
            rows.append(dict(game_id=game.game_id,side=side,phase=game.phase,prediction_time=game.prediction_time,
                recent_most_used_goalie_id=leading,recent_most_used_goalie_name=names.get(leading),
                recent_goalie_source_max=max(sources) if sources else None,
                previous_game_ids_json=json.dumps([x.game_id for x,_ in h]),
                recent_most_used_goalie_appeared=present,actual_goalies_json=json.dumps(actual),
                interpretation='After-game diagnostic; recent five-game usage is not a confirmed pre-match starter'))
    evidence=pd.DataFrame(rows)
    evidence.to_parquet(RESULT/'goalie_usage_case_evidence.parquet',index=False)
    b=bets.copy();b['side']=np.where(b.side.eq(0),'A','B')
    b=b.merge(evidence,on=['game_id','side'],validate='many_to_one')
    b['goalie_context']=b.recent_most_used_goalie_appeared.map({True:'recent_goalie_appeared',False:'recent_goalie_did_not_appear'}).fillna('unresolved')
    out=b.groupby(['provider','year','phase','goalie_context']).agg(bets=('game_id','size'),
        wins=('won','sum'),mean_probability=('probability','mean'),mean_price=('price','mean'),net_profit=('profit','sum')).reset_index()
    out.to_csv(RESULT/'goalie_usage_diagnosis.csv',index=False)
    b[~b.won].sort_values('probability',ascending=False).to_csv(RESULT/'losing_goalie_examples.csv',index=False)
    print(out.to_string(index=False),flush=True)


def paired(raw,reference):
    a=raw[raw.variant.eq(CONTROL)].set_index('game_id').sort_index()
    b=reference.set_index('game_id').loc[a.index]
    assert np.array_equal(a.target,b.target)
    assert np.allclose(a[['p0','p1']],b[['p0','p1']],rtol=0,atol=1e-12)
    for col in ['train_label_max','calibration_label_max','calibration_train_label_max']:
        assert np.array_equal(a[col],b[col])
    candidate=raw[raw.variant.eq(CANDIDATE)].set_index('game_id').loc[a.index]
    assert candidate.train_label_max.lt(candidate.prediction_time).all()
    assert candidate.calibration_label_max.lt(candidate.prediction_time).all()
    assert candidate.calibration_train_label_max.lt(candidate.calibration_prediction_min).all()
    combined=b.reset_index();combined['corrected_p1']=candidate.p1.to_numpy()
    frame=pd.read_parquet(WORK/'nhl_features.parquet').set_index('game_id')
    combined['phase']=frame.loc[combined.game_id,'phase'].to_numpy()
    return combined


def score(p):
    rows=[]
    for name,col in [('reference','p1'),('phase_context','corrected_p1')]:
        for year,f in [('pooled',p)]+list(p.groupby(p.prediction_time.dt.year)):
            for phase,g in [('all',f)]+list(f.groupby('phase')):
                pr=g[col].to_numpy();y=g.target.to_numpy()
                rows.append(dict(variant=name,year=year,phase=phase,games=len(g),accuracy=accuracy_score(y,pr>=.5),
                    logloss=log_loss(y,np.c_[1-pr,pr],labels=[0,1]),brier=brier_score_loss(y,pr)))
    return pd.DataFrame(rows)


def replay(raw,stage):
    f=pd.read_parquet(WORK/'nhl_features.parquet');f=pd.concat([f,pd.get_dummies(f.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
    effects=[];n=0
    for name in [CONTROL,CANDIDATE]:
        package=pickle.loads((WORK/'model_runs/nhl'/stage/(name+'.pkl')).read_bytes())
        selected=raw[raw.variant.eq(name)&raw.fold.eq(package['boundary'].strftime('%Y-%m'))].head(12)
        x=f.loc[selected.game_id,package['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
        actual=models.apply_calibration(package['model'].predict_proba(x),package['calibrator'])
        assert np.allclose(actual,selected[['p0','p1']],rtol=0,atol=1e-12);n+=len(selected)
        if name==CANDIDATE:
            for target,model in zip(['away_regulation_goals','home_regulation_goals'],package['model'].models):
                coef=model.steps[-1][1].coef_.ravel()
                for field in FIELDS:
                    effects.append(dict(target=target,field=field,coefficient_per_training_sd=float(coef[package['columns'].index(field)]),
                        boundary=str(package['boundary']),link='log expected regulation goals before calibration'))
    pd.DataFrame(effects).to_csv(RESULT/(stage+'_phase_coefficients.csv'),index=False)
    return n


def train():
    initialize();setup();assert not (RESULT/'validation.json').exists()
    proof=json.loads((RESULT/'feature_validation.json').read_bytes())
    assert file_sha256(WORK/'nhl_features.parquet')==proof['feature_sha256']
    diagnose_goalies()
    from nhl_sports_combination import source
    import nhl_disagreement_calibration as cash
    cash.RESULT=RESULT
    raw=models.run('nhl','development',[CONTROL,CANDIDATE]);p=paired(raw,source())
    replayed=replay(raw,'development')
    p.to_parquet(RESULT/'development_predictions.parquet',index=False)
    m=score(p);m.to_csv(RESULT/'development_metrics.csv',index=False)
    s=m.set_index(['variant','year','phase'])
    gate=bool(all(s.loc[('phase_context','pooled','all'),c]<s.loc[('reference','pooled','all'),c] for c in ['logloss','brier']) and
        all(s.loc[('phase_context',2025,phase),'logloss']<s.loc[('reference',2025,phase),'logloss'] for phase in ['all','Preseason']) and
        s.loc[('phase_context','pooled','all'),'accuracy']>=.52)
    a=cash.accounts(p,'development',candidate_name='phase_context');choices={}
    ref=pd.read_csv(ROOT_OUT/'simulation_results/nhl_disagreement_calibration/development_annual.csv')
    for provider,g in a.groupby('provider'):
        v=g.set_index(['variant','year']);x,y=v.loc[('phase_context',2025)],v.loc[('reference',2025)]
        allowed=gate and x.sharpe>y.sharpe and x.return_pct>0 and x.max_drawdown_pct<=y.max_drawdown_pct
        if pd.notna(v.loc[('reference',2024),'sharpe']):allowed &= v.loc[('phase_context',2024),'sharpe']>=v.loc[('reference',2024),'sharpe']
        choices[provider]=bool(allowed)
        for r in g[g.variant.eq('reference')].itertuples():
            old=ref[ref.variant.eq('reference')&ref.provider.eq(provider)&ref.year.eq(r.year)].iloc[0]
            for col in ['funded_games','return_pct','sharpe','max_drawdown_pct']:
                assert np.isclose(getattr(r,col),old[col],rtol=0,atol=1e-10,equal_nan=True)
    selection=dict(at_utc=stamp(),probability_gate=gate,providers=choices,adopted=False)
    dump(RESULT/'selection.json',selection)
    if any(choices.values()):
        dump(WORK/'nhl_selection.json',dict(selected_candidates=[CONTROL,CANDIDATE]))
        eraw=models.run('nhl','evaluation',[CONTROL,CANDIDATE])
        ref=source(True);ref=ref[ref.prediction_time.dt.year.eq(2026)]
        ev=paired(eraw,ref);replayed+=replay(eraw,'evaluation')
        ev.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
        score(ev).to_csv(RESULT/'evaluation_metrics.csv',index=False)
        cash.accounts(ev,'evaluation',[k for k,v in choices.items() if v],candidate_name='phase_context')
    dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),selection=selection,old_forecasts_reproduced=len(p),
        fitted_forecasts_replayed=replayed,prior_training_and_calibration_verified=True,
        evaluated2026=any(choices.values()),app_changed=False,goal_achieved=False))
    print(m[m.phase.eq('all')|m.phase.eq('Preseason')].to_string(index=False),flush=True)
    print(a[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print(json.dumps(selection),flush=True)


def calibration():
    """Use earlier preseason forecast errors, rather than unrelated phase errors.

    Warm-up2022/23 forecasts exist solely as earlier calibration observations;
    strategy testing still begins2024. No2026 choice or outcome enters fitting.
    """
    assert not json.loads((RESULT/'selection.json').read_bytes())['probability_gate']
    assert not (RESULT/'phase_calibration_validation.json').exists()
    setup()
    plan=dict(at_utc=stamp(),diagnosis='Four preseason inputs improved2025preseason winner accuracy but worsened probabilities and accounts. The September trailing180daycalibration has no preseason examples. Test a phase-specific confidence correction of the ORIGINAL model instead.',
        model='Original37inputs and original Poisson/OT recipe. Rejected41input candidate is not used.',
        warmup='Generate exact same monthly expanding recipe for preseason forecasts in2022/23 solely for earlier calibration data. All base history starts2021. Strategy development begins2024, evaluation2026onlyaftergates.',
        formula='For preseason only,q=expit(logit(p)/T),T>=1. Each month minimize logloss on ALL earlier settled preseason out-of-fit forecasts. Other phases unchanged. Require100prior games and10of each class; otherwiseT1. No window or temperature grid.',
        gate='Lower pooled2024/25logloss andBrier, lower2025overall/preseasonlogloss, overallwinneraccuracy>=52%. Provider2025higherSharpe,positive return,no worse drawdown;2024Sharpe no worse.',
        unchanged='Secondary classifier,pre12quote rules,10%relative advantage,budget/settlement/cost assumptions unchanged. No app deployment.',
        evaluation='2026 remains repeatedly inspected retrospective rolling research.')
    dump(RESULT/'phase_calibration_plan.json',plan)
    data=pd.read_parquet(WORK/'nhl_features.parquet').sort_values(['prediction_time','game_id'])
    data=pd.concat([data,pd.get_dummies(data.league,prefix='league',dtype=float)],axis=1)
    spec=models.CANDIDATES[CONTROL];cols=models.columns(data,spec)
    x=lambda frame:frame[cols].replace([np.inf,-np.inf],np.nan).astype(float)
    earlier=data[data.prediction_time.dt.year.isin([2022,2023])&data.phase.eq('Preseason')]
    warm=[];proof=[]
    for fold,test in earlier.groupby(earlier.prediction_time.dt.strftime('%Y-%m')):
        cutoff=pd.Timestamp(fold+'-01',tz='UTC');prior=data[data.available_time.lt(cutoff)]
        cal=prior[prior.prediction_time.ge(cutoff-pd.Timedelta(days=180))]
        training=prior[prior.available_time.lt(cal.prediction_time.min())]
        assert len(cal)>=80 and len(training)>=500
        assert training.available_time.max()<cal.prediction_time.min()
        assert prior.available_time.max()<test.prediction_time.min()
        with threadpool_limits(limits=4):
            model=models.make_model(spec,'nhl');models.fit_model(model,x(training),training,spec,cal.prediction_time.min())
            c=models.calibration_fit(model.predict_proba(x(cal)),cal.target.astype(int))
            model=models.make_model(spec,'nhl');models.fit_model(model,x(prior),prior,spec,cutoff)
            probability=models.apply_calibration(model.predict_proba(x(test)),c)
        f=test[models.META+['phase']].copy();f['p0']=probability[:,0];f['p1']=probability[:,1]
        f['train_label_max']=prior.available_time.max();f['calibration_label_max']=cal.available_time.max()
        warm.append(f);proof.append(dict(fold=fold,train_games=len(prior),calibration_games=len(cal),
            calibration_preseason_games=int(cal.phase.eq('Preseason').sum()),forecasts=len(test),
            train_label_max=str(prior.available_time.max()),calibration_train_label_max=str(training.available_time.max()),
            calibration_prediction_min=str(cal.prediction_time.min()),base_temperature=float(c['temperature'])))
    warm=pd.concat(warm,ignore_index=True)
    warm.to_parquet(RESULT/'preseason_calibration_warmup.parquet',index=False)
    dump(RESULT/'preseason_warmup_validation.json',dict(status='PASS',rows=len(warm),folds=proof,feature_sha256=file_sha256(WORK/'nhl_features.parquet')))
    from nhl_sports_combination import source
    base=source().merge(data[['game_id','phase']],on='game_id',validate='one_to_one')
    def transform(p):
        history=pd.concat([warm,p],ignore_index=True);out=[];fits=[]
        for fold,test in p.groupby(p.prediction_time.dt.strftime('%Y-%m')):
            cut=pd.Timestamp(fold+'-01',tz='UTC')
            prior=history[history.available_time.lt(cut)&history.phase.eq('Preseason')]
            counts=prior.target.value_counts();ready=len(prior)>=100 and len(counts)==2 and counts.min()>=10
            temperature=1.
            if ready:
                z=logit(prior.p1.to_numpy());y=prior.target.to_numpy()
                def objective(t):
                    v=z*np.exp(-t[0])
                    return float(np.mean(np.logaddexp(0,v)-y*v)),np.array([-np.mean((expit(v)-y)*v)])
                opt=minimize(objective,[0.],jac=True,method='L-BFGS-B',bounds=[(0,None)],options={'ftol':1e-12,'gtol':1e-9})
                assert opt.success,opt.message
                temperature=float(np.exp(opt.x[0]));assert np.isfinite(temperature)
            row=test.copy();row['corrected_p1']=row.p1
            mask=row.phase.eq('Preseason');row.loc[mask,'corrected_p1']=expit(logit(row.loc[mask,'p1'])/temperature)
            row['phase_temperature']=temperature;row['phase_calibration_cutoff']=cut
            row['phase_calibration_last_label']=prior.available_time.max()
            assert prior.empty or prior.available_time.max()<test.prediction_time.min()
            assert np.array_equal(row.p1.ge(.5),row.corrected_p1.ge(.5))
            assert row.loc[~mask,'corrected_p1'].equals(row.loc[~mask,'p1'])
            out.append(row);fits.append(dict(fold=fold,prior_preseason_games=len(prior),ready=bool(ready),temperature=temperature,last_label=str(prior.available_time.max())))
        return pd.concat(out,ignore_index=True),pd.DataFrame(fits)
    p,fits=transform(base);prefix,_=transform(base[base.prediction_time.dt.year.eq(2024)])
    pd.testing.assert_frame_equal(prefix.set_index('game_id').sort_index(),p.set_index('game_id').loc[prefix.game_id].sort_index(),check_exact=True)
    m=score(p).replace({'variant':{'phase_context':'preseason_calibration'}})
    m.to_csv(RESULT/'phase_calibration_development_metrics.csv',index=False)
    p.to_parquet(RESULT/'phase_calibration_development_predictions.parquet',index=False)
    fits.to_csv(RESULT/'phase_calibration_fits.csv',index=False)
    s=m.set_index(['variant','year','phase']);name='preseason_calibration'
    gate=bool(all(s.loc[(name,'pooled','all'),c]<s.loc[('reference','pooled','all'),c] for c in ['logloss','brier']) and
        all(s.loc[(name,2025,phase),'logloss']<s.loc[('reference',2025,phase),'logloss'] for phase in ['all','Preseason']) and
        s.loc[(name,'pooled','all'),'accuracy']>=.52)
    import nhl_disagreement_calibration as cash
    cash.RESULT=RESULT
    a=cash.accounts(p,'phase_calibration_development',candidate_name=name);choices={}
    for provider,g in a.groupby('provider'):
        v=g.set_index(['variant','year']);u,b=v.loc[(name,2025)],v.loc[('reference',2025)]
        passed=gate and u.sharpe>b.sharpe and u.return_pct>0 and u.max_drawdown_pct<=b.max_drawdown_pct
        if pd.notna(v.loc[('reference',2024),'sharpe']):passed &= v.loc[(name,2024),'sharpe']>=v.loc[('reference',2024),'sharpe']
        choices[provider]=bool(passed)
    selection=dict(at_utc=stamp(),probability_gate=gate,providers=choices,adopted=False)
    dump(RESULT/'phase_calibration_selection.json',selection)
    if any(choices.values()):
        allbase=source(True).merge(data[['game_id','phase']],on='game_id',validate='one_to_one')
        both,_=transform(allbase);old=both[both.prediction_time.dt.year.lt(2026)]
        pd.testing.assert_frame_equal(old.set_index('game_id').sort_index(),p.set_index('game_id').sort_index(),check_exact=True)
        ev=both[both.prediction_time.dt.year.eq(2026)]
        ev.to_parquet(RESULT/'phase_calibration_evaluation_predictions.parquet',index=False)
        score(ev).replace({'variant':{'phase_context':name}}).to_csv(RESULT/'phase_calibration_evaluation_metrics.csv',index=False)
        cash.accounts(ev,'phase_calibration_evaluation',[k for k,v in choices.items() if v],candidate_name=name)
    dump(RESULT/'phase_calibration_validation.json',dict(status='PASS',at_utc=stamp(),selection=selection,
        warmup_forecasts=len(warm),earlier_prefix_replays=len(prefix),regular_and_playoff_probabilities_unchanged=True,
        same_winner_predictions=True,prior_training_labels_verified=True,evaluated2026=any(choices.values()),app_changed=False))
    print(m[m.phase.isin(['all','Preseason'])].to_string(index=False),flush=True)
    print(a[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print(json.dumps(selection),flush=True)


def finish():
    proof=json.loads((RESULT/'validation.json').read_bytes());assert proof['status']=='PASS'
    def table(f):
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(str(v) for v in row)+' |' for row in f.itertuples(index=False,name=None)])
    m=pd.read_csv(RESULT/'development_metrics.csv')
    lines=['# NHL preseason context test','',
        'The loss inspection found preseason among the largest-confidence mistakes. The original all-phase inputs include playoffs but do not explicitly encode preseason. This test adds the official preseason indicator and three interactions: preseason times Elo difference, jointly fitted skater strength and goalie strength. This allows historical strengths to have different effects without excluding preseason games. Phase is checked against the native NHL game-type code; all strength inputs use only earlier observations.','',
        'Same regulation-goal Poisson model, learned overtime outcome and existing regularization; same monthly expanding2021+training and purged180daycalibration. Independent logistic confirmation is unchanged. All3,066old development control forecasts reproduce exactly. Four additional inputs; no parameter grid.','',
        'The separate goalie-usage diagnosis compares the preceding five-game most-used goalie with actual game participation. It retains native IDs, prior game IDs, source clocks and actual official player source references. Actual participation is used only to explain observed errors; it never enters the model or an entry filter. A missing recent goalie is not asserted to be the cause of a loss.','',
        table(pd.read_csv(RESULT/'goalie_usage_diagnosis.csv')),'',
        table(m[m.phase.isin(['all','Preseason'])]),'',
        'Selection: '+json.dumps(proof['selection'])+'. Each provider must pass the earlier probability and account gates before new2026evaluation. Repeatedly inspected2026is retrospective research. No model or app adoption.','',
        'Account rules remain pre12closest-prior quote at most24hoursold;one outcome,both models imply at least10%relative advantage,$20fixedstake,annual$2000cash-only. Hold to official settlement. No added costs. Daily-calendar Sharpe annualizes bysqrt365.25. Polymarket historical token prices are reference prices, not verified executable US asks; Kalshi uses retainedYESaskcloses.','',
        table(pd.read_csv(RESULT/'development_annual.csv')[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        'Reproduce nhl_season_phase_model.py build, train, calibration, stake, finish. Existing source phase/strength tables are reused; no duplicate research table is added. Rejected fitted packages and temporary feature matrices are deleted after validation.']
    ev=RESULT/'evaluation_annual.csv'
    if ev.exists():lines+=['','2026retrospective evaluation:',table(pd.read_csv(ev)[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']])]
    cpath=RESULT/'phase_calibration_validation.json'
    if cpath.exists():
        cp=json.loads(cpath.read_bytes());assert cp['status']=='PASS'
        lines+=['','Follow-up: preserve the original37-input forecast and calibrate preseason confidence using all earlier settled preseason forecasts. Earlier2022/23out-of-fit preseason forecasts are generated with expanding2021+training solely as calibration warmup; strategy testing still starts2024. Fit one temperature>=1 by logloss each month; ordinary-season probabilities and winner choices are unchanged. No fitted threshold or stake search. This addresses the absence of prior preseason examples in the September180daycalibration window.','',
                'Selection: '+json.dumps(cp['selection'])+'.2024prefix forecasts replay exactly.','',
                table(pd.read_csv(RESULT/'phase_calibration_development_metrics.csv').query("phase in ['all','Preseason']")),'',
                table(pd.read_csv(RESULT/'phase_calibration_development_annual.csv')[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']])]
        lines+=['','For Winnipeg versus Minnesota on2025-09-21, the earlier five-game most-used goalie was Connor Hellebuyck, but the actual game used Thomas Milic and Isaac Poulter. The model originally gave Winnipeg80.8875%; the past-only preseason correction reduces this to72.9436%. For Los Angeles versus Anaheim on2025-09-27, the earlier most-used goalie was Darcy Kuemper; Erik Portillo played. Confidence falls from78.0654%to70.5303%. These explain why phase/roster uncertainty warrants investigation; they do not establish that goalie changes caused the losses. The broader usage comparison includes profitable games without the recent goalie, so no such post-game exclusion is used.','',
            'Probability quality improved in both development years, but the fixed betting rule did not improve. Keep the phase-calibration forecasts as a research reference for subsequent strategy work, not an adopted strategy or a claim of target achievement.']
        ee=RESULT/'phase_calibration_evaluation_annual.csv'
        if ee.exists():lines+=['','2026retrospective follow-up:',table(pd.read_csv(ee)[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']])]
    stakepath=RESULT/'calibrated_stake_validation.json'
    if stakepath.exists():
        stakeproof=json.loads(stakepath.read_bytes());assert stakeproof['status']=='PASS'
        lines+=['','Staking follow-up on the improved probability model: keep original entry eligibility and reduce the existing$20stake continuously when corrected expected profit is lower. Stake=$20*clip((corrected_probability-price)/(original_probability-price),0,1). This avoids changing a10%qualification boundary merely because the probability map changed. Both original and corrected probabilities remain in the ledger. No leverage, new timing or fitted stake coefficient. No negative-value corrected position is funded.','',
            'Selection: '+json.dumps(stakeproof['choices'])+'.','',table(pd.read_csv(RESULT/'calibrated_stake_development_annual.csv')[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']])]
        ee=RESULT/'calibrated_stake_evaluation_annual.csv'
        if ee.exists():lines+=['','2026retrospective sizing follow-up:',table(pd.read_csv(ee)[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']])]
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False)
    parts=[pd.read_csv(file).assign(source_result_file=LABEL+'/'+file.name) for file in RESULT.glob('*annual.csv')]
    pd.concat([old[~old.source_result_file.str.startswith(LABEL+'/',na=False)]]+parts,ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes())
    d[LABEL]=dict(plan=json.loads((RESULT/'plan.json').read_bytes()),validation=proof)
    if cpath.exists():d[LABEL+'/phase_calibration']=dict(plan=json.loads((RESULT/'phase_calibration_plan.json').read_bytes()),validation=json.loads(cpath.read_bytes()))
    if stakepath.exists():d[LABEL+'/calibrated_stake']=dict(plan=json.loads((RESULT/'calibrated_stake_plan.json').read_bytes()),validation=json.loads(stakepath.read_bytes()))
    dump(path,d)
    from final_pipeline import discard_work,cleanup,validate
    if WORK.exists():discard_work(WORK)
    cleanup();check=validate()
    receipt=dict(status='PASS',at_utc=stamp(),validation=proof,app_validation=check,adopted=False,goal_achieved=False)
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(path.read_bytes())
    m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']),latest_simulation_update=receipt);dump(path,m)


def stake():
    """Isolate sizing from a hard eligibility-boundary change after calibration."""
    assert json.loads((RESULT/'phase_calibration_selection.json').read_bytes())['probability_gate']
    assert not (RESULT/'calibrated_stake_validation.json').exists()
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    dump(RESULT/'calibrated_stake_plan.json',dict(at_utc=stamp(),
        diagnosis='Phase calibration improved proper forecast scores but its10%filter removed four2025Polymarket bets with$40netprofit. Isolate stake adjustment instead of threshold-crossing membership.',
        formula='Keep original10%both-model eligibility,pre12andone-sidechoice. Stake=20*clip((corrected_p-price)/(original_p-price),0,1). Uncorrected phases remainexactly20. Corrected nonpositive edges receive0. Secondary unchanged.',
        control='Exact original flat20cash-only account,annual2000; same observed prices/settlements. No cost assumptions or stake parameter search.',
        gate='Probability correction already passes earlier proper-score gate. New2025providerSharpehigher,positive return,no worse drawdown,2024Sharpeno worse. Only then2026retrospectiveevaluation.',app_changed=False))
    transfer.RESULT=RESULT
    quotes=quote_inputs(RESULT/'calibrated_stake_quote_quality.json',revision='closest_v62')
    p=pd.read_parquet(RESULT/'phase_calibration_development_predictions.parquet')
    def evaluate(p,stage,providers=None):
        f=transfer.normalize('nhl',p,quotes,True);ix=p.set_index('game_id').loc[f.game_id]
        f['secondary_probability']=np.where(f.side.eq(0),ix.second_p0,ix.second_p1)
        f['corrected_probability']=np.where(f.side.eq(0),1-ix.corrected_p1,ix.corrected_p1)
        f['phase']=ix.phase.to_numpy()
        f=f[np.minimum(f.probability,f.secondary_probability)/f.price>=1.10].copy()
        # Preserve exact original complements outside the corrected phase;
        # 1-p1 may otherwise differ from the stored p0 by one floating-point bit.
        unchanged=f.phase.ne('Preseason')
        assert np.allclose(f.loc[unchanged,'corrected_probability'],f.loc[unchanged,'probability'],rtol=0,atol=1e-14)
        f.loc[unchanged,'corrected_probability']=f.loc[unchanged,'probability']
        f['stake_multiplier']=((f.corrected_probability-f.price)/(f.probability-f.price)).clip(0,1)
        assert f.loc[f.phase.ne('Preseason'),'stake_multiplier'].eq(1).all()
        annual=[];bets=[];days=[];checks=[]
        for name,sizing in [('reference','flat20_cash_only'),('calibrated_stake','fixed20_scaled_cash_only')]:
            for provider,g in f.groupby('provider'):
                if providers is not None and provider not in providers:continue
                for year in sorted(p.prediction_time.dt.year.unique()):
                    m,b,l,d=engine.simulate(g,int(year),'all_selected_outcomes',sizing,5.,2000.)
                    key=dict(sport='nhl',provider=provider,variant=name,year=int(year))
                    annual.append(key|m);checks.append(key|engine.validate(b,l,d,sizing,5.,2000.))
                    if len(b):
                        if name=='calibrated_stake':
                            independent=20*np.minimum(1,np.maximum(0,(b.corrected_probability-b.price)/(b.probability-b.price)))
                            assert np.allclose(b.proposed_stake,independent,rtol=0,atol=1e-10)
                            assert b.corrected_probability.gt(b.price).all()
                        bets.append(b.assign(**key))
                    days.append(d.assign(**key))
        a=pd.DataFrame(annual);a.to_csv(RESULT/('calibrated_stake_'+stage+'_annual.csv'),index=False)
        pd.concat(bets,ignore_index=True).to_parquet(RESULT/('calibrated_stake_'+stage+'_bets.parquet'),index=False)
        pd.concat(days,ignore_index=True).to_parquet(RESULT/('calibrated_stake_'+stage+'_daily.parquet'),index=False)
        dump(RESULT/('calibrated_stake_'+stage+'_cash_validation.json'),dict(status='PASS',checks=checks))
        return a
    a=evaluate(p,'development');choices={}
    baseline=pd.read_csv(RESULT/'development_annual.csv')
    for provider,g in a.groupby('provider'):
        v=g.set_index(['variant','year']);x,y=v.loc[('calibrated_stake',2025)],v.loc[('reference',2025)]
        passed=x.sharpe>y.sharpe and x.return_pct>0 and x.max_drawdown_pct<=y.max_drawdown_pct
        if pd.notna(v.loc[('reference',2024),'sharpe']):passed &= v.loc[('calibrated_stake',2024),'sharpe']>=v.loc[('reference',2024),'sharpe']
        choices[provider]=bool(passed)
        for r in g[g.variant.eq('reference')].itertuples():
            old=baseline[baseline.variant.eq('reference')&baseline.provider.eq(provider)&baseline.year.eq(r.year)].iloc[0]
            for field in ['funded_games','return_pct','sharpe','max_drawdown_pct']:
                assert np.isclose(getattr(r,field),old[field],rtol=0,atol=1e-10,equal_nan=True)
    dump(RESULT/'calibrated_stake_selection.json',dict(at_utc=stamp(),choices=choices,adopted=False))
    # If this passes, the same phase-temperature transform must generate2026
    # forecasts from prior settled preseason errors before evaluation proceeds.
    if any(choices.values()):
        raise RuntimeError('Earlier sizing gate passed; generate dated2026phase calibration before finishing this run')
    dump(RESULT/'calibrated_stake_validation.json',dict(status='PASS',at_utc=stamp(),choices=choices,
        independent_stake_and_cash_replay=True,original_accounts_reproduced=True,evaluated2026=False,app_changed=False))
    print(a[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print(json.dumps(choices),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['build','train','calibration','stake','finish'])
    globals()[parser.parse_args().stage]()
