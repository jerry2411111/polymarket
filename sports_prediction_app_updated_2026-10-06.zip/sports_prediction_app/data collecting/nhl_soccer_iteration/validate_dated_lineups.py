"""Source replay, native joins and publication-cutoff checks for lineup survey."""
import hashlib,html,json,re,urllib.request
import pandas as pd
from common import PROJECT,ROOT_OUT,dump,stamp
from collect_dated_lineup_survey import RUN,selection,parse,source_games
from collect_nhl_opening_rosters import namekey,StructuredArticle
from nhl_roster_aliases import read_source,verify_proof


def main(run=RUN,archive=False):
    f=pd.read_parquet(run/'verified_players.parquet');r=pd.read_parquet(run/'reports.parquet')
    if archive:
        audit=json.loads((run/'raw_validation.json').read_bytes());assert audit['status']=='PASS_RAW_AND_GAME_LINKS'
        g=pd.read_parquet(run/'requested_games.parquet')
        expected=source_games();expected=expected[expected.date.str.startswith(str(audit['year']))][g.columns].sort_values(['start_time','game_id'])
        pd.testing.assert_frame_equal(g.reset_index(drop=True),expected.reset_index(drop=True),check_exact=True)
        assert not g.duplicated(['date','teamA','teamB']).any()
        assert len(f)==audit['player_entries'] and len(r)==audit['replayed_reports']
        g=g[g.game_id.isin(r.game_id)]
    else:
        g=pd.read_parquet(run/'selected_games.parquet');pd.testing.assert_frame_equal(selection(),g,check_exact=True)
    fields=['side','source_group_number','source_player_index','report_status','player_name_raw','source_group_text'];sources={};identities=0
    for row in r.to_dict('records'):
        game=g[g.game_id.eq(row['game_id'])].iloc[0].to_dict()|dict(_allow_unique_schedule_match=archive);source=json.loads(row['source_json']);blob=read_source(source);sources[source['sha256']]=blob
        actual=f[f.game_id.eq(row['game_id'])];parsed,reason=parse(blob,game);assert reason=='parsed'
        expected=pd.DataFrame(parsed['players'])[fields].reset_index(drop=True)
        pd.testing.assert_frame_equal(actual[fields].reset_index(drop=True),expected,check_exact=True)
        a=StructuredArticle();a.feed(blob.decode());a=next(x for x in a.items if isinstance(x,dict) and x.get('@type')=='NewsArticle')
        published=pd.Timestamp(a['datePublished']);modified=pd.Timestamp(a.get('dateModified',a['datePublished']));available=max(published,modified)
        assert available==pd.Timestamp(row['available_at_utc'])
        assert actual.available_at_utc.map(pd.Timestamp).eq(available).all()
        assert bool(available<=pd.Timestamp(game['prediction_time']))==bool(row['available_by_pre12'])
        for p in actual[actual.identity_verified].itertuples():
            proof=json.loads(p.identity_proof_json);kind=proof['kind']
            if kind=='dated_full_name_sweater':
                e=proof['evidence'];assert verify_proof(e) and e['official_player_id']==p.official_player_id and namekey(e['report_name'])==namekey(p.player_name_raw)
                for k in ['report_source','box_source']:sources[e[k]['sha256']]=read_source(e[k])
            elif kind=='validated_opening_alias':
                e=proof['evidence'];assert e['identity_verified'] and str(e['official_player_id'])==p.official_player_id and namekey(e['player_name_raw'])==namekey(p.player_name_raw)
                assert str(e['team_id'])==p.team_id
                for field in ['release_source_json','identity_source_json']:
                    if e.get(field):read_source(json.loads(e[field]))
            else:
                src=proof['source'];raw=read_source(src);sources[src['sha256']]=raw
                if kind=='roster_exact':
                    native=json.loads(raw);part,index=proof['pointer'].strip('/').split('/');person=native[part][int(index)]
                    assert str(person['id'])==p.official_player_id and namekey(person['firstName']['default']+' '+person['lastName']['default'])==namekey(p.player_name_raw)
                elif kind=='landing_exact':
                    person=json.loads(raw);assert str(person['playerId'])==p.official_player_id and namekey(person['firstName']['default']+' '+person['lastName']['default'])==namekey(p.player_name_raw)
                else:
                    assert kind=='article_native_link'
                    links=[(pid,html.unescape(re.sub('<[^>]+>','',name))) for pid,name in re.findall(r'<a[^>]+href="(?:https://www.nhl.com)?/player/[^"/]+-(\d+)"[^>]*>(.*?)</a>',raw.decode(),re.S)]
                    ids={pid for pid,name in links if namekey(name)==namekey(p.player_name_raw)};assert ids=={p.official_player_id}
            identities+=1
    # Date-query availability never changes when later reports are removed.
    cut=pd.Timestamp(f"{audit['year']}-07-01" if archive else '2025-01-01',tz='UTC');prefix=f[pd.to_datetime(f.available_at_utc,utc=True,format='ISO8601')<cut]
    earlyreports=r[pd.to_datetime(r.available_at_utc,utc=True,format='ISO8601')<cut]
    expected=f[f.game_id.isin(earlyreports.game_id)]
    pd.testing.assert_frame_equal(prefix,expected,check_exact=True)
    assert not f.duplicated(['game_id','side','source_group_number','source_player_index']).any()
    assert f.loc[~f.identity_verified,'official_player_id'].isna().all()
    expected_conflict=f.identity_verified&f.duplicated(['game_id','side','official_player_id'],keep=False)
    assert f.identity_or_status_conflict.eq(expected_conflict).all()
    app=json.loads((ROOT_OUT/'retention/app_preservation_baseline.json').read_bytes())
    assert all(hashlib.sha256((PROJECT/'sports_app'/name).read_bytes()).hexdigest()==h for name,h in app.items())
    with urllib.request.urlopen('http://127.0.0.1:8766/api/health',timeout=15) as response:health=response.status
    result=dict(status='PASS',at_utc=stamp(),reports=len(r),raw_sources=len(sources),player_rows=len(f),verified_native_joins=identities,
        unresolved_identity_rows=int((~f.identity_verified).sum()),conflicting_source_rows=int(f.identity_or_status_conflict.sum()),earlier_date_query_rows=len(prefix),
        publication_clocks_verified=True,no_model_uses_current_future_lineups=True,app_unchanged_files=len(app),app_health=health)
    dump(run/'validation.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
