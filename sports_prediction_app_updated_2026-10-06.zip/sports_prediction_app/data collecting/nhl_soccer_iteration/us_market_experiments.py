"""Causal market windows, chronological second-stage models, bounded ablations."""
import argparse,collections,json,math
import numpy as np
import pandas as pd
from scipy.special import expit,logit,softmax
from sklearn.linear_model import LogisticRegression,Ridge
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from common import ROOT_OUT,dump,stamp
from us_market_data import RESULT,predictions
from us_market_research import protocol,probability_scores
from models import temperature_fit,apply_calibration

HOURS=[12,6,3,1]
CONTEXT=['f_elo_diff','f_rest_days_diff','f_games_7d_diff','f_margin_diff',
         'xg_diff','goalie_quality_diff','goalie_uncertainty','lineup_available','feature_missing_fraction']

def goalie_setup():
    games=pd.read_parquet(ROOT_OUT/'games.parquet').set_index('game_id')
    q=pd.read_parquet(ROOT_OUT/'nhl_context_goalie_quality.parquet')
    q['at']=pd.to_datetime(q.available_at_utc,utc=True,format='mixed');q['official_player_id']=q.official_player_id.astype(str)
    q['team']=[games.loc[g,'team'+s] for g,s in zip(q.game_id,q.side)]
    reports=pd.read_parquet(ROOT_OUT/'nhl_dated_lineup_players.parquet')
    reports=reports[reports.identity_verified&~reports.identity_or_status_conflict&reports.report_status.eq('projected')].copy()
    reports['at']=pd.to_datetime(reports.available_at_utc,utc=True,format='mixed')
    reports['official_player_id']=reports.official_player_id.astype(str)
    return games,{k:v.sort_values('at') for k,v in q.groupby('team')},{k:v.sort_values('at') for k,v in q.groupby('official_player_id')},{k:v for k,v in reports.groupby('game_id')}

def goalie_features(g,entry,resources):
    games,teams,players,reports=resources;names=games.loc[g.game_id];report=reports.get(g.game_id,pd.DataFrame())
    quality=[];uncertainty=[];used=0;maxsource=None
    for side in ['A','B']:
        history=teams.get(names['team'+side],pd.DataFrame())
        if not len(history):return dict(goalie_quality_diff=np.nan,goalie_uncertainty=np.nan,lineup_available=0.,goalie_source_time=None)
        history=history[history['at'].lt(entry)].tail(20)
        if not len(history):return dict(goalie_quality_diff=np.nan,goalie_uncertainty=np.nan,lineup_available=0.,goalie_source_time=None)
        candidates=[]
        if len(report):
            visible=report[report.side.eq(side)&report['at'].le(entry)]
            if len(visible):
                visible=visible[visible['at'].eq(visible['at'].max())]
                candidates=[pid for pid in visible.official_player_id.unique() if pid in players and players[pid]['at'].lt(entry).any()]
                if candidates:used+=1;maxsource=max(maxsource or visible['at'].max(),visible['at'].max())
        # Earlier observed shot workload is a proxy for starter likelihood, not known starter identity.
        if not candidates:candidates=list(history.official_player_id.unique())
        weights=[];ratings=[]
        for pid in candidates:
            own=players[pid];own=own[own['at'].lt(entry)].tail(20)
            valid=own[own.xg.notna()&own.goals.notna()&own.modelled_attempts.gt(0)]
            if not len(valid):continue
            ratings.append(30*float((valid.xg-valid.goals).sum())/(float(valid.modelled_attempts.sum())+100))
            weights.append(float(history[history.official_player_id.eq(pid)].modelled_attempts.sum())+30)
            maxsource=max(maxsource or valid['at'].max(),valid['at'].max(),history['at'].max())
        if not weights:return dict(goalie_quality_diff=np.nan,goalie_uncertainty=np.nan,lineup_available=used/2,goalie_source_time=maxsource)
        w=np.array(weights)/sum(weights);quality.append(float(np.dot(w,ratings)));uncertainty.append(1-float(w.max()))
    assert maxsource is None or maxsource<=entry
    return dict(goalie_quality_diff=quality[1]-quality[0],goalie_uncertainty=float(np.mean(uncertainty)),lineup_available=used/2,goalie_source_time=maxsource)

def prepare():
    protocol();assert not (RESULT/'entry_dataset.parquet').exists(),'Preserve completed entry dataset'
    p=predictions();contracts=pd.read_parquet(RESULT/'contracts.parquet');points=pd.read_parquet(RESULT/'us_price_points.parquet')
    points['timestamp']=pd.to_datetime(points.timestamp,utc=True);points['created']=pd.to_datetime(points.market_created_at,utc=True)
    points['creation_consistent']=points.created.notna()&points.created.le(points.timestamp)
    conflicts=points.groupby(['game_id','side','timestamp']).price.nunique()
    assert conflicts.max()<=1,'Contradictory same-timestamp prices'
    points=points.drop_duplicates(['game_id','side','timestamp'])
    byquote={k:v.sort_values('timestamp') for k,v in points.groupby(['game_id','side'])}
    available=set(contracts.game_id);rows=[];coverage=[];context={}
    for sport in ['nhl','soccer']:
        f=pd.read_parquet(ROOT_OUT/f'retained_models/{sport}/{sport}_features.parquet')
        if sport=='nhl':f=pd.read_parquet(ROOT_OUT/'nhl_identity_repaired_model_features.parquet')
        context[sport]=f.set_index('game_id')
    goalies=goalie_setup()
    for _,g in p[p.game_id.isin(available)].iterrows():
        start=pd.Timestamp(g.start_time);lo=start-pd.Timedelta(hours=12);k=2 if g.sport=='nhl' else 3
        assert pd.Timestamp(g.prediction_time)<=lo
        for h in HOURS:
            entry=start-pd.Timedelta(hours=h)
            r=g.to_dict();r.update(entry=entry,entry_hours=h,provider='polymarket_us',start=start,exit=g.available_time)
            r['feature_time']=g.prediction_time
            frame=context[g.sport]
            f=frame.loc[g.game_id] if g.game_id in frame.index else None
            for field in CONTEXT:r[field]=np.nan
            if f is not None and pd.Timestamp(f.prediction_time)<=entry:
                for field in ['f_elo_diff','f_rest_days_diff','f_games_7d_diff','f_margin_diff']:r[field]=f.get(field,np.nan)
                r['xg_diff']=f.get('f_gran_even_strength_expected_margin',np.nan) if g.sport=='nhl' else f.get('f_quality_xg_diff',np.nan)
            r['feature_missing_fraction']=float(np.mean([pd.isna(r[x]) for x in CONTEXT[:5]]))
            if g.sport=='nhl':r.update(goalie_features(g,entry,goalies))
            else:r.update(goalie_quality_diff=np.nan,goalie_uncertainty=np.nan,lineup_available=np.nan,goalie_source_time=None)
            for side in range(k):
                hist=byquote.get((g.game_id,side),pd.DataFrame());valid=hist[hist.creation_consistent] if len(hist) else hist
                valid=valid[valid.timestamp.ge(lo)&valid.timestamp.le(entry)] if len(valid) else valid
                observed=hist[hist.timestamp.le(entry)] if len(hist) else hist
                r['diagnostic_unverified_q'+str(side)]=float(observed.iloc[-1].price) if len(observed) else np.nan
                if len(valid):
                    last=valid.iloc[-1];assert lo<=last.timestamp<=entry<start
                    r.update({f'q{side}':float(last.price),f'quote_time{side}':last.timestamp,f'quote_request{side}':int(last.request_number),f'quote_pointer{side}':last.raw_pointer,f'contract_id{side}':last.contract_id})
                    r[f'quote_age_minutes{side}']=(entry-last.timestamp).total_seconds()/60
                    r[f'quote_count{side}']=len(valid);r[f'quote_changes{side}']=int(valid.price.diff().fillna(0).ne(0).sum())
                else:
                    for key in ['q','quote_time','quote_request','quote_pointer','contract_id','quote_age_minutes','quote_count','quote_changes']:r[key+str(side)]=np.nan
                for anchor in [12,9,6,3,1]:
                    earlier=valid[valid.timestamp.le(start-pd.Timedelta(hours=anchor))] if len(valid) and anchor>=h else pd.DataFrame()
                    r[f'q{side}_at{anchor}']=float(earlier.iloc[-1].price) if len(earlier) else np.nan
            used_times=[pd.Timestamp(g.prediction_time)]+[pd.Timestamp(r['quote_time'+str(j)]) for j in range(k) if pd.notna(r.get('quote_time'+str(j)))]
            if r.get('goalie_source_time') is not None:used_times.append(pd.Timestamp(r['goalie_source_time']))
            r['feature_time']=max(used_times)
            rows.append(r)
    f=pd.DataFrame(rows)
    for c in ['entry','start','exit','prediction_time','feature_time']:f[c]=pd.to_datetime(f[c],utc=True)
    for c in ['train_label_max','calibration_label_max']:assert pd.to_datetime(f[c],utc=True).lt(f.feature_time).all()
    assert f.feature_time.le(f.entry).all() and f.entry.lt(f.start).all() and f.start.lt(f.exit).all()
    assert not f.duplicated(['game_id','entry_hours']).any()
    for sport in ['nhl','soccer']:
        for year in [2024,2025,2026]:
            for h in HOURS:
                total=int((p.sport.eq(sport)&(pd.to_datetime(p.start_time,utc=True)-pd.Timedelta(hours=h)).dt.year.eq(year)).sum())
                z=f[f.sport.eq(sport)&f.entry.dt.year.eq(year)&f.entry_hours.eq(h)]
                k=2 if sport=='nhl' else 3
                choice=z[['p'+str(i) for i in range(k)]].to_numpy().argmax(axis=1) if len(z) else []
                usable=sum(pd.notna(row['q'+str(int(side))]) for (_,row),side in zip(z.iterrows(),choice))
                full=int(z[['q'+str(i) for i in range(k)]].notna().all(axis=1).sum())
                coverage.append(dict(sport=sport,year=year,entry_hours=h,baseline_forecasts=total,matched_us_games=len(z),complete_prices=full,selected_winner_prices=usable,missing_winner_quote_pct=100*(1-usable/total) if total else None))
    f.to_parquet(RESULT/'entry_dataset.parquet',index=False);pd.DataFrame(coverage).to_csv(RESULT/'us_coverage.csv',index=False)
    dump(RESULT/'entry_validation.json',dict(status='PASS',at_utc=stamp(),entries=len(f),points=len(points),precreation_points=int((~points.creation_consistent).sum()),all_feature_entry_start_orderings_checked=True))
    print(pd.DataFrame(coverage).to_string(index=False),flush=True)

def preprocessor(model):
    return make_pipeline(SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True),StandardScaler(),model)

def calibrate(raw,y):
    return temperature_fit(raw,y)

def apply_temp(raw,temp):return softmax(np.log(np.clip(raw,1e-8,1))/temp,axis=1)

def fit_models():
    protocol();assert not (RESULT/'market_model_predictions.parquet').exists(),'Preserve completed fits'
    f=pd.read_parquet(RESULT/'entry_dataset.parquet');out=[];audit=[]
    dc=pd.read_parquet(RESULT/'soccer_model_predictions.parquet')
    for sport in ['nhl','soccer']:
        k=2 if sport=='nhl' else 3;pcols=['p'+str(i) for i in range(k)];qcols=['q'+str(i) for i in range(k)]
        for h in HOURS:
            g=f[f.sport.eq(sport)&f.entry_hours.eq(h)].copy().sort_values('entry')
            base=g.copy();base['model']='sports_baseline';out.append(base)
            if sport=='soccer':
                for name,x in dc.groupby('model'):
                    if name=='sports_baseline':continue
                    z=g.drop(columns=pcols).merge(x[['game_id']+pcols],on='game_id',validate='one_to_one');z['model']=name;out.append(z)
            g=g[g[qcols].notna().all(axis=1)].copy()
            if not len(g):continue
            q=g[qcols].to_numpy();market=np.column_stack([1-q[:,1],q[:,1]]) if k==2 else q/q.sum(axis=1)[:,None]
            z=g.copy();z[pcols]=market;z['model']='market_only';out.append(z)
            g['market_logit']=logit(np.clip(q[:,1],1e-5,1-1e-5))
            for j in range(k):g['market_log'+str(j)]=np.log(np.clip(market[:,j],1e-5,1))
            g['base_logit']=logit(np.clip(g.p1,1e-5,1-1e-5))
            if sport=='soccer':
                ens=dc[dc.model.eq('ensemble_0.75')].set_index('game_id')
                for j in range(3):g['ensemble_p'+str(j)]=g.game_id.map(ens['p'+str(j)])
            linear=['market_logit','base_logit'] if k==2 else ['market_log'+str(j) for j in range(k)]+pcols
            linear+=CONTEXT
            pick=g[pcols].to_numpy().argmax(axis=1);prob=g[pcols].to_numpy()[np.arange(len(g)),pick]
            chosen=g[qcols].to_numpy()[np.arange(len(g)),pick]
            g['confidence']=prob;g['selected_quote']=chosen;g['edge']=prob-chosen
            g['entropy']=-np.sum(g[pcols].to_numpy()*np.log(np.clip(g[pcols],1e-8,1)),axis=1)
            ordered=np.sort(g[pcols].to_numpy(),axis=1);g['margin']=ordered[:,-1]-ordered[:,-2]
            g['home_pick']=(pick==1).astype(float);g['correct']=(pick==g.target.to_numpy()).astype(int)
            g['activity']=[row['quote_changes'+str(side)] for (_,row),side in zip(g.iterrows(),pick)]
            g['age']=[row['quote_age_minutes'+str(side)] for (_,row),side in zip(g.iterrows(),pick)]
            meta=['confidence','selected_quote','edge','entropy','margin','home_pick','activity','age']+CONTEXT
            for fold,test in g.groupby(g.entry.dt.strftime('%Y-%m')):
                cut=pd.Timestamp(fold,tz='UTC');prior=g[g.exit.lt(cut)].sort_values('entry')
                if len(prior)<200:
                    audit.append(dict(sport=sport,horizon=h,fold=fold,status='insufficient_prior_us_history',prior_games=len(prior)));continue
                cal=prior.tail(60);train=prior.iloc[:-60];train=train[train.exit.lt(cal.entry.min())]
                if len(train)<120 or train.target.nunique()<k:continue
                assert train.exit.max()<cal.entry.min() and cal.exit.max()<test.entry.min()
                with threadpool_limits(limits=1):
                    anchored=preprocessor(LogisticRegression(C=.02,max_iter=2000,random_state=37)).fit(train[linear],train.target)
                    rawcal=anchored.predict_proba(cal[linear]);temp=calibrate(rawcal,cal.target)
                    raw=anchored.predict_proba(test[linear]);pq=apply_temp(raw,temp)
                    z=test.copy();z[pcols]=pq;z['model']='linear_residual';out.append(z)
                    if sport=='soccer':
                        ensemble_cols=[c for c in linear if c not in pcols]+['ensemble_p'+str(j) for j in range(3)]
                        em=preprocessor(LogisticRegression(C=.02,max_iter=2000,random_state=37)).fit(train[ensemble_cols],train.target)
                        ep=apply_temp(em.predict_proba(test[ensemble_cols]),calibrate(em.predict_proba(cal[ensemble_cols]),cal.target))
                        z=test.copy();z[pcols]=ep;z['model']='soccer_residual_ensemble';out.append(z)
                    # Direct conditional Y-q residual; outcome prices remain separate purchase values.
                    tq=train[qcols].to_numpy();cq=cal[qcols].to_numpy();vq=test[qcols].to_numpy()
                    if k==2:tq=np.c_[1-tq[:,1],tq[:,1]];cq=np.c_[1-cq[:,1],cq[:,1]];vq=np.c_[1-vq[:,1],vq[:,1]]
                    else:tq=tq/tq.sum(axis=1)[:,None];cq=cq/cq.sum(axis=1)[:,None];vq=vq/vq.sum(axis=1)[:,None]
                    ridge=preprocessor(Ridge(alpha=10)).fit(train[linear],np.eye(k)[train.target]-tq)
                    def normalized(v):
                        v=np.clip(v,1e-5,1-1e-5);return v/v.sum(axis=1)[:,None]
                    rc=normalized(cq+ridge.predict(cal[linear]));rp=normalized(vq+ridge.predict(test[linear]))
                    z=test.copy();z[pcols]=apply_temp(rp,calibrate(rc,cal.target));z['model']='direct_residual';out.append(z)
                    gate=preprocessor(LogisticRegression(C=.02,max_iter=2000,random_state=37)).fit(train[meta],train.correct)
                    mc=gate.predict_proba(cal[meta]);mt=calibrate(mc,cal.correct)
                    z=test.copy();z['meta_confidence']=apply_temp(gate.predict_proba(test[meta]),mt)[:,1];z['model']='meta_gate';out.append(z)
                    if sport=='nhl':
                        nonlinear=preprocessor(HistGradientBoostingRegressor(max_iter=100,max_depth=2,max_leaf_nodes=4,min_samples_leaf=30,l2_regularization=10,learning_rate=.05,random_state=37)).fit(train[linear],train.target-tq[:,1])
                        pc=np.clip(cq[:,1]+nonlinear.predict(cal[linear]),1e-5,1-1e-5);pt=np.clip(vq[:,1]+nonlinear.predict(test[linear]),1e-5,1-1e-5)
                        z=test.copy();z[pcols]=apply_temp(np.c_[1-pt,pt],calibrate(np.c_[1-pc,pc],cal.target));z['model']='nonlinear_residual';out.append(z)
                        # Explicit goalie ablation holds learner/rows fixed.
                        columns=[c for c in linear if c not in ['goalie_quality_diff','goalie_uncertainty','lineup_available']]
                        no=preprocessor(LogisticRegression(C=.02,max_iter=2000,random_state=37)).fit(train[columns],train.target)
                        z=test.copy();z[pcols]=apply_temp(no.predict_proba(test[columns]),calibrate(no.predict_proba(cal[columns]),cal.target));z['model']='linear_without_goalie';out.append(z)
                for z in out:
                    # Annotate only this fold's newly fitted outputs; baseline provenance remains intact.
                    if z.get('model',pd.Series(dtype=str)).eq('sports_baseline').all():continue
                    if z is not out[-1] and 'second_stage_training_end' in z:continue
                    if len(z) and z.entry.min()>=cut and z.model.iloc[0] in ['linear_residual','direct_residual','meta_gate','nonlinear_residual','linear_without_goalie','soccer_residual_ensemble']:
                        z['second_stage_training_end']=train.exit.max();z['second_stage_calibration_end']=cal.exit.max();z['second_stage_fold']=fold
                audit.append(dict(sport=sport,horizon=h,fold=fold,status='fitted',train_games=len(train),calibration_games=len(cal),test_games=len(test),train_label_max=str(train.exit.max()),calibration_label_max=str(cal.exit.max()),first_entry=str(test.entry.min())))
            print('Market model fits',sport,h,'hours',flush=True)
    output=pd.concat(out,ignore_index=True)
    output['correct']=pd.to_numeric(output['correct']).astype('Float64')
    output.to_parquet(RESULT/'market_model_predictions.parquet',index=False)
    pd.DataFrame(audit).to_csv(RESULT/'market_fit_audit.csv',index=False)
    metrics=[];cal=[]
    for (sport,h,model),g in output.groupby(['sport','entry_hours','model']):
        m,c=probability_scores(g,model,['p0','p1']+(['p2'] if sport=='soccer' else []))
        metrics.append(m.assign(entry_hours=h));cal.append(c.assign(entry_hours=h))
    pd.concat(metrics).to_csv(RESULT/'market_model_metrics.csv',index=False);pd.concat(cal).to_csv(RESULT/'market_model_calibration.csv',index=False)
    print('Market model forecast rows',len(output),flush=True)

def winners(frame):
    g=frame.copy();k=2 if g.iloc[0].sport=='nhl' else 3
    pcols=['p'+str(j) for j in range(k)];qcols=['q'+str(j) for j in range(k)]
    pr=g[pcols].to_numpy();side=pr.argmax(axis=1);g['side']=side
    g['probability']=pr[np.arange(len(g)),side];g['price']=g[qcols].to_numpy()[np.arange(len(g)),side]
    g=g[g.price.notna()].copy();g['edge']=g.probability-g.price;g['won']=g.side.eq(g.target)
    g['year']=g.entry.dt.year;g['date']=g.entry.dt.strftime('%Y-%m-%d')
    g['source_utc']=[r['quote_time'+str(int(r['side']))] for r in g.to_dict('records')]
    g['available_utc']=g.source_utc # Historical observation time; retrieval time remains in request audit.
    g['quote_age_minutes']=[r['quote_age_minutes'+str(int(r['side']))] for r in g.to_dict('records')]
    g['activity']=[r['quote_changes'+str(int(r['side']))] for r in g.to_dict('records')]
    early=[]
    for r in g.to_dict('records'):
        value=np.nan
        for anchor in [12,9,6,3]:
            q=r.get(f'q{int(r["side"])}_at{anchor}',np.nan)
            if anchor>r['entry_hours'] and pd.notna(q):value=q;break
        early.append(value)
    g['early_quote']=early;g['movement']=g.price-g.early_quote
    g['convergence']=(g.probability-g.early_quote).abs()-(g.probability-g.price).abs()
    g['signed_movement']=np.sign(g.probability-g.early_quote)*g.movement
    g['baseline_stake']=5*(100*g.probability-51).clip(lower=0)
    g['baseline_condition']=(g.probability.gt(.6)&g.price.gt(.5)) if k==2 else (g.probability.gt(.51)&g.side.eq(1))
    return g

def simulate(g,year,rule,amount=None):
    import test_confidence_dollars as engine
    g=g.copy();g['proposed_dollars']=g.baseline_stake if amount is None else amount
    g=g[g.proposed_dollars.gt(0)].copy()
    # Use the audited cash-only engine; proposed dollars are a risk-score multiple of20.
    g['risk_score_multiplier']=g.proposed_dollars/20
    m,b,l,d=engine.simulate(g,year,'all_selected_outcomes','mean_variance_cash_only',5.,2000.)
    engine.validate(b,l,d,'mean_variance_cash_only',5.,2000.)
    if len(b):
        assert b.side.eq(b[['p0','p1']+(['p2'] if b.iloc[0].sport=='soccer' else [])].to_numpy().argmax(axis=1)).all()
        assert pd.to_datetime(b.source_utc,utc=True).le(b.entry).all()
        assert pd.to_datetime(b.source_utc,utc=True).ge(b.start-pd.Timedelta(hours=12)).all()
        assert np.allclose(b.profit,b.stake*(b.won.astype(float)/b.price-1),atol=1e-9)
    m.update(median_stake=float(b.stake.median()) if len(b) else None,
        mean_p=float(b.probability.mean()) if len(b) else None,mean_q=float(b.price.mean()) if len(b) else None,
        mean_edge=float(b.edge.mean()) if len(b) else None,mean_outcome_minus_price=float((b.won.astype(float)-b.price).mean()) if len(b) else None,
        selected_brier=float(((b.probability-b.won.astype(float))**2).mean()) if len(b) else None,
        selected_logloss=float(-np.mean(b.won*np.log(b.probability)+(1-b.won)*np.log(1-b.probability))) if len(b) else None,
        median_quote_age_minutes=float(b.quote_age_minutes.median()) if len(b) else None)
    return m,b,d

def accounts():
    protocol();assert not (RESULT/'us_annual.csv').exists(),'Preserve completed account experiments'
    f=pd.read_parquet(RESULT/'market_model_predictions.parquet')
    other_soccer=pd.read_parquet(RESULT/'dixon_coles_predictions.parquet').set_index('game_id')
    other_nhl=pd.concat([pd.read_parquet(ROOT_OUT/'simulation_results/feature_revisions/nhl_player_strength'/(s+'_predictions.parquet')) for s in ['development','evaluation']])
    other_nhl=other_nhl[other_nhl.variant.eq('candidate')].set_index('game_id')
    rows=[];bets=[];days=[];buckets=[];conditionals=[];slopes=[]
    for (sport,h,model),frame in f.groupby(['sport','entry_hours','model']):
        g=winners(frame)
        if not len(g):continue
        # K is fixed using only earlier OOS observations, without using their profits.
        other=other_nhl if sport=='nhl' else other_soccer
        g['sigma_proxy']=[abs(r['probability']-other.loc[r['game_id'],'p'+str(int(r['side']))])/np.sqrt(2) if r['game_id'] in other.index else np.nan for r in g.to_dict('records')]
        g['edge_stake']=np.nan;g['edge_K']=np.nan;g['activity_prior_median']=np.nan
        for fold,index in g.groupby(g.entry.dt.strftime('%Y-%m')).groups.items():
            cut=pd.Timestamp(fold,tz='UTC');prior=g[g.exit.lt(cut)];past=prior[prior.baseline_condition]
            if len(past)>=30 and past.edge.clip(lower=0).sum()>0:
                K=float(past.baseline_stake.sum()/past.edge.clip(lower=0).sum())
                g.loc[index,'edge_K']=K
                g.loc[index,'edge_stake']=(K*g.loc[index,'edge'].clip(lower=0)).clip(upper=100)
                slopes.append(dict(sport=sport,entry_hours=h,model=model,fold=fold,K=K,prior_games=len(past),latest_result=str(past.exit.max())))
            if len(prior)>=30:g.loc[index,'activity_prior_median']=prior.activity.median()
        candidates=[]
        if model=='sports_baseline':
            candidates=[('us_baseline',g.baseline_condition,None),('winner_no_filter',pd.Series(True,index=g.index),None)]
            for edge in [0,.02,.04,.06,.08]:candidates.append((f'baseline_edge_gt_{edge:.2f}',g.baseline_condition&g.edge.gt(edge),None))
            candidates += [('winner_edge_gt_0.04',g.edge.gt(.04),None),
                ('converging_edge',g.edge.gt(.04)&g.convergence.gt(0),None),
                ('signed_movement_edge',g.edge.gt(.04)&g.signed_movement.gt(0),None),
                ('active_edge',g.edge.gt(.04)&g.activity.gt(g.activity_prior_median),None),
                ('edge_sizing',g.edge.gt(0)&g.edge_stake.notna(),g.edge_stake),
                ('edge_sizing_floor_0.04',g.edge.gt(.04)&g.edge_stake.notna(),(g.edge_K*(g.edge-.04).clip(lower=0)).clip(upper=100)),
                ('per_bet_cap100',g.baseline_condition,g.baseline_stake.clip(upper=100))]
            for lam in [.5,1.]:
                adjusted=g.edge-lam*g.sigma_proxy
                candidates.append((f'disagreement_buffer_{lam}',adjusted.gt(0)&g.edge_K.notna(),(g.edge_K*adjusted.clip(lower=0)).clip(upper=100)))
            # Predetermined cluster caps; no regrouping based on subsequent wins/losses.
            order=g[g.baseline_condition].sort_values(['entry','game_id'])
            same_day=pd.Series(0.,index=g.index);league_cap=pd.Series(False,index=g.index);favorite=pd.Series(0.,index=g.index);bucketcap=pd.Series(False,index=g.index)
            spent={};favorite_spent={};league_counts={};bucket_counts={}
            for ix,r in order.iterrows():
                day=str(r.entry.date());league=(day,r.league);band=(day,int(np.floor(r.edge/.04)))
                proposed=min(r.baseline_stake,max(0.,400-spent.get(day,0.)));same_day[ix]=proposed;spent[day]=spent.get(day,0.)+proposed
                league_cap[ix]=league_counts.get(league,0)<3;league_counts[league]=league_counts.get(league,0)+1
                bucketcap[ix]=bucket_counts.get(band,0)<2;bucket_counts[band]=bucket_counts.get(band,0)+1
                fav=bool(r.side==1 and r.price>.5)
                stake=min(r.baseline_stake,max(0.,200-favorite_spent.get(day,0.))) if fav else r.baseline_stake
                favorite[ix]=stake
                if fav:favorite_spent[day]=favorite_spent.get(day,0.)+stake
            candidates += [('daily_cap400',g.baseline_condition,same_day),('league_max3',g.baseline_condition&league_cap,None),
                ('home_favorite_cap200',g.baseline_condition,favorite),('edge_bucket_max2',g.baseline_condition&bucketcap,None)]
        elif model=='market_only':candidates=[('market_winner',pd.Series(True,index=g.index),None)]
        elif model=='meta_gate':
            for threshold in [.55,.60,.65,.70]:candidates.append((f'meta_gt_{threshold:.2f}',g.meta_confidence.gt(threshold),None))
            candidates.append(('meta60_and_edge04',g.meta_confidence.gt(.60)&g.edge.gt(.04),None))
        else:
            candidates=[('model_winner',pd.Series(True,index=g.index),None),('model_edge04',g.edge.gt(.04),None)]
        for rule,condition,size in candidates:
            z=g[condition].copy()
            for year in [2024,2025,2026]:
                amount=None if size is None else size.loc[z.index]
                m,b,d=simulate(z,year,rule,amount)
                key=dict(sport=sport,provider='polymarket_us',model=model,rule=rule,entry_hours=int(h),year=year)
                rows.append(key|m)
                if len(b):bets.append(b.assign(**key))
                days.append(d.assign(**key))
        if model=='sports_baseline':
            g['edge_bucket']=pd.cut(g.edge,[-np.inf,0,.02,.04,.06,.10,np.inf],right=False,labels=['negative','0-.02','.02-.04','.04-.06','.06-.10','.10+'])
            for universe,z in [('all_winners',g),('baseline',g[g.baseline_condition])]:
                for (year,band),part in z.groupby(['year','edge_bucket'],observed=True):
                    m,_,_=simulate(part,int(year),'edge_bucket')
                    buckets.append(dict(sport=sport,entry_hours=int(h),universe=universe,year=int(year),bucket=str(band))|m)
            contexts={'confidence':pd.cut(g.probability,[0,.55,.60,.65,.70,1],include_lowest=True),
                'price':pd.cut(g.price,[0,.5,.6,.7,.8,1],include_lowest=True),'home_away':g.side.map({0:'away',1:'home',2:'draw'}),
                'convergence':np.where(g.convergence.isna(),'unobserved',np.where(g.convergence>0,'toward','away_or_equal')),
                'market_activity':np.where(g.activity_prior_median.isna(),'no_prior_reference',np.where(g.activity>g.activity_prior_median,'high','low')),
                'rest':pd.cut(g.f_rest_days_diff,[-np.inf,-1,1,np.inf]),'xg':pd.cut(g.xg_diff,[-np.inf,-.25,.25,np.inf]),
                'data_coverage':np.where(g.feature_missing_fraction>0,'some_unavailable','complete'),
                'competition':g.league,'season_phase':g.phase.fillna('not_recorded') if 'phase' in g else 'not_recorded',
                'goalie_report':np.where(g.lineup_available.eq(1),'both_sides',np.where(g.lineup_available.eq(.5),'one_side','no_dated_report'))}
            for label,values in contexts.items():
                t=g.assign(group=np.asarray(values) if not isinstance(values,str) else values)
                for (year,group),v in t.groupby(['year','group'],observed=True):
                    conditionals.append(dict(sport=sport,entry_hours=int(h),year=int(year),dimension=label,group=str(group),games=len(v),win_rate=float(v.won.mean()),mean_p=float(v.probability.mean()),mean_q=float(v.price.mean()),mean_edge=float(v.edge.mean()),mean_y_minus_q=float((v.won-v.price).mean()),flat_unit_return=float((v.won/v.price-1).mean())))
        print('US accounts',sport,h,model,'rules',len(candidates),flush=True)
    annual=pd.DataFrame(rows);annual.to_csv(RESULT/'us_annual.csv',index=False)
    b=pd.concat(bets,ignore_index=True) if bets else pd.DataFrame();b.to_parquet(RESULT/'us_bets.parquet',index=False)
    fields=['sport','model','rule','year','game_id','start','entry','entry_hours','probability','price','edge','side','stake','won','profit','source_utc']
    if len(b):b[fields].to_csv(RESULT/'us_bets.csv',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'us_daily.parquet',index=False)
    pd.DataFrame(buckets).to_csv(RESULT/'edge_buckets.csv',index=False)
    pd.DataFrame(conditionals).to_csv(RESULT/'conditional_diagnostics.csv',index=False)
    pd.DataFrame(slopes).to_csv(RESULT/'edge_sizing_slopes.csv',index=False)
    dump(RESULT/'account_validation.json',dict(status='PASS',at_utc=stamp(),accounts=len(rows),funded_position_records=len(b),provider='polymarket_us',buy_only_model_argmax=True,source_timestamp_checks=True,cash_reconciliation=True,no_cost_assumptions=True,calendar_idle_days=True))
    print(annual[(annual.year==2026)&(annual.rule=='us_baseline')][['sport','entry_hours','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)

def market_meta_control():
    """Required attribution: does the successful meta gate add to price alone?"""
    assert not (RESULT/'meta_market_control_annual.csv').exists()
    dump(RESULT/'meta_market_control_plan.json',dict(at_utc=stamp(),reason='Attribution ablation after fixed-grid meta results: compare the same dated calibration, rows and thresholds using only logit(selected US price). No new optimized settings.',C=.02,thresholds=[.55,.60,.65,.70],horizons=HOURS,calibration=60,minimum_prior_games=200,uses_future_returns_for_fitting=False))
    f=pd.read_parquet(RESULT/'entry_dataset.parquet');out=[];rows=[];positions=[];days=[]
    for (sport,h),part in f.groupby(['sport','entry_hours']):
        k=2 if sport=='nhl' else 3
        part=part[part[['q'+str(i) for i in range(k)]].notna().all(axis=1)]
        if not len(part):continue
        g=winners(part).sort_values('entry');g['selected_logit']=logit(g.price.clip(1e-5,1-1e-5))
        for fold,test in g.groupby(g.entry.dt.strftime('%Y-%m')):
            cut=pd.Timestamp(fold,tz='UTC');prior=g[g.exit.lt(cut)].sort_values('entry')
            if len(prior)<200:continue
            cal=prior.tail(60);train=prior.iloc[:-60];train=train[train.exit.lt(cal.entry.min())]
            if len(train)<120:continue
            with threadpool_limits(limits=1):
                m=preprocessor(LogisticRegression(C=.02,max_iter=2000,random_state=37)).fit(train[['selected_logit']],train.won.astype(int))
                t=calibrate(m.predict_proba(cal[['selected_logit']]),cal.won.astype(int))
                z=test.copy();z['meta_confidence']=apply_temp(m.predict_proba(test[['selected_logit']]),t)[:,1]
            z['model']='market_only_meta';z['second_stage_training_end']=train.exit.max();z['second_stage_calibration_end']=cal.exit.max();out.append(z)
    frames=pd.concat(out,ignore_index=True);frames.to_parquet(RESULT/'meta_market_control_predictions.parquet',index=False)
    for (sport,h),g in frames.groupby(['sport','entry_hours']):
        for threshold in [.55,.60,.65,.70]:
            z=g[g.meta_confidence.gt(threshold)]
            for year in [2024,2025,2026]:
                rule=f'meta_gt_{threshold:.2f}';m,b,d=simulate(z,year,rule)
                key=dict(sport=sport,provider='polymarket_us',model='market_only_meta',rule=rule,entry_hours=int(h),year=year)
                rows.append(key|m)
                if len(b):positions.append(b.assign(**key))
                days.append(d.assign(**key))
    pd.DataFrame(rows).to_csv(RESULT/'meta_market_control_annual.csv',index=False)
    pd.concat(positions,ignore_index=True).to_parquet(RESULT/'meta_market_control_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'meta_market_control_daily.parquet',index=False)
    print(pd.DataFrame(rows)[lambda x:x.year.eq(2026)&x.rule.eq('meta_gt_0.55')][['sport','entry_hours','funded_games','win_rate_pct','return_pct','sharpe']].to_string(index=False),flush=True)

def overall_sequence():
    """Whole-cohort check requested after inspecting the short meta-model sample."""
    assert not (RESULT/'overall_sequence_annual.csv').exists()
    dump(RESULT/'overall_sequence_plan.json',dict(at_utc=stamp(),reason='User requires the overall sequence, not a favorable part. One fixed bridge: existing baseline before the meta-model has sufficient earlier observations, then meta r>.55. No parameter search.',horizons=HOURS,threshold=.55,fallback='Original NHL p>.60 and q>.50; soccer home-only p>.51',requested_start='2024-01-01',missing_years_are_not_zero_returns=True))
    f=pd.read_parquet(RESULT/'market_model_predictions.parquet');rows=[];bets=[];days=[];decisions=[]
    for (sport,h),part in f[f.model.eq('sports_baseline')].groupby(['sport','entry_hours']):
        g=winners(part)
        meta=f[f.sport.eq(sport)&f.entry_hours.eq(h)&f.model.eq('meta_gate')][['game_id','meta_confidence','second_stage_training_end','second_stage_calibration_end']]
        g=g.drop(columns=['meta_confidence','second_stage_training_end','second_stage_calibration_end'],errors='ignore').merge(meta,on='game_id',how='left',validate='one_to_one')
        g['meta_ready']=g.meta_confidence.notna()
        g['decision_source']=np.where(g.meta_ready,'meta_gate','baseline_before_meta_ready')
        g['selected']=np.where(g.meta_ready,g.meta_confidence.gt(.55)&g.probability.gt(.51),g.baseline_condition)
        decisions.append(g)
        for year in [2024,2025,2026]:
            m,b,d=simulate(g[g.selected],year,'baseline_then_meta55')
            scope=g[g.year.eq(year)]
            key=dict(sport=sport,provider='polymarket_us',model='baseline_then_meta',rule='baseline_then_meta55',entry_hours=int(h),year=year)
            rows.append(key|m|dict(quoted_games=len(scope),decisions_using_baseline=int((~scope.meta_ready).sum()),decisions_using_meta=int(scope.meta_ready.sum()),full_requested_history_covered=False))
            if len(b):bets.append(b.assign(**key))
            days.append(d.assign(**key))
    pd.DataFrame(rows).to_csv(RESULT/'overall_sequence_annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/'overall_sequence_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'overall_sequence_daily.parquet',index=False)
    pd.concat(decisions,ignore_index=True).to_parquet(RESULT/'overall_sequence_decisions.parquet',index=False)
    print(pd.DataFrame(rows)[lambda x:x.year.eq(2026)][['sport','entry_hours','quoted_games','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['prepare','fit_models','accounts','market_meta_control','overall_sequence']);globals()[p.parse_args().stage]()
