"""Official dated practice reports, distinct from finalized game rosters."""
import html,json,re
import pandas as pd
from common import ROOT_OUT,PREVIOUS,OfficialClient,read_db,dump,stamp
from collect_nhl_opening_rosters import StructuredArticle,namekey
from nhl_roster_aliases import read_source

RUN=ROOT_OUT/'pregame_report_pilot_v70'
URL='https://www.nhl.com/bruins/news/bjork-looking-to-prove-himself-on-bruins-fourth-line-320245534'
ALIAS_URL='https://www.nhl.com/flames/news/flames-acquire-daniel-vladar-325854870'


def alias_proof(blob,roster):
    parser=StructuredArticle();parser.feed(blob.decode('utf8'))
    a=[x for x in parser.items if isinstance(x,dict) and x.get('@type')=='NewsArticle'];assert len(a)==1
    a=a[0];body=re.sub(r'[#*_]','',a['articleBody'])
    name=a['headline'].removeprefix('FLAMES ACQUIRE ').title();assert name=='Daniel Vladar' and name in body
    date=re.search(r'DATE:\s*(August\s+20,\s+1997)',body);assert date
    dob=pd.Timestamp(date.group(1)).date().isoformat();assert 'BORN: Prague, Czech Republic' in body
    candidates=[(i,p) for i,p in enumerate(roster['goalies']) if p['birthDate']==dob and p['birthCity']['default']=='Prague' and namekey(p['lastName']['default'])==namekey(name.split()[-1])]
    assert len(candidates)==1;idx,p=candidates[0]
    return dict(source_name=name,native_id=str(p['id']),birth_date=dob,birth_city='Prague',native_pointer='/goalies/'+str(idx),
        rule='Official full-name announcement and unique same-surname, birth-date, birth-city goalie in native club roster. Static identity only; later team membership and performance excluded.')


def parse(blob):
    raw=blob.decode('utf8');p=StructuredArticle();p.feed(raw)
    article=[a for a in p.items if isinstance(a,dict) and a.get('@type')=='NewsArticle'];assert len(article)==1
    article=article[0]
    # The structured article concatenates lines, so retain the official HTML
    # <br> boundaries to preserve source line/pair groupings exactly.
    marker="Wednesday's Practice Lineup</strong></h3>";assert raw.count(marker)==1
    section=re.search(r'<p>(.*?)</p>',raw.split(marker,1)[1],re.S).group(1)
    text=html.unescape(re.sub(r'<[^>]+>','',re.sub(r'<br\s*/?>','\n',section)))
    rows=[];group=None;ordinal=0
    for line in text.splitlines():
        line=line.strip()
        if line in ['FORWARDS','DEFENSEMEN','GOALIES']:group=line;ordinal=0;continue
        if not line:continue
        assert group;ordinal+=1
        for index,name in enumerate(re.split(r' - |/',line),1):
            rows.append(dict(player_name_raw=name.strip(),position_group=group,source_group_number=ordinal,source_player_index=index,source_group_text=line))
    assert len(rows)==25 and len({r['player_name_raw'] for r in rows})==25
    assert pd.Series([r['position_group'] for r in rows]).value_counts().to_dict()=={'FORWARDS':14,'DEFENSEMEN':8,'GOALIES':3}
    anchors={}
    for pid,text in re.findall(r'<a[^>]+href="/player/[^"/]+-(\d+)"[^>]*>(.*?)</a>',raw,re.S):
        name=html.unescape(re.sub('<[^>]+>','',text));anchors.setdefault(namekey(name),set()).add(pid)
    available=max(pd.Timestamp(article['datePublished']),pd.Timestamp(article.get('dateModified',article['datePublished'])))
    return rows,anchors,article,available


def main():
    RUN.mkdir(exist_ok=True);client=OfficialClient(per_second=1)
    if (RUN/'pilot_source.json').exists():source=json.loads((RUN/'pilot_source.json').read_bytes())['source'];blob=read_source(source)
    else:blob,source=client.get(URL,'Dated pregame practice and availability pilot, Boston January2021','nhl_pregame_report',document=True)
    rows,anchors,article,available=parse(blob)
    roster,identity=client.get('https://api-web.nhle.com/v1/roster/BOS/20202021','Native identities for dated Boston practice report','nhl_season_roster_identity')
    alias_blob,alias_source=client.get(ALIAS_URL,'Resolve Daniel/Dan Vladar using official full name and birth identity only','nhl_player_identity_document',document=True)
    alias=alias_proof(alias_blob,roster)
    registry,teamsource=client.get('https://api.nhle.com/stats/rest/en/team','Native club identity for practice report','nhl_team_identity')
    team=[r for r in registry['data'] if r['fullName']=='Boston Bruins'];assert len(team)==1;tid=str(team[0]['id'])
    native={};names={}
    for group in ['forwards','defensemen','goalies']:
        for idx,p in enumerate(roster[group]):
            full=p['firstName']['default']+' '+p['lastName']['default'];native[str(p['id'])]=(full,'/'+group+'/'+str(idx));names.setdefault(namekey(full),[]).append(str(p['id']))
    with read_db(PREVIOUS/'expanded.sqlite') as db:g=pd.read_sql_query('SELECT game_id,official_game_id,league,start_time,prediction_time,native_team_ids_json FROM nhl_games',db)
    g['start_time']=pd.to_datetime(g.start_time,utc=True);g['prediction_time']=pd.to_datetime(g.prediction_time,utc=True)
    next_games=g[g.start_time.gt(available)&g.native_team_ids_json.map(lambda s:tid in list(map(str,json.loads(s))))].sort_values('start_time')
    game=next_games.iloc[0];assert game.start_time.date().isoformat()=='2021-01-15' and available<game.prediction_time
    result=[]
    for r in rows:
        linked=anchors.get(namekey(r['player_name_raw']),set());options=names.get(namekey(r['player_name_raw']),[])
        pid=next(iter(linked)) if len(linked)==1 else options[0] if len(options)==1 else None
        reason='native link in same official report' if len(linked)==1 else 'exact normalized name in official same-club season roster' if len(options)==1 else 'requires additional documented identity evidence'
        is_alias=pid is None and r['player_name_raw']==alias['source_name']
        if is_alias:pid=alias['native_id'];reason=alias['rule']
        full=native.get(pid,(None,None))[0] if pid else None
        if pid and not full:full=r['player_name_raw']
        result.append(dict(report_id='BOS_20210113_practice',game_id=game.game_id,official_game_id=str(game.official_game_id),sport='nhl',league='NHL',team_id=tid,team_name='Boston Bruins',
            available_at_utc=available.isoformat(),report_kind='practice_lineup',**r,official_player_id=pid,player_name=full,identity_verified=pid is not None,
            identity_method=reason,source_json=json.dumps(source,sort_keys=True),identity_source_json=json.dumps(dict(alias_source=alias_source,native_source=identity,proof=alias) if is_alias else source if len(linked)==1 else identity,sort_keys=True),identity_pointer=native.get(pid,(None,None))[1] if len(linked)!=1 else '/player/*-'+pid))
    f=pd.DataFrame(result);f.to_parquet(RUN/'practice_players.parquet',index=False);f.to_csv(RUN/'practice_players.csv',index=False)
    dump(RUN/'pilot_source.json',dict(at_utc=stamp(),source=source,article=article,identity_source=identity,team_source=teamsource,alias_source=alias_source,alias_proof=alias,
        api_insufficiency='Season roster API has no dated practice membership or projected lines. Official dated HTML retains source line boundaries missing from structured article text. Practice inclusion does not prove game participation or a finalized active roster.',
        schema_notes='source_group_number is the ordinal printed group, not an assertion of fifth competitive line. Group text preserves the slash-separated alternative names. Future lineup/results are not added.',
        pre12_forecast_utc=game.prediction_time.isoformat(),game_start_utc=game.start_time.isoformat(),publication_lead_hours=(game.start_time-available).total_seconds()/3600))
    # Raw replay verifies names and every grouping boundary, native links and
    # season-roster pointers. No inference turns an unverified name into an ID.
    expected,links,_,at=parse(read_source(source));assert at==available
    assert [(r['player_name_raw'],r['position_group'],r['source_group_number'],r['source_player_index']) for r in expected]==list(f[['player_name_raw','position_group','source_group_number','source_player_index']].itertuples(index=False,name=None))
    raw_roster=json.loads(read_source(identity))
    for r in f[f.identity_verified].itertuples():
        if r.identity_method=='native link in same official report':assert r.official_player_id in links[namekey(r.player_name_raw)]
        elif r.identity_method==alias['rule']:
            proof=alias_proof(read_source(alias_source),raw_roster);assert proof==alias and r.official_player_id==proof['native_id'] and r.player_name_raw==proof['source_name']
        else:
            group,index=r.identity_pointer.strip('/').split('/');p=raw_roster[group][int(index)]
            assert str(p['id'])==r.official_player_id and namekey(p['firstName']['default']+' '+p['lastName']['default'])==namekey(r.player_name_raw)
    report=dict(status='PASS',at_utc=stamp(),rows=len(f),verified_ids=int(f.identity_verified.sum()),unresolved=f[~f.identity_verified].player_name_raw.tolist(),unresolved_identity_pct=float(100*(~f.identity_verified).mean()),pre12_available=True,practice_not_finalized_roster=True,no_model_changed=True)
    dump(RUN/'validation.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
