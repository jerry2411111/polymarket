"""Pre12 qualification certificates from earlier official group-stage results.

Strict points bounds avoid future scores and guesses about unresolved tie-breaks.
False means not certified by this sufficient test, not guaranteed motivation.
"""
import argparse
import collections
import copy
import json
import sqlite3
from html.parser import HTMLParser
import pandas as pd
from common import ROOT_OUT,REPORTS,PROJECT,OfficialClient,dump,stamp,file_sha256
from soccer_match_phases import raw

TABLE='soccer_qualification_context'
PROOF=ROOT_OUT/'retention/uefa_qualification_validation.json'
RULES=[
 'https://www.uefa.com/uefachampionsleague/news/0283-187947650d95-5db6cf78af68-1000--group-stage-draw-details/',
 'https://www.uefa.com/uefachampionsleague/news/0290-1bae124dbd1a-4a9fc08cd25c-1000--2024-25-champions-league-teams-format-dates-draws-final/',
 'https://www.uefa.com/uefachampionsleague/news/02a8-216eb10b789e-0768c05cf31b-1000--champions-league-europa-league-and-conference-league-leag/']
CASES=[
 ('2042050','7889',21,2,'https://www.uefa.com/uefachampionsleague/news/0295-1cd4c365c94b-ac767cee74e2-1000--psv-eindhoven-vs-liverpool-facts/','top-two finish'),
 ('2039167','50051',15,1,'https://www.uefa.com/uefachampionsleague/news/0288-199de2bdafe3-ab07a4ea3641-1000--union-berlin-vs-real-madrid-facts/','seal first place'),
 ('2039171','52919',15,1,'https://www.uefa.com/uefachampionsleague/news/0288-199f29ed5b65-0b08e1a6d8b5-1000--crvena-zvezda-vs-man-city-facts/','seal top spot')]


def inputs():
    path=ROOT_OUT/'soccer_match_phase_observations.parquet'
    validation=json.loads((ROOT_OUT/'retention/soccer_match_phases_validation.json').read_bytes())
    assert validation['status']=='PASS' and validation['output_sha256']==file_sha256(path)
    f=pd.read_parquet(path);f=f[f.league.eq('UEFA Champions League')&f.match_type.eq('GROUP_STAGE')].copy()
    rows=[];metadata={}
    for r in f.itertuples(index=False):
        source=json.loads(r.source_json)['match'];m=raw(source);m=m[0] if isinstance(m,list) else m
        assert str(m['id'])==r.official_game_id and m['type']=='GROUP_STAGE'
        assert str(m['awayTeam']['id'])==r.teamA_id and str(m['homeTeam']['id'])==r.teamB_id
        group=m['group'];members=sorted(map(str,group['teams']));season=int(m['seasonYear'])
        assert str(group['competitionId'])=='1' and len(members)==len(set(members))
        old=season<=2024
        assert len(members)==(4 if old else 36)
        assert int(group['teamsQualifiedNumber'])==(2 if old else 24)
        row=r._asdict();row.update(season_year=season,group_id=str(group['id']),group_team_ids=members,
            scheduled_team_games=6 if old else 8,direct_qualification_places=2 if old else 8,
            survival_places=2 if old else 24,matchday=int(m['matchday']['sequenceNumber']))
        rows.append(row);metadata[r.official_game_id]=dict(source=source,group_pointer='/group',round_pointer='/round',
            ignored=['/score/current','/score/aggregate','/winner','/round/status','current match result'])
    f=pd.DataFrame(rows)
    for c in ['start_time','available_time']:f[c]=pd.to_datetime(f[c],utc=True,format='mixed')
    checks=[]
    for (season,group),g in f.groupby(['season_year','group_id']):
        members=g.iloc[0].group_team_ids
        assert all(z==members for z in g.group_team_ids)
        count=collections.Counter(g.teamA_id.tolist()+g.teamB_id.tolist())
        assert set(count)==set(members) and len(set(count.values()))==1
        expected=g.iloc[0].scheduled_team_games
        assert max(count.values())<=expected
        if season<=2026:assert set(count.values())=={expected},'Incomplete closed group calendar: repair before deriving status'
        else:assert len(set(g.matchday))==max(g.matchday) and set(count.values())=={max(g.matchday)}
        checks.append(dict(season_year=int(season),group_id=group,teams=len(members),observed_games=len(g),
            observed_games_each=int(next(iter(count.values()))),full_stage=bool(max(count.values())==expected)))
    return f,metadata,validation,checks


def derive(current,history,metadata):
    cut=current.start_time-pd.Timedelta(hours=12)
    past=history[history.group_id.eq(current.group_id)&history.season_year.eq(current.season_year)&history.available_time.lt(cut)]
    assert current.official_game_id not in set(past.official_game_id)
    points=collections.Counter();played=collections.Counter();gf=collections.Counter();ga=collections.Counter()
    for g in past.itertuples(index=False):
        a,b=int(g.regulation_scoreA),int(g.regulation_scoreB)
        played[g.teamA_id]+=1;played[g.teamB_id]+=1
        points[g.teamA_id]+=3 if a>b else int(a==b);points[g.teamB_id]+=3 if b>a else int(a==b)
        gf[g.teamA_id]+=a;ga[g.teamA_id]+=b;gf[g.teamB_id]+=b;ga[g.teamB_id]+=a
    assert sum(played.values())==2*len(past)
    assert sum(points.values())==3*len(past)-int(past.regulation_scoreA.eq(past.regulation_scoreB).sum())
    members=current.group_team_ids
    table={tid:dict(points=points[tid],played=played[tid],remaining=current.scheduled_team_games-played[tid]) for tid in members}
    assert all(z['remaining']>=0 for z in table.values())
    result=[]
    for side in ['A','B']:
        tid=getattr(current,'team'+side+'_id');own=table[tid];max_points=own['points']+3*own['remaining']
        others=[v for k,v in table.items() if k!=tid]
        # Equal final points may lose an unmodelled tie-break: include equality
        # in the adverse bound, and require strict superiority for elimination.
        worst=1+sum(v['points']+3*v['remaining']>=own['points'] for v in others)
        best=1+sum(v['points']>max_points for v in others)
        assert own['remaining']>=1 and own['played']<current.scheduled_team_games
        source=dict(current_group=metadata[current.official_game_id],
            past_game_ids=sorted(past.official_game_id.tolist()),
            past_source_refs={r.official_game_id:json.loads(r.source_json) for r in past.itertuples(index=False)},
            method='Only earlier validated regulation scores and availability clocks. Group membership and competition format are fixed before group play. Current/later results and final table/rank are excluded.',
            clock_limitation='Historical official result availability proxy, not a claim the API was retrieved then.')
        result.append(dict(game_id=current.game_id,official_game_id=current.official_game_id,league=current.league,
            date=current.date,prediction_time=cut.isoformat(),start_time=current.start_time.isoformat(),season_year=int(current.season_year),
            group_id=current.group_id,side=side,team_id=tid,group_teams=len(members),scheduled_team_games=int(current.scheduled_team_games),
            games_played=int(own['played']),games_remaining=int(own['remaining']),points=int(own['points']),maximum_final_points=int(max_points),
            best_rank_lower_bound=int(best),worst_rank_upper_bound=int(worst),direct_qualification_places=int(current.direct_qualification_places),
            survival_places=int(current.survival_places),direct_qualification_certified=worst<=current.direct_qualification_places,
            elimination_certified=best>current.survival_places,
            latest_history_available_utc=None if past.empty else past.available_time.max().isoformat(),
            prior_table_json=json.dumps(table,sort_keys=True),source_json=json.dumps(source,sort_keys=True)))
    return result


class Visible(HTMLParser):
    def __init__(self):super().__init__();self.parts=[];self.skip=0
    def handle_starttag(self,tag,attrs):
        if tag in ['script','style']:self.skip+=1
    def handle_endtag(self,tag):
        if tag in ['script','style'] and self.skip:self.skip-=1
    def handle_data(self,data):
        if not self.skip:self.parts.append(data)


def collect():
    f,metadata,validation,calendars=inputs();rows=[];milestone=10
    for i,current in enumerate(f.sort_values(['start_time','official_game_id']).itertuples(index=False),1):
        row=derive(current,f,metadata)
        # Perturb every result unavailable at the decision, including today's.
        poison=f.copy();future=poison.available_time.ge(current.start_time-pd.Timedelta(hours=12))
        poison.loc[future,'regulation_scoreA']=987;poison.loc[future,'regulation_scoreB']=654
        assert row==derive(current,poison,metadata)
        rows+=row
        while i*100>=milestone*len(f):
            print(json.dumps(dict(stage='qualification_context',percent=milestone,games=i,total=len(f))),flush=True);milestone+=10
    out=pd.DataFrame(rows);assert not out.duplicated(['official_game_id','side']).any()
    source_file=ROOT_OUT/(TABLE+'.parquet');out.to_parquet(source_file,index=False);out.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    client=OfficialClient(per_second=2);docs=[];examples=[]
    # Official website only for rule documentation and manual source validation;
    # all modelling results are calculated from the previously acquired API.
    for url in RULES:
        body,src=client.get(url,'Document historical and current Champions League qualification format','official_rule_documentation',document=True)
        assert body,src;docs.append(src)
    for native,team,points,bound,url,phrase in CASES:
        body,src=client.get(url,'Validate already-secured qualification against official pre-match facts','official_qualification_validation',document=True)
        assert body,src;page=Visible();page.feed(body.decode('utf8'));text=' '.join(' '.join(page.parts).split()).lower()
        assert phrase in text,(native,phrase)
        r=out[out.official_game_id.eq(native)&out.team_id.eq(team)];assert len(r)==1;r=r.iloc[0]
        assert r.points==points and r.worst_rank_upper_bound==bound and r.direct_qualification_certified
        examples.append(dict(official_game_id=native,team_id=team,points=int(r.points),worst_rank_upper_bound=int(r.worst_rank_upper_bound),
            direct_qualification_certified=True,official_statement=phrase,public_source=src,match=True))
    receipt=dict(status='PASS',at_utc=stamp(),games=len(f),team_rows=len(out),earliest_date=str(out.date.min()),latest_date=str(out.date.max()),
        future_result_poison_replays=len(f),direct_certificates=int(out.direct_qualification_certified.sum()),elimination_certificates=int(out.elimination_certified.sum()),
        calendars=calendars,source_phase_validation=validation,source_phase_sha256=file_sha256(ROOT_OUT/'soccer_match_phase_observations.parquet'),
        output_sha256=file_sha256(source_file),documentation=docs,public_examples=examples,
        limitation='Sufficient conservative bounds, not exact tie-break scenario enumeration. A zero flag means not certified; it does not mean qualification is impossible or the team must be motivated. Group elimination does not imply no Europa League or seeding incentive.')
    dump(PROOF,receipt);print(json.dumps({k:receipt[k] for k in ['status','games','team_rows','direct_certificates','elimination_certificates']}),flush=True)


def publish():
    proof=json.loads(PROOF.read_bytes());assert proof['status']=='PASS'
    path=ROOT_OUT/(TABLE+'.parquet');assert file_sha256(path)==proof['output_sha256']
    f=pd.read_parquet(path)
    definitions={
      'game_id':('Canonical group-stage match identifier','identifier'),'official_game_id':('Native UEFA match ID','identifier'),
      'league':('UEFA Champions League competition name','category'),'date':('Official game date','YYYY-MM-DD'),
      'prediction_time':('Boundary of earlier history, twelve hours before kickoff','UTC timestamp'),'start_time':('Official scheduled kickoff','UTC timestamp'),
      'season_year':('UEFA season ending year','year'),'group_id':('Official group or league-phase identifier','identifier'),
      'side':('A away or B home within this game','category'),'team_id':('Native UEFA club identifier','identifier'),
      'group_teams':('Number of clubs in the complete official group membership','teams'),
      'scheduled_team_games':('Six old-group or eight league-phase games per team','games'),
      'games_played':('Group games with official result available before prediction_time','games'),
      'games_remaining':('Scheduled team games minus already observed games, including current game','games'),
      'points':('Earlier group points: three per win and one per draw','points'),
      'maximum_final_points':('Current points plus three for each remaining group game','points'),
      'best_rank_lower_bound':('One plus other teams already strictly above this team maximum points; conservative best-position bound','rank'),
      'worst_rank_upper_bound':('One plus other teams whose maximum points reach this team current points; conservative worst-position bound','rank'),
      'direct_qualification_places':('Top two old group or top eight league phase advance directly to round16','places'),
      'survival_places':('Top two old group or top24league phase remain in Champions League','places'),
      'direct_qualification_certified':('True only if the conservative worst rank is within direct qualification places; false means not certified','boolean'),
      'elimination_certified':('True only if the conservative best rank exceeds Champions League survival places; false means not certified','boolean'),
      'latest_history_available_utc':('Latest prior result clock used; null means no prior group matches at the cutoff','UTC timestamp'),
      'prior_table_json':('Native team IDs mapped to earlier points, games and remaining games; no final standings','JSON'),
      'source_json':('Official API source hashes/paths, prior game IDs and excluded future fields','JSON')}
    assert set(definitions)==set(f)
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        f.to_sql(TABLE,db,if_exists='replace',index=False)
        for name in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+name+' WHERE [table]=?',(TABLE,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(TABLE,len(f),len(f.columns)))
        for c in f:
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(TABLE,c,*definitions[c],'Official match.uefa.com group metadata and validated earlier results; UEFA published competition format; conservative mathematical derivation.'))
            db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(TABLE,c,len(f),int(f[c].isna().sum()),100*f[c].isna().mean()))
        sql=pd.read_sql_query('SELECT * FROM '+TABLE,db)
    for c in ['direct_qualification_certified','elimination_certified']:sql[c]=sql[c].astype(bool)
    pd.testing.assert_frame_equal(sql,f,check_dtype=False)
    from publish import main
    main()
    proof['sql_parquet_equal']=True;proof['published_at_utc']=stamp();dump(PROOF,proof)
    print(json.dumps(dict(status='PASS',table=TABLE,rows=len(f),sql_equal=True)),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['collect','publish']);args=parser.parse_args();globals()[args.stage]()
