"""Retained NHL/soccer rolling models, simulations and completion checks.

Temporary fit folds live under _work and are removed after their consolidated
predictions, latest model and metrics have been successfully promoted.
"""
import argparse
import hashlib
import json
import pickle
import shutil
import sqlite3
import stat
import sys
import urllib.request
from pathlib import Path

sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
from common import PROJECT, ROOT_OUT, REPORTS, dump, stamp, file_sha256

MODELS = {'nhl': ('identity_v28', ['granular_regulation_ot', 'granular_logistic_strong']),
          'soccer': ('uefa_v14', ['context_league'])}
FINAL = ROOT_OUT / 'retained_models'
SIM = ROOT_OUT / 'simulation_results'
EVIDENCE = ROOT_OUT / 'retention'
sha = file_sha256


def predictions(sport, stage):
    p = pd.read_parquet(FINAL / sport / (stage + '_predictions.parquet'))
    if sport == 'nhl':
        first = p[p.variant.eq('granular_regulation_ot')].copy()
        second = p[p.variant.eq('granular_logistic_strong')][['game_id','p0','p1']]
        p = first.merge(second.rename(columns={'p0':'second_p0','p1':'second_p1'}), on='game_id', validate='one_to_one')
    return p


def simulate():
    from backtest import quote_inputs, attach, select, simulate as account
    folder = SIM / 'current'; folder.mkdir(exist_ok=True)
    quotes = quote_inputs(folder / 'quote_quality.json', revision='closest_v62')
    annual = []; bets = []; daily = []
    for sport in MODELS:
        for stage, years in [('development',[2024,2025]),('evaluation',[2026])]:
            joined, audit = attach(predictions(sport,stage), quotes)
            dump(folder / (sport+'_'+stage+'_matching.json'), audit)
            for provider, group in joined.groupby('provider'):
                chosen = select(group, 'expected_profit' if sport=='nhl' else 'edge_any')
                if sport=='nhl':
                    second = np.array([r['second_p'+str(int(r['quote_class']))] for r in chosen.to_dict('records')])
                    chosen = chosen[second/chosen.entry_price.to_numpy()>=1.10].copy()
                else:
                    chosen['sizing_probability'] = chosen.probability-.05
                for recipe in (['fixed'] if sport=='nhl' else ['fixed','margin_quarter_kelly']):
                    for year in years:
                        summary, trades, curve = account(chosen,year,sizing=recipe)
                        meta = dict(sport=sport,provider=provider,recipe=recipe,year=year)
                        annual.append(meta|summary)
                        if len(trades): bets.append(trades.assign(**meta))
                        daily.append(curve.assign(**meta))
    a=pd.DataFrame(annual); a.to_csv(folder/'annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(folder/'bets.parquet',index=False)
    pd.concat(daily,ignore_index=True).to_parquet(folder/'daily.parquet',index=False)
    dump(folder/'settings.json',dict(at_utc=stamp(),price_revision='closest_v62',
        entry='pre12, latest prior source and availability timestamps, age<=24h',
        fixed_stake='1% NAV per bet, 20% total open-cost cap, $10000 annual reset',
        nhl='Both retained models require probability/price>=1.10',
        soccer='Probability-price>=0.05; fixed baseline plus retained quarter-Kelly sizing candidate',
        costs='No cost/spread assumptions. Historical quotes are not established executable asks.',
        evaluation='2026 repeatedly researched retrospective results'))
    print(a[['sport','provider','recipe','year','bets','return_pct','sharpe']].to_string(index=False),flush=True)


def _train(sport):
    import models
    work=ROOT_OUT/'_work'/('rolling_'+sport)
    if work.exists():
        raise RuntimeError('Unfinished run exists; inspect it before resuming or removing it: '+str(work))
    work.mkdir(parents=True)
    shutil.copy2(FINAL/sport/(sport+'_features.parquet'),work/(sport+'_features.parquet'))
    names=MODELS[sport][1]
    dump(work/(sport+'_selection.json'),dict(selected_candidates=names))
    models.OUT=work
    ready=work/'ready';ready.mkdir()
    shutil.copy2(work/(sport+'_features.parquet'),ready/(sport+'_features.parquet'))
    for stage in ['development','evaluation']:
        p=models.run(sport,stage,names)
        assert p.train_label_max.lt(p.prediction_time).all()
        p.to_parquet(ready/(stage+'_predictions.parquet'),index=False)
    manifest=json.loads((FINAL/'manifest.json').read_text())
    for name in names:
        source=work/'model_runs'/sport/'evaluation'/(name+'.pkl')
        target=ready/(name+'.pkl')
        shutil.copy2(source,target)
        for record in manifest['models']:
            if record['sport']==sport and record['name']==name:
                record['sha256']=sha(target)
                record['feature_sha256']=sha(ready/(sport+'_features.parquet'))
                check_package(ready,record)
    # Promote only after all completed fits pass probability/temporal replay.
    for path in ready.iterdir():
        destination=FINAL/sport/path.name
        temporary=destination.with_suffix(destination.suffix+'.tmp')
        shutil.copy2(path,temporary);temporary.replace(destination)
    manifest['updated_utc']=stamp();dump(FINAL/'manifest.json',manifest)
    validate(check_app=False)
    discard_work(work)


def discard_work(work):
    # Preflight every path before deletion. Do not traverse Windows junctions
    # or other reparse points, including the requested directory itself.
    root=(ROOT_OUT/'_work').resolve(strict=True)
    resolved=work.resolve(strict=True)
    assert resolved!=root and resolved.is_relative_to(root)
    paths=[];pending=[work]
    while pending:
        path=pending.pop()
        info=path.lstat()
        assert not path.is_symlink() and not (getattr(info,'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT)
        assert path.resolve(strict=True).is_relative_to(resolved)
        paths.append(path)
        if path.is_dir():pending.extend(path.iterdir())
    for path in sorted(paths,key=lambda p:len(p.parts),reverse=True):
        if path.is_file():path.unlink()
        elif path.is_dir():path.rmdir()


def cleanup():
    """Remove reviewed disposable outputs, never source data or active work.

    Only historical output directories listed here may lose exact duplicates.
    Their collection code reads the canonical copies at ROOT_OUT. A different
    hash is retained for review, not assumed to be an obsolete version.
    """
    root = ROOT_OUT.resolve(strict=True)
    reviewed = ('ligue_counts_v37', 'participant_recovery_v29',
                'player_pool_diagnosis_v53', 'soccer_identity_v55',
                'sparse_player_v26', 'travel_context_v40')
    candidates = []

    def safe(path):
        assert path.resolve(strict=True).is_relative_to(root)
        assert path.resolve(strict=True) != root
        for node in (path, *path.parents):
            info = node.lstat()
            assert not node.is_symlink()
            assert not (getattr(info, 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT)
            if node == root:
                break

    for folder in reviewed:
        directory = root / folder
        if not directory.exists():
            continue
        safe(directory)
        for path in directory.iterdir():
            canonical = root / path.name
            if not path.is_file() or not canonical.is_file():
                continue
            safe(path); safe(canonical)
            if path.stat().st_size == canonical.stat().st_size and sha(path) == sha(canonical):
                candidates.append((path, 'Identical to canonical ' + path.name))

    # Keeper normalization stages a table before source replay. Once a
    # validated publication matches, consumers can use the canonical copy.
    staged = root / 'soccer_keeper_v81/keeper_observations.parquet'
    canonical = root / 'soccer_goalkeeper_game_observations.parquet'
    check = root / 'soccer_keeper_v81/keeper_validation.json'
    if staged.exists() and canonical.exists() and check.exists():
        safe(staged); safe(canonical); safe(check)
        validation = json.loads(check.read_bytes())
        digest = sha(staged)
        if validation.get('status') == 'PASS' and validation.get('source_sha256') == digest and sha(canonical) == digest:
            candidates.append((staged, 'Validated publication matches canonical keeper table; staged duplicate removed'))

    rejected = root / 'travel_context_v40/rejected_runner_attempt'
    directories = []
    if rejected.exists():
        safe(rejected)
        # Preserve the reason this run was rejected; its forecast cache is not
        # valid simulation evidence and must not be mistaken for a final model.
        exclusion = rejected / 'exclusion.json'
        if exclusion.exists():
            safe(exclusion)
            decision_path = SIM / 'experiment_decisions.json'
            decisions = json.loads(decision_path.read_text())
            decisions['travel_context_v40/rejected_runner_attempt/exclusion.json'] = json.loads(exclusion.read_text())
            dump(decision_path, decisions)
        pending = [rejected]
        while pending:
            path = pending.pop(); safe(path)
            if path.is_dir():
                directories.append(path); pending.extend(path.iterdir())
            else:
                candidates.append((path, 'Rejected runner cache; exclusion retained in experiment_decisions.json'))

    records = [dict(path=str(path.relative_to(root)), bytes=path.stat().st_size,
                    sha256=sha(path), reason=reason) for path, reason in candidates]
    # All deletion targets have been checked before the first unlink.
    for path, _ in candidates:
        safe(path); path.unlink()
    for path in sorted(directories, key=lambda p: len(p.parts), reverse=True):
        safe(path); path.rmdir()
    receipt_path = EVIDENCE / 'maintenance_cleanup.json'
    prior = json.loads(receipt_path.read_text()) if receipt_path.exists() else {}
    previous = prior.get('removed_files', [])
    result = dict(at_utc=stamp(), status='PASS', removed_this_run=len(records),
                  bytes_this_run=sum(r['bytes'] for r in records),
                  removed_files=previous + records,
                  total_removed_files=len(previous) + len(records),
                  total_removed_bytes=sum(r['bytes'] for r in previous + records),
                  active_work_preserved=True, canonical_data_preserved=True,
                  raw_sources_preserved=True)
    dump(receipt_path, result)
    print(json.dumps({k: v for k, v in result.items() if k != 'removed_files'}), flush=True)
    return result


def train(sport):
    work=ROOT_OUT/'_work'/('rolling_'+sport)
    if work.exists():
        raise RuntimeError('A prior unfinished run needs inspection: '+str(work))
    try:
        _train(sport)
        simulate()
    except Exception as exc:
        record=SIM/'failed_runs.json'
        failures=json.loads(record.read_text()) if record.exists() else []
        failures.append(dict(at_utc=stamp(),sport=sport,error=repr(exc)))
        dump(record,failures)
        raise
    finally:
        if work.exists():discard_work(work)


def check_package(directory,record):
    import models
    file=directory/(record['name']+'.pkl');assert sha(file)==record['sha256']
    bundle=pickle.loads(file.read_bytes())
    feature_path=directory/(record['sport']+'_features.parquet')
    frame=pd.read_parquet(feature_path)
    assert sha(feature_path)==record['feature_sha256']
    frame=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1)
    p=pd.read_parquet(directory/'evaluation_predictions.parquet')
    sample=p[p.variant.eq(record['name']) & p.fold.eq(bundle['boundary'].strftime('%Y-%m'))]
    sample=sample.head(12);assert len(sample)>0
    x=frame.set_index('game_id').loc[sample.game_id,bundle['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
    actual=models.apply_calibration(bundle['model'].predict_proba(x),bundle['calibrator'])
    k=3 if record['sport']=='soccer' else 2
    assert np.allclose(actual,sample[[f'p{i}' for i in range(k)]],rtol=0,atol=1e-12)
    assert p.train_label_max.lt(p.prediction_time).all()
    return dict(sport=record['sport'],model=record['name'],forecast_replays=len(sample))


def validate(check_app=True):
    checks=[check_package(FINAL/record['sport'],record)
            for record in json.loads((FINAL/'manifest.json').read_text())['models']]
    app={};health=None
    if check_app:
        app=json.loads((EVIDENCE/'app_preservation_baseline.json').read_text())
        assert all(sha(PROJECT/'sports_app'/p)==h for p,h in app.items())
        try:
            with urllib.request.urlopen('http://127.0.0.1:8766/api/health',timeout=10) as response:health=response.status
        except OSError as exc:health=str(exc)
    with sqlite3.connect('file:'+str(ROOT_OUT/'granular.sqlite')+'?mode=ro',uri=True) as db:
        count=db.execute('SELECT COUNT(*) FROM table_catalog').fetchone()[0]
    result=dict(at_utc=stamp(),status='PASS',model_checks=checks,final_sql_tables=count,
                protected_app_files=len(app),app_health=health)
    dump(EVIDENCE/'final_validation.json',result);print(json.dumps(result),flush=True)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['validate','simulate','train','catalog','cleanup'])
    parser.add_argument('--sport',choices=list(MODELS))
    args=parser.parse_args()
    if args.action=='validate':validate()
    elif args.action=='simulate':simulate()
    elif args.action=='catalog':
        from publish import main
        main()
    elif args.action=='train':
        if not args.sport:parser.error('--sport is required for train')
        train(args.sport)
    # Every completed publication or simulation receives the same cleanup.
    if args.action != 'validate':cleanup()
