"""User-requested NHL 52% probability floor; no fitted probability is altered.

Keep rolling forecasts, provider prices, expected-profit checks and account
rules fixed. Report realized win frequency separately from predicted chance.
"""
import json
import math
import numpy as np
import pandas as pd
from scipy.stats import norm
from backtest import quote_inputs,attach,select,simulate
from cash_validation import validate_cash
from common import ROOT_OUT,dump,stamp,file_sha256
from final_pipeline import cleanup

RESULT=ROOT_OUT/'simulation_results/nhl_probability_floor52'
FLOOR=.52


def uncertainty(bets):
    n=len(bets)
    if not n:return dict(bets=0)
    wins=int(bets.won.sum());p=wins/n;z=norm.ppf(.975)
    middle=(p+z*z/(2*n))/(1+z*z/n)
    radius=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
    # Cluster whole entry weeks; avoid treating simultaneous games as wholly
    # independent profit observations. This is not a multiple-testing correction.
    at=pd.to_datetime(bets.decision_time,utc=True)
    weeks=(at.dt.normalize()-pd.to_timedelta(at.dt.dayofweek,unit='D')).dt.strftime('%Y-%m-%d')
    g=bets.assign(week=weeks).groupby('week').agg(n=('won','size'),wins=('won','sum'),unit_profit=('unit_return','sum'))
    rng=np.random.default_rng(731);indices=rng.integers(0,len(g),size=(5000,len(g)))
    size=g.n.to_numpy()[indices].sum(axis=1)
    wr=g.wins.to_numpy()[indices].sum(axis=1)/size
    profit=g.unit_profit.to_numpy()[indices].sum(axis=1)/size
    return dict(bets=n,wins=wins,mean_model_probability=float(bets.probability.mean()),
        mean_purchase_price=float(bets.price.mean()),minimum_model_probability=float(bets.probability.min()),
        realized_win_rate=p,winrate_wilson95_low=float(middle-radius),winrate_wilson95_high=float(middle+radius),
        entry_week_clusters=len(g),winrate_week_bootstrap95_low=float(np.quantile(wr,.025)),
        winrate_week_bootstrap95_high=float(np.quantile(wr,.975)),
        average_unit_return=float(bets.unit_return.mean()),unit_return_week_bootstrap95_low=float(np.quantile(profit,.025)),
        unit_return_week_bootstrap95_high=float(np.quantile(profit,.975)),
        actual_winrate_at_least52=bool(p>=FLOOR),winrate_lower_week_bound_above52=bool(np.quantile(wr,.025)>FLOOR),
        multiple_testing_adjusted=False)


def main():
    assert not (RESULT/'validation.json').exists(),'Preserve completed user-requested comparison'
    RESULT.mkdir(exist_ok=True)
    files=[ROOT_OUT/'retained_models/nhl'/(s+'_predictions.parquet') for s in ['development','evaluation']]
    plan=dict(at_utc=stamp(),user_probability_floor=FLOOR,years=[2024,2025,2026],
        change='Require retained primary-model probability>=.52 after the unchanged two-model expected-profit checks. No probability clamping, model retraining or threshold sweep.',
        rules='Both primary and secondary probability/price>=1.10; pre12 closest prior quotes, maximum24h age;1%NAV perbet;20%total open-cost cap;hold to official result;no costs.',
        target='Report actual win rate as well as model probability; neither a forecast floor nor an observed sample win rate guarantees a true52%success rate.',
        uncertainty='Wilson win intervals and5000entry-week cluster bootstrap intervals for win frequency and average unit return; no correction for repeated historical research.',
        history='Existing monthly expanding fits from2021; forecasts2024onward; all training/calibration labels earlier than prediction.',
        retrospective='2026 repeatedly inspected; this is a fixed user-requested diagnostic, not an independent holdout.',
        sources={p.name:file_sha256(p) for p in files},app_changed=False,adopted=False)
    dump(RESULT/'plan.json',plan)
    p=pd.concat([pd.read_parquet(path) for path in files],ignore_index=True)
    assert not p.duplicated(['game_id','variant']).any()
    assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
    a=p[p.variant.eq('granular_regulation_ot')].copy()
    b=p[p.variant.eq('granular_logistic_strong')][['game_id','p0','p1']].rename(columns={'p0':'second_p0','p1':'second_p1'})
    a=a.merge(b,on='game_id',validate='one_to_one')
    q=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62')
    joined,audit=attach(a,q);dump(RESULT/'matching.json',audit)
    summaries=[];trades=[];curves=[]
    for provider,g in joined.groupby('provider'):
        eligible=select(g,'expected_profit')
        second=np.where(eligible.quote_class.eq(0),eligible.second_p0,eligible.second_p1)
        eligible=eligible[second/eligible.entry_price>=1.10].copy()
        for rule in ['retained','probability_at_least52']:
            chosen=eligible if rule=='retained' else eligible[eligible.probability.ge(FLOOR)]
            if rule!='retained':assert chosen.quote_class.eq(chosen.pick).all()
            for year in [2024,2025,2026]:
                summary,t,c=simulate(chosen,year)
                meta=dict(sport='nhl',provider=provider,variant=rule,recipe='fixed',year=year)
                summaries.append(meta|summary)
                if len(t):trades.append(t.assign(**meta))
                curves.append(c.assign(**meta))
    annual=pd.DataFrame(summaries);bets=pd.concat(trades,ignore_index=True);daily=pd.concat(curves,ignore_index=True)
    checked=validate_cash(bets,daily)
    retained=pd.read_csv(ROOT_OUT/'simulation_results/current/annual.csv')
    for row in annual[annual.variant.eq('retained')].itertuples():
        ref=retained[retained.sport.eq('nhl')&retained.provider.eq(row.provider)&retained.year.eq(row.year)].iloc[0]
        for col in ['bets','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
            assert np.isclose(getattr(row,col),ref[col],rtol=0,atol=1e-10,equal_nan=True)
    # Independent threshold replay from the original funded baseline. The cap
    # is not binding in this cohort, so outcomes retained must match exactly.
    baseline=bets[bets.variant.eq('retained')]
    expected=set(map(tuple,baseline.loc[baseline.probability.ge(FLOOR),['provider','year','game_id','class_index']].to_numpy()))
    actual=set(map(tuple,bets.loc[bets.variant.eq('probability_at_least52'),['provider','year','game_id','class_index']].to_numpy()))
    assert expected==actual
    assert bets.loc[bets.variant.eq('probability_at_least52'),'probability'].ge(FLOOR).all()
    diagnostic=[]
    for keys,g in bets.groupby(['provider','variant','year']):
        diagnostic.append(dict(zip(['provider','variant','year'],keys))|uncertainty(g))
    intervals=pd.DataFrame(diagnostic)
    annual.to_csv(RESULT/'annual.csv',index=False);intervals.to_csv(RESULT/'uncertainty.csv',index=False)
    bets.to_parquet(RESULT/'bets.parquet',index=False);daily.to_parquet(RESULT/'daily.parquet',index=False)
    validation=dict(at_utc=stamp(),status='PASS',cash_days=checked,baseline_reproduced=True,
        independent_threshold_replay_bets=len(actual),forecast_files_unchanged=all(file_sha256(path)==plan['sources'][path.name] for path in files),
        probabilities_not_modified=True,adopted=False,target_achieved=False,
        note='A forecast floor is an eligibility change, not proof that true or realized win frequency exceeds52%.')
    dump(RESULT/'validation.json',validation)
    root=ROOT_OUT/'simulation_results';path=root/'experiment_results.csv';ledger=pd.read_csv(path,low_memory=False)
    key='nhl_probability_floor52/annual.csv';ledger=pd.concat([ledger[~ledger.source_result_file.eq(key)],annual.assign(source_result_file=key)],ignore_index=True);ledger.to_csv(path,index=False)
    path=root/'experiment_decisions.json';decisions=json.loads(path.read_bytes());decisions['nhl_probability_floor52']=dict(plan=plan,decision=validation);dump(path,decisions)
    print(annual.to_string(index=False),flush=True)
    print(intervals[intervals.year.eq(2026)].to_string(index=False),flush=True)
    print(json.dumps(validation),flush=True);cleanup()


if __name__=='__main__':main()
