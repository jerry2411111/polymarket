"""Independent raw replay, causal quote selection and account reconciliation."""
import argparse,json,sqlite3,hashlib,stat
import numpy as np
import pandas as pd
from common import PROJECT,ROOT_OUT,dump,stamp,file_sha256
from us_market_data import RESULT

def raw():
    q=pd.read_parquet(RESULT/'us_price_points.parquet');total=0
    with sqlite3.connect(RESULT/'acquisition.sqlite') as c:
        c.row_factory=sqlite3.Row;sources={r['request_number']:dict(r) for r in c.execute('SELECT * FROM request_audit')}
    for rid,part in q.groupby('request_number'):
        source=sources[rid];assert source['url'].startswith('https://gateway.polymarket.us/v1/price-history?')
        blob=(PROJECT/source['raw_file']).read_bytes();assert hashlib.sha256(blob).hexdigest()==source['sha256']
        history=json.loads(blob)['history'];ix=part.raw_pointer.str.rsplit('/',n=1).str[-1].astype(int).to_numpy()
        ts=np.array([int(x['timestamp']) for x in history],dtype=np.int64)
        assert np.array_equal(pd.to_datetime(part.timestamp,utc=True).dt.as_unit('s').astype('int64'),ts[ix])
        for field,g in part.groupby('raw_field'):
            pos=g.raw_pointer.str.rsplit('/',n=1).str[-1].astype(int).to_numpy()
            expected=np.array([float(x[field]) for x in history])
            assert np.array_equal(g.price.to_numpy(),expected[pos])
        total+=len(part)
    dump(RESULT/'raw_validation.json',dict(status='PASS',at_utc=stamp(),exact_price_and_timestamp_replays=total,source_requests=q.request_number.nunique(),provider='polymarket_us'))
    print('Raw response replay PASS',total,flush=True)

def final():
    entries=pd.read_parquet(RESULT/'entry_dataset.parquet');q=pd.read_parquet(RESULT/'us_price_points.parquet')
    q['created']=pd.to_datetime(q.market_created_at,utc=True);q=q[q.created.notna()&q.created.le(q.timestamp)]
    grouped={k:g.drop_duplicates('timestamp').sort_values('timestamp') for k,g in q.groupby(['game_id','side'])}
    cells=0
    for r in entries.to_dict('records'):
        assert r['feature_time']<=r['entry']<r['start']
        for side in range(2 if r['sport']=='nhl' else 3):
            hist=grouped.get((r['game_id'],side),pd.DataFrame())
            allowed=hist[hist.timestamp.ge(r['start']-pd.Timedelta(hours=12))&hist.timestamp.le(r['entry'])] if len(hist) else hist
            price=r['q'+str(side)]
            if not len(allowed):assert pd.isna(price)
            else:
                last=allowed.iloc[-1];assert price==last.price and pd.Timestamp(r['quote_time'+str(side)])==last.timestamp
                cells+=1
    f=pd.concat([pd.read_parquet(RESULT/'market_model_predictions.parquet'),pd.read_parquet(RESULT/'meta_market_control_predictions.parquet')],ignore_index=True)
    for field in ['second_stage_training_end','second_stage_calibration_end']:
        known=f[field].notna();assert pd.to_datetime(f.loc[known,field],utc=True).lt(f.loc[known,'entry']).all()
    prefixes=['us','meta_market_control','overall_sequence']
    b=pd.concat([pd.read_parquet(RESULT/(p+'_bets.parquet')) for p in prefixes],ignore_index=True)
    daily=pd.concat([pd.read_parquet(RESULT/(p+'_daily.parquet')) for p in prefixes],ignore_index=True)
    summary=pd.concat([pd.read_csv(RESULT/(p+'_annual.csv')) for p in prefixes],ignore_index=True)
    keys=['sport','model','rule','entry_hours','year'];indexed=summary.set_index(keys);checked=0
    assert not summary.duplicated(keys).any()
    for key,g in daily.groupby(keys):
        row=indexed.loc[key];g=g.sort_values('date');previous=g.equity.shift(1,fill_value=2000.)
        returns=g.equity/previous-1;sd=returns.std(ddof=1);s=np.sqrt(365.25)*returns.mean()/sd if sd>0 else np.nan
        assert np.isclose(s,row.sharpe,equal_nan=True,atol=1e-10)
        if row.get('performance_observed',True):
            assert np.isclose(100*(g.equity.iloc[-1]/2000-1),row.return_pct,atol=1e-9)
        else:
            assert pd.isna(row.return_pct) and row.funded_games==0 and g.equity.eq(2000).all()
        assert g.date.nunique()==int(row.calendar_days)
        checked+=1
    for key,g in b.groupby(keys):
        row=indexed.loc[key];end=pd.Timestamp(f'{int(key[-1])+1}-01-01',tz='UTC')
        end=min(end,pd.Timestamp('2026-09-30T00:00:00Z'));settled=g[g.exit.lt(end)]
        assert np.isclose(2000+settled.profit.sum(),row.final_equity,atol=1e-7)
        assert len(g)==row.funded_games
        assert np.allclose(g.profit,g.stake*(g.won/g.price-1),atol=1e-10)
    assert pd.to_datetime(b.source_utc,utc=True).le(b.entry).all()
    assert pd.to_datetime(b.source_utc,utc=True).ge(b.start-pd.Timedelta(hours=12)).all()
    for sport,g in b.groupby('sport'):
        fields=['p0','p1']+(['p2'] if sport=='soccer' else [])
        assert np.array_equal(g.side.to_numpy(),g[fields].to_numpy().argmax(axis=1))
    sequence=pd.read_parquet(RESULT/'overall_sequence_decisions.parquet')
    expected=np.where(sequence.meta_ready,sequence.meta_confidence.gt(.55)&sequence.probability.gt(.51),sequence.baseline_condition)
    assert np.array_equal(sequence.selected.to_numpy(),expected)
    for (sport,h),g in sequence.groupby(['sport','entry_hours']):
        base=f[f.sport.eq(sport)&f.entry_hours.eq(h)&f.model.eq('sports_baseline')]
        cols=['q0','q1']+(['q2'] if sport=='soccer' else [])
        selected=base[cols].to_numpy()[np.arange(len(base)),base[['p0','p1']+(['p2'] if sport=='soccer' else [])].to_numpy().argmax(axis=1)]
        assert set(g.game_id)==set(base.loc[pd.notna(selected),'game_id'])
    protected=json.loads((RESULT/'protocol.json').read_text())['protected_sha256']
    for name,digest in protected.items():assert file_sha256(PROJECT/name)==digest,name
    report=dict(status='PASS',at_utc=stamp(),latest_prior_quote_cells_checked=cells,all_entry_windows_checked=len(entries),accounts_reconciled=checked,protected_app_and_baseline_files=len(protected),future_quote_substitution=False,precreation_quotes_used=False)
    dump(RESULT/'final_validation.json',report);print(json.dumps(report),flush=True)

def retain():
    """Publish retention receipts only after research evidence has passed."""
    checks={name:json.loads((RESULT/(name+'_validation.json')).read_text()) for name in ['raw','baseline','final']}
    assert all(v['status']=='PASS' for v in checks.values())
    assert (RESULT/'research_report.html').exists() and (RESULT/'catalog.csv').exists()
    removed=[];root=ROOT_OUT.resolve(strict=True)
    for path in [RESULT/'dixon_coles_latest.pkl',ROOT_OUT/'_work/us_discovery.log']:
        if not path.exists():continue
        resolved=path.resolve(strict=True);assert resolved.is_relative_to(root) and resolved!=root
        for node in [path,*path.parents]:
            info=node.lstat()
            assert not node.is_symlink() and not (getattr(info,'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT)
            if node==ROOT_OUT:break
        assert path.is_file()
        removed.append(dict(path=str(path.relative_to(ROOT_OUT)),sha256=file_sha256(path),bytes=path.stat().st_size))
        path.unlink()
    receipt=ROOT_OUT/'retention/retained_artifacts.json';manifest=json.loads(receipt.read_text())
    scripts=PROJECT/'data collecting/nhl_soccer_iteration'
    for path in scripts.glob('us_*.py'):manifest['scripts'][path.name]=file_sha256(path)
    manifest['retained_scripts']=len(manifest['scripts']);manifest['updated_utc']=stamp()
    manifest['latest_us_research']=dict(at_utc=stamp(),folder=str(RESULT.relative_to(ROOT_OUT)),validation=checks['final'],overall_target_achieved=False,removed_candidate_artifacts=removed,report_sha256=file_sha256(RESULT/'research_report.md'))
    dump(receipt,manifest)
    continuation=ROOT_OUT/'research_continuation.json';state=json.loads(continuation.read_text())
    state.update(at_utc=stamp(),goal_achieved=False,current_job=None,last_action='Completed fixed US-only NHL/soccer experiments, raw replay, causal quote checks and complete-sequence comparison. Soccer full available sequence: +21.20%, Sharpe 0.98 at one-hour entry; shorter meta segment is not overall success. NBA/MLB app unchanged.')
    state['latest_us_research']=dict(result=str(RESULT.relative_to(ROOT_OUT)),report='research_report.html',target='Overall Sharpe >3 and return >20%',target_achieved=False,unavailable='Eligible primary US price coverage for 2024/25 not established',next_review='Inspect early-period soccer probability calibration versus US market control; retain losses and all coverage. No new strategy is deployed, and no background research job is running.')
    dump(continuation,state)
    dump(RESULT/'retention_receipt.json',dict(at_utc=stamp(),status='PASS',removed=removed,raw_evidence_preserved=True,baseline_preserved=True,overall_target_achieved=False))
    print('Retention published; temporary artifacts removed:',len(removed),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['raw','final','retain']);globals()[p.parse_args().stage]()
