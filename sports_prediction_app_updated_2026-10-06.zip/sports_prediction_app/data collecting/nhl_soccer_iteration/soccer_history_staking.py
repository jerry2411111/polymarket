"""Inspect new club-history forecasts and transfer existing simple stake rules.

2025 selects the rule. Evaluate only that choice in2026; preserve the already
known edge-sized baseline. No new probability or price threshold is searched.
"""
import json
import numpy as np
import pandas as pd
from common import ROOT_OUT,dump,stamp,file_sha256
from final_pipeline import cleanup
import test_confidence_dollars as engine

SOURCE=ROOT_OUT/'simulation_results/feature_revisions/soccer_additional_club_history'
OUT=ROOT_OUT/'simulation_results/soccer_history_staking'
RULES={'edge_dollars':'edge_dollars_cash_only','fixed20':'flat20_cash_only','fixed40shares':'flat40shares_cash_only'}


def main():
    assert not (OUT/'validation.json').exists();OUT.mkdir(exist_ok=True)
    source=SOURCE/'bets.parquet';f=pd.read_parquet(source);f=f[f.variant.eq('candidate')].copy()
    previous=pd.read_csv(SOURCE/'annual.csv');previous=previous[previous.variant.eq('candidate')]
    assert previous.unfunded_games.eq(0).all() and not f.duplicated(['provider','game_id','year']).any()
    plan=dict(at_utc=stamp(),hypothesis='Additional club observations improve winner probability scores, but edge-sized stakes still produce large drawdown. Separate outcome selection from uncertain edge magnitude with existing fixed-cost/fixed-payout rules.',
        source_sha256=file_sha256(source),initial_cash=2000,models_unchanged=True,entry_and_outcomes_unchanged=True,
        rules=dict(edge_dollars='5*100*max(p-price,0)',fixed20='20dollars per bet',fixed40shares='40*price dollars per bet'),
        selection='2025:choose highest Sharpe among alternatives with positive return, higher Sharpe AND lower drawdown than edge_dollars. Only chosen alternative evaluated2026. Keep unchanged baseline for comparison.',
        no_threshold_search=True,no_cost_assumptions=True,providers_separate=True,app_changed=False,
        evaluation='2026retrospective, not untouched; predictions still rolling and trained only on earlier results.')
    dump(OUT/'experiment_plan.json',plan)
    rows=[];bets=[];days=[];checks=[];choices={};diagnosis=[]
    for (provider,year),g in f.groupby(['provider','year']):
        if year<2025:continue
        for name,part in [('below50',g[g.probability.lt(.5)]),('50to60',g[g.probability.ge(.5)&g.probability.lt(.6)]),('60plus',g[g.probability.ge(.6)])]:
            diagnosis.append(dict(provider=provider,year=int(year),probability_group=name,bets=len(part),
                average_probability=float(part.probability.mean()),win_rate=float(part.won.mean()),
                average_price=float(part.price.mean()),total_staked=float(part.stake.sum()),
                gross_loss=float(-part.profit.clip(upper=0).sum()),gross_profit=float(part.profit.clip(lower=0).sum()),
                net_profit=float(part.profit.sum()),unsettled_at_end=int(part.unsettled_at_end.sum())))
    pd.DataFrame(diagnosis).to_csv(OUT/'probability_loss_groups.csv',index=False)
    for year in [2025,2026]:
        for provider,g in f.groupby('provider'):
            rules=list(RULES) if year==2025 else list(dict.fromkeys(['edge_dollars']+([choices[provider]] if choices[provider] else [])))
            for rule in rules:
                m,b,l,d=engine.simulate(g,year,'all_selected_outcomes',RULES[rule],5.,2000.)
                key=dict(sport='soccer',provider=provider,year=year,rule=rule)
                rows.append(key|m);bets.append(b.assign(**key));days.append(d.assign(**key))
                checks.append(key|engine.validate(b,l,d,RULES[rule],5.,2000.))
                if rule=='edge_dollars':
                    prior=g[g.year.eq(year)].sort_values('game_id');replay=b.sort_values('game_id')
                    assert list(prior.game_id)==list(replay.game_id)
                    assert np.allclose(prior[['stake','profit']],replay[['stake','profit']],atol=1e-8,rtol=0)
        if year==2025:
            a=pd.DataFrame(rows)
            for provider,h in a.groupby('provider'):
                baseline=h[h.rule.eq('edge_dollars')].iloc[0]
                good=h[h.rule.ne('edge_dollars')&h.return_pct.gt(0)&h.sharpe.gt(baseline.sharpe)&h.max_drawdown_pct.lt(baseline.max_drawdown_pct)].sort_values('sharpe',ascending=False)
                choices[provider]=None if good.empty else str(good.iloc[0].rule)
            dump(OUT/'selection.json',dict(at_utc=stamp(),choices=choices,selection_year=2025,adopted=False))
    a=pd.DataFrame(rows);a.to_csv(OUT/'annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(OUT/'bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(OUT/'daily.parquet',index=False)
    dump(OUT/'validation.json',dict(status='PASS',at_utc=stamp(),cash_checks=checks,baseline_reproduced=True,
        only_preselected_rule_evaluated2026=True,source_unchanged=file_sha256(source)==plan['source_sha256'],app_changed=False,adopted=False))
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);label=OUT.name+'/annual.csv'
    pd.concat([old[old.source_result_file.ne(label)],a.assign(source_result_file=label)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[OUT.name]=dict(plan=plan,choices=choices,adopted=False);dump(path,old)
    cleanup();print(a[['provider','year','rule','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].round(4).to_string(index=False),flush=True)
    print(pd.DataFrame(diagnosis).round(5).to_string(index=False),flush=True)


if __name__=='__main__':main()
