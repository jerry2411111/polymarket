"""Official shot-region observations and earlier-only goalie/opponent matchups.

The inner-slot rectangle is the existing research definition: attacking x in
[69,89]feet and |y|<=15feet. It is not an NHL-published danger classification.
Expected goals are existing earlier-year model estimates, not official stats.
"""
import argparse
import collections
import json
import math
import sqlite3

import numpy as np
import pandas as pd

from common import PROJECT,PREVIOUS,ROOT_OUT,read_db,dump,stamp,file_sha256
from nhl_identity_features import history_keys

TABLE='nhl_goalkeeper_region_observations'
FIELDS=['f_gran_goalie_profile_matchup_diff','f_gran_goalie_profile_matchup_sum',
        'f_gran_goalie_profile_coverage_diff','f_gran_goalie_profile_coverage_sum']
WORK=ROOT_OUT/'_work/nhl_goalie_profile'


def games():
    base=pd.read_parquet(ROOT_OUT/'retained_models/nhl/nhl_features.parquet')
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        g=pd.read_sql_query('SELECT * FROM nhl_games',db)
    g=g[g.game_id.isin(base.game_id)].copy()
    assert len(g)==len(base)
    for c in ['prediction_time','available_time','start_time']:g[c]=pd.to_datetime(g[c],utc=True,format='mixed')
    return g,base


def build_observations():
    game,base=games();lookup=game.set_index('game_id');path=ROOT_OUT/'nhl_shot_detail.parquet'
    shots=pd.read_parquet(path);shots=shots[shots.game_id.isin(lookup.index)].copy()
    assert not shots.duplicated(['game_id','event_id']).any()
    fitted=pd.to_datetime(shots.shot_model_fit_before_utc,utc=True)
    assert (shots.model_xg.isna()|fitted.le(shots.start_time)).all()
    audits=json.loads((ROOT_OUT/'shot_model_audit.json').read_bytes())
    assert all(pd.Timestamp(a['training_last_available_utc'])<pd.Timestamp(a['fit_cutoff_utc']) for a in audits)
    rows=[];checked=0;mark=10;grouped=shots.groupby('game_id',sort=True);total=len(grouped);raw_sources=[]
    for i,(gid,s) in enumerate(grouped,1):
        g=lookup.loc[gid];native=list(map(str,json.loads(g.native_team_ids_json)))
        assert s.source_sha256.nunique()==1 and s.source_raw_file.nunique()==1
        file=PROJECT/s.source_raw_file.iloc[0];assert file_sha256(file)==s.source_sha256.iloc[0]
        raw=json.loads(file.read_bytes());assert str(raw['id'])==g.official_game_id and raw['gameState'] in ['OFF','FINAL']
        for side,k,n in zip(['A','B'],['awayTeam','homeTeam'],native):
            assert str(raw[k]['id'])==n and raw[k]['score']==g['score'+side]
        events={e['eventId']:(j,e) for j,e in enumerate(raw['plays'])}
        for r in s.itertuples():
            j,e=events[r.event_id];d=e['details'];side='A' if str(d['eventOwnerTeamId'])==native[0] else 'B'
            assert side==r.side and e['typeDescKey']==r.result and e['periodDescriptor']['periodType']==r.period_type
            goalie=d.get('goalieInNetId');assert (goalie is None and pd.isna(r.goalie_id)) or goalie==r.goalie_id
            situation=str(e.get('situationCode',''))
            if len(situation)==4 and situation.isdigit():
                assert int(situation[0 if side=='B' else 3])==r.defending_goalie_present
            else:assert pd.isna(r.defending_goalie_present)
            x,y=d.get('xCoord'),d.get('yCoord');direction=e.get('homeTeamDefendingSide')
            if x is not None and y is not None and direction in ['left','right']:
                right=(direction=='left') if side=='B' else (direction=='right');ax=x if right else -x
                assert r.inner_slot==int(69<=ax<=89 and abs(y)<=15)
                assert abs(r.distance_ft-math.hypot(89-ax,y))<1e-10
            else:assert pd.isna(r.inner_slot)
            checked+=1
        q=s[s.period_type.eq('REG')&s.defending_goalie_present.eq(1)].copy()
        q['region']=q.inner_slot.map({0.:'outside_slot',1.:'inner_slot'}).fillna('unlocated')
        q['official_player_id']=q.goalie_id.map(lambda x:str(int(x)) if pd.notna(x) else None)
        q['modelled_goal']=q.goal.where(q.model_xg.notna())
        source=dict(url=f'https://api-web.nhle.com/v1/gamecenter/{g.official_game_id}/play-by-play',
            raw_file=s.source_raw_file.iloc[0],sha256=s.source_sha256.iloc[0])
        raw_sources.append(source['sha256'])
        for (side,pid,region),part in q.groupby(['side','official_player_id','region'],dropna=False):
            modeled=part.model_xg.notna();defside='B' if side=='A' else 'A'
            rows.append(dict(game_id=gid,official_game_id=g.official_game_id,date=g.date,league='NHL',
                shooting_side=side,defending_side=defside,shooting_team_id=native[0 if side=='A' else 1],
                defending_team_id=native[0 if defside=='A' else 1],official_player_id=pid if pd.notna(pid) else None,
                region=region,attempts=len(part),goals=int(part.goal.sum()),modelled_attempts=int(modeled.sum()),
                modelled_goals=int(part.loc[modeled,'goal'].sum()),
                model_xg=float(part.loc[modeled,'model_xg'].sum()) if modeled.any() else None,
                available_at_utc=g.available_time.isoformat(),
                event_ids_json=json.dumps(part.event_id.astype(int).tolist()),source_json=json.dumps(source,sort_keys=True)))
        while 100*i/total>=mark:
            print(json.dumps(dict(stage='nhl_goalie_profile_raw_replay',percent=mark,games=i,total=total)),flush=True);mark+=10
    frame=pd.DataFrame(rows)
    assert not frame.duplicated(['game_id','shooting_side','official_player_id','region']).any()
    assert frame.attempts.sum()==int((shots.period_type.eq('REG')&shots.defending_goalie_present.eq(1)).sum())
    assert frame.modelled_attempts.ge(frame.modelled_goals).all()
    file=ROOT_OUT/(TABLE+'.parquet');frame.to_parquet(file,index=False);frame.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    meanings={
        'game_id':('Canonical collected match ID','identifier'),'official_game_id':('Official NHL game ID','identifier'),
        'date':('Official game date','YYYY-MM-DD'),'league':('NHL competition','text'),
        'shooting_side':('A=away, B=home attacking team','category'),'defending_side':('A=away, B=home defending team','category'),
        'shooting_team_id':('Native attacking NHL team ID','identifier'),'defending_team_id':('Native defending NHL team ID','identifier'),
        'official_player_id':('Native goalieInNetId; null if omitted by source','identifier'),
        'region':('Research inner-slot rectangle 69<=attacking_x<=89 and abs(y)<=15 feet; otherwise outside_slot; unlocated when geometry unavailable','category'),
        'attempts':('Regulation unblocked goal/shot-on-goal/missed-shot events with a defending goalie present','attempts'),
        'goals':('Actual goals among attempts','goals'),'modelled_attempts':('Attempts with an earlier-year fitted xG estimate','attempts'),
        'modelled_goals':('Actual goals among the modelled subset; zero is an observed subset count','goals'),
        'model_xg':('Sum of internally estimated goal probabilities on modelled attempts; null if none, never an official NHL xG field','expected goals'),
        'available_at_utc':('Existing conservative postgame availability cutoff; source retrieval dates remain separate','UTC timestamp'),
        'event_ids_json':('Exact native event IDs for replay against the raw plays list','JSON array'),
        'source_json':('Official endpoint, immutable raw response path and SHA256','JSON')}
    origin='Official NHL gamecenter play-by-play: team IDs, goalieInNetId, situationCode, xCoord/yCoord and event type. Geometry and xG are research derivations; shot model fitted only on earlier years. No actual upcoming starter is used.'
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        frame.to_sql(TABLE,db,if_exists='replace',index=False)
        for name in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+name+' WHERE "table"=?',(TABLE,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(TABLE,len(frame),len(frame.columns)))
        for c in frame:
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(TABLE,c,*meanings[c],origin))
            n=int(frame[c].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(TABLE,c,len(frame),n,100*n/len(frame)))
        restored=pd.read_sql_query('SELECT * FROM '+TABLE,db);pd.testing.assert_frame_equal(frame,restored,check_dtype=False)
    report=dict(at_utc=stamp(),status='PASS',rows=len(frame),games=frame.game_id.nunique(),raw_sources=len(set(raw_sources)),
        raw_events_replayed=checked,regulation_nonempty_attempts=int(frame.attempts.sum()),
        modelled_attempts=int(frame.modelled_attempts.sum()),unknown_goalie_attempts=int(frame.loc[frame.official_player_id.isna(),'attempts'].sum()),
        unlocated_attempts=int(frame.loc[frame.region.eq('unlocated'),'attempts'].sum()),
        source_sha256=file_sha256(path),output_sha256=file_sha256(file),first_year_xg='2021 has no earlier-year model; observations retained without invented xG')
    dump(ROOT_OUT/'retention/nhl_goalie_profile_validation.json',report);print(json.dumps(report),flush=True)
    from publish import main
    main()


def derive(forecasts,games,observations,keys):
    regional=collections.defaultdict(list)
    for row in observations.to_dict('records'):regional[row['game_id']].append(row)
    past=list(games.sort_values(['available_time','game_id']).itertuples());cursor=0
    teams=collections.defaultdict(lambda:collections.deque(maxlen=20));people=collections.defaultdict(lambda:collections.deque(maxlen=60));last_team={};out=[]
    for game in forecasts.sort_values(['prediction_time','game_id']).itertuples():
        while cursor<len(past) and past[cursor].available_time<game.prediction_time:
            old=past[cursor];cursor+=1;stats=regional[old.game_id]
            for side in ['A','B']:
                team=keys[old.game_id,side];counts=np.zeros(2);goalies=collections.Counter();faced=0
                for row in stats:
                    if row['shooting_side']==side and row['region']!='unlocated':counts[int(row['region']=='inner_slot')]+=row['attempts']
                    if row['defending_side']==side:
                        faced+=row['attempts']
                        if row['official_player_id'] is not None:goalies[row['official_player_id']]+=row['attempts']
                teams[team].append(dict(game_id=old.game_id,at=old.available_time,counts=counts,goalies=goalies,faced=faced))
                group=collections.defaultdict(lambda:dict(counts=np.zeros(2),residual=np.zeros(2)))
                for row in stats:
                    if row['defending_side']!=side or row['official_player_id'] is None:continue
                    pid=row['official_player_id'];last_team[pid]=team
                    if row['region']=='unlocated' or not row['modelled_attempts']:continue
                    k=int(row['region']=='inner_slot');group[pid]['counts'][k]+=row['modelled_attempts']
                    group[pid]['residual'][k]+=row['model_xg']-row['modelled_goals']
                for pid,record in group.items():people[pid].append(dict(record,at=old.available_time,game_id=old.game_id))
        parts={};latest=[];evidence={}
        for side in ['A','B']:
            key=keys[game.game_id,side];opponent=keys[game.game_id,'B' if side=='A' else 'A']
            team=list(teams[key]);attack=list(teams[opponent]);counts=sum((h['counts'] for h in attack),np.zeros(2));weights=collections.Counter()
            for h in team[-5:]:
                for pid,n in h['goalies'].items():
                    if last_team.get(pid)==key:weights[pid]+=n
            all_faced=sum(h['faced'] for h in team[-5:]);rates=[];persons=[]
            for pid,w in weights.items():
                h=list(people[pid]);n=sum((r['counts'] for r in h),np.zeros(2));s=sum((r['residual'] for r in h),np.zeros(2))
                if not n.sum():continue
                overall=s.sum()/(n.sum()+100.)
                specific=(s+100*overall)/(n+100.)-overall
                if counts.sum():rates.append((w,float(np.dot(counts/counts.sum(),specific))))
                persons.append(dict(player_id=pid,weight=w,attempts=n.tolist(),residual=s.tolist(),region_deviation=specific.tolist()))
                latest.extend(r['at'] for r in h)
            parts[side]=dict(matchup=sum(w*r for w,r in rates)/sum(w for w,_ in rates) if rates else np.nan,
                coverage=sum(w for w,_ in rates)/all_faced if all_faced else 0.)
            latest.extend(h['at'] for h in team+attack)
            evidence[side]=dict(goalies=persons,opponent_profile_counts=counts.tolist(),recent_faced=all_faced,
                prior_team_games=[h['game_id'] for h in team[-5:]],opponent_games=[h['game_id'] for h in attack])
        assert not latest or max(latest)<game.prediction_time
        row=dict(game_id=game.game_id,goalie_profile_source_max_utc=max(latest) if latest else pd.NaT,
            goalie_profile_history_json=json.dumps(evidence,sort_keys=True))
        for field in ['matchup','coverage']:
            row['f_gran_goalie_profile_'+field+'_diff']=parts['B'][field]-parts['A'][field]
            row['f_gran_goalie_profile_'+field+'_sum']=parts['B'][field]+parts['A'][field]
        out.append(row)
    result=pd.DataFrame(out).set_index('game_id')
    result['goalie_profile_source_max_utc']=pd.to_datetime(result.goalie_profile_source_max_utc,utc=True).dt.as_unit('ns')
    return result


def build_features():
    assert not WORK.exists();WORK.mkdir(parents=True)
    g,baseline=games();keys,_=history_keys(g,True)
    path=ROOT_OUT/(TABLE+'.parquet');check=json.loads((ROOT_OUT/'retention/nhl_goalie_profile_validation.json').read_bytes())
    assert check['status']=='PASS' and check['output_sha256']==file_sha256(path)
    observations=pd.read_parquet(path);observations['official_player_id']=observations.official_player_id.where(observations.official_player_id.notna(),None)
    facts=derive(baseline,g,observations,keys)
    cut=pd.Timestamp('2025-01-01',tz='UTC');prefix=baseline[baseline.prediction_time.lt(cut)]
    earlier=g[g.available_time.lt(cut)]
    replay=derive(prefix,earlier,observations[observations.game_id.isin(earlier.game_id)],keys)
    pd.testing.assert_frame_equal(replay,facts.loc[replay.index],check_exact=True)
    picked=baseline.sort_values(['prediction_time','game_id']).iloc[np.linspace(0,len(baseline)-1,10,dtype=int)]
    for row in picked.itertuples():
        earlier=g[g.available_time.lt(row.prediction_time)]
        one=derive(baseline[baseline.game_id.eq(row.game_id)],earlier,observations[observations.game_id.isin(earlier.game_id)],keys)
        pd.testing.assert_frame_equal(one,facts.loc[one.index],check_exact=True)
    output=baseline.merge(facts,left_on='game_id',right_index=True,validate='one_to_one')
    pd.testing.assert_frame_equal(output[baseline.columns],baseline,check_exact=True)
    output.to_parquet(WORK/'nhl_features.parquet',index=False)
    report=dict(status='PASS',at_utc=stamp(),rows=len(output),added_inputs=FIELDS,prefix_invariant_rows=len(prefix),direct_cutoff_replays=len(picked),
        feature_sha256=file_sha256(WORK/'nhl_features.parquet'),source_validation=check,
        baseline_inputs_unchanged=True,current_starter_used=False,
        definition='Prior20teamgames attack-region mix against earlier keeper-specific region residuals from last60modelledappearances; prior5game observed shots weight possible keepers;100attempt shrinkage toward own overall residual; no current lineup.')
    dump(WORK/'feature_validation.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--features',action='store_true');a=p.parse_args()
    build_features() if a.features else build_observations()
