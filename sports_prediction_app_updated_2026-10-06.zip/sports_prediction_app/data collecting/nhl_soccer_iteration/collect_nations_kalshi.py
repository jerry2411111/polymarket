"""UEFA-verified single-game contracts; actual-cutoff routed hourly candles."""
import argparse
import collections
import datetime as dt
import hashlib
import json
import re
from urllib.parse import urlencode

import pandas as pd

from common import OfficialClient, ROOT_OUT, REPORTS, PROJECT, dump, stamp
from collect_nations_league import connect
from discover_nations_kalshi import BASE
from nations_market_pilot import norm as plain_norm

SERIES = 'KXUEFANLGAME'
HOURS = [0, 12, 24, 36, 48]


def norm(name):
    value=plain_norm(name)
    return 'republicofireland' if value=='ireland' else value


def verify_identity_alias(client, games, market_rows):
    path=ROOT_OUT/'nations_kalshi_ireland_identity.json'
    if not path.exists():
        native={r['market']['custom_strike']['soccer_team'] for r in market_rows
                if r['market'].get('yes_sub_title')=='Ireland'}
        assert len(native)==1, 'Ireland provider identity must be uniquely observed'
        body,source=client.get(BASE+'/structured_targets/'+next(iter(native)),
            'Resolve Ireland national-team alias against official provider identity','kalshi_team_identity')
        game=next(g for g in games if 'Republic of Ireland' in [g['teamA'],g['teamB']])
        dump(path,dict(at_utc=stamp(),structured_target=body,source=source,uefa_game=game))
    proof=json.loads(path.read_bytes())
    source=proof['source'];blob=(PROJECT/source['raw_file']).read_bytes()
    assert hashlib.sha256(blob).hexdigest()==source['sha256']
    target=json.loads(blob)['structured_target']
    assert target['name']=='Ireland' and target['details']['country']=='IRL'
    game=proof['uefa_game'];source=game['source'];blob=(PROJECT/source['raw_file']).read_bytes()
    assert hashlib.sha256(blob).hexdigest()==source['sha256']
    match=json.loads(blob)[int(game['pointer'].strip('/'))]
    official=next(match[s] for s in ['awayTeam','homeTeam'] if match[s]['countryCode']=='IRL')
    assert official['id']=='64' and official['countryCode']=='IRL'
    assert official['internationalName']=='Republic of Ireland' and official['typeIsNational']


def discover(client, db):
    games = [json.loads(b) for b, in db.execute('SELECT body FROM calendar')]
    rows, pages, duplicates = {}, [], []
    for endpoint in ['/markets', '/historical/markets']:
        cursor, seen = None, set()
        for _ in range(100):
            params = dict(series_ticker=SERIES, limit=1000)
            if cursor:
                params['cursor'] = cursor
            body, source = client.get(BASE+endpoint+'?'+urlencode(params),
                'UEFA Nations League single-game contract discovery', 'kalshi_market_discovery')
            assert isinstance(body, dict) and isinstance(body.get('markets'), list)
            pages.append(dict(source=source, rows=len(body['markets'])))
            for i, market in enumerate(body['markets']):
                if market.get('result') not in ['yes', 'no']:
                    continue
                ticker = market['ticker']
                if ticker in rows:
                    assert rows[ticker]['market']['result'] == market['result']
                    duplicates.append(ticker)
                rows[ticker] = dict(market=market, source=source, pointer='/markets/'+str(i))
            cursor = body.get('cursor')
            if not cursor:
                break
            assert cursor not in seen
            seen.add(cursor)
        else:
            raise AssertionError('Pagination unfinished')
    verify_identity_alias(client,games,list(rows.values()))
    contracts, rejected = [], []
    for item in rows.values():
        market = item['market']
        rules = market['rules_primary']
        pair = re.search(r'(?:wins the |is the result of the )(.+?) vs (.+?) professional UEFA Nations League soccer game originally scheduled for (.+?) after 90 minutes', rules)
        if not pair or 'does not include extra time or penalties' not in rules:
            rejected.append(dict(ticker=market['ticker'], reason='Unverified regulation-only rules')); continue
        day = dt.datetime.strptime(pair[3], '%b %d, %Y').date().isoformat()
        names = {norm(pair[1]), norm(pair[2])}
        matching = [g for g in games if g['date'] == day and {norm(g['teamA']), norm(g['teamB'])} == names]
        if len(matching) != 1:
            rejected.append(dict(ticker=market['ticker'], reason='Exact team/date join not unique', date=day, names=[pair[1],pair[2]])); continue
        game = matching[0]
        label = market['yes_sub_title']
        side = 'D' if label == 'Tie' else next((s for s in ['A', 'B'] if norm(label) == norm(game['team'+s])), None)
        assert side is not None, (market['ticker'], label)
        expected = int(game['scoreA'] == game['scoreB']) if side == 'D' else int(game['score'+side] > game['score'+('B' if side == 'A' else 'A')])
        actual = int(market['result'] == 'yes')
        assert expected == actual == float(market['settlement_value_dollars']), ('Official result conflict', market['ticker'])
        contracts.append(dict(provider='kalshi', game_id=game['game_id'], series_ticker=SERIES,
            event_ticker=market['event_ticker'], market_ticker=market['ticker'], side=side,
            outcome='Draw' if side == 'D' else game['team'+side], result=market['result'],
            official_result=expected, rules=rules, settlement_time=market['settlement_ts'],
            open_time=market['open_time'], public_url=BASE+('/historical/markets/' if '/historical/' in item['source']['url'] else '/markets/')+market['ticker'],
            source=item['source'], raw_market_pointer=item['pointer']))
    groups = collections.defaultdict(list)
    for contract in contracts:
        groups[contract['game_id']].append(contract)
    incomplete = {g:[c['market_ticker'] for c in cs] for g,cs in groups.items()
                  if len(cs) != 3 or {c['side'] for c in cs} != {'A', 'B', 'D'}}
    dump(ROOT_OUT/'nations_kalshi_matching_audit.json',dict(rejected=rejected,incomplete=incomplete))
    assert not incomplete, incomplete
    return games, groups, dict(pages=pages, rejected=rejected, deduplicated_tickers=duplicates,
                              settled_contracts=len(rows), matched_games=len(groups))


def value(block, key, historical):
    raw = block.get(key if historical else key+'_dollars')
    if raw is None:
        return None
    assert isinstance(raw, str), 'Expected documented fixed-point dollar string; do not guess cents'
    answer = float(raw)
    assert 0 <= answer <= 1
    return answer


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--all', action='store_true'); args = parser.parse_args()
    client = OfficialClient(per_second=3); client.HOSTS.add('external-api.kalshi.com')
    db = connect()
    boundary = json.loads((ROOT_OUT/'nations_kalshi_discovery.json').read_text())
    cutoff = pd.Timestamp(boundary['cutoff']['market_settled_ts'])
    games, groups, audit = discover(client, db)
    selected = sorted([g for g in games if g['game_id'] in groups], key=lambda g:g['date'])
    if not args.all:
        selected = [selected[i] for i in sorted({0, len(selected)//2, len(selected)-1})]
    candles, quotes, wide, contracts = [], [], [], []
    step = 10
    for number, game in enumerate(selected, 1):
        start = pd.Timestamp(game['start_time']); end_ts = int(start.timestamp())-1
        row = {k:game[k] for k in ['game_id','date','league','season','location','home_away','final']}
        row.update(match=game['teamA']+'/'+game['teamB'], game_type='Soccer', timestamp=start.isoformat(),
                   teamA_final_score=game['scoreA'], teamB_final_score=game['scoreB'])
        for contract in groups[game['game_id']]:
            contracts.append(contract)
            historical = pd.Timestamp(contract['settlement_time']) < cutoff
            endpoint = '/historical/markets/' if historical else '/series/'+SERIES+'/markets/'
            endpoint += contract['market_ticker']+'/candlesticks'
            parameters = dict(start_ts=int(start.timestamp())-7*86400, end_ts=end_ts, period_interval=60)
            body, source = client.get(BASE+endpoint+'?'+urlencode(parameters),
                game['date']+' Nations League hourly pre-match '+contract['outcome'], 'kalshi_candles')
            assert isinstance(body, dict) and body.get('ticker') == contract['market_ticker']
            observations = []
            for i, candle in enumerate(body['candlesticks']):
                at = pd.Timestamp(candle['end_period_ts'], unit='s', tz='UTC')
                assert at < start
                item = {k:contract[k] for k in ['provider','game_id','series_ticker','event_ticker','market_ticker','side','outcome']}
                item.update(timestamp_utc=at.isoformat(), period_interval=60, source=source,
                            raw_pointer='/candlesticks/'+str(i), historical_route=historical)
                for group in ['yes_bid', 'yes_ask', 'price']:
                    prefix = 'trade' if group == 'price' else group
                    for field in ['open','high','low','close']+(['mean','previous'] if group == 'price' else []):
                        item[prefix+'_'+field] = value(candle.get(group, {}), field, historical)
                for field in ['volume','open_interest']:
                    v = candle.get(field if historical else field+'_fp');item[field] = None if v is None else float(v)
                bid, ask = item['yes_bid_close'], item['yes_ask_close']
                assert bid is None or ask is None or bid <= ask, ('Crossed quote', contract['market_ticker'], at)
                item['mid_close'] = None if bid is None or ask is None else (bid+ask)/2
                observations.append(item);candles.append(item)
            assert len({r['timestamp_utc'] for r in observations}) == len(observations)
            for hours in HOURS:
                target = start-pd.Timedelta(hours=hours)
                eligible = [r for r in observations if r['yes_bid_close'] is not None and pd.Timestamp(r['timestamp_utc']) <= target]
                best = max(eligible, key=lambda r:r['timestamp_utc']) if eligible else None
                probability = best['yes_bid_close'] if best else None
                prefix = ('draw' if contract['side'] == 'D' else 'team'+contract['side'])+f'_pre_{hours}'
                row[prefix+'_p'] = probability; row[prefix+'_odd'] = 1/probability if probability is not None and probability > 0 else None
                quotes.append(dict(provider='kalshi', game_id=game['game_id'], market_ticker=contract['market_ticker'],
                    side=contract['side'], hours_before=hours, target_utc=target.isoformat(), price=probability,
                    observation_utc=best['timestamp_utc'] if best else None,
                    age_hours=(target-pd.Timestamp(best['timestamp_utc'])).total_seconds()/3600 if best else None,
                    request_number=source['request_number'], pointer=best['raw_pointer']+'/yes_bid/'+('close' if historical else 'close_dollars') if best else None,
                    reason=None if best else ('Market not yet open' if pd.Timestamp(contract['open_time']) > target else 'No supplied earlier bid close in seven-day window')))
        wide.append(row)
        if number*100 >= step*len(selected) or number == len(selected):
            progress=dict(at_utc=stamp(), processed=number, total=len(selected), percent=100*number/len(selected), candle_rows=len(candles))
            dump(ROOT_OUT/'nations_kalshi_progress.json',progress);print(json.dumps(progress),flush=True);step+=10
    prefix = 'nations_kalshi_' if args.all else 'pilot_nations_kalshi_'
    for name, rows in [('contracts',contracts),('candles',candles),('quote_audit',quotes),('pre_match',wide)]:
        frame = pd.DataFrame(rows)
        for col in frame:
            if any(isinstance(x,(dict,list)) for x in frame[col]):
                frame[col] = frame[col].map(lambda x:json.dumps(x) if isinstance(x,(dict,list)) else x)
        frame.to_sql(prefix+name,db,if_exists='replace',index=False)
    missing = pd.DataFrame(quotes).groupby('hours_before').price.agg(slots='size',missing=lambda s:s.isna().sum()).reset_index()
    missing['missing_pct'] = 100*missing.missing/missing.slots
    missing.to_csv(REPORTS/(prefix+'missing_by_lookback.csv'),index=False)
    report = dict(at_utc=stamp(), acquisition_complete=True, validation='PENDING_INDEPENDENT_RAW_REPLAY',
        games=len(wide), contracts=len(contracts), candles=len(candles), quote_slots=len(quotes),
        filled_slots=sum(r['price'] is not None for r in quotes), first_date=min(g['date'] for g in selected),
        last_date=max(g['date'] for g in selected), cutoff=boundary['cutoff'], discovery=audit,
        price_basis='YES bid close in probability dollars; not an executable ask price',
        scores='Official UEFA regulation scores; market result used only for consistency validation')
    dump(ROOT_OUT/(prefix+'acquisition.json'),report);db.close()
    print(json.dumps({k:v for k,v in report.items() if k != 'discovery'}),flush=True)


if __name__ == '__main__':
    main()
