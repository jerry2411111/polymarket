"""Dated projected-player strength updates, separate from entry timing effects."""
import argparse
import json
import pickle
import sqlite3
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, PREVIOUS, PROJECT, REPORTS, read_db, dump, stamp, file_sha256
import nhl_player_strength as roster
from forecast_pairing import PRIMARY, SECOND, paired_predictions

WORK = ROOT_OUT / '_work/nhl_lineup_model'
RESULT = ROOT_OUT / 'simulation_results/nhl_lineup_model'
SOURCE = ROOT_OUT / 'simulation_results/nhl_lineup_entry'
FIELDS = ['f_gran_lineup_skater_goal_change', 'f_gran_lineup_first_goalie_change',
          'f_gran_lineup_skater_xg_change', 'f_gran_lineup_update_available']
PROJECTED = ['projected_skater_goal_margin', 'projected_first_goalie_goal_margin', 'projected_skater_xg_margin']
CONTROL = {PRIMARY: 'lineup_control_regulation_ot', SECOND: 'lineup_control_logistic_strong'}


def load_projection(games, players):
    reports = pd.read_parquet(SOURCE / 'lineup_readiness.parquet')
    reports = reports[reports.usable_projected_lineup & reports.game_id.isin(games.game_id)].copy()
    with read_db(ROOT_OUT / 'granular.sqlite') as db:
        people = pd.read_sql_query("SELECT game_id,side,team_id,official_player_id,source_group_number,source_player_index,identity_verified,identity_or_status_conflict,identity_proof_json FROM nhl_dated_lineup_players WHERE report_status='projected'", db)
    role = players.assign(is_goalie=players.position.eq('G')).groupby('official_player_id').is_goalie.agg(['min','max'])
    assert role['min'].eq(role['max']).all()
    roles = {str(pid): 'goalie' if bool(r['min']) else 'skater' for pid, r in role.iterrows()}
    grouped = {k: v.sort_values(['source_group_number','source_player_index']) for k,v in people.groupby('game_id')}
    projection, audit = {}, []
    raw_cache = {}
    for r in reports.to_dict('records'):
        p = grouped[r['game_id']]
        assert p.identity_verified.eq(1).all() and p.identity_or_status_conflict.eq(0).all()
        item = dict(available_at_utc=r['article_available_at_utc'], source_json=r['source_json'], A=[], B=[])
        issue = None
        native = dict(zip(['A','B'], map(str,json.loads(r['native_team_ids_json']))))
        for row in p.to_dict('records'):
            assert str(row['team_id']) == native[row['side']]
            pid = str(row['official_player_id'])
            position = roles.get(pid)
            if position is None:
                proof = json.loads(row['identity_proof_json'])
                code = None
                if proof['kind'] == 'roster_exact':
                    source = proof['source']
                    if source['sha256'] not in raw_cache:
                        path = PROJECT / source['raw_file']
                        assert file_sha256(path) == source['sha256']
                        raw_cache[source['sha256']] = json.loads(path.read_bytes())
                    group, idx = proof['pointer'].strip('/').split('/')
                    obj = raw_cache[source['sha256']][group][int(idx)]
                    assert str(obj['id']) == pid
                    code = obj.get('positionCode')
                elif proof['kind'] == 'validated_opening_alias':
                    code = proof['evidence'].get('position')
                elif proof['kind'] == 'dated_full_name_sweater':
                    code = proof['evidence'].get('position')
                if code in {'G','C','D','L','R','LW','RW'}:
                    position = 'goalie' if code=='G' else 'skater'
                else:
                    issue = 'Static native goalie/skater role requires source repair'
                    break
            item[row['side']].append(dict(player_id=pid, role=position,
                                          source_group_number=int(row['source_group_number']),
                                          source_player_index=int(row['source_player_index'])))
        if issue is None:
            for side in ['A','B']:
                goalies = sum(x['role']=='goalie' for x in item[side])
                skaters = sum(x['role']=='skater' for x in item[side])
                if not (1<=goalies<=3 and 16<=skaters<=20):
                    issue = 'Projected role counts need source review'
        if issue is None:
            projection[r['game_id']] = item
        audit.append(dict(game_id=r['game_id'], official_game_id=r['official_game_id'], date=r['date'],
                          available_at_utc=r['article_available_at_utc'], model_information_time=r['information_time'],
                          source_json=r['source_json'], usable=issue is None, review_reason=issue,
                          projected_people_json=json.dumps(item, default=str)))
    return projection, pd.DataFrame(audit)


def initialize():
    WORK.mkdir(parents=True, exist_ok=True)
    RESULT.mkdir(parents=True, exist_ok=True)
    plan = dict(at_utc=stamp(), hypothesis='Waiting with a frozen forecast lost profitable early opportunities. Test whether match-specific projected skaters and first-listed goalie provide additional probability information.',
        history='2021 onward, expanding monthly fits; select on2024/25 before any new2026evaluation.',
        sources='Previously raw-verified official NHL dated projected-lineup reports and native identities. Complete projected identity/status and goalie/skater role checks; unresolved sources retained for repair.',
        decision='max(original pre12, latest article publication/modification), strictly before scheduled start. Both candidate and control use the same later forecast clock. No future actual starter or appearance enters an input.',
        player_strength='Existing joint game-usage Ridge20 regulation-goal and prior-year internal-xG ratings. Earlier observed last5 player minutes supply projected skater weights; earlier skater median for a player without observed minutes. First listed goalie strength is a signal, not a confirmed start.',
        features=FIELDS, feature_meaning='Three differences between projected strength and original pre12 expected strength, plus a flag that a complete dated update exists. Zero difference without an update means no additional signal, not observed zero player ability. Original features remain.',
        control='Same full all-phase population, pre12 original predictors, with later forecast clocks and past-only train/calibration splits. Reconstruct original player features separately to check the shared helper remains unchanged.',
        gate='Both pooled primary and mean-component2024/25logloss must improve, and primary logloss must improve on rows with an available update. No penalty, hour, confidence or stake grid.',
        betting='After probability scoring, use the same stored paired post-information quotes, both p/price>=1.10, original one-side expected-log-growth selection, flat20 dollars, annual2000cash, no costs. Providers separate. Compare same quoted games.',
        limitations='Projected is not confirmed; source revision vintage is reconstructed from last metadata, not a contemporaneous archive. Preseason lacks this particular official report feed. Repeatedly inspected2026 remains retrospective.',
        app_changed=False)
    path = RESULT/'experiment_plan.json'
    if path.exists():
        assert all(json.loads(path.read_bytes())[k] == v for k,v in plan.items() if k!='at_utc')
    else:
        dump(path,plan)
    return plan


def build():
    initialize()
    games,players,rosters,keys = roster.load()
    projection,audit = load_projection(games,players)
    audit.to_parquet(RESULT/'projected_source_audit.parquet',index=False)
    # Confirm optional hook and bookkeeping changes do not change the original
    # pre12 strength features or their source clocks.
    original,_ = roster.derive(games,players,rosters,keys,save=False)
    previous = pd.read_parquet(ROOT_OUT/'nhl_roster_strength_features.parquet').set_index('game_id')
    fields = roster.FIELDS + ['player_rating_source_max_utc','rating_fit_cutoff','rating_training_games','opening_roster_observations','imputed_usage_weights']
    pd.testing.assert_frame_equal(original.set_index('game_id')[fields],previous.loc[original.game_id,fields],
                                  check_dtype=False,check_exact=False,atol=1e-10,rtol=0)
    dated = games.copy()
    clocks = {gid:max(pd.Timestamp(v['available_at_utc']),games.set_index('game_id').loc[gid,'prediction_time']) for gid,v in projection.items()}
    dated['prediction_time'] = [clocks.get(r.game_id,r.prediction_time) for r in games.itertuples()]
    assert dated.prediction_time.ge(games.prediction_time).all() and dated.prediction_time.lt(dated.start_time).all()
    extra,stats = roster.derive(dated,players,rosters,keys,save=False,projection=projection)
    cutoff = pd.Timestamp('2025-01-01',tz='UTC')
    early = dated[dated.prediction_time.lt(cutoff)].copy()
    early_projection = {gid:v for gid,v in projection.items() if gid in set(early.game_id)}
    prefix,_ = roster.derive(early,players[players.game_id.isin(early.game_id)],
        rosters[pd.to_datetime(rosters.available_at_utc,utc=True,format='mixed').lt(cutoff)],keys,save=False,projection=early_projection)
    pd.testing.assert_frame_equal(prefix.set_index('game_id'),extra.set_index('game_id').loc[prefix.game_id],
                                  check_dtype=False,check_exact=False,atol=1e-10,rtol=0)
    extra = extra.merge(dated[['game_id','date','prediction_time']],on='game_id',validate='one_to_one')
    extra.to_parquet(WORK/'projected_strength.parquet',index=False)
    summary = dict(at_utc=stamp(),status='PASS',games=len(games),projected_reports=len(projection),
                   original_pre12_strength_replayed=len(original),prefix_invariant_rows=len(prefix),
                   moved_forecast_clocks=int(dated.prediction_time.ne(games.prediction_time).sum()),
                   rating_stats=stats,complete_strength_updates=int(extra[PROJECTED].notna().all(axis=1).sum()))
    dump(RESULT/'projection_validation.json',summary)
    print(json.dumps(dict(stage='projected_strength',**summary)),flush=True)
    # The pre12 control information stays fixed even when a new report triggers
    # a later forecast; candidate adds only the published-player update.
    import features,nhl_identity_features
    basepath = WORK/'base_features.parquet'
    if basepath.exists():
        base=pd.read_parquet(basepath)
    else:
        g,o,p,_,teamstats,metrics,_=features.sources('nhl',include_preseason=True)
        needed=['game_id','side','available_at_utc','player_id','official_player_id','minutes','position','saves','shots_against']+metrics
        p=roster.apply_repairs(p[list(dict.fromkeys(needed+['played']))])
        base,_=nhl_identity_features.derive(g,o,p,teamstats,metrics,repaired=True,regulation_labels=games)
        base.to_parquet(basepath,index=False)
    assemble_features()


def assemble_features():
    base=pd.read_parquet(WORK/'base_features.parquet')
    original=pd.read_parquet(ROOT_OUT/'nhl_roster_strength_features.parquet')
    extra=pd.read_parquet(WORK/'projected_strength.parquet')
    summary=json.loads((RESULT/'projection_validation.json').read_bytes())
    frame=base.merge(original[['game_id']+roster.FIELDS],on='game_id',validate='one_to_one')
    frame=frame.merge(extra[['game_id']+PROJECTED],on='game_id',validate='one_to_one')
    valid=np.zeros(len(frame),dtype=bool);counts={}
    for new,projected,prior in zip(FIELDS[:3],PROJECTED,roster.FIELDS):
        available=frame[[projected,prior]].notna().all(axis=1)
        frame[new]=np.where(available,frame[projected]-frame[prior],0.)
        valid|=available.to_numpy();counts[new]=int(available.sum())
    frame[FIELDS[3]]=valid.astype(float)
    old_clock=frame.prediction_time.copy()
    frame['prediction_time']=frame.game_id.map(extra.set_index('game_id').prediction_time)
    assert frame.prediction_time.ge(old_clock).all()
    frame=frame.drop(columns=PROJECTED)
    frame.to_parquet(WORK/'nhl_features.parquet',index=False)
    dump(RESULT/'feature_validation.json',summary|dict(feature_sha256=file_sha256(WORK/'nhl_features.parquet'),
        complete_incremental_updates=int(valid.sum()),control_fields_unchanged=True,
        later_info_never_backdated=True,available_updates_by_field=counts,
        partial_history_policy='Each known strength change is used independently; absent prior-year xG does not discard existing goal/goalie history. Zero unavailable difference means preserve the pre12 input.',
        source_manifest_sha256=file_sha256(RESULT/'projected_source_audit.parquet')))
    print(json.dumps(dict(stage='features_ready',rows=len(frame),updates=int(valid.sum()))),flush=True)


def pair(raw,label):
    names=CONTROL if label=='control' else {PRIMARY:PRIMARY,SECOND:SECOND}
    f=raw[raw.variant.isin(names.values())].copy()
    f.variant=f.variant.replace({v:k for k,v in names.items()})
    return paired_predictions(f,label)


def account_test(p,stage='development'):
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    transfer.RESULT=RESULT
    entries=pd.read_parquet(SOURCE/(stage+'_entries.parquet'))
    manifest=pd.read_parquet(SOURCE/'contract_manifest.parquet')
    native=manifest[['provider','official_game_id','native_team_ids_json']].drop_duplicates()
    q=entries.merge(native,on=['provider','official_game_id'],validate='many_to_one')
    q=q.merge(p[['official_game_id','sport','league','target']].drop_duplicates(),on='official_game_id',validate='many_to_one')
    q=q.rename(columns={'price':'entry_price','source_utc':'entry_source_utc','available_utc':'entry_available_utc',
                        'quote_age_hours':'entry_age_hours','pointer':'entry_pointer'})
    q['entry_request_id']='nhl_soccer_iteration:'+q.request_number.astype(str)
    fields=['provider','sport','league','official_game_id','game_id','native_team_ids_json','target','class_index','decision_utc',
            'entry_price','entry_source_utc','entry_available_utc','entry_age_hours','entry_request_id','entry_pointer','entry_contract_id','price_basis']
    annual=[];bets=[];days=[];checks=[];coverage=[]
    for variant,g in p.groupby('variant'):
        for provider,quotes in q.groupby('provider'):
            clocks=quotes[['official_game_id','decision_utc']].drop_duplicates()
            forecasts=g.merge(clocks,on='official_game_id',validate='one_to_one')
            assert forecasts.prediction_time.le(forecasts.decision_utc).all()
            forecasts['prediction_time']=forecasts.decision_utc
            f=transfer.normalize('nhl',forecasts,quotes[fields],True)
            idx=forecasts.set_index('game_id').loc[f.game_id]
            f['secondary_probability']=np.where(f.side.eq(0),idx.second_p0,idx.second_p1)
            f=f[np.minimum(f.probability,f.secondary_probability)/f.price>=1.10].copy()
            f['model_stage']='dated_projected_lineup'
            coverage.append(dict(variant=variant,provider=provider,quoted_forecasts=len(forecasts)))
            for year in [2024,2025] if stage=='development' else [2026]:
                m,b,l,d=engine.simulate(f,year,'all_selected_outcomes','flat20_cash_only',5.,2000.)
                key=dict(sport='nhl',variant=variant,provider=provider,year=year)
                checks.append(key|engine.validate(b,l,d,'flat20_cash_only',5.,2000.));annual.append(key|m)
                if len(b):bets.append(b.assign(**key))
                days.append(d.assign(**key))
    a=pd.DataFrame(annual);a.to_csv(RESULT/(stage+'_annual.csv'),index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/(stage+'_bets.parquet'),index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/(stage+'_daily.parquet'),index=False)
    dump(RESULT/(stage+'_cash_validation.json'),dict(status='PASS',checks=checks,coverage=coverage))
    return a


def train():
    import models
    from evaluate_nhl_player_strength import loss,diagnose,forecast_metrics
    proof=json.loads((RESULT/'feature_validation.json').read_bytes())
    assert proof['status']=='PASS' and file_sha256(WORK/'nhl_features.parquet')==proof['feature_sha256']
    models.OUT=WORK
    for base,name in CONTROL.items():models.CANDIDATES[name]=dict(models.CANDIDATES[base],exclude_columns=FIELDS)
    names=[PRIMARY,SECOND]+list(CONTROL.values())
    raw=models.run('nhl','development',names)
    p=pd.concat([pair(raw,'candidate'),pair(raw,'control')],ignore_index=True)
    assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
    frame=pd.read_parquet(WORK/'nhl_features.parquet')
    p=p.merge(frame[['game_id',FIELDS[3]]],on='game_id',validate='many_to_one')
    p.to_parquet(RESULT/'development_predictions.parquet',index=False)
    forecast_metrics(p).to_csv(RESULT/'development_metrics.csv',index=False)
    diagnose(p,RESULT/'development_paired_loss.json')
    design=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
    replays=0
    for name in names:
        pkg=pickle.loads((WORK/'model_runs/nhl/development'/(name+'.pkl')).read_bytes())
        sample=raw[raw.variant.eq(name)&raw.fold.eq(pkg['boundary'].strftime('%Y-%m'))].head(12)
        x=design.loc[sample.game_id,pkg['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
        predicted=models.apply_calibration(pkg['model'].predict_proba(x),pkg['calibrator'])
        assert np.allclose(predicted,sample[['p0','p1']],atol=1e-12,rtol=0)
        assert set(FIELDS).issubset(pkg['columns']) if name in [PRIMARY,SECOND] else not set(FIELDS)&set(pkg['columns'])
        replays+=len(sample)
    scores={}
    for variant,g in p.groupby('variant'):
        y=g.target.to_numpy(int);primary=-np.log(g[['p0','p1']].to_numpy()[np.arange(len(g)),y])
        scores[variant]=dict(primary_logloss=float(primary.mean()),component_logloss=float(loss(g).mean()),
                              updated_primary_logloss=float(primary[g[FIELDS[3]].eq(1).to_numpy()].mean()),
                              updated_forecasts=int(g[FIELDS[3]].eq(1).sum()),all_forecasts=len(g))
    gate=all(scores['candidate'][k]<scores['control'][k] for k in ['primary_logloss','component_logloss','updated_primary_logloss'])
    dump(RESULT/'selection.json',dict(at_utc=stamp(),passed=bool(gate),scores=scores,adopted=False))
    a=account_test(p)
    dump(RESULT/'model_validation.json',dict(at_utc=stamp(),status='PASS',development_gate_passed=bool(gate),
        forecast_replays=replays,source_and_training_clock_checks=True,evaluation2026_run=False,
        original_pre12_model_preserved=True,adopted=False,app_changed=False))
    print(json.dumps(dict(stage='selection',passed=bool(gate),scores=scores)),flush=True)
    print(a[['variant','provider','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


def diagnose_updates():
    p=pd.read_parquet(RESULT/'development_predictions.parquet')
    rows=[]
    for (variant,year,updated),g in p.groupby(['variant',p.prediction_time.dt.year,FIELDS[3]]):
        y=g.target.to_numpy(int);probs=g[['p0','p1']].to_numpy();pick=probs.argmax(axis=1)
        rows.append(dict(variant=variant,year=int(year),lineup_update=bool(updated),games=len(g),
                         primary_logloss=float(-np.log(probs[np.arange(len(g)),y]).mean()),
                         primary_accuracy=float(np.mean(pick==y)),mean_pick_confidence=float(probs.max(axis=1).mean())))
    pd.DataFrame(rows).to_csv(RESULT/'updated_cohort_metrics.csv',index=False)
    control=p[p.variant.eq('control')].set_index('game_id')
    candidate=p[p.variant.eq('candidate')].set_index('game_id').loc[control.index]
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games=pd.read_sql_query('SELECT game_id,official_game_id,teamA,teamB,phase,scoreA,scoreB FROM nhl_games',db).set_index('game_id')
    g=games.loc[control.index]
    assert control.target.eq(np.where(g.scoreB>g.scoreA,1,0)).all()
    chosen=control[['p0','p1']].to_numpy().argmax(axis=1)
    cases=g.copy();cases['date']=control.date;cases['picked_side']=chosen
    cases['baseline_probability']=control[['p0','p1']].to_numpy()[np.arange(len(control)),chosen]
    cases['candidate_probability']=candidate[['p0','p1']].to_numpy()[np.arange(len(candidate)),chosen]
    cases['won']=chosen==control.target.to_numpy();cases['lineup_update']=control[FIELDS[3]].eq(1)
    cases['probability_change']=cases.candidate_probability-cases.baseline_probability
    details=pd.read_parquet(WORK/'nhl_features.parquet').set_index('game_id')
    cases=cases.join(details[FIELDS[:3]])
    audit=pd.read_parquet(RESULT/'projected_source_audit.parquet').set_index('game_id')
    cases['lineup_source_url']=cases.index.map(audit.source_json.map(lambda s:json.loads(s)['url']))
    cases['public_verification_url']='https://www.nhl.com/gamecenter/'+cases.official_game_id.astype(str)
    picked=cases[cases.date.str.startswith('2025') & cases.lineup_update & ~cases.won].nlargest(12,'baseline_probability')
    picked.to_csv(RESULT/'earlier_updated_high_confidence_losses.csv')
    changed=cases[cases.date.str.startswith('2025') & cases.lineup_update].copy()
    changed['absolute_change']=changed.probability_change.abs()
    changed.nlargest(20,'absolute_change').to_csv(RESULT/'largest_earlier_probability_updates.csv')
    effects=[]
    for name in [PRIMARY,SECOND]:
        pkg=pickle.loads((WORK/'model_runs/nhl/development'/(name+'.pkl')).read_bytes())
        fitted=pkg['model']
        components=list(zip(['away_regulation_goals','home_regulation_goals'],fitted.models)) if hasattr(fitted,'models') else [('home_win',fitted)]
        for response,component in components:
            coefficients=np.asarray(component.steps[-1][1].coef_).reshape(-1)
            for field in FIELDS:
                effects.append(dict(model=name,response=response,field=field,
                    coefficient_per_training_standard_deviation=float(coefficients[pkg['columns'].index(field)]),
                    link='log_expected_goals' if hasattr(fitted,'models') else 'log_odds',
                    fit_boundary=pkg['boundary'],interpretation='Conditional fitted association, not causal; before probability calibration'))
    dump(RESULT/'feature_effects.json',effects)
    dump(RESULT/'case_validation.json',dict(status='PASS',at_utc=stamp(),official_results_checked=len(g),
        earlier_high_confidence_losses=len(picked),model_updates_diagnosed=len(changed),
        no_losing_team_or_month_filter=True))
    check_projection_reliability()


def check_projection_reliability():
    """Post-event diagnostic labels, never merged into pregame features."""
    games,players,_,_=roster.load()
    reports=pd.read_parquet(RESULT/'projected_source_audit.parquet')
    reports=reports[reports.usable & reports.date.lt('2026-01-01')]
    start=pd.read_parquet(ROOT_OUT/'nhl_verified_ice_intervals.parquet',
        columns=['game_id','period','start_seconds','goalieA_id','goalieB_id','usable'],
        filters=[('period','==',1),('start_seconds','==',0)])
    assert not start.game_id.duplicated().any()
    start=start[start.usable.eq(1)].set_index('game_id')
    groups={key:g for key,g in players.groupby(['game_id','side'])}
    rows=[]
    for r in reports.itertuples():
        info=json.loads(r.projected_people_json)
        for side in ['A','B']:
            projected=info[side]
            skaters={p['player_id'] for p in projected if p['role']=='skater'}
            goalies=[p['player_id'] for p in projected if p['role']=='goalie']
            p=groups.get((r.game_id,side),players.iloc[:0])
            observed=p[p.position.ne('G') & (p.played.eq(1)|p.minutes.gt(0))]
            actual=set(observed.official_player_id.astype(str))
            complete=bool(len(actual)>=16 and not (p.played.isna() & p.minutes.isna()).any())
            actual_goalie=start.loc[r.game_id,'goalie'+side+'_id'] if r.game_id in start.index else None
            known=actual_goalie is not None and pd.notna(actual_goalie)
            rows.append(dict(game_id=r.game_id,date=r.date,side=side,projected_first_goalie=goalies[0],
                actual_first_goalie=str(actual_goalie) if known else None,
                first_goalie_matches=(goalies[0]==str(actual_goalie)) if known else None,
                projected_skaters=len(skaters),observed_skaters=len(actual),appearance_comparison_complete=complete,
                exact_skater_set=(skaters==actual) if complete else None,
                actual_skater_recall=len(skaters&actual)/len(actual) if actual and complete else None,
                projected_not_observed_json=json.dumps(sorted(skaters-actual)) if complete else None,
                observed_not_projected_json=json.dumps(sorted(actual-skaters)) if complete else None,
                purpose='post-event source reliability diagnostic only; excluded from model inputs'))
    frame=pd.DataFrame(rows);frame.to_parquet(RESULT/'projection_reliability.parquet',index=False)
    summary=[]
    for year,g in frame.groupby(frame.date.str[:4]):
        goalie=g.first_goalie_matches.dropna().astype(bool);skater=g.exact_skater_set.dropna().astype(bool)
        summary.append(dict(year=int(year),team_reports=len(g),verified_opening_goalies=len(goalie),
            first_listed_goalie_correct_pct=100*float(goalie.mean()) if len(goalie) else None,
            comparable_skater_sets=len(skater),exact_projected_skater_set_pct=100*float(skater.mean()) if len(skater) else None,
            mean_actual_skater_recall_pct=100*float(g.actual_skater_recall.mean())))
    pd.DataFrame(summary).to_csv(RESULT/'projection_reliability_by_year.csv',index=False)
    dump(RESULT/'projection_reliability_validation.json',dict(status='PASS',at_utc=stamp(),team_reports=len(frame),
        through='2025-12-31',post_event_labels_never_inputs=True,
        first_goalie_source='Verified official on-ice interval at period1/start0; unsafe intervals excluded explicitly.',
        participation_source='Official NHL player-game participation/minutes with documented repairs.',
        source_sha256=file_sha256(ROOT_OUT/'nhl_verified_ice_intervals.parquet')))


def publish():
    proof=json.loads((RESULT/'feature_validation.json').read_bytes());assert proof['status']=='PASS'
    extra=pd.read_parquet(WORK/'projected_strength.parquet')
    features=pd.read_parquet(WORK/'nhl_features.parquet')
    wanted=['game_id','date','prediction_time','rating_fit_cutoff','rating_training_games','projected_source_utc',
            'projected_weight_source_max_utc','projected_players','projected_weight_fallbacks',
            'projected_unseen_rating_players','projected_pool_json']+PROJECTED
    data=extra[wanted].merge(features[['game_id']+FIELDS],on='game_id',validate='one_to_one')
    sources=pd.read_parquet(RESULT/'projected_source_audit.parquet')[['game_id','source_json']]
    data=data.merge(sources,on='game_id',how='left',validate='one_to_one')
    # Reports rejected for role ambiguity do not become available model data
    # at the earlier fallback pre12 clock. Their evidence stays in the audit.
    data.loc[data.projected_source_utc.isna(),'source_json']=None
    timecols=['prediction_time','rating_fit_cutoff','projected_source_utc','projected_weight_source_max_utc']
    for col in timecols:data[col]=pd.to_datetime(data[col],utc=True)
    assert (data.projected_source_utc.isna() | data.projected_source_utc.le(data.prediction_time)).all()
    assert (data.projected_weight_source_max_utc.isna() | data.projected_weight_source_max_utc.lt(data.prediction_time)).all()
    assert data.rating_fit_cutoff.le(data.prediction_time).all()
    for r in data[data.projected_pool_json.notna()].itertuples():
        pool=json.loads(r.projected_pool_json)
        if not pool:continue
        for side in ['A','B']:
            group=[x for x in pool if x['side']==side]
            if group:
                assert np.isclose(sum(x['exposure'] for x in group if x['role']=='skater'),5.,atol=1e-10)
                assert sum(x['role']=='first_listed_goalie' for x in group)==1
    table='nhl_projected_strength_features'
    meanings={
      'game_id':('Canonical official-game-linked identifier','identifier'),
      'date':('Official game calendar date','YYYY-MM-DD'),
      'prediction_time':('Later of pre12 or verified report publication/modification; before start','UTC timestamp'),
      'rating_fit_cutoff':('Monthly boundary; only earlier completed games fit strength ratings','UTC timestamp'),
      'rating_training_games':('Earlier games with complete official minutes in strength estimation','games'),
      'projected_source_utc':('Latest publication/modification time of eligible projected lineup','UTC timestamp'),
      'projected_weight_source_max_utc':('Latest earlier player/minutes evidence used in projected usage weights','UTC timestamp'),
      'projected_players':('Native identified people in the projected lists, including backup goalies','players'),
      'projected_weight_fallbacks':('Skater weights using the earlier skater median because no individual minute history exists','players'),
      'projected_unseen_rating_players':('Used projected people without observations in the preceding monthly goal-rating fit; coefficients shrink to zero','players'),
      'projected_pool_json':('Ordered native IDs, sides, roles, exposures, prior minute weights and whether fitted from earlier observations; only first listed goalie enters strength','JSON array'),
      PROJECTED[0]:('Home-minus-away projected skater joint goal-rating sum weighted by earlier expected usage','regulation goals'),
      PROJECTED[1]:('Home-minus-away first-listed projected goalie goal-rating coefficient; not confirmation of who starts','regulation goals'),
      PROJECTED[2]:('Home-minus-away projected skater xG-rating sum; shot xG is fitted on prior years','internally modelled expected goals'),
      FIELDS[0]:('Projected skater goal strength minus original pre12 expectation; zero means no extra signal if unavailable','regulation goals'),
      FIELDS[1]:('First-listed projected goalie strength minus original pre12 weighted goalie expectation; zero preserves baseline if unavailable','regulation goals'),
      FIELDS[2]:('Projected skater xG strength minus original pre12 expectation; zero preserves baseline if unavailable','internally modelled expected goals'),
      FIELDS[3]:('At least one earlier-rated strength update is usable from a complete identified projected lineup','0/1'),
      'source_json':('Original official article request, URL, response file, retrieval timestamp and hash','JSON object')}
    assert set(meanings)==set(data)
    source='Official NHL projected-lineup articles and native roster/player identities; earlier official minutes/results and prior-year internal shot xG. Derived by nhl_lineup_model.py with monthly Ridge20 ratings, not an official NHL player rating.'
    sql=data.copy()
    for col in timecols:sql[col]=sql[col].map(lambda x:x.isoformat() if pd.notna(x) else None)
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        sql.to_sql(table,db,if_exists='replace',index=False)
        for name in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+name+' WHERE "table"=?',(table,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(table,len(data),len(data.columns)))
        for col in data:
            meaning,unit=meanings[col];db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(table,col,meaning,unit,source))
            n=int(data[col].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(table,col,len(data),n,100*n/len(data)))
        actual=pd.read_sql_query('SELECT * FROM '+table,db)
    pd.testing.assert_frame_equal(sql,actual,check_dtype=False,check_exact=False,atol=1e-12,rtol=0)
    path=ROOT_OUT/(table+'.parquet');data.to_parquet(path,index=False)
    data.to_csv(path.with_suffix('.csv'),index=False)
    pd.testing.assert_frame_equal(data,pd.read_parquet(path),check_exact=True)
    result=dict(status='PASS',at_utc=stamp(),table=table,rows=len(data),columns=len(data.columns),
                sha256=file_sha256(path),sql_parquet_equal=True,all_source_clocks_checked=True,
                projected_first_goalie_is_not_confirmed=True)
    dump(RESULT/'publication_validation.json',result)
    import publish as catalog
    catalog.main()
    return result


def finish():
    from final_pipeline import discard_work,cleanup,validate
    choice=json.loads((RESULT/'selection.json').read_bytes())
    proof=json.loads((RESULT/'model_validation.json').read_bytes());assert proof['status']=='PASS'
    diagnose_updates();source=publish()
    stats=json.loads((RESULT/'feature_validation.json').read_bytes())
    annual=pd.read_csv(RESULT/'development_annual.csv')
    cohorts=pd.read_csv(RESULT/'updated_cohort_metrics.csv')
    report=REPORTS/'nhl_lineup_model.md'
    lines=['# NHL forecasts using dated projected lineups','',
        'Waiting for lineup reports while keeping old probabilities reduced returns. This test instead adds the information in the report to the forecast, while holding the betting rule and later quote cohort fixed.','',
        'Three added inputs compare projected skater goal strength, first-listed goalie strength and projected skater xG strength with the original pre12 expected roster. A fourth flag identifies an available update. Joint Ridge20 ratings use only games completed before the monthly boundary; skater usage uses earlier observed last-five minutes or an earlier skater median. The first-listed goalie is an uncertain projected identity, not an assertion about the eventual starter. Unknown fitted ability shrinks to zero; unrecorded actual minutes remain unknown.','',
        'Each available strength component is used independently: lack of earlier xG training does not erase already observed goal/goalie information. A zero incremental feature without evidence preserves the original expectation; it is not a fabricated zero player statistic.','',
        f"The data cover {stats['games']:,} games from 2021. {stats['projected_reports']:,} reports pass projected-identity, status and role checks. {stats['original_pre12_strength_replayed']:,} original feature rows replay exactly; removing future history leaves {stats['prefix_invariant_rows']:,} earlier derived rows unchanged. Source clocks and monthly training boundaries are checked for every row.",'',
        'Both versions use the later of pre12 and the latest article publication/modification as the forecast cutoff. The original inputs are the saved pre12 information. The candidate adds only the dated player update. Both regulation/OT and strongly regularized logistic models use expanding history and purged past-only calibration. Thus different forecast timing alone cannot account for candidate-versus-control differences.','',
        '|2024/25 probability score|Control|Projected-lineup inputs|','|---|---:|---:|']
    for field in ['primary_logloss','component_logloss','updated_primary_logloss']:
        lines.append(f"|{field}|{choice['scores']['control'][field]:.9f}|{choice['scores']['candidate'][field]:.9f}|")
    lines += ['',f"The fixed earlier-period probability gate {'passed' if choice['passed'] else 'failed'}. New 2026 evaluation has not been run. No app model has been changed.",'',
        '|Year|Model|Published update|Games|Primary accuracy|Primary log loss|','|---|---|---|---:|---:|']
    for r in cohorts.itertuples():lines.append(f'|{r.year}|{r.variant}|{r.lineup_update}|{r.games}|{100*r.primary_accuracy:.2f}%|{r.primary_logloss:.6f}|')
    lines += ['', 'The account rule remains one selected outcome, both model probabilities/price at least1.10, flat$20 from an annual$2,000 cash-only account, hold to official settlement. Providers stay separate. Quotes follow publication; no costs/spread assumptions are added. Open positions retain cost value until settlement; Sharpe annualizes daily account returns by sqrt(365.25).','',
        '|Provider|Year|Model|Bets|Bet win rate|Return|Sharpe|Max drawdown|','|---|---:|---|---:|---:|---:|---:|---:|']
    for r in annual.itertuples():
        fmt=lambda v,s='':'—' if pd.isna(v) else f'{v:.2f}{s}'
        lines.append(f'|{r.provider}|{r.year}|{r.variant}|{r.funded_games}|{fmt(r.win_rate_pct,"%")}|{fmt(r.return_pct,"%")}|{fmt(r.sharpe)}|{fmt(r.max_drawdown_pct,"%")}|')
    lines += ['', 'The 2024 quoted sample is partial. Earlier high-confidence losing cases, largest probability changes and standardized feature coefficients are retained to inspect the mechanism. No losing team, month or outcome was removed to improve results. Projected identity/status issues remain in the source repair queue; article timestamps reconstruct availability conservatively but are not a contemporaneous archived feed. This source collection does not cover preseason lineup reports.','',
        'The overall NHL/soccer target remains active. Repeatedly inspected2026results elsewhere are retrospective rolling evaluations, not a pristine OOS test. A passed earlier score gate only permits the next evaluation; it does not establish adoption or target achievement.','',
        'Sources: native dated articles in projected_source_audit.parquet, official NHL player-game observations, and the documented nhl_roster_strength_features/nhl_team_shot_quality tables. Internal xG and Ridge ratings are model-derived, not official statistics. Original article URLs, responses and hashes remain linked.','',
        'Reproduce: nhl_lineup_model.py build ; nhl_lineup_model.py train ; nhl_lineup_model.py finish . Required source preparation: nhl_lineup_entry.py prepare/pilot/collect/validate. Final projected strength facts and simulation evidence are retained; temporary matrices and fitted trial packages are removed after publication and replay.']
    reliability=pd.read_csv(RESULT/'projection_reliability_by_year.csv')
    r=reliability[reliability.year.eq(2025)].iloc[0]
    lines += ['',f"Post-event source checks, excluded from every model input: the first-listed goalie actually began the game in {r.first_listed_goalie_correct_pct:.2f}% of {int(r.verified_opening_goalies):,} verifiable 2025 team reports. Projected skaters cover {r.mean_actual_skater_recall_pct:.2f}% of actual participants on average; the exact set agrees in {r.exact_projected_skater_set_pct:.2f}% of team reports. Thus the new data mostly identify the participants correctly. This particular strength representation does not improve probability quality; the failure is not explained simply by universally wrong projected lineups.",'',
        'Next mechanism: preserve early model-value purchases, then test selling at the first observed pre-match price that reaches the original model probability. The timing-only test lost profitable early opportunities by waiting to buy. Capturing those opportunities and later closing at model fair value is a different hypothesis, with the target fixed by the existing forecast rather than a searched profit percentage. Keep same-cohort hold-to-settlement comparison and require genuine observed exit prices; do not interpolate a threshold crossing or use future lineups at entry.']
    report.write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False)
    prefix='nhl_lineup_model/';old=old[~old.source_result_file.str.startswith(prefix,na=False)]
    parts=[old]
    for filename in ['development_annual.csv','development_metrics.csv']:
        parts.append(pd.read_csv(RESULT/filename).assign(source_result_file=prefix+filename,sport='nhl'))
    pd.concat(parts,ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';decisions=json.loads(path.read_bytes())
    decisions['nhl_lineup_model']=dict(plan=json.loads((RESULT/'experiment_plan.json').read_bytes()),selection=choice,validation=proof,source=source)
    dump(path,decisions)
    discard_work(WORK);cleanup();app=validate()
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        tables=db.execute('SELECT COUNT(*) FROM table_catalog').fetchone()[0]
        columns=db.execute('SELECT COUNT(*) FROM column_catalog').fetchone()[0]
    path=ROOT_OUT/'retention/retained_artifacts.json';manifest=json.loads(path.read_bytes())
    manifest['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    manifest.update(updated_utc=stamp(),retained_scripts=len(manifest['scripts']),final_tables=tables,current_sql_columns=columns,
        latest_dataset_update=dict(table=source,report=str(report)),latest_simulation_update=dict(result=str(RESULT.relative_to(ROOT_OUT)),adopted=False,report=str(report)))
    dump(path,manifest)
    receipt=dict(status='PASS',at_utc=stamp(),source=source,model=proof,selection=choice,app_validation=app,
                 temporary_work_removed=True,goal_achieved=False,report=str(report))
    dump(ROOT_OUT/'retention/nhl_lineup_model_completion.json',receipt)
    path=ROOT_OUT/'research_continuation.json';state=json.loads(path.read_bytes())
    state.update(at_utc=stamp(),current_job=None,live_sessions=[],running_jobs=[],
        last_action='Completed dated projected-lineup strength model comparison on2024/25; published as-of features and source/cash/forecast checks; trial work removed.',
        next_action='Projected-lineup strength failed earlier probability gate despite mostly accurate projected identities. Keep existing forecast. Test early purchase plus first observed pre-match exit at original model probability, against same-cohort hold, using the newly verified later price points. No interpolated hits or parameter grid; preserve source repair queue and soccer role/replacement-quality work.',
        final_sql_tables=tables,final_sql_columns=columns,report=str(report))
    state.setdefault('research_state',{})['nhl_lineup_model']=receipt;dump(path,state)
    print(json.dumps(dict(status='PASS',development_gate_passed=choice['passed'],report=str(report),goal_achieved=False)),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['build','assemble','train','finish']);args=ap.parse_args()
    {'build':build,'assemble':assemble_features,'train':train,'finish':finish}[args.action]()
