"""Dated official club-strength rankings, preserving the service update clock.

The official public client documents comp.uefa.com/v2/coefficients and its
paging/season parameters. We do not backdate a later-revised ranking snapshot.
"""
import argparse
import json
import sqlite3
from decimal import Decimal
import pandas as pd
from common import ROOT_OUT,PROJECT,OfficialClient,read_db,dump,stamp,file_sha256

TABLE='soccer_uefa_club_coefficients'
PROOF=ROOT_OUT/'retention/uefa_club_coefficients_validation.json'
URL='https://comp.uefa.com/v2/coefficients'


def normalize(document,source,year):
    assert source['return_status']=='200'
    data=document['data'];rows=[]
    if not data.get('members'):return []
    updated=pd.Timestamp(data['lastUpdateDate'])
    if updated.tzinfo is None:raise ValueError('Source ranking clock has no timezone')
    # July is after ordinary UEFA season completion; the2020season ended in
    # August. More importantly, never use a snapshot before its API update.
    complete=pd.Timestamp(f'{year}-09-01' if year==2020 else f'{year}-07-01',tz='UTC')
    available=max(complete,updated)
    for index,r in enumerate(data['members']):
        member=r['member'];overall=r['overallRanking'];seasons=r['seasonRankings']
        assert member['typeTeam']=='DOMESTIC' and not member['typeIsNational']
        assert int(overall['targetSeasonYear'])==year and int(overall['baseSeasonYear'])==year-4
        # Some clubs have no supplied entry in seasons without participation.
        # Keep that sparse list verbatim; do not fabricate annual zero records.
        assert set(int(s['seasonYear']) for s in seasons).issubset(set(range(year-4,year+1)))
        total=Decimal(str(overall['totalPoints']));reported=Decimal(str(overall['totalValue']))
        floor=Decimal(str(overall['nationalAssociationPoints']))
        parts=sum(Decimal(str(s['totalValue'])) for s in seasons)
        assert total>=0 and floor>=0
        # Some older snapshots put the association floor into totalValue;
        # totalPoints remains the club's own score. Preserve both raw fields.
        assert abs(parts-total)<=Decimal('.005'),(member['id'],parts,total)
        rows.append(dict(ranking_season_year=year,uefa_club_id=str(member['id']),
            club_name=member['displayOfficialName'],association_id=str(member['associationId']),
            country_code=member['countryCode'],club_coefficient=float(total),association_floor=float(floor),
            reported_total_value=float(reported),seeding_coefficient=float(max(total,floor)),rank=int(overall['position']),
            season_complete_after_utc=complete.isoformat(),source_last_update_utc=updated.isoformat(),
            available_after_utc=available.isoformat(),retrieved_at_utc=source['retrieved_at_utc'],
            season_values_json=json.dumps(seasons,sort_keys=True),
            source_request_number=source['request_number'],source_url=source['url'],
            source_pointer=f'/data/members/{index}',raw_file=source['raw_file'],source_sha256=source['sha256']))
    return rows


def collect():
    OfficialClient.HOSTS.add('comp.uefa.com');client=OfficialClient()
    rows=[];sources=[];snapshots=[]
    for year in range(2020,2027):
        seen=set();page=1;yearrows=[]
        while True:
            url=URL+f'?coefficientRange=OVERALL&coefficientType=MEN_CLUB&seasonYear={year}&page={page}&pagesize=500&language=EN'
            doc,src=client.get(url,f'Historical{year}UEFAclub coefficients, page{page}','official_historical_club_coefficients')
            assert doc is not None,src['return_status']
            part=normalize(doc,src,year);sources.append(src)
            if not part:break
            assert not seen&{r['uefa_club_id'] for r in part},'Repeated pagination members'
            seen.update(r['uefa_club_id'] for r in part);yearrows.extend(part);page+=1
            assert page<20,'Unexpected pagination: inspect response instead of downloading indefinitely'
        assert len(yearrows)>100 and len({r['source_last_update_utc'] for r in yearrows})==1
        rows.extend(yearrows);snapshots.append(dict(year=year,clubs=len(yearrows),
            available_after_utc=yearrows[0]['available_after_utc'],source_last_update_utc=yearrows[0]['source_last_update_utc']))
        print(json.dumps(dict(stage='uefa_coefficients',year=year,clubs=len(yearrows),percent=round(100*(year-2019)/7,1),
            available_after_utc=yearrows[0]['available_after_utc'])),flush=True)
    f=pd.DataFrame(rows);assert not f.duplicated(['ranking_season_year','uefa_club_id']).any()
    f.to_parquet(ROOT_OUT/(TABLE+'.parquet'),index=False);f.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    checks=[]
    # Replay every published row against saved original API bodies.
    for src in sources:
        raw=PROJECT/src['raw_file'];assert file_sha256(raw)==src['sha256']
        year=int(src['url'].split('seasonYear=')[1].split('&')[0])
        replay=pd.DataFrame(normalize(json.loads(raw.read_bytes()),src,year))
        if len(replay):
            old=f[f.source_request_number.eq(src['request_number'])].reset_index(drop=True)
            pd.testing.assert_frame_equal(old,replay,check_dtype=False,check_exact=True)
            checks.append(dict(request=src['request_number'],replayed_rows=len(old)))
    dump(PROOF,dict(status='PASS',at_utc=stamp(),rows=len(f),snapshots=snapshots,sources=sources,
        raw_replays=checks,output_sha256=file_sha256(ROOT_OUT/(TABLE+'.parquet')),
        availability='max(conservative season completion boundary, official API lastUpdateDate); no later revised table is backdated. Retrieval time remains separate.',
        limitation='LastUpdateDate is not first-publication time. The conservative rule can intentionally delay a historical ranking beyond when some original values were known. Native IDs, not names, join teams.',
        documentation=['https://www.uefa.com/nationalassociations/uefarankings/club/',
          'https://documents.uefa.com/r/Regulations-of-the-UEFA-Champions-League-2026/27/D.2-Reference-periods-for-rankings-Online'],
        discovery_receipt='retention/uefa_coefficients_source_probe.json'))
    publish(f)


def publish(f):
    meanings={
        'ranking_season_year':('End year of the last complete season in the five-season ranking','year'),
        'uefa_club_id':('Native UEFA club identifier','identifier'),
        'club_name':('Official club name from the ranking response','text'),
        'association_id':('Native UEFA national association identifier','identifier'),
        'country_code':('UEFA national association code','category'),
        'club_coefficient':('Five-season club total supplied by UEFA, before the association floor','coefficient points'),
        'association_floor':('20-percent association component supplied separately by UEFA','coefficient points'),
        'reported_total_value':('Original overallRanking.totalValue; older snapshots may already apply the association floor','coefficient points'),
        'seeding_coefficient':('Maximum of club coefficient and supplied association floor','coefficient points'),
        'rank':('Official position within this historical ranking','ordinal'),
        'season_complete_after_utc':('Conservative completed-season boundary; not asserted first publication','UTC timestamp'),
        'source_last_update_utc':('LastUpdateDate returned by the official API for this ranking snapshot','UTC timestamp'),
        'available_after_utc':('Model-use boundary, maximum of season completion and official last update','UTC timestamp'),
        'retrieved_at_utc':('Time this original response was downloaded','UTC timestamp'),
        'season_values_json':('Original five separate seasonal coefficient records','JSON'),
        'source_request_number':('Acquisition request number linking the raw-first log','identifier'),
        'source_url':('Exact official endpoint including nonsecret parameters','URL'),
        'source_pointer':('JSON pointer to this club in its paginated original response','JSON pointer'),
        'raw_file':('Project-relative immutable original API response','path'),
        'source_sha256':('SHA256 of the original response','SHA256')}
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        f.to_sql(TABLE,db,if_exists='replace',index=False)
        db.execute(f'CREATE INDEX IF NOT EXISTS {TABLE}_asof ON {TABLE}(uefa_club_id,available_after_utc)')
        for table in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+table+' WHERE "table"=?',(TABLE,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(TABLE,len(f),len(f.columns)))
        for col in f:
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(TABLE,col,*meanings[col],
                'Official UEFA comp.uefa.com/v2/coefficients; native club IDs and complete original seasonal records preserved.'))
            db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(TABLE,col,len(f),int(f[col].isna().sum()),100*f[col].isna().mean()))
    from publish import main
    main()


def public_validate():
    """Manual-validation pages corroborate nine native-ID API observations."""
    import re
    from html.parser import HTMLParser
    class VisibleText(HTMLParser):
        def __init__(self):
            super().__init__(convert_charrefs=True);self.parts=[];self.skip=0
        def handle_starttag(self,tag,attrs):
            if tag in {'script','style','noscript'}:self.skip+=1
        def handle_endtag(self,tag):
            if tag in {'script','style','noscript'}:self.skip=max(0,self.skip-1)
        def handle_data(self,data):
            if not self.skip:self.parts.append(data)
    OfficialClient.HOSTS.update({'es.uefa.com','www.realmadrid.com'})
    client=OfficialClient();frame=pd.read_parquet(ROOT_OUT/(TABLE+'.parquet'));rows=[]
    examples=[
        (2021,'https://www.uefa.com/uefachampionsleague/news/026b-12a6cf1883a5-902841e42354-1000--2021-22-group-stage-as-it-stands/',
         [('50037','Bayern',134.,'134.000'),('52919','Manchester City',125.,'125.000'),('50051','Real Madrid',127.,'127.000')]),
        (2024,'https://es.uefa.com/uefachampionsleague/news/0270-14127d1d4632-c8e93067d4dd-1000--ranking-uefa-clasificacion-novedades-equipos/',
         [('52919','Manchester City',148.,'148,000'),('50037','Bayern',144.,'144,000'),('50051','Real Madrid',136.,'136,000')]),
        (2025,'https://www.realmadrid.com/es-ES/noticias/futbol/primer-equipo/actualidad/el-real-madrid-cierra-la-temporada-lider-del-ranking-uefa-03-06-2025',
         [('50051','Real Madrid',143.5,'143.500'),('52919','Manchester City',137.75,'137.750'),('50037','Bayern',135.25,'135.250')])]
    for year,url,expected in examples:
        raw,source=client.get(url,f'Manually corroborate{year}club coefficient values with official dated report','official_manual_validation',document=True)
        assert source['return_status']=='200'
        parser=VisibleText();parser.feed(raw.decode('utf-8') if isinstance(raw,bytes) else raw);plain=' '.join(' '.join(parser.parts).split())
        for uid,name,value,printed in expected:
            row=frame[frame.ranking_season_year.eq(year)&frame.uefa_club_id.eq(uid)].iloc[0]
            evidence=re.search(re.escape(name)+r'.{0,160}?'+re.escape(printed),plain,re.I)
            assert evidence,(year,name,printed)
            assert float(row.club_coefficient)==value
            rows.append(dict(ranking_season_year=year,uefa_club_id=uid,club_name=row.club_name,
                api_value=row.club_coefficient,public_value=value,public_printed_value=printed,match=True,
                api_endpoint=row.source_url,api_request_number=int(row.source_request_number),
                api_source_pointer=row.source_pointer,api_retrieved_at_utc=row.retrieved_at_utc,
                public_url=url,public_excerpt=evidence.group(0),public_source=source,discrepancy=None))
    dump(ROOT_OUT/'retention/uefa_coefficients_public_validation.json',dict(status='PASS',at_utc=stamp(),examples=rows,
        note='Public pages corroborate selected values, not the original publication time of every API record. Model availability remains conservatively gated by lastUpdateDate.'))
    print(json.dumps(dict(status='PASS',public_examples=len(rows),years=[2021,2024,2025])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--validate-public',action='store_true');args=parser.parse_args()
    public_validate() if args.validate_public else collect()
