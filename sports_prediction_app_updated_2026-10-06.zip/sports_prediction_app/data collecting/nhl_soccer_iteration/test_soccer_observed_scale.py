"""Test one preprocessing revision with the exact retained 39 source features.

CompetitionScale uses observed training values to normalize numeric fields.
Preserve those units after median imputation, instead of inflating rare fields
and indicators by their observation prevalence. No cutoff or threshold search.
"""
import argparse
import json
import shutil

import numpy as np
import pandas as pd

import models
from common import ROOT_OUT,dump,stamp,file_sha256
from compare_feature_revision import main
from final_pipeline import cleanup,discard_work


def run(pooled_variance_floor=False,drop_sparse_keypasses=False):
    assert not (pooled_variance_floor and drop_sparse_keypasses),'Test one revision at a time'
    label=('soccer_without_sparse_keypasses' if drop_sparse_keypasses else
           'soccer_pooled_scale' if pooled_variance_floor else 'soccer_observed_scale')
    work=ROOT_OUT/'_work'/label
    assert not (ROOT_OUT/'simulation_results/feature_revisions'/label).exists()
    assert not work.exists();work.mkdir(parents=True)
    try:
        source=ROOT_OUT/'retained_models/soccer/soccer_features.parquet'
        feature=work/'soccer_features.parquet';shutil.copy2(source,feature)
        frame=pd.read_parquet(feature)
        data=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1)
        base=dict(models.CANDIDATES['context_league']);base_cols=models.columns(data,base)
        excluded=['f_ctx_roster_key_passes_rate_diff'] if drop_sparse_keypasses else []
        cols=[c for c in base_cols if c not in excluded]
        assert not excluded or len(cols)==len(base_cols)-1
        keep=[c for c in cols if c.startswith('f_')]
        spec=dict(base,preserve_unit_columns=keep)
        if excluded:spec['exclude_columns']=excluded
        if pooled_variance_floor:spec['pooled_variance_floor']=True
        # Reproduce the diagnosed calibration fold with no target access.
        boundary=pd.Timestamp('2024-06-01',tz='UTC');prior=data[data.available_time.lt(boundary)]
        cal=prior[prior.prediction_time.ge(boundary-pd.Timedelta(days=180))]
        train=prior[prior.available_time.lt(cal.prediction_time.min())]
        ordinary=models.make_model(base,'soccer')[:-1];revised=models.make_model(spec,'soccer')[:-1]
        ordinary.fit(train[base_cols]);revised.fit(train[cols])
        old=np.asarray(ordinary.transform(cal[base_cols]));new=np.asarray(revised.transform(cal[cols]))
        old_names=list(ordinary[-2].get_feature_names_out())
        names=list(revised[-2].get_feature_names_out())
        for i,name in enumerate(names):
            if name.startswith('missingindicator_'):
                assert set(np.unique(new[:,i])).issubset({0.,1.})
            elif name.startswith('league_'):
                assert np.allclose(old[:,old_names.index(name)],new[:,i],rtol=0,atol=1e-12)
        # All original sources, timestamps, targets and feature values are byte-identical.
        assert file_sha256(source)==file_sha256(feature)
        diagnostic='f_ctx_roster_key_passes_rate_diff'
        validation=dict(status='PASS',at_utc=stamp(),rows=len(frame),added_model_inputs=0,
            total_model_inputs=len(cols),excluded_model_inputs=excluded,feature_sha256=file_sha256(feature),source_features_unchanged=True,
            definition='Observed competition units preserved through imputation; binary missing indicators stay0/1. League dummy transform unchanged.',
            calibration_replay=dict(fold='2024-06',train_rows=len(train),calibration_rows=len(cal),
                original_max_abs_key_passes=float(abs(old[:,old_names.index(diagnostic)]).max()),
                revised_max_abs_key_passes=float(abs(new[:,names.index(diagnostic)]).max()) if diagnostic in names else None),
            no_future_transform_fit=True)
        if pooled_variance_floor:
            scaler=revised[0]
            assert scaler.sds_.ge(scaler.global_sd_,axis=1).all().all()
            validation.update(pooled_variance_floor=True,definition='Prior observed competition SD floored at prior pooled observed SD; preserve units after imputation. No new tuning constant.')
        if drop_sparse_keypasses:
            assert all(diagnostic not in n for n in names)
            validation.update(definition='Keep observed-unit scaling; remove only the key-pass roster difference identified by dated source replay as a sparse player-subset measurement. All source values stay unchanged.')
        dump(work/'feature_validation.json',validation)
        models.CANDIDATES['context_league']=spec
        hypothesis='The retained soccer transform inflates sparse fields after imputation; preserve observed competition units and binary indicators to improve rolling probabilities without changing input data, learner, hyperparameters or betting rule.'
        if pooled_variance_floor:
            hypothesis+=' Sparse competition scales can still be too small; floor their observed SD at the pooled earlier observed SD. Require improvement over the preceding observed-unit revision as well as the original retained model.'
        if drop_sparse_keypasses:
            hypothesis+=' Dated source replay found three Bundesliga key-pass comparisons used only one player per team from earlier foreign-league records. Remove this single squad-proxy input; preserve other38inputs and the observed-unit correction. Require improvement over observed-unit revision and retained baseline before2026.'
        main(label,hypothesis,'soccer_observed_scale' if pooled_variance_floor or drop_sparse_keypasses else None)
    finally:
        if work.exists():discard_work(work)
        cleanup()


if __name__=='__main__':
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group()
    group.add_argument('--pooled-variance-floor',action='store_true')
    group.add_argument('--drop-sparse-keypasses',action='store_true')
    args=parser.parse_args()
    run(args.pooled_variance_floor,args.drop_sparse_keypasses)
