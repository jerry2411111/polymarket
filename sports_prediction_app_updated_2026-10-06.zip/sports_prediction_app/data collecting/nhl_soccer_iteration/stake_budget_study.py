"""Select a small per-match budget grid on2025; inspect2026 with frozen choices."""
import argparse
import json
import numpy as np
import pandas as pd
from common import ROOT_OUT, dump, stamp
from final_pipeline import cleanup
import test_confidence_dollars as engine

RESULT=ROOT_OUT/'simulation_results/stake_budget_study'
BUDGETS=[500.,1000.,2000.,4000.]


def main(starting_account=10000.):
    global RESULT
    corrected=starting_account==2000.
    if corrected: RESULT=ROOT_OUT/'simulation_results/starting_account_staking'
    assert not (RESULT/'validation.json').exists(),'Preserve completed study'
    RESULT.mkdir(exist_ok=True)
    plan=dict(at_utc=stamp(),formula='stake=match_budget*max(model_winner_probability-0.51,0)',
        example='budget2000,p=.58 -> stake140,remaining1860 not wagered',
        budgets=BUDGETS,initial_account_dollars=10000,
        unused_budget='Budget is a staking reference, not a2000dollar purchase or collateral lock. Unspent money remains account cash. Actual open stakes consume cash until settlement.',
        model_selection='Saved NBA and MLB app models unchanged. NHL/soccer selections recorded separately using only2024/25 probability scores.',
        choice='For each sport/entryfilter, rank budgets on2025 calendar daily Sharpe; ties choose lower drawdown then smaller budget. Save choices before calculating2026 grid.',
        comparison='Same winner-above51 opportunity set against1%equity capped at20%open-cost; also MLB existing5pp price advantage. Cash-only budget rule has no extra exposure cap; show cap20 sensitivity separately.',
        model_accuracy_is_not_edge='Probability alone does not establish expected profit; at binary contract price q, expected profit per dollar is p/q-1.',
        extra_reference='Quarter-Kelly fraction .25*max((p-price)/(1-price),0) of equity,20%total open-cost cap. Fixed formula, no fraction tuning or theorem-based drawdown guarantee for this historical portfolio.',
        periods='2025 selection;2026 throughSeptember29 retrospective check.2024 sparse quoted pilot is reported in initial confidence-dollar comparison and not used to choose stake budget.',
        papers=[
            dict(title='A New Interpretation of Information Rate',authors='J.L.Kelly',year=1956,url='https://onlinelibrary.wiley.com/doi/abs/10.1002/j.1538-7305.1956.tb03809.x',use='Bet growth depends on probabilities together with available odds.'),
            dict(title='Risk-Constrained Kelly Gambling',authors='E.Busseti,E.Ryu,S.Boyd',year=2016,url='https://web.stanford.edu/~boyd/papers/pdf/kelly.pdf',use='Fractional staking and wealth drawdown are distinct from classification accuracy. Binary Kelly fraction transforms to(p-q)/(1-q) for a$1payoff contract.'),
            dict(title='Machine learning for sports betting: should forecasting models be optimised for accuracy or calibration?',year=2024,url='https://arxiv.org/html/2303.06021v2',use='Inspect calibrated probabilities as well as winner accuracy; paper results do not establish an edge in our data.')],
        no_parameter_selection_on2026=True,app_changed=False)
    dump(RESULT/'plan.json',plan)
    if corrected:
        plan.update(initial_account_dollars=2000.,
            formula='stake=dollars_per_percentage_point*max(100*model_winner_probability-51,0)',
            dollars_per_percentage_point=[b/100 for b in BUDGETS],
            example='Starting account2000,20dollars/point,p=.58 -> stake140; if account grows to3000 stake remains140.',
            unused_budget='Only actual stakes consume account cash. The starting account is2000; there is no separate per-game2000reserve. No borrowing. Simultaneous requests prorate if available cash is insufficient.',
            legacy_match_budget_column='Historical internal column match_budget means100*dollars_per_point; in this corrected study it is a nominal sizing multiplier, not an additional bankroll or match reserve.',
            supersedes='The10000dollar-account comparisons used an earlier interpretation. This2000dollar-account study follows both explicit user clarifications.',
            model_selection=plan['model_selection'])
        dump(RESULT/'plan.json',plan)
    original_result=engine.RESULT;engine.RESULT=RESULT
    try:f=engine.inputs()
    finally:engine.RESULT=original_result
    records=[];positions=[];daily=[];checks=[]
    choices=[]
    for year in [2025,2026]:
        for sport,g in f.groupby('sport'):
            selections=['winner_above51']+(['winner_edge5_above51'] if sport=='mlb' else [])
            for selection in selections:
                recipes=[('fixed1pct_cap20',None),('quarter_kelly_cap20',None)]
                recipes += [(s,budget) for s in ['dollars_cash_only','dollars_cap20'] for budget in BUDGETS]
                for sizing,budget in recipes:
                    amount=budget/100 if budget is not None else 20.
                    m,b,l,d=engine.simulate(g,year,selection,sizing,amount,starting_account)
                    key=dict(sport=sport,provider='polymarket',year=year,selection=selection,sizing=sizing,match_budget=budget)
                    checks.append(key|engine.validate(b,l,d,sizing,amount,starting_account));records.append(key|m)
                    if len(b):positions.append(b.assign(**key))
                    daily.append(d.assign(**key))
                print(json.dumps(dict(stage='budget_grid',sport=sport,year=year,entry=selection)),flush=True)
        if year==2025:
            earlier=pd.DataFrame(records)
            for (sport,selection),g in earlier[earlier.sizing.eq('dollars_cash_only')].groupby(['sport','selection']):
                best=g.sort_values(['sharpe','max_drawdown_pct','match_budget'],ascending=[False,True,True]).iloc[0]
                choices.append(dict(sport=sport,selection=selection,match_budget=float(best.match_budget),
                    dollars_per_point=float(best.match_budget)/100,initial_cash=starting_account,
                    chosen_on_year=2025,selection_sharpe=float(best.sharpe),selection_return_pct=float(best.return_pct)))
            dump(RESULT/'frozen_choices.json',dict(at_utc=stamp(),choices=choices,selection_used2026=False))
    a=pd.DataFrame(records);b=pd.concat(positions,ignore_index=True);d=pd.concat(daily,ignore_index=True)
    a.to_csv(RESULT/'annual.csv',index=False);b.to_parquet(RESULT/'bets.parquet',index=False);d.to_parquet(RESULT/'daily.parquet',index=False)
    comparison=[]
    for choice in choices:
        for year in [2025,2026]:
            subset=a[a.sport.eq(choice['sport'])&a.selection.eq(choice['selection'])&a.year.eq(year)]
            candidate=subset[subset.sizing.eq('dollars_cash_only')&subset.match_budget.eq(choice['match_budget'])].iloc[0]
            baseline=subset[subset.sizing.eq('fixed1pct_cap20')].iloc[0]
            comparison.append(choice|dict(year=year,candidate_return_pct=float(candidate.return_pct),candidate_sharpe=float(candidate.sharpe),
                candidate_drawdown_pct=float(candidate.max_drawdown_pct),baseline_return_pct=float(baseline.return_pct),baseline_sharpe=float(baseline.sharpe),
                return_improves=bool(candidate.return_pct>baseline.return_pct),sharpe_improves=bool(candidate.sharpe>baseline.sharpe)))
    compared=pd.DataFrame(comparison);compared.to_csv(RESULT/'frozen_choice_comparison.csv',index=False)
    nba=compared[compared.sport.eq('nba')&compared.selection.eq('winner_above51')]
    transfer=bool(nba.return_improves.all() and nba.sharpe_improves.all() and nba.candidate_return_pct.gt(0).all())
    # Replay the user20dollar case against the completed first experiment.
    previous=pd.read_csv(ROOT_OUT/'simulation_results/nba_mlb_confidence_dollars/annual.csv')
    for r in a[a.match_budget.eq(2000)&a.sizing.str.startswith('dollars')&(not corrected)].itertuples():
        sizing='dollars20_cash_only' if r.sizing=='dollars_cash_only' else 'dollars20_cap20'
        old=previous[previous.sport.eq(r.sport)&previous.year.eq(r.year)&previous.selection.eq(r.selection)&previous.sizing.eq(sizing)].iloc[0]
        for field in ['funded_games','return_pct','sharpe','max_drawdown_pct']:
            assert np.isclose(getattr(r,field),old[field],rtol=0,atol=1e-8)
    decision=dict(at_utc=stamp(),status='PASS',checks=checks,legacy10000case_reproduced=not corrected,
        corrected_initial_account=starting_account,dollars_stay_fixed_after_balance_changes=True,
        transfer_nba_rule_to_other_sports=transfer,transfer_budget=float(nba.match_budget.iloc[0]) if transfer else None,
        transfer_basis='NBA selected2025budget improves both return and Sharpe versus matched1%baseline in2025and already-inspected2026; transfer is a new retrospective research test, not validation of universal effectiveness.',
        adopted=False,app_changed=False)
    dump(RESULT/'validation.json',decision)
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=RESULT.name+'/annual.csv'
    pd.concat([old[~old.source_result_file.eq(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[RESULT.name]=dict(plan=plan,decision={k:v for k,v in decision.items() if k!='checks'});dump(path,old)
    cleanup()
    print(compared.to_string(index=False),flush=True)
    print(json.dumps({k:v for k,v in decision.items() if k!='checks'}),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--starting-account',type=float,choices=[10000.,2000.],default=2000.)
    main(parser.parse_args().starting_account)
