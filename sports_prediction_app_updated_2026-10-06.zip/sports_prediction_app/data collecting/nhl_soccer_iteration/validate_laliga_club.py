"""Replay sources, verify historical identity and reconcile fixture-filtered stats."""
import argparse,collections,datetime as dt,hashlib,json,re
from common import ROOT_OUT,PROJECT,read_db,dump,stamp
from laliga_club_archive import BASE,games,sid
from collect_laliga_club_facts import connect,parse
from laliga_club_players import parse as parse_player

def raw(source):
    b=(PROJECT/source['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==source['sha256'];return b

def evidence(g,fixture):
    fixes={};sources=json.loads((ROOT_OUT/'laliga_club_staff_sources.json').read_text())
    if g['game_id']=='HIST_LAL_16359':
        source=sources[0];b=raw(source).decode('utf8')
        assert 'Ronald Koeman' in b and '66th minute' in b and 'Granada' in b
        assert source['url']=='https://www.fcbarcelona.com/en/news/2123640/fc-barcelona-to-appeal-koeman-suspension'
        fixes['130876']=dict(club_team_id='49',clock_secs=3960,reason='Official dated club announcement identifies coach Ronald Koeman dismissal in minute 66; no player-time deduction.',available_at_utc='2021-05-01 00:00:00+00:00',source=source)
    if g['game_id']=='HIST_LAL_81492':
        source=sources[1];p=json.loads(re.search(rb'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',raw(source),re.S)[1])['props']['pageProps']['data']
        assert p['game']['date']==g['date'] and (p['game']['homeScore'],p['game']['awayScore'])==(g['scoreB'],g['scoreA'])
        assert dt.datetime.fromisoformat(p['game']['time'].replace('Z','+00:00'))==dt.datetime.fromisoformat(g['timestamp'])
        minute_totals={};red_players=[]
        for side in ['home','away']:
            ps=p['stats'][side+'TeamPlayersStats'];values=[x['stats']['minsPlayed'] for x in ps if x.get('stats') and 'minsPlayed' in x['stats']]
            assert len(values)>=11 and all(0<=v<=90 for v in values);minute_totals[side]=sum(values)
            red_players.extend(x for x in ps if (x.get('stats') or {}).get('redCard'))
        assert minute_totals=={'home':990,'away':914}
        assert len(red_players)==1 and red_players[0]['player']['name']=='Gonzalo Verdú' and red_players[0]['stats']['minsPlayed']==14
        bad=[e for e in fixture['events'] if e['type']=='B' and e.get('description')=='R' and e.get('personId') is None]
        assert len(bad)==1 and sid(bad[0]['teamId'])=='770' and bad[0]['clock']['secs']==2700
        fixes[str(bad[0]['id'])]=dict(club_team_id='770',clock_secs=2700,reason='Complete official Elche individual-minute totals establish only the known minute-14 player reduction (990-76=914); unidentified dismissal causes no additional player-time loss. Actor identity is not inferred.',available_at_utc=g['available_time'],source=source,minute_totals=minute_totals)
    return fixes

def run(rebuild=False):
    lookup=games();db=connect();records=[json.loads(r[0]) for r in db.execute('SELECT body FROM games')]
    with read_db(ROOT_OUT/'acquisition.sqlite') as c:
        sources={r['url']:dict(r) for r in c.execute("SELECT * FROM request_audit WHERE return_status='200' AND (url LIKE '%/textstream/en?%' OR url LIKE 'https://www.fcbarcelona.com/en/matches/%') ORDER BY request_number")}
    counts=collections.Counter();examples=[];bygame={}
    for old in records:
        g=lookup[old['game_id']];fs,ss=old['sources'][:2];f=json.loads(raw(fs));s=json.loads(raw(ss));fid=old['club_archive_index']['club_fixture_id']
        cs=sources.get(BASE+f'/fixtures/{fid}/textstream/en?page=0&pageSize=1000&sort=asc&altIds=false');comment=json.loads(raw(cs)) if cs else None
        fixes=evidence(g,f);new=parse(g,old['club_archive_index'],f,s,fs,ss,comment,cs,fixes)
        if rebuild:
            with db:db.execute('UPDATE games SET body=? WHERE game_id=?',(json.dumps(new,allow_nan=False),g['game_id']))
        else:assert new==old,'Normalized facts differ from retained source replay'
        assert new['minutes_complete'] and new['goal_counts_reconcile'],(g['game_id'],new['issues'])
        counts['games']+=1;counts['player_rows']+=len(new['players']);counts['team_rows']+=len(new['teams']);bygame[g['game_id']]=new
        for p in new['players']:
            assert 0<=p['minutes']<=90 and p['played']==(p['started'] or p['minutes']>0 or any(e.get('personId')==int(p['club_player_id']) and e.get('type')=='S' and e.get('description')=='ON' for e in f['events']))
            assert dt.datetime.fromisoformat(p['available_at_utc'])>dt.datetime.fromisoformat(g['timestamp'])
            if not p['played']:assert p['minutes']==0 and p['goals']==0
        public=sources.get('https://www.fcbarcelona.com/en/matches/'+fid)
        if public:
            html=raw(public).decode('utf8');match_scores=re.findall(r'class="[^"]*js-match-score[^"]*">\s*<span>(\d+)\s*-\s*(\d+)</span>',html)
            assert match_scores and set(match_scores)=={(str(g['scoreB']),str(g['scoreA']))}
            assert f'data-fixture-id="{fid}"' in html and f'data-opta-id="{f["altIds"]["opta"]}"' in html
            assert str(int(f['kickoff']['millis'])) in re.findall(r'data-kickoff="(\d+)"',html)
            examples.append(dict(game_id=g['game_id'],event=g['teamA']+' / '+g['teamB'],date=g['date'],start_utc=g['timestamp'],scoreA=g['scoreA'],scoreB=g['scoreB'],fixture_api=fs['url'],stats_api=ss['url'],retrieved_at_utc=fs['retrieved_at_utc'],raw_normalized_match=True,public_verification_url=public['url'],public_title=re.search(r'<title>(.*?)</title>',html,re.S)[1],discrepancy=None))
    assert len(examples)>=3
    people=[json.loads(r[0]) for r in db.execute('SELECT body FROM player_statistics')];lineups={(r['game_id'],p['official_player_id']):p for r in bygame.values() for p in r['players']};checks=[]
    for r in people:
        original=lineups[(r['game_id'],r['official_player_id'])];again=parse_player(json.loads(raw(r['source'])),original,r['source'])
        # Direct source statistics retain their own original availability. Later
        # disciplinary evidence delays only derived lineup/playing-time facts.
        again['available_at_utc']=r['available_at_utc'];assert again==r
        counts['statistic_rows']+=1
    for gid,r in bygame.items():
        ps=[p for p in people if p['game_id']==gid]
        if {p['official_player_id'] for p in ps if p['appearances_reported']==1}!={p['official_player_id'] for p in r['players'] if p['played']}:continue
        for side in ['A','B']:
            group=[p for p in ps if p['side']==side];team=next(t for t in r['teams'] if t['side']==side)
            reported_minutes=sum(p['minutes_reported'] for p in group if p['minutes_reported'] is not None)
            derived_minutes=sum(p['minutes'] for p in r['players'] if p['side']==side)
            checks.append(dict(game_id=gid,side=side,metric='minutes_reported_vs_event_clock',player_sum=reported_minutes,team_source=derived_minutes,match=reported_minutes==derived_minutes,likely_reason='Published player minutes and event display clocks can have different minute-rounding conventions; both original values are preserved.'))
            for metric in ['passes','passes_completed','shots','shots_on_target','tackles','interceptions','saves']:
                if team[metric] is None:continue
                # Sum supplied counts only; omitted individual source cells stay NULL.
                summed=sum(p[metric] for p in group if p[metric] is not None)
                checks.append(dict(game_id=gid,side=side,metric=metric,player_sum=summed,team_source=team[metric],match=summed==team[metric]))
        counts['complete_player_stat_games']+=1
    db.close()
    dump(ROOT_OUT/'laliga_club_validation.json',dict(at_utc=stamp(),status='PASS',counts=dict(counts),validated_player_keys=[[r['game_id'],r['official_player_id']] for r in people],examples=examples,team_stat_reconciliation=checks,discrepancies=[r for r in checks if not r['match']],source_note='Official club API publishes Opta data; it is labelled separately from the direct league API. Current profile affiliation and current-season website widgets are not historical predictors.'))
    print(json.dumps(dict(counts)),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--rebuild',action='store_true');a=p.parse_args();run(a.rebuild)
