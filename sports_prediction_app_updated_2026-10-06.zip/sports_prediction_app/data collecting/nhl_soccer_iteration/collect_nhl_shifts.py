"""Official NHL shift charts, raw first, paginated and native-ID verified."""
import argparse,collections,concurrent.futures,json,sqlite3
import pandas as pd
from common import ROOT_OUT,PREVIOUS,OfficialClient,read_db,dump,stamp

def seconds(value):
    a,b=map(int,value.split(':'));assert a>=0 and 0<=b<60;return a*60+b

def normalize(game,pages,roster):
    ids=json.loads(game['native_team_ids_json']);sides={int(t):s for t,s in zip(ids,['A','B'])};rows=[];seen=set();totals=collections.Counter();rejected=[];duration_differences=[]
    for page,source in pages:
        for i,r in enumerate(page['data']):
            assert r['id'] not in seen,'Duplicate shift ID across API pages';seen.add(r['id']);assert int(game['official_game_id'])==r['gameId'],'API game identity differs'
            if r['typeCode']!=517:continue # Goal/event markers are not shifts.
            pid=str(r['playerId']);reason=None
            if r['teamId'] not in sides:reason='Shift team absent from official game'
            elif pid not in roster:reason='Shift player absent from official boxscore'
            elif str(roster[pid]['team_id'])!=str(r['teamId']):reason='Shift player team differs from official boxscore'
            if reason:
                rejected.append(dict(shift_id=r['id'],request_number=source['request_number'],pointer='/data/'+str(i),reason=reason));continue
            start,end,duration=seconds(r['startTime']),seconds(r['endTime']),seconds(r['duration'])
            if not 0<=start<=end<=1200:
                rejected.append(dict(shift_id=r['id'],request_number=source['request_number'],pointer='/data/'+str(i),reason='Invalid within-period interval',start_seconds=start,end_seconds=end,source_duration_seconds=duration));continue
            # Preserve both raw duration and clock-derived exposure; small rounding
            # differences are evidence, not grounds for discarding a whole game.
            elapsed=end-start
            if elapsed!=duration:duration_differences.append(dict(shift_id=r['id'],source_duration_seconds=duration,clock_duration_seconds=elapsed))
            totals[pid]+=elapsed
            rows.append(dict(shift_id=r['id'],player_id=pid,team_id=str(r['teamId']),side=sides[r['teamId']],period=r['period'],shift_number=r['shiftNumber'],start_seconds=start,end_seconds=end,duration_seconds=elapsed,source_duration_seconds=duration,duration_matches_source=elapsed==duration,request_number=source['request_number'],pointer='/data/'+str(i)))
    assert rows,'Official API returned no shift intervals'
    differences=[]
    for pid,player in roster.items():
        if player.get('minutes') is not None:
            observed=totals.get(pid);expected=round(player['minutes']*60)
            if observed is None and expected==0:continue # Dressed, unused player.
            if observed is None or abs(observed-expected)>2:differences.append(dict(player_id=pid,shift_seconds=observed,boxscore_seconds=expected))
    return dict(game_id=game['game_id'],official_game_id=game['official_game_id'],date=game['date'],phase=game['phase'],available_at_utc=game['available_time'],rows=rows,sources=[s for p,s in pages],time_on_ice_discrepancies=differences,rejected_rows=rejected,duration_differences=duration_differences,parser_version=2)

def main():
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int);p.add_argument('--native-id',nargs='*');p.add_argument('--workers',type=int,default=6);p.add_argument('--schema-repairs-only',action='store_true');a=p.parse_args()
    with read_db(PREVIOUS/'expanded.sqlite') as c:
        games=[dict(r) for r in c.execute("SELECT * FROM nhl_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30' ORDER BY date,game_id")]
        people=collections.defaultdict(dict)
        for r in c.execute('SELECT game_id,official_player_id,team_id,minutes FROM nhl_player_games'):people[r['game_id']][str(r['official_player_id'])]=dict(r)
    db=sqlite3.connect(ROOT_OUT/'nhl_shifts.sqlite',timeout=60);db.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT); CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,reason TEXT);')
    done={r[0] for r in db.execute('SELECT game_id FROM games')};tasks=[g for g in games if g['game_id'] not in done and (not a.native_id or str(g['official_game_id']) in a.native_id)]
    if a.schema_repairs_only:
        repair_ids={r[0] for r in db.execute("SELECT game_id FROM issues WHERE reason!='AssertionError: Official API returned no shift intervals'")}
        tasks=[g for g in tasks if g['game_id'] in repair_ids]
    progress_file='nhl_shift_repair_progress.json' if a.schema_repairs_only else 'nhl_shift_progress.json'
    if a.limit:tasks=tasks[:a.limit]
    client=OfficialClient(per_second=3);print(json.dumps(dict(stage='nhl_shift_start',pending=len(tasks),completed=len(done),window=['2021-01-01','2026-09-30'])),flush=True)
    dump(ROOT_OUT/progress_file,dict(at_utc=stamp(),processed=0,total=len(tasks),percent=0 if tasks else 100,counts={},stage='schema_repair' if a.schema_repairs_only else ('full_window' if not a.native_id and not a.limit else 'pilot')))
    def fetch(g):
        pages=[];start=0;total=None
        try:
            while True:
                url='https://api.nhle.com/stats/rest/en/shiftcharts?cayenneExp=gameId%3D'+str(g['official_game_id'])+'&limit=1000&start='+str(start)
                d,s=client.get(url,g['date']+' NHL '+g['teamA']+' / '+g['teamB']+' player shifts, page '+str(start//1000+1),kind='official_shift_chart')
                if d is None:raise ValueError('Official API status '+s['return_status'])
                assert isinstance(d.get('data'),list) and isinstance(d.get('total'),int)
                if total is None:total=d['total']
                assert total==d['total'] and (d['data'] or total==0)
                pages.append((d,s));start+=len(d['data'])
                if start>=total:break
                assert len(pages)<20,'Unexpected shift pagination'
            assert start==total
            return g['game_id'],normalize(g,pages,people[g['game_id']]),None
        except Exception as exc:return g['game_id'],None,type(exc).__name__+': '+str(exc)
    milestone=10;counts=collections.Counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
        for n,(gid,row,error) in enumerate(pool.map(fetch,tasks),1):
            with db:
                if row:db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(gid,json.dumps(row)));db.execute('DELETE FROM issues WHERE game_id=?',(gid,));counts['games']+=1;counts['shift_rows']+=len(row['rows']);counts['games_with_toi_discrepancy']+=bool(row['time_on_ice_discrepancies'])
                else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?)',(gid,error));counts['issues']+=1
            if n*100>=milestone*len(tasks) or n==len(tasks):
                result=dict(at_utc=stamp(),processed=n,total=len(tasks),percent=round(n*100/len(tasks),1),counts=dict(counts));dump(ROOT_OUT/progress_file,result);print(json.dumps(result),flush=True);milestone+=10
    db.close()

if __name__=='__main__':main()
