"""Official before-shot context and strictly earlier-fitted nonlinear NHL xG."""
import collections
import hashlib
import json
import pickle

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import brier_score_loss, log_loss
from threadpoolctl import threadpool_limits

from common import PROJECT, ROOT_OUT, dump, stamp

RUN = ROOT_OUT / 'chance_context_v17'
NEW = ['saved_rebound_3s', 'missed_repeat_3s', 'previous_shot_gap_log',
       'previous_shot_angle_change', 'previous_shot_distance_change',
       'previous_shooter_changed', 'score_margin_before', 'period_remaining_fraction']
NUMERIC = ['log_distance', 'angle_degrees', 'distance_angle', 'inner_slot',
           'repeat_shot_3s', 'manpower_advantage', 'attackers', 'defenders'] + NEW
SHOT_TYPES = ['wrist', 'snap', 'slap', 'backhand', 'tip-in', 'deflected', 'wrap-around']


def context(raw, frame):
    lookup = frame.set_index('event_id').to_dict('index')
    assert len(lookup) == len(frame)
    ids = [str(raw['awayTeam']['id']), str(raw['homeTeam']['id'])]
    goals = [0, 0]
    previous = None
    rows = []
    for e in sorted(raw['plays'], key=lambda e: e['sortOrder']):
        kind = e['typeDescKey']
        period = e['periodDescriptor']
        if period['periodType'] == 'SO':
            continue
        details = e.get('details', {})
        if kind in {'faceoff', 'stoppage', 'period-start', 'period-end', 'game-end'}:
            previous = None
        if e['eventId'] in lookup:
            r = lookup[e['eventId']]
            owner = str(details['eventOwnerTeamId'])
            side = ids.index(owner)
            minute, second = map(int, e['timeInPeriod'].split(':'))
            elapsed = minute * 60 + second
            assert elapsed == r['seconds'] and period['number'] == r['period']
            assert kind == r['result'] and ['A', 'B'][side] == r['side']
            x, y = details.get('xCoord'), details.get('yCoord')
            angle = np.degrees(np.arctan2(y, 89 - abs(x))) if x is not None and y is not None else None
            distance = np.hypot(89 - abs(x), y) if x is not None and y is not None else None
            recent = previous and previous['period'] == period['number'] and previous['owner'] == owner
            gap = elapsed - previous['seconds'] if recent else None
            assert gap is None or gap >= 0
            recent = bool(recent and gap <= 10)
            row = dict(game_id=r['game_id'], event_id=int(e['eventId']),
                saved_rebound_3s=int(recent and gap <= 3 and previous['kind'] == 'shot-on-goal'),
                missed_repeat_3s=int(recent and gap <= 3 and previous['kind'] == 'missed-shot'),
                previous_shot_gap_log=float(np.log1p(gap)) if recent else None,
                previous_shot_angle_change=abs(angle - previous['angle']) if recent and angle is not None and previous['angle'] is not None else None,
                previous_shot_distance_change=distance - previous['distance'] if recent and distance is not None and previous['distance'] is not None else None,
                previous_shooter_changed=int(str(details.get('shootingPlayerId', details.get('scoringPlayerId'))) != previous['shooter']) if recent else None,
                score_margin_before=goals[side] - goals[1-side],
                period_remaining_fraction=(1200 - elapsed) / 1200 if period['periodType'] == 'REG' else None,
                previous_event_id=previous['event_id'] if recent else None,
                raw_sort_order=e['sortOrder'])
            rows.append(row)
            previous = dict(period=period['number'], seconds=elapsed, owner=owner, kind=kind, angle=angle, distance=distance,
                            shooter=str(details.get('shootingPlayerId', details.get('scoringPlayerId'))), event_id=e['eventId'])
        if kind == 'goal':
            side = ids.index(str(details['eventOwnerTeamId']))
            goals[side] += 1
            if 'awayScore' in details and 'homeScore' in details:
                assert goals == [details['awayScore'], details['homeScore']]
            previous = None
    assert len(rows) == len(frame)
    return pd.DataFrame(rows)


def enrich():
    source = ROOT_OUT / 'nhl_shot_detail.parquet'
    shots = pd.read_parquet(source)
    shots = shots[shots.phase.isin(['Regular Season', 'Playoffs']) & shots.date.ge('2021-01-01')].copy()
    groups = list(shots.groupby('game_id', sort=False))
    extras = []
    mark = 10
    for i, (gid, frame) in enumerate(groups, 1):
        assert frame.source_raw_file.nunique() == 1 and frame.source_sha256.nunique() == 1
        raw = (PROJECT / frame.source_raw_file.iloc[0]).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == frame.source_sha256.iloc[0]
        extra = context(json.loads(raw), frame)
        extras.append(extra)
        if i * 100 >= mark * len(groups):
            print(json.dumps(dict(stage='nhl_shot_context', percent=i * 100 // len(groups), games=i, total=len(groups))), flush=True)
            mark = i * 100 // len(groups) // 10 * 10 + 10
    shots = shots.merge(pd.concat(extras, ignore_index=True), on=['game_id', 'event_id'], validate='one_to_one')
    shots.to_parquet(RUN / 'nhl_shot_context.parquet', index=False)
    dump(RUN / 'context_audit.json', dict(at_utc=stamp(), games=len(groups), events=len(shots), source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        definitions='Previous recorded same-team shot within 10 elapsed seconds, same period, without intervening faceoff/stoppage/goal. Saved rebound and missed-shot repeat require <=3s. Angle change is absolute signed shooting-angle change; score is before current event. These are observed proxies, not an asserted pass or rush.',
        raw_hashes_checked=len(groups), new_fields=NEW,
        missing_pct={col: float(100 * shots[col].isna().mean()) for col in NEW}))
    return shots


def matrix(shots):
    x = shots[NUMERIC].copy()
    for kind in SHOT_TYPES:
        x['shot_type_' + kind] = shots.shot_type.eq(kind).astype(float)
    x['shot_type_other'] = (~shots.shot_type.isin(SHOT_TYPES)).astype(float)
    return x


def fit(shots):
    eligible = shots.defending_goalie_present.eq(1) & shots.distance_ft.notna() & shots.angle_degrees.notna()
    x = matrix(shots)
    # First-year monthly fits use accumulated observations instead of leaving
    # an entire year empty. Later years retain the prior-year comparison cadence.
    shots = shots.copy()
    shots['context_xg'] = np.nan
    shots['context_model_cutoff_utc'] = None
    periods = [(f'2021-{m:02d}', pd.Timestamp(f'2021-{m:02d}-01', tz='UTC'),
                pd.Timestamp(f'2021-{m:02d}-01', tz='UTC') + pd.offsets.MonthBegin(1)) for m in range(1, 13)]
    periods += [(str(y), pd.Timestamp(f'{y}-01-01', tz='UTC'), pd.Timestamp(f'{y+1}-01-01', tz='UTC')) for y in range(2022, 2027)]
    audit = []
    (RUN / 'shot_models').mkdir(exist_ok=True)
    for label, boundary, end in periods:
        train = eligible & shots.available_time.lt(boundary)
        test = eligible & shots.start_time.ge(boundary) & shots.start_time.lt(end)
        if not test.any():
            continue
        if train.sum() < 10000:
            audit.append(dict(period=label, training_shots=int(train.sum()), eligible_test_shots=int(test.sum()), status='Insufficient earlier shots for predeclared minimum 10000'))
            continue
        path = RUN / 'shot_models' / (label + '.pkl')
        model = HistGradientBoostingClassifier(max_iter=150, max_leaf_nodes=15, max_depth=4,
            learning_rate=.06, l2_regularization=10, min_samples_leaf=100, max_bins=64,
            early_stopping=False, random_state=42)
        with threadpool_limits(limits=3):
            model.fit(x.loc[train], shots.loc[train, 'goal'])
            probability = model.predict_proba(x.loc[test])[:, 1]
        path.write_bytes(pickle.dumps(model, protocol=5))
        shots.loc[test, 'context_xg'] = probability
        shots.loc[test, 'context_model_cutoff_utc'] = boundary.isoformat()
        y = shots.loc[test, 'goal'].to_numpy(int)
        old = shots.loc[test, 'model_xg']
        valid = old.notna().to_numpy()
        row = dict(period=label, training_shots=int(train.sum()), training_max_available_utc=shots.loc[train, 'available_time'].max(),
                   test_shots=int(test.sum()), prediction_cutoff_utc=boundary, mean_probability=float(probability.mean()),
                   goal_rate=float(y.mean()), log_loss=float(log_loss(y, probability, labels=[0, 1])),
                   brier=float(brier_score_loss(y, probability)), old_comparison_shots=int(valid.sum()),
                   old_log_loss=float(log_loss(y[valid], old[valid], labels=[0, 1])) if valid.any() else None,
                   new_same_sample_log_loss=float(log_loss(y[valid], probability[valid], labels=[0, 1])) if valid.any() else None,
                   status='fitted')
        assert row['training_max_available_utc'] < boundary
        audit.append(row)
        dump(RUN / 'shot_fit_audit.json', audit)
        print(json.dumps({k: str(v) if isinstance(v, pd.Timestamp) else v for k, v in row.items()}), flush=True)
    shots.to_parquet(RUN / 'nhl_shot_context.parquet', index=False)
    dump(RUN / 'shot_fit_audit.json', audit)
    return shots


def main():
    RUN.mkdir(exist_ok=True)
    plan = dict(created_at_utc=stamp(), history_start='2021-01-01', game_prediction_test_start='2024-01-01',
        goal='Test whether nonlinear shot geometry and observed saved-shot rebound context improve earlier player/team quality estimates.',
        shot_inputs=NUMERIC + ['fixed shot-type indicators'], shot_hyperparameters=dict(iterations=150, leaves=15, depth=4, rate=.06, l2=10, minimum_leaf=100, bins=64),
        timing='2021 monthly fit once 10000 earlier shots exist; 2022 onward prior-year expanding fits. Raw result is target only, never a shot input.',
        comparison='Do not overwrite original xG or game-model baselines. Game-model variants selected on 2024-25 only, then researched 2026 diagnosed.',
        costs='No changed quote timing, stake size, transaction costs or app models.')
    path = RUN / 'plan.json'
    if path.exists():
        old = json.loads(path.read_text())
        assert {k: v for k, v in old.items() if k != 'created_at_utc'} == {k: v for k, v in plan.items() if k != 'created_at_utc'}
    else:
        dump(path, plan)
    context_path = RUN / 'nhl_shot_context.parquet'
    shots = pd.read_parquet(context_path) if context_path.exists() else enrich()
    if 'context_xg' not in shots:
        fit(shots)


if __name__ == '__main__':
    main()
