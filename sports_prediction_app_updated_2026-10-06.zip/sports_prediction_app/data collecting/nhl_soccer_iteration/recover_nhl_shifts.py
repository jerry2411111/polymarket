"""Recover empty shift APIs from official home/visitor time-on-ice reports.

HTML fallback is used only after the official API is demonstrably insufficient.
Native player IDs come from the same game's official roster; no fuzzy matching.
Unresolved reports/rows stay in an explicit retry ledger. Raw responses are kept.
"""
import argparse,collections,concurrent.futures,datetime as dt,json,re,sqlite3
from common import ROOT_OUT,PREVIOUS,OfficialClient,read_db,dump,stamp
from collect_nhl_shifts import normalize,seconds
from validate_shifts import text,key


def report_rows(game,body,source,side,roster,identity=None):
    markup=body.decode('utf8',errors='replace');native=str(game['official_game_id'])
    date=dt.date.fromisoformat(game['date']);visible=text(markup)
    header=re.search(r'<table[^>]*id="GameInfo".*?</table>',markup,re.S)
    numbers=re.findall(r'\bGame\s+(\d+)\b',text(header.group(0))) if header else []
    assert len(numbers)==1 and int(numbers[0])==int(native[-4:]),'Report game number mismatch'
    assert f'{date.strftime("%B")} {date.day}, {date.year}' in visible,'Report game date mismatch'
    team_heading=re.search(r'<td[^>]*class="teamHeading[^\"]*"[^>]*>(.*?)</td>',markup,re.S)
    assert team_heading and key(text(team_heading.group(1)))==key(game['team'+side]),'Report team identity mismatch'
    team_id=str(json.loads(game['native_team_ids_json'])[0 if side=='A' else 1])
    headings=list(re.finditer(r'<td[^>]*class="playerHeading[^\"]*"[^>]*>(.*?)</td>',markup,re.S))
    assert headings,'Report has no player headings'
    rows=[];unresolved=[];differences=[];players=[]
    for i,m in enumerate(headings):
        heading=text(m.group(1));name=re.sub(r'^\d+\s+','',heading);parts=name.split(',')
        name=parts[1].strip()+' '+parts[0].strip() if len(parts)==2 else name
        matches=[pid for pid,r in roster.items() if str(r['team_id'])==team_id and key(r['player_name'])==key(name)]
        identity_number=None
        if len(matches)!=1 and identity:
            box,identity_source=identity;number=int(heading.split()[0]);last=key(parts[0]);initial=key(parts[1])[:1] if len(parts)==2 else ''
            official_side='awayTeam' if side=='A' else 'homeTeam'
            assert str(box[official_side]['id'])==team_id
            candidates=[]
            for group in box['playerByGameStats'][official_side].values():
                if not isinstance(group,list):continue
                for player in group:
                    label=key(player.get('name',{}).get('default',''));pid=str(player['playerId'])
                    # Full first names and familiar names can differ (Anthony/Tony).
                    # Require the same dated team, exact surname and unique jersey.
                    if player.get('sweaterNumber')==number and label.endswith(last) and pid in roster:
                        candidates.append(pid)
            matches=list(set(candidates));identity_number=identity_source['request_number']
        if len(matches)!=1:
            unresolved.append(dict(pointer=f'playerHeading[{i}]',name=heading,reason='No unique exact name in dated official team roster'));continue
        pid=matches[0];players.append(pid)
        section=markup[m.end():headings[i+1].start() if i+1<len(headings) else len(markup)]
        for j,tr in enumerate(re.findall(r'<tr class="\s*(?:oddColor|evenColor)[^\"]*"[^>]*>(.*?)</tr>',section,re.S)):
            cells=[text(v) for v in re.findall(r'<td[^>]*>(.*?)</td>',tr,re.S)]
            if len(cells)<5 or not cells[0].isdigit() or '/' not in cells[2]:continue
            pointer=f'playerHeading[{i}]/shiftRow[{j}]'
            try:
                overtime=re.fullmatch(r'(\d*)OT',cells[1])
                if cells[1].isdigit():period=int(cells[1])
                elif overtime:period=3+int(overtime.group(1) or 1)
                else:raise ValueError('Unrecognized report period '+cells[1])
                start=seconds(cells[2].split('/')[0].strip());end=seconds(cells[3].split('/')[0].strip());duration=seconds(cells[4])
                assert 0<=start<=end<=1200,'Invalid within-period interval'
            except (ValueError,AssertionError) as exc:
                unresolved.append(dict(pointer=pointer,player_id=pid,reason=str(exc),source_cells=cells));continue
            row=dict(shift_id=None,source_row_key=f'{native}:{side}:{pid}:{cells[0]}:{cells[1]}',player_id=pid,
                     team_id=team_id,side=side,period=period,shift_number=int(cells[0]),start_seconds=start,
                     end_seconds=end,duration_seconds=end-start,source_duration_seconds=duration,duration_matches_source=end-start==duration,
                     request_number=source['request_number'],pointer=pointer,source_kind='official_html_time_on_ice',identity_request_number=identity_number)
            rows.append(row)
            if duration!=end-start:differences.append(dict(source_row_key=row['source_row_key'],source_duration_seconds=duration,clock_duration_seconds=end-start))
    assert len({r['source_row_key'] for r in rows})==len(rows),'Duplicate report shift row'
    totals=collections.Counter()
    for r in rows:totals[r['player_id']]+=r['duration_seconds']
    toi=[]
    for pid,p in roster.items():
        if str(p['team_id'])!=team_id or p.get('minutes') is None:continue
        expected=round(p['minutes']*60);observed=totals.get(pid)
        if expected==0 and observed is None:continue
        if observed is None or abs(expected-observed)>2:toi.append(dict(player_id=pid,shift_seconds=observed,boxscore_seconds=expected))
    return rows,unresolved,differences,toi,players


def main():
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int);p.add_argument('--workers',type=int,default=4)
    p.add_argument('--native-id',nargs='*');p.add_argument('--retry-api',action='store_true');p.add_argument('--reparse-recovered',action='store_true');p.add_argument('--repair-rejected-rows',action='store_true');a=p.parse_args()
    with read_db(PREVIOUS/'expanded.sqlite') as c:
        games={r['game_id']:dict(r) for r in c.execute("SELECT * FROM nhl_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30'")}
        people=collections.defaultdict(dict)
        for r in c.execute('SELECT game_id,official_player_id,player_name,team_id,minutes FROM nhl_player_games'):people[r['game_id']][str(r['official_player_id'])]=dict(r)
    db=sqlite3.connect(ROOT_OUT/'nhl_shifts.sqlite',timeout=60)
    db.execute('CREATE TABLE IF NOT EXISTS recovery_attempts(game_id TEXT PRIMARY KEY,checked_at_utc TEXT,body TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS normalization_history(game_id TEXT,archived_at_utc TEXT,body TEXT)')
    tasks=[games[r[0]] for r in db.execute('SELECT game_id FROM issues') if r[0] in games]
    if a.reparse_recovered:
        tasks=[games[r[0]] for r in db.execute("SELECT game_id FROM games WHERE json_extract(body,'$.recovery_method')='official_report_after_insufficient_api' AND json_extract(body,'$.parser_version')<4")]
    if a.repair_rejected_rows:
        tasks=[games[r[0]] for r in db.execute("SELECT game_id FROM games WHERE json_array_length(body,'$.rejected_rows')>0")]
    if a.native_id:tasks=[g for g in tasks if str(g['official_game_id']) in a.native_id]
    tasks.sort(key=lambda g:(g['phase']!='Regular Season',g['date'],g['game_id']))
    if a.limit:tasks=tasks[:a.limit]
    client=OfficialClient(per_second=2);counts=collections.Counter();milestone=10
    def fetch(g):
        native=str(g['official_game_id']);roster=people[g['game_id']];sources=[];errors=[];rows=[];unresolved=[];differences=[];toi=[];sides=[]
        try:
            url=f'https://api.nhle.com/stats/rest/en/shiftcharts?cayenneExp=gameId%3D{native}&limit=1000&start=0'
            d,s=client.get(url,'Recheck empty NHL shift response: '+native,kind='official_shift_chart',refresh=a.retry_api);sources.append(s)
            if d and d.get('data') and not a.repair_rejected_rows:
                pages=[(d,s)];offset=len(d['data']);total=d['total']
                while offset<total:
                    page,source=client.get(url.replace('start=0','start='+str(offset)),'Recover NHL shift pagination: '+native,kind='official_shift_chart',refresh=a.retry_api)
                    assert page and page['data'] and page['total']==total
                    pages.append((page,source));offset+=len(page['data'])
                assert offset==total
                row=normalize(g,pages,roster)
                return g['game_id'],row,dict(method='official_api_retry',sources=row['sources'],errors=[],unresolved_rows=[])
        except Exception as exc:errors.append(dict(route='api',reason=type(exc).__name__+': '+str(exc)))
        for side,code in [('A','TV'),('B','TH')]:
            season=int(native[:4]);url=f'https://www.nhl.com/scores/htmlreports/{season}{season+1}/{code}{native[4:]}.HTM'
            try:
                body,source=client.get(url,'Recover '+g['team'+side]+' NHL shifts from official report: '+native,kind='official_shift_report',document=True);sources.append(source)
                if body is None:raise ValueError('HTTP '+source['return_status'])
                parsed,bad,diff,discrepancy,players=report_rows(g,body,source,side,roster)
                if any(r['reason']=='No unique exact name in dated official team roster' for r in bad):
                    box,bm=client.get(f'https://api-web.nhle.com/v1/gamecenter/{native}/boxscore','Resolve report full name with dated sweater number and native player ID: '+native,kind='official_player_identity')
                    sources.append(bm);assert box and str(box['id'])==native
                    parsed,bad,diff,discrepancy,players=report_rows(g,body,source,side,roster,identity=(box,bm))
                rows.extend(parsed);unresolved.extend([r|dict(request_number=source['request_number']) for r in bad]);differences.extend(diff);toi.extend(discrepancy);sides.append(side)
            except Exception as exc:errors.append(dict(side=side,url=url,reason=type(exc).__name__+': '+str(exc)))
        # A complete game needs both official reports and all usable player rows.
        # Partial responses are retained in the recovery ledger for further work.
        attempt=dict(method='official_report_after_insufficient_api',sources=sources,errors=errors,unresolved_rows=unresolved,
                     report_sides=sides,recovered_shift_rows=len(rows),time_on_ice_discrepancies=toi)
        if set(sides)!={'A','B'} or not rows or unresolved:
            attempt['partial_rows']=rows
            return g['game_id'],None,attempt
        result=dict(game_id=g['game_id'],official_game_id=native,date=g['date'],phase=g['phase'],available_at_utc=g['available_time'],
                    rows=rows,sources=sources,time_on_ice_discrepancies=toi,rejected_rows=[],duration_differences=differences,parser_version=4,
                    recovery_method='official_report_after_insufficient_api')
        return g['game_id'],result,attempt
    print(json.dumps(dict(stage='official_shift_recovery',total=len(tasks))),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
        for n,(gid,row,attempt) in enumerate(pool.map(fetch,tasks),1):
            with db:
                db.execute('INSERT OR REPLACE INTO recovery_attempts VALUES (?,?,?)',(gid,stamp(),json.dumps(attempt)))
                if row:
                    prior=db.execute('SELECT body FROM games WHERE game_id=?',(gid,)).fetchone()
                    if prior:db.execute('INSERT INTO normalization_history VALUES (?,?,?)',(gid,stamp(),prior[0]))
                    db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(gid,json.dumps(row)))
                    db.execute('DELETE FROM issues WHERE game_id=?',(gid,));counts['recovered_games']+=1;counts['recovered_shifts']+=len(row['rows'])
                else:counts['unresolved_games']+=1
            if n*100>=milestone*len(tasks) or n==len(tasks):
                report=dict(at_utc=stamp(),processed=n,total=len(tasks),percent=round(100*n/len(tasks),1),counts=dict(counts))
                dump(ROOT_OUT/'nhl_shift_recovery_progress.json',report);print(json.dumps(report),flush=True);milestone+=10
    db.close()


if __name__=='__main__':main()
