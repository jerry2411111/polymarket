"""Replay derived Bundesliga minutes from original official JSON and identities."""
import collections,hashlib,json
from common import PROJECT,ROOT_OUT,PREVIOUS,read_db,dump,stamp
from collect_bundesliga_minutes import parse


def main():
    with read_db(PREVIOUS/'expanded.sqlite') as c:games={r['game_id']:dict(r) for r in c.execute("SELECT * FROM soccer_games WHERE league='Bundesliga'")}
    with read_db(ROOT_OUT/'bundesliga_minutes.sqlite') as c:
        rows=[json.loads(b) for b, in c.execute('SELECT body FROM games')];request_issues=[dict(r) for r in c.execute('SELECT * FROM issues')]
    years=collections.Counter();complete=0;issues=[];examples=[]
    for record in rows:
        data=[]
        for source in record['sources']:
            blob=(PROJECT/source['raw_file']).read_bytes();assert hashlib.sha256(blob).hexdigest()==source['sha256'];data.append(json.loads(blob))
        fresh=parse(games[record['game_id']],*data,*record['sources'],staff_evidence=record.get('staff_identity_evidence'));assert fresh==record
        assert len({r['official_player_id'] for r in record['players']})==len(record['players'])
        for row in record['players']:
            assert row['minutes'] is None or 0<=row['minutes']<=90
            if row['minutes_complete']:
                assert row['played'] is not None and row['minutes'] is not None
                if row['played'] is False:assert row['minutes']==0
                complete+=1
        if not years[record['date'][:4]]:
            examples.append(dict(game_id=record['game_id'],date=record['date'],source=record['sources'][0],players=[{key:r[key] for key in ['player_name','official_player_id','side','started','played','minutes']} for r in record['players']]))
        years[record['date'][:4]]+=1
        issues.extend(dict(game_id=record['game_id'],**r) for r in record['issues'])
    report=dict(at_utc=stamp(),status='PASS',games=len(rows),player_rows=sum(len(r['players']) for r in rows),complete_minutes_rows=complete,
        games_by_year=dict(years),retained_event_issues=issues,request_or_schema_issues=request_issues,examples=examples,
        units='Regulation minutes, minute resolution, stoppage excluded; explicit unused-substitute zero requires a consistent complete timeline.',
        checks='Raw hashes, official game/team/date/final score, dated native player IDs, eleven starters, substitution sequence, dismissals, team-minute conservation and exact normalized replay.')
    dump(ROOT_OUT/'bundesliga_minutes_validation.json',report)
    print(json.dumps({k:v for k,v in report.items() if k not in ['examples','retained_event_issues','request_or_schema_issues']}),flush=True)


if __name__=='__main__':main()
