"""Loss-motivated, source-timed correction of recent player-pool features.

Keep learner and betting rule fixed. A complete, predecision official called-up
squad can exclude recent contributors; it cannot establish the starting XI.
No fitted artefacts are retained unless separately adopted.
"""
import argparse
import collections
import copy
import json
import pickle
import re
import unicodedata
import numpy as np
import pandas as pd
from common import ROOT_OUT,PROJECT,read_db,dump,stamp,file_sha256

LABEL='soccer_squad_model'
WORK=ROOT_OUT/'_work'/LABEL
RESULT=ROOT_OUT/'simulation_results'/LABEL
REFERENCE=ROOT_OUT/'simulation_results/feature_revisions/soccer_club_strength'
FIELDS=['goals','assists','key_passes','distance_covered_km','challenges_won','shots_at_goal']
PHYSICAL=FIELDS[3:]


def tokens(value):
    from soccer_identity_repair import decoded
    return tuple(re.sub('[^a-z0-9 ]',' ',unicodedata.normalize('NFKD',decoded(str(value))).encode('ascii','ignore').decode().lower()).split())


def name_matches(short,full):
    a,b=tokens(short),tokens(full)
    return bool(a) and all(any(x==y or (len(x)==1 and y.startswith(x)) for y in b) for x in a)


def aliases():
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
        records=[dict(r) for r in db.execute('SELECT * FROM _eu_documented_player_aliases')]
    result=collections.defaultdict(list)
    for r in records:result[r['source_person_id']].append(r['alias'])
    path=RESULT/'documented_name_aliases.json'
    assert path.exists(),'Validate registered/playing-name aliases before absence inference'
    additional=json.loads(path.read_bytes())
    for r in additional['rows']:
        assert file_sha256(PROJECT/r['source']['raw_file'])==r['source']['sha256']
        result[r['player_id']].append(r['alias'])
    records+=additional['rows']
    return result,records


def collect_aliases():
    """Manual official-page identity validation where match API omits nicknames."""
    from common import OfficialClient
    from html.parser import HTMLParser
    if not (WORK/'players.pkl').exists():
        import loss_case_revision as case
        case.WORK=WORK;case.RESULT=RESULT;case.sources()
    class Visible(HTMLParser):
        def __init__(self):super().__init__();self.skip=0;self.parts=[]
        def handle_starttag(self,tag,attrs):
            if tag in ['script','style']:self.skip+=1
        def handle_endtag(self,tag):
            if tag in ['script','style'] and self.skip:self.skip-=1
        def handle_data(self,data):
            if not self.skip:self.parts.append(data)
    jobs=[
        ('EU_LAL:p88477','Nacho','José Ignacio Fernández Iglesias','https://www.realmadrid.com/es-ES/el-club/historia/leyendas-futbol/jose-ignacio-fernandez-iglesias'),
        ('EU_LAL:p61316','Joselu','José Luis Mato Sanmartín','https://rfef.es/es/noticias/joselu-se-convierte-tras-puskas-en-el-jugador-mas-veterano-en-debutar-con-la-absoluta'),
        ('EU_LAL:p592984','Chema','José María Andrés Baixauli','https://www.realmadrid.com/es-ES/el-club/historia/leyendas-futbol/jose-maria-andres-baixauli'),
        ('EU_UCL:250153621','Nico Paz','Nicolás Paz','https://www.realmadrid.com/en-US/football/academy/castilla/nicolas-paz-martinez')]
    OfficialClient.HOSTS.update({'www.realmadrid.com','rfef.es'});client=OfficialClient()
    p=pd.read_pickle(WORK/'players.pkl');rows=[]
    for pid,alias,registered,url in jobs:
        raw,src=client.get(url,'Verify announced nickname and registered name omitted by match API; static identity only','official_player_alias_validation',document=True)
        assert raw is not None,src['return_status']
        visible=Visible();visible.feed(raw.decode('utf8'));body=' '.join(tokens(' '.join(visible.parts)))
        assert ' '.join(tokens(alias)) in body and ' '.join(tokens(registered)) in body,(pid,url)
        historical=p[p.player_id.eq(pid)].player_name.drop_duplicates()
        assert any(tokens(registered)==tokens(n) for n in historical),(pid,registered)
        rows.append(dict(player_id=pid,alias=alias,registered_name=registered,source=src,
            purpose='Static documented playing name for the existing native-ID record; no career/availability facts or current statistics imported. No cross-ID merge.'))
    dump(RESULT/'documented_name_aliases.json',dict(status='PASS',at_utc=stamp(),rows=rows,
        official_api_insufficiency='Dated match source gives registered name without the nickname in the squad announcement. Official public club/federation pages manually validate both names.'))
    print(json.dumps(dict(stage='aliases',verified=len(rows))),flush=True)


def derive(g,p,keys,reports,names):
    """Past-only player rates; ambiguous announced-name matches stay included."""
    evidence_aliases,alias_records=aliases()
    named={rid:f.to_dict('records') for rid,f in names.groupby('report_id')}
    allowed=reports[reports.available_by_pre12].copy()
    allowed['available_after_utc']=pd.to_datetime(allowed.available_after_utc,utc=True,format='mixed')
    allowed=allowed.sort_values(['available_after_utc','report_id']).drop_duplicates(['game_id','side'],keep='last')
    announcement={(r.game_id,r.side):r for r in allowed.itertuples()}
    selected=set(allowed.game_id)
    player_rows=collections.defaultdict(list)
    keep=['game_id','side','player_id','official_player_id','player_name','position','minutes','available_at_utc']+FIELDS
    for row in p[keep].to_dict('records'):player_rows[row['game_id'],row['side']].append(row)
    hist=collections.defaultdict(lambda:collections.deque(maxlen=5))
    phist=collections.defaultdict(lambda:collections.deque(maxlen=30));last_team={}
    numerator=collections.Counter();denominator=collections.Counter()
    events=g.sort_values(['available_time','game_id']).to_dict('records');pos=0
    out=[];audit=[];membership=[]
    for game in g.sort_values(['prediction_time','game_id']).itertuples():
        while pos<len(events) and events[pos]['available_time']<game.prediction_time:
            old=events[pos];pos+=1
            for side in ['A','B']:
                team=keys[old['game_id'],side];observed=[]
                for pl in player_rows[old['game_id'],side]:
                    minutes=pl['minutes']
                    if minutes is None or not np.isfinite(minutes) or minutes<=0:continue
                    assert pd.Timestamp(pl['available_at_utc'])<=old['available_time']
                    pid=pl['player_id'];phist[pid].append(pl);last_team[pid]=team;observed.append((pid,minutes))
                    for field in PHYSICAL:
                        value=pl[field]
                        if value is not None and np.isfinite(value):
                            numerator[field]+=value;denominator[field]+=minutes
                hist[team].append(observed)
        if game.game_id not in selected:continue
        values={};row={'game_id':game.game_id}
        for side in ['A','B']:
            team=keys[game.game_id,side];weights=collections.defaultdict(float)
            for old in hist[team]:
                for pid,minutes in old:
                    if last_team.get(pid)==team:weights[pid]+=minutes
            report=announcement.get((game.game_id,side));revised=dict(weights)
            if report:
                assert report.available_after_utc<=game.prediction_time
                roster_names=named[report.report_id]
                for pid,weight in weights.items():
                    past=phist[pid];native_names={x['player_name'] for x in past}|set(evidence_aliases.get(pid,[]))
                    positions={str(x['position']).upper() for x in past}
                    matched=[]
                    for nm in roster_names:
                        if nm['position_group']=='porteros' and not positions.intersection({'GK','G','1','GOALKEEPER'}):continue
                        if nm['position_group'] and nm['position_group']!='porteros' and positions.issubset({'GK','G','1','GOALKEEPER'}):continue
                        if any(name_matches(nm['player_name_raw'],fullname) for fullname in native_names):matched.append(nm['player_name_raw'])
                    # An abbreviation compatible with two earlier player IDs
                    # retains both; do not assert identity or an absence.
                    included=bool(matched)
                    if not included:revised.pop(pid)
                    membership.append(dict(game_id=game.game_id,side=side,report_id=report.report_id,
                        cutoff_utc=game.prediction_time,squad_available_utc=report.available_after_utc,
                        player_id=pid,player_name=past[-1]['player_name'],prior_names_json=json.dumps(sorted(native_names),ensure_ascii=False),
                        recent_minutes=weight,in_announced_squad=included,matched_announced_names_json=json.dumps(matched,ensure_ascii=False),
                        latest_stat_utc=max(pd.Timestamp(z['available_at_utc']) for z in past)))
            for mode,ww in [('reference',weights),('candidate',revised)]:
                total=sum(ww.values());values[side,mode,'players']=len(ww)
                for field in FIELDS:
                    rates=[];clocks=[]
                    for pid,weight in ww.items():
                        obs=[z for z in phist[pid] if z[field] is not None and np.isfinite(z[field])]
                        if not obs:continue
                        rates.append((weight,90*sum(z[field] for z in obs)/sum(z['minutes'] for z in obs)))
                        clocks.extend(pd.Timestamp(z['available_at_utc']) for z in obs)
                    if field in PHYSICAL:
                        prior=90*numerator[field]/denominator[field] if denominator[field] else np.nan
                        value=prior+sum(w*(v-prior) for w,v in rates)/total if total and np.isfinite(prior) else prior
                    else:value=sum(w*v for w,v in rates)/sum(w for w,v in rates) if rates else np.nan
                    assert not clocks or max(clocks)<game.prediction_time
                    values[side,mode,field]=value
                    audit.append(dict(game_id=game.game_id,side=side,mode=mode,field=field,rate_per90=value,
                        roster_players=len(ww),roster_minutes=total,report_id=report.report_id if report else None,
                        latest_stat_utc=max(clocks) if clocks else None,cutoff_utc=game.prediction_time))
            for mode in ['reference','candidate']:
                row[mode+'_players_'+side]=values[side,mode,'players']
        for mode in ['reference','candidate']:
            for field in FIELDS:row[mode+'_f_ctx_roster_'+field+'_rate_diff']=values['B',mode,field]-values['A',mode,field]
            row[mode+'_f_ctx_roster_players_diff']=values['B',mode,'players']-values['A',mode,'players']
        out.append(row)
    return pd.DataFrame(out).set_index('game_id'),pd.DataFrame(audit),pd.DataFrame(membership),alias_records


def build():
    import loss_case_revision as case
    from soccer_club_strength import coefficients,FEATURES
    assert not (RESULT/'validation.json').exists()
    case.WORK=WORK;case.RESULT=RESULT
    if not (WORK/'sources_ready.json').exists():case.sources()
    if not (WORK/'features_ready.json').exists():case.build()
    g,_,p,_,keys,_=case.load_sources()
    reports=pd.read_parquet(ROOT_OUT/'soccer_squad_reports.parquet')
    names=pd.read_parquet(ROOT_OUT/'soccer_squad_report_players.parquet')
    proof=json.loads((ROOT_OUT/'simulation_results/soccer_squad_availability/validation.json').read_bytes())
    for table in proof['tables']:assert table['sha256']==file_sha256(ROOT_OUT/(table['table']+'.parquet'))
    frame=pd.read_parquet(WORK/'candidate/soccer_features.parquet').set_index('game_id')
    ranking=pd.read_parquet(ROOT_OUT/'soccer_uefa_club_coefficients.parquet')
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
        registry={(code,str(native)):json.loads(body) for code,native,body in db.execute('SELECT * FROM _eu_team_identity')}
    coef,_=coefficients(g,ranking,registry);frame=frame.join(coef,validate='one_to_one')
    recipe=copy.deepcopy(json.loads((REFERENCE/'experiment_plan.json').read_bytes())['recipe'])
    dump(RESULT/'experiment_plan.json',dict(at_utc=stamp(),hypothesis='Some recent player contributions belong to players explicitly omitted from an already announced travelling squad. Recompute existing rates using called-up members of that recent pool.',
        features='Seven existing recent-roster rates/count; no new coefficient or outcome-selected cutoff.',recipe=recipe,
        unchanged='41-input club-strength learner, scaling, calibration and monthly expanding training from2021. Existing baseline preserved.',
        scope='Every published and uniquely matched squad available bypre12, not only losing matches. Announcement body and revision time both required.',
        membership='Accent/abbreviation normalization of earlier official player names; separately documented club nicknames. Ambiguous compatible names retain all possible existing IDs. No native IDs invented for new youth players.',
        limitation='Remaining recent-player pool only; announcement does not confirm starter choices or assign unseen players a historical rate.',
        gate='Lower pooled2024/25multiclass logloss AND Brier than identical41-input reference; evaluate2026only if both improve.',
        staking='Identical$5per probability-percentage-point positive edge, pre12, one outcome, providers separate, cash-only$2000annual start, no costs.',
        evaluation='2026 repeatedly inspected; retrospective rolling evaluation, not untouched.',app_changed=False))
    derived,audit,members,aliases_used=derive(g,p,keys,reports,names)
    columns=[c.removeprefix('candidate_') for c in derived if c.startswith('candidate_f_')]
    for c in columns:
        assert np.allclose(derived['reference_'+c],frame.loc[derived.index,c],atol=1e-10,rtol=0,equal_nan=True),c
    changed=frame.copy()
    for c in columns:changed.loc[derived.index,c]=derived['candidate_'+c]
    assert changed.drop(columns=columns).equals(frame.drop(columns=columns))
    assert changed.loc[~changed.index.isin(derived.index)].equals(frame.loc[~frame.index.isin(derived.index)])
    # Recompute an earlier prefix with all later source games and squads gone.
    cut=pd.Timestamp('2025-01-01',tz='UTC');gg=g[g.prediction_time.lt(cut)]
    gp=g[g.available_time.lt(cut)|g.game_id.isin(gg.game_id)]
    rp=reports[pd.to_datetime(reports.available_after_utc,utc=True,format='mixed').lt(cut)]
    prefix,_,_,_=derive(gp,p[p.game_id.isin(gp.game_id)],keys,rp,names[names.report_id.isin(rp.report_id)])
    common=prefix.index.intersection(derived.index)
    pd.testing.assert_frame_equal(prefix.loc[common],derived.loc[common],check_exact=True)
    assert members.latest_stat_utc.lt(members.cutoff_utc).all()
    assert members.squad_available_utc.le(members.cutoff_utc).all()
    work=WORK/'squad';work.mkdir(exist_ok=True);changed.reset_index().to_parquet(work/'soccer_features.parquet',index=False)
    audit.to_parquet(RESULT/'feature_evidence.parquet',index=False);members.to_parquet(RESULT/'player_membership.parquet',index=False)
    members.to_csv(RESULT/'player_membership.csv',index=False)
    derived.reset_index().to_parquet(RESULT/'feature_changes.parquet',index=False)
    dump(RESULT/'feature_validation.json',dict(status='PASS',at_utc=stamp(),all_games=len(frame),affected_games=len(derived),
        report_count=members.report_id.nunique(),player_membership_rows=len(members),prefix_replayed_games=len(common),
        unchanged_other_games_and_features=True,prior_feature_rates_reproduced=True,
        documented_aliases=aliases_used,source_table_validation=proof,
        source_feature_sha256=file_sha256(work/'soccer_features.parquet'),changed_columns=columns))
    print(json.dumps(dict(stage='features',games=len(frame),squad_games=len(derived),members=len(members))),flush=True)


def train():
    import models
    from sklearn.metrics import log_loss
    import soccer_club_history_model as paired
    import soccer_tie_context as simulation
    assert (RESULT/'feature_validation.json').exists() and not (RESULT/'validation.json').exists()
    recipe=json.loads((RESULT/'experiment_plan.json').read_bytes())['recipe']
    name='announced_squad_pool';models.CANDIDATES[name]=recipe;models.OUT=WORK/'squad'
    candidate=models.run('soccer','development',[name]);candidate['variant']='candidate'
    reference=pd.read_parquet(REFERENCE/'development_predictions.parquet')
    reference=reference[reference.variant.eq('candidate')].copy();reference['variant']='reference'
    joined=pd.concat([candidate,reference],ignore_index=True)
    joined.to_parquet(RESULT/'development_predictions.parquet',index=False);models.metrics(joined).to_csv(RESULT/'development_metrics.csv',index=False)
    scores={}
    for variant,f in joined.groupby('variant'):
        p=f[['p0','p1','p2']].to_numpy();y=f.target.to_numpy(int)
        scores[variant]=dict(log_loss=log_loss(y,p,labels=[0,1,2]),brier=float(np.mean(np.sum((p-np.eye(3)[y])**2,axis=1))))
    passed=all(scores['candidate'][m]<scores['reference'][m] for m in ['log_loss','brier'])
    paired.RESULT=RESULT;delta=paired.paired_comparison(candidate,reference)
    dump(RESULT/'selection.json',dict(at_utc=stamp(),passed=bool(passed),scores=scores,paired=delta,adopted=False))
    package=pickle.loads((WORK/'squad/model_runs/soccer/development'/(name+'.pkl')).read_bytes())
    frame=pd.read_parquet(WORK/'squad/soccer_features.parquet');matrix=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
    sample=candidate[candidate.fold.eq(package['boundary'].strftime('%Y-%m'))].head(20)
    xx=matrix.loc[sample.game_id,package['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
    replay=models.apply_calibration(package['model'].predict_proba(xx),package['calibrator'])
    assert np.allclose(replay,sample[['p0','p1','p2']],atol=1e-12,rtol=0)
    assert candidate.train_label_max.lt(candidate.prediction_time).all() and candidate.calibration_label_max.lt(candidate.prediction_time).all()
    evaluation=None
    if passed:
        dump(WORK/'squad/soccer_selection.json',dict(selected_candidates=[name]))
        test=models.run('soccer','evaluation',[name]);test['variant']='candidate'
        ref=pd.read_parquet(REFERENCE/'evaluation_predictions.parquet');ref=ref[ref.variant.eq('candidate')].copy();ref['variant']='reference'
        evaluation=pd.concat([test,ref],ignore_index=True);evaluation.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
        models.metrics(evaluation).to_csv(RESULT/'evaluation_metrics.csv',index=False)
    simulation.RESULT=RESULT;simulation.simulate(joined,evaluation)
    dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),development_gate_passed=bool(passed),
        evaluated2026=bool(passed),inputs=len(package['columns']),forecast_replays=len(sample),adopted=False,app_changed=False))
    print(json.dumps(dict(stage='training_complete',passed=bool(passed),scores=scores)),flush=True)


def stake():
    """Separate predecision squad uncertainty from probability/stake magnitude."""
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    assert (RESULT/'validation.json').exists() and not (RESULT/'stake_validation.json').exists()
    members=pd.read_parquet(RESULT/'player_membership.parquet')
    m=members.assign(included_minutes=np.where(members.in_announced_squad,members.recent_minutes,0.))
    shares=m.groupby(['game_id','side']).agg(total_minutes=('recent_minutes','sum'),included_minutes=('included_minutes','sum'),
        source_report=('report_id','first'),source_clock=('squad_available_utc','max'),cutoff=('cutoff_utc','first')).reset_index()
    assert shares.source_clock.le(shares.cutoff).all() and shares.total_minutes.gt(0).all()
    shares['retained_minute_fraction']=shares.included_minutes/shares.total_minutes
    factors=shares.groupby('game_id').retained_minute_fraction.min().to_dict()
    dump(RESULT/'stake_plan.json',dict(at_utc=stamp(),hypothesis='Large documented squad turnover increases uncertainty in an otherwise unchanged forecast. Reduce exposure in direct proportion to the remaining recent-minute share; no fitted cutoff or multiplier.',
        formula='Baseline$5per positive probability-price percentage point * min(verified retained recent-minute fraction across reported sides). No report: baseline stake policy unchanged, not asserted full availability.',
        unchanged='Original41-input club-strength forecasts, selected outcome, prices, settlement, starting cash$2000and no costs. No losing-game exclusion or fitted threshold.',
        gate='2025positive return, higher Sharpe, lower max drawdown;2024Sharpe cannot worsen when available. Evaluate a provider in2026only if that earlier gate passes.',
        evaluation='2026is repeatedly examined retrospective research, not pristineOOS.',
        membership_sha256=file_sha256(RESULT/'player_membership.parquet'),app_changed=False))
    shares.to_csv(RESULT/'stake_availability_evidence.csv',index=False)
    quotes=quote_inputs(RESULT/'stake_quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    records=[];positions=[];days=[];checks=[];choices={}
    for stage in ['development','evaluation']:
        if stage=='evaluation' and not any(choices.values()):break
        pred=pd.read_parquet(REFERENCE/(stage+'_predictions.parquet'));pred=pred[pred.variant.eq('candidate')]
        source=transfer.normalize('soccer',pred,quotes,pick_growth=True)
        source['availability_stake_multiplier']=source.game_id.map(factors).fillna(1.)
        source['has_verified_squad']=source.game_id.isin(factors)
        for provider,g in source.groupby('provider'):
            if stage=='evaluation' and not choices[provider]:continue
            for year in sorted(g.year.unique()):
                for rule,sizing in [('reference','edge_dollars_cash_only'),('availability','availability_edge_cash_only')]:
                    summary,b,l,d=engine.simulate(g,int(year),'all_selected_outcomes',sizing,5.,2000.)
                    key=dict(sport='soccer',provider=provider,year=int(year),rule=rule)
                    checks.append(key|engine.validate(b,l,d,sizing,5.,2000.))
                    if rule=='reference':
                        prior=pd.read_parquet(REFERENCE/'bets.parquet')
                        old=prior[prior.variant.eq('candidate')&prior.provider.eq(provider)&prior.year.eq(year)].sort_values('game_id')
                        new=b.sort_values('game_id');assert old.game_id.tolist()==new.game_id.tolist()
                        assert np.allclose(old[['stake','profit']],new[['stake','profit']],rtol=0,atol=1e-8)
                    assert np.allclose(b.probability,np.where(b.side.eq(0),b.p0,np.where(b.side.eq(1),b.p1,b.p2)),atol=1e-12,rtol=0)
                    records.append(key|summary);positions.append(b.assign(**key));days.append(d.assign(**key))
            if stage=='development':
                a=pd.DataFrame(records);a=a[a.provider.eq(provider)]
                base=a[a.rule.eq('reference')].set_index('year');new=a[a.rule.eq('availability')].set_index('year')
                choices[provider]=bool(new.loc[2025,'return_pct']>0 and new.loc[2025,'sharpe']>base.loc[2025,'sharpe'] and
                    new.loc[2025,'max_drawdown_pct']<base.loc[2025,'max_drawdown_pct'] and
                    (2024 not in base.index or new.loc[2024,'sharpe']>=base.loc[2024,'sharpe']))
        if stage=='development':dump(RESULT/'stake_selection.json',dict(at_utc=stamp(),choices=choices,adopted=False))
    annual=pd.DataFrame(records);annual.to_csv(RESULT/'stake_annual.csv',index=False)
    all_positions=pd.concat(positions,ignore_index=True)
    all_positions.to_parquet(RESULT/'stake_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'stake_daily.parquet',index=False)
    dump(RESULT/'stake_validation.json',dict(status='PASS',at_utc=stamp(),checks=checks,choices=choices,baseline_replayed=True,
        probabilities_unchanged=True,source_clocks_checked=True,adopted=False,app_changed=False))
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/stake_annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],annual.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes())
    old[LABEL+'/stake']=dict(plan=json.loads((RESULT/'stake_plan.json').read_bytes()),choices=choices,adopted=False);dump(path,old)
    stake_diagnose()
    print(annual[['provider','year','rule','funded_games','return_pct','sharpe','max_drawdown_pct']].round(4).to_string(index=False),flush=True)


def stake_diagnose():
    """Separate direct reductions from propagated cash-allocation effects."""
    b=pd.read_parquet(RESULT/'stake_bets.parquet');index=['provider','year','game_id']
    base=b[b.rule.eq('reference')].set_index(index);candidate=b[b.rule.eq('availability')].set_index(index)
    assert set(base.index)==set(candidate.index),'Changed funding needs explicit unmatched-case audit'
    fields=['teamA','teamB','side','won','probability','price','availability_stake_multiplier','stake','profit']
    cases=candidate[fields].copy();cases['baseline_stake']=base.stake;cases['baseline_profit']=base.profit
    cases['profit_change']=cases.profit-cases.baseline_profit
    cases['effect']=np.where(cases.availability_stake_multiplier.lt(1),'direct_squad_stake_reduction','propagated_available_cash')
    cases=cases[(cases.stake-cases.baseline_stake).abs().gt(1e-9)].reset_index()
    cases.to_csv(RESULT/'stake_changed_cases.csv',index=False)
    totals=cases.groupby(['provider','year','effect']).agg(games=('game_id','size'),wins=('won','sum'),profit_change=('profit_change','sum')).reset_index()
    totals.to_csv(RESULT/'stake_change_attribution.csv',index=False)
    a=pd.read_csv(RESULT/'stake_annual.csv');ref=a[a.rule.eq('reference')].set_index(['provider','year']);new=a[a.rule.eq('availability')].set_index(['provider','year'])
    delta=totals.groupby(['provider','year']).profit_change.sum()
    # Current cohorts settle inside the account period. Explicitly require it
    # before comparing cohort profits with the annual equity difference.
    assert not b.unsettled_at_end.any()
    assert np.allclose(delta,(new.final_equity-ref.final_equity).loc[delta.index],atol=1e-7,rtol=0)
    dump(RESULT/'stake_attribution_validation.json',dict(status='PASS',at_utc=stamp(),every_profit_change_reconciled=True,
        cash_propagation_separate=True,changed_bets=len(cases),matched_opportunity_sets=True))


def finish():
    from pathlib import Path
    from common import REPORTS
    from final_pipeline import discard_work,cleanup,validate
    for name in ['validation.json','cash_validation.json','feature_validation.json']:
        assert json.loads((RESULT/name).read_bytes())['status']=='PASS'
    selection=json.loads((RESULT/'selection.json').read_bytes())
    proof=json.loads((RESULT/'feature_validation.json').read_bytes())
    forecasts=pd.read_parquet(RESULT/'development_predictions.parquet')
    members=pd.read_parquet(RESULT/'player_membership.parquet')
    case='UCL_20250129_LIV_PSV';example=forecasts[forecasts.game_id.eq(case)]
    membership=members[members.game_id.eq(case)]
    fraction=float(membership.loc[~membership.in_announced_squad,'recent_minutes'].sum()/membership.recent_minutes.sum())
    audit=[]
    for variant,f in forecasts.groupby('variant'):
        f=f[f.game_id.isin(members.game_id)];p=f[['p0','p1','p2']].to_numpy();y=f.target.to_numpy(int)
        audit.append(dict(variant=variant,games=len(f),log_loss=float(-np.log(p[np.arange(len(y)),y]).mean()),accuracy=float(np.mean(p.argmax(axis=1)==y))))
    dump(RESULT/'loss_followup.json',dict(at_utc=stamp(),changed_game_comparison=audit,
        liverpool_case=example[['variant','p0','p1','p2','target']].to_dict('records'),recent_minutes_omitted_fraction=fraction,
        failure_mechanism='Renormalizing the remaining contributors overweights remaining attackers when omitted players include defenders/midfielders. For PSV-Liverpool, revised attacking rates rise despite73.6%recent minutes omitted. Team history/Elo remain unchanged.',
        next_hypothesis='Player-role and replacement-quality representation; do not equate average attacking rate among called-up recent players with full-team strength. Broader dated squad evidence needed before adding absence coefficients.',
        no_losing_game_exclusions=True))
    # Describe the existing NHL comparator, without changing its selection.
    nhlpath=ROOT_OUT/'simulation_results/uncertainty_buffer_staking/fixed_stake_bets.parquet'
    nhl=pd.read_parquet(nhlpath);nhl=nhl[nhl.sport.eq('nhl')&nhl.provider.eq('polymarket')&nhl.rule.eq('relative_advantage10_flat20')].copy()
    nhl['probability_band']=pd.cut(nhl.probability,[0,.4,.5,.6,.7,1],include_lowest=True).astype(str)
    bands=nhl.groupby(['year','probability_band']).agg(bets=('won','size'),win_rate=('won','mean'),
        mean_forecast=('probability','mean'),mean_price=('price','mean'),profit=('profit','sum')).reset_index()
    bands.to_csv(RESULT/'unchanged_nhl_loss_bands.csv',index=False)
    annual=pd.read_csv(RESULT/'annual.csv')
    def table(frame):
        def fmt(x):return f'{x:.6f}' if isinstance(x,(float,np.floating)) else str(x)
        return '\n'.join(['| '+' | '.join(frame.columns)+' |','| '+' | '.join(['---']*len(frame.columns))+' |']+
            ['| '+' | '.join(map(fmt,row))+' |' for row in frame.itertuples(index=False,name=None)])
    score=pd.DataFrame([dict(model=k,**v) for k,v in selection['scores'].items()])
    lines=['# Soccer squad availability and losing-case follow-up','',
        'The first availability model adjustment fails the earlier probability gate and is not adopted. The target remains Sharpe >=3 and return >20%. No new2026model forecast was fitted. A separate stake-only experiment below uses unchanged prior forecasts. The NBA/MLB app and research baselines remain unchanged.','',
        '## Diagnosed data problem','',
        'The Liverpool-PSV loss on January29,2025 used the recent player pool even though an official travelling squad had already excluded11of21recent contributors, representing73.6185%of their recorded minutes. This is missing pregame information, not proof the outcome was inevitable. The source publication and last update precede the pre12 decision.','',
        'Systematic official archive collection now publishes344announcements and7,461named player entries:333Madrid reports and11Liverpool travelling lists.82announcements have verified pre12 clocks and unique official-game links. Raw source replay, named-list counts and SQL equality passed. No losing-game-only source sample was used. See soccer_squad_availability.md for API endpoints, coverage boundaries and source limitations.','',
        'Nickname validation matters: the full names of Nacho, Joselu, Chema and Nico Paz were manually matched against official club/federation pages. Those static aliases repair announced-name matching; they do not import later performance, team membership or availability. Original page hashes and exact URLs are retained in documented_name_aliases.json. Previously documented Vini Jr. and Fede Valverde aliases are also retained.','',
        '## Controlled experiment','',
        '1. Reconstruct all11,594game feature rows from441,080earlier player records. Only statistics whose release predates each decision enter history.','',
        '2. Use the last five observed team games to weight recent players; use their last30available appearances for rates. A verified predecision complete squad removes omitted recent contributors. Ambiguous compatible abbreviations retain possible players instead of declaring an absence. New players without earlier minutes are not assigned fabricated performance.','',
        '3. Recompute seven existing roster inputs: goals, assists, key passes, distance covered, challenges won and shots per90, plus recent-pool size. Keep the other inputs and the41-input logistic recipe unchanged, including club-strength context, pooled scaling, regularization and calibration.','',
        '4. Train on expanding history from2021 with monthly refits; predictions begin2024. Earlier-only purged180day calibration is unchanged. Verify a truncated-history prefix reproduces identical earlier features and replay20saved predictions.','',
        '5. Require lower multiclass logloss and Brier on2024/25before examining a new2026candidate. The gate failed:', '',table(score),'',
        f"Paired logloss change: {selection['paired']['paired_logloss_change']:.9f}. Monthly-block95%interval: {selection['paired']['month_block95_interval']}. This interval is descriptive and unadjusted for repeated research. It does not establish improvement.",'',
        'The65directly affected2024/25games improve slightly, but retrained probabilities across the full3,961game comparison become slightly worse. Coverage is limited to two clubs, so it is not evidence of a general availability model.','',table(pd.DataFrame(audit)),'',
        '## Same chronological cash simulation','',
        'Each year begins with$2,000. Request$5per percentage point of positive model probability minus purchase price, select one quoted outcome by the unchanged expected-log-growth rule, and hold to the official result. Cash-only settlement timing prevents using unsettled winnings. Pre12 uses the closest preceding quote, at most24hours old. Providers remain separate; no costs or spread assumptions were added.','',
        table(annual[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        'Polymarket observations here are international historical token prices, not verified executable Polymarket US quotes. Kalshi uses the separately recorded ask basis. Return is actual account-period return. Sharpe uses daily calendar returns, idle days included, with sqrt(365.25) annualization; that factor is distinct from the number of observations used to estimate dispersion.','',
        '## Why this attempt failed and next direction','',
        'For Liverpool at PSV, predicted Liverpool probability falls only from56.4821%to55.7070%. Removing defenders and midfielders raises the remaining pool average goal/assist rate. The model still retains its older full-team results and strength estimates. Averaging the remaining attackers therefore does not adequately describe a replacement lineup. The next representation should preserve player roles and estimate replacement contribution from earlier observations. It should be tested across a broader archive, rather than attaching a special penalty to this known loss.','',
        'NHL is unchanged. Its existing fixed$20two-model-value comparator has2026Polymarket return+37.41%, Sharpe2.11 and drawdown12.09%. The target return is met for that historical sample; the Sharpe target is not. In its2025selected bets, the above70%forecast group won7of13(53.85%)against mean forecast75.50%. That sample is too small to justify deleting the group, but it explains why stake size should not grow mechanically with model confidence. Full band counts, forecasts, prices and profit are saved in unchanged_nhl_loss_bands.csv.','',
        'Repeatedly inspected2026results are retrospective rolling research, not a pristine strategy holdout. This experiment never used2026returns to choose a rule.','',
        '## Reproduce and retained files','',
        'Source stages: collect_soccer_squads.py archive, collect, lfc_archive, lfc_collect, publish, document. Model stages: soccer_squad_model.py collect_aliases, build, train, stake, finish. A completed result is immutable; reproduce in a fresh research work/result namespace. Final source tables, original responses, forecasts, account results and audit evidence remain. Temporary source matrices and rejected fitted artefacts are removed only after publication validation.','']
    if (RESULT/'stake_validation.json').exists():
        staking=json.loads((RESULT/'stake_validation.json').read_bytes());assert staking['status']=='PASS'
        lines+=['## Separate stake-only test','',
            'The original41-input forecasts and outcome choices are retained. Multiply the baseline desired stake by the lowest documented remaining recent-minute fraction across reported sides. Unknown squad coverage leaves the baseline policy unchanged; it is not treated as evidence of full availability. This is a sizing allowance, not a changed model probability. The multiplier and source timestamps are explicitly saved.','',
            table(pd.read_csv(RESULT/'stake_annual.csv')[['provider','year','rule','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
            'Earlier-period gate by provider: '+json.dumps(staking['choices'])+'. A provider is evaluated on2026only if2025Sharpe improves, drawdown falls, return remains positive and2024Sharpe does not worsen. Exact baseline stake/profit reproduction and independent cash-ledger checks passed. No adoption.','',
            'The rule reduces the Liverpool-PSV losing stake from$127.41to$33.61and improves2025Polymarket Sharpe from1.4460to1.4722. It fails later:2026return falls from59.75%to54.22%, Sharpe1.2415to1.2350and drawdown82.92%to84.18%. Ten of the12directly adjusted2026Polymarket bets won. Direct reduced-bet effects and propagated cash-allocation effects are separately reconciled in stake_change_attribution.csv. Blanket turnover discounts reduce many good positions as well as bad ones. Next test replacement quality and role, not a retrospectively selected match/month exclusion.','']
    report=REPORTS/(LABEL+'.md');report.write_text('\n'.join(lines),encoding='utf8')
    code=Path(__file__).resolve().parent;readme=code/'README.md';body=readme.read_text(encoding='utf8')
    marker='## Squad availability model experiment'
    if marker not in body:
        body+='\n\n'+marker+'\n\n'+(
            '`soccer_squad_model.py` validates official name aliases, replays earlier player-pool features, tests the unchanged41-input learner with dated squad exclusion, then records its decision and removes rejected fits. Stages: `collect_aliases`, `build`, `train`, `finish`. See `reports/nhl_soccer_iteration/soccer_squad_model.md`.\n\n'
            'Official alias validation URLs (manual identity evidence where the match API omitted playing names):\n'+
            '\n'.join('- '+r['source']['url'] for r in json.loads((RESULT/'documented_name_aliases.json').read_bytes())['rows'])+'\n')
        readme.write_text(body,encoding='utf8')
    duplicate=RESULT/'roster_coverage_audit.parquet';canonical=ROOT_OUT/'simulation_results/loss_case_revision/roster_coverage_audit.parquet'
    if duplicate.exists():
        pd.testing.assert_frame_equal(pd.read_parquet(duplicate),pd.read_parquet(canonical),check_exact=True)
        dump(RESULT/'roster_coverage_reference.json',dict(path=str(canonical.relative_to(ROOT_OUT)),sha256=file_sha256(canonical),identical=True))
        resolved=duplicate.resolve();assert resolved.parent==RESULT.resolve() and resolved.is_relative_to(ROOT_OUT.resolve())
        assert not duplicate.is_symlink() and not duplicate.is_junction();resolved.unlink()
    failures_path=ROOT_OUT/'simulation_results/failed_runs.json';failures=json.loads(failures_path.read_bytes())
    if not any(r.get('experiment')==LABEL for r in failures):
        failures.append(dict(at_utc=stamp(),experiment=LABEL,resolved=True,
            issues=['Liverpool final partial page repeated because cursor advanced by returned count','Mixed fractional-second source clocks required format=mixed','Registered names initially missed documented nicknames; repaired before any training'],
            outcome='All source and feature checks passed. Corrected candidate fails probability gate; no new2026evaluation or adoption.'))
        dump(failures_path,failures)
    verified=validate()
    hashes={str(p.relative_to(RESULT)):file_sha256(p) for p in RESULT.rglob('*') if p.is_file()}
    if WORK.exists():discard_work(WORK)
    squad_work=ROOT_OUT/'_work/soccer_squad_availability'
    assert (ROOT_OUT/'simulation_results/soccer_squad_availability/collection_manifest.json').exists()
    if squad_work.exists():discard_work(squad_work)
    cleanup()
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        tables=db.execute('SELECT COUNT(*) FROM table_catalog').fetchone()[0];columns=db.execute('SELECT COUNT(*) FROM column_catalog').fetchone()[0]
    manifest_path=ROOT_OUT/'retention/retained_artifacts.json';manifest=json.loads(manifest_path.read_bytes())
    manifest['scripts']={p.name:file_sha256(p) for p in sorted(code.glob('*.py'))}
    manifest.update(updated_utc=stamp(),retained_scripts=len(manifest['scripts']),final_tables=tables,current_sql_columns=columns)
    manifest['latest_simulation_update']=dict(report=str(report),result=str(RESULT.relative_to(ROOT_OUT)),adopted=False,app_validation=verified)
    source_proof=json.loads((ROOT_OUT/'simulation_results/soccer_squad_availability/validation.json').read_bytes())
    manifest['latest_dataset_update']=dict(at_utc=stamp(),tables=source_proof['tables'],liverpool_selected_archive_complete=True,
        older_liverpool_archive_coverage_unresolved=True,report=str(REPORTS/'soccer_squad_availability.md'))
    dump(manifest_path,manifest)
    dump(ROOT_OUT/'retention/squad_publication_receipt.json',dict(status='PASS',at_utc=stamp(),completed_publication=source_proof,
        app_validation=verified,temporary_article_cache_removed=True,retained_manifest='simulation_results/soccer_squad_availability/collection_manifest.json'))
    state_path=ROOT_OUT/'research_continuation.json';state=json.loads(state_path.read_bytes())
    state.update(at_utc=stamp(),current_job=None,running_jobs=[],live_sessions=[],
        terminal_sessions=[90111,12751,2187,77830,23877,97510,61913,95610,19422,55185],
        final_sql_tables=tables,final_sql_columns=columns,report=str(report),
        next_action='Availability-pool exclusion model rejected on2024/25gate, no2026model fit. Separate unchanged-forecast stake discount passes2025PM but fails2026:10of12directly affected bets won. Do not apply blanket turnover haircut. Next improve player-role/replacement quality or inspect NHL high-confidence calibration using earlier months; no losing-game/calendar blacklist. Broader dated squad archives needed including unresolved older/Europa Liverpool routes. All trial work removed; raw/final evidence retained.',
        previous_goal_turn=dict(progress='Published344dated squads/7461names; verified nickname aliases; tested82eligible squads in3961rolling forecasts, rejected model; separate staking passesearlierPM but fails2026. Diagnosed both failures and cleaned trial work.',oos='2024/25model gate failed. Stake-only2026PM evaluation used unchanged prior forecasts after earlier gate; retrospective, not pristine. Target unmet.'))
    research=state.setdefault('research_state',{});research['no_running_jobs']=True
    research['latest_validated_data']=f'{tables}SQLtables/{columns}columns;344officialsquadreports,7461names,82pre12eligible;rawreplaypassed;catalogcurrent.'
    research['soccer_squad_availability']=dict(reports=344,players=7461,eligible_pre12=82,all_published_raw_replayed=True,collection_pending=False,older_liverpool_archive_coverage_unresolved=True)
    research['soccer_squad_model']=dict(result=str(RESULT.relative_to(ROOT_OUT)),selection=selection,adopted=False,model_work_removed=True)
    if (RESULT/'stake_validation.json').exists():research['soccer_squad_staking']=json.loads((RESULT/'stake_validation.json').read_bytes())
    research['previous_goal_turn_classification']='progress: source publication, controlled rolling model test, loss mechanism diagnosed, clean final results; not blocked.'
    dump(state_path,state)
    receipt=dict(status='PASS',at_utc=stamp(),report=str(report),result_hashes=hashes,app_validation=verified,
        final_sql_tables=tables,final_sql_columns=columns,temporary_work_removed=True,target_achieved=False,adopted=False)
    dump(ROOT_OUT/'retention/squad_model_completion.json',receipt);dump(ROOT_OUT/'retention/current_update_receipt.json',receipt)
    print(json.dumps(dict(status='PASS',report=str(report),adopted=False,target_achieved=False)),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['collect_aliases','build','train','stake','stake_diagnose','finish']);args=parser.parse_args()
    globals()[args.stage]()
