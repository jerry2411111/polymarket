"""Winner-only risk revision, selected on earlier years without changing sides."""
import json
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, REPORTS, dump, stamp, file_sha256
from backtest import quote_inputs
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine

LABEL='winner_risk_revision'
RESULT=ROOT_OUT/'simulation_results'/LABEL
RULES={'fixed5_cash':'dollars_cash_only','fixed5_cap20':'dollars_cap20',
       'adaptive5_cap20':'confidence_fraction_cap20','winner_quarter_kelly':'quarter_kelly_cap20'}


def run():
    RESULT.mkdir(exist_ok=True)
    assert not (RESULT/'validation.json').exists()
    plan=dict(at_utc=stamp(),diagnosis='Fixed dollar confidence positions become a larger fraction of shrinking equity. Winner-only low-confidence cohorts also show negative unit returns in development.',
        invariants='Outcome is full-class model argmax before price lookup. No outcome switch, no model refit, no price-entry-hour sweep. Existing pre12 closest-prior quotes age<=24h, annual2000cash, no costs.',
        controls='Fixed5 dollars per probability point above51, the pre-existing winner baseline; same rule with existing20%open-cost cap.',
        alternatives={'adaptive5_cap20':'5*(100*p-51)*current_equity/2000, floor0, totalopen-cost<=20%equity',
                      'winner_quarter_kelly':'.25*equity*max((p-price)/(1-price),0), on the model winner only withp>51%, totalopen-cost<=20%equity'},
        interpretation='Price may reduce the stake to zero for the already selected winner; it cannot substitute a different outcome.',
        gate='Each alternative must improve2025Sharpe with positive return and no worse drawdown versus fixed5_cash. Where2024quotes exist,2024Sharpe must not deteriorate. Save choice before2026; only qualifying alternatives receive2026evaluation.',
        parameters='5dollars and20%exposure cap are existing controls; quarterKelly is existing fraction. No new parameter grid.',
        paper='https://web.stanford.edu/~boyd/papers/pdf/kelly.pdf',
        paper_scope='Paper supplies binary Kelly expression and fractional-Kelly discussion. This simple20%open-cost rule is not the paper risk-constrained optimization and does not inherit its guarantees.',
        evaluation='2026 is repeatedly inspected retrospective rolling research, not an untouched holdout.',app_changed=False)
    dump(RESULT/'plan.json',plan)
    quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    forecasts={};hashes={}
    for sport,folder in [('nhl','feature_revisions/nhl_player_strength'),('soccer','soccer_source_count_rates')]:
        forecasts[sport]={}
        for stage in ['development','evaluation']:
            path=ROOT_OUT/'simulation_results'/folder/(stage+'_predictions.parquet')
            hashes[str(path.relative_to(ROOT_OUT))]=file_sha256(path)
            p=pd.read_parquet(path);p=p[p.variant.eq('candidate')]
            assert p.game_id.is_unique and p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
            forecasts[sport][stage]=p
    rows=[];bets=[];days=[];checks=[];choices={}
    for stage in ['development','evaluation']:
        for sport in forecasts:
            p=forecasts[sport][stage]
            f=transfer.normalize(sport,p,quotes,pick_growth=False)
            cols=['p0','p1']+(['p2'] if sport=='soccer' else [])
            assert f.side.eq(f[cols].to_numpy().argmax(axis=1)).all()
            for provider,g in f.groupby('provider'):
                for label,sizing in RULES.items():
                    if stage=='evaluation' and label!='fixed5_cash' and not choices.get((sport,provider,label),False):continue
                    for year in sorted(p.prediction_time.dt.year.unique()):
                        m,b,l,d=engine.simulate(g,int(year),'winner_above51',sizing,5.,2000.)
                        key=dict(sport=sport,provider=provider,variant=label,year=int(year))
                        rows.append(key|m);checks.append(key|engine.validate(b,l,d,sizing,5.,2000.))
                        if len(b):
                            assert b.side.eq(b[cols].to_numpy().argmax(axis=1)).all()
                            if label=='winner_quarter_kelly':assert b.probability.gt(b.price).all()
                            if label!='fixed5_cash':
                                funded=l[l.spent.gt(0)]
                                assert funded.open_cost.le(.20*funded.equity+1e-7).all()
                            bets.append(b.assign(**key))
                        days.append(d.assign(**key))
                print(json.dumps(dict(stage=stage,sport=sport,provider=provider)),flush=True)
        if stage=='development':
            a=pd.DataFrame(rows)
            for (sport,provider),group in a.groupby(['sport','provider']):
                index=group.set_index(['variant','year']);base=index.loc[('fixed5_cash',2025)]
                for label in RULES:
                    if label=='fixed5_cash':continue
                    new=index.loc[(label,2025)]
                    passed=new.sharpe>base.sharpe and new.return_pct>0 and new.max_drawdown_pct<=base.max_drawdown_pct
                    if ('fixed5_cash',2024) in index.index and pd.notna(index.loc[('fixed5_cash',2024),'sharpe']):
                        passed &= index.loc[(label,2024),'sharpe']>=index.loc[('fixed5_cash',2024),'sharpe']
                    choices[sport,provider,label]=bool(passed)
            dump(RESULT/'selection.json',dict(at_utc=stamp(),choices=[dict(sport=k[0],provider=k[1],variant=k[2],passed=v) for k,v in choices.items()],used2026=False,adopted=False))
    a=pd.DataFrame(rows);b=pd.concat(bets,ignore_index=True);d=pd.concat(days,ignore_index=True)
    old=pd.read_csv(ROOT_OUT/'simulation_results/winner_stake_sizing/winner_annual.csv')
    old=old[old.stake_rule.eq('confidence5')].set_index(['sport','provider','year'])
    control=a[a.variant.eq('fixed5_cash')].set_index(['sport','provider','year'])
    for col in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
        assert np.allclose(control[col],old.loc[control.index,col],rtol=0,atol=1e-9,equal_nan=True),col
    a.to_csv(RESULT/'annual.csv',index=False);b.to_parquet(RESULT/'bets.parquet',index=False);d.to_parquet(RESULT/'daily.parquet',index=False)
    for name,sha in hashes.items():assert file_sha256(ROOT_OUT/name)==sha
    proof=dict(status='PASS',at_utc=stamp(),checks=checks,source_hashes=hashes,baseline_replayed=True,
        all_bets_are_model_argmax=True,no_new_model_fits=True,adopted=False,app_changed=False)
    dump(RESULT/'validation.json',proof)
    def table(f):
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+[
            '| '+' | '.join(f'{v:.4f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in f.itertuples(index=False,name=None)])
    report=['# Winner-only risk sizing','',plan['diagnosis'],'',
        'Only the model argmax is purchased. Fixed-dollar5, fixed-dollar5with20%open-cost limit, account-scaled5withthe same limit, and quarterKelly on that same predicted winner are compared. Price can reduce the last rule stake to zero; it never selects another outcome. No model refit, amount/hour sweep, fees or spread assumptions.','',
        plan['gate'],'',table(a[['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        'The unchanged confidence5baseline reproduces every saved annual metric. Independent cash replay verifies settlement funding, stakes and daily balances; every funded side equals the full-class model argmax. The20%open-cost constraint is checked after each funded batch, not asserted as a mark-to-market guarantee.','',
        'Method reference: [Risk-Constrained Kelly Gambling](https://web.stanford.edu/~boyd/papers/pdf/kelly.pdf). Its binary Kelly expression motivates the fractional sizing comparison. This implementation does not reproduce its constrained optimizer or claim its probability bounds.','',
        '2026 remains retrospective repeatedly inspected evidence. Sharpe uses actual calendar daily returns with idle days andsqrt365.25. Open positions carried atcost until official settlement. Polymarket historical international token prices and KalshiYESaskcloses remain separate source types. No retained/app model changes. Reproduce winner_risk_revision.py.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(report)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';v=json.loads(path.read_bytes());v[LABEL]=dict(plan=plan,selection=json.loads((RESULT/'selection.json').read_bytes()),validation=proof);dump(path,v)
    from final_pipeline import cleanup
    cleanup()
    path=ROOT_OUT/'retention/retained_artifacts.json';v=json.loads(path.read_bytes());v['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};v.update(updated_utc=stamp(),retained_scripts=len(v['scripts']));dump(path,v)
    print(a[['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


def confidence_floor():
    """One sport-specific weak-confidence exclusion motivated by2025 losses."""
    assert (RESULT/'validation.json').exists() and not (RESULT/'floor_validation.json').exists()
    floors={'nhl':.60,'soccer':.55}
    plan=dict(at_utc=stamp(),diagnosis='2025fixed-dollar winner diagnostics: NHL50-60%cohorts lose; soccer50-55%cohort loses, while55-60%earns positive unit returns. Test one corresponding floor per sport, not a threshold sweep.',
        floors=floors,rule='Keep original model argmax and fixed5dollars per confidence point above51. Set stake to zero below the stated floor. No price filter, side switch, model refit or amount tuning.',
        gate='Higher2025Sharpe,positive2025return,and no worse drawdown than original confidence5.2024Sharpe not worse where quotes exist. Save decision before2026.',
        evaluation='2024/25are inspected development;2026repeatedly inspected retrospective rolling evidence,not pristineholdout.',app_changed=False)
    dump(RESULT/'floor_plan.json',plan)
    quotes=quote_inputs(RESULT/'floor_quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    annual=[];bets=[];days=[];checks=[];choices={};attribution=[]
    for stage in ['development','evaluation']:
        for sport,folder in [('nhl','feature_revisions/nhl_player_strength'),('soccer','soccer_source_count_rates')]:
            path=ROOT_OUT/'simulation_results'/folder/(stage+'_predictions.parquet')
            p=pd.read_parquet(path);p=p[p.variant.eq('candidate')]
            assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
            f=transfer.normalize(sport,p,quotes,pick_growth=False)
            cols=['p0','p1']+(['p2'] if sport=='soccer' else [])
            for provider,g in f.groupby('provider'):
                if stage=='evaluation' and not choices.get((sport,provider),False):continue
                for variant in ['original51','development_floor']:
                    h=g[g.probability.gt(.51 if variant=='original51' else floors[sport])]
                    for year in sorted(p.prediction_time.dt.year.unique()):
                        m,b,l,d=engine.simulate(h,int(year),'all_selected_outcomes','dollars_cash_only',5.,2000.)
                        meta=dict(sport=sport,provider=provider,variant=variant,year=int(year))
                        annual.append(meta|m);checks.append(meta|engine.validate(b,l,d,'dollars_cash_only',5.,2000.))
                        if len(b):
                            assert b.side.eq(b[cols].to_numpy().argmax(axis=1)).all()
                            bets.append(b.assign(**meta))
                        days.append(d.assign(**meta))
        if stage=='development':
            a=pd.DataFrame(annual)
            for (sport,provider),g in a.groupby(['sport','provider']):
                ix=g.set_index(['variant','year']);old,new=ix.loc[('original51',2025)],ix.loc[('development_floor',2025)]
                passed=new.sharpe>old.sharpe and new.return_pct>0 and new.max_drawdown_pct<=old.max_drawdown_pct
                if ('original51',2024) in ix.index and pd.notna(ix.loc[('original51',2024),'sharpe']):passed &= ix.loc[('development_floor',2024),'sharpe']>=ix.loc[('original51',2024),'sharpe']
                choices[sport,provider]=bool(passed)
            dump(RESULT/'floor_selection.json',dict(at_utc=stamp(),choices=[dict(sport=k[0],provider=k[1],passed=v) for k,v in choices.items()],used2026=False,adopted=False))
    a=pd.DataFrame(annual);b=pd.concat(bets,ignore_index=True)
    ref=pd.read_csv(ROOT_OUT/'simulation_results/winner_stake_sizing/winner_annual.csv')
    ref=ref[ref.stake_rule.eq('confidence5')].set_index(['sport','provider','year'])
    control=a[a.variant.eq('original51')].set_index(['sport','provider','year'])
    for c in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
        assert np.allclose(control[c],ref.loc[control.index,c],rtol=0,atol=1e-9,equal_nan=True)
    for (sport,provider,year),g in b.groupby(['sport','provider','year']):
        old=g[g.variant.eq('original51')].set_index('game_id');new=g[g.variant.eq('development_floor')].set_index('game_id')
        removed=old.loc[old.index.difference(new.index)];common=old.index.intersection(new.index)
        attribution.append(dict(sport=sport,provider=provider,year=int(year),removed_bets=len(removed),
            removed_profit=removed.profit.sum(),removed_win_rate=removed.won.mean(),common_bets=len(common),
            common_stakes_unchanged=bool(np.allclose(old.loc[common,'stake'],new.loc[common,'stake'],rtol=0,atol=1e-9))))
    a.to_csv(RESULT/'floor_annual.csv',index=False);b.to_parquet(RESULT/'floor_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'floor_daily.parquet',index=False)
    pd.DataFrame(attribution).to_csv(RESULT/'floor_attribution.csv',index=False)
    proof=dict(status='PASS',at_utc=stamp(),checks=checks,original_baseline_replayed=True,all_bets_are_original_argmax=True,app_changed=False,adopted=False)
    dump(RESULT/'floor_validation.json',proof)
    cols=['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']
    report=REPORTS/(LABEL+'.md')
    table='\n'.join(['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']+['| '+' | '.join(f'{v:.4f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in a[cols].itertuples(index=False,name=None)])
    with report.open('a',encoding='utf8') as out:
        out.write('\nThe subsequent confidence-floor comparison uses one threshold per sport motivated by2025losses:60%NHL,55%soccer. No threshold grid; side, entry timing and fixed-dollar formula unchanged. Only an earlier-qualified provider is evaluated in2026.\n\n'+table+'\n')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/floor_annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL+'/confidence_floor']=dict(plan=plan,selection=json.loads((RESULT/'floor_selection.json').read_bytes()),validation=proof);dump(path,d)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(a[cols].to_string(index=False),flush=True)


def floor_price():
    """Combine the earlier-supported confidence floors with winner-only sizing."""
    assert (RESULT/'floor_validation.json').exists() and not (RESULT/'floor_price_validation.json').exists()
    floors=json.loads((RESULT/'floor_plan.json').read_bytes())['floors']
    plan=dict(at_utc=stamp(),diagnosis='The confidence floors improved development outcomes. Price sizing alone failed while including weak-confidence winners. Test their combination without changing either existing parameter.',
        floors=floors,control='Original fixed $5 confidence sizing on the declared model-winner confidence floor.',
        candidate='Quarter Kelly on that SAME model winner, with 20% total open-cost cap. Zero stake if its probability does not exceed price. No side switching.',
        gate='Higher 2025 Sharpe, positive return and no worse drawdown than the confidence-floor control; no worse 2024 Sharpe where available.',
        evaluation='Only earlier-qualified cases reach 2026. All 2026 evidence is retrospective and repeatedly inspected.',app_changed=False)
    dump(RESULT/'floor_price_plan.json',plan)
    quotes=quote_inputs(RESULT/'floor_price_quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    annual=[];bets=[];days=[];checks=[];choices={}
    for stage in ['development','evaluation']:
        for sport,folder in [('nhl','feature_revisions/nhl_player_strength'),('soccer','soccer_source_count_rates')]:
            p=pd.read_parquet(ROOT_OUT/'simulation_results'/folder/(stage+'_predictions.parquet'));p=p[p.variant.eq('candidate')]
            assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
            f=transfer.normalize(sport,p,quotes,pick_growth=False);f=f[f.probability.gt(floors[sport])]
            cols=['p0','p1']+(['p2'] if sport=='soccer' else [])
            for provider,g in f.groupby('provider'):
                if stage=='evaluation' and not choices.get((sport,provider),False):continue
                for variant,sizing in [('floor_control','dollars_cash_only'),('floor_quarter_kelly','quarter_kelly_cap20')]:
                    for year in sorted(p.prediction_time.dt.year.unique()):
                        m,b,l,d=engine.simulate(g,int(year),'all_selected_outcomes',sizing,5.,2000.)
                        meta=dict(sport=sport,provider=provider,variant=variant,year=int(year))
                        annual.append(meta|m);checks.append(meta|engine.validate(b,l,d,sizing,5.,2000.))
                        if len(b):
                            assert b.side.eq(b[cols].to_numpy().argmax(axis=1)).all()
                            if sizing=='quarter_kelly_cap20':assert b.probability.gt(b.price).all()
                            bets.append(b.assign(**meta))
                        days.append(d.assign(**meta))
        if stage=='development':
            a=pd.DataFrame(annual)
            for (sport,provider),g in a.groupby(['sport','provider']):
                ix=g.set_index(['variant','year']);old,new=ix.loc[('floor_control',2025)],ix.loc[('floor_quarter_kelly',2025)]
                passed=new.sharpe>old.sharpe and new.return_pct>0 and new.max_drawdown_pct<=old.max_drawdown_pct
                if ('floor_control',2024) in ix.index and pd.notna(ix.loc[('floor_control',2024),'sharpe']):passed &= ix.loc[('floor_quarter_kelly',2024),'sharpe']>=ix.loc[('floor_control',2024),'sharpe']
                choices[sport,provider]=bool(passed)
            dump(RESULT/'floor_price_selection.json',dict(at_utc=stamp(),choices=[dict(sport=k[0],provider=k[1],passed=v) for k,v in choices.items()],used2026=False,adopted=False))
    a=pd.DataFrame(annual);ref=pd.read_csv(RESULT/'floor_annual.csv');ref=ref[ref.variant.eq('development_floor')].set_index(['sport','provider','year'])
    baseline=a[a.variant.eq('floor_control')].set_index(['sport','provider','year'])
    for c in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
        assert np.allclose(baseline[c],ref.loc[baseline.index,c],rtol=0,atol=1e-9,equal_nan=True)
    a.to_csv(RESULT/'floor_price_annual.csv',index=False);pd.concat(bets).to_parquet(RESULT/'floor_price_bets.parquet',index=False)
    pd.concat(days).to_parquet(RESULT/'floor_price_daily.parquet',index=False)
    proof=dict(status='PASS',at_utc=stamp(),checks=checks,all_bets_are_argmax=True,baseline_reproduced=True,app_changed=False,adopted=False)
    dump(RESULT/'floor_price_validation.json',proof)
    cols=['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']
    table='\n'.join(['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']+['| '+' | '.join(f'{v:.4f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in a[cols].itertuples(index=False,name=None)])
    with (REPORTS/(LABEL+'.md')).open('a',encoding='utf8') as out:
        out.write('\nThe subsequent combined test applies the unchanged quarter-Kelly formula only above the earlier-supported confidence floors. This tests a specific interaction between weak-confidence losses and stake sizing. No parameter sweep or opposite-side purchase.\n\n'+table+'\n')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';d=pd.read_csv(path,low_memory=False);key=LABEL+'/floor_price_annual.csv'
    pd.concat([d[d.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL+'/floor_price']=dict(plan=plan,selection=json.loads((RESULT/'floor_price_selection.json').read_bytes()),validation=proof);dump(path,d)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(a[cols].to_string(index=False),flush=True)


def goal_qualified_followup():
    """Preserve the stricter drawdown gate; separately test the user's targets."""
    assert (RESULT/'floor_price_validation.json').exists() and not (RESULT/'goal_followup_validation.json').exists()
    earlier=pd.read_csv(RESULT/'floor_price_annual.csv')
    selected=earlier[earlier.variant.eq('floor_quarter_kelly')&earlier.year.eq(2025)&earlier.sharpe.ge(3)&earlier.return_pct.gt(20)]
    assert len(selected)
    plan=dict(at_utc=stamp(),reason='The prior researcher-added no-worse-drawdown gate rejects a2025soccerKalshi result despite Sharpe3.0708,return359.05%,drawdown18.89%. The user target does not require drawdown no higher than control15.25%. Preserve the original decision and separately evaluate unchanged candidates meeting the actual2025Sharpe/return targets.',
        chosen_on_year=2025,choices=selected[['sport','provider','variant','sharpe','return_pct','max_drawdown_pct']].to_dict('records'),
        outcome='Original model argmax only',rule='Existing confidence floor,quarterKelly,20%open-cost cap,annual2000,pre12,unchanged forecasts.',
        no_new_parameter_fit=True,evaluation='2026 retrospective repeated research; no claim of fresh holdout or goal achievement from development.',app_changed=False)
    dump(RESULT/'goal_followup_plan.json',plan)
    quotes=quote_inputs(RESULT/'goal_followup_quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    floors=json.loads((RESULT/'floor_plan.json').read_bytes())['floors'];rows=[];positions=[];days=[];checks=[]
    for r in selected.itertuples():
        folder='soccer_source_count_rates' if r.sport=='soccer' else 'feature_revisions/nhl_player_strength'
        p=pd.read_parquet(ROOT_OUT/'simulation_results'/folder/'evaluation_predictions.parquet');p=p[p.variant.eq('candidate')]
        assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
        f=transfer.normalize(r.sport,p,quotes,pick_growth=False);f=f[f.provider.eq(r.provider)&f.probability.gt(floors[r.sport])]
        m,b,l,d=engine.simulate(f,2026,'all_selected_outcomes','quarter_kelly_cap20',5.,2000.)
        cols=['p0','p1']+(['p2'] if r.sport=='soccer' else [])
        assert b.side.eq(b[cols].to_numpy().argmax(axis=1)).all() and b.probability.gt(b.price).all()
        key=dict(sport=r.sport,provider=r.provider,variant='floor_quarter_kelly',year=2026)
        rows.append(key|m);checks.append(key|engine.validate(b,l,d,'quarter_kelly_cap20',5.,2000.))
        positions.append(b.assign(**key));days.append(d.assign(**key))
    a=pd.DataFrame(rows);a.to_csv(RESULT/'goal_followup_annual.csv',index=False)
    pd.concat(positions).to_parquet(RESULT/'goal_followup_bets.parquet',index=False);pd.concat(days).to_parquet(RESULT/'goal_followup_daily.parquet',index=False)
    proof=dict(status='PASS',at_utc=stamp(),checks=checks,all_bets_are_argmax=True,original_gate_unchanged=True,app_changed=False,adopted=False)
    dump(RESULT/'goal_followup_validation.json',proof)
    cols=['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']
    table='\n'.join(['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']+['| '+' | '.join(f'{v:.4f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in a[cols].itertuples(index=False,name=None)])
    with (REPORTS/(LABEL+'.md')).open('a',encoding='utf8') as out:
        out.write('\nA separate follow-up applies the user\'s actual development targets (Sharpe>=3,return>20%) without the additional no-worse-drawdown condition. The original stricter rejection remains recorded. Only the2025qualifying candidate receives this unchanged2026evaluation; no parameter or2026return selects it.\n\n'+table+'\n')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';d=pd.read_csv(path,low_memory=False);key=LABEL+'/goal_followup_annual.csv'
    pd.concat([d[d.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL+'/goal_followup']=dict(plan=plan,validation=proof);dump(path,d)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(a[cols].to_string(index=False),flush=True)


def price_buffer():
    """Transfer the existing MLB five-point entry buffer to model winners."""
    assert (RESULT/'floor_validation.json').exists() and not (RESULT/'buffer_validation.json').exists()
    floors=json.loads((RESULT/'floor_plan.json').read_bytes())['floors']
    plan=dict(at_utc=stamp(),
        diagnosis='2025 winner price gaps between zero and five points are weak or negative. The largest claimed gaps are overconfident; Kelly increases exposure to those gaps. Test the pre-existing MLB five-point entry buffer with confidence-dollar stakes unchanged by the size of the price gap.',
        side='Original full-class argmax, selected before prices. Never substitute another outcome.',
        rule='Retain the earlier confidence floors (NHL60%,soccer55%) and 5 dollars per probability point above51. Stake zero unless model probability minus price is at least0.05. No new parameter grid or cost assumption.',
        selection='Choose on2025 only: higher Sharpe than the confidence-floor control and positive return. Report drawdown and the sparse2024 replay separately, without using them as extra gates. Choice is recorded before2026.',
        evaluation='2026 is repeatedly inspected retrospective rolling research, not a pristine holdout.',app_changed=False)
    dump(RESULT/'buffer_plan.json',plan)
    quotes=quote_inputs(RESULT/'buffer_quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    rows=[];positions=[];days=[];checks=[];choices={};hashes={}
    for stage in ['development','evaluation']:
        for sport,folder in [('nhl','feature_revisions/nhl_player_strength'),('soccer','soccer_source_count_rates')]:
            path=ROOT_OUT/'simulation_results'/folder/(stage+'_predictions.parquet')
            hashes[str(path.relative_to(ROOT_OUT))]=file_sha256(path)
            p=pd.read_parquet(path);p=p[p.variant.eq('candidate')]
            assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
            f=transfer.normalize(sport,p,quotes,pick_growth=False);f=f[f.probability.gt(floors[sport])]
            cols=['p0','p1']+(['p2'] if sport=='soccer' else [])
            for provider,g in f.groupby('provider'):
                if stage=='evaluation' and not choices.get((sport,provider),False):continue
                for variant in ['floor_control','winner_buffer5']:
                    h=g if variant=='floor_control' else g[g.edge.ge(.05)]
                    for year in sorted(p.prediction_time.dt.year.unique()):
                        m,b,l,d=engine.simulate(h,int(year),'all_selected_outcomes','dollars_cash_only',5.,2000.)
                        key=dict(sport=sport,provider=provider,variant=variant,year=int(year))
                        rows.append(key|m);checks.append(key|engine.validate(b,l,d,'dollars_cash_only',5.,2000.))
                        if len(b):
                            assert b.side.eq(b[cols].to_numpy().argmax(axis=1)).all()
                            if variant=='winner_buffer5':assert b.edge.ge(.05).all()
                            positions.append(b.assign(**key))
                        days.append(d.assign(**key))
        if stage=='development':
            a=pd.DataFrame(rows)
            for (sport,provider),g in a.groupby(['sport','provider']):
                ix=g.set_index(['variant','year']);old,new=ix.loc[('floor_control',2025)],ix.loc[('winner_buffer5',2025)]
                choices[sport,provider]=bool(new.sharpe>old.sharpe and new.return_pct>0)
            dump(RESULT/'buffer_selection.json',dict(at_utc=stamp(),choices=[dict(sport=k[0],provider=k[1],passed=v) for k,v in choices.items()],used2026=False,adopted=False))
    a=pd.DataFrame(rows);ref=pd.read_csv(RESULT/'floor_annual.csv');ref=ref[ref.variant.eq('development_floor')].set_index(['sport','provider','year'])
    baseline=a[a.variant.eq('floor_control')].set_index(['sport','provider','year'])
    for c in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
        assert np.allclose(baseline[c],ref.loc[baseline.index,c],rtol=0,atol=1e-9,equal_nan=True)
    a.to_csv(RESULT/'buffer_annual.csv',index=False);pd.concat(positions).to_parquet(RESULT/'buffer_bets.parquet',index=False)
    pd.concat(days).to_parquet(RESULT/'buffer_daily.parquet',index=False)
    for name,sha in hashes.items():assert file_sha256(ROOT_OUT/name)==sha
    proof=dict(status='PASS',at_utc=stamp(),checks=checks,source_hashes=hashes,baseline_replayed=True,
        all_bets_are_original_argmax=True,stakes_do_not_grow_with_price_gap=True,adopted=False,app_changed=False)
    dump(RESULT/'buffer_validation.json',proof)
    cols=['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']
    table='\n'.join(['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']+['| '+' | '.join(f'{v:.4f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in a[cols].itertuples(index=False,name=None)])
    with (REPORTS/(LABEL+'.md')).open('a',encoding='utf8') as out:
        out.write('\nThe five-point buffer transfers the existing MLB entry rule to the same model winner. Confidence-floor stakes remain fixed by model confidence, not by price-gap magnitude. '+plan['selection']+'\n\n'+table+'\n')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';d=pd.read_csv(path,low_memory=False);key=LABEL+'/buffer_annual.csv'
    pd.concat([d[d.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL+'/price_buffer']=dict(plan=plan,selection=json.loads((RESULT/'buffer_selection.json').read_bytes()),validation=proof);dump(path,d)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(a[cols].to_string(index=False),flush=True)


def corrected_soccer():
    """Carry the existing winner rule onto factually repaired soccer sources."""
    assert not (RESULT/'corrected_soccer_validation.json').exists()
    source=ROOT_OUT/'simulation_results/soccer_laliga_current_history'
    assert json.loads((source/'model_validation.json').read_bytes())['status']=='PASS'
    plan=dict(at_utc=stamp(),source='soccer_laliga_current_history:clock_identity',
        reason='Known kickoff/person facts are corrected regardless of whether their returns improve. Recheck the previously supported55%confidence floor on this current reference; no new threshold, model fit or side rule.',
        selection='Floor must improve2025Sharpe with positive return against corrected confidence5. Save before2026; report2024 separately.',
        rule='Original full-class argmax; fixed5dollars per confidence percentage point above51. Candidate sets stake zero unless p>55%. Same pre12/cash/settlement rules.',
        evaluation='Repeatedly inspected retrospective2026, no app changes or target assertion.')
    dump(RESULT/'corrected_soccer_plan.json',plan)
    quotes=quote_inputs(RESULT/'corrected_soccer_quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    rows=[];bets=[];days=[];checks=[];choices={};hashes={}
    for stage in ['development','evaluation']:
        path=source/(stage+'_predictions.parquet');hashes[stage]=file_sha256(path)
        p=pd.read_parquet(path);p=p[p.variant.eq('clock_identity')]
        assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
        f=transfer.normalize('soccer',p,quotes,pick_growth=False)
        for provider,g in f.groupby('provider'):
            if stage=='evaluation' and not choices.get(provider,False):continue
            for variant,threshold in [('corrected_control',.51),('corrected_floor55',.55)]:
                h=g[g.probability.gt(threshold)]
                for year in sorted(p.prediction_time.dt.year.unique()):
                    m,b,l,d=engine.simulate(h,int(year),'all_selected_outcomes','dollars_cash_only',5.,2000.)
                    key=dict(sport='soccer',provider=provider,variant=variant,year=int(year))
                    rows.append(key|m);checks.append(key|engine.validate(b,l,d,'dollars_cash_only',5.,2000.))
                    if len(b):
                        assert b.side.eq(b[['p0','p1','p2']].to_numpy().argmax(axis=1)).all();bets.append(b.assign(**key))
                    days.append(d.assign(**key))
        if stage=='development':
            for provider,g in pd.DataFrame(rows).groupby('provider'):
                ix=g.set_index(['variant','year']);a,b=ix.loc[('corrected_floor55',2025)],ix.loc[('corrected_control',2025)]
                choices[provider]=bool(a.return_pct>0 and a.sharpe>b.sharpe)
            dump(RESULT/'corrected_soccer_selection.json',dict(at_utc=stamp(),choices=choices,used2026=False,adopted=False))
    a=pd.DataFrame(rows);reference=pd.read_csv(source/'winner_annual.csv')
    reference=reference[reference.variant.eq('clock_identity')&reference.stake_rule.eq('confidence5')].set_index(['provider','year'])
    baseline=a[a.variant.eq('corrected_control')].set_index(['provider','year'])
    for c in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
        assert np.allclose(baseline[c],reference.loc[baseline.index,c],rtol=0,atol=1e-9,equal_nan=True)
    a.to_csv(RESULT/'corrected_soccer_annual.csv',index=False)
    pd.concat(bets).to_parquet(RESULT/'corrected_soccer_bets.parquet',index=False);pd.concat(days).to_parquet(RESULT/'corrected_soccer_daily.parquet',index=False)
    for stage,sha in hashes.items():assert file_sha256(source/(stage+'_predictions.parquet'))==sha
    proof=dict(status='PASS',at_utc=stamp(),source_hashes=hashes,checks=checks,baseline_replayed=True,every_bet_is_model_argmax=True,app_changed=False,adopted=False)
    dump(RESULT/'corrected_soccer_validation.json',proof)
    cols=['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']
    table='\n'.join(['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']+['| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in a[cols].itertuples(index=False,name=None)])
    with (REPORTS/(LABEL+'.md')).open('a',encoding='utf8') as out:out.write('\nCorrected soccer reference: '+plan['reason']+' '+plan['selection']+'\n\n'+table+'\n')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';d=pd.read_csv(path,low_memory=False);key=LABEL+'/corrected_soccer_annual.csv'
    pd.concat([d[d.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL+'/corrected_soccer']=dict(plan=plan,selection=json.loads((RESULT/'corrected_soccer_selection.json').read_bytes()),validation=proof);dump(path,d)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(a[cols].to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',nargs='?',choices=['run','confidence_floor','floor_price','goal_qualified_followup','price_buffer','corrected_soccer'],default='run')
    globals()[parser.parse_args().stage]()
