"""Validate report participants against native API events and dated rosters."""
import collections,hashlib,json
from common import ROOT_OUT,PROJECT,read_db,dump,stamp
from collect_nhl_event_players import VERSION,EventRows,surname_matches
from validate_shifts import seconds,key


def main():
    counts=collections.Counter();examples=[];coverage=[]
    with read_db(ROOT_OUT/'nhl_event_players.sqlite') as db:records=[json.loads(r[0]) for r in db.execute('SELECT body FROM games')]
    for g in records:
        if g['parser_version']!=VERSION:continue
        raw=[]
        for source in g['sources']:
            blob=(PROJECT/source['raw_file']).read_bytes()
            assert hashlib.sha256(blob).hexdigest()==source['sha256'];raw.append(blob);counts['source_hashes_checked']+=1
        parser=EventRows();parser.feed(raw[0].decode('utf8',errors='replace'));printed={r['report_event_id']:r for r in parser.rows}
        pbp=json.loads(raw[1]);assert str(pbp['id'])==g['official_game_id'] and pbp['gameDate']==g['date']
        plays={r['eventId']:r for r in pbp['plays']};roster={str(r['playerId']):r for r in pbp['rosterSpots']}
        for row in g['rows']:
            source=plays[row['event_id']];assert source['typeDescKey']==row['result']
            assert seconds(source['timeInPeriod'])==row['seconds'] and source['periodDescriptor']['number']==row['period']
            assert str(source['details'].get('shootingPlayerId',source['details'].get('scoringPlayerId')))==row['shooter_id']
            for rid in row['report_event_ids']:
                cells=printed[rid];assert int(cells['cells'][1])==row['period'] and seconds(cells['cells'][3].split()[0])==row['seconds']
                for side,team in [('A','awayTeam'),('B','homeTeam')]:
                    normalized=row['participants'][side];assert len(normalized)==len(set(normalized))
                    jersey_to_pid={roster[pid]['sweaterNumber']:pid for pid in normalized}
                    assert set(jersey_to_pid)=={int(p['number'].strip()) for p in cells['players'][side]}
                    for p in cells['players'][side]:
                        pid=jersey_to_pid[int(p['number'].strip())]
                        assert roster[pid]['teamId']==pbp[team]['id']
                        assert row['positions'][pid]==roster[pid]['positionCode']
                        assert surname_matches(p['title'].split(' - ',1)[1],roster[pid])
            counts['validated_events']+=1
        assert len(g['rows'])+len(g['unmatched_events'])==g['eligible_events']
        coverage.append(dict(game_id=g['game_id'],date=g['date'],eligible_events=g['eligible_events'],matched_events=len(g['rows']),unresolved_events=len(g['unmatched_events']),
                             matched_pct=100*len(g['rows'])/g['eligible_events'] if g['eligible_events'] else None))
        counts['games']+=1;counts['eligible_events']+=g['eligible_events'];counts['unresolved_events']+=len(g['unmatched_events'])
        if g['official_game_id'] in ['2021020001','2023020001','2024021238']:
            r=g['rows'][0];examples.append(dict(game_id=g['game_id'],date=g['date'],event_id=r['event_id'],source_url=g['sources'][0]['url'],
                report_event_ids=r['report_event_ids'],period=r['period'],seconds=r['seconds'],teams={s:pbp[t]['abbrev'] for s,t in [('A','awayTeam'),('B','homeTeam')]},
                raw_jerseys={s:[int(p['number']) for p in printed[r['report_event_ids'][0]]['players'][s]] for s in ['A','B']},normalized_native_player_ids=r['participants'],match=True))
    assert len(examples)==3,'Three completed pilot games required'
    dump(ROOT_OUT/'nhl_event_players_validation.json',dict(at_utc=stamp(),counts=dict(counts),examples=examples,game_coverage=coverage,
         unresolved_policy='All unmatched native API events remain in the repair ledger; no substitute participant identities are fabricated.'))
    print(json.dumps(dict(counts)),flush=True)


if __name__=='__main__':main()
