"""Test additional official club results in the existing soccer winner recipe.

Only score-strength, recent workload and rest summaries change. New result-only
matches do not fabricate player appearances or erase observed roster history.
"""
import collections
import copy
import json
import pickle
import numpy as np
import pandas as pd
from sklearn.metrics import log_loss
from common import ROOT_OUT,PROJECT,read_db,dump,stamp,file_sha256
from final_pipeline import discard_work,cleanup

LABEL='soccer_additional_club_history'
RESULT=ROOT_OUT/'simulation_results/feature_revisions'/LABEL
FIELDS=['f_elo_diff','f_rest_days_diff','f_rest_days_sum','f_games_7d_diff',
        'f_margin_diff','f_margin_sum','f_home_attack','f_away_attack','f_home_defence','f_away_defence']


def paired_comparison(candidate,reference):
    a=candidate.set_index('game_id');b=reference.set_index('game_id').loc[a.index]
    y=a.target.to_numpy(int);assert np.array_equal(y,b.target.to_numpy(int))
    delta=-np.log(a[['p0','p1','p2']].to_numpy()[np.arange(len(a)),y])+np.log(b[['p0','p1','p2']].to_numpy()[np.arange(len(a)),y])
    blocks=pd.DataFrame(dict(fold=a.fold,delta=delta)).groupby('fold').delta.agg(['sum','count'])
    draws=np.random.default_rng(916).integers(0,len(blocks),size=(3000,len(blocks)))
    sample=blocks['sum'].to_numpy()[draws].sum(axis=1)/blocks['count'].to_numpy()[draws].sum(axis=1)
    result=dict(at_utc=stamp(),paired_logloss_change=float(delta.mean()),
        month_block95_interval=np.quantile(sample,[.025,.975]).tolist(),adjusted_for_repeated_research=False)
    dump(RESULT/'paired_probability_comparison.json',result)
    return result


def summaries(targets,history,keys):
    events=history.sort_values(['available_time','game_id']).to_dict('records');pos=0
    ratings=collections.defaultdict(lambda:1500.);past=collections.defaultdict(lambda:collections.deque(maxlen=60));out=[]
    def ewm(h,field):
        rows=[(.94**i,r[field]) for i,r in enumerate(reversed(h))]
        return sum(w*v for w,v in rows)/sum(w for w,v in rows) if rows else np.nan
    for r in targets.sort_values(['prediction_time','game_id']).itertuples():
        while pos<len(events) and events[pos]['available_time']<r.prediction_time:
            g=events[pos];pos+=1;a,b=keys[g['game_id'],'A'],keys[g['game_id'],'B']
            expected=1/(1+10**((ratings[b]+60-ratings[a])/400))
            actual=.5 if g['scoreA']==g['scoreB'] else float(g['scoreA']>g['scoreB']);change=20*(actual-expected)
            for key,side,opp in [(a,'A','B'),(b,'B','A')]:
                past[key].append(dict(scored=g['score'+side],conceded=g['score'+opp],margin=g['score'+side]-g['score'+opp],start_time=g['start_time'],available_time=g['available_time']))
            ratings[a]+=change;ratings[b]-=change
        sidevalues=[]
        for side in ['A','B']:
            k=keys[r.game_id,side];h=list(past[k])
            assert not h or max(x['available_time'] for x in h)<r.prediction_time
            sidevalues.append(dict(elo=ratings[k],rest=min(120,(r.start_time-h[-1]['start_time']).total_seconds()/86400) if h else np.nan,
                workload=sum((r.start_time-x['start_time']).total_seconds()<7*86400 for x in h),
                margin=ewm(h,'margin'),attack=ewm(h,'scored'),defence=ewm(h,'conceded'),observations=len(h)))
        a,b=sidevalues
        out.append(dict(game_id=r.game_id,f_elo_diff=b['elo']-a['elo'],f_rest_days_diff=b['rest']-a['rest'],
            f_rest_days_sum=b['rest']+a['rest'],f_games_7d_diff=b['workload']-a['workload'],
            f_margin_diff=b['margin']-a['margin'],f_margin_sum=b['margin']+a['margin'],
            f_home_attack=b['attack'],f_away_attack=a['attack'],f_home_defence=b['defence'],f_away_defence=a['defence'],
            teamA_prior_games=a['observations'],teamB_prior_games=b['observations']))
    return pd.DataFrame(out).set_index('game_id')


def main():
    import models,features
    import team_context_features as context
    import uefa_exposure_features as exposure
    import additional_soccer_features as additional
    from soccer_clock_recovery import aliases
    import soccer_tie_context as simulation
    work=ROOT_OUT/'_work'/LABEL
    assert not work.exists() and not (RESULT/'validation.json').exists()
    work.mkdir(parents=True);RESULT.mkdir(exist_ok=True)
    for module in [context,exposure,additional]:module.OUT=work
    proof=json.loads((ROOT_OUT/'retention/uefa_additional_club_history_validation.json').read_bytes());assert proof['status']=='PASS'
    extra_path=ROOT_OUT/'soccer_additional_club_results.parquet';assert file_sha256(extra_path)==proof['output_sha256']
    recipe=json.loads((ROOT_OUT/'simulation_results/feature_revisions/soccer_pooled_scale/experiment_plan.json').read_bytes())['recipe']
    dump(RESULT/'experiment_plan.json',dict(at_utc=stamp(),hypothesis='Add3552official Europa/Conference score histories to sparse-club team strength, score rates,rest and workload. Preserve player summaries until actual player reports are acquired.',
        changed_fields=FIELDS,source_sha256=proof['output_sha256'],recipe=recipe,
        history_from='2021-01-01',predictions_from='2024-01-01',
        gate='Lower pooled2024/25 multiclass logloss AND Brier than identical clock-repaired reference. No price/return selection.2026only after passing; retrospective.',
        source_correction='Verified native terminal clocks apply after player-source merging.',
        scope='Same six target competitions; additional competitions enter prior team history only. Nations are covered separately in extra-time research.',
        strategy='Unchanged fixed$5per percentage point of positive price advantage, pre12, one outcome perprovider/game, $2000cash only.',app_changed=False))
    complete=False
    try:
        g,o,p,keys,stats,metrics,evidence,labels=context.context_sources(include_exposure=True,include_uefa_exposure=True)
        print(json.dumps(dict(stage='build_corrected_base',games=len(g),player_rows=len(p))),flush=True)
        base,checks=features.build('soccer',g,o,p,keys,stats,metrics)
        base['observation_available_time']=base.available_time;base['available_time']=base.game_id.map(labels.set_index('game_id').available_time)
        base=aliases(base).set_index('game_id')
        control=summaries(g,g,keys).loc[base.index]
        assert np.allclose(base[FIELDS],control[FIELDS],atol=1e-10,rtol=0,equal_nan=True),'Independent score-history replay differs from full feature builder'
        extra=pd.read_parquet(extra_path).rename(columns={'regulation_scoreA':'scoreA','regulation_scoreB':'scoreB'})
        with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
            registry={(code,str(native)):json.loads(body)['team_id'] for code,native,body in db.execute('SELECT * FROM _eu_team_identity')}
        for r in extra.itertuples():
            for side in ['A','B']:
                native=str(getattr(r,'team'+side+'_id'));keys[r.game_id,side]=registry.get(('UCL',native),'UEFA Champions League:'+native)
        for c in ['start_time','available_time']:extra[c]=pd.to_datetime(extra[c],utc=True,format='mixed')
        hist=pd.concat([g,extra],ignore_index=True);assert hist.game_id.is_unique
        revised=summaries(g,hist,keys).loc[base.index]
        candidate=base.copy();candidate[FIELDS]=revised[FIELDS]
        assert candidate.drop(columns=FIELDS).equals(base.drop(columns=FIELDS))
        cut=pd.Timestamp('2025-01-01',tz='UTC');prefix=summaries(g[g.prediction_time.lt(cut)],hist[hist.available_time.lt(cut)],keys)
        pd.testing.assert_frame_equal(prefix,revised.loc[prefix.index],check_exact=True)
        changed=~np.isclose(base[FIELDS],candidate[FIELDS],atol=1e-12,rtol=0,equal_nan=True)
        coverage=pd.DataFrame(dict(game_id=base.index,year=base.prediction_time.dt.year,changed_features=changed.sum(axis=1),
            previous_min_team_history=control[['teamA_prior_games','teamB_prior_games']].min(axis=1),
            enriched_min_team_history=revised[['teamA_prior_games','teamB_prior_games']].min(axis=1)))
        coverage.to_csv(RESULT/'history_coverage.csv',index=False)
        frame=candidate.reset_index();frame.to_parquet(work/'soccer_features.parquet',index=False)
        feature_proof=dict(status='PASS',source_clock_repairs=evidence.get('native_terminal_clock_repairs'),rows=len(frame),
            source_games=len(hist),additional_games=len(extra),changed_rows=int(changed.any(axis=1).sum()),
            changed_columns={c:int(changed[:,i].sum()) for i,c in enumerate(FIELDS)},prefix_invariant_rows=len(prefix),
            observed_player_features_unchanged=True,source_sha256=proof['output_sha256'],feature_sha256=file_sha256(work/'soccer_features.parquet'))
        dump(RESULT/'feature_validation.json',feature_proof)
        print(json.dumps(dict(stage='club_history_features_ready',rows=len(frame),affected=int(changed.any(axis=1).sum()))),flush=True)
        name='extra_club_history';models.OUT=work;models.CANDIDATES[name]=copy.deepcopy(recipe)
        dev=models.run('soccer','development',[name]);dev['variant']='candidate'
        refs=pd.read_parquet(ROOT_OUT/'simulation_results/feature_revisions/soccer_clock_recovery/predictions.parquet')
        refs=refs[refs.variant.eq('clock_repaired')].copy();refs['variant']='reference'
        reference=refs[refs.prediction_time.dt.year.lt(2026)];assert set(dev.game_id)==set(reference.game_id)
        paired_comparison(dev,reference)
        pooled=[]
        for name_,f in [('candidate',dev),('reference',reference)]:
            probs=f[['p0','p1','p2']].to_numpy();y=f.target.to_numpy(int)
            pooled.append(dict(variant=name_,log_loss=log_loss(y,probs,labels=[0,1,2]),brier=float(np.mean(np.sum((probs-np.eye(3)[y])**2,axis=1)))))
        passed=pooled[0]['log_loss']<pooled[1]['log_loss'] and pooled[0]['brier']<pooled[1]['brier']
        dump(RESULT/'selection.json',dict(at_utc=stamp(),passed=bool(passed),scores=pooled,adopted=False))
        joined=pd.concat([dev,reference],ignore_index=True);joined.to_parquet(RESULT/'development_predictions.parquet',index=False)
        models.metrics(joined).to_csv(RESULT/'development_metrics.csv',index=False)
        package=pickle.loads((work/'model_runs/soccer/development'/(name+'.pkl')).read_bytes())
        matrix=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
        sample=dev[dev.fold.eq(package['boundary'].strftime('%Y-%m'))].head(20)
        x=matrix.loc[sample.game_id,package['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
        actual=models.apply_calibration(package['model'].predict_proba(x),package['calibrator'])
        assert np.allclose(actual,sample[['p0','p1','p2']],atol=1e-12,rtol=0)
        assert dev.train_label_max.lt(dev.prediction_time).all() and dev.calibration_label_max.lt(dev.prediction_time).all()
        test=None
        if passed:
            dump(work/'soccer_selection.json',dict(selected_candidates=[name]));test=models.run('soccer','evaluation',[name]);test['variant']='candidate'
            test=pd.concat([test,refs[refs.prediction_time.dt.year.eq(2026)]],ignore_index=True)
            test.to_parquet(RESULT/'evaluation_predictions.parquet',index=False);models.metrics(test).to_csv(RESULT/'evaluation_metrics.csv',index=False)
        simulation.RESULT=RESULT;simulation.simulate(joined,test)
        dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),feature_validation=feature_proof,forecast_replays=len(sample),
            development_forecasts=len(dev),gate_passed=bool(passed),evaluated2026=bool(passed),adopted=False,app_changed=False))
        complete=True
    except Exception as exc:
        path=ROOT_OUT/'simulation_results/failed_runs.json';failures=json.loads(path.read_bytes()) if path.exists() else []
        failures.append(dict(at_utc=stamp(),experiment=LABEL,error=repr(exc),unfinished_work_preserved=True));dump(path,failures);raise
    finally:
        if complete:discard_work(work)
        cleanup()


if __name__=='__main__':main()
