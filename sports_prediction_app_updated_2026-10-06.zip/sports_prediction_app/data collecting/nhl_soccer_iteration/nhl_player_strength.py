"""Dated NHL player strength, using earlier games and opening-roster releases.

Game-usage regression estimates predictive associations, not causal adjusted
plus-minus. Unrecorded minutes remain NULL. Such games cannot fit usage ratings,
but still enter team histories and the winner-model training population.
"""
import collections,json,sqlite3
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.linear_model import Ridge
from threadpoolctl import threadpool_limits
from common import ROOT_OUT,PREVIOUS,read_db,dump,stamp,file_sha256
from nhl_identity_features import history_keys,identity_evidence
from repair_nhl_player_exposure import apply as apply_repairs

WORK=ROOT_OUT/'_work/nhl_player_strength'
FIELDS=['f_gran_adjusted_skater_goal_margin','f_gran_adjusted_goalie_goal_margin','f_gran_adjusted_skater_xg_margin']


def load():
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games=pd.read_sql_query("SELECT * FROM nhl_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30' AND phase IN ('Regular Season','Playoffs','Preseason')",db)
        players=pd.read_sql_query('SELECT game_id,side,official_player_id,position,played,minutes,available_at_utc FROM nhl_player_games',db)
    for c in ['prediction_time','available_time','start_time']:games[c]=pd.to_datetime(games[c],utc=True,format='mixed')
    players=apply_repairs(players[players.game_id.isin(games.game_id)]).copy()
    players['role']=np.where(players.position.eq('G'),'goalie','skater')
    assert (players.minutes.isna()|players.minutes.ge(0)).all()
    assert not players.duplicated(['game_id','side','official_player_id']).any()
    assert pd.to_datetime(players.available_at_utc,utc=True,format='mixed').le(players.game_id.map(games.set_index('game_id').available_time)).all()
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        targets=pd.read_sql_query('SELECT game_id,side,regulation_goals,xg FROM nhl_team_shot_quality',db)
        rosters=pd.read_sql_query("SELECT * FROM nhl_opening_roster_snapshots WHERE roster_status='active_roster'",db)
    labels=targets.pivot(index='game_id',columns='side',values='regulation_goals')
    xg=targets.pivot(index='game_id',columns='side',values='xg')
    games['regulation_scoreA']=games.game_id.map(labels.A);games['regulation_scoreB']=games.game_id.map(labels.B)
    assert games[['regulation_scoreA','regulation_scoreB']].notna().all().all()
    games['goal_margin']=games.regulation_scoreB-games.regulation_scoreA
    games['xg_margin']=games.game_id.map(xg.B-xg.A)
    keys,_=history_keys(games,True)
    return games,players,rosters,keys


def derive(games,players,rosters,keys,save=True,rating_provider=None,fields=None,projection=None):
    fields=FIELDS if fields is None else fields
    games=games.sort_values(['prediction_time','game_id']).reset_index(drop=True)
    missing=set(players.loc[players.minutes.isna(),'game_id'])
    used=players[players.minutes.gt(0)].copy()
    ids=sorted(set(zip(used.role,used.official_player_id)));lookup={key:i for i,key in enumerate(ids)}
    skater=np.array([role=='skater' for role,pid in ids]);goalie=~skater
    den=used.groupby(['game_id','side','role']).minutes.transform('sum')
    used['exposure']=used.minutes/den*np.where(used.role.eq('goalie'),1.,5.)
    counts=used.groupby('game_id').apply(lambda f:f[['side','role']].drop_duplicates().shape[0],include_groups=False)
    complete=~games.game_id.isin(missing)&games.game_id.map(counts).eq(4)
    index=games.reset_index().set_index('game_id')['index'].to_dict()
    X=sparse.coo_matrix((used.exposure.to_numpy()*np.where(used.side.eq('B'),1.,-1.),
        (used.game_id.map(index),[lookup[r,p] for r,p in zip(used.role,used.official_player_id)])),shape=(len(games),len(ids))).tocsr()
    assert np.allclose(np.asarray(X[complete.to_numpy()][:,skater].sum(axis=1)),0,atol=1e-10)
    assert np.allclose(np.asarray(X[complete.to_numpy()][:,goalie].sum(axis=1)),0,atol=1e-10)
    appearances=players[players.minutes.gt(0)|players.played.eq(1)]
    bygame={k:f for k,f in appearances.groupby(['game_id','side'],sort=False)}
    empty=appearances.iloc[:0]
    events=[];release_audit=[]
    for (season,team,at),group in rosters.groupby(['season','team_id','available_at_utc']):
        valid=group.identity_verified.eq(1).all() and group.official_player_id.notna().all() and group.position.notna().all()
        release_audit.append(dict(season=season,team_id=str(team),available_at_utc=at,active_players=len(group),applied=bool(valid)))
        if valid:events.append((pd.Timestamp(at),0,str(team),group))
    events.extend((g.available_time,1,g.game_id,g) for g in games.itertuples())
    events.sort(key=lambda e:(e[0],e[1],e[2]));cursor=0
    history=collections.defaultdict(lambda:collections.deque(maxlen=5))
    ph=collections.defaultdict(lambda:collections.deque(maxlen=5));last_team={};role_minutes=collections.defaultdict(list)
    ph_at={};role_minutes_at={}
    identity_at=pd.Timestamp(identity_evidence()['conservative_available_at_utc'])
    def key_for(native,at):
        if str(native)=='68':assert at>=identity_at;return '59'
        return str(native)
    def prior_weight(pid):
        if ph[pid]:return float(np.mean(ph[pid]))
        if role_minutes[pid[0]]:return float(np.median(role_minutes[pid[0]]))
        return None
    fits={};audits=[];outputs=[]
    for number,g in enumerate(games.itertuples(),1):
        while cursor<len(events) and events[cursor][0]<g.prediction_time:
            at,kind,key,event=events[cursor];cursor+=1
            if kind==1:
                for side in ['A','B']:
                    team=keys[event.game_id,side];pool=[]
                    for p in bygame.get((event.game_id,side),empty).itertuples():
                        pid=(p.role,p.official_player_id);last_team[pid]=team
                        observed=pd.notna(p.minutes) and p.minutes>0
                        weight=float(p.minutes) if observed else prior_weight(pid)
                        if observed:
                            ph[pid].append(float(p.minutes));role_minutes[p.role].append(float(p.minutes))
                            ph_at[pid]=at;role_minutes_at[p.role]=at
                        if weight is not None:pool.append((pid,weight,not observed))
                    # Do not replace a useful past pool with an empty sparse report.
                    if pool:history[team].append((pool,at,'observed_game'))
            else:
                team=key_for(key,at);pool=[];members=[];known=collections.defaultdict(list)
                for p in event.itertuples():
                    pid=('goalie' if p.position=='G' else 'skater',str(p.official_player_id))
                    weight=float(np.mean(ph[pid])) if ph[pid] else None
                    if weight is not None:known[pid[0]].append(weight)
                    members.append((pid,weight));last_team[pid]=team
                for pid,weight in members:
                    estimated=weight is None
                    if estimated:
                        values=known[pid[0]] or role_minutes[pid[0]]
                        if not values:continue
                        weight=float(np.median(values))
                    pool.append((pid,weight,estimated))
                history[team].clear();history[team].append((pool,at,'opening_roster'))
        fold=g.prediction_time.strftime('%Y-%m');boundary=pd.Timestamp(fold+'-01',tz='UTC')
        if fold not in fits:
            prior=(games.available_time.lt(boundary)&complete).to_numpy();fitted=None
            if rating_provider is not None:
                fitted,fit_audit=rating_provider.fit(boundary,ids)
                if fit_audit:audits.append(fit_audit)
            elif prior.sum()>=100:
                coefficients=[];fit_counts=[];errors=[];goal_seen=np.zeros(len(ids),dtype=bool)
                for target,allowed in [('goal_margin',np.ones(len(ids),dtype=bool)),('xg_margin',skater)]:
                    mask=prior&games[target].notna().to_numpy();coef=np.zeros(len(ids));fit_counts.append(int(mask.sum()))
                    if mask.sum()>=100:
                        seen=np.flatnonzero((np.asarray(abs(X[mask]).sum(axis=0)).ravel()>0)&allowed)
                        if target=='goal_margin':goal_seen[seen]=True
                        with threadpool_limits(limits=2):
                            model=Ridge(alpha=20,fit_intercept=True,solver='lsqr',tol=1e-10).fit(X[mask][:,seen],games.loc[mask,target])
                        coef[seen]=model.coef_
                        residual=games.loc[mask,target].to_numpy()-model.predict(X[mask][:,seen])
                        error=float(max(abs(np.asarray(X[mask][:,seen].T@residual).ravel()-20*model.coef_)))
                        assert error<1e-4 and abs(residual.sum())<1e-5
                        errors.append(error)
                    coefficients.append(coef)
                fitted=dict(goal=coefficients[0],xg=coefficients[1],xg_available=fit_counts[1]>=100,training_games=int(prior.sum()),goal_seen=goal_seen)
                audits.append(dict(fold=fold,training_games=int(prior.sum()),xg_training_games=fit_counts[1],source_max=games.loc[prior,'available_time'].max(),normal_equation_error=max(errors)))
            fits[fold]=fitted
        fitted=fits[fold];vector=np.zeros(len(ids));valid=True;latest=[];seeds=0;estimated=0
        for side in ['A','B']:
            weights=collections.Counter()
            for pool,at,kind in history[keys[g.game_id,side]]:
                latest.append(at);seeds+=int(kind=='opening_roster')
                for pid,weight,imputed in pool:
                    if last_team.get(pid)==keys[g.game_id,side]:weights[pid]+=weight;estimated+=int(imputed)
            for role in ['skater','goalie']:
                den=sum(w for (r,p),w in weights.items() if r==role)
                if den<=0:valid=False;continue
                for pid,w in weights.items():
                    if pid[0]==role and pid in lookup:vector[lookup[pid]]+=(1 if side=='B' else -1)*(5 if role=='skater' else 1)*w/den
        assert not latest or max(latest)<g.prediction_time
        row=dict(game_id=g.game_id,player_rating_source_max_utc=max(latest) if latest else pd.NaT,rating_fit_cutoff=boundary,
                 rating_training_games=fitted['training_games'] if fitted else 0,opening_roster_observations=seeds,imputed_usage_weights=estimated)
        row.update(dict.fromkeys(fields,np.nan))
        if fitted is not None and valid:
            if rating_provider is not None:row.update(rating_provider.predict(vector,fitted))
            else:
                row[FIELDS[0]]=float(vector[skater]@fitted['goal'][skater]);row[FIELDS[1]]=float(vector[goalie]@fitted['goal'][goalie])
                row[FIELDS[2]]=float(vector@fitted['xg']) if fitted['xg_available'] else np.nan
        if projection is not None:
            assert rating_provider is None, 'Projected game-usage ratings use the existing goal/xG coefficients'
            info=projection.get(g.game_id)
            names=['projected_skater_goal_margin','projected_first_goalie_goal_margin','projected_skater_xg_margin']
            row.update(dict.fromkeys(names,np.nan))
            row.update(projected_source_utc=pd.NaT,projected_players=0,projected_weight_fallbacks=0,
                       projected_unseen_rating_players=0,projected_pool_json=None,projected_weight_source_max_utc=pd.NaT)
            if info is not None:
                at=pd.Timestamp(info['available_at_utc']);assert at<=g.prediction_time<g.start_time
                row['projected_source_utc']=at
                vec=np.zeros(len(ids));okay=True;pool_audit=[];weight_sources=[]
                known_rating=lambda pid:fitted is not None and pid in lookup and bool(fitted['goal_seen'][lookup[pid]])
                for side in ['A','B']:
                    people=info[side];row['projected_players']+=len(people)
                    # First-listed goalie is an uncertain projected identity,
                    # not an assertion that this person eventually starts.
                    goalies=[x for x in people if x['role']=='goalie']
                    skaters=[x for x in people if x['role']=='skater']
                    assert 1<=len(goalies)<=3 and 16<=len(skaters)<=20
                    weighted=[]
                    for person in skaters:
                        pid=('skater',person['player_id']);w=prior_weight(pid)
                        fallback=not bool(ph[pid]);row['projected_weight_fallbacks']+=int(fallback)
                        if w is None or w<=0:okay=False;continue
                        weight_sources.append(ph_at[pid] if ph[pid] else role_minutes_at[pid[0]])
                        weighted.append((pid,float(w),fallback))
                    total=sum(x[1] for x in weighted)
                    if total<=0:okay=False;continue
                    for pid,w,fallback in weighted:
                        exposure=5*w/total;known=known_rating(pid)
                        if pid in lookup:vec[lookup[pid]]+=(1 if side=='B' else -1)*exposure
                        row['projected_unseen_rating_players']+=int(not known)
                        pool_audit.append(dict(side=side,role='skater',player_id=pid[1],exposure=exposure,
                                               prior_minutes=w,weight_fallback=fallback,rated_from_past_games=known))
                    first=goalies[0];pid=('goalie',first['player_id']);known=known_rating(pid)
                    if pid in lookup:vec[lookup[pid]]+=(1 if side=='B' else -1)
                    row['projected_unseen_rating_players']+=int(not known)
                    pool_audit.append(dict(side=side,role='first_listed_goalie',player_id=pid[1],exposure=1.,
                                           prior_minutes=None,weight_fallback=False,rated_from_past_games=known))
                row['projected_pool_json']=json.dumps(pool_audit,sort_keys=True)
                if weight_sources:
                    assert max(weight_sources)<g.prediction_time
                    row['projected_weight_source_max_utc']=max(weight_sources)
                if fitted is not None and okay:
                    row[names[0]]=float(vec[skater]@fitted['goal'][skater])
                    row[names[1]]=float(vec[goalie]@fitted['goal'][goalie])
                    row[names[2]]=float(vec@fitted['xg']) if fitted['xg_available'] else np.nan
        outputs.append(row)
        if number%1000==0:print(json.dumps(dict(stage='dated_player_strength',games=number,total=len(games),prefix_check=not save)),flush=True)
    if save:
        dump(WORK/'rating_fit_audit.json',audits);pd.DataFrame(release_audit).to_csv(WORK/'release_coverage.csv',index=False)
    return pd.DataFrame(outputs),dict(games=len(games),complete_usage_games=int(complete.sum()),incomplete_usage_games=int((~complete).sum()),fitted_months=len(audits))


def build():
    WORK.mkdir(parents=True,exist_ok=True)
    games,players,rosters,keys=load()
    plan=dict(at_utc=stamp(),hypothesis='Joint player contribution ratings and dated opening rosters improve forecasts beyond raw recent player averages.',
        history_start='2021-01-01',forecast_start='2024-01-01',scope=['Regular Season','Playoffs','Preseason'],features=FIELDS,
        regression='Monthly expanding Ridge alpha20. Complete official usage rows fit regulation home-minus-away goals jointly for skaters and goalies; full-game prior-year internal xG fits skaters. Usage normalized to5skaters+1goalie perteam. Unseen fitted players have coefficient0.',
        missing='Unknown actual minutes are never zero. Incomplete usage games remain in winner-model training and team histories, but cannot fit player-usage regression. Verified appearances update roster; unknown forecast usage weights use only earlier player means or same-role medians and are counted separately.',
        roster='Last5observed team pools with last-known team filter. Fully identified dated active opening roster resets pool; expires after5game observations. No future starting lineup.',
        comparison='All-phase control and augmented candidate use identical forecasts and source histories; original retained baseline additionally compared on common games. Thus extra preseason games cannot alone explain a player-feature effect.',
        selection='First require lower2024/25 pooled mean component log loss versus all-phase control. Then test monthly choice using only mean prior completed out-of-fit forecast errors; price and return never choose the model.2026results retrospective, not untouched.',
        stakes='Unchanged pre12 closest-prior quotes age<=24h; both component p/price>=1.10;1%NAV/bet;20%open-cost cap; annual$10000reset; no costs.',
        limitation='Predictive game-usage associations, not causal shift-level adjusted plus-minus. Historical source revision times incompletely known.',
        source_hashes={name:file_sha256(ROOT_OUT/name) for name in ['nhl_player_exposure_repairs.parquet','nhl_regulation_score_repairs.parquet','nhl_on_ice.sqlite','nhl_shot_detail.parquet']})
    if (WORK/'plan.json').exists():
        old=json.loads((WORK/'plan.json').read_bytes());assert all(old[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(WORK/'plan.json',plan)
    print(json.dumps(dict(stage='source_inputs',games=len(games),player_rows=len(players))),flush=True)
    basepath=WORK/'base_features.parquet'
    if basepath.exists():base=pd.read_parquet(basepath)
    else:
        import features,nhl_identity_features
        g,o,p,_,stats,metrics,_=features.sources('nhl',include_preseason=True)
        assert set(g.game_id)==set(games.game_id)
        needed=['game_id','side','available_at_utc','player_id','official_player_id','minutes','position','saves','shots_against']+metrics
        p=apply_repairs(p[list(dict.fromkeys(needed+['played']))])
        base,_=nhl_identity_features.derive(g,o,p,stats,metrics,repaired=True,regulation_labels=games)
        base.to_parquet(basepath,index=False);del o,p
    extra,audit=derive(games,players,rosters,keys)
    early=games[games.prediction_time.lt(pd.Timestamp('2025-01-01',tz='UTC'))].copy()
    prefix,_=derive(early,players[players.game_id.isin(early.game_id)],rosters[pd.to_datetime(rosters.available_at_utc,utc=True,format='mixed').lt(pd.Timestamp('2025-01-01',tz='UTC'))],keys,False)
    pd.testing.assert_frame_equal(prefix.set_index('game_id'),extra.set_index('game_id').loc[prefix.game_id],check_exact=False,rtol=0,atol=1e-10)
    extra.to_parquet(ROOT_OUT/'nhl_roster_strength_features.parquet',index=False)
    frame=base.merge(extra,on='game_id',validate='one_to_one');frame.to_parquet(WORK/'nhl_features.parquet',index=False)
    report=dict(status='PASS',at_utc=stamp(),**audit,prefix_invariant_rows=len(prefix),new_features=3,source_cutoffs_checked=True,
        feature_sha256=file_sha256(WORK/'nhl_features.parquet'),derived_data_sha256=file_sha256(ROOT_OUT/'nhl_roster_strength_features.parquet'))
    dump(WORK/'feature_validation.json',report);dump(ROOT_OUT/'retention/nhl_roster_strength_validation.json',report);print(json.dumps(report),flush=True)


def publish():
    """Publish only the validated dated derived facts, not temporary matrices."""
    validation=json.loads((ROOT_OUT/'retention/nhl_roster_strength_validation.json').read_bytes())
    assert validation['status']=='PASS'
    path=ROOT_OUT/'nhl_roster_strength_features.parquet'
    assert file_sha256(path)==validation['derived_data_sha256']
    frame=pd.read_parquet(path).drop(columns=['date','prediction_time'],errors='ignore')
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        dates=pd.read_sql_query('SELECT game_id,date,prediction_time FROM nhl_games',db)
    frame=frame.merge(dates,on='game_id',validate='one_to_one')
    for col in ['prediction_time','player_rating_source_max_utc','rating_fit_cutoff']:
        frame[col]=pd.to_datetime(frame[col],utc=True,format='mixed')
    assert (frame.player_rating_source_max_utc.isna()|frame.player_rating_source_max_utc.lt(frame.prediction_time)).all()
    meanings={
      'game_id':('Canonical NHL game identifier','identifier'), 'date':('Official game calendar date','YYYY-MM-DD'),
      'prediction_time':('Pre12 prediction cutoff: no later observation enters these features','UTC timestamp'),
      'player_rating_source_max_utc':('Latest included roster release or completed player appearance','UTC timestamp'),
      'rating_fit_cutoff':('Monthly boundary; only earlier completed games fit player coefficients','UTC timestamp'),
      'rating_training_games':('Earlier games with complete official player minutes used for goal-margin regression','games'),
      'opening_roster_observations':('Active dated opening-roster seed observations still in the two five-observation team pools','observations'),
      'imputed_usage_weights':('Roster-pool weights derived from earlier means/medians because no observed usage weight was available; actual source minutes remain NULL','weights'),
      FIELDS[0]:('Home-minus-away sum of earlier jointly fitted skater goal-margin coefficients weighted by dated expected usage','regulation goals'),
      FIELDS[1]:('Home-minus-away sum of earlier jointly fitted goalie goal-margin coefficients weighted by dated expected usage','regulation goals'),
      FIELDS[2]:('Home-minus-away sum of earlier fitted skater expected-goal-margin coefficients; shot xG model itself uses only prior years','expected goals')}
    table='nhl_roster_strength_features';source='Official NHL completed-game player minutes/participation and dated opening-roster announcements; predictive Ridge20 associations derived by nhl_player_strength.py. Prior-year internal xG is not an official NHL statistic.'
    sql=frame.copy()
    for col in ['prediction_time','player_rating_source_max_utc','rating_fit_cutoff']:sql[col]=sql[col].map(lambda v:v.isoformat() if pd.notna(v) else None)
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        sql.to_sql(table,db,if_exists='replace',index=False)
        for cat in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+cat+' WHERE "table"=?',(table,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(table,len(frame),len(frame.columns)))
        for col in frame:
            meaning,unit=meanings[col];db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(table,col,meaning,unit,source))
            n=int(frame[col].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(table,col,len(frame),n,100*n/len(frame)))
    frame.to_csv(ROOT_OUT/(table+'.csv'),index=False);frame.to_parquet(path,index=False)
    validation.setdefault('derived_component_sha256',validation['derived_data_sha256'])
    validation['derived_data_sha256']=file_sha256(path)
    validation['published_sql_rows']=len(frame);validation['published_sql_columns']=len(frame.columns)
    dump(ROOT_OUT/'retention/nhl_roster_strength_validation.json',validation)
    if (WORK/'feature_validation.json').exists():dump(WORK/'feature_validation.json',validation)


if __name__=='__main__':
    from final_pipeline import discard_work
    if WORK.exists():
        raise RuntimeError('Existing work must be inspected before a new build: '+str(WORK))
    try:
        build();publish()
    finally:
        if WORK.exists():discard_work(WORK)
