"""Verified five-on-five shot events for joint on-ice player estimation.

Reuses original official event reports and shift APIs already acquired. Neither
future lineups nor prices enter player ratings. Event-weighted contributions
are conditional on a shot opportunity, not causal per-minute adjusted plus-minus.
"""
import argparse
import collections
import hashlib
import json
import sqlite3
import numpy as np
import pandas as pd
from common import ROOT_OUT,PREVIOUS,PROJECT,REPORTS,read_db,dump,stamp,file_sha256

LABEL='nhl_joint_chances'
WORK=ROOT_OUT/'_work'/LABEL
RESULT=ROOT_OUT/'simulation_results/feature_revisions'/LABEL
EVENTS='nhl_five_on_five_event_players'
COVERAGE='nhl_five_on_five_event_coverage'


def normalize(game,shots,report,positions,states):
    """Independent event membership check; no duration-based rate inferred."""
    state={int(r['event_id']):r for r in states['shots']}
    # Equal skater counts do not imply both goalies are present. Exact1551
    # distinguishes normal five-on-five from a pulled-goalie sequence.
    eligible={eid for eid,r in state.items() if r['five_on_five'] and r['period_type']=='REG'}
    s=shots[shots.event_id.isin(eligible)].copy()
    assert not s.event_id.duplicated().any()
    sides={str(r['player_id']):r['side'] for r in game['rows']}
    reports={int(r['event_id']):(i,r) for i,r in enumerate(report['rows'])} if report else {}
    player_positions=dict(positions)
    if report:
        assert report['parser_version']==4
        for r in report['rows']:
            for side,pids in r['participants'].items():
                for pid in pids:
                    assert pid not in sides or sides[pid]==side
                    sides[pid]=side;player_positions[pid]=r['positions'][pid]
    pids=sorted(sides);lookup={pid:i for i,pid in enumerate(pids)}
    membership=np.zeros((len(pids),len(s)),dtype=bool)
    periods=s.period.to_numpy();seconds=s.seconds.to_numpy()
    for row in game['rows']:
        if row['duration_seconds']<=0:continue
        active=(periods==row['period'])&(seconds>=row['start_seconds'])&(seconds<=row['end_seconds'])
        membership[lookup[row['player_id']],active]=True
    rows=[];rejects=[];methods=collections.Counter()
    for j,shot in enumerate(s.itertuples()):
        groups={side:[pid for pid in pids if sides[pid]==side and membership[lookup[pid],j]] for side in ['A','B']}
        source_index=None;basis='verified_shift_membership'
        if shot.event_id in reports:
            source_index,r=reports[shot.event_id];groups=r['participants'];basis='official_event_report'
            assert (r['period'],r['seconds'],r['shooting_side'],r['shooter_id'])==(shot.period,shot.seconds,shot.side,str(shot.shooter_id))
        reason=None;skaters={};goalies={}
        for side in ['A','B']:
            if any(pid not in player_positions for pid in groups[side]):reason='unknown_native_player_role';break
            skaters[side]=sorted(pid for pid in groups[side] if player_positions[pid]!='G')
            goalies[side]=sorted(pid for pid in groups[side] if player_positions[pid]=='G')
            if len(set(skaters[side]))!=5 or len(set(goalies[side]))!=1:reason='event_players_do_not_match_exact_five_skater_one_goalie';break
        if reason is None and str(shot.shooter_id) not in skaters[shot.side]:reason='shooter_not_on_shooting_side'
        opposite='B' if shot.side=='A' else 'A'
        if reason is None and pd.notna(shot.goalie_id) and str(int(shot.goalie_id))!=goalies[opposite][0]:reason='defending_goalie_mismatch'
        if reason:
            rejects.append(dict(event_id=int(shot.event_id),reason=reason));continue
        st=state.get(int(shot.event_id));margin=None
        if st:
            assert st['five_on_five'] and st['period_type']=='REG'
            assert (st['side'],st['period'],st['seconds'])==(shot.side,shot.period,shot.seconds)
            margin=st['scoreB_before']-st['scoreA_before']
        rows.append(dict(game_id=game['game_id'],event_id=int(shot.event_id),period=int(shot.period),period_seconds=int(shot.seconds),
            shooting_side=shot.side,shooter_id=str(shot.shooter_id),goalieA_id=goalies['A'][0],goalieB_id=goalies['B'][0],
            skaterA_ids_json=json.dumps(skaters['A']),skaterB_ids_json=json.dumps(skaters['B']),
            result=shot.result,home_score_margin_before=margin,model_xg=float(shot.model_xg) if pd.notna(shot.model_xg) else None,
            shot_model_fit_before_utc=shot.shot_model_fit_before_utc if pd.notna(shot.shot_model_fit_before_utc) else None,
            available_at_utc=game['available_at_utc'],participant_basis=basis,participant_report_row=source_index,
            shot_source_raw_file=shot.source_raw_file,shot_source_sha256=shot.source_sha256))
        methods[basis]+=1
    coverage=dict(game_id=game['game_id'],official_game_id=str(game['official_game_id']),date=game['date'],
        phase=game.get('phase'),available_at_utc=game['available_at_utc'],eligible_events=len(s),matched_events=len(rows),
        unresolved_events=len(rejects),unresolved_pct=100*len(rejects)/len(s) if len(s) else 0.,
        events_with_xg=sum(r['model_xg'] is not None for r in rows),events_with_score_context=sum(r['home_score_margin_before'] is not None for r in rows),
        event_report_events=methods['official_event_report'],shift_verified_events=methods['verified_shift_membership'],
        unresolved_json=json.dumps(rejects),source_json=json.dumps(dict(shifts=game['sources'],event_reports=report['sources'] if report else [],score_state=states.get('source') if states else None),sort_keys=True))
    assert len(rows)+len(rejects)==len(s)
    return rows,coverage


def collect(limit=None):
    WORK.mkdir(parents=True,exist_ok=True);RESULT.mkdir(parents=True,exist_ok=True)
    shot_path=ROOT_OUT/'nhl_shot_detail.parquet';shots=pd.read_parquet(shot_path)
    grouped={k:f for k,f in shots.groupby('game_id',sort=False)}
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        players=pd.read_sql_query('SELECT game_id,official_player_id,position FROM nhl_player_games',db)
        calendar={r['game_id']:dict(r) for r in db.execute('SELECT * FROM nhl_games')}
    positions={gid:dict(zip(f.official_player_id.astype(str),f.position)) for gid,f in players.groupby('game_id')}
    caches=sqlite3.connect(WORK/'normalized.sqlite')
    caches.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,source_signature TEXT,body TEXT);')
    sources={name:file_sha256(ROOT_OUT/name) for name in ['nhl_shifts.sqlite','nhl_event_players.sqlite','nhl_score_state.sqlite','nhl_shot_detail.parquet']}
    dump(RESULT/'source_plan.json',dict(at_utc=stamp(),scope='Every acquired2021-2026official NHL game with regulation five-on-five attempts; all outcomes, phases and price availability included in source normalization.',
        target='Joint player effects conditional on a shot opportunity; do not call these per60or causal adjusted plus-minus.',
        raw_policy='Original official APIs/reports already retained. This stage joins native IDs and revalidates manpower, shooter, goalie and score clocks; no network download or invented source response.',
        missing='Unresolved events explicitly retained in coverage repair evidence. Unknown xG or score staysNULL; not fabricated0.2021has no preceding-year xG model.',
        method_reference='https://arxiv.org/abs/1201.0317',sources=sources))
    with read_db(ROOT_OUT/'nhl_shifts.sqlite') as shifts,read_db(ROOT_OUT/'nhl_event_players.sqlite') as reports,read_db(ROOT_OUT/'nhl_score_state.sqlite') as states:
        tasks=shifts.execute('SELECT game_id,body FROM games ORDER BY game_id').fetchall()
        if limit:tasks=tasks[:limit]
        next_notice=10
        for index,(gid,raw) in enumerate(tasks,1):
            if gid not in grouped:continue
            rr=reports.execute('SELECT body FROM games WHERE game_id=?',(gid,)).fetchone();ss=states.execute('SELECT body FROM games WHERE game_id=?',(gid,)).fetchone()
            rb=rr[0] if rr else '';sb=ss[0] if ss else ''
            signature=hashlib.sha256(('joint-chances-v2'+sources['nhl_shot_detail.parquet']+raw+rb+sb).encode()).hexdigest()
            old=caches.execute('SELECT source_signature FROM games WHERE game_id=?',(gid,)).fetchone()
            if not old or old[0]!=signature:
                from nhl_score_state import parse as score_state
                game=json.loads(raw);game['phase']=calendar[gid]['phase'];r=json.loads(rb) if rb else None
                source_shots=grouped[gid].to_dict('records');raw_sources={(z['source_raw_file'],z['source_sha256']) for z in source_shots}
                assert len(raw_sources)==1
                raw_file,sha=next(iter(raw_sources));blob=(PROJECT/raw_file).read_bytes();assert hashlib.sha256(blob).hexdigest()==sha
                source=dict(raw_file=raw_file,sha256=sha,event_model_sha256=sources['nhl_shot_detail.parquet'],url='https://api-web.nhle.com/v1/gamecenter/'+str(game['official_game_id'])+'/play-by-play')
                state=score_state(calendar[gid],json.loads(blob),source_shots,source)
                if sb:
                    earlier=json.loads(sb);old={z['event_id']:(z['scoreA_before'],z['scoreB_before'],z['five_on_five']) for z in earlier['shots']}
                    assert old=={z['event_id']:(z['scoreA_before'],z['scoreB_before'],z['five_on_five']) for z in state['shots']}
                events,coverage=normalize(game,grouped[gid],r,positions.get(gid,{}),state)
                with caches:caches.execute('INSERT OR REPLACE INTO games VALUES(?,?,?)',(gid,signature,json.dumps(dict(events=events,coverage=coverage),allow_nan=False)))
            percent=100*index/len(tasks)
            if percent>=next_notice or index==len(tasks):
                progress=dict(at_utc=stamp(),stage=LABEL,complete=index,total=len(tasks),percent=round(percent,1))
                dump(RESULT/'collection_progress.json',progress);print(json.dumps(progress),flush=True);next_notice+=10
    count=caches.execute('SELECT COUNT(*) FROM games').fetchone()[0];caches.close()
    dump(WORK/'collection_complete.json',dict(at_utc=stamp(),games=count,pilot=limit is not None,source_hashes=sources))


def publish():
    proof=json.loads((WORK/'collection_complete.json').read_bytes());assert not proof['pilot']
    for name,digest in proof['source_hashes'].items():assert file_sha256(ROOT_OUT/name)==digest
    events=[];coverage=[]
    with read_db(WORK/'normalized.sqlite') as db:
        for row in db.execute('SELECT body FROM games ORDER BY game_id'):
            record=json.loads(row[0]);events.extend(record['events']);coverage.append(record['coverage'])
    e=pd.DataFrame(events);c=pd.DataFrame(coverage)
    assert not e.duplicated(['game_id','event_id']).any() and not c.game_id.duplicated().any()
    assert c.matched_events.sum()==len(e) and c.eligible_events.eq(c.matched_events+c.unresolved_events).all()
    assert e.home_score_margin_before.notna().all()
    for col in ['skaterA_ids_json','skaterB_ids_json']:assert e[col].map(lambda v:len(set(json.loads(v)))==5).all()
    known=e.model_xg.notna();assert e.loc[known,'model_xg'].between(0,1).all()
    assert pd.to_datetime(e.loc[known,'shot_model_fit_before_utc'],utc=True).lt(pd.to_datetime(e.loc[known,'available_at_utc'],utc=True)).all()
    meanings={
      'game_id':('Canonical game identity; joins official game, team and player data','identifier'),
      'event_id':('Native NHL play-by-play event identity within game','identifier'),
      'period':('Regulation period containing the attempt','period number'),
      'period_seconds':('Elapsed game-clock time within the regulation period','seconds'),
      'shooting_side':('Attempting team: A away, B home','A/B'),
      'shooter_id':('Native NHL shooting player identity','identifier'),
      'goalieA_id':('Verified native away goalie on ice','identifier'),
      'goalieB_id':('Verified native home goalie on ice','identifier'),
      'skaterA_ids_json':('Exactly five verified native away skaters on ice','JSON array of IDs'),
      'skaterB_ids_json':('Exactly five verified native home skaters on ice','JSON array of IDs'),
      'result':('Original NHL shot-on-goal, missed-shot or goal event classification','category'),
      'home_score_margin_before':('Home minus away goals strictly before this event, excluding the event itself','goals'),
      'model_xg':('Internal earlier-year shot goal probability; no prior-year fit for2021, kept NULL','probability0..1'),
      'shot_model_fit_before_utc':('Strict upper bound on training observations of the internal shot model','UTC timestamp'),
      'available_at_utc':('Conservative completed-game observation cutoff inherited from dated NHL source; original revision vintage is not guaranteed','UTC timestamp'),
      'participant_basis':('Official event report or exact verified shift-membership fallback','category'),
      'participant_report_row':('Zero-based row in normalized official event-player report; NULL for shift fallback','row index'),
      'shot_source_raw_file':('Original official play-by-play response relative to project','path'),
      'shot_source_sha256':('SHA256 of original play-by-play response','SHA256'),
      'official_game_id':('Native NHL game identity','identifier'),
      'date':('Official game calendar date','YYYY-MM-DD'),
      'phase':('Official schedule competition phase; models use regular season, playoffs and preseason only','category'),
      'eligible_events':('Regulation attempts with exact1551 manpower code and both goalies present','events'),
      'matched_events':('Eligible events passing all native player, shooter and goalie checks','events'),
      'unresolved_events':('Eligible events needing source repair; not asserted externally unavailable','events'),
      'unresolved_pct':('100 times unresolved events divided by eligible events;0if no eligible events','percent'),
      'events_with_xg':('Matched events with a valid strictly earlier-year internal shot model','events'),
      'events_with_score_context':('Matched events with verified before-event score context','events'),
      'event_report_events':('Matched events verified by native official event report','events'),
      'shift_verified_events':('Matched events verified by exact shift membership','events'),
      'unresolved_json':('Every unresolved event identity and exact validation failure for repair','JSON array'),
      'source_json':('Official shift, event report and score-replay source URLs, raw paths and hashes','JSON object')}
    source='Official NHL gamecenter play-by-play, shiftcharts and NHL HTML event reports. Exact1551 five-on-five regulation filter and native participant verification in nhl_joint_chances.py. model_xg is internally derived using prior years, not official NHL xG.'
    published=[]
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        for table,frame in [(EVENTS,e),(COVERAGE,c)]:
            frame.to_sql(table,db,if_exists='replace',index=False,chunksize=5000)
            db.execute('CREATE UNIQUE INDEX IF NOT EXISTS '+table+'_key ON '+table+'(game_id'+(',event_id' if table==EVENTS else '')+')')
            for cat in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+cat+' WHERE "table"=?',(table,))
            db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(table,len(frame),len(frame.columns)))
            for col in frame:
                meaning,unit=meanings[col];db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(table,col,meaning,unit,source))
                n=int(frame[col].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(table,col,len(frame),n,100*n/len(frame)))
            path=ROOT_OUT/(table+'.parquet');frame.to_parquet(path,index=False)
            replay=pd.read_sql_query('SELECT * FROM '+table+' ORDER BY game_id'+(',event_id' if table==EVENTS else ''),db)
            ordered=frame.sort_values(['game_id','event_id'] if table==EVENTS else ['game_id']).reset_index(drop=True)
            pd.testing.assert_frame_equal(ordered,replay,check_dtype=False,check_exact=True)
            pd.testing.assert_frame_equal(frame,pd.read_parquet(path),check_exact=True)
            published.append(dict(table=table,rows=len(frame),columns=len(frame.columns),sha256=file_sha256(path)))
    c.groupby('phase')[['eligible_events','matched_events','unresolved_events','events_with_xg']].sum().to_csv(RESULT/'source_phase_coverage.csv')
    validation=dict(status='PASS',at_utc=stamp(),tables=published,eligible_events=int(c.eligible_events.sum()),matched_events=len(e),unresolved_events=int(c.unresolved_events.sum()),
        unresolved_pct=float(100*c.unresolved_events.sum()/c.eligible_events.sum()),xg_missing_pct=float(100*e.model_xg.isna().mean()),
        source_hashes=proof['source_hashes'],all_game_raw_score_replay=True,all_sql_parquet_equal=True,
        unresolved_policy='Every rejected event remains in coverage.unresolved_json; partial game event coverage is explicit, not imputed or declared impossible.')
    dump(RESULT/'source_validation.json',validation)
    from publish import main as catalog
    catalog();print(json.dumps(validation),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['collect','publish'],nargs='?',default='collect');parser.add_argument('--limit',type=int);args=parser.parse_args()
    collect(args.limit) if args.stage=='collect' else publish()
