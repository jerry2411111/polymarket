"""Official historical UEFA appearances when player PDFs are absent.

Match metadata, dated lineups and paginated events are retained independently.
No current profile club/age is used as a historical fact. Derived minutes exclude
stoppage and extra time; source event counts are labelled as recorded events.
"""
import argparse,collections,concurrent.futures,hashlib,json,sqlite3,urllib.parse
from pathlib import Path
import pandas as pd
from common import PROJECT,PREVIOUS,ROOT_OUT,OfficialClient,read_db,dump,stamp

PHASES=['FIRST_HALF','SECOND_HALF']


def reconcile_aliases(events):
    grouped={};aliases=[]
    for e in events:
        native=str(e['id']);key=native.replace('-','').lower()
        if len(key)!=32 or any(c not in '0123456789abcdef' for c in key):key=native
        if key not in grouped:grouped[key]=e;continue
        old=grouped[key]
        for field in ['type','phase','matchId']:assert old.get(field)==e.get(field),'Conflicting UUID event aliases'
        for field in ['minute','second','injuryMinute']:
            if field in old.get('time',{}) and field in e.get('time',{}):assert old['time'][field]==e['time'][field],'Conflicting UUID event clocks'
        for actor in ['primaryActor','secondaryActor']:
            a=old.get(actor,{}).get('person',{}).get('id');b=e.get(actor,{}).get('person',{}).get('id')
            if a and b:assert str(a)==str(b),'Conflicting UUID event participants'
        precision=lambda r:('second' in r.get('time',{}),bool(r.get('timestamp')),len(json.dumps(r)))
        chosen=max([old,e],key=precision);grouped[key]=chosen
        aliases.append(dict(canonical_uuid=key,raw_ids=[old['id'],e['id']],kept_id=chosen['id'],reason='Same UUID and compatible native event fields; retain complete clock copy'))
    return list(grouped.values()),aliases


def event_minute(e):
    # UEFA START_PHASE is minute 1 / 46 at elapsed 0 / 45 respectively.
    t=e['time'];minute=t['minute'];second=t['second']
    assert isinstance(minute,(int,float)) and isinstance(second,(int,float)) and 0<=second<60
    if t.get('injuryMinute',0)>0:return 45. if e['phase']=='FIRST_HALF' else 90.
    at=max(0.,minute-1+second/60)
    return min(45.,at) if e['phase']=='FIRST_HALF' else min(90.,max(45.,at))


def parse(g,match,lineup,events,sources,accept_full_time=False,ignore_zero_duration_unknown_cards=False):
    raw_event_count=len(events);events,aliases=reconcile_aliases(events)
    mid=str(g['official_game_id']);assert str(match['id'])==mid and str(lineup['matchId'])==mid
    assert match['status']=='FINISHED' and match['kickOffTime']['date']==g['date']
    native=list(map(str,json.loads(g['native_team_ids_json'])))
    score=match['score']['regular'];metadata_agrees=[score['away'],score['home']]==[g['scoreA'],g['scoreB']]
    assert len({str(e['id']) for e in events})==len(events) and all(str(e['matchId'])==mid for e in events)
    boundary={(e['type'],e.get('phase')) for e in events}
    # Clock-normalized exposure does not need every START_PHASE marker. The
    # complete paginated feed must cover both halves and the regulation end.
    terminal=('END_PHASE','SECOND_HALF') in boundary or (accept_full_time and ('FULL_TIME','SECOND_HALF') in boundary)
    phases_complete=all(any(e.get('phase')==phase for e in events) for phase in PHASES) and terminal
    byid={};coaches=set();players=[];issues=[];scorers=collections.Counter();own_goals=collections.Counter();goals=collections.Counter()
    if not metadata_agrees:issues.append(dict(field='metadata_regular_score',reason='Current metadata regular field disagrees with retained official regulation score; independently reconcile phase-specific scorer events.',raw=[score['away'],score['home']],retained=[g['scoreA'],g['scoreB']]))
    for side,label,tid in zip(['A','B'],['awayTeam','homeTeam'],native):
        assert str(match[label]['id'])==tid and str(lineup[label]['team']['id'])==tid
        section=lineup[label];assert len(section['field'])==11,'Dated lineup does not contain eleven starters: '+side
        for coach in section.get('coaches',[]):
            if coach.get('person',{}).get('id'):coaches.add(str(coach['person']['id']))
        for group in ['field','bench']:
            for slot in section[group]:
                p=slot['player'];pid=str(p['id']);assert pid not in byid
                r=dict(game_id=g['game_id'],official_game_id=mid,league=g['league'],date=g['date'],side=side,team_id=tid,
                    official_player_id=pid,player_name=p['internationalName'],started=group=='field',position='GOALKEEPER' if slot.get('type')=='GOALKEEPER' else None)
                byid[pid]=r;players.append(r)
    goals_complete=True
    try:
        for e in match.get('playerEvents',{}).get('scorers',[]):
            if e.get('phase') not in PHASES:continue
            pid=str(e['player']['id']);assert pid in byid,'Scorer native ID absent from dated lineup'
            side=byid[pid]['side'];assert str(e['teamId'])==byid[pid]['team_id'],'Scorer team contradicts dated lineup'
            own=e['goalType']=='OWN';credited=({'A':'B','B':'A'}[side] if own else side);goals[credited]+=1
            (own_goals if own else scorers)[pid]+=1
        assert [goals['A'],goals['B']]==[g['scoreA'],g['scoreB']],'Player goals fail official regulation score reconciliation'
    except (AssertionError,KeyError,TypeError,ValueError) as exc:
        goals_complete=False;issues.append(dict(field='goals',reason=type(exc).__name__+': '+str(exc)))
    relevant=[e for e in events if e.get('phase') in PHASES]
    transition_issues=collections.defaultdict(list)
    for e in relevant:
        if e['type'] not in ['SUBSTITUTION','RED_CARD','RED_YELLOW_CARD']:continue
        actor=e.get('primaryActor',{});p=actor.get('person',{});pid=str(p.get('id') or p.get('person',{}).get('id'))
        if actor.get('type')=='COACH' and pid not in byid:continue
        if pid not in byid:
            if (ignore_zero_duration_unknown_cards and e['type'] in ['RED_CARD','RED_YELLOW_CARD']
                    and e.get('phase')=='SECOND_HALF' and event_minute(e)==90):
                issues.append(dict(field='red_card_identity',event_id=e['id'],reason='Unknown dismissal actor at or after regulation minute 90; identity remains unresolved. No remaining regulation duration is affected.'))
                continue
            team=str(actor.get('team',{}).get('id'));affected=[['A','B'][native.index(team)]] if team in native else ['A','B']
            for side in affected:transition_issues[side].append('Transition actor absent from dated team roster: '+pid+'; event '+str(e['id']))
            continue
        if e['type']=='SUBSTITUTION':
            on=str(e['secondaryActor']['person']['id'])
            assert on in byid and byid[on]['side']==byid[pid]['side'],'Substitution crosses or lacks native dated team identity'
    for side in ['A','B']:
        side_players=[p for p in players if p['side']==side];roster={p['official_player_id'] for p in side_players}
        active={p['official_player_id']:0. for p in side_players if p['started']};played=set(active);minutes=collections.Counter();dismissals=[];proofs=[];transitions=[]
        complete=True
        try:
            assert phases_complete,'Incomplete official regulation phase boundaries'
            assert not transition_issues[side],'; '.join(transition_issues[side])
            for i,e in enumerate(relevant):
                if e['type'] not in ['SUBSTITUTION','RED_CARD','RED_YELLOW_CARD']:continue
                actor=e.get('primaryActor',{});p=actor.get('person',{});pid=str(p.get('id') or p.get('person',{}).get('id'))
                if actor.get('type')=='COACH' and pid not in byid:continue
                if pid not in roster:continue
                at=event_minute(e)
                if e['type']=='SUBSTITUTION':
                    on=str(e['secondaryActor']['person']['id']);assert on in roster,'Substitute native ID missing from same-side dated lineup'
                    transitions.append((at,i,'sub',pid,on,e))
                else:transitions.append((at,i,'red',pid,None,e))
            for at,_,kind,off,on,e in sorted(transitions):
                if kind=='red' and off not in active:continue
                assert off in active and (on is None or on not in played),'Substitution sequence contradicts active players'
                minutes[off]+=at-active.pop(off)
                if on is not None:active[on]=at;played.add(on)
                else:dismissals.append(at)
                proofs.append(dict(event_id=e['id'],type=e['type'],raw_clock=e['time'],raw_timestamp=e.get('timestamp'),regulation_minute=at,off=off,on=on))
            for pid,at in active.items():minutes[pid]+=90-at
            assert all(0<=v<=90 for v in minutes.values()) and abs(sum(minutes.values())-(990-sum(90-v for v in dismissals)))<1e-7
            assert all(pid in played for pid in set(scorers)|set(own_goals) if pid in roster)
        except (AssertionError,KeyError,TypeError,ValueError) as exc:
            complete=False;issues.append(dict(side=side,field='minutes',reason=type(exc).__name__+': '+str(exc)))
        for p in side_players:
            pid=p['official_player_id'];recorded=collections.Counter(e['type'] for e in relevant if str(e.get('primaryActor',{}).get('person',{}).get('id'))==pid)
            p.update(played=(pid in played) if complete else (True if p['started'] else None),minutes=float(minutes[pid]) if complete else None,
                goals=scorers[pid] if goals_complete else None,own_goals=own_goals[pid] if goals_complete else None,assists=None,minutes_complete=complete,goals_reconcile=goals_complete,
                minutes_basis='Regulation minutes excluding stoppage and extra time; UEFA one-based event minute normalized to elapsed minute, with explicit seconds.',
                recorded_event_counts=dict(recorded),transition_evidence=proofs,available_at_utc=g['available_time'],
                source=sources['match'],lineup_source=sources['lineup'],event_sources=sources['events'])
    return dict(game_id=g['game_id'],date=g['date'],players=players,sources=sources,event_count=len(events),raw_event_count=raw_event_count,event_aliases=aliases,issues=issues,goals_reconcile=goals_complete,metadata_regular_score_agrees=metadata_agrees,parser_version=2,
        source_notes='Only matched official native identities; no profile club or age. Absent assist events do not establish zero assists. Minute clock is regulation-only, not wall-clock elapsed time.')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--all',action='store_true');ap.add_argument('--retry',action='store_true');args=ap.parse_args()
    with read_db(PREVIOUS/'expanded.sqlite') as c:games=[dict(r) for r in c.execute("SELECT * FROM soccer_games WHERE league='UEFA Champions League' AND date>='2021-01-01' ORDER BY date,game_id")]
    coverage=pd.read_csv(ROOT_OUT/'soccer_player_game_coverage.csv')
    needed=set(coverage.loc[coverage.league.eq('UEFA Champions League')&(coverage.dated_rows.eq(0)|coverage.minutes_rows.lt(coverage.player_rows)),'game_id'])
    games=[g for g in games if g['game_id'] in needed]
    if args.pilot:
        chosen={}
        for g in games:chosen.setdefault(g['date'][:4],g)
        games=list(chosen.values())
    elif not args.all:raise ValueError('Choose --pilot or --all')
    with read_db(PREVIOUS/'collection.sqlite') as c:lineups={r['url']:dict(r) for r in c.execute("SELECT * FROM requests WHERE status=200 AND url LIKE '%uefa%/lineups'")}
    db=sqlite3.connect(ROOT_OUT/'uefa_exposure.sqlite',timeout=60)
    db.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT); CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,reason TEXT,sources TEXT);')
    done=set() if args.retry else {r[0] for r in db.execute('SELECT game_id FROM games')};games=[g for g in games if g['game_id'] not in done]
    client=OfficialClient(per_second=2)
    def get(g):
        sources={}
        try:
            root='https://match.uefa.com/v5/matches/'+str(g['official_game_id']);old=lineups.get(root+'/lineups')
            if old:
                blob=Path(old['raw_file']).read_bytes();assert hashlib.sha256(blob).hexdigest()==old['sha256'];lineup=json.loads(blob)
                sources['lineup']=dict(url=old['url'],raw_file=old['raw_file'],sha256=old['sha256'],retrieved_at_utc=old['retrieved_at'],reused=True)
            else:lineup,sources['lineup']=client.get(root+'/lineups','Historical UEFA dated lineup '+g['date'],'official_match_lineup')
            match,sources['match']=client.get(root,'Historical UEFA official score and player goal identities '+g['date'],'official_match_metadata')
            assert match is not None and lineup is not None,'Official metadata/lineup request requires recovery'
            events=[];sources['events']=[]
            for offset in range(0,10000,500):
                url=root+'/events?'+urllib.parse.urlencode(dict(filter='ALL',limit=500,offset=offset,order='ASC'))
                page,source=client.get(url,'Historical UEFA substitutions and recorded player actions '+g['date'],'official_match_events');sources['events'].append(source)
                assert isinstance(page,list),'Official event page requires recovery'
                events.extend(page)
                if len(page)<500:break
            else:raise AssertionError('Unexhausted official event pagination')
            return g,parse(g,match,lineup,events,sources),None,sources
        except Exception as exc:return g,None,type(exc).__name__+': '+str(exc),sources
    mark=10;counts=collections.Counter();print(json.dumps(dict(stage='uefa_exposure_start',tasks=len(games),retained=len(done),pilot=args.pilot)),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for n,(g,result,error,sources) in enumerate(pool.map(get,games),1):
            with db:
                if result:
                    db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(g['game_id'],json.dumps(result)));db.execute('DELETE FROM issues WHERE game_id=?',(g['game_id'],))
                    counts['games']+=1;counts['players']+=len(result['players']);counts['known_minutes']+=sum(r['minutes'] is not None for r in result['players']);counts['event_issues']+=len(result['issues'])
                else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?,?)',(g['game_id'],error,json.dumps(sources)));counts['request_or_schema_issues']+=1
            if n*100>=mark*len(games) or n==len(games):
                report=dict(at_utc=stamp(),stage='uefa_exposure',processed=n,total=len(games),percent=round(100*n/len(games),1),counts=dict(counts),latest_date=g['date'])
                dump(ROOT_OUT/'uefa_exposure_progress.json',report);print(json.dumps(report),flush=True);mark+=10
    db.close()


if __name__=='__main__':main()
