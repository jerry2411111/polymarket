"""Winner-only hourly observation entry, using a fixed pre12 forecast."""
import argparse
import concurrent.futures
import hashlib
import json
import sqlite3
import urllib.parse
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT,PROJECT,REPORTS,dump,stamp,file_sha256
from refresh_hourly_prices import Client
from backtest import quote_inputs
from nhl_winner_classifier import inputs
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine

LABEL='nhl_winner_patient_entry'
RESULT=ROOT_OUT/'simulation_results'/LABEL
DOCS=['https://docs.polymarket.com/api-reference/markets/get-prices-history','https://docs.polymarket.com/api-reference/rate-limits']


def population(stage):
    p=inputs(stage);p=p[p.variant.eq('logistic')]
    transfer.RESULT=RESULT
    q=quote_inputs(RESULT/(stage+'_quote_quality.json'),revision='closest_v62')
    f=transfer.normalize('nhl',p,q,pick_growth=False)
    f=f[f.provider.eq('polymarket')&f.probability.gt(.60)].sort_values(['entry','game_id'])
    assert f.side.eq(f[['p0','p1']].to_numpy().argmax(axis=1)).all()
    return f


def collect(stage):
    RESULT.mkdir(exist_ok=True)
    if stage=='evaluation':assert json.loads((RESULT/'selection.json').read_bytes())['passed']
    if not (RESULT/'plan.json').exists():
        dump(RESULT/'plan.json',dict(at_utc=stamp(),
            hypothesis='A model winner can be overpriced at pre12 but become affordable later. Keep its pre12 probability and selected side fixed; wait for a five-point price allowance, without selecting the best price retrospectively.',
            model='Existing NHL logistic, selected on2024/25 winner accuracy before this test. Existing probability>60% condition and5 dollars per point above51 stake.',
            entry='At pre12 buy immediately if its known closest-prior price<=p-0.05. Otherwise buy at the FIRST returned hourly observation with price<=p-0.05 strictly before puck drop. Pay that observed price, not an assumed better limit fill. Never switch side or refresh the forecast with post-decision information.',
            source='Official international Polymarket CLOB historical token observations, fidelity60minutes. Not verified executable ask quotes or US prices.',
            coverage='For the paired comparison require a successful raw response and no gap longer than two requested hourly intervals, including window endpoints. Report excluded windows; a sparse/empty response is unresolved acquisition coverage, not proof that no cheaper price existed. No interpolation.',
            gate='2025 higher Sharpe and positive return versus immediate pre12 purchases on the identical covered cohort. Record before collecting/evaluating2026.2024 is separate sparse-history sensitivity.',
            evaluation='2026 repeatedly inspected retrospective research. Current trial is selected on earlier dates; no fresh-holdout claim.',
            docs=DOCS,rate_per_second=4,workers=3,requests='One bounded12hour request per eligible model winner, no full-history download.',app_changed=False))
    f=population(stage);client=Client(per_second=4)
    def acquire(r):
        params=dict(market=r['entry_contract_id'],startTs=int(r['entry'].timestamp()),endTs=int(r['start'].timestamp())-1,fidelity=60)
        url='https://clob.polymarket.com/prices-history?'+urllib.parse.urlencode(params)
        body,src=client.get(url,'NHL fixed-winner price from pre12 until puck drop: '+r['game_id'],kind='GET pre-match hourly prices')
        return dict(game_id=r['game_id'],provider='polymarket',token_id=r['entry_contract_id'],side=int(r['side']),
            prediction_time=r['entry'].isoformat(),start_time=r['start'].isoformat(),source=src,
            status='ok' if isinstance(body,dict) and isinstance(body.get('history'),list) else 'request_or_schema_failure',
            raw_rows=len(body['history']) if isinstance(body,dict) and isinstance(body.get('history'),list) else None)
    rows=[];milestone=10
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for row in pool.map(acquire,f.to_dict('records')):
            rows.append(row);pct=100*len(rows)/len(f)
            if pct>=milestone or len(rows)==len(f):
                dump(RESULT/(stage+'_requests.json'),rows)
                print(json.dumps(dict(stage=stage,percent=milestone,completed=len(rows),total=len(f),failures=sum(r['status']!='ok' for r in rows))),flush=True)
                milestone+=10
    assert all(r['status']=='ok' for r in rows),'Retry failed acquisition before evaluation; do not silently skip rejected requests'
    dump(RESULT/(stage+'_acquisition.json'),dict(status='PASS',at_utc=stamp(),requested_games=len(rows),response_rows=sum(r['raw_rows'] for r in rows),
        empty_responses=sum(r['raw_rows']==0 for r in rows),source_api='CLOB prices-history',fidelity_minutes=60,stage=stage))


def paths(stage,f):
    records=json.loads((RESULT/(stage+'_requests.json')).read_bytes())
    assert {r['game_id'] for r in records}==set(f.game_id)
    observations=[];coverage=[];found={}
    for r in records:
        src=r['source'];assert r['status']=='ok' and src['return_status']=='200'
        raw=(PROJECT/src['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==src['sha256']
        body=json.loads(raw);a=pd.Timestamp(r['prediction_time']);b=pd.Timestamp(r['start_time'])
        points=[];seen={}
        for i,x in enumerate(body['history']):
            assert isinstance(x['t'],(int,float)) and isinstance(x['p'],(int,float)) and np.isfinite(x['p']) and 0<=x['p']<=1
            if x['t'] in seen:assert x['p']==seen[x['t']]
            seen[x['t']]=x['p'];t=pd.Timestamp(x['t'],unit='s',tz='UTC')
            if not a<=t<b:continue
            point=dict(game_id=r['game_id'],provider='polymarket',token_id=r['token_id'],side=r['side'],
                prediction_time=a,start_time=b,timestamp_utc=t,price=float(x['p']),fidelity_minutes=60,
                source_pointer='/history/'+str(i)+'/p',source_json=json.dumps(src,sort_keys=True))
            observations.append(point);points.append(point)
        points=sorted({p['timestamp_utc']:p for p in points}.values(),key=lambda p:p['timestamp_utc'])
        gaps=np.diff(np.array([a.timestamp()]+[p['timestamp_utc'].timestamp() for p in points]+[b.timestamp()]))/3600
        maxgap=float(max(gaps));complete=bool(len(points) and maxgap<=2)
        coverage.append(dict(game_id=r['game_id'],provider='polymarket',prediction_time=a,start_time=b,
            observation_count=len(points),max_gap_hours=maxgap,covered=complete,
            coverage_status='covered_hourly_window' if complete else 'empty_response' if not points else 'sparse_hourly_window',source_json=json.dumps(src,sort_keys=True)))
        found[r['game_id']]=points
    pd.DataFrame(observations).to_parquet(RESULT/(stage+'_observations.parquet'),index=False)
    pd.DataFrame(coverage).to_parquet(RESULT/(stage+'_coverage.parquet'),index=False)
    return found,pd.DataFrame(coverage)


def evaluate(stage):
    assert not (RESULT/(stage+'_validation.json')).exists()
    assert json.loads((RESULT/(stage+'_acquisition.json')).read_bytes())['status']=='PASS'
    f=population(stage);found,coverage=paths(stage,f)
    eligible=set(coverage[coverage.covered].game_id);control=f[f.game_id.isin(eligible)].copy()
    candidate=[];decisions=[]
    for r in control.to_dict('records'):
        limit=r['probability']-.05;before=dict(r);chosen=None;reason='no_qualifying_observed_price'
        if r['price']<=limit:chosen=r;reason='already_affordable_at_pre12'
        else:
            for point in found[r['game_id']]:
                if not 0<point['price']<1 or point['price']>limit:continue
                src=json.loads(point['source_json']);at=point['timestamp_utc']
                chosen=r|dict(entry=at,price=point['price'],source_utc=at,available_utc=at,quote_age_hours=0.,
                    entry_pointer=point['source_pointer'],entry_request_id='nhl_soccer_iteration:'+str(src['request_number']),
                    price_basis='polymarket_clob_hourly_historical_price')
                reason='first_affordable_hourly_observation';break
        decisions.append(dict(game_id=r['game_id'],initial_price=before['price'],model_probability=r['probability'],price_limit=limit,
            reason=reason,entry_time=str(chosen['entry']) if chosen else None,entry_price=chosen['price'] if chosen else None,
            delay_hours=(chosen['entry']-before['entry']).total_seconds()/3600 if chosen else None))
        if chosen:
            assert before['entry']<=chosen['entry']<before['start'] and chosen['price']<=limit
            chosen['forecast_time']=before['entry'];chosen['edge']=chosen['probability']-chosen['price'];candidate.append(chosen)
    new=pd.DataFrame(candidate)
    if not len(new):new=control.iloc[:0].copy()
    annual=[];bets=[];daily=[];checks=[]
    for variant,h in [('full_pre12_reference',f),('covered_pre12_control',control),('wait_for_price',new)]:
        for year in sorted(f.year.unique()):
            m,b,l,d=engine.simulate(h,int(year),'all_selected_outcomes','dollars_cash_only',5.,2000.)
            key=dict(sport='nhl',provider='polymarket',variant=variant,stage=stage,year=int(year))
            annual.append(key|m);checks.append(key|engine.validate(b,l,d,'dollars_cash_only',5.,2000.))
            if len(b):
                assert b.side.eq(b[['p0','p1']].to_numpy().argmax(axis=1)).all()
                assert b.source_utc.le(b.entry).all() and b.available_utc.le(b.entry).all()
                if variant=='wait_for_price':assert b.forecast_time.le(b.entry).all() and b.price.le(b.probability-.05).all()
                bets.append(b.assign(**key))
            daily.append(d.assign(**key))
    a=pd.DataFrame(annual);a.to_csv(RESULT/(stage+'_annual.csv'),index=False)
    pd.concat(bets).to_parquet(RESULT/(stage+'_bets.parquet'),index=False);pd.concat(daily).to_parquet(RESULT/(stage+'_daily.parquet'),index=False)
    decision_frame=pd.DataFrame(decisions)
    decision_frame.to_csv(RESULT/(stage+'_entry_decisions.csv'),index=False)
    attributed=pd.concat(bets).merge(decision_frame[['game_id','reason']],on='game_id',validate='many_to_one')
    attributed.groupby(['year','variant','reason']).agg(bets=('game_id','size'),win_rate=('won','mean'),
        model_probability=('probability','mean'),price=('price','mean'),profit=('profit','sum'),
        average_unit_return=('unit_return','mean')).reset_index().to_csv(RESULT/(stage+'_entry_attribution.csv'),index=False)
    if stage=='development':
        ix=a.set_index(['variant','year']);old=ix.loc[('covered_pre12_control',2025)];newscore=ix.loc[('wait_for_price',2025)]
        passed=bool(newscore.sharpe>old.sharpe and newscore.return_pct>0)
        dump(RESULT/'selection.json',dict(at_utc=stamp(),passed=passed,used2026=False,adopted=False))
    # The full-cohort control must reproduce the prior classifier study.
    old=pd.read_csv(ROOT_OUT/'simulation_results/nhl_winner_classifier/annual.csv')
    old=old[old.provider.eq('polymarket')&old.variant.eq('logistic')&old.stake_rule.eq('confidence5_floor60')].set_index('year')
    current=a[a.variant.eq('full_pre12_reference')].set_index('year')
    for c in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
        assert np.allclose(current[c],old.loc[current.index,c],rtol=0,atol=1e-9,equal_nan=True)
    proof=dict(status='PASS',at_utc=stamp(),requested_games=len(f),paired_covered_games=len(control),unresolved_window_coverage=len(f)-len(control),
        checks=checks,all_bets_are_model_winner=True,first_qualifying_point_used=True,raw_values_and_hashes_replayed=True,
        original_full_cohort_reproduced=True,app_changed=False,adopted=False)
    dump(RESULT/(stage+'_validation.json'),proof)
    print(a[['variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print(json.dumps({k:proof[k] for k in ['requested_games','paired_covered_games','unresolved_window_coverage']}),flush=True)


def finish():
    assert (RESULT/'development_validation.json').exists()
    selected=json.loads((RESULT/'selection.json').read_bytes())['passed']
    if selected:assert (RESULT/'evaluation_validation.json').exists()
    stages=['development']+(['evaluation'] if selected else [])
    source_fields={
        'game_id':('Canonical NHL game linked to the source forecast','identifier'),
        'provider':('Prediction-market provider','text'),
        'token_id':('Native CLOB token for the fixed model winner','identifier'),
        'side':('Model outcome index:0TeamA,1TeamB','class index'),
        'prediction_time':('Pre12 forecast and start of monitoring; model probabilities stay fixed','UTC timestamp'),
        'start_time':('Official puck-drop boundary; later price observations excluded','UTC timestamp'),
        'timestamp_utc':('Historical CLOB observation timestamp','UTC timestamp'),
        'price':('Original token price, distinct from verified executable ask orUSprice','USD per1USD-payoutshare'),
        'fidelity_minutes':('Requested historical sample fidelity','minutes'),
        'source_pointer':('JSON pointer to the exact original response value','JSON pointer'),
        'source_json':('Original URL, request number, retrieval time, raw path and SHA256','JSON'),
        'observation_count':('Returned observations within the requested pre12-to-start window','count'),
        'max_gap_hours':('Largest interval between observations including request boundaries','hours'),
        'covered':('True if response has observations and no gap exceeds two requested hourly intervals','boolean'),
        'coverage_status':('Covered, sparse or empty response; unresolved coverage is not external-unavailability assertion','text')}
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        for suffix in ['observations','coverage']:
            table='nhl_winner_price_'+suffix
            frame=pd.concat([pd.read_parquet(RESULT/(stage+'_'+suffix+'.parquet')) for stage in stages],ignore_index=True)
            for c in frame:
                if isinstance(frame[c].dtype,pd.DatetimeTZDtype):frame[c]=frame[c].map(lambda v:v.isoformat())
                if frame[c].dtype=='bool':frame[c]=frame[c].astype(int)
            assert set(frame).issubset(source_fields)
            frame.to_sql(table,db,if_exists='replace',index=False)
            pd.testing.assert_frame_equal(frame,pd.read_sql_query('SELECT * FROM '+table,db),check_dtype=False)
            frame.to_parquet(ROOT_OUT/(table+'.parquet'),index=False);frame.to_csv(ROOT_OUT/(table+'.csv'),index=False)
            for meta in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+meta+' WHERE "table"=?',(table,))
            db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(table,len(frame),len(frame.columns)))
            for c in frame:
                db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(table,c,*source_fields[c],'Official Polymarket CLOB prices-history; previous validated official NHL identity and forecast clock. Fixed winner opportunities only, not all NHL games.'))
                db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(table,c,len(frame),int(frame[c].isna().sum()),100*frame[c].isna().mean()))
    def table(f):
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(f'{v:.5f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in f.itertuples(index=False,name=None)])
    a=pd.concat([pd.read_csv(RESULT/(s+'_annual.csv')) for s in stages]);coverage=pd.concat([pd.read_parquet(RESULT/(s+'_coverage.parquet')) for s in stages])
    summary=coverage.groupby(coverage.prediction_time.dt.year).agg(requested=('game_id','size'),covered=('covered','sum')).reset_index()
    summary['unresolved_window_pct']=100*(1-summary.covered/summary.requested)
    plan=json.loads((RESULT/'plan.json').read_bytes())
    lines=['# NHL fixed-winner observed-price entry','',plan['hypothesis'],'',plan['entry'],'',plan['model'],'',plan['coverage'],'',table(summary),'',
        table(a[['variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',plan['gate'],'','Selection: '+(RESULT/'selection.json').read_text(),'',
        'Hourly sampling can miss shorter price movements. This tests purchases at the first qualifying recorded observation, not guaranteed limit-order fills. Forecasts and sides stay fixed before the monitoring window; neither the final winner nor the lowest later price selects entry. Empty/sparse windows remain in the coverage table and original responses; no missing point is replaced or interpolated.','',
        'The saved entry-attribution table distinguishes already-affordable, later-affordable and excluded games. In2025, waiting improved profit on the20later-affordable games from29.89to80.66USD. However, it excluded377other winners with a68.97%win rate and1267.88USDnetprofit. The reduction in overall Sharpe comes mainly from the opportunity filter; this comparison does not establish that waiting itself caused worse outcomes.','',
        'Accounts begin annually with$2000; fixed confidence-dollar stakes, cash-only funding and official settlement availability are independently replayed. Calendar-day Sharpe includes idle days andsqrt365.25; open positions carried atcost. No costs assumed. '+plan['source'],'',plan['evaluation'],'',
        'Current official documentation read before acquisition: '+', '.join(DOCS)+'. One bounded12-hour request per token with market,startTs,endTs,fidelity60. Endpoint supplies a history array without a documented pagination cursor. Request log exposes request number,type,intent,status; raw-first metadata preserves reproducibility.','',
        'Reproduce collect development, evaluate development; only if selected collect evaluation and evaluate evaluation; then finish. See nhl_winner_patient_entry.py.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';prior=pd.read_csv(path,low_memory=False);key=LABEL+'/annual.csv'
    pd.concat([prior[prior.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL]=dict(plan=plan,selection=json.loads((RESULT/'selection.json').read_bytes()),validation={s:json.loads((RESULT/(s+'_validation.json')).read_bytes()) for s in stages});dump(path,d)
    from publish import main
    from final_pipeline import cleanup,validate
    main();cleanup();validate()
    path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    # SQL/CSV/Parquet are now canonical; remove only duplicate normalized copies.
    for stage in stages:
        for suffix in ['observations','coverage']:
            file=(RESULT/(stage+'_'+suffix+'.parquet')).resolve()
            assert file.parent==RESULT.resolve() and file.is_file();file.unlink()


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['collect','evaluate','finish']);p.add_argument('stage',nargs='?',choices=['development','evaluation'])
    a=p.parse_args()
    if a.action=='finish':finish()
    else:
        assert a.stage;globals()[a.action](a.stage)
