"""Official UEFA club fixtures omitted from the six-competition workload history.

Calendar only: no new betting outcomes or current lineups enter the model.
The official historical pages declare UEL=14 and UECL=2019 (not Nations2014).
"""
import collections,datetime as dt,hashlib,json,sqlite3
from urllib.parse import urlencode
import pandas as pd
from common import OfficialClient,ROOT_OUT,PROJECT,dump,stamp

RUN=ROOT_OUT/'soccer_cup_workload_v73'
BASE='https://match.uefa.com/v5/matches'
COMPETITIONS={'14':('UEL','UEFA Europa League',2021),'2019':('UECL','UEFA Conference League',2022)}
START='2021-01-01';END='2026-09-30'


def normalize(m,source,index):
    cid=str(m['competition']['id']);code,name,first=COMPETITIONS[cid]
    assert m['competition']['code']==code
    assert all(m[s]['typeTeam']=='DOMESTIC' and not m[s].get('isPlaceHolder') for s in ['awayTeam','homeTeam'])
    clock=m['kickOffTime'].get('dateTime');start=pd.Timestamp(clock) if clock else None
    assert start is None or start.tzinfo
    assert START<=m['kickOffTime']['date']<=END
    teams=[m['awayTeam'],m['homeTeam']];assert teams[0]['id']!=teams[1]['id']
    reason=m.get('winner',{}).get('match',{}).get('reason')
    available=m.get('fullTimeAt')
    if available and start is not None:assert pd.Timestamp(available)>start
    # A FINISHED walkover is not physical workload. Unknown completion remains
    # explicitly uncertain; it is never silently turned into a played game.
    played=start is not None and m['status']=='FINISHED' and (bool(available) or reason in ['WIN_REGULAR','WIN_EXTRA_TIME','WIN_PENALTY','DRAW']) and not any(v in str(reason).upper() for v in ['AWARD','FORFEIT','WALK'])
    fallback=((start.tz_convert('UTC').date() if start is not None else dt.date.fromisoformat(m['kickOffTime']['date']))+dt.timedelta(days=1)).isoformat()+'T00:00:00Z'
    return dict(game_id='HIST_'+code+'_'+str(m['id']),official_game_id=str(m['id']),league=name,competition_id=cid,season_year=int(m['seasonYear']),
        date=m['kickOffTime']['date'],start_time=start.tz_convert('UTC').isoformat() if start is not None else None,available_time=available or fallback,
        availability_basis='official_full_time' if available else 'conservative_next_utc_day',status=m['status'],result_reason=reason,
        workload_eligible=played,phase=m['competitionPhase'],teamA=teams[0]['translations']['displayOfficialName']['EN'],teamB=teams[1]['translations']['displayOfficialName']['EN'],
        native_team_ids_json=json.dumps([str(t['id']) for t in teams]),teamA_key='EU_UEFA_CLUB:'+str(teams[0]['id']),teamB_key='EU_UEFA_CLUB:'+str(teams[1]['id']),
        raw_score_json=json.dumps(m.get('score',{}),sort_keys=True),source_json=json.dumps(source,sort_keys=True),source_pointer='/'+str(index))


def main():
    RUN.mkdir(exist_ok=True);client=OfficialClient(per_second=2)
    doc=json.loads((RUN/'documentation.json').read_bytes())
    assert len(doc['pages'])==2
    for page,cid in zip(doc['pages'],COMPETITIONS):
        assert any("competitionId = '"+cid+"'" in x for x in page['configuration'])
    windows=[(cid,y) for cid,(_,_,first) in COMPETITIONS.items() for y in range(first,2028)]
    db=sqlite3.connect(RUN/'calendar.sqlite',timeout=60)
    db.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT NOT NULL); CREATE TABLE IF NOT EXISTS pages(url TEXT PRIMARY KEY,body TEXT NOT NULL);')
    milestone=10
    for n,(cid,year) in enumerate(windows,1):
        seen=set()
        for offset in range(0,10000,50):
            params=dict(competitionId=cid,seasonYear=year,fromDate=START,toDate=END,order='ASC',limit=50,offset=offset)
            url=BASE+'?'+urlencode(params)
            data,source=client.get(url,'Completed and cancelled '+COMPETITIONS[cid][0]+' club workload calendar season '+str(year),'uefa_workload_calendar')
            assert isinstance(data,list),'Calendar response needs recovery: '+str(source)
            ids=[str(m['id']) for m in data];assert len(ids)==len(set(ids)) and not seen.intersection(ids)
            seen.update(ids)
            with db:
                db.execute('INSERT OR REPLACE INTO pages VALUES (?,?)',(url,json.dumps(dict(params=params,source=source,count=len(data)))))
                for i,m in enumerate(data):
                    assert str(m['competition']['id'])==cid and int(m['seasonYear'])==year
                    row=normalize(m,source,i);db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(row['game_id'],json.dumps(row)))
            if len(data)<50:break
        else:raise AssertionError('Unexhausted official pagination')
        while n*100>=milestone*len(windows):
            p=dict(at_utc=stamp(),stage='uefa_cup_calendar',percent=milestone,completed_windows=n,total_windows=len(windows),latest_competition=COMPETITIONS[cid][0],latest_season=year)
            dump(RUN/'progress.json',p);print(json.dumps(p),flush=True);milestone+=10
    rows=[json.loads(b) for b, in db.execute('SELECT body FROM games')];pages=[json.loads(b) for b, in db.execute('SELECT body FROM pages')];db.close()
    f=pd.DataFrame(rows).sort_values(['start_time','game_id']);assert not f.official_game_id.duplicated().any()
    f.to_parquet(RUN/'games.parquet',index=False);f.to_csv(RUN/'games.csv',index=False)
    # Replay every value, not merely HTTP status or a sample of successful calls.
    sources={};checked=0
    for r in f.to_dict('records'):
        s=json.loads(r['source_json']);path=s['raw_file']
        if path not in sources:
            blob=(PROJECT/path).read_bytes();assert hashlib.sha256(blob).hexdigest()==s['sha256'];sources[path]=json.loads(blob)
        index=int(r['source_pointer'][1:]);clean={k:(None if pd.isna(v) else v) for k,v in r.items()}
        assert normalize(sources[path][index],s,index)==clean;checked+=1
    counts=f.groupby(['league','season_year','status','workload_eligible'],dropna=False).size().rename('games').reset_index()
    counts.to_csv(RUN/'calendar_coverage.csv',index=False)
    summary=dict(status='PASS_RAW_CALENDAR',at_utc=stamp(),games=len(f),verified_rows=checked,raw_pages=len(sources),
        official_windows=len(windows),workload_eligible=int(f.workload_eligible.sum()),nonplayed_or_unresolved=int((~f.workload_eligible).sum()),
        first_date=f.date.min(),last_date=f.date.max(),source='Official UEFA fixture API; exact native club IDs shared across UEFA competitions; no name-based joins',
        scope='Additional club workload context only. Scores and lineup statistics are not new model inputs. Pending identity/calendar coverage must not be interpreted as healthy/rested.')
    dump(RUN/'calendar_validation.json',summary);print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
