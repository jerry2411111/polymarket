"""Recover lineup continuity from complete, internally identified Maker history.

An Opta bridge is not required to count repeated starts within one stable native
person namespace. Unbridged people never become guessed cross-source aliases.
"""
import argparse
import collections
import copy
import json
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT,PREVIOUS,PROJECT,REPORTS,read_db,dump,stamp,file_sha256

LABEL='soccer_source_continuity'
RESULT=ROOT_OUT/'simulation_results'/LABEL
TABLE='soccer_recent_starting_lineups'
WORK=ROOT_OUT/'_work'/LABEL


def native_lineups():
    from laliga_maker_api import opta_id
    from validate_laliga_maker import pointer
    with read_db(ROOT_OUT/'laliga_maker.sqlite') as db:
        records=[json.loads(r[0]) for r in db.execute('SELECT body FROM fixtures ORDER BY game_id')]
    index={r['game_id']:r for r in json.loads((ROOT_OUT/'laliga_maker_index.json').read_bytes())['matched']}
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games={r['game_id']:dict(r) for r in db.execute("SELECT * FROM soccer_games WHERE league='La Liga'")}
    identities={};sources={};starter_sets={};rows=0
    for record in records:
        src=record['source'];path=PROJECT/src['raw_file']
        assert file_sha256(path)==src['sha256'];body=json.loads(path.read_bytes());sources[src['sha256']]=src
        game=games[record['game_id']];match=index[record['game_id']];raw=body['game']
        assert str(game['official_game_id'])==str(match['official_game_id'])==str(record['match']['official_game_id'])
        assert raw['id']==match['maker_game_id'] and pd.Timestamp(raw['time'])==pd.Timestamp(match['start_time'])
        assert [raw['awayScore'],raw['homeScore']]==[game['scoreA'],game['scoreB']]
        for side,native in [('A','awayTeam'),('B','homeTeam')]:
            assert raw[native]['id']==match['fixture'][native]['id']
            assert str(match['team'+side+'_id'])==str(json.loads(game['native_team_ids_json'])[0 if side=='A' else 1])
        for p in record['players']:
            node=pointer(body,p['lineup_pointer']);person=node['player']
            assert person['id']==p['maker_player_id'] and not node.get('manager')
            assert bool(node['starting'])==p['started'] and person['name']==p['player_name']
            native=opta_id(person);assert native==p.get('opta_player_id');rows+=1
            if native:
                uid=p['maker_player_id']
                if uid in identities:assert identities[uid]['opta_player_id']==native
                else:identities[uid]=dict(maker_player_id=uid,opta_player_id=native,
                    source=src,pointer=p['lineup_pointer']+'/player',basis='Literal Opta asset ID attached to the same Maker native player UUID; immutable identity only')
        for side in ['A','B']:
            members=[p for p in record['players'] if p['side']==side and p.get('started') is True]
            if len(members)!=11 or len({p['maker_player_id'] for p in members})!=11:continue
            at=max([pd.Timestamp(game['available_time'])]+[pd.Timestamp(p['available_at_utc']) for p in members])
            assert at>=pd.Timestamp(raw['time'])
            starter_sets[record['game_id'],side]=dict(game_id=record['game_id'],official_game_id=str(game['official_game_id']),
                side=side,available_time=at.isoformat(),source=src,players=members)
    # Static aliases are verified from raw IDs/assets, not from equal names.
    output={}
    for key,item in starter_sets.items():
        players=[];natives=[];proof=[]
        for p in item['players']:
            uid=p['maker_player_id'];alias=identities.get(uid)
            token='opta:'+alias['opta_player_id'] if alias else 'maker:'+uid
            players.append(token);natives.append(uid)
            if alias:proof.append(alias)
        assert len(set(players))==11
        output[key]=dict(game_id=item['game_id'],official_game_id=item['official_game_id'],side=item['side'],
            available_time=item['available_time'],complete=True,count=11,players=sorted(players),natives=sorted(natives),
            identity_namespace='opta:pID when linked by literal raw asset; otherwise maker:UUID. These keys are not asserted equal to the other canonical person namespace.',
            recovery_source_class='official_club_Elche_LaLigaMaker',recovery_sources=[item['source']],
            identity_evidence=proof)
    return output,dict(raw_responses_verified=len(sources),player_rows_replayed=rows,complete_native_starter_sides=len(output),
        literal_static_id_links=len(identities),raw_source_hashes=sorted(sources))


def recover(before,lineups):
    result=before.copy();audit=[];overlap=0
    for i,row in before.iterrows():
        old=json.loads(row.source_lineups_json)
        if row.league!='La Liga' or len(old)!=10:continue
        keys=[(r['game_id'],r['side']) for r in old]
        if not all(key in lineups for key in keys):continue
        new=[lineups[key] for key in keys]
        cutoff=pd.Timestamp(row.prediction_time)
        if any(pd.Timestamp(r['available_time'])>=cutoff for r in new):continue
        assert all(str(a['official_game_id'])==str(b['official_game_id']) for a,b in zip(old,new))
        now=collections.Counter(pid for r in new[-5:] for pid in r['players'])
        past=collections.Counter(pid for r in new[:5] for pid in r['players'])
        assert sum(now.values())==sum(past.values())==55
        value=.5*sum(abs(now[pid]-past[pid]) for pid in now.keys()|past.keys())/55
        if row.evidence_status=='ready':
            assert np.isclose(value,row.starter_usage_turnover,rtol=0,atol=1e-12),(row.game_id,row.side)
            overlap+=1;continue
        assert row.evidence_status=='incomplete_prior_starting_eleven'
        # Existing explicit starter identity sets are not overwritten piecemeal:
        # the entire ten-game window uses one consistent native identity system.
        result.loc[i,'complete_lineup_games']=10
        result.loc[i,'starter_usage_turnover']=value
        result.loc[i,'evidence_status']='ready'
        result.loc[i,'recent_starter_counts_json']=json.dumps(now,sort_keys=True)
        result.loc[i,'preceding_starter_counts_json']=json.dumps(past,sort_keys=True)
        result.loc[i,'latest_source_utc']=max(pd.Timestamp(r['available_time']) for r in new).isoformat()
        result.loc[i,'source_lineups_json']=json.dumps(new,sort_keys=True)
        result.loc[i,'source_reference']='Complete ten-game official Elche/LaLigaMaker lineage. Counts use explicit opta:pID or maker:UUID keys. No unverified canonical player join. See soccer_source_continuity validation for raw replay and same-window comparisons.'
        audit.append(dict(game_id=row.game_id,side=row.side,date=row.date,prediction_time=row.prediction_time,
            previous_status=row.evidence_status,previous_complete_games=int(row.complete_lineup_games),
            complete_lineup_games=10,starter_usage_turnover=value,
            native_unbridged_people=len({pid for r in new for pid in r['players'] if pid.startswith('maker:')}),
            latest_source_utc=result.loc[i,'latest_source_utc']))
    return result,pd.DataFrame(audit),overlap


def build():
    RESULT.mkdir(exist_ok=True);assert not (RESULT/'validation.json').exists()
    path=ROOT_OUT/(TABLE+'.parquet');before=pd.read_parquet(path);oldhash=file_sha256(path)
    dump(RESULT/'plan.json',dict(at_utc=stamp(),
        problem='Complete11-player Maker lineups were rejected solely because an optional Opta bridge was absent. Within-source turnover only requires consistent native person IDs.',
        rule='Replace only incomplete ten-game LaLiga windows when all ten have exactly11explicit unique Maker starters. No mixture with incomplete other-source sets. Use literal asset-linked Opta IDs when verified, otherwise retain namespaced Maker UUIDs.',
        validation='Replay native games/teams/scores, starting flags,UUIDs,assetIDs and raw hashes. Every already-ready overlapping turnover value must match. Strict source availability before forecast. No added present-day lineup facts.',
        model='Data recovery first. Rebuild the same identity-corrected44-input turnover model with increased coverage; compare earlier2024/25forecasts before2026.',app_changed=False))
    lineups,source=native_lineups();after,audit,overlap=recover(before,lineups)
    assert len(audit)>0
    changed=set(map(tuple,audit[['game_id','side']].to_numpy()))
    unchanged=np.array([(gid,side) not in changed for gid,side in before[['game_id','side']].itertuples(index=False,name=None)])
    pd.testing.assert_frame_equal(before.loc[unchanged],after.loc[unchanged],check_exact=True)
    # Truncate both target windows and observation clocks. This must preserve all
    # recovered windows whose forecasts precede2025.
    cutoff=pd.Timestamp('2025-01-01',tz='UTC')
    early=before[pd.to_datetime(before.prediction_time,utc=True).lt(cutoff)]
    prefix,_,_=recover(early,{k:v for k,v in lineups.items() if pd.Timestamp(v['available_time'])<cutoff})
    pd.testing.assert_frame_equal(prefix,after.loc[early.index],check_exact=True)
    audit.to_csv(RESULT/'recovered_windows.csv',index=False)
    after.groupby(['league','evidence_status']).size().rename('team_sides').reset_index().to_csv(RESULT/'coverage.csv',index=False)
    after.to_parquet(path,index=False);after.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    receipt=dict(status='PASS',at_utc=stamp(),table=TABLE,**source,previous_ready_windows=int(before.evidence_status.eq('ready').sum()),
        ready_windows=int(after.evidence_status.eq('ready').sum()),new_ready_windows=len(audit),
        existing_ready_native_comparisons=overlap,unchanged_rows=int(unchanged.sum()),prefix_invariant_rows=len(prefix),
        unknown_cross_provider_ids_not_invented=True,all_source_times_before_forecast=True,
        prior_table_sha256=oldhash,final_table_sha256=file_sha256(path))
    dump(RESULT/'validation.json',receipt);dump(ROOT_OUT/'retention/soccer_lineup_continuity_validation.json',receipt)
    from soccer_current_roster import publish
    publish()
    print(json.dumps(receipt|dict(raw_source_hashes='Retained in validation.json')),flush=True)


def finish():
    from final_pipeline import cleanup,validate,discard_work
    proof=json.loads((RESULT/'validation.json').read_bytes());assert proof['status']=='PASS'
    assert file_sha256(ROOT_OUT/(TABLE+'.parquet'))==proof['final_table_sha256']
    coverage=pd.read_csv(RESULT/'coverage.csv')
    lines=['# Soccer continuity recovered from native player IDs','',
        'A complete starting eleven does not require an Opta identity bridge to measure turnover within the same source. The recovery uses ten complete official Elche/LaLigaMaker lineups, consistent UUIDs and only literal asset-ID bridges. Unresolved players retain maker:UUID keys; no name-based canonical alias is invented. Counts from these windows must not be joined to canonical player tables without a separately verified link.','',
        f'Recovered {proof["new_ready_windows"]} previously incomplete team-date windows. Ready coverage is now {proof["ready_windows"]} of23,188, compared with {proof["previous_ready_windows"]}. All {proof["existing_ready_native_comparisons"]} already-complete overlapping windows reproduce the original turnover values exactly. All other rows remain identical.','',
        f'Validation replays {proof["raw_responses_verified"]} raw responses and {proof["player_rows_replayed"]} player records. Exact native game/team IDs, official score, explicit starting flags, stable UUIDs and asset-linked IDs are checked. Every observation predates the forecast. Truncating later observations reproduces {proof["prefix_invariant_rows"]} earlier output rows.','',
        'Original direct league/FCBarcelona source methods remain available. This recovery is explicitly an official club API republishing LaLigaMaker data. The current public route was read from the official client: https://www.elchecf.es/_next/static/chunks/pages/_app-bbcca07184f495da.js and https://www.elchecf.es/_next/static/chunks/8168.2083131325c4ec44.js . Exact dated/API request URLs, original responses and hashes are preserved in each recovered window. No credentials or restricted upstream API are used.','',
        'Reproduce soccer_source_continuity.py build then finish. Recovery changes the existing SQL/CSV/Parquet continuity table and catalog definitions; it does not create a duplicate research table or alter the app.']
    if (RESULT/'model_validation.json').exists():
        check_model=json.loads((RESULT/'model_validation.json').read_bytes());assert check_model['status']=='PASS'
        metrics=pd.read_csv(RESULT/'development_metrics.csv')
        def table(f):
            def fmt(v):return f'{v:.6f}' if isinstance(v,(float,np.floating)) else str(v)
            return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(map(fmt,row))+' |' for row in f.itertuples(index=False,name=None)])
        lines+=['','Model test: reconstruct the validated count-corrected41-input features, apply the previously verified static-person feature evidence, and keep the same44-input continuity recipe. Only the three derived turnover inputs can change. Reproduce every saved control forecast before comparing the increased source coverage. Monthly training expands from2021; forecasts begin2024; imputation/scaling and purged calibration use earlier observations only.','',
            table(metrics),'','Selection: '+json.dumps(json.loads((RESULT/'selection.json').read_bytes()))+'. Correct source data remain published whether the forecasting gate passes or fails.2026is repeatedly inspected retrospective evidence.','',
            table(pd.read_csv(RESULT/'annual.csv')[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
            'Accounts retain the existing$5per positive probability-minus-price percentage point on one selected outcome, annual$2000cash-only,pre12closest-prior quote at most24hoursold. No costs assumed. Sharpe annualizes calendar daily returns withsqrt365.25. Polymarket is historical token-price reference data, not verified executable USasks. Kalshi uses retainedYESasks. Reproduce model_prepare and train between build and finish.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    if WORK.exists():
        assert (RESULT/'model_validation.json').exists(),'Preserve unfinished model work'
        discard_work(WORK)
    cleanup();check=validate()
    receipt=dict(status='PASS',at_utc=stamp(),data_validation=proof,app_validation=check,goal_achieved=False)
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(path.read_bytes())
    m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']),latest_data_update=receipt);dump(path,m)


def model_prepare():
    import soccer_source_count_rates as counts
    from soccer_current_roster import FIELDS
    assert not (RESULT/'model_feature_validation.json').exists()
    WORK.mkdir(parents=True,exist_ok=True)
    counts.WORK=WORK;counts.RESULT=WORK/'count_replay';counts.RESULT.mkdir(exist_ok=True)
    counts.build()
    previous=ROOT_OUT/'simulation_results/soccer_current_roster'
    reference=ROOT_OUT/'simulation_results/soccer_source_count_rates'
    frame=pd.read_parquet(WORK/'squad/soccer_features.parquet').set_index('game_id')
    assert file_sha256(WORK/'squad/soccer_features.parquet')==json.loads((reference/'feature_validation.json').read_bytes())['candidate_hash']
    evidence_path=previous/'identity_feature_evidence.parquet'
    identity=pd.read_parquet(evidence_path).set_index('game_id').loc[frame.index]
    assert identity.index.equals(frame.index)
    cols=[c.removeprefix('linked_') for c in identity if c.startswith('linked_')]
    assert len(cols)==7
    for c in cols:
        assert np.allclose(frame[c],identity['previous_'+c],rtol=0,atol=1e-10,equal_nan=True)
        frame[c]=identity['linked_'+c]
    table=pd.read_parquet(ROOT_OUT/(TABLE+'.parquet'))
    check=json.loads((RESULT/'validation.json').read_bytes())
    assert file_sha256(ROOT_OUT/(TABLE+'.parquet'))==check['final_table_sha256']
    old=table.copy();changed=pd.read_csv(RESULT/'recovered_windows.csv')
    keys=set(map(tuple,changed[['game_id','side']].to_numpy()))
    mask=np.array([(g,s) in keys for g,s in old[['game_id','side']].itertuples(index=False,name=None)])
    assert int(mask.sum())==check['new_ready_windows']
    old.loc[mask,'starter_usage_turnover']=np.nan
    a=(frame.f_ctx_uefa_log_strength_sum-frame.f_ctx_uefa_log_strength_diff)/2
    b=(frame.f_ctx_uefa_log_strength_sum+frame.f_ctx_uefa_log_strength_diff)/2
    matrices={}
    for label,t in [('control',old),('candidate',table)]:
        pivot=t.pivot(index='game_id',columns='side',values='starter_usage_turnover').reindex(frame.index)
        f=frame.copy();f[FIELDS[0]]=pivot.B-pivot.A;f[FIELDS[1]]=pivot.B+pivot.A;f[FIELDS[2]]=b*pivot.B-a*pivot.A
        folder=WORK/label;folder.mkdir(exist_ok=True);f.reset_index().to_parquet(folder/'soccer_features.parquet',index=False)
        matrices[label]=f
    pd.testing.assert_frame_equal(matrices['control'].drop(columns=FIELDS),matrices['candidate'].drop(columns=FIELDS),check_exact=True)
    recipe=copy.deepcopy(json.loads((previous/'experiment_plan.json').read_bytes())['recipe']);recipe['preserve_unit_columns']+=FIELDS
    dump(RESULT/'experiment_plan.json',dict(at_utc=stamp(),recipe=recipe,new_columns=[],changed_columns=FIELDS,
        question='Does complete native starter history add predictive information beyond the previous identical44-input model?',
        scope='Only added208complete earlier lineup windows change turnover. Same verified person-ID correction and source-count proofs; no outcome-selected source matching.',
        gate='Candidate improves pooled2024/25logloss andBrier and2025logloss versus prior44-inputcontrol AND41-inputidentitycontrol. No threshold/hyperparameter grid. Only then new2026evaluation.',
        training='Monthly expanding2021+history, purged180daycalibration, predictions2024onward.',
        evaluation='2026 repeatedly inspected retrospective rolling research.',app_changed=False))
    proof=dict(status='PASS',at_utc=stamp(),games=len(frame),identity_feature_evidence_sha256=file_sha256(evidence_path),
        source_feature_hash_reproduced=True,only_turnover_fields_change=True,
        changed_rows={c:int((~np.isclose(matrices['control'][c],matrices['candidate'][c],rtol=0,atol=1e-12,equal_nan=True)).sum()) for c in FIELDS},
        source_table_sha256=check['final_table_sha256'],feature_hashes={k:file_sha256(WORK/k/'soccer_features.parquet') for k in matrices})
    dump(RESULT/'model_feature_validation.json',proof);print(json.dumps(proof),flush=True)


def train():
    import pickle
    import models
    import soccer_tie_context as simulation
    from sklearn.metrics import log_loss
    assert not (RESULT/'model_validation.json').exists()
    plan=json.loads((RESULT/'experiment_plan.json').read_bytes())
    saved=pd.read_parquet(ROOT_OUT/'simulation_results/soccer_current_roster/development_predictions.parquet')
    control=saved[saved.variant.eq('turnover_recovered')].copy();control['variant']='reference'
    identity=saved[saved.variant.eq('identity')].copy();identity['variant']='identity_control'
    modelchecks=0;parts=[control,identity]
    for name in ['control','candidate']:
        models.OUT=WORK/name;models.CANDIDATES[name]=copy.deepcopy(plan['recipe'])
        p=models.run('soccer','development',[name])
        if name=='control':
            a=p.set_index('game_id');b=control.set_index('game_id').loc[a.index]
            assert np.allclose(a[['p0','p1','p2']],b[['p0','p1','p2']],rtol=0,atol=1e-12)
            for c in ['target','prediction_time','train_label_max','calibration_label_max']:assert np.array_equal(a[c],b[c])
        else:parts.append(p)
        package=pickle.loads((models.OUT/'model_runs/soccer/development'/(name+'.pkl')).read_bytes())
        frame=pd.read_parquet(models.OUT/'soccer_features.parquet');frame=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
        sample=p[p.fold.eq(package['boundary'].strftime('%Y-%m'))]
        got=models.apply_calibration(package['model'].predict_proba(frame.loc[sample.game_id,package['columns']].astype(float)),package['calibrator'])
        assert np.allclose(got,sample[['p0','p1','p2']],rtol=0,atol=1e-12);modelchecks+=len(sample)
        assert len(package['columns'])==44
        assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
        assert p.calibration_train_label_max.lt(p.calibration_prediction_min).all()
    joined=pd.concat(parts,ignore_index=True);joined.to_parquet(RESULT/'development_predictions.parquet',index=False)
    models.metrics(joined).to_csv(RESULT/'development_metrics.csv',index=False)
    scores={}
    for variant,f in joined.groupby('variant'):
        y=f.target.to_numpy(int);prob=f[['p0','p1','p2']].to_numpy();last=f[f.prediction_time.dt.year.eq(2025)]
        scores[variant]=dict(logloss=log_loss(y,prob,labels=[0,1,2]),brier=float(np.mean(np.sum((prob-np.eye(3)[y])**2,axis=1))),
            logloss2025=log_loss(last.target,last[['p0','p1','p2']],labels=[0,1,2]))
    passed=all(scores['candidate'][c]<scores[v][c] for v in ['reference','identity_control'] for c in scores['candidate'])
    dump(RESULT/'selection.json',dict(at_utc=stamp(),passed=bool(passed),scores=scores,adopted=False))
    evaluation=None
    if passed:
        models.OUT=WORK/'candidate';dump(models.OUT/'soccer_selection.json',dict(selected_candidates=['candidate']))
        ev=models.run('soccer','evaluation',['candidate'])
        ref=pd.read_parquet(ROOT_OUT/'simulation_results/soccer_source_count_rates/evaluation_predictions.parquet');ref=ref[ref.variant.eq('candidate')].copy();ref['variant']='count_reference'
        evaluation=pd.concat([ref,ev],ignore_index=True);evaluation.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
    simulation.RESULT=RESULT;simulation.simulate(joined,evaluation)
    dump(RESULT/'model_validation.json',dict(status='PASS',at_utc=stamp(),original_control_forecasts_reproduced=len(control),fitted_forecasts_replayed=modelchecks,
        earlier_training_and_calibration_checked=True,only_three_turnover_inputs_changed=True,selection_passed=bool(passed),evaluated2026=bool(passed),app_changed=False))
    print(json.dumps(dict(passed=bool(passed),scores=scores)),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['build','model_prepare','train','finish'])
    globals()[parser.parse_args().stage]()
