"""Small sport-specific feature sets, derived only from existing causal facts."""
import argparse,hashlib,json
import numpy as np
import pandas as pd
from common import ROOT_OUT,OUT,dump,stamp

STRENGTH=['f_elo_diff','f_rest_days_diff','f_rest_days_sum','f_games_7d_diff','f_margin_diff','f_margin_sum',
          'f_home_attack','f_away_attack','f_home_defence','f_away_defence','f_playoffs']


def paired(f,field):
    return (f[field+'_sum']-f[field+'_diff'])/2,(f[field+'_sum']+f[field+'_diff'])/2


def ratio(num,den):return num/den.where(den>0)


def build(sport,frame=None,save=True):
    run='nhl_tuning_v3' if sport=='nhl' else 'player_backfill_v4'
    source=ROOT_OUT/run/(sport+'_features.parquet');f=pd.read_parquet(source) if frame is None else frame.copy();catalog=[]
    def add(name,values,meaning,inputs):
        field='f_mech_'+name;f[field]=values.replace([np.inf,-np.inf],np.nan)
        catalog.append(dict(column=field,meaning=meaning,source_columns=inputs,missing_pct=float(100*f[field].isna().mean())))
    def keep(column,meaning):add(column.removeprefix('f_'),f[column],meaning,[column])
    if sport=='nhl':
        # B-A orientation follows the existing research features.
        add('even_strength_expected_margin',(f.f_xg_even_strength_diff-f.f_xg_even_strength_against_diff)/2,
            'Home-minus-away expected even-strength chance advantage, pairing own attack with opponent defence.',
            ['f_xg_even_strength_diff','f_xg_even_strength_against_diff'])
        add('even_strength_expected_total',(f.f_xg_even_strength_sum+f.f_xg_even_strength_against_sum)/2,
            'Expected combined even-strength chance volume; not an official goal forecast.',
            ['f_xg_even_strength_sum','f_xg_even_strength_against_sum'])
        for field,meaning in {
            'f_usat_fraction_5v5_diff':'Difference in prior five-on-five unblocked shot share.',
            'f_role_goalie_goals_saved_above_model_per60_60_diff':'Recent observed goalie pool: goals saved above internal xG per 60, up to 60 appearances.',
            'f_role_goalie_goals_saved_above_model_per60_10_diff':'Shorter-form goalie quality using up to ten appearances.',
            'f_goalie_workload_concentration_diff':'Difference in dependence on one recently observed goalie.',
            'f_role_leading_goalie_rest_days_diff':'Rest difference for the most-used recent goalie; not a confirmed starter.',
            'f_role_back_to_back_diff':'Difference in back-to-back schedule exposure.',
            'f_role_forward_model_xg_per60_60_diff':'Observed forwards chance creation per 60 minutes.',
            'f_role_defence_model_xg_per60_60_diff':'Observed defenders chance creation per 60 minutes.',
            'f_role_forward_assists_per60_60_diff':'Observed forwards assist production per 60 minutes.',
            'f_role_defence_blocked_shots_per60_60_diff':'Observed defenders blocked shots per 60 minutes.',
            'f_role_finishing_residual_recent_diff':'Recent goals above internal shot-quality expectation.',
            'f_role_xg_change_diff':'Shorter-minus-longer chance-creation trend difference.',
        }.items():keep(field,meaning)
        goals=paired(f,'f_pp_goals');opps=paired(f,'f_pp_opportunities')
        allowed=paired(f,'f_pp_goals_against');short=paired(f,'f_times_shorthanded')
        attack=[ratio(goals[i],opps[i]) for i in range(2)];defence=[ratio(allowed[i],short[i]) for i in range(2)]
        expected=[(opps[i]+short[1-i])/2*(attack[i]+defence[1-i])/2 for i in range(2)]
        inputs=[f'f_{n}_{suffix}' for n in ['pp_goals','pp_opportunities','pp_goals_against','times_shorthanded'] for suffix in ['sum','diff']]
        add('special_teams_expected_margin',expected[1]-expected[0],
            'Power-play matchup: earlier conversion and opponent concession rates multiplied by expected opportunity counts.',inputs)
        add('special_teams_expected_total',expected[1]+expected[0],'Combined special-team scoring proxy from earlier observations.',inputs)
    else:
        add('expected_chance_margin',(f.f_quality_xg_diff-f.f_quality_xg_against_diff)/2,
            'Home-minus-away chance advantage pairing earlier attacking xG with opponent xG conceded.',
            ['f_quality_xg_diff','f_quality_xg_against_diff'])
        add('expected_chance_total',(f.f_quality_xg_sum+f.f_quality_xg_against_sum)/2,
            'Combined expected chance volume from earlier attack and defence; useful for low-score/draw tendency.',
            ['f_quality_xg_sum','f_quality_xg_against_sum'])
        for field,meaning in {
            'f_context_goal_balance_relative':'Relative balance of teams earlier scoring/conceding rates.',
            'f_context_draw_rate_sum':'Combined observed historical draw frequency.',
            'f_context_low_total_rate_sum':'Combined fraction of earlier games with at most two goals.',
            'f_finishing_residual_diff':'Difference between earlier goals and chance-quality expectation.',
            'f_keeper_goals_saved_diff':'Keeper goals prevented relative to earlier on-target chance quality.',
            'f_expected_goals_on_target_diff':'Difference in earlier on-target shot quality.',
            'f_big_chances_diff':'Earlier clear-chance production difference.',
            'f_box_entries_diff':'Earlier progression into the penalty area.',
            'f_recoveries_attacking_third_diff':'Earlier attacking-third ball recovery difference.',
            'f_errors_to_shot_diff':'Earlier errors leading to opponent shots.',
            'f_roster_key_passes_rate_diff':'Recently observed player pool: chance-creating passes per 90.',
            'f_roster_xg_rate_diff':'Recently observed player pool: attacking xG per 90.',
            'f_roster_xa_rate_diff':'Recently observed player pool: expected assists per 90.',
            'f_roster_interceptions_rate_diff':'Recently observed player pool: interceptions per 90.',
            'f_roster_continuity_diff':'Earlier observed lineup continuity difference.',
            'f_context_passing_completion_fraction_30_diff':'Earlier team passing accuracy.',
            'f_context_passing_passer_concentration_30_diff':'Dependence on a few players for completed passes.',
            'f_context_passing_reciprocal_passing_fraction_30_diff':'Earlier bidirectional passing connections, where official passing matrices exist.',
        }.items():keep(field,meaning)
    # Source summaries are frozen for this experiment. Future collection changes
    # require a new run, rather than silently changing a previously scored fold.
    if not save:return f
    f.to_parquet(OUT/(sport+'_features.parquet'),index=False)
    dump(OUT/(sport+'_mechanism_features.json'),dict(at_utc=stamp(),source_run=run,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
         games=len(f),strength_columns=STRENGTH,mechanism_columns=catalog,
         hypotheses='Hockey: shot quality, goalie contribution, rest and special teams. Soccer: chance creation/concession, finishing, keeper quality, player contributions, passing and draw tendency.',
         market_inputs=False,selection='Candidate settings and feature groups specified before evaluating this run on 2026.'))
    print(json.dumps(dict(sport=sport,games=len(f),strength_features=len(STRENGTH),added_mechanism_features=len(catalog))),flush=True)
    return f


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--sport',choices=['nhl','soccer'],required=True);a=p.parse_args();build(a.sport)
