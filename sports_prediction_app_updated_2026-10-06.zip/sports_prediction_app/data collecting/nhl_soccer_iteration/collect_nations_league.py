"""Official UEFA Nations League history. National-team IDs never join club IDs.

The current official fixtures page declares competitionId=2014, code UNL.
Calendar, dated lineups and events use the same official endpoints as UCL.
Retain raw responses before normalization and reconcile regulation scores.
"""
import argparse,collections,concurrent.futures,datetime as dt,hashlib,json,sqlite3,sys
from pathlib import Path
from urllib.parse import urlencode
import pandas as pd
from common import OfficialClient,PROJECT,ROOT_OUT,REPORTS,dump,stamp
from collect_uefa_exposure import parse
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from uefa_regulation_scores import score

LEAGUE='UEFA Nations League'
DATABASE=ROOT_OUT/'nations_league.sqlite'
BASE='https://match.uefa.com/v5/matches'


def connect():
    c=sqlite3.connect(DATABASE,timeout=60)
    c.executescript('''CREATE TABLE IF NOT EXISTS calendar(game_id TEXT PRIMARY KEY,body TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS details(game_id TEXT PRIMARY KEY,body TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,reason TEXT,sources TEXT);
    CREATE TABLE IF NOT EXISTS calendar_pages(url TEXT PRIMARY KEY,body TEXT NOT NULL);''')
    return c


def normalize(m,source,index):
    assert str(m['competition']['id'])=='2014' and m['competition']['code']=='UNL'
    assert m['status']=='FINISHED'
    a,b=m['awayTeam'],m['homeTeam']
    assert all(t['typeTeam']=='NATIONAL' and not t.get('isPlaceHolder') for t in [a,b])
    assert a['id']!=b['id']
    ko=m['kickOffTime'];start=dt.datetime.fromisoformat(ko['dateTime'])
    assert start.tzinfo and start.astimezone(dt.timezone(dt.timedelta(hours=ko['utcOffsetInHours']))).date().isoformat()==ko['date']
    result=score(m);scores=result['scores'] or [None,None]
    year=int(m['seasonYear']);end=m.get('fullTimeAt')
    # A missing end clock is not a fabricated final-whistle time. Use next
    # UTC day as a conservative modeling cutoff, explicitly labelled.
    available=end or (start.astimezone(dt.UTC).date()+dt.timedelta(days=1)).isoformat()+'T00:00:00Z'
    assert dt.datetime.fromisoformat(available.replace('Z','+00:00'))>start
    stadium=m.get('stadium') or {};translations=stadium.get('translations',{})
    venue=translations.get('officialName',{}).get('EN')
    city=stadium.get('city',{}).get('translations',{}).get('name',{}).get('EN')
    return dict(game_id='HIST_UNL_'+str(m['id']),official_game_id=str(m['id']),sport='soccer',game_type='Soccer',league=LEAGUE,
        competition_id='2014',team_type='national',date=ko['date'],season=f'{year-1}-{str(year)[-2:]}',season_year=year,
        start_time=start.astimezone(dt.UTC).isoformat(),available_time=available,
        availability_basis='official_full_time' if end else 'conservative_next_utc_day',
        teamA=a['translations']['displayOfficialName']['EN'],teamB=b['translations']['displayOfficialName']['EN'],
        teamA_id='UEFA_NATIONAL:'+str(a['id']),teamB_id='UEFA_NATIONAL:'+str(b['id']),
        native_team_ids_json=json.dumps([str(a['id']),str(b['id'])]),scoreA=scores[0],scoreB=scores[1],
        final=None if result['scores'] is None else ('Draw' if scores[0]==scores[1] else [a,b][int(scores[1]>scores[0])]['translations']['displayOfficialName']['EN']),
        phase=m['competitionPhase'],round_name=m.get('round',{}).get('metaData',{}).get('name'),
        location=', '.join(x for x in [venue,city] if x) or None,
        home_away=';'.join('Home' if t['countryCode']==stadium['countryCode'] else 'Away' for t in [a,b]) if stadium.get('countryCode') else None,
        home_away_basis='Official stadium country compared with each national-team country; A/B order remains official away/home, including Away;Away neutral fixtures',
        public_url=f'https://www.uefa.com/uefanationsleague/match/{m["id"]}/',source=source,pointer='/'+str(index),score_evidence=result)


def calendar(start,end):
    client=OfficialClient(per_second=2);db=connect();counts=collections.Counter();requests=[]
    for year in [2021,2023,2025,2027]:
        if year<dt.date.fromisoformat(start).year or year-1>dt.date.fromisoformat(end).year:continue
        seen=set()
        for offset in range(0,2000,50):
            params=dict(competitionId=2014,seasonYear=year,fromDate=start,toDate=end,order='ASC',limit=50,offset=offset)
            url=BASE+'?'+urlencode(params)
            data,source=client.get(url,'Nations League calendar '+str(year)+' dates '+start+' through '+end,'official_schedule',refresh=True)
            assert isinstance(data,list),f'Calendar acquisition failed: {source}'
            ids=[str(m['id']) for m in data];assert len(ids)==len(set(ids)) and not seen.intersection(ids),'Repeated official page'
            seen.update(ids);requests.append(source)
            with db:
                db.execute('INSERT OR REPLACE INTO calendar_pages VALUES (?,?)',(url,json.dumps(dict(source=source,params=params,count=len(data)))))
                for i,m in enumerate(data):
                    assert str(m['competition']['id'])=='2014' and int(m['seasonYear'])==year
                    assert start<=m['kickOffTime']['date']<=end
                    counts[m['status']]+=1
                    if m['status']!='FINISHED':continue
                    row=normalize(m,source,i)
                    db.execute('INSERT OR REPLACE INTO calendar VALUES (?,?)',(row['game_id'],json.dumps(row)))
            print(json.dumps(dict(stage='nations_calendar',season=year,offset=offset,rows=len(data),statuses=dict(counts))),flush=True)
            if len(data)<50:break
        else:raise AssertionError('Official calendar pagination not exhausted')
    db.close();dump(ROOT_OUT/'nations_calendar_acquisition.json',dict(at_utc=stamp(),start=start,end=end,statuses=dict(counts),requests=requests))


def fetch_details(client,g):
    sources={}
    try:
        root=BASE+'/'+g['official_game_id']
        match,sources['match']=client.get(root,'Nations League official final result '+g['date'],'official_match_metadata')
        lineup,sources['lineup']=client.get(root+'/lineups','Nations League historical national-team lineup '+g['date'],'official_match_lineup')
        assert match is not None and lineup is not None,'Metadata or lineup acquisition needs retry'
        assert str(match['competition']['id'])=='2014'
        events=[];sources['events']=[];seen=set()
        for offset in range(0,10000,500):
            page,s=client.get(root+'/events?'+urlencode(dict(filter='ALL',limit=500,offset=offset,order='ASC')),'Nations League historical events '+g['date'],'official_match_events')
            sources['events'].append(s);assert isinstance(page,list),'Event acquisition needs retry'
            ids=[str(e['id']) for e in page];assert not seen.intersection(ids),'Overlapping event pages';seen.update(ids);events.extend(page)
            if len(page)<500:break
        else:raise AssertionError('Event pagination not exhausted')
        # Independent metadata must agree with the calendar's regulation score.
        result=score(match);assert result['scores']==[g['scoreA'],g['scoreB']],'Calendar/detail regulation result conflict'
        from nations_official_corrections import correct_events
        events,corrections=correct_events(g,events,client)
        output=parse(g,match,lineup,events,sources,accept_full_time=True,ignore_zero_duration_unknown_cards=True)
        output['official_corrections']=corrections
        coaches=[]
        for side,label,tid in zip(['A','B'],['awayTeam','homeTeam'],json.loads(g['native_team_ids_json'])):
            for coach in lineup[label].get('coaches',[]):
                p=coach.get('person',{});name=p.get('internationalName') or p.get('translations',{}).get('name',{}).get('EN')
                if p.get('id') and name:coaches.append(dict(game_id=g['game_id'],date=g['date'],league=LEAGUE,side=side,
                    team_id='UEFA_NATIONAL:'+tid,team_name=g['team'+side],manager_id='UEFA:'+str(p['id']),manager_name=name,
                    role=coach.get('role') or coach.get('type'),available_at_utc=g['available_time'],source=sources['lineup']))
        for p in output['players']:
            p['team_id']='UEFA_NATIONAL:'+p['team_id'];p['player_id']='UEFA:'+p['official_player_id'];p['team_name']=g['team'+p['side']]
        output['coaches']=coaches
        return g,output,None,sources
    except Exception as exc:return g,None,type(exc).__name__+': '+str(exc),sources


def details(pilot=False,through_percent=100):
    db=connect();games=[json.loads(b) for b, in db.execute('SELECT body FROM calendar')];games.sort(key=lambda r:(r['date'],r['game_id']))
    games=[g for g in games if g['scoreA'] is not None and g['scoreB'] is not None]
    if pilot:
        chosen={}
        for g in games:chosen.setdefault(g['date'][:4],g)
        games=list(chosen.values())
    games=games[:max(1,(len(games)*through_percent+99)//100)]
    done={r[0] for r in db.execute('SELECT game_id FROM details')};tasks=[g for g in games if g['game_id'] not in done]
    client=OfficialClient(per_second=2);count=collections.Counter();retained=len(games)-len(tasks);milestone=(retained*100//max(1,len(games))//10+1)*10
    print(json.dumps(dict(stage='nations_details_start',tasks=len(tasks),retained=len(done),pilot=pilot)),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for n,(g,body,error,sources) in enumerate(pool.map(lambda g:fetch_details(client,g),tasks),1):
            with db:
                if body:
                    db.execute('INSERT OR REPLACE INTO details VALUES (?,?)',(g['game_id'],json.dumps(body)))
                    db.execute('DELETE FROM issues WHERE game_id=?',(g['game_id'],))
                    count['games']+=1;count['players']+=len(body['players']);count['field_issues']+=len(body['issues'])
                else:
                    db.execute('INSERT OR REPLACE INTO issues VALUES (?,?,?)',(g['game_id'],error,json.dumps(sources)))
                    count['request_or_schema_issues']+=1
            if (n+retained)*100>=milestone*len(games) or n==len(tasks):
                progress=dict(at_utc=stamp(),stage='nations_details',processed=n+retained,total=len(games),percent=100*(n+retained)/len(games),latest_date=g['date'],new_batch_counts=dict(count))
                dump(ROOT_OUT/'nations_league_progress.json',progress);print(json.dumps(progress),flush=True);milestone+=10
    db.close()


def publish():
    from publish import flat
    db=connect();games=[json.loads(b) for b, in db.execute('SELECT body FROM calendar')];details=[json.loads(b) for b, in db.execute('SELECT body FROM details')]
    failures=[dict(game_id=g,reason=r) for g,r in db.execute('SELECT game_id,reason FROM issues')]
    checked=0
    for g in games:
        s=g['source'];b=(PROJECT/s['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==s['sha256']
        raw=json.loads(b)[int(g['pointer'][1:])];assert normalize(raw,s,int(g['pointer'][1:]))==g;checked+=1
    rows=[];weather=[];team_facts=[]
    for g in games:
        r={k:v for k,v in g.items() if k not in ['source','score_evidence']}
        r.update(source_request_id=g['source']['request_number'],source_url=g['source']['url'],source_raw_file=g['source']['raw_file'],source_sha256=g['source']['sha256'],score_evidence_json=json.dumps(g['score_evidence']))
        rows.append(r)
        for side,other in [('A','B'),('B','A')]:
            sf,sa=g['score'+side],g['score'+other]
            team_facts.append(dict(game_id=g['game_id'],date=g['date'],league=LEAGUE,team_id=g['team'+side+'_id'],team_name=g['team'+side],
                home_away=g['home_away'].split(';')[int(side=='B')] if g['home_away'] else None,score_for=sf,score_against=sa,
                win=int(sf>sa) if sf is not None and sa is not None else None,draw=int(sf==sa) if sf is not None and sa is not None else None,
                score_margin=sf-sa if sf is not None and sa is not None else None,
                absolute_score_difference=abs(sf-sa) if sf is not None and sa is not None else None,
                available_at_utc=g['available_time'],source_request_id=g['source']['request_number']))
    frames={'nations_league_games':flat(rows)}
    frames['nations_league_team_match_statistics']=flat(team_facts)
    if details:
        frames['nations_league_player_match_statistics']=flat([p for b in details for p in b['players']])
        frames['nations_league_manager_appearances']=flat([p for b in details for p in b['coaches']])
        frames['nations_league_source_links']=flat([{k:v for k,v in b.items() if k not in ['players','coaches']} for b in details])
        lookup={g['game_id']:g for g in games}
        for b in details:
            s=b['sources']['match'];raw=json.loads((PROJECT/s['raw_file']).read_bytes());condition=raw.get('condition') or {};g=lookup[b['game_id']]
            weather.append(dict(game_id=g['game_id'],date=g['date'],location=g['location'],temperature_c=condition.get('temperature'),
                humidity_pct=condition.get('humidity'),weather_type=condition.get('translations',{}).get('weatherConditionName',{}).get('EN') or condition.get('weatherCondition'),
                wind_speed_kmh=condition.get('windSpeed'),wind_direction=condition.get('windDirection'),
                available_at_utc=g['available_time'],source_url=s['url'],source_raw_file=s['raw_file'],source_sha256=s['sha256']))
        frames['nations_league_weather']=flat(weather)
    missing=[]
    for name,f in frames.items():
        if f.empty:continue
        f.to_sql(name,db,if_exists='replace',index=False);f.to_parquet(ROOT_OUT/(name+'.parquet'),index=False);f.to_csv(ROOT_OUT/(name+'.csv'),index=False)
        for col in f:missing.append(dict(table=name,column=col,rows=len(f),missing=int(f[col].isna().sum()),missing_pct=100*float(f[col].isna().mean())))
    report=dict(at_utc=stamp(),games=len(games),by_year=dict(collections.Counter(g['date'][:4] for g in games)),
        first_date=min(g['date'] for g in games),last_date=max(g['date'] for g in games),raw_calendar_rows_replayed=checked,
        games_with_player_details=len(details),player_rows=sum(len(b['players']) for b in details),request_or_schema_issues=failures,
        field_issues=[dict(game_id=b['game_id'],issues=b['issues']) for b in details if b['issues']],
        missing_regulation_scores=sum(g['scoreA'] is None for g in games),
        scope='Official national-team facts. Market odds and rolling models have separate coverage and validation reports. Club history is not treated as national-team match history.')
    dump(ROOT_OUT/'nations_league_validation.json',report);pd.DataFrame(missing).to_csv(REPORTS/'nations_league_missing.csv',index=False)
    db.close();print(json.dumps({k:v for k,v in report.items() if k!='field_issues'}),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--calendar',action='store_true');ap.add_argument('--pilot',action='store_true');ap.add_argument('--details',action='store_true');ap.add_argument('--publish',action='store_true')
    ap.add_argument('--start',default='2021-01-01');ap.add_argument('--end',default=dt.datetime.now(dt.UTC).date().isoformat());ap.add_argument('--through-percent',type=int,default=100);a=ap.parse_args()
    assert 0<a.through_percent<=100
    if a.calendar:calendar(a.start,a.end)
    if a.pilot or a.details:details(a.pilot,a.through_percent)
    if a.publish:publish()
