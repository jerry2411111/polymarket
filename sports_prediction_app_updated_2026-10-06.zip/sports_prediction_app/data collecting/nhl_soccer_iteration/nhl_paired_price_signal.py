"""Test incremental forecast information on all paired pre12 markets.

Earlier reliability work conditioned on a side picked by the sports model.
Here both prices are required before any outcome selection. One expanding
weight combines the saved sports forecast and normalized market probabilities.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from sklearn.metrics import log_loss, brier_score_loss, accuracy_score

from common import ROOT_OUT, REPORTS, dump, stamp, file_sha256
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine
from backtest import attach, quote_inputs

LABEL='nhl_paired_price_signal'
RESULT=ROOT_OUT/'simulation_results'/LABEL


def initialize():
    RESULT.mkdir(parents=True,exist_ok=True)
    selection=json.loads((ROOT_OUT/'simulation_results/staking_model_selection/selection.json').read_bytes())['selections']['nhl']
    plan=dict(at_utc=stamp(),sports_model=selection,
      hypothesis='Selected apparent edges can select probability errors. Measure incremental model information on all games with two usable prices, independently of model outcome selection.',
      cohort='Official native game/team IDs, both away/home pre12 quotes, source and availability no later than decision, each at most24hoursold. Historical reference observations, not proof of executable orders.',
      market_probability='Home price divided by sum of the two prices; used only as a probability forecast. Actual purchase prices remain the original values and are never normalized.',
      estimator='One weight w in[0,1]: q=w*model_p+(1-w)*market_p. Minimize mean logloss over all prior settled paired games separately by provider. No intercept, other predictors or parameter grid.',
      training='Monthly expanding calibration on stored out-of-fit forecast/price pairs from2024. Underlying sports models expand from2021. Require100prior paired games and10of each result; report readiness and compare all models on the same ready cohort.',
      controls='Raw sports probability and normalized price probability on identical whole-game observations, before selection of a bet.',
      gate='Rolling2025 blended logloss must beat BOTH raw sports and market controls; Brier must beat the sports control; accuracy>=52%. Account diagnostic must then improve2025Sharpe with positive return before new2026evaluation.',
      betting='Unchanged one-side expected-log-growth selection, primary and independent secondary probability/price>=1.10,flat20dollars,cash-only annual2000. Sports and blend both use original secondary confirmation. No stake/hour tuning.',
      evaluation='Freeze2025decision before evaluating2026.2026already repeatedly inspected: retrospective rolling evidence.',app_changed=False)
    path=RESULT/'plan.json'
    if path.exists():assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(path,plan)
    return plan


def load(stage):
    plan=initialize();s=plan['sports_model'];path=ROOT_OUT/s['source']
    assert file_sha256(path)==s['source_sha256'] and s['component']=='primary'
    parts=[pd.read_parquet(path)]
    if stage=='evaluation':parts.append(pd.read_parquet(path.with_name('evaluation_predictions.parquet')))
    p=pd.concat(parts,ignore_index=True);p=p[p.variant.eq(s['variant'])].copy()
    assert not p.game_id.duplicated().any()
    years=[2024,2025] if stage=='development' else [2024,2025,2026]
    p=p[p.prediction_time.dt.year.isin(years)]
    quotes=quote_inputs(RESULT/(stage+'_quote_quality.json'),revision='closest_v62')
    quotes=quotes[quotes.sport.eq('nhl')&quotes.decision_utc.dt.year.isin(years)].copy()
    linked,audit=attach(p,quotes);dump(RESULT/(stage+'_matching.json'),audit)
    usable=linked[linked.usable_price&linked.entry_age_hours.le(24)&linked.quote_class.isin([0,1])].copy()
    assert not usable.duplicated(['provider','game_id','quote_class']).any()
    counts=usable.groupby(['provider','game_id']).quote_class.nunique()
    pairs=set(counts[counts.eq(2)].index)
    usable=usable[[tuple(x) in pairs for x in usable[['provider','game_id']].itertuples(index=False,name=None)]]
    meta=p.set_index('game_id');rows=[]
    for (provider,gid),f in usable.groupby(['provider','game_id']):
        f=f.set_index('quote_class');r=meta.loc[gid].to_dict();r.update(game_id=gid,provider=provider)
        for side in [0,1]:
            q=f.loc[side];r['price'+str(side)]=float(q.entry_price)
            r['source'+str(side)]=q.entry_source_utc;r['quote_available'+str(side)]=q.entry_available_utc
            r['age'+str(side)]=float(q.entry_age_hours)
            for field in ['entry_request_id','entry_pointer','entry_contract_id','price_basis']:
                r[field+str(side)]=q[field]
        r['price_sum']=r['price0']+r['price1'];r['market_p1']=r['price1']/r['price_sum']
        r['quote_time_difference_hours']=abs((r['source0']-r['source1']).total_seconds())/3600
        rows.append(r)
    cohort=pd.DataFrame(rows).sort_values(['prediction_time','provider','game_id']).reset_index(drop=True)
    assert cohort.train_label_max.lt(cohort.prediction_time).all()
    assert cohort.calibration_label_max.lt(cohort.prediction_time).all()
    published=cohort if stage=='development' else cohort[cohort.prediction_time.dt.year.eq(2026)]
    published.to_parquet(RESULT/(stage+'_paired_games.parquet'),index=False)
    coverage=[]
    for provider in ['polymarket','kalshi']:
        for year in years:
            original=p[p.prediction_time.dt.year.eq(year)]
            f=cohort[cohort.provider.eq(provider)&cohort.prediction_time.dt.year.eq(year)]
            coverage.append(dict(provider=provider,year=year,forecasts=len(original),paired_games=len(f),
                missing_paired_price_pct=100*(1-len(f)/len(original)),
                first_decision=str(f.prediction_time.min()),last_decision=str(f.prediction_time.max())))
    pd.DataFrame(coverage).to_csv(RESULT/(stage+'_coverage.csv'),index=False)
    return cohort,quotes


def rolling(cohort):
    records=[];fits=[]
    for provider,g in cohort.groupby('provider'):
        for fold,test in g.groupby(g.prediction_time.dt.strftime('%Y-%m')):
            boundary=pd.Timestamp(fold+'-01',tz='UTC');train=g[g.available_time.lt(boundary)]
            counts=train.target.value_counts()
            ready=len(train)>=100 and len(counts)==2 and counts.min()>=10
            if ready:
                y=train.target.to_numpy(int);sports=train.p1.to_numpy();market=train.market_p1.to_numpy()
                def loss(w):
                    p=w*sports+(1-w)*market
                    return float(-np.mean(y*np.log(p)+(1-y)*np.log1p(-p)))
                result=minimize_scalar(loss,bounds=(0,1),method='bounded');assert result.success
                choices=[(loss(w),w) for w in [0.,float(result.x),1.]]
                _,weight=min(choices)
                assert train.available_time.max()<test.prediction_time.min()
            else:weight=1.
            out=test.copy();out['blend_weight']=weight;out['blend_p1']=weight*out.p1+(1-weight)*out.market_p1
            out['fit_ready']=ready;out['price_fit_boundary']=boundary;out['price_fit_last_label']=train.available_time.max()
            records.append(out)
            fits.append(dict(provider=provider,fold=fold,ready=bool(ready),prior_games=len(train),forecast_games=len(test),
                sports_weight=weight,first_training_entry=None if not len(train) else str(train.prediction_time.min()),
                last_training_label=None if not len(train) else str(train.available_time.max())))
    result=pd.concat(records,ignore_index=True)
    for col in ['price_fit_boundary','price_fit_last_label']:
        result[col]=pd.to_datetime(result[col],utc=True,format='mixed').astype('datetime64[ns, UTC]')
    return result,pd.DataFrame(fits)


def score(data,years):
    rows=[]
    for (provider,year),g in data[data.fit_ready&data.prediction_time.dt.year.isin(years)].groupby(['provider',data.prediction_time.dt.year]):
        for label,col in [('sports','p1'),('market','market_p1'),('blend','blend_p1')]:
            prob=g[col].to_numpy();y=g.target.to_numpy(int)
            rows.append(dict(provider=provider,year=int(year),variant=label,games=len(g),accuracy=accuracy_score(y,prob>=.5),
                logloss=log_loss(y,np.column_stack([1-prob,prob]),labels=[0,1]),brier=brier_score_loss(y,prob),
                mean_quote_sum=g.price_sum.mean(),mean_quote_age=np.maximum(g.age0,g.age1).mean()))
    return pd.DataFrame(rows)


def accounts(data,quotes,years,stage,positive_only=False,variants=None):
    transfer.RESULT=RESULT;rows=[];bets=[];days=[];checks=[]
    for provider,records in data[data.fit_ready].groupby('provider'):
        for label in (variants or ['sports','blend']):
            p=records.copy();p['p1']=p.p1 if label=='sports' else p.blend_p1;p['p0']=1-p.p1
            f=transfer.normalize('nhl',p,quotes[quotes.provider.eq(provider)],True)
            ix=p.set_index('game_id').loc[f.game_id]
            f['secondary_probability']=np.where(f.side.eq(0),ix.second_p0,ix.second_p1)
            advantage=np.minimum(f.probability,f.secondary_probability)/f.price
            f=f[advantage.gt(1+1e-12) if positive_only else advantage.ge(1.10)].copy()
            for year in years:
                m,b,l,d=engine.simulate(f,year,'all_selected_outcomes','flat20_cash_only',5.,2000.)
                key=dict(provider=provider,variant=label,year=year,sport='nhl')
                checks.append(key|engine.validate(b,l,d,'flat20_cash_only',5.,2000.));rows.append(key|m)
                if len(b):bets.append(b.assign(**key))
                days.append(d.assign(**key))
    a=pd.DataFrame(rows);a.to_csv(RESULT/(stage+'_annual.csv'),index=False)
    if bets:pd.concat(bets,ignore_index=True).to_parquet(RESULT/(stage+'_bets.parquet'),index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/(stage+'_daily.parquet'),index=False)
    dump(RESULT/(stage+'_cash_validation.json'),dict(status='PASS',checks=checks))
    return a


def positive_value():
    """Remove the old10% hurdle after probability shrinkage; fixed stakes remain."""
    selection=json.loads((RESULT/'selection.json').read_bytes())
    allowed=[p for p,x in selection['choices'].items() if x['probability_gate']]
    assert allowed
    plan=dict(at_utc=stamp(),hypothesis='The blend improves proper probability scores but compresses edges, so keeping the10%hurdle removes many positive-value opportunities. Test the simpler expected-profit>0rule, with no searched numeric margin.',
      providers=allowed,source='development_predictions.parquet',
      rule='One side with highest existing expected-log-growth score; both primary and unchanged secondary probability exceed original purchase price;fixed20dollars, annual2000cash-only.',
      ablation='Apply the same positive-value rule to raw sports probabilities to distinguish removing the hurdle from adding market information.',
      gate='Compare2025Sharpe and positive return against original raw-sports10%hurdle on the same eligible cohort. Blended probabilities already passed the separate earlier probability gate. No2026accounts before this decision.',
      unchanged='All forecast/price observations and the previously fitted rolling model weights. No refit or threshold sweep.',app_changed=False)
    path=RESULT/'positive_value_plan.json'
    if path.exists():assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(path,plan)
    p=pd.read_parquet(RESULT/'development_predictions.parquet');p=p[p.provider.isin(allowed)]
    quotes=quote_inputs(RESULT/'positive_quote_quality.json',revision='closest_v62')
    quotes=quotes[quotes.sport.eq('nhl')&quotes.decision_utc.dt.year.le(2025)]
    annual=accounts(p,quotes,[2024,2025],'positive_development',positive_only=True)
    base=pd.read_csv(RESULT/'development_annual.csv');base=base[base.variant.eq('sports')&base.year.eq(2025)].set_index('provider')
    choices={}
    for provider,g in annual[annual.year.eq(2025)].groupby('provider'):
        g=g.set_index('variant');ref=base.loc[provider]
        choices[provider]=dict(blend_passed=bool(g.loc['blend','sharpe']>ref.sharpe and g.loc['blend','return_pct']>0),
            sports_ablation_passed=bool(g.loc['sports','sharpe']>ref.sharpe and g.loc['sports','return_pct']>0))
    dump(RESULT/'positive_value_selection.json',dict(at_utc=stamp(),choices=choices,new2026evaluation=False,adopted=False))
    print(annual[['provider','year','variant','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print(json.dumps(choices),flush=True)


def provider_diagnosis():
    """Read only earlier dates; use the same native game and forecast clocks."""
    path=RESULT/'development_paired_games.parquet'
    p=pd.read_parquet(path if path.exists() else RESULT/'development_predictions.parquet')
    a=p[p.provider.eq('polymarket')].set_index('game_id');b=p[p.provider.eq('kalshi')].set_index('game_id')
    ids=a.index.intersection(b.index)
    a=a.loc[ids];b=b.loc[ids]
    assert a.prediction_time.equals(b.prediction_time) and a.target.equals(b.target)
    assert np.allclose(a[['p0','p1']],b[['p0','p1']],atol=0,rtol=0)
    fields=['game_id','date','prediction_time','target','p1','market_p1','price0','price1','price_sum','source0','source1','age0','age1']
    cross=a.reset_index()[fields].merge(b.reset_index()[fields],on='game_id',suffixes=('_polymarket','_kalshi'),validate='one_to_one')
    cross['home_probability_difference']=cross.market_p1_polymarket-cross.market_p1_kalshi
    cross['price_sum_difference']=cross.price_sum_kalshi-cross.price_sum_polymarket
    cross.to_parquet(RESULT/'matched_provider_prices.parquet',index=False)
    scores=[]
    for provider,g in [('polymarket',a),('kalshi',b)]:
        for year,part in g.groupby(g.prediction_time.dt.year):
            for label,col in [('sports','p1'),('market','market_p1')]:
                y=part.target.to_numpy(int);pr=part[col].to_numpy()
                scores.append(dict(provider=provider,year=int(year),variant=label,games=len(part),
                    accuracy=accuracy_score(y,pr>=.5),logloss=log_loss(y,np.column_stack([1-pr,pr]),labels=[0,1]),
                    brier=brier_score_loss(y,pr),mean_price_sum=part.price_sum.mean()))
    pd.DataFrame(scores).to_csv(RESULT/'matched_provider_metrics.csv',index=False)
    dump(RESULT/'provider_comparison.json',dict(at_utc=stamp(),games=len(cross),same_forecasts_and_results=True,
      mean_absolute_normalized_home_probability_gap=float(cross.home_probability_difference.abs().mean()),
      max_absolute_normalized_home_probability_gap=float(cross.home_probability_difference.abs().max()),
      mean_kalshi_minus_polymarket_price_sum=float(cross.price_sum_difference.mean()),
      interpretation='Different source meanings: Kalshi historical YES ask closes; Polymarket token price references. Normalized prices are probability controls, not executable buy prices. Quote clocks retained; this is not an arbitrage assertion.'))
    print(pd.DataFrame(scores).to_string(index=False),flush=True)


def positive_evaluation():
    choice=json.loads((RESULT/'positive_value_selection.json').read_bytes())
    allowed=[p for p,v in choice['choices'].items() if v['sports_ablation_passed']]
    assert allowed
    plan=dict(at_utc=stamp(),selection_sha256=file_sha256(RESULT/'positive_value_selection.json'),
      selected='Raw sports probabilities with both primary and secondary indicating positive expected profit;fixed20cash-only. The blended forecast failed its strategy gate and is not evaluated here.',
      providers=allowed,comparator='Original10%relative-advantage hurdle, same paired games and fixed20stakes.',
      data='2026 saved rolling forecasts and raw-verified prices; underlying models expand from2021; no retraining or parameter changes.',
      interpretation='Retrospective rolling evaluation, not untouched OOS; chosen from2025only.')
    path=RESULT/'positive_evaluation_plan.json'
    if path.exists():assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(path,plan)
    cohort,quotes=load('evaluation');cohort=cohort[cohort.provider.isin(allowed)].copy()
    path=RESULT/'development_paired_games.parquet'
    earlier=pd.read_parquet(path if path.exists() else RESULT/'development_predictions.parquet');earlier=earlier[earlier.provider.isin(allowed)]
    fields=['p0','p1','second_p0','second_p1','price0','price1','target','prediction_time','available_time']
    idx=['provider','game_id'];pd.testing.assert_frame_equal(earlier.set_index(idx)[fields].sort_index(),cohort.set_index(idx).loc[earlier.set_index(idx).index,fields].sort_index(),check_exact=True)
    # Every evaluated row must meet the original paired-cohort readiness rule.
    cohort['fit_ready']=False
    for provider,g in cohort.groupby('provider'):
        for fold,test in g.groupby(g.prediction_time.dt.strftime('%Y-%m')):
            at=pd.Timestamp(fold+'-01',tz='UTC');past=g[g.available_time.lt(at)];counts=past.target.value_counts()
            ready=len(past)>=100 and len(counts)==2 and counts.min()>=10
            cohort.loc[test.index,'fit_ready']=ready
    data=cohort[cohort.prediction_time.dt.year.eq(2026)].copy()
    assert data.fit_ready.all()
    a=accounts(data,quotes,[2026],'positive_evaluation',positive_only=True,variants=['sports'])
    b=accounts(data,quotes,[2026],'reference_evaluation',positive_only=False,variants=['sports'])
    dump(RESULT/'positive_evaluation_validation.json',dict(status='PASS',at_utc=stamp(),providers=allowed,
      earlier_predictions_and_quotes_unchanged=len(earlier),forecast_rows=len(data),probability_model_changed=False,
      policy_frozen_before_reading_new_evaluation=True,app_changed=False,adopted=False,
      target_rows=a[a.sharpe.ge(3)&a.return_pct.gt(20)].to_dict('records')))
    print('Positive-value rule',flush=True);print(a[['provider','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print('Original10%hurdle',flush=True);print(b[['provider','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


def finish():
    from final_pipeline import cleanup,validate
    proof=json.loads((RESULT/'positive_evaluation_validation.json').read_bytes());assert proof['status']=='PASS'
    a=pd.read_parquet(RESULT/'positive_evaluation_bets.parquet');b=pd.read_parquet(RESULT/'reference_evaluation_bets.parquet')
    ix=['provider','game_id'];common=a.set_index(ix).loc[b.set_index(ix).index].sort_index();old=b.set_index(ix).sort_index()
    pd.testing.assert_frame_equal(common[['stake','price','side','profit']],old[['stake','price','side','profit']],check_exact=True)
    added=a[~a.game_id.isin(b.game_id)]
    attribution=dict(at_utc=stamp(),same_original_bets=len(old),added_bets=len(added),
        added_win_rate=float(added.won.mean()),added_profit=float(added.profit.sum()),
        added_mean_forecast=float(added.probability.mean()),added_mean_price=float(added.price.mean()),
        original_positions_exact=True,adopted=False)
    dump(RESULT/'positive_rule_attribution.json',attribution)
    # Diagnose the same added rule in earlier and later periods; these groups
    # describe errors, and do not choose a new threshold or exclude any game.
    groups=[]
    for stage,positive,reference in [('development','positive_development_bets.parquet','development_bets.parquet'),
                                     ('evaluation','positive_evaluation_bets.parquet','reference_evaluation_bets.parquet')]:
        new=pd.read_parquet(RESULT/positive);base=pd.read_parquet(RESULT/reference)
        new=new[new.provider.eq('polymarket')&new.variant.eq('sports')&new.year.ge(2025)].copy()
        base=base[base.provider.eq('polymarket')&base.variant.eq('sports')&base.year.ge(2025)].copy()
        assert set(base.game_id)<=set(new.game_id)
        expected=base.set_index('game_id').sort_index();observed=new.set_index('game_id').loc[expected.index]
        pd.testing.assert_frame_equal(expected[['stake','price','side','profit']],observed[['stake','price','side','profit']],check_exact=True)
        new['cohort']=np.where(new.game_id.isin(base.game_id),'original10percent','added_positive_only')
        new['entry_month']=pd.to_datetime(new.entry,utc=True).dt.strftime('%Y-%m')
        new['forecast_error']=new.probability-new.won.astype(float)
        new['quote_age_group']=pd.cut(new.quote_age_hours,[-1e-9,1,12,24],include_lowest=True).astype(str)
        groups.append(new.assign(stage=stage))
    diagnostics=pd.concat(groups,ignore_index=True)
    fields=dict(bets=('game_id','size'),wins=('won','sum'),win_rate=('won','mean'),profit=('profit','sum'),
        mean_probability=('probability','mean'),mean_price=('price','mean'),mean_overprediction=('forecast_error','mean'),
        median_quote_age_hours=('quote_age_hours','median'),max_quote_age_hours=('quote_age_hours','max'))
    for label,by in [('year',['year','cohort']),('month',['year','cohort','entry_month']),('quote_age',['year','cohort','quote_age_group'])]:
        diagnostics.groupby(by,observed=True).agg(**fields).reset_index().to_csv(RESULT/('loss_diagnosis_'+label+'.csv'),index=False)
    scores=pd.read_csv(RESULT/'development_metrics.csv')
    lines=['# NHL model information beyond paired market prices','',
      'This comparison uses every eligible game with both team prices before selecting a side. It removes a limitation of the earlier reliability test, whose price-only control still used outcomes chosen by the sports model.','',
      'The underlying player-strength models use expanding history from 2021. A single weight combines the sports probability with the two-price normalized market probability. Each month and provider fits that weight to all earlier settled forecast/price pairs. At least 100 earlier games and 10 of each result are required. The probability archive starts in 2024; this is not a claim of market-price coverage since 2021. Purchase prices are never normalized.','',
      '|Provider|2025 forecast|Ready games|Accuracy|Log loss|Brier|','|---|---|---:|---:|---:|---:|']
    for r in scores[scores.year.eq(2025)].itertuples():lines.append(f'|{r.provider}|{r.variant}|{r.games}|{100*r.accuracy:.2f}%|{r.logloss:.6f}|{r.brier:.6f}|')
    lines+=['',
      'Polymarket has a small improvement in probability scores with the blend. Kalshi does not beat the market-only control. The Kalshi ready comparison covers October–December 2025; it is not a full-season result. The paired-source audit also compares both providers on identical official games and forecast clocks. Kalshi uses recorded YES ask closes; Polymarket uses historical token price references. Their price sums and timestamps differ, so this is not a claim of executable cross-provider arbitrage.','',
      'Initial betting holds the existing rule fixed: both primary and independent secondary probabilities imply at least 10% return, one side selected by expected log growth, $20 stake, $2,000 annual starting cash. Shrinking probability differences while preserving the 10% hurdle removes many bets and weakens performance.','',
      'A separately frozen follow-up removes the numeric hurdle: both forecasts need only imply positive expected profit. The same rule is applied to raw sports and blended probabilities as an ablation. The raw-sports rule improved 2025 Sharpe and return; the blend did not. Only the raw-sports positive-value rule proceeded to 2026 evaluation.','',
      '|Provider|Year|Probability/rule|Bets|Win rate|Return|Sharpe|Max drawdown|','|---|---:|---|---:|---:|---:|---:|---:|']
    for file,rule in [('development_annual.csv','10% hurdle'),('positive_development_annual.csv','positive value'),('reference_evaluation_annual.csv','10% hurdle'),('positive_evaluation_annual.csv','positive value')]:
        for r in pd.read_csv(RESULT/file).query('year>=2025').itertuples():
            fmt=lambda v:'n/a' if pd.isna(v) else f'{v:.2f}'
            lines.append(f'|{r.provider}|{r.year}|{r.variant}; {rule}|{r.funded_games}|{fmt(r.win_rate_pct)}%|{fmt(r.return_pct)}%|{fmt(r.sharpe)}|{fmt(r.max_drawdown_pct)}%|')
    lines+=['',
      f"The 2026 change preserves all {len(old)} original positions exactly. It adds {len(added)} bets with {100*added.won.mean():.2f}% wins, {100*added.probability.mean():.2f}% mean forecast probability and ${added.profit.sum():.2f} net profit. Thus the weaker-edge additions reduce performance; the failure is not caused by changing the original stakes or spending unsettled cash.",'',
      'Loss diagnostics are also grouped by year, entry month and the natural hourly quote-age boundary in loss_diagnosis_year/month/quote_age.csv. Both 2025 and 2026 preserve every original fixed-stake position exactly. These are descriptive checks, not fitted filters. Forecast overprediction alone is not proof of a particular causal explanation, and average purchase price is not the exact break-even win rate for bets with different prices.','',
      'Reject the new rule. The original baseline remains. 2026 is a repeatedly inspected retrospective rolling evaluation, not an untouched holdout. No new 2026 blended-model evaluation was run. The target remains unmet.','',
      'Every source/availability clock is at or before pre12, at most 24 hours old; official IDs and team orientation are checked. Cash ledgers reconcile, original positions replay, and removing later data leaves earlier blend forecasts unchanged. No cost or spread assumptions were added. Historical reference prices do not prove executable fills. Daily account-return Sharpe annualizes by sqrt(365.25); 2026 is the available period, not a full calendar year.','',
      'Reproduce: nhl_paired_price_signal.py development, positive, diagnose, positive_evaluation, finish. The evaluation action is guarded by the earlier saved decision. Shared official source documentation is in README.md. All pair-level prices retain raw request IDs and pointers; temporary duplicate cohort files are removed after equality checks.']
    report=REPORTS/(LABEL+'.md');report.write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old_results=pd.read_csv(path,low_memory=False)
    old_results=old_results[~old_results.source_result_file.str.startswith(LABEL+'/',na=False)]
    filenames=['development_metrics.csv','development_annual.csv','positive_development_annual.csv','reference_evaluation_annual.csv','positive_evaluation_annual.csv']
    pd.concat([old_results]+[pd.read_csv(RESULT/f).assign(source_result_file=LABEL+'/'+f,sport='nhl') for f in filenames],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';decisions=json.loads(path.read_bytes())
    decisions[LABEL]=dict(plan=json.loads((RESULT/'plan.json').read_bytes()),selection=json.loads((RESULT/'selection.json').read_bytes()),
      positive_selection=json.loads((RESULT/'positive_value_selection.json').read_bytes()),evaluation=proof,adopted=False);dump(path,decisions)
    duplicate=RESULT/'development_paired_games.parquet'
    if duplicate.exists():
        raw=pd.read_parquet(duplicate);pred=pd.read_parquet(RESULT/'development_predictions.parquet')
        pd.testing.assert_frame_equal(raw.set_index(ix).sort_index(),pred.set_index(ix).loc[:,raw.set_index(ix).columns].sort_index(),check_exact=True)
        assert duplicate.resolve().is_relative_to(RESULT.resolve()) and not duplicate.is_symlink() and not duplicate.is_junction()
        duplicate.unlink()
    evalpath=RESULT/'evaluation_paired_games.parquet'
    if evalpath.exists():
        saved=pd.read_parquet(evalpath);saved=saved[saved.prediction_time.dt.year.eq(2026)]
        saved.to_parquet(evalpath,index=False)
    cleanup();app=validate()
    receipt=dict(status='PASS',at_utc=stamp(),validation=proof,app_validation=app,goal_achieved=False,adopted=False,report=str(report))
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    manifest_path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(manifest_path.read_bytes())
    m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']),latest_simulation_update=receipt);dump(manifest_path,m)
    print(json.dumps(receipt),flush=True)


def development():
    cohort,quotes=load('development');p,fits=rolling(cohort)
    prefix,_=rolling(cohort[cohort.prediction_time.lt(pd.Timestamp('2025-01-01',tz='UTC'))])
    fields=['blend_weight','blend_p1','fit_ready','price_fit_boundary','price_fit_last_label']
    key=['provider','game_id'];pd.testing.assert_frame_equal(prefix.set_index(key)[fields].sort_index(),p.set_index(key).loc[prefix.set_index(key).index,fields].sort_index(),check_exact=True)
    p.to_parquet(RESULT/'development_predictions.parquet',index=False);fits.to_csv(RESULT/'development_fits.csv',index=False)
    metrics=score(p,[2024,2025]);metrics.to_csv(RESULT/'development_metrics.csv',index=False)
    annual=accounts(p,quotes,[2024,2025],'development');choices={}
    for provider,g in metrics[metrics.year.eq(2025)].groupby('provider'):
        s=g.set_index('variant');a=annual[annual.provider.eq(provider)&annual.year.eq(2025)].set_index('variant')
        pg=bool(s.loc['blend','logloss']<min(s.loc['sports','logloss'],s.loc['market','logloss']) and s.loc['blend','brier']<s.loc['sports','brier'] and s.loc['blend','accuracy']>=.52)
        sg=bool(a.loc['blend','sharpe']>a.loc['sports','sharpe'] and a.loc['blend','return_pct']>0)
        choices[provider]=dict(probability_gate=pg,strategy_gate=sg,evaluate2026=pg and sg)
    dump(RESULT/'selection.json',dict(at_utc=stamp(),choices=choices,adopted=False))
    dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),prefix_forecasts=len(prefix),
      all_games_before_model_outcome_selection=True,original_buy_prices_preserved=True,
      quoted_forecasts=len(p),price_and_training_clocks_verified=True,parameter_count=1,
      choices=choices,new2026evaluation=False,app_changed=False))
    print(metrics.to_string(index=False),flush=True)
    print(annual[['provider','year','variant','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)
    print(json.dumps(choices),flush=True)


def evaluation():
    choice=json.loads((RESULT/'selection.json').read_bytes())
    allowed=[p for p,v in choice['choices'].items() if v['evaluate2026']]
    assert allowed,'No provider passed earlier qualification'
    cohort,quotes=load('evaluation');cohort=cohort[cohort.provider.isin(allowed)]
    p,fits=rolling(cohort)
    dev=pd.read_parquet(RESULT/'development_predictions.parquet');dev=dev[dev.provider.isin(allowed)]
    fields=['blend_weight','blend_p1','fit_ready','price_fit_boundary','price_fit_last_label']
    pd.testing.assert_frame_equal(dev.set_index(['provider','game_id'])[fields].sort_index(),p.set_index(['provider','game_id']).loc[dev.set_index(['provider','game_id']).index,fields].sort_index(),check_exact=True)
    out=p[p.prediction_time.dt.year.eq(2026)];out.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
    fits.to_csv(RESULT/'evaluation_fits.csv',index=False);metrics=score(p,[2026]);metrics.to_csv(RESULT/'evaluation_metrics.csv',index=False)
    annual=accounts(p,quotes,[2026],'evaluation')
    dump(RESULT/'evaluation_validation.json',dict(status='PASS',at_utc=stamp(),earlier_forecasts_unchanged=len(dev),
      providers=allowed,forecast_rows=len(out),classification='retrospective rolling evaluation',adopted=False))
    print(metrics.to_string(index=False),flush=True);print(annual.to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['development','evaluation','positive','diagnose','positive_evaluation','finish']);a=parser.parse_args()
    {'development':development,'evaluation':evaluation,'positive':positive_value,'diagnose':provider_diagnosis,'positive_evaluation':positive_evaluation,'finish':finish}[a.stage]()
