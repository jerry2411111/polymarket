"""Inspect current official routes before expanding goalkeeper statistics."""
import hashlib,json,re
from urllib.parse import urljoin,urlsplit
from common import ROOT_OUT,PROJECT,OfficialClient,read_db,dump,stamp

RUN=ROOT_OUT/'soccer_keeper_v81'


def main():
    RUN.mkdir(exist_ok=True);client=OfficialClient(2);sources=[];scripts=[]
    pages=[
      'https://www.bundesliga.com/en/bundesliga/stats/players/goalkeeper-saves/',
      'https://www.bundesliga.com/en/bundesliga/stats/bmf-zone/',
      'https://www.legaseriea.it/serie-a/statistiche/giocatori',
      'https://ligue1.com/en/articles/l1_article_4622-']
    for url in pages:
        OfficialClient.HOSTS.add(urlsplit(url).hostname)
        data,source=client.get(url,'Current official goalkeeper-statistic definitions and documented client routes',kind='official_keeper_documentation',document=True)
        sources.append(source)
        if data:
            text=data.decode('utf8',errors='replace')
            for src in re.findall(r'<script[^>]+src=[\"\x27]([^\"\x27]+)',text):scripts.append(dict(page=url,url=urljoin(url,src)))
            print(json.dumps(dict(page=url,status=source['return_status'],script_count=sum(x['page']==url for x in scripts))),flush=True)
    d,s=client.get('https://compstats.uefa.com/v2/definitions','Current UEFA goalkeeper statistic definitions',kind='official_keeper_definitions');sources.append(s)
    if d:dump(RUN/'uefa_keeper_definitions.json',[r for r in d if re.search('save|goal.*conced|keeper',r['name'],re.I)])
    # REST shallow inspection returns only child names, not a broad data dump.
    records=[]
    with read_db(ROOT_OUT/'soccer_additional.sqlite') as db:
        allrecords=[json.loads(row[0]) for row in db.execute("SELECT body FROM games WHERE league='Bundesliga'")]
    for year in [2021,2024,2026]:
        choices=sorted([r for r in allrecords if r['date'].startswith(str(year))],key=lambda r:r['date'])
        if not choices:continue
        r=choices[len(choices)//2];src=next(s for s in r['sources'] if '/stats.json' in s['url'])
        url=src['url'].rsplit('/',1)[0]+'.json?shallow=true'
        data,s=client.get(url,'Official Bundesliga match branch names for historical goalkeeper route discovery: '+r['game_id'],kind='official_keeper_route_discovery')
        sources.append(s);records.append(dict(game_id=r['game_id'],date=r['date'],source=s,branch_names=list(data) if isinstance(data,dict) else data))
        print(json.dumps(records[-1]),flush=True)
    dump(RUN/'current_official_route_discovery.json',dict(at_utc=stamp(),sources=sources,scripts=scripts,bundesliga_match_branches=records))


if __name__=='__main__':main()
