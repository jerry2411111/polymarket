"""Official date-indexed squad announcements; revised pages are not backdated.

Real Madrid exposes the squad text through its anonymous public content API.
The article's revision timestamp is absent there, so use the official page's
structured NewsArticle solely to obtain that necessary clock.
"""
import argparse
import concurrent.futures
import hashlib
import html
import json
import re
import sqlite3
import unicodedata
from urllib.parse import quote,urlencode
import pandas as pd
from common import ROOT_OUT,PROJECT,PREVIOUS,OfficialClient,read_db,dump,stamp,file_sha256

LABEL='soccer_squad_availability'
WORK=ROOT_OUT/'_work'/LABEL
RESULT=ROOT_OUT/'simulation_results'/LABEL
ARCHIVE='https://publish.realmadrid.com/content/sling/app-servlets/realmadrid/news-filter.json?lang=es-es&offset={}&limit=18&tags=realmadrid-com:noticias/futbol/primer-equipo/convocatorias'
DETAIL='https://publish.realmadrid.com/graphql/execute.json/realmadridmastersite/newsByPath%3Bpath='
PUBLIC='https://www.realmadrid.com/es-ES/noticias/futbol/primer-equipo/convocatorias/'


def client():
    OfficialClient.HOSTS.update({'publish.realmadrid.com','www.realmadrid.com'})
    return OfficialClient(per_second=2)


def archive():
    WORK.mkdir(parents=True,exist_ok=True);RESULT.mkdir(exist_ok=True)
    if (WORK/'archive.json').exists():return json.loads((WORK/'archive.json').read_bytes())
    c=client();rows=[];sources=[];total=None
    for offset in range(0,1800,18):
        doc,src=c.get(ARCHIVE.format(offset),'Enumerate complete official first-team squad archive; no outcome selection','official_squad_archive')
        assert doc is not None,src['return_status']
        part=doc['data']['page'];total=part['totalCount'] if total is None else total
        assert total==part['totalCount'],'Archive changed during pagination; inspect instead of silently losing rows'
        sources.append(src)
        for i,r in enumerate(part['item']):rows.append(r|dict(archive_source=src,archive_pointer=f'/data/page/item/{i}'))
        if len(rows)>=total:break
        assert len(part['item'])>0
    assert len(rows)==total and len({r['path'] for r in rows})==len(rows)
    out=dict(source='All official first-team squad-tag archive pages, independently of games, forecasts or outcomes',rows=rows,sources=sources,total=total)
    dump(WORK/'archive.json',out);return out


def key(text):
    return re.sub('[^a-z0-9 ]','',unicodedata.normalize('NFKD',text).encode('ascii','ignore').decode().lower())


def parse(item,blob,source,page_source):
    assert source['return_status']=='200' and page_source['return_status']=='200'
    page=blob.decode('utf8');pub=re.findall(r'"datePublished"\s*:\s*"([^"]+)"',page)
    mod=re.findall(r'"dateModified"\s*:\s*"([^"]+)"',page)
    published=pd.Timestamp(item['date']);assert published.tzinfo is not None
    modified=None
    if len(set(pub))!=1 or len(set(mod))!=1:clock_status='public_route_has_no_unique_article_clock'
    elif pd.Timestamp(pub[0])!=published:clock_status='reused_slug_resolves_to_different_publication'
    else:
        modified=pd.Timestamp(mod[0]);assert modified.tzinfo is not None
        clock_status='exact_publication_clock_matched'
    # Parse the exact named position sections; do not split abbreviations at
    # periods or turn unrelated prose into player records.
    source_text='\n'.join(html.unescape(x['plaintext']) for x in item['bodyList'])
    positions=list(re.finditer(r'(Porteros|Defensas|Centrocampistas|Delanteros)\s*:',source_text,re.I))
    if len(positions)!=4:raise ValueError(('position_sections',item['slug'],source_text))
    rows=[];sections=[]
    for i,m in enumerate(positions):
        end=positions[i+1].start() if i+1<len(positions) else len(source_text)
        raw=source_text[m.end():end].strip().split('\n\n')[0].strip()
        # Some bodies append a promotional paragraph directly after a single
        # newline. The first section line is the actual comma-separated list.
        raw=raw.split('\n')[0].strip().rstrip('.')
        names=[re.sub(r'^(?:y|e)\s+','',s.strip()) for s in re.split(r',\s*|\s+(?:y|e)\s+',raw) if s.strip()]
        if not names or any(len(n.split())>5 for n in names):raise ValueError(('names',item['slug'],raw))
        sections.append(dict(position_group=m[1].lower(),source_group_text=raw))
        for index,name in enumerate(names,1):
            rows.append(dict(position_group=m[1].lower(),source_player_index=index,player_name_raw=name,source_group_text=raw))
    assert 15<=len(rows)<=35,('squad_size',item['slug'],len(rows))
    assert len({key(r['player_name_raw']) for r in rows})==len(rows)
    return dict(title=item['title'],source_path=item['_path'],slug=item['slug'],
        published_at_utc=published.isoformat(),modified_at_utc=modified.isoformat() if modified is not None else None,
        available_after_utc=max(published,modified).isoformat() if modified is not None else None,
        clock_status=clock_status,squad_count=len(rows),
        sections_json=json.dumps(sections,ensure_ascii=False),body_text=source_text),rows


def fetch(row,c,repair=False):
    report_id='RMA_'+hashlib.sha256(row['path'].encode()).hexdigest()[:20]
    record=WORK/(report_id+'.json')
    if record.exists() and not repair:return json.loads(record.read_bytes())
    doc,src=c.get(DETAIL+quote(row['path'],safe='/'),'Dated official Real Madrid squad announcement '+row['date'],'official_squad_article')
    page,page_src=c.get(PUBLIC+row['slug'],'Article revision clock absent from squad content API '+row['date'],'official_squad_publication_clock',document=True)
    out=dict(report_id=report_id,archive=row,api_source=src,page_source=page_src)
    try:
        assert doc is not None and page is not None,(src['return_status'],page_src['return_status'])
        item=doc['data']['news']['item'];assert item['_path']==row['path'] and item['slug']==row['slug']
        metadata,players=parse(item,page,src,page_src)
        out.update(metadata=metadata,players=players,status='parsed')
    except Exception as exc:out.update(status='requires_repair',error=repr(exc))
    dump(record,out);return out


def collect(repair=False):
    data=archive();RESULT.mkdir(exist_ok=True)
    chosen=[r for r in data['rows'] if '2021-01-01'<=r['date']<='2026-10-03']
    plan=dict(at_utc=stamp(),scope='Every official Real Madrid first-team squad-tag article dated2021-01-01through2026-10-03; no outcome or market filtering.',
        archive_total=data['total'],requested=len(chosen),api_insufficiency='Official article API supplies roster and precise publication but omits modification time. Official public NewsArticle structured markup supplies this required clock only.',
        availability='max(publication,modification); never use a later-revised page at its initial publication time.',
        output='Announced travelling/called-up squad, not starting XI or guaranteed fitness. Unmatched player names are not invented native IDs.',
        source_policy='Only official club endpoints and official public pages. Two anonymous requests per article; raw-first, rate-limited, retrying, resumable.',
        intended_feature='Share of prior player contribution absent from complete announced squad; train only after systematic identity and time validation, not on selectively chosen losses.')
    dump(RESULT/'collection_plan.json',plan)
    completed=[];c=client();threshold=10
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        futures=[executor.submit(fetch,row,c,repair) for row in chosen]
        for future in concurrent.futures.as_completed(futures):
            completed.append(future.result());pct=100*len(completed)/len(chosen)
            if pct>=threshold or len(completed)==len(chosen):
                progress=dict(at_utc=stamp(),complete=len(completed),total=len(chosen),percent=round(pct,1),
                    repairs=sum(r['status']!='parsed' for r in completed))
                dump(RESULT/'collection_progress.json',progress);print(json.dumps(progress),flush=True)
                threshold+=10
    failures=[dict(report_id=r['report_id'],date=r['archive']['date'],error=r['error']) for r in completed if r['status']!='parsed']
    dump(RESULT/'repair_queue.json',failures)
    print(json.dumps(dict(stage='collection_finished',reports=len(completed),parsed=len(completed)-len(failures),repairs=len(failures))),flush=True)


def normalized():
    data=archive();records=[json.loads((WORK/('RMA_'+hashlib.sha256(r['path'].encode()).hexdigest()[:20]+'.json')).read_bytes()) for r in data['rows'] if '2021-01-01'<=r['date']<='2026-10-03']
    assert all(r['status']=='parsed' for r in records),'Repair every downloaded parser failure before publication'
    reports=[];players=[]
    for record in records:
        meta=record['metadata'];src=record['api_source'];page=record['page_source'];archive_src=record['archive']['archive_source']
        for s in [src,page,archive_src]:assert file_sha256(PROJECT/s['raw_file'])==s['sha256']
        item=json.loads((PROJECT/src['raw_file']).read_bytes())['data']['news']['item']
        replay,people=parse(item,(PROJECT/page['raw_file']).read_bytes(),src,page)
        assert replay==meta and people==record['players']
        report_id=record['report_id']
        reports.append(dict(report_id=report_id,provider='official_real_madrid',team_name='Real Madrid C.F.',
            uefa_club_id='50051',**meta,public_url=PUBLIC+meta['slug'],
            source_json=json.dumps(dict(api=src,page_clock=page,archive=archive_src),sort_keys=True),
            api_request_number=src['request_number'],page_request_number=page['request_number'],
            retrieved_at_utc=src['retrieved_at_utc']))
        for r in people:players.append(dict(report_id=report_id,**r))
    lfc_index=WORK/'lfc_archive.json'
    if lfc_index.exists():
        for article in json.loads(lfc_index.read_bytes())['rows']:
            record_path=WORK/('LFC_'+str(article['id'])+'.json')
            if not record_path.exists():raise ValueError('Finish every Liverpool article before combined publication')
            record=json.loads(record_path.read_bytes());assert record['status']!='requires_repair'
            src=record['api_source'];assert file_sha256(PROJECT/src['raw_file'])==src['sha256']
            parsed,status=parse_lfc(json.loads((PROJECT/src['raw_file']).read_bytes()))
            assert status==record['status'] and parsed==record['metadata']
            if parsed is None:continue
            names=parsed['names'];report_id=parsed['report_id']
            meta={k:parsed[k] for k in ['title','slug','published_at_utc','modified_at_utc','available_after_utc','squad_count','body_text','public_url']}
            reports.append(dict(report_id=report_id,provider='official_liverpool',team_name='Liverpool F.C.',uefa_club_id='7889',
                source_path='/news/'+str(article['id']),clock_status='native_article_publication_and_update',
                sections_json=json.dumps([dict(position_group=None,source_group_text=parsed['source_group_text'],source_pointer=parsed['source_pointer'])]),
                **meta,source_json=json.dumps(dict(api=src,archive=article['archive_source']),sort_keys=True),
                api_request_number=src['request_number'],page_request_number=None,retrieved_at_utc=src['retrieved_at_utc']))
            for i,name in enumerate(names,1):
                players.append(dict(report_id=report_id,position_group=None,source_player_index=i,player_name_raw=name,source_group_text=parsed['source_group_text']))
    return pd.DataFrame(reports),pd.DataFrame(players)


def lfc_archive():
    """Competition-tag pagination, not searches restricted to losing games."""
    WORK.mkdir(exist_ok=True);RESULT.mkdir(exist_ok=True);c=client();c.timeout_seconds=90;OfficialClient.HOSTS.add('backend.liverpoolfc.com')
    articles={};sources=[];bounds=[]
    for tag in ['Champions League','Europa League']:
        tag_rows=[];seen=set();completed=False;offset=0;size=100;requests=0
        while offset<10000:
            page=offset//size+1
            url='https://backend.liverpoolfc.com/lfc-rest-api/news?'+urlencode(dict(currentPage=page,perPage=size,tags=tag))
            doc,src=c.get(url,'Systematic Liverpool '+tag+' news index before collecting dated squads','official_squad_archive')
            sources.append(src);requests+=1
            if doc is None:
                if src['return_status']=='204':
                    # The club reports a nominal5000 count even when this
                    # filtered archive has ended. Explicit HTTP204 is an
                    # observed empty page, not a failed retrieval.
                    batch=[];completed=True;break
                dump(WORK/'lfc_retrieval_progress.json',dict(at_utc=stamp(),tag=tag,offset=offset,page_size=size,
                    status='retry_with_smaller_page' if size>20 else 'pending_retrieval_repair',sources=sources))
                if size==100:
                    size=20;continue
                raise RuntimeError(('lfc_archive_request_failed_not_missing',tag,offset,src['return_status']))
            assert doc['currentPage']==page and doc['perPage']==size
            batch=doc['results'];ids={x['id'] for x in batch}
            assert not seen&ids,'Unstable news pagination; reconcile repeated IDs before proceeding'
            seen|=ids
            for i,r in enumerate(batch):
                if pd.Timestamp(r['publishedAt'])>=pd.Timestamp('2021-01-01',tz='UTC'):
                    entry=r|dict(archive_source=src,archive_pointer=f'/results/{i}',competition_tag=tag)
                    tag_rows.append(entry);articles[r['id']]=entry
            print(json.dumps(dict(stage='lfc_archive',tag=tag,page=page,page_size=size,eligible_news=len(tag_rows),
                oldest_date=min((x['publishedAt'] for x in batch),default=None))),flush=True)
            if not batch or max(pd.Timestamp(x['publishedAt']) for x in batch)<pd.Timestamp('2021-01-01',tz='UTC') or page>=doc['totalPages']:
                completed=True;break
            # Page numbers advance by the requested page size even if the
            # final page is short; using its returned length repeats that page.
            offset+=size
        assert completed
        bounds.append(dict(tag=tag,requests=requests,news=len(tag_rows),
            oldest_available_publication=min((x['publishedAt'] for x in tag_rows),default=None),
            official_archive_exhausted=bool(not batch),
            reached_requested_2021_boundary=bool(batch and max(pd.Timestamp(x['publishedAt']) for x in batch)<pd.Timestamp('2021-01-01',tz='UTC'))))
    candidates=[a for a in articles.values() if 'squad' in a['title'].lower() and not re.search(r'women|u18|u19|u21|youth',a['title'],re.I)]
    dump(WORK/'lfc_archive.json',dict(rows=candidates,sources=sources,bounds=bounds,all_news_count=len(articles),
        selection='Every non-youth/non-women title containing squad in the complete two European-competition tag windows. Bodies will distinguish specific travelling squads from season registrations, interviews or galleries. No scores or model losses consulted.'))
    print(json.dumps(dict(stage='lfc_candidates',articles=len(candidates),total_news=len(articles),bounds=bounds)),flush=True)


def link_calendar(reports):
    """Conservative club + opponent text + unique upcoming official fixture."""
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games=pd.read_sql_query("SELECT game_id,official_game_id,league,date,start_time,prediction_time,teamA,teamB,native_team_ids_json FROM soccer_games WHERE date>='2021-01-01'",db)
    for col in ['start_time','prediction_time']:games[col]=pd.to_datetime(games[col],utc=True)
    club_map={'official_real_madrid':{'La Liga':'15','UEFA Champions League':'50051'},
              'official_liverpool':{'Premier League':'14','UEFA Champions League':'7889'}}
    calendars={provider:games[games.apply(lambda g:g.league in clubs and clubs[g.league] in list(map(str,json.loads(g.native_team_ids_json))),axis=1)]
               for provider,clubs in club_map.items()}
    rows=[]
    stop={'real','club','deportivo','sociedad','futbol','football','sport','de','la','fc','cf','sad','04'}
    for r in reports.itertuples():
        clubs=club_map[r.provider];calendar=calendars[r.provider]
        published=pd.Timestamp(r.published_at_utc)
        possible=calendar[calendar.start_time.ge(published)&calendar.start_time.le(published+pd.Timedelta(days=3))]
        tags=[]
        if r.provider=='official_liverpool':
            source=json.loads(r.source_json)['api']
            tags=json.loads((PROJECT/source['raw_file']).read_bytes()).get('tags',[])
        text=key(r.title+' '+r.body_text+' '+' '.join(tags));hits=[]
        for g in possible.itertuples():
            ids=list(map(str,json.loads(g.native_team_ids_json)));club=clubs[g.league]
            side='A' if ids[0]==club else 'B';opponent=g.teamB if side=='A' else g.teamA
            terms={w for w in key(opponent).split() if len(w)>=4 and w not in stop}
            shared=sorted(w for w in terms if re.search(r'\b'+re.escape(w)+r'\b',text))
            if shared:hits.append((g,side,opponent,shared))
        link=dict(report_id=r.report_id,game_id=None,official_game_id=None,league=None,side=None,
            prediction_time=None,game_start_time=None,available_by_pre12=False,
            game_match_status='no_unique_tracked_fixture_with_matching_opponent',matching_evidence=None)
        if len(hits)==1:
            g,side,opponent,shared=hits[0]
            available=pd.Timestamp(r.available_after_utc) if r.available_after_utc else None
            link.update(game_id=g.game_id,official_game_id=str(g.official_game_id),league=g.league,side=side,
                prediction_time=g.prediction_time.isoformat(),game_start_time=g.start_time.isoformat(),
                available_by_pre12=available is not None and available<=g.prediction_time,
                game_match_status='unique_club_calendar_and_opponent_text',
                matching_evidence=json.dumps(dict(opponent=opponent,matched_terms=shared,native_article_tags=tags,
                    method='Official native club ID, publication before scheduled match within72h, unique opponent-name match. Other competitions remain unlinked.'),ensure_ascii=False))
        rows.append(link)
    links=pd.DataFrame(rows)
    return reports.merge(links,on='report_id',validate='one_to_one')


def parse_lfc(document):
    """Only article text supplies squad facts; live fixture widgets excluded."""
    blocks=[(i,b.get('formattedText','')) for i,b in enumerate(document['blocks']) if b.get('type')=='formattedText']
    named=[]
    for block_index,body in blocks:
        # Preserve paragraph boundaries, then read only explicit squad labels.
        paragraphs=re.findall(r'<p[^>]*>(.*?)</p>',body,re.S)
        for paragraph_index,p in enumerate(paragraphs):
            text=html.unescape(re.sub(r'<[^>]+>',' ',p));text=' '.join(text.split())
            m=re.match(r"(?:Travelling Liverpool squad|Liverpool(?:'s)? (?:travelling )?squad(?: for PSG)?|Travelling squad)\s*:\s*(.+)",text,re.I)
            if not m:continue
            section=m[1].strip().rstrip('.')
            names=[re.sub(r'^and\s+','',s.strip()) for s in re.split(r',\s*|\s+and\s+',section) if s.strip()]
            if not 16<=len(names)<=35 or any(len(n.split())>5 for n in names):
                raise ValueError(('ambiguous_squad_list',document['slug'],section))
            assert len(set(map(key,names)))==len(names)
            named.append(dict(block_index=block_index,paragraph_index=paragraph_index,names=names,source_group_text=section))
    if not named:return None,'article_does_not_contain_supported_complete_named_match_squad'
    if len(named)!=1:raise ValueError(('multiple_named_lists_require_review',document['slug']))
    found=named[0]
    count=re.search(r'(\d+)[- ]man squad',document['title'],re.I)
    if count:assert len(found['names'])==int(count[1]),('announced_count',document['slug'])
    published=pd.Timestamp(document['publishedAt']);modified=pd.Timestamp(document['updatedAt'])
    assert published.tzinfo and modified.tzinfo
    return dict(report_id='LFC_'+str(document['id']),title=document['title'],slug=document['slug'],
        published_at_utc=published.isoformat(),modified_at_utc=modified.isoformat(),
        available_after_utc=max(published,modified).isoformat(),squad_count=len(found['names']),
        source_pointer='/blocks/'+str(found['block_index'])+'/formattedText',
        source_paragraph_index=found['paragraph_index'],source_group_text=found['source_group_text'],
        names=found['names'],body_text='\n'.join(html.unescape(re.sub('<[^>]+>',' ',b)) for _,b in blocks),
        public_url='https://www.liverpoolfc.com/news/'+document['slug']), 'parsed'


def lfc_collect(repair=False):
    archive_data=json.loads((WORK/'lfc_archive.json').read_bytes());c=client();OfficialClient.HOSTS.add('backend.liverpoolfc.com')
    results=[];threshold=10
    for a in sorted(archive_data['rows'],key=lambda r:(r['publishedAt'],r['id'])):
        path=WORK/('LFC_'+str(a['id'])+'.json')
        if path.exists() and not repair:results.append(json.loads(path.read_bytes()));continue
        d,src=c.get('https://backend.liverpoolfc.com/lfc-rest-api/news/'+quote(a['slug'],safe=''),
            'Dated Liverpool squad candidate discovered from complete competition news index','official_squad_article')
        r=dict(archive=a,api_source=src)
        try:
            assert d is not None,src['return_status'];assert d['id']==a['id']
            parsed,status=parse_lfc(d);r.update(status=status,metadata=parsed)
            if parsed:
                # Poison future-changing fixture widgets and prove no effect.
                import copy
                mutated=copy.deepcopy(d)
                for b in mutated['blocks']:
                    if b.get('type')!='formattedText':b.clear();b.update(type='future_data_removed')
                assert parse_lfc(mutated)==(parsed,status)
        except Exception as exc:r.update(status='requires_repair',error=repr(exc))
        dump(path,r);results.append(r)
        pct=100*len(results)/len(archive_data['rows'])
        if pct>=threshold or len(results)==len(archive_data['rows']):
            print(json.dumps(dict(stage='lfc_squad_articles',complete=len(results),total=len(archive_data['rows']),percent=round(pct,1))),flush=True);threshold+=10
    dump(RESULT/'lfc_collection_status.json',dict(at_utc=stamp(),candidates=len(results),
        status_counts=pd.Series([r['status'] for r in results]).value_counts().to_dict(),
        index_bounds=archive_data['bounds'],future_fixture_fields_excluded=True))
    print(json.dumps(dict(stage='lfc_collection_finished',status_counts=pd.Series([r['status'] for r in results]).value_counts().to_dict())),flush=True)


def publish():
    reports,players=normalized();reports=link_calendar(reports)
    meanings={
        'report_id':('Stable official native article ID or hash of unique content path; reused slugs stay separate','identifier'),
        'provider':('Official club publishing the announcement','category'),
        'team_name':('Full official club name','text'),
        'uefa_club_id':('Native UEFA club identifier; static identity, not a forecast','identifier'),
        'title':('Original announcement title','text'),
        'source_path':('Native content path uniquely identifying this dated announcement','path'),
        'slug':('Official URL slug; may be reused across years and is not a primary key','text'),
        'published_at_utc':('Exact initial article publication returned by the content API','UTC timestamp'),
        'modified_at_utc':('Native article update time; Madrid uses the official page only when its publication exactly matches the API article','UTC timestamp'),
        'available_after_utc':('Conservative forecast eligibility clock: later of verified publication and revision; null if revision identity unverified','UTC timestamp'),
        'clock_status':('Whether the public revision clock belongs to this exact article or a reused/empty route','category'),
        'squad_count':('Number of explicitly named called-up players; not confirmed starters','players'),
        'sections_json':('Original named position sections, preserved for parser replay','JSON'),
        'body_text':('Official squad article text from API, preserving announced names and context','text'),
        'public_url':('Official public page; reused routes are disclosed by clock_status','URL'),
        'source_json':('Exact API, page-clock and archive request provenance with raw paths and hashes','JSON'),
        'api_request_number':('Request number for the original squad API response','identifier'),
        'page_request_number':('Request number for official revision-clock page','identifier'),
        'retrieved_at_utc':('Acquisition time; distinct from historical publication/availability','UTC timestamp'),
        'game_id':('Matched collected game ID, only with unique club/date/opponent evidence','identifier'),
        'official_game_id':('Native league match ID from the linked official calendar','identifier'),
        'league':('Actual competition of the linked collected match','category'),
        'side':('A or B in the linked game table','category'),
        'prediction_time':('Pre-12 decision cutoff for the matched collected game','UTC timestamp'),
        'game_start_time':('Official recorded start of the linked game','UTC timestamp'),
        'available_by_pre12':('True only when a verified article version was available by the matched pre-12 cutoff','boolean'),
        'game_match_status':('Explicit result of conservative official-calendar matching','category'),
        'matching_evidence':('Opponent tokens and unique native-club/calendar conditions used to link the article','JSON'),
        'position_group':('Position group printed by the official club','category'),
        'source_player_index':('Player ordinal within that original position group','integer'),
        'player_name_raw':('Announced name/abbreviation after list punctuation and coordinating-word removal; source_group_text preserves original list. Not a cross-provider identity','text'),
        'source_group_text':('Complete original group text supporting the player parsing','text')}
    frames={'soccer_squad_reports':reports,'soccer_squad_report_players':players};checks=[]
    assert not reports.report_id.duplicated().any() and set(players.report_id)==set(reports.report_id)
    assert players.groupby('report_id').size().sort_index().equals(reports.set_index('report_id').squad_count.sort_index())
    source='Official club APIs: publish.realmadrid.com and backend.liverpoolfc.com. Madrid public NewsArticle supplies its API-missing revision clock only. Per-row source_json records direct publisher, raw response, request and hash.'
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        for table,frame in frames.items():
            assert set(frame).issubset(meanings)
            frame.to_parquet(ROOT_OUT/(table+'.parquet'),index=False);frame.to_csv(ROOT_OUT/(table+'.csv'),index=False)
            frame.to_sql(table,db,if_exists='replace',index=False)
            db.execute('CREATE INDEX IF NOT EXISTS '+table+'_report ON '+table+'(report_id)')
            for cat in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+cat+' WHERE "table"=?',(table,))
            db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(table,len(frame),len(frame.columns)))
            for col in frame:
                db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(table,col,*meanings[col],source))
                db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(table,col,len(frame),int(frame[col].isna().sum()),float(100*frame[col].isna().mean())))
            replay=pd.read_sql_query('SELECT * FROM '+table,db);pd.testing.assert_frame_equal(frame,replay,check_dtype=False)
            checks.append(dict(table=table,rows=len(frame),columns=len(frame.columns),sha256=file_sha256(ROOT_OUT/(table+'.parquet'))))
    unknown=reports.modified_at_utc.isna();linked=reports.game_id.notna();late=linked&~unknown&~reports.available_by_pre12
    summary=dict(status='PASS',at_utc=stamp(),tables=checks,raw_api_replayed=len(reports),source_player_rows_replayed=len(players),
        earliest_publication=reports.published_at_utc.min(),latest_publication=reports.published_at_utc.max(),
        unknown_revision_clocks=int(unknown.sum()),unknown_revision_pct=float(100*unknown.mean()),
        linked_tracked_games=int(linked.sum()),pre12_eligible_reports=int(reports.available_by_pre12.sum()),
        linked_later_revised_or_late_publications=int(late.sum()),
        clock_status=reports.clock_status.value_counts().to_dict(),
        limitation='Every parsed article raw-replayed. Unknown article revision clocks remain unknown eligibility. Liverpool API tagged archive begins August2021; Europa tag returns204 and is not claimed as full Europa coverage. Unrelated interviews, galleries and season registration articles are excluded from match squads, with status retained. No starting-XI inference.',
        false_imputed_availability=False,model_changed=False,app_changed=False)
    dump(RESULT/'validation.json',summary)
    year=reports.assign(year=reports.published_at_utc.str[:4]).groupby('year').agg(reports=('report_id','size'),
        known_revision_clocks=('modified_at_utc','count'),matched_games=('game_id','count'),pre12_eligible=('available_by_pre12','sum')).reset_index()
    year.to_csv(RESULT/'yearly_coverage.csv',index=False)
    from publish import main
    main();print(json.dumps(summary),flush=True)


def document():
    """Publish current source coverage, aliases and reproducible archive bounds."""
    from common import REPORTS
    from publish import main as catalog
    proof=json.loads((RESULT/'validation.json').read_bytes());assert proof['status']=='PASS'
    reports=pd.read_parquet(ROOT_OUT/'soccer_squad_reports.parquet')
    for table in proof['tables']:assert table['sha256']==file_sha256(ROOT_OUT/(table['table']+'.parquet'))
    coverage=reports.groupby('provider').agg(reports=('report_id','size'),players=('squad_count','sum'),matched=('game_id','count'),eligible_pre12=('available_by_pre12','sum')).reset_index()
    lf=json.loads((WORK/'lfc_archive.json').read_bytes())
    classifications=[]
    for row in lf['rows']:
        record=json.loads((WORK/('LFC_'+str(row['id'])+'.json')).read_bytes())
        classifications.append(dict(article_id=row['id'],title=row['title'],published_at=row['publishedAt'],status=record['status'],api_source=record['api_source'],archive_source=row['archive_source']))
    manifest=dict(at_utc=stamp(),madrid_archive_sources=archive()['sources'],liverpool_index_sources=lf['sources'],
        liverpool_bounds=lf['bounds'],liverpool_articles=classifications,
        scope='Outcome-independent official club archives. Liverpool tagged API has no entries before August2021 and no Europa entries; this is observed endpoint coverage, not proof that all older club articles are unattainable.')
    dump(RESULT/'collection_manifest.json',manifest)
    lines=['# Dated soccer squad announcements','',
        'These two SQL tables store complete announced match squads, their publication/revision clocks, player names and original source evidence. They support dated player-availability research. A called-up squad is not a confirmed starting XI.','',
        '`soccer_squad_reports` contains one dated announcement: native article identity, club, original title/text, source clocks and requests, player count and the linked official fixture where unambiguous. `soccer_squad_report_players` contains the names/position sections in those announcements, joined by report_id. The SQL catalog supplies every column meaning, unit, source and missing percentage.','',
        '| Official publisher | Reports | Player entries | Linked games | Eligible by pre-12 |',
        '| --- | ---: | ---: | ---: | ---: |']
    lines += ['| '+' | '.join(map(str,row))+' |' for row in coverage.itertuples(index=False,name=None)]
    lines += ['',
        f"All {len(reports)} reports and {int(reports.squad_count.sum())} player entries were replayed from original hashed responses and compared with SQL/Parquet outputs. Unknown revision clocks: {proof['unknown_revision_clocks']}/{len(reports)} ({proof['unknown_revision_pct']:.6f}%). The squad bodies themselves were acquired. Unknown clocks cannot establish earlier forecast eligibility.",'',
        'Madrid uses its unique content path because public slugs can repeat across years. The content API omits revision time, so the official public NewsArticle clock is accepted only when its publication exactly matches the path-specific API article. Later revisions are not backdated. Liverpool supplies native article IDs and both clocks directly in its API. Future-changing fixture widgets in Liverpool articles are excluded; removing those widgets leaves the parsed squad unchanged.','',
        'The Liverpool index returned 1,127 Champions League news entries; all 32 squad-title candidates were inspected, yielding 11 complete travelling squads. Other candidates contain interviews, galleries, registration lists or the opposing club squad and are explicitly classified. The tagged index ends in August2021; the Europa tag returns HTTP204. Those are documented archive limits, not a claim that Liverpool has no older or Europa reports.','',
        'Native club identity, a unique upcoming official fixture within72hours and opponent text/native article tags link games. Tags resolve Inter/Internazionale without inventing a club alias. Only a publication and verified last revision at or before the pre12 decision permit a model adjustment.','',
        'A date-specific query:', '', '```sql',
        'SELECT r.report_id, r.team_name, r.available_after_utc, p.player_name_raw',
        'FROM soccer_squad_reports r JOIN soccer_squad_report_players p USING (report_id)',
        'WHERE r.game_id = :game_id',
        'AND julianday(r.available_after_utc) <= julianday(:query_utc);','```','',
        'Reproduce source publication with collect_soccer_squads.py stages archive, collect, lfc_archive, lfc_collect, publish, document. --repair reparses cached original bodies. The normalized and raw data, acquisition SQLite log and collection_manifest.json are retained; temporary article caches can be reconstructed and removed after publication.','',
        'Official current interface evidence: https://www.realmadrid.com/es-ES/noticias/futbol/primer-equipo/convocatorias?page=0 ; https://www.realmadrid.com/main-RXZLFXFW.js ; https://www.liverpoolfc.com/news . Their public browser clients document the requests used. Exact script/source URLs and hashes are recorded in retention/soccer_squad_source_discovery.json. These website services are not guaranteed stable developer APIs.','',
        'Madrid index: https://publish.realmadrid.com/content/sling/app-servlets/realmadrid/news-filter.json using lang,offset,limit,tags. Detail: https://publish.realmadrid.com/graphql/execute.json/realmadridmastersite/newsByPath%3Bpath= followed by the unique native path. Liverpool index: https://backend.liverpoolfc.com/lfc-rest-api/news using currentPage,perPage,tags; article: /news/{slug}.','',
        'AEM metadata documentation read: https://experienceleague.adobe.com/en/docs/experience-manager-cloud-service/content/headless/graphql-api/graphql-endpoint and https://experienceleague.adobe.com/en/docs/experience-manager-cloud-service/content/headless/graphql-api/sample-queries . The club generic metadata route returned404. The original request/response is retained; missing clocks are not fabricated.','',
        'The separate soccer_squad_model experiment tests reweighting recent-player inputs. Its report contains probability and account results when complete. Source collection alone is not evidence of improved returns. NBA/MLB app files are unchanged.','']
    report=REPORTS/(LABEL+'.md');report.write_text('\n'.join(lines),encoding='utf8')
    catalog();print(json.dumps(dict(status='PASS',report=str(report),source_reports=len(reports))),flush=True)


if __name__=='__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf8')
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['archive','collect','lfc_archive','lfc_collect','publish','document']);parser.add_argument('--repair',action='store_true');args=parser.parse_args()
    globals()[args.stage](args.repair) if args.stage in ['collect','lfc_collect'] else globals()[args.stage]()
