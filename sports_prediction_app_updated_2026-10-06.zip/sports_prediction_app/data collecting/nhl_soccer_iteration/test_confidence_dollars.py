"""User-specified $20 per probability point above51%, using frozen NBA/MLB fits.

No model fitting or parameter search. Source databases are read-only. Keep the
literal available-cash rule separate from an existing20% exposure-cap comparison.
"""
import collections
import json
import math
import sqlite3
import numpy as np
import pandas as pd
from common import PROJECT, ROOT_OUT, dump, stamp, file_sha256, read_db
from final_pipeline import cleanup

FINAL = PROJECT/'final_models'
RESULT = ROOT_OUT/'simulation_results/nba_mlb_confidence_dollars'
END = pd.Timestamp('2026-09-30', tz='UTC')


def dates(x):
    return pd.to_datetime(x, utc=True, format='mixed')


def inputs():
    all_inputs, coverage, exclusions, proofs = [], [], [], {}
    with read_db(FINAL/'nba/backtest.sqlite') as db:
        nba = pd.read_sql_query("SELECT * FROM entry_candidates WHERE version='repaired_v21'", db)
        fits = pd.read_sql_query('SELECT * FROM folds', db)
    pred = pd.read_parquet(FINAL/'nba/predictions.parquet')
    indexed = nba.set_index('game_id').loc[pred.game_id]
    assert np.allclose(indexed[['p0','p1']], pred[['p0','p1']], rtol=0, atol=1e-14)
    assert np.array_equal(indexed.target, pred.target)
    for _, rows in fits.groupby('fit_id'):
        # The same dated training membership is reused at later forecast times.
        # Only cutoff differs; counts, temperature and label boundaries must agree.
        assert rows.drop(columns='cutoff_utc').drop_duplicates().shape[0] == 1
    fits = fits.sort_values('cutoff_utc').drop_duplicates('fit_id').set_index('fit_id').loc[pred.fit_id]
    assert (dates(fits.training_last_label_utc).to_numpy() < dates(fits.cutoff_utc).to_numpy()).all()
    assert (dates(fits.calibration_last_label_utc).to_numpy() < dates(fits.cutoff_utc).to_numpy()).all()
    assert (dates(fits.cutoff_utc).to_numpy() <= dates(pred.prediction_timestamp_utc).to_numpy()).all()
    proofs['nba'] = dict(forecasts=len(pred), dated_fits=fits.index.nunique(), saved_forecasts_exact=True,
        training_and_calibration_labels_before_cutoff=True, cutoff_before_forecast=True,
        model='nba_complete_history_v21_interactions', forecast_stage='pre12')
    for row in nba.to_dict('records'):
        if not row['eligible']:
            exclusions.append(dict(sport='nba', game_id=row['game_id'], date=row['date'], reason=row['exclusion_reason'] or 'No valid selected-outcome quote'))
            continue
        all_inputs.append(dict(sport='nba', provider='polymarket', game_id=row['game_id'],
            date=row['date'], start=row['timestamp'], entry=row['entry_utc'], exit=row['exit_utc'],
            p0=row['p0'], p1=row['p1'], target=int(row['target']), side=int(row['selected_class']),
            price=row['entry_price'], source_utc=row['entry_source_utc'], available_utc=row['entry_available_utc'],
            request_id=row['entry_request_id'], pointer=row['entry_pointer'], contract_id=row['entry_contract_id'],
            price_basis=row['price_basis'], quote_age_hours=row['entry_age_hours'], fit_id=row['fit_id'],
            teamA=row['teamA'], teamB=row['teamB'], model_stage='pre12'))
    mlb = pd.read_parquet(FINAL/'mlb/predictions.parquet')
    q = pd.read_parquet(FINAL/'reference_market/features.parquet')
    # Explicit source quote whitelist: no reference-model probabilities/features.
    fields = ['game_id','teamA','teamB']+[key+str(i) for i in [0,1] for key in
        ['price','source_utc','available_utc','age_hours','request_id','pointer','contract_id','eligible']]
    joined = mlb.merge(q[fields], on='game_id', how='left', validate='one_to_one', indicator=True)
    fitted = pd.read_parquet(FINAL/'mlb/model_fits.parquet')
    used_fits = fitted[fitted.fit_date.isin(mlb.fit_date)]
    assert used_fits.groupby('fit_date').recipe.nunique().eq(2).all()
    assert set(mlb.fit_date).issubset(set(used_fits.fit_date))
    assert used_fits.training_max_label.lt(used_fits.calibration_first_feature).all()
    assert used_fits.calibration_max_label.lt(used_fits.cutoff).all()
    fit_cutoff = used_fits.groupby('fit_date').cutoff.max()
    assert (pd.to_datetime(mlb.fit_date.map(fit_cutoff), utc=True, unit='ns') <= dates(mlb.prediction_timestamp_utc)).all()
    proofs['mlb'] = dict(forecasts=len(mlb), dated_fits=used_fits.fit_date.nunique(), saved_forecasts_unchanged=True,
        purged_training_before_calibration=True, calibration_labels_before_cutoff=True,
        cutoff_before_forecast=True, model='mlb_final_daily_baseball', market_predictors_used=False,
        forecast_stage='first_archived_confirmed_lineup_forecast_within12hours')
    for row in joined.to_dict('records'):
        side = int(row['p1'] > row['p0'])
        if row['_merge'] != 'both' or not row['eligible'+str(side)]:
            exclusions.append(dict(sport='mlb', game_id=row['game_id'], date=row['date'], reason='No retained eligible selected-outcome quote'))
            continue
        all_inputs.append(dict(sport='mlb', provider='polymarket', game_id=row['game_id'],
            date=row['date'], start=row['timestamp'], entry=row['prediction_timestamp_utc'], exit=row['label_available_at_utc'],
            p0=row['p0'], p1=row['p1'], target=int(row['target']), side=side,
            price=row['price'+str(side)], source_utc=row['source_utc'+str(side)], available_utc=row['available_utc'+str(side)],
            request_id=row['request_id'+str(side)], pointer=row['pointer'+str(side)], contract_id=row['contract_id'+str(side)],
            price_basis='polymarket_historical_token_price', quote_age_hours=row['age_hours'+str(side)], fit_id=row['fit_date'],
            teamA=row['teamA'], teamB=row['teamB'], model_stage='confirmed_lineup'))
    f = pd.DataFrame(all_inputs)
    for c in ['start','entry','exit','source_utc','available_utc']: f[c] = dates(f[c])
    assert not f.duplicated(['sport','game_id']).any()
    assert f.price.between(0,1,inclusive='neither').all()
    assert np.allclose(f.p0+f.p1, 1)
    assert f.p0.between(0,1).all() and f.p1.between(0,1).all()
    assert f.entry.lt(f.start).all() and f.start.lt(f.exit).all()
    assert f.source_utc.le(f.entry).all() and f.available_utc.le(f.entry).all()
    age=(f.entry-f.source_utc).dt.total_seconds()/3600
    assert age.le(24).all() and age.ge(0).all() and np.allclose(age,f.quote_age_hours)
    f['probability']=np.where(f.side.eq(0),f.p0,f.p1)
    assert f.probability.ge(.5).all()
    f['won']=f.side.eq(f.target)
    f['edge']=f.probability-f.price
    f['year']=f.entry.dt.year
    for sport,p in [('nba',pred),('mlb',mlb)]:
        for year,g in p.groupby(dates(p.prediction_timestamp_utc).dt.year):
            selected=f[f.sport.eq(sport)&f.year.eq(year)]
            coverage.append(dict(sport=sport,year=int(year),forecasts=len(g),quoted_games=len(selected),
                missing_quote_games=len(g)-len(selected),missing_quote_pct=100*(1-len(selected)/len(g)),
                first_entry=str(selected.entry.min()),last_entry=str(selected.entry.max())))
    pd.DataFrame(exclusions).to_csv(RESULT/'exclusions.csv',index=False)
    pd.DataFrame(coverage).to_csv(RESULT/'coverage.csv',index=False)
    dump(RESULT/'input_validation.json',proofs|dict(quote_timing_checked=True,source_prices_unchanged=True))
    return f


def simulate(f, year, selection, sizing, dollars_per_point=20., initial_cash=10000., per_bet_cap_dollars=None):
    if per_bet_cap_dollars is not None:
        assert math.isfinite(per_bet_cap_dollars) and per_bet_cap_dollars > 0
    start=pd.Timestamp(f'{year}-01-01',tz='UTC')
    end=min(pd.Timestamp(f'{year+1}-01-01',tz='UTC'),END)
    data=f[f.entry.ge(start)&f.entry.lt(end)].copy()
    if selection=='winner_above51': data=data[data.probability.gt(.51)]
    elif selection=='winner_edge5_above51': data=data[data.probability.gt(.51)&data.edge.ge(.05)]
    elif selection=='retained_mlb_edge5': data=data[data.edge.ge(.05)]
    else: assert selection in ['retained_nba_all_winners','all_selected_outcomes']
    capped=not sizing.endswith('cash_only')
    events=collections.defaultdict(lambda:dict(entries=[],exits=[],day=False))
    for at in pd.date_range(start,end,freq='D'): events[at]['day']=True
    for r in data.to_dict('records'):
        events[r['entry']]['entries'].append(r)
        if r['exit'] <= end: events[r['exit']]['exits'].append(r['game_id'])
    cash=float(initial_cash);open_positions={};bets=[];ledger=[];daily=[];peak=float(initial_cash);max_dd=0.;max_open=0.
    scaled_batches=0;unfunded=0
    for at,e in sorted(events.items()):
        if e['day'] and at>start:
            # Left-limit UTC boundary: a settlement at exactly midnight belongs
            # to the following day, not a backward move into yesterday's cash.
            daily.append(dict(date=(at-pd.Timedelta(days=1)).date().isoformat(),equity=cash+math.fsum(x['stake'] for x in open_positions.values()),cash=cash,open_cost=math.fsum(x['stake'] for x in open_positions.values())))
        if at==end: break
        payout=0.
        for gid in e['exits']:
            if gid in open_positions:
                r=open_positions.pop(gid);payout+=r['payout']
        cash+=payout
        committed=math.fsum(x['stake'] for x in open_positions.values())
        equity=cash+committed
        entries=sorted(e['entries'],key=lambda r:r['game_id'])
        if sizing=='flat40shares_cash_only':
            proposed=[40.*r['price'] for r in entries]
        elif sizing=='flat20_cash_only':
            proposed=[20. for _ in entries]
        elif sizing=='fixed20_scaled_cash_only':
            assert all(0<=r['stake_multiplier']<=1 for r in entries)
            proposed=[20.*r['stake_multiplier'] for r in entries]
        elif sizing=='mean_variance_cash_only':
            assert all(math.isfinite(r['risk_score_multiplier']) and r['risk_score_multiplier']>0 for r in entries)
            proposed=[20.*r['risk_score_multiplier'] for r in entries]
        elif sizing=='confidence_fraction_cap20':
            # Preserve the initial dollar slope, then scale it with account
            # equity so losses do not mechanically increase fractional risk.
            proposed=[equity/initial_cash*dollars_per_point*max(0.,100*r['probability']-51) for r in entries]
        elif sizing=='calibrated_dollars_cash_only':
            assert all(0<=r['sizing_probability']<=1 for r in entries)
            proposed=[dollars_per_point*max(0.,100*r['sizing_probability']-51) for r in entries]
        elif sizing=='quarter_kelly_cap20':
            proposed=[.25*equity*max(0.,(r['probability']-r['price'])/(1-r['price'])) for r in entries]
        elif sizing=='availability_edge_cash_only':
            assert all(0<=r['availability_stake_multiplier']<=1 for r in entries)
            proposed=[dollars_per_point*100*max(0.,r['probability']-r['price'])*r['availability_stake_multiplier'] for r in entries]
        elif sizing in ['edge_dollars_cash_only','edge_dollars_cap20']:
            proposed=[dollars_per_point*100*max(0.,r['probability']-r['price']) for r in entries]
        else:
            proposed=[.01*equity if sizing=='fixed1pct_cap20' else dollars_per_point*max(0.,100*r['probability']-51) for r in entries]
        if per_bet_cap_dollars is not None:
            proposed=[min(wanted,per_bet_cap_dollars) for wanted in proposed]
        room=max(0.,min(cash,.20*equity-committed)) if capped else max(0.,cash)
        total=math.fsum(proposed);scale=min(1.,room/total) if total>0 else 0.
        if total>0 and scale<1-1e-12: scaled_batches+=1
        spent=0.
        for r,wanted in zip(entries,proposed):
            stake=wanted*scale
            if stake<=1e-10: unfunded+=1;continue
            assert r['game_id'] not in open_positions
            payout_per_share=r.get('payout_per_share',float(r['won']))
            assert math.isfinite(payout_per_share) and 0<=payout_per_share<=1
            paid=stake/r['price']*payout_per_share
            row=r|dict(proposed_stake=wanted,stake=stake,allocation_scale=scale,entry_equity=equity,
                payout=paid,profit=paid-stake,unit_return=payout_per_share/r['price']-1,
                unsettled_at_end=bool(r['exit']>=end))
            open_positions[r['game_id']]=row;bets.append(row);spent+=stake
        cash-=spent;committed=math.fsum(x['stake'] for x in open_positions.values())
        assert cash>=-1e-7 and np.isclose(cash+committed,equity,atol=1e-7)
        if capped and spent>0: assert committed<=.2*equity+1e-7
        peak=max(peak,equity)
        if peak>0: max_dd=max(max_dd,1-equity/peak)
        if equity>0: max_open=max(max_open,committed/equity)
        ledger.append(dict(timestamp=at,cash=cash,open_cost=committed,equity=equity,spent=spent,payout=payout,
            proposed=total,allocation_scale=scale))
    b=pd.DataFrame(bets);d=pd.DataFrame(daily);l=pd.DataFrame(ledger)
    previous=d.equity.shift(1,fill_value=initial_cash)
    # After total ruin returns are undefined, never divide zero by zero.
    d['daily_return']=np.where(previous>0,d.equity/previous-1,np.nan)
    valid=d.daily_return.dropna();sd=valid.std(ddof=1)
    final=float(d.equity.iloc[-1]);settled=b[~b.unsettled_at_end] if len(b) else b
    if len(b): assert np.isclose(final,initial_cash+settled.profit.sum(),atol=1e-7)
    m=dict(year=year,selection=selection,sizing=sizing,dollars_per_point=dollars_per_point if sizing.startswith('dollars') else None,eligible_games=len(data),funded_games=len(b),
        unfunded_games=unfunded,scaled_batches=scaled_batches,calendar_days=len(d),
        undefined_post_ruin_days=int(d.daily_return.isna().sum()),
        win_rate_pct=100*float(b.won.mean()) if len(b) else None,
        initial_cash=initial_cash,return_pct=100*(final/initial_cash-1),sharpe=float(math.sqrt(365.25)*valid.mean()/sd) if sd>0 else None,
        max_drawdown_pct=100*max_dd,max_open_cost_pct=100*max_open,final_equity=final,
        mean_stake=float(b.stake.mean()) if len(b) else None,
        average_bet_return_pct=100*float(b.unit_return.mean()) if len(b) else None,
        unsettled_positions=len(open_positions),first_entry=str(data.entry.min()),last_entry=str(data.entry.max()))
    return m,b,l,d


def validate(b,l,d,sizing,dollars_per_point=20.,initial_cash=10000.,per_bet_cap_dollars=None):
    """Independent saved-position accounting, batch stakes and daily cutoffs."""
    if not len(b): return dict(bets=0,ledger_rows=len(l),daily_rows=len(d))
    entries=b.groupby('entry').stake.sum().sort_index()
    exits=b.groupby('exit')[['stake','payout']].sum().sort_index()
    def cumulative(series,times,side):
        indices=series.index.searchsorted(pd.DatetimeIndex(times),side=side)
        return np.r_[0.,series.cumsum().to_numpy()][indices]
    spent=cumulative(entries,l.timestamp,'right')
    released=cumulative(exits.stake,l.timestamp,'right')
    payout=cumulative(exits.payout,l.timestamp,'right')
    assert np.allclose(initial_cash-spent+payout,l.cash,rtol=0,atol=1e-7)
    assert np.allclose(spent-released,l.open_cost,rtol=0,atol=1e-7)
    boundary=dates(d.date)+pd.Timedelta(days=1)
    profit=cumulative(exits.payout-exits.stake,boundary,'left')
    assert np.allclose(initial_cash+profit,d.equity,rtol=0,atol=1e-7)
    if sizing=='flat40shares_cash_only': expected=40.*b.price
    elif sizing=='flat20_cash_only': expected=pd.Series(20.,index=b.index)
    elif sizing=='fixed20_scaled_cash_only':
        assert b.stake_multiplier.between(0,1).all()
        expected=20.*b.stake_multiplier
    elif sizing=='mean_variance_cash_only':
        expected=20.*b.risk_score_multiplier
    elif sizing=='confidence_fraction_cap20':
        expected=b.entry_equity/initial_cash*dollars_per_point*(100*b.probability-51).clip(lower=0)
    elif sizing=='calibrated_dollars_cash_only':
        expected=dollars_per_point*(100*b.sizing_probability-51).clip(lower=0)
    elif sizing=='quarter_kelly_cap20': expected=.25*b.entry_equity*((b.probability-b.price)/(1-b.price)).clip(lower=0)
    elif sizing=='availability_edge_cash_only':
        assert b.availability_stake_multiplier.between(0,1).all()
        expected=dollars_per_point*100*(b.probability-b.price).clip(lower=0)*b.availability_stake_multiplier
    elif sizing in ['edge_dollars_cash_only','edge_dollars_cap20']: expected=dollars_per_point*100*(b.probability-b.price).clip(lower=0)
    else: expected=.01*b.entry_equity if sizing=='fixed1pct_cap20' else dollars_per_point*(100*b.probability-51).clip(lower=0)
    if per_bet_cap_dollars is not None:
        expected=expected.clip(upper=per_bet_cap_dollars)
        assert b.stake.le(per_bet_cap_dollars+1e-10).all()
    assert np.allclose(expected,b.proposed_stake,rtol=0,atol=1e-10)
    assert np.allclose(b.proposed_stake*b.allocation_scale,b.stake,rtol=0,atol=1e-10)
    payoff=b.payout_per_share if 'payout_per_share' in b else b.won.astype(float)
    assert payoff.between(0,1).all()
    assert np.allclose(b.stake/b.price*payoff,b.payout)
    assert b.source_utc.le(b.entry).all() and b.available_utc.le(b.entry).all()
    return dict(bets=len(b),ledger_rows=len(l),daily_rows=len(d))


def main():
    assert not (RESULT/'validation.json').exists(),'Preserve completed comparison'
    RESULT.mkdir(exist_ok=True)
    sources=[FINAL/sport/name for sport in ['nba','mlb'] for name in ['predictions.parquet','backtest.sqlite']]
    sources += [FINAL/'mlb/model_fits.parquet',FINAL/'reference_market/features.parquet']
    hashes={str(p.relative_to(PROJECT)):file_sha256(p) for p in sources}
    plan=dict(at_utc=stamp(),requested_rule='Dollar stake=20*max(100*winner_probability-51,0); fractional percentage points used continuously; fixed dollars, not a percentage of growing equity.',
        examples={'51%':0,'58%':140,'70%':380},models='Unchanged saved rolling NBA interaction logistic and MLB no-market daily ensemble; historical fits use2021+data.',
        entries={'nba':'pre12','mlb':'First retained confirmed-lineup forecast, before start within the fixed12hour window'},
        providers=['polymarket'],price_basis='Retained international Polymarket historical token prices; not US-price records or verified executable asks.',
        selection='Primary proposed rule buys the model winner above51% regardless of price. Also isolate staking on MLB existing p-price>=.05 opportunities.',
        sizing=['fixed1pct_cap20','dollars20_cash_only','dollars20_cap20'],
        literal_rule='Cash-only version has no extra exposure cap; simultaneous requests share available cash proportionately. No borrowing or reuse of unsettled payouts.',
        controlled_comparison='Cap20 version preserves20%total open purchase cost while changing stake formula; actual reduced allocations recorded.',
        account='Each calendar year begins with$10000; game cohort by decision timestamp;2026endsSeptember29. Open positions at cost, winnings released at official result availability. No fees/spread assumptions.',
        sharpe='sqrt(365.25)*mean(actual calendar daily returns)/sample standard deviation; idle days included, post-ruin undefined days disclosed.',
        historical_comparison='NBA older saved report groups games bygame date and starts daily series around first/last funded games; primary annual comparison here uses identical UTC calendar-year boundaries for both rules.',
        testing='No parameter search or new model fit.2026 repeatedly inspected retrospective evidence. Rule is specified byuser, not selected using these outcomes.',source_sha256=hashes,app_changed=False)
    dump(RESULT/'plan.json',plan)
    f=inputs();summaries=[];positions=[];ledgers=[];days=[];checks=[]
    for sport,g in f.groupby('sport'):
        choices=[('winner_above51',s) for s in ['fixed1pct_cap20','dollars20_cash_only','dollars20_cap20']]
        if sport=='mlb':
            choices += [('winner_edge5_above51',s) for s in ['fixed1pct_cap20','dollars20_cash_only','dollars20_cap20']]
            choices += [('retained_mlb_edge5','fixed1pct_cap20')]
        else: choices += [('retained_nba_all_winners','fixed1pct_cap20')]
        for year in [2024,2025,2026]:
            for selection,sizing in choices:
                m,b,l,d=simulate(g,year,selection,sizing)
                key=dict(sport=sport,provider='polymarket',year=year,selection=selection,sizing=sizing)
                checks.append(key|validate(b,l,d,sizing));summaries.append(key|m)
                if len(b): positions.append(b.assign(**key))
                ledgers.append(l.assign(**key));days.append(d.assign(**key))
            print(json.dumps(dict(stage='confidence_dollars',sport=sport,year=year,finished_rules=len(choices))),flush=True)
    summary=pd.DataFrame(summaries)
    # Existing MLB baseline is independently reproduced on its original years.
    with read_db(FINAL/'mlb/backtest.sqlite') as db: baseline=pd.read_sql_query('SELECT * FROM summary',db)
    for r in baseline.itertuples():
        s=summary[summary.sport.eq('mlb')&summary.year.eq(r.year)&summary.selection.eq('retained_mlb_edge5')].iloc[0]
        for a,b in [('funded_games','funded_games'),('return_pct','portfolio_return_pct'),('sharpe','daily_sharpe'),('max_drawdown_pct','max_drawdown_pct')]:
            assert np.isclose(s[a],getattr(r,b),rtol=0,atol=1e-8),(a,s[a],getattr(r,b))
    for p in sources: assert file_sha256(p)==hashes[str(p.relative_to(PROJECT))]
    summary.to_csv(RESULT/'annual.csv',index=False)
    pd.concat(positions,ignore_index=True).to_parquet(RESULT/'bets.parquet',index=False)
    pd.concat(ledgers,ignore_index=True).to_parquet(RESULT/'ledger.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'daily.parquet',index=False)
    proof=dict(at_utc=stamp(),status='PASS',source_files_unchanged=True,mlb_original_baseline_reproduced=True,
        checks=checks,no_lookahead_in_quote_selection=True,no_model_refits=True,app_changed=False,
        adopted=False,annual_groups=len(summary))
    dump(RESULT/'validation.json',proof)
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False)
    key=RESULT.name+'/annual.csv'
    pd.concat([old[~old.source_result_file.eq(key)],summary.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';records=json.loads(path.read_bytes())
    records[RESULT.name]=dict(plan=plan,decision={k:v for k,v in proof.items() if k!='checks'});dump(path,records)
    cleanup()
    print(summary[['sport','year','selection','sizing','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


if __name__=='__main__': main()
