"""Earlier-outcome reliability check for a model-selected apparent price edge.

Three small features plus intercept: model log-odds, price log-odds, and outcome
role. Compare a control omitting model log-odds on the exact same opportunities.
This is a research sizing probability, not a replacement app forecast.
"""
import json
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, brier_score_loss
from common import ROOT_OUT, PREVIOUS, dump, stamp, read_db, file_sha256
from backtest import quote_inputs
from final_pipeline import cleanup
import test_confidence_dollars as engine
import transfer_stake_sizing as transfer

SIM=ROOT_OUT/'simulation_results'
OUT=SIM/'rolling_price_reliability'


def matrix(frame,include_model):
    f=pd.DataFrame(index=frame.index)
    for source in (['probability','price'] if include_model else ['price']):
        p=frame[source].clip(1e-6,1-1e-6)
        f[source+'_logit']=np.log(p/(1-p))
    f['home_outcome']=frame.bought_role.eq('Home').astype(float)
    if frame.sport.iloc[0]=='soccer':f['draw_outcome']=frame.bought_role.eq('Draw').astype(float)
    return f


def main():
    assert not (OUT/'validation.json').exists()
    OUT.mkdir(exist_ok=True)
    selection=json.loads((SIM/'staking_model_selection/selection.json').read_bytes())
    plan=dict(at_utc=stamp(),hypothesis='Apparent value bets can select forecast errors. Estimate whether model and purchase price together predict outcomes in previously settled bets, rather than assuming every positive raw edge is real.',
        features=['logit(saved sports model probability)','logit(current pregame purchase price)','home indicator','soccer draw indicator'],
        control='Same selected opportunities and outcome-role controls, omitting the sports-model probability. This is a calibration control, not a fully model-free strategy, because the original model selected the outcome.',
        estimator='sklearn LogisticRegression,C=1,L2,intercept,max_iter1000; no parameter search; logit clip1e-6; no resampling or class weights.',
        rolling='At each UTC month start fit on all available selected-outcome examples from2024 onward with official label availability strictly before month start. Require100prior games and at least10of each binary label. Future labels unavailable to fit.',
        model_history='Underlying sports forecasts already use expanding2021+history. Reliability fit uses only out-of-sample saved forecast/price pairs, not fitted training predictions.',
        sizing='Fixed$5for each percentage point adjusted probability exceeds price, with$2000startingcash and original available-cash limits. One originally selected outcome per game. No additional price margin or cap.',
        selection='Development2025 must improve logloss over raw sports probability AND the price-only calibration control, plus improve strategy Sharpe with positive return. Save decision before2026accounts.2026is repeatedly inspected retrospective research.',
        outcome_roles='Official stored home/away mapping; draw as its own role.',app_changed=False)
    dump(OUT/'plan.json',plan)
    quotes=quote_inputs(OUT/'quote_quality.json',revision='closest_v62')
    data=[]
    for sport in ['nhl','soccer']:
        transfer.RESULT=SIM/'transferred_account_staking'
        p=transfer.get_forecasts(sport,selection['selections'][sport])
        transfer.RESULT=OUT
        f=transfer.normalize(sport,p,quotes,pick_growth=True)
        with read_db(PREVIOUS/'expanded.sqlite') as db:
            names=pd.read_sql_query('SELECT game_id,home_away FROM '+sport+'_games',db).set_index('game_id').home_away
        roles=f.game_id.map(names);assert roles.notna().all()
        f['bought_role']=[r.split(';')[int(side)] if side<2 else 'Draw' for r,side in zip(roles,f.side)]
        assert f.bought_role.isin(['Home','Away','Draw']).all()
        data.append(f)
    frame=pd.concat(data,ignore_index=True)
    predictions=[];fits=[];coverage=[]
    for (sport,provider),g in frame.groupby(['sport','provider']):
        for boundary in pd.date_range('2025-01-01','2026-09-01',freq='MS',tz='UTC'):
            end=boundary+pd.offsets.MonthBegin(1)
            train=g[g.exit.lt(boundary)&g.entry.ge(pd.Timestamp('2024-01-01',tz='UTC'))]
            test=g[g.entry.ge(boundary)&g.entry.lt(end)]
            counts=train.won.value_counts()
            ready=len(train)>=100 and len(counts)==2 and counts.min()>=10
            coverage.append(dict(sport=sport,provider=provider,boundary=str(boundary),prior_games=len(train),forecast_games=len(test),ready=bool(ready)))
            if not ready or not len(test):continue
            assert train.exit.max()<boundary<=test.entry.min()
            for include_model,rule in [(True,'model_and_price'),(False,'price_control')]:
                x=matrix(train,include_model);x_test=matrix(test,include_model)
                model=LogisticRegression(C=1.,max_iter=1000).fit(x,train.won.astype(int))
                assert model.n_iter_.max()<1000
                out=test.copy();out['primary_probability']=out.probability
                out['reliability_probability']=model.predict_proba(x_test)[:,1]
                out['calibration_boundary']=boundary;out['calibration_last_label']=train.exit.max();out['rule']=rule
                predictions.append(out)
                fits.append(dict(sport=sport,provider=provider,boundary=str(boundary),rule=rule,train_games=len(train),
                    first_training_entry=str(train.entry.min()),last_training_label=str(train.exit.max()),
                    coefficients=dict(zip(x.columns,model.coef_[0].tolist())),intercept=float(model.intercept_[0]),
                    training_membership_sha256=__import__('hashlib').sha256('\n'.join(sorted(train.game_id)).encode()).hexdigest()))
        print(json.dumps(dict(stage='rolling_price_reliability',sport=sport,provider=provider)),flush=True)
    predictions=pd.concat(predictions,ignore_index=True)
    predictions.to_parquet(OUT/'reliability_predictions.parquet',index=False)
    pd.DataFrame(coverage).to_csv(OUT/'coverage.csv',index=False)
    dump(OUT/'fits.json',dict(fits=fits))
    scores=[]
    for key,g in predictions.groupby(['sport','provider','year','rule']):
        scores.append(dict(zip(['sport','provider','year','rule'],key))|dict(games=len(g),
            logloss=log_loss(g.won,g.reliability_probability,labels=[False,True]),brier=brier_score_loss(g.won,g.reliability_probability)))
    base=predictions[predictions.rule.eq('model_and_price')].copy()
    for key,g in base.groupby(['sport','provider','year']):
        scores.append(dict(zip(['sport','provider','year'],key))|dict(rule='raw_model',games=len(g),
            logloss=log_loss(g.won,g.primary_probability,labels=[False,True]),brier=brier_score_loss(g.won,g.primary_probability)))
    scores=pd.DataFrame(scores);scores.to_csv(OUT/'probability_metrics.csv',index=False)
    rows=[];bets=[];days=[];checks=[];choices={}
    for year in [2025,2026]:
        for (sport,provider),g in predictions.groupby(['sport','provider']):
            for rule in ['raw_model','price_control','model_and_price']:
                f=g[g.rule.eq('model_and_price' if rule=='raw_model' else rule)].copy()
                f['probability']=f.primary_probability if rule=='raw_model' else f.reliability_probability
                f['edge']=f.probability-f.price;f=f[f.edge.gt(0)]
                m,b,l,d=engine.simulate(f,year,'all_selected_outcomes','edge_dollars_cash_only',5.,2000.)
                key=dict(sport=sport,provider=provider,year=year,rule=rule)
                rows.append(key|m);bets.append(b.assign(**key));days.append(d.assign(**key))
                checks.append(key|engine.validate(b,l,d,'edge_dollars_cash_only',5.,2000.))
        if year==2025:
            a=pd.DataFrame(rows)
            for key,g in a.groupby(['sport','provider']):
                metrics=scores[scores.sport.eq(key[0])&scores.provider.eq(key[1])&scores.year.eq(2025)].set_index('rule')
                actual=g.set_index('rule')
                accept=bool(metrics.loc['model_and_price','logloss']<min(metrics.loc['raw_model','logloss'],metrics.loc['price_control','logloss']) and actual.loc['model_and_price','return_pct']>0 and actual.loc['model_and_price','sharpe']>actual.loc['raw_model','sharpe'])
                choices['/'.join(key)]=dict(accepted_on2025=accept)
            dump(OUT/'frozen_choices.json',dict(at_utc=stamp(),choices=choices))
    a=pd.DataFrame(rows);a.to_csv(OUT/'annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(OUT/'bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(OUT/'daily.parquet',index=False)
    assert predictions.calibration_last_label.lt(predictions.calibration_boundary).all()
    assert predictions.calibration_boundary.le(predictions.entry).all()
    dump(OUT/'validation.json',dict(at_utc=stamp(),status='PASS',checks=checks,
        every_reliability_fit_label_before_forecast=True,complete_matched_cohort=True,
        providers_separate=True,app_changed=False,adopted=False))
    path=SIM/'experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=OUT.name+'/annual.csv'
    pd.concat([old[~old.source_result_file.eq(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=SIM/'experiment_decisions.json';old=json.loads(path.read_bytes());old[OUT.name]=dict(plan=plan,choices=choices,adopted=False);dump(path,old)
    cleanup()
    print(scores.round(5).to_string(index=False))
    print(a[['sport','provider','year','rule','funded_games','return_pct','sharpe','max_drawdown_pct']].round(4).to_string(index=False))


if __name__=='__main__':main()
