"""Real raw replay, score/identity checks and temporal SQL verification."""
import hashlib,json,sqlite3
from pathlib import Path
from common import ROOT_OUT,PROJECT,REPORTS,OfficialClient,dump,stamp
from collect_nations_league import fetch_details,connect

CASES=[
 ('2030758','2021-10-06','Spain','Italy',2,1,'https://www.uefa.com/uefanationsleague/news/026e-136a8a6c12d1-760400cb5c10-1000--italy-1-2-spain-ferran-torres-double-ends-azzurri-run/'),
 ('2030759','2021-10-07','France','Belgium',3,2,'https://www.uefa.com/uefanationsleague/news/026e-136c90f5ce2c-05c6c012c9d6-1000--belgium-2-3-france-theo-hernandez-completes-stunning-com/'),
 ('2035581','2023-06-14','Croatia','Netherlands',2,2,'https://www.uefa.com/uefanationsleague/news/0282-1841c89faf2f-f449471df8eb-1000--netherlands-2-4-croatia-aet-modric-stars-as-vatreni-win-c/'),
]


def main():
    client=OfficialClient();db=connect();games={k:json.loads(b) for k,b in db.execute('SELECT game_id,body FROM calendar')}
    checked=0;sources=set();all_players=0;repaired=0
    for gid,body in db.execute('SELECT game_id,body FROM details').fetchall():
        old=json.loads(body)
        for s in [old['sources']['match'],old['sources']['lineup']]+old['sources']['events']:
            blob=(PROJECT/s['raw_file']).read_bytes();assert hashlib.sha256(blob).hexdigest()==s['sha256'];sources.add(s['sha256'])
        _,new,error,_=fetch_details(client,games[gid]);assert error is None,(gid,error)
        # These include the two documented source repairs already applied.
        assert old['players']==new['players'],gid
        assert old['coaches']==new['coaches'],gid
        assert all(p['team_id'].startswith('UEFA_NATIONAL:') for p in new['players'])
        assert all(p['minutes'] is not None and 0<=p['minutes']<=90 for p in new['players'])
        all_players+=len(new['players']);checked+=1;repaired+=len(new['official_corrections'])
        with db:db.execute('UPDATE details SET body=? WHERE game_id=?',(json.dumps(new),gid))
    sql=Path(__file__).with_name('nations_league_asof.sql').read_text(encoding='utf8')
    sql='\n'.join(line.split('--')[0] for line in sql.splitlines());statements=[s.strip() for s in sql.split(';') if s.strip()]
    assert len(statements)==5
    memory=sqlite3.connect(':memory:');db.backup(memory)
    cutoff='2025-01-01T00:00:00Z';before=[memory.execute(s,dict(as_of_utc=cutoff)).fetchall() for s in statements]
    assert all(before)
    for name in ['nations_league_games','nations_league_team_match_statistics','nations_league_player_match_statistics','nations_league_manager_appearances','nations_fifa_rankings']:
        field='available_time' if name=='nations_league_games' else 'available_at_utc'
        memory.execute('DELETE FROM '+name+' WHERE julianday('+field+')>=julianday(?)',(cutoff,))
    after=[memory.execute(s,dict(as_of_utc=cutoff)).fetchall() for s in statements]
    assert before==after,'A future observation influenced an as-of query'
    assert all(not memory.execute(s,dict(as_of_utc='2021-01-01T00:00:00Z')).fetchall() for s in statements)
    public=[]
    for mid,date,a,b,sa,sb,url in CASES:
        g=games['HIST_UNL_'+mid];assert [g[k] for k in ['date','teamA','teamB','scoreA','scoreB']]==[date,a,b,sa,sb]
        blob,source=client.get(url,'Manual official public result validation '+mid,'official_public_validation',document=True)
        assert blob is not None
        public.append(dict(game_id=g['game_id'],teams=[a,b],date=date,regulation_score=[sa,sb],match=True,public_source=source,
            detail='2023 semifinal was 2-2 after regulation and 4-2 to Croatia after extra time; phase-specific label confirmed.' if mid=='2035581' else 'Dated official UEFA result report agrees.'))
    out=dict(at_utc=stamp(),status='PASS',games_replayed=checked,players_replayed=all_players,source_hashes_checked=len(sources),documented_substitution_repairs=repaired,
        all_regulation_minutes_present=True,temporal_sql_future_removal='PASS',asof_team_rows=len(before[0]),asof_player_rows=len(before[1]),public_result_validation=public,
        asof_ranking_rows=len(before[4]),
        limitation='Detailed assists/passing are not inferred from omitted events; odds and rolling model results have separate validation reports.')
    dump(ROOT_OUT/'nations_league_replay_validation.json',out)
    print(json.dumps({k:v for k,v in out.items() if k!='public_result_validation'}),flush=True)
    db.close();memory.close()


if __name__=='__main__':main()
