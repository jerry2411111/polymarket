"""Resolve absent player-stat pages only with a complete official appearance tally."""
import json,sqlite3
from common import ROOT_OUT,PREVIOUS,OfficialClient,read_db,dump,stamp


def main():
    client=OfficialClient();db=sqlite3.connect(ROOT_OUT/'player_detail.sqlite',timeout=60)
    db.execute('CREATE TABLE IF NOT EXISTS verified_nonappearances(game_id TEXT,player_id TEXT,body TEXT,PRIMARY KEY(game_id,player_id))')
    pending=list(db.execute("SELECT game_id,player_id,source_json FROM acquisition_issues WHERE reason='Official API status 404'"));repaired=[]
    for gid,pid,failed in pending:
        with read_db(PREVIOUS/'expanded.sqlite') as c:g=dict(c.execute('SELECT * FROM soccer_games WHERE game_id=?',(gid,)).fetchone())
        base='https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v3/matches/'+str(g['official_game_id'])
        lineup,ls=client.get(base+'/lineups','Verify completed dated lineup and unused substitute: '+gid,kind='official_appearance_reconciliation')
        stats,ss=client.get(base+'/stats','Verify official team substitution count for unused-substitute reconciliation: '+gid,kind='official_appearance_reconciliation')
        for side,label in [('A','away'),('B','home')]:
            team=lineup[label+'_team'];ids={str(p['id']) for p in team['players']}
            if pid not in ids:continue
            candidate=next(p for p in team['players'] if str(p['id'])==pid)
            assert candidate['position']=='Substitute'
            found=[json.loads(b) for b, in db.execute('SELECT body FROM player_match_detail WHERE game_id=?',(gid,))]
            found=[r for r in found if r['side']==side]
            assert {r['player_id'] for r in found}==ids-{pid},'Other unverified roster players remain'
            starters=[r for r in found if r['started']==1];subs=[r for r in found if r['started']!=1 and r['minutes'] is not None and r['minutes']>0]
            ts=next(r for r in stats if str(r['teamId'])==str(team['teamId']))
            assert len(starters)==11 and len(subs)==ts['stats']['subsMade'],'Incomplete explicit appearance tally'
            assert sum(r['minutes'] or 0 for r in found)==990,'Playing-time sum does not cover 11 players for 90 minutes'
            row=dict(game_id=gid,official_game_id=g['official_game_id'],player_id=pid,player_name=' '.join([candidate['firstName'],candidate['lastName']]),
                     league='Premier League',date=g['date'],available_at_utc=g['available_time'],team_id=str(team['teamId']),side=side,
                     played=False,minutes=0,started=False,evidence=dict(official_substitutions=ts['stats']['subsMade'],verified_substitutes=[r['player_id'] for r in subs],
                     sum_official_player_minutes=990),sources=[ls,ss]+[r['source'] for r in starters+subs],failed_statistics_request=json.loads(failed),
                     meaning='Verified unused substitute. Zero is no appearance, not a fabricated player-stat API response; no unprovided action statistics are filled.')
            with db:
                db.execute('INSERT OR REPLACE INTO verified_nonappearances VALUES (?,?,?)',(gid,pid,json.dumps(row)))
                db.execute('DELETE FROM acquisition_issues WHERE game_id=? AND player_id=?',(gid,pid))
            repaired.append(dict(game_id=gid,player_id=pid,minutes=0))
    dump(ROOT_OUT/'player_nonappearance_reconciliation.json',dict(at_utc=stamp(),verified=repaired,remaining_issues=db.execute('SELECT count(*) FROM acquisition_issues').fetchone()[0]))
    print(json.dumps(dict(verified=repaired,remaining_issues=db.execute('SELECT count(*) FROM acquisition_issues').fetchone()[0])),flush=True);db.close()


if __name__=='__main__':main()
