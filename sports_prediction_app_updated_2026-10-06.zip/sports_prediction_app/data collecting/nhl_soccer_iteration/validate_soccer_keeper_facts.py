"""Verify unified goalkeeper rows from original native lineups and raw cells."""
import collections,hashlib,json,re
from pathlib import Path
import pandas as pd
from common import ROOT_OUT,PREVIOUS,PROJECT,read_db,dump,stamp
from discover_soccer_keeper_sources import RUN
from soccer_keeper_facts import FIELDS,observation_path

def identity_links(frame):
    aliases=collections.defaultdict(set);references=0
    for row in frame.itertuples():
        role=json.loads(row.role_evidence_json)
        if role.get('maker_player_id') and role.get('identity_link'):
            aliases[role['maker_player_id']].add((row.id_namespace,row.official_player_id))
            references+=1
    assert all(len(ids)==1 for ids in aliases.values()),'Contradictory native player identity link'
    return dict(unique_club_native_identities=len(aliases),consistent_dated_link_references=references)

def main():
    source_path=observation_path()
    frame=pd.read_parquet(source_path);cache={};checked_sources=set();counts=collections.Counter()
    link_checks=identity_links(frame)
    with read_db(PREVIOUS/'expanded.sqlite') as db:games={r['game_id']:dict(r) for r in db.execute('SELECT * FROM soccer_games')}
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        uefa={r['game_id']:json.loads(r['source_links']) for r in db.execute('SELECT * FROM uefa_match_statistics_sources')}
        uefa_players={(r['game_id'],str(r['lineup_player_id'] or r['official_player_id'])):dict(r) for r in db.execute("SELECT * FROM uefa_match_player_statistics WHERE position='GOALKEEPER' AND lineup_identity_verified=1")}
    with read_db(RUN/'seriea/statistics.sqlite') as db:
        seriea_minutes={(g['game_id'],str(p['official_player_id'])):p['minutes_regulation']
            for body, in db.execute('SELECT body FROM games') for g in [json.loads(body)] for p in g['players']}
    def raw(source):
        digest=source['sha256']
        if digest not in cache:
            path=Path(source['raw_file']);path=path if path.is_absolute() else PROJECT/path
            data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==digest
            if len(cache)>=12:del cache[next(iter(cache))]
            if data.lstrip().startswith(b'<'):
                match=re.search(rb'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',data,re.S)
                assert match,'Official structured match document missing'
                cache[digest]=json.loads(match[1])
            else:cache[digest]=json.loads(data)
            checked_sources.add(digest)
        return cache[digest]
    def ptr(d,path):
        for key in path.strip('/').split('/'):
            if isinstance(d,list):d=d[int(key)]
            else:d=d.get(key)
            if d is None:break
        return d
    for r in frame.to_dict('records'):
        game=games[r['game_id']];source=json.loads(r['source_json']);data=raw(source);role=json.loads(r['role_evidence_json']);proof=json.loads(r['field_evidence_json'])
        assert pd.Timestamp(r['available_at_utc'])>pd.Timestamp(game['timestamp'])
        side=r['side'];native='away' if side=='A' else 'home';pid=r['official_player_id']
        assert r['team_id']==str(json.loads(game['native_team_ids_json'])[0 if side=='A' else 1])
        if r['league']=='UEFA Champions League':
            lu=raw(uefa[r['game_id']]['lineup']);section=lu[native+'Team'];assert str(section['team']['id'])==r['team_id']
            actors=[x['player'] for group in ['field','bench'] for x in section.get(group,[]) if str(x['player']['id'])==pid]
            assert len(actors)==1 and actors[0]['fieldPosition']=='GOALKEEPER'
            p=uefa_players[r['game_id'],pid];actor=ptr(data,p['source_pointer']);assert str(actor['playerId'])==p['official_player_id']
            assert p['minutes_played_official']==r['minutes']
            if p['official_player_id']!=pid:assert p['identity_evidence_json'] is not None
        else:
            lu=raw(role['source']);assert ptr(lu,role['pointer'])==role['raw_value']
            if r['league']=='Premier League':
                assert str(data['playerMetadata']['id'])==pid
                assert str(ptr(lu,role['pointer'].rsplit('/',1)[0])['id'])==pid
                assert data['stats']['minsPlayed']==r['minutes']
            elif r['league']=='Ligue 1':
                person=ptr(lu,role['pointer'].rsplit('/',1)[0]);identity=person['playerIdentity'];idval=identity.get('shortOptaId')
                assert (str(idval) if idval is not None else person['id'])==pid
                assert person['minutesPlayed']==r['minutes'] and str(data['id'])==r['official_game_id']
            elif r['league']=='Serie A':
                assert ptr(lu,role['pointer'].rsplit('/',1)[0])['playerId']==pid and data['matchId']==r['official_game_id']
                assert r['minutes']==seriea_minutes[r['game_id'],pid], 'Regulation exposure must retain exact source-derived precision'
                # Regulation exposure is independently replayed by the separate
                # full Serie A validator, not equated to elapsed stat minutes.
            elif r['league']=='La Liga' and role.get('direct_league_full_match'):
                person=ptr(lu,role['pointer'].rsplit('/',1)[0]);maker_id=person['player']['id']
                assert person['starting'] and not person.get('manager') and person['formationPlace']==1
                assert maker_id==role['maker_player_id'] and lu['game']['id']==role['maker_game_id']
                assert lu['game'][native+'Team']['id']==role['maker_team_id']
                assert [lu['game']['awayScore'],lu['game']['homeScore']]==[game['scoreA'],game['scoreB']]
                link=role['identity_link'];linked=ptr(raw(link['source']),link['lineup_pointer'])
                if link.get('basis')=='unique exact full name in same dated official team lineup':
                    from laliga_retained_facts import namekey
                    assert link['source']['sha256']==source['sha256']
                    assert namekey(person['player']['name'])==namekey(linked['person']['name'])
                    assert link['maker_player_id']==maker_id and link['opta_player_id']==pid
                    starters=data['props']['pageProps']['data']['lineups'][native]['starts']
                    assert sum(namekey(p['person']['name'])==namekey(person['player']['name']) for p in starters)==1
                    assert {x for x in re.findall(r'/(p\d+)/',str(linked.get('photos',{})))}=={pid}
                    counts['exact_dated_team_name_links']+=1
                else:
                    actor=linked['player'];assert actor['id']==maker_id
                    urls=[actor.get('imageMainUrl') or '',(actor.get('image') or {}).get('url') or '']
                    assert {x for url in urls for x in re.findall(r'/(p\d+)/',url)}=={pid}
                page=data['props']['pageProps'];match=page['match'];player=ptr(data,role['league_lineup_pointer'])
                assert str(match['id'])==r['official_game_id'] and match['status']=='FullTime'
                assert str(match[native+'_team']['id'])==r['team_id']
                assert [match['away_score'],match['home_score']]==[game['scoreA'],game['scoreB']]
                assert {x for x in re.findall(r'/(p\d+)/',str(player.get('photos',{})))}=={pid}
                assert player['status']=='start' and r['minutes']==90
                from laliga_retained_facts import parse,namekey
                parsed=parse(game,page,source,allow_stoppage_clock=True)
                assert parsed['minutes_complete'] and parsed['goal_counts_reconcile']
                if role.get('regulation_clock_recoveries'):
                    assert role['regulation_clock_recoveries']==parsed['regulation_clock_recoveries']
                    for item in role['regulation_clock_recoveries']:
                        event=page['events'][item['event_index']]
                        assert event['id']==item['event_id']
                        base,extra=map(int,event['clock'].split('+'))
                        assert extra>0 and event['time']==base+extra
                        assert base==({'FirstHalf':45,'SecondHalf':90}[event['period']])==item['regulation_minute']
                    assert pd.Timestamp(r['available_at_utc'])>=max(pd.Timestamp(e['date_source']) for e in page['events'] if e.get('date_source'))
                p=next(x for x in parsed['players'] if x['side']==side and x['official_player_id']==pid)
                assert p['started'] and p['minutes']==90 and str(player['id'])==p['source_lineup_id']
                names={namekey(x) for x in [player['person'].get('name'),player['person'].get('nickname'),
                    ' '.join([player['person'].get('firstname') or '',player['person'].get('lastname') or ''])] if x}
                for event in page['events']:
                    kind=event['match_event_kind']['collection'];label=event['match_event_kind']['name']
                    if kind=='substitution':exit_actor=event.get('lineup_off')
                    elif kind=='booking' and label in ['Second Yellow','Straight Red']:exit_actor=event.get('lineup')
                    else:continue
                    assert exit_actor and event.get('period') in ['FirstHalf','SecondHalf']
                    assert not (str(exit_actor['team']['id'])==r['team_id'] and namekey(exit_actor['person']['name']) in names)
                definition=role['definition_source'];blob=(PROJECT/definition['raw_file']).read_bytes()
                assert hashlib.sha256(blob).hexdigest()==definition['sha256']
                text=blob.decode('utf8');formation=lu['game'][native+'Formation']
                match=re.search(r'(?<!\d)'+re.escape(formation)+r':P\((\[[^\]]+\])\)',text)
                assert match and json.loads(match[1])==role['formation_grid']
                assert 'gridArea:`n${n?.formationPlace||e+1}`' in text
                assert all(line.split()[0] in ['.','n1'] and 'n1' not in line.split()[1:] for line in role['formation_grid'])
                assert pd.Timestamp(lu['game']['time'])==pd.Timestamp(role['verified_start_utc'])
                assert pd.Timestamp(r['available_at_utc'])>=pd.Timestamp(lu['game']['time'])+pd.Timedelta(hours=6)
                counts['full_match_keeper_assignment_checks']+=1
            elif r['league']=='La Liga' and 'maker_game_id' in role:
                person=ptr(lu,role['pointer'].rsplit('/',1)[0]);maker_id=person['player']['id']
                assert person['starting'] and not person.get('manager') and person['formationPlace']==1
                assert maker_id==role['maker_player_id']
                assert data['game']['id']==role['maker_game_id']
                assert data['game'][native+'Team']['id']==role['maker_team_id']
                assert [data['game']['awayScore'],data['game']['homeScore']]==[game['scoreA'],game['scoreB']]
                corrected={x['game_id']:x['verified_start_utc'] for x in json.loads((ROOT_OUT/'laliga_clock_audit.json').read_bytes())['records']}
                assert pd.Timestamp(data['game']['time'])==pd.Timestamp(corrected.get(r['game_id'],game['timestamp']))
                assert pd.Timestamp(r['available_at_utc'])>=pd.Timestamp(data['game']['time'])+pd.Timedelta(hours=6)
                stats_path=proof['saves']['pointer'].rsplit('/',1)[0]
                assert ptr(data,stats_path+'/minsPlayed')==r['minutes']
                assert ptr(data,stats_path.rsplit('/stats',1)[0])['player']['id']==maker_id
                link=role['identity_link']
                if link:
                    identity=raw(link['source']);linked=ptr(identity,link['lineup_pointer'])
                    if link.get('basis')=='unique exact full name in same dated official team lineup':
                        from laliga_retained_facts import namekey
                        page=identity['props']['pageProps'];match=page['match']
                        assert str(match['id'])==r['official_game_id'] and match['status']=='FullTime'
                        assert str(match[native+'_team']['id'])==r['team_id']
                        assert [match['away_score'],match['home_score']]==[game['scoreA'],game['scoreB']]
                        assert namekey(person['player']['name'])==namekey(linked['person']['name'])
                        assert linked['status']=='start'
                        assert sum(namekey(p['person']['name'])==namekey(person['player']['name']) for p in page['data']['lineups'][native]['starts'])==1
                        assert {x for x in re.findall(r'/(p\d+)/',str(linked.get('photos',{})))}=={pid}
                        assert link['maker_player_id']==maker_id and link['opta_player_id']==pid
                        assert role['raw_player_id_preserved']==maker_id
                        counts['same_game_native_identity_repairs']+=1
                    else:
                        actor=linked['player'];assert actor['id']==maker_id
                        urls=[actor.get('imageMainUrl') or '',(actor.get('image') or {}).get('url') or '']
                        tokens={x for url in urls for x in re.findall(r'/(p\d+)/',url)}
                        assert tokens=={pid}
                    assert r['id_namespace']=='opta_player_asset'
                else:assert pid==maker_id and r['id_namespace']=='laliga_maker_uuid'
                definition=role['definition_source'];blob=(PROJECT/definition['raw_file']).read_bytes()
                assert hashlib.sha256(blob).hexdigest()==definition['sha256']
                text=blob.decode('utf8');formation=data['game'][native+'Formation']
                match=re.search(r'(?<!\d)'+re.escape(formation)+r':P\((\[[^\]]+\])\)',text)
                assert match and json.loads(match[1])==role['formation_grid']
                assert 'gridArea:`n${n?.formationPlace||e+1}`' in text
                for line in role['formation_grid']:
                    cells=line.split();assert cells[0] in ['.','n1'] and 'n1' not in cells[1:]
                corroboration=json.loads((RUN/'laliga/maker_role_validation.json').read_bytes())
                assert corroboration['status']=='PASS' and corroboration['dated_explicit_G_matches']>=500
                counts['derived_formation_roles']+=1
            elif r['league']=='La Liga':
                person=ptr(lu,role['pointer'].rsplit('/',1)[0])
                assert person['altIds']['opta']==pid==data['entity']['altIds']['opta']
                assert str(int(person['id']))==role['club_player_id']==str(int(data['entity']['id']))
                assert str(int(lu['id']))==role['club_fixture_id'] and lu['altIds']['opta']==role['opta_match_id']
                section=lu['teamLists'][int(role['pointer'].split('/')[2])]
                expected=lu['teams'][1 if side=='A' else 0]
                assert str(int(section['teamId']))==str(int(expected['team']['id']))
                assert [t['score'] for t in lu['teams']]==[game['scoreB'],game['scoreA']]
                assert pd.Timestamp(lu['kickoff']['millis'],unit='ms',tz='UTC')==pd.Timestamp(game['timestamp'])
                assert [c['value'] for c in data['stats'] if c['name']=='mins_played']==[r['minutes']]
                import urllib.parse
                assert urllib.parse.parse_qs(urllib.parse.urlsplit(source['url']).query)['fixtures']==[role['club_fixture_id']]
            else:raise AssertionError(r['league'])
        counts['native_role_checks']+=1
        for f in FIELDS:
            e=proof.get(f) or {};value=r[f];rawvalue=r['raw_'+f]
            expected=e.get('raw_value')
            paths=e.get('pointers') or ([e['pointer']] if e.get('pointer') else [])
            if paths:
                vals=[ptr(data,p) for p in paths]
                assert all(v==vals[0] for v in vals)
                expected=float(vals[0]) if vals[0] is not None else None
            if pd.isna(rawvalue):assert expected is None,(r['game_id'],f,expected)
            else:assert expected is not None and float(expected)==rawvalue,(r['game_id'],f,expected,rawvalue)
            counts['raw_cells']+=1
            if pd.isna(value):assert pd.isna(rawvalue);continue
            if not pd.isna(rawvalue) and value==rawvalue:counts['direct_values']+=1;continue
            basis=e.get('basis')
            if basis in ['official team clean sheet','official final score with verified full-match goalkeeper']:
                assert value==game['scoreB' if side=='A' else 'scoreA']
                if basis=='official team clean sheet':assert value==0
                else:assert r['league']=='Serie A' and r['minutes']==90
            elif basis=='complete official team/player total reconciliation':
                p=e['zero_proof'];assert value==0 and p['team_total']==p['known_sum']
                assert str(p['official_player_id'])==pid and p['game_id']==r['game_id']
                assert json.loads((ROOT_OUT/'sparse_player_v26/pl_zero_validation.json').read_bytes())['status']=='PASS'
            elif basis=='explicit official team saves zero':
                assert value==0 and float(ptr(raw(e['source']),e['field_evidence']['pointer']))==0
            elif basis=='verified full-match goalkeeper assigned official team total':
                assert role.get('direct_league_full_match') and r['minutes']==90
                assert pd.isna(rawvalue) and value==e['team_raw_value']==ptr(data,e['team_pointer'])
            elif basis=='official clean sheet supersedes conflicting keeper statistic':
                assert r['league']=='Premier League' and value==0 and rawvalue>0
                final=ptr(raw(e['calendar_source']),e['calendar_pointer'])
                assert final['period']=='FullTime' and str(final['matchId'])==r['official_game_id']
                assert str(final[native+'Team']['id'])==r['team_id']
                assert [final[k]['score'] for k in ['awayTeam','homeTeam']]==[game['scoreA'],game['scoreB']]
                assert final[('home' if side=='A' else 'away')+'Team']['score']==0
            else:raise AssertionError((r['game_id'],f,basis,value,rawvalue))
            counts['derived_values']+=1;counts['derived_'+str(basis)]+=1
    seriea=json.loads((RUN/'seriea/validation.json').read_bytes());assert seriea['status']=='PASS'
    report=dict(status='PASS',at_utc=stamp(),rows=len(frame),raw_sources=len(checked_sources),**dict(counts),
        identity_link_checks=link_checks,
        source_sha256=hashlib.sha256(source_path.read_bytes()).hexdigest(),
        player_role_not_inferred_from_saves=True,missing_values_not_automatically_zero=True,forecast_features_not_yet_validated=True)
    dump(RUN/'keeper_validation.json',report);print(json.dumps(report),flush=True)

if __name__=='__main__':main()
