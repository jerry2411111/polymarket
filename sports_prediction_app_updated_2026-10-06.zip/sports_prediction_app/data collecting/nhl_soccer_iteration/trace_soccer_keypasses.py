"""Replay sparse keeper-independent roster key-pass features from dated players.

The saved report contains only the three diagnosed forecasts and the source
observations supporting their player rates, not another full player export.
"""
import collections
import argparse
import json
import numpy as np
import pandas as pd

from common import ROOT_OUT,PROJECT,read_db,dump,stamp,file_sha256
from team_context_features import context_sources

TARGETS={'HIST_BUN_DFL-MAT-J03WGY','HIST_BUN_DFL-MAT-J03WHD','HIST_BUN_DFL-MAT-J03YI4'}


def clean(value):
    if isinstance(value,dict):return {k:clean(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [clean(v) for v in value]
    if isinstance(value,(float,np.floating)) and not np.isfinite(value):return None
    return value


def main():
    games,_,players,keys,_,_,evidence,_=context_sources(include_exposure=True,include_uefa_exposure=True)
    frozen=pd.read_parquet(ROOT_OUT/'retained_models/soccer/soccer_features.parquet').set_index('game_id')
    games=games[games.game_id.isin(frozen.index)].copy()
    games['available_time']=games.game_id.map(frozen.observation_available_time)
    # No current lineup is consulted: the prior5collectedgames establish weights.
    minimal=['game_id','side','player_id','official_player_id','league','player_name','minutes','key_passes','available_at_utc']
    for c in ['minutes','key_passes']:players[c]=pd.to_numeric(players[c],errors='coerce')
    rows=collections.defaultdict(list);proofs={}
    for r in players[minimal].to_dict('records'):rows[r['game_id'],r['side']].append(r)
    for r in players[players.key_passes.notna()].to_dict('records'):
        proofs[r['game_id'],r['side'],r['player_id']]={k:r.get(k) for k in ['source','raw_stats','field_evidence_json','request_ids_json','source_pointer','source_table']}
    team_history=collections.defaultdict(lambda:collections.deque(maxlen=60))
    histories=collections.defaultdict(lambda:collections.deque(maxlen=30));last_team={}
    events=list(games.sort_values(['available_time','game_id']).itertuples());cursor=0;output=[]
    for g in games[games.game_id.isin(TARGETS)].sort_values(['prediction_time','game_id']).itertuples():
        while cursor<len(events) and events[cursor].available_time<g.prediction_time:
            old=events[cursor];cursor+=1
            for side in ['A','B']:
                team=keys[old.game_id,side];observed=[]
                for p in rows[old.game_id,side]:
                    if pd.notna(p['minutes']) and p['minutes']>0:
                        assert pd.Timestamp(p['available_at_utc'])<=old.available_time
                        histories[p['player_id']].append(dict(p,used_at=old.available_time));last_team[p['player_id']]=team
                        observed.append((p['player_id'],p['minutes']))
                team_history[team].append(observed)
        sides={}
        for side in ['A','B']:
            team=keys[g.game_id,side];weights=collections.Counter()
            for roster in list(team_history[team])[-5:]:
                for pid,minutes in roster:
                    if last_team[pid]==team:weights[pid]+=minutes
            people=[]
            for pid,weight in weights.items():
                h=[p for p in histories[pid] if pd.notna(p['key_passes'])]
                if not h:continue
                assert all(p['used_at']<g.prediction_time for p in h)
                rate=90*sum(p['key_passes'] for p in h)/sum(p['minutes'] for p in h)
                people.append(dict(player_id=pid,name=h[-1]['player_name'],weight=weight,rate=rate,
                    observations=[dict(p,source_evidence=proofs[p['game_id'],p['side'],pid]) for p in h]))
            rate=sum(p['weight']*p['rate'] for p in people)/sum(p['weight'] for p in people) if people else np.nan
            sides[side]=dict(team_key=team,weighted_roster_players=len(weights),statistic_players=len(people),rate=rate,players=people)
        replay=sides['B']['rate']-sides['A']['rate'];expected=frozen.loc[g.game_id,'f_ctx_roster_key_passes_rate_diff']
        output.append(dict(game_id=g.game_id,cutoff=g.prediction_time,normalized_feature=replay,retained_feature=expected,
            match=bool(np.isclose(replay,expected,rtol=0,atol=1e-10,equal_nan=True)),sides=sides))
    result=dict(at_utc=stamp(),status='PASS' if all(r['match'] for r in output) else 'REPLAY_DIFFERENCE',
        feature_source_sha256=file_sha256(ROOT_OUT/'retained_models/soccer/soccer_features.parquet'),
        sources=evidence,records=output,current_lineup_used=False)
    dump(ROOT_OUT/'simulation_results/preprocessing_diagnosis/key_pass_source_trace.json',clean(result))
    print(json.dumps(dict(status=result['status'],games=[dict(game_id=r['game_id'],match=r['match'],feature=r['normalized_feature'],
        sides={s:dict(roster=d['weighted_roster_players'],statistic_players=d['statistic_players'],names=[p['name'] for p in d['players']],
            source_leagues=sorted({o['league'] for p in d['players'] for o in p['observations']})) for s,d in r['sides'].items()}) for r in output])),flush=True)


def validate_raw():
    result=json.loads((ROOT_OUT/'simulation_results/preprocessing_diagnosis/key_pass_source_trace.json').read_bytes())
    seen=set();checked=[]
    for game in result['records']:
        for side in game['sides'].values():
            for player in side['players']:
                for obs in player['observations']:
                    key=obs['game_id'],obs['player_id']
                    if key in seen:continue
                    seen.add(key);e=obs['source_evidence'];source=e.get('source')
                    if source:
                        path=PROJECT/source['raw_file'];assert file_sha256(path)==source['sha256']
                        raw=json.loads(path.read_bytes());assert str(raw['playerMetadata']['id'])==str(obs['official_player_id'])
                        pointer='/stats/totalAttAssist';value=raw['stats']['totalAttAssist']
                    else:
                        fields=json.loads(e['field_evidence_json']);v=fields.get('key_passes',fields.get('chances_created'))
                        rid=v['request_id'];pointer=v['pointer']
                        with read_db(PROJECT/'collected data/result/soccer_statistics.sqlite') as db:
                            row=db.execute('SELECT * FROM source_manifest WHERE request_id=?',(rid,)).fetchone()
                        if row is None:
                            with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
                                row=db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()
                                source=json.loads(row[0]) if row else None
                        else:source=dict(row)
                        assert source,rid
                        path=source['raw_file'].replace('\\','/');mapping=json.loads((PROJECT/'final_models/sources/path_map.json').read_bytes())
                        for old,new in mapping.items():
                            old,new=old.replace('\\','/'),new.replace('\\','/')
                            if path.startswith(old):path=new+path[len(old):];break
                        if path.startswith('data/'):path='collected data/'+path[5:]
                        path=PROJECT/path;assert file_sha256(path)==source['sha256'];value=json.loads(path.read_bytes())
                        for part in pointer.strip('/').split('/'):value=value[int(part)] if isinstance(value,list) else value[part]
                    assert value==obs['key_passes'],(key,value,obs['key_passes'])
                    checked.append(dict(game_id=key[0],player_id=key[1],value=value,pointer=pointer,source=source))
    proof=dict(at_utc=stamp(),status='PASS',raw_cells=len(checked),records=checked)
    dump(ROOT_OUT/'simulation_results/preprocessing_diagnosis/key_pass_raw_validation.json',proof)
    print(json.dumps(dict(status='PASS',raw_cells=len(checked))),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--validate-raw',action='store_true')
    validate_raw() if parser.parse_args().validate_raw else main()
