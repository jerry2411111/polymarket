"""Corroborate fragmented soccer histories with retained official biographies.

Only immutable identity attributes enter this crosswalk. No current club,
future appearance, career statistic or forthcoming lineup is a predictor.
"""
import collections,hashlib,json,re,unicodedata
from pathlib import Path
from html.parser import HTMLParser
import pandas as pd
from common import ROOT_OUT,PROJECT,PREVIOUS,read_db,dump,stamp

RUN=ROOT_OUT/'soccer_identity_v55'
SOURCE=ROOT_OUT/'player_pool_diagnosis_v53'


class JsonScripts(HTMLParser):
    def __init__(self):super().__init__();self.collect=False;self.parts=[];self.items=[]
    def handle_starttag(self,tag,attrs):
        values=dict(attrs)
        if tag=='script':self.collect=values.get('type')=='application/json' or values.get('id')=='__NEXT_DATA__';self.parts=[]
    def handle_data(self,data):
        if self.collect:self.parts.append(data)
    def handle_endtag(self,tag):
        if tag=='script' and self.collect:
            try:self.items.append(json.loads(''.join(self.parts)))
            except json.JSONDecodeError:pass
            self.collect=False


def decoded(value):
    return re.sub(r'\\u([0-9a-fA-F]{4})',lambda m:chr(int(m[1],16)),str(value))


def namekey(value):
    return ''.join(c for c in unicodedata.normalize('NFKD',decoded(value)).casefold() if c.isalnum() and not unicodedata.combining(c))


def full(value):
    words=re.split(r'[\s-]+',decoded(value).strip())
    return len(words)>=2 and all(len(namekey(w))>=2 for w in words)


def pointer(obj,path):
    for part in path.strip('/').split('/') if path!='/' else []:
        key=part.replace('~1','/').replace('~0','~');obj=obj[int(key)] if isinstance(obj,list) else obj[key]
    return obj


def read(source):
    raw=source['raw_file'].replace('\\','/')
    old='C:/Users/Jerry/Desktop/sentinent snake/'
    if raw.startswith(old):raw=raw[len(old):]
    mapping=json.loads((PROJECT/'final_models/sources/path_map.json').read_bytes())
    for a,b in mapping.items():
        a=a.replace('\\','/');b=b.replace('\\','/')
        if raw.startswith(a):raw=b+raw[len(a):];break
    path=PROJECT/raw;blob=path.read_bytes();assert hashlib.sha256(blob).hexdigest()==source['sha256']
    source=source|dict(raw_file=path.relative_to(PROJECT).as_posix())
    if blob.lstrip().startswith((b'{',b'[')):return json.loads(blob),source
    parser=JsonScripts();parser.feed(blob.decode('utf8'));return parser.items,source


def identity(kind,node):
    if kind=='pl':return str(node['id']['playerId']),[node['name'].get('display'),' '.join(filter(None,[node['name'].get('first'),node['name'].get('last')]))],node['dates'].get('birth')
    if kind=='fl1':return str(node.get('shortOptaId') if node.get('shortOptaId') is not None else node['id']),[' '.join(filter(None,[node.get('firstName'),node.get('lastName')]))],node.get('birthDate')
    if kind=='uefa':return str(node['id']),[node.get('internationalName'),node.get('translations',{}).get('name',{}).get('EN')],node.get('birthDate')
    if kind=='bun':return str(node['id']),[node['names'].get(k) for k in ['full','alias']],node.get('birth',{}).get('date')
    if kind=='sea':return str(node['playerId']),[' '.join(filter(None,[node.get('mediaFirstName'),node.get('mediaLastName')])),node.get('shortName')],node.get('dateOfBirth')
    if kind=='lal':return str(node['id']),[node.get('name'),' '.join(filter(None,[node.get('firstname'),node.get('lastname')]))],node.get('date_of_birth')
    raise ValueError(kind)


def catalog(target_rows=None,extra_uefa_sources=None):
    RUN.mkdir(exist_ok=True);p=pd.read_parquet(SOURCE/'players.parquet')
    if target_rows is None:
        review=json.loads((SOURCE/'same_name_identity_review.json').read_bytes())
        targets={pid for r in review for group in r['candidates'] for pid in group['player_ids']}
    else:targets=set(target_rows.player_id)
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
        if target_rows is None:
            cross={a:b for a,b,_ in db.execute('SELECT * FROM _eu_person_crosswalk')}
            for pid in p.player_id.unique():
                if pid in cross and cross[pid]!=pid:targets.update([pid,cross[pid]])
            target_rows=p[p.player_id.isin(targets)][['league','official_player_id','player_id']].drop_duplicates()
        assert target_rows.groupby(['league','official_player_id']).player_id.nunique().max()==1
        desired=target_rows.set_index(['league','official_player_id']).player_id.to_dict()
        rows=[];pending=[];seen=set();request_cache={}
        def source(rid):
            if rid not in request_cache:
                row=db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone();assert row,rid
                m=json.loads(row[0]);assert m['status']==200;request_cache[rid]=m
            return request_cache[rid]
        def add(league,native,kind,node,meta,path):
            key=(league,str(native));pid=desired.get(key)
            if pid is None or (key,meta['sha256']) in seen:return
            actual,names,dob=identity(kind,node)
            if kind!='lal':assert actual==str(native),(kind,actual,native)
            else:
                assets=set(re.findall(r'/(p\d+)/',json.dumps(node.get('squads',[]))))
                if str(native).startswith('p') and str(native) not in assets:return
                if not str(native).startswith('p'):return # No lineup-scoped name-only assignment.
            names=sorted({n for n in names if n and full(n)})
            if not dob or not names:return
            day=str(dob)[:10];pd.Timestamp(day);assert re.fullmatch(r'\d{4}-\d{2}-\d{2}',day)
            rows.append(dict(player_id=pid,league=league,official_player_id=str(native),identity_kind=kind,
                full_names_json=json.dumps(names,ensure_ascii=True),birth_date=day,profile_pointer=path,source_json=json.dumps(meta,sort_keys=True)))
            seen.add((key,meta['sha256']))
        # Re-read official profile bytes, not merely an old normalized mapping.
        for table,kind,league in [('_epl_people_biographies','pl','Premier League'),('_official_bundesliga_people_sources','bun','Bundesliga'),('_official_seriea_people_sources','sea','Serie A'),('_official_laliga_native_profile_revisions','lal','La Liga')]:
            for body, in db.execute('SELECT body FROM '+table):
                r=json.loads(body)
                if kind=='pl':
                    if r['kind']!='player' or not r.get('birth_date'):continue
                    native=r['official_person_id'];rid=r['biography_request_id'];path=r['sources']['birth_date'].rsplit('/dates/birth',1)[0]
                elif kind=='lal':
                    if r.get('status')!='ok':continue
                    native=r['source_person_id'].split(':',1)[1];rid=r['request_id'];path=r['json_pointer']
                else:
                    if r.get('status')!='ok':continue
                    native=r['person_id'];rid=r['request_id'];path=r.get('json_pointer','/')
                if (league,str(native)) not in desired:continue
                doc,meta=read(source(rid))
                if kind in ['bun','lal']:
                    options=[]
                    for i,d in enumerate(doc):
                        try:node=pointer(d,path);options.append((node,'/'+str(i)+path))
                        except (KeyError,TypeError,IndexError):pass
                    assert len(options)==1,(kind,native);node,path=options[0]
                else:node=pointer(doc,path)
                add(league,native,kind,node,meta,path)
        print(json.dumps(dict(stage='retained_profile_identities',evidence=len(rows))),flush=True)
        # One earliest retained native lineup source per player is sufficient
        # for a static identity proof; later performance fields are not read.
        found={('Ligue 1',r['official_player_id']) for r in rows if r['league']=='Ligue 1'}
        with read_db(ROOT_OUT/'soccer_additional.sqlite') as c:
            for body, in c.execute("SELECT body FROM games WHERE league='Ligue 1' ORDER BY game_id"):
                game=json.loads(body);needed=[r for r in game['players'] if ('Ligue 1',r['official_player_id']) in desired and ('Ligue 1',r['official_player_id']) not in found]
                if not needed:continue
                doc,meta=read(game['sources'][0])
                for r in needed:
                    side='away' if r['side']=='A' else 'home';path='/'+side+'/players/'+r['source_player_id']+'/playerIdentity'
                    add('Ligue 1',r['official_player_id'],'fl1',pointer(doc,path),meta,path)
                    if any(x['league']=='Ligue 1' and x['official_player_id']==r['official_player_id'] for x in rows):found.add(('Ligue 1',r['official_player_id']))
        print(json.dumps(dict(stage='retained_ligue_lineup_identities',evidence=len(rows))),flush=True)
        sources=[]
        with read_db(ROOT_OUT/'uefa_exposure.sqlite') as c:
            for body, in c.execute('SELECT body FROM games'):
                r=json.loads(body);sources.append(r['sources']['lineup'])
        with read_db(ROOT_OUT/'uefa_matchstats_v33/match_statistics.sqlite') as c:
            for body, in c.execute('SELECT body FROM games'):
                r=json.loads(body);sources.append(r['source_links']['lineup'])
        with read_db(ROOT_OUT/'uefa_passing.sqlite') as c:
            for body, in c.execute('SELECT body FROM reports'):
                r=json.loads(body)[0]['source']
                if r.get('lineup_raw_file'):sources.append(dict(raw_file=r['lineup_raw_file'],sha256=r['lineup_sha256'],url='https://match.uefa.com/v5/matches/'+json.loads(body)[0]['official_game_id']+'/lineups',retrieved_at_utc=r['retrieved_at_utc']))
        sources.extend(extra_uefa_sources or [])
        found=set();done=set()
        for meta in sources:
            league=meta.get('identity_league','UEFA Champions League')
            if (league,meta['sha256']) in done:continue
            done.add((league,meta['sha256']));doc,meta=read(meta)
            for side in ['awayTeam','homeTeam']:
                for group in ['field','bench']:
                    for i,item in enumerate(doc[side].get(group,[])):
                        node=item['player'];native=str(node['id']);key=(league,native)
                        if key not in desired or key in found:continue
                        add(key[0],native,'uefa',node,meta,f'/{side}/{group}/{i}/player')
                        if any(x['league']==key[0] and x['official_player_id']==native for x in rows):found.add(key)
        frame=pd.DataFrame(rows);frame.to_parquet(RUN/'identity_evidence.parquet',index=False)
        missing=target_rows.merge(frame[['league','official_player_id']].drop_duplicates().assign(has_evidence=True),on=['league','official_player_id'],how='left')
        missing=missing[missing.has_evidence.isna()].drop(columns='has_evidence');missing.to_csv(RUN/'identity_evidence_pending.csv',index=False)
        dump(RUN/'catalog_summary.json',dict(at_utc=stamp(),target_player_ids=len(targets),target_native_identities=len(target_rows),
            evidence_rows=len(frame),corroborated_native_identities=len(frame[['league','official_player_id']].drop_duplicates()),
            native_identities_needing_evidence=len(missing),raw_responses=len({json.loads(s)['sha256'] for s in frame.source_json}),
            new_requests=0,source_hash=hashlib.sha256((SOURCE/'players.parquet').read_bytes()).hexdigest()))
        print(json.dumps(json.loads((RUN/'catalog_summary.json').read_bytes())),flush=True)


def links():
    evidence=pd.read_parquet(RUN/'identity_evidence.parquet');p=pd.read_parquet(SOURCE/'players.parquet')
    conflicts=[];groups=collections.defaultdict(set);births=evidence.groupby('player_id').birth_date.agg(set).to_dict()
    for r in evidence.itertuples():
        if len(births[r.player_id])!=1:continue
        for name in json.loads(r.full_names_json):groups[namekey(name),r.birth_date].add(r.player_id)
    ids=set(p.player_id);parent={x:x for x in ids};members={x:{x} for x in ids};games={pid:set(g.game_id) for pid,g in p.groupby('player_id')};edges=[]
    def root(x):
        while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
        return x
    for (name,birth),group in sorted(groups.items()):
        group=sorted(group)
        for other in group[1:]:
            a,b=root(group[0]),root(other)
            if a==b:continue
            overlap=games[a]&games[b]
            if overlap:
                conflicts.append(dict(player_ids=sorted(members[a]|members[b]),reason='Proposed identity appears twice in same game; require source reconciliation before merging',game_ids=sorted(overlap),normalized_full_name=name,birth_date=birth));continue
            canonical=min(a,b);obsolete=max(a,b);parent[obsolete]=canonical
            members[canonical]|=members.pop(obsolete);games[canonical]|=games.pop(obsolete)
            edges.append(dict(player_a=group[0],player_b=other,normalized_full_name=name,birth_date=birth,
                method='Exact mechanically normalized official full name and birth date in native-ID-verified raw profiles/lineups; no same-game participant conflict. Inferred cross-source identity.'))
    mapping={pid:root(pid) for pid in sorted(ids)};cross=pd.DataFrame([dict(source_player_id=pid,canonical_player_id=cid) for pid,cid in mapping.items() if pid!=cid])
    cross.to_parquet(RUN/'identity_crosswalk.parquet',index=False);cross.to_csv(RUN/'identity_crosswalk.csv',index=False)
    dump(RUN/'identity_edges.json',edges);dump(RUN/'identity_conflicts.json',conflicts)
    raw=p.copy();p['source_model_player_id']=p.player_id;p['player_id']=p.player_id.map(mapping)
    assert not p.duplicated(['game_id','player_id']).any()
    assert len(p)==len(raw);pd.testing.assert_frame_equal(p.drop(columns=['player_id','source_model_player_id']),raw.drop(columns='player_id'),check_exact=True)
    p.to_parquet(RUN/'players_relinked.parquet',index=False)
    result=dict(at_utc=stamp(),source_player_ids=len(ids),canonical_player_ids=p.player_id.nunique(),linked_source_ids=len(cross),
        evidence_edges=len(edges),changed_player_rows=int(p.player_id.ne(p.source_model_player_id).sum()),same_game_link_conflicts=len(conflicts),
        conflicting_birth_ids=sum(len(b)>1 for b in births.values()),source_statistics_unchanged=True,source_clocks_unchanged=True)
    dump(RUN/'link_summary.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':catalog();links()
