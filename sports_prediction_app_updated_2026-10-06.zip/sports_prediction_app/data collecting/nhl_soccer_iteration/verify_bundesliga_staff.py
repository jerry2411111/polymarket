"""Retain official, game-scoped evidence for staff dismissals in match feeds.

The lineup route lists only head coaches. Named assistant/goalkeeping coaches
must not be counted as dismissed players. Evidence never joins by a name alone:
the match, side and native person ID are checked against the dated event feed.
"""
import hashlib,html,json,re,unicodedata,urllib.parse
from common import PROJECT,ROOT_OUT,OfficialClient,read_db,dump,stamp

RECORDS=[
    ('HIST_BUN_DFL-MAT-J03YM4','B','DFL-OBJ-00266V','Michael Gspurning','2024-05-22',
     'https://www.dfb.de/news/detail/ein-spiel-innenraumverbot-und-geldstrafe-fuer-unions-torwarttrainer-gspurning-261597',
     ['Michael Gspurning, den Torwarttrainer','18. Mai 2024']),
    ('HIST_BUN_DFL-MAT-J0403L','A','DFL-OBJ-00285X','Pascal Formann','2024-06-26',
     'https://www.vfl-wolfsburg.de/en/newsdetails/news-detail/detail/news/pascal-formann-to-remain-a-wolf',
     ['Pascal Formann','VfL goalkeeper coach']),
    ('HIST_BUN_DFL-MAT-J0405D','A','DFL-OBJ-00007Q','Stefan Buck','2024-08-16',
     'https://profis.eintracht.de/news/sehe-mich-immer-als-teamplayer-160420/',
     ['Stefan Buck beschreibt seine zwei Hauptaufgaben als Co-Trainer']),
    ('BUN_20250426_BVB_TSG','B','DFL-OBJ-J022QF','Uwe Hölzl','2024-11-15',
     'https://www.bundesliga.com/de/bundesliga/news/tsg-hoffenheim-trainer-christian-ilzer-sturm-graz-29730',
     ['Co-Trainer Dominik Deutschl und Uwe Hölzl nach Hoffenheim']),
    ('BUN_20260418_HSV_SVW','A','DFL-OBJ-002GES','Loïc Favé','2026-04-21',
     'https://www.dfb.de/news/zwei-spiele-sperre-fuer-hamburgs-otele',
     ['Loïc Favé, Co-Trainer','18. April 2026']),
    ('BUN_20260418_HSV_SVW','B','DFL-OBJ-J01AK3','Jan Hoepner','2026-04-20',
     'https://www.dfb.de/news/zwei-spiele-sperre-fuer-herthas-eichhorn',
     ['Jan Hoepner, Co-Trainer','Hamburger SV am 18. April 2026']),
]


def normal(value):
    text=' '.join(''.join(c for c in unicodedata.normalize('NFKD',value) if not unicodedata.combining(c)).lower().split())
    return re.sub(r'\s+([,.;:])',r'\1',text)


def document_text(blob):
    text=blob.decode('utf8',errors='replace')
    text=re.sub(r'<(script|style)\b[^>]*>.*?</\1>', ' ',text,flags=re.S|re.I)
    return html.unescape(re.sub('<[^>]+>',' ',text))


def main():
    OfficialClient.HOSTS.update(urllib.parse.urlsplit(r[5]).hostname for r in RECORDS)
    client=OfficialClient(per_second=1);verified=[]
    with read_db(ROOT_OUT/'bundesliga_minutes.sqlite') as c:games={gid:json.loads(b) for gid,b in c.execute('SELECT game_id,body FROM games')}
    for gid,side,pid,name,published,url,phrases in RECORDS:
        record=games[gid];event_source=record['sources'][0]
        raw=(PROJECT/event_source['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==event_source['sha256']
        document=json.loads(raw);events=document['liveBlogEntries'];events=events.items() if isinstance(events,dict) else enumerate(events)
        selected=[(str(k),e) for k,e in events if e.get('side')=={'A':'away','B':'home'}[side]
                  and e['entryType'] in ['redCard','yellowRedCard','secondYellowCard'] and e.get('detail',{}).get('person',{}).get('dflDatalibraryObjectId')==pid]
        assert len(selected)==1,(gid,pid)
        event_id,event=selected[0];assert normal(event['detail']['person']['name'])==normal(name)
        assert pid not in {r['official_player_id'] for r in record['players']}
        body,source=client.get(url,'Resolve native staff dismissal without removing player minutes: '+gid+' '+pid,'official_staff_identity',document=True)
        if body is None:
            verified.append(dict(game_id=gid,side=side,person_id=pid,state='request_failed',source=source));continue
        text=normal(document_text(body));missing=[v for v in phrases if normal(v) not in text]
        assert not missing,(pid,missing)
        verified.append(dict(game_id=gid,side=side,person_id=pid,person_name=name,event_id=event_id,role='coaching staff',
            source_published_date=published,required_identity_phrases=phrases,source=source,event_source=event_source,state='verified',
            scope='Only this native person/side/game dismissal; no general name-based player classification.'))
    dump(ROOT_OUT/'bundesliga_verified_staff.json',dict(at_utc=stamp(),records=verified))
    print(json.dumps([{k:r[k] for k in ['game_id','person_id','state']} for r in verified]),flush=True)


if __name__=='__main__':main()
