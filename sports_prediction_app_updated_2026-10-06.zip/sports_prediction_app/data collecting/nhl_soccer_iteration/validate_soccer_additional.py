"""Raw-field and identity verification of the real enrichment pilot."""
import collections,hashlib,json
from common import ROOT_OUT,PROJECT,read_db,dump,stamp
from soccer_additional_facts import BUN_PLAYER,BUN_TEAM,LIGUE_FIELDS,PARSER_VERSION
from laliga_retained_facts import page_props,PARSER_VERSION as LALIGA_VERSION


def main():
    counts=collections.Counter();examples=[]
    with read_db(ROOT_OUT/'soccer_additional.sqlite') as c:records=[json.loads(r[0]) for r in c.execute("SELECT body FROM games WHERE (league!='La Liga' AND json_extract(body,'$.parser_version')=?) OR (league='La Liga' AND json_extract(body,'$.parser_version')=?)",(PARSER_VERSION,LALIGA_VERSION))]
    seen=collections.Counter()
    for g in records:
        raw={}
        for source in g['sources']:
            b=(PROJECT/source['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==source['sha256']
            raw[source['url']]=page_props(b) if g['league']=='La Liga' else json.loads(b);counts['source_hashes_checked']+=1
        for r in g['players']:
            assert r['available_at_utc'] and r['date']==g['date']
            source=raw[r['source']['url']]
            if g['league']=='Ligue 1':
                side='away' if r['side']=='A' else 'home';p=source[side]['players'][r['source_player_id']]
                assert r['minutes']==p.get('minutesPlayed') and r['goals']==p.get('goals')
                assert r['started']==p.get('startedMatch') and r['played']==p.get('playedMatch')
                assert r['opta_player_id']==(str(p['playerIdentity']['shortOptaId']) if p['playerIdentity'].get('shortOptaId') is not None else None)
                for field,native in LIGUE_FIELDS.items():assert r[field]==(p.get('stats') or {}).get(native)
            elif g['league']=='Bundesliga':
                for native,field in BUN_PLAYER.items():
                    fact=(source.get('playerRankings',{}).get(native) or {}).get(r['official_player_id'])
                    assert r[field]==(fact.get('value') if fact else None)
                    if fact:assert fact['club']['dflDatalibraryClubId']==r['team_id']
            else:
                side='away' if r['side']=='A' else 'home'
                assert str(source['match']['id'])==str(g['official_game_id'])
                lineup=source['data']['lineups'][side]
                candidates=[p for key in ['starts','subs'] for p in lineup[key] if str(p['id'])==r['source_lineup_id']]
                assert len(candidates)==1 and candidates[0]['person']['name']==r['player_name']
                assert r['started']==any(str(p['id'])==r['source_lineup_id'] for p in lineup['starts'])
                if r['minutes'] is not None:assert 0<=r['minutes']<=90
                if r['played'] is False:assert r['minutes'] in [0,None]
                if not g['goal_counts_reconcile']:assert r['goals'] is None
                for event in g.get('excluded_staff_events',[]):
                    original=source['events'][event['event_index']]
                    assert original['match_event_kind']['collection']=='booking'
                    assert any(m['person']['name']==event['name'] for li in source['data']['lineups'].values() for m in li.get('manager',[]))
            counts[g['league']+'_player_rows']+=1
        if g['league']=='Bundesliga':
            for r in g['teams']:
                source=raw[r['source']['url']];native='awayValue' if r['side']=='A' else 'homeValue'
                for metric,field in BUN_TEAM.items():assert r[field]==(source.get(metric) or {}).get(native)
        seen[g['league']]+=1;counts[g['league']+'_games']+=1
        if seen[g['league']]<=4:
            r=next(r for r in g['players'] if r.get('played',True))
            examples.append(dict(league=g['league'],game_id=g['game_id'],date=g['date'],player_id=r['official_player_id'],player_name=r['player_name'],team_id=r['team_id'],
                endpoint=r['source']['url'],raw_file=r['source']['raw_file'],values={k:r.get(k) for k in (['distance_covered_km','maximum_speed_kmh','challenges_won'] if g['league']=='Bundesliga' else ['minutes','goals','passes','recoveries'])},raw_normalized_match=True,derived_minutes=g['league']=='La Liga'))
    assert all(seen[league]>=3 for league in ['Bundesliga','Ligue 1','La Liga'])
    dump(ROOT_OUT/'soccer_additional_validation.json',dict(at_utc=stamp(),counts=dict(counts),examples=examples,
         temporal_scope='These are completed-game observations, usable only for later fixtures. Current-match postgame player measurements never enter that match forecast.',
         source_vintage='Raw retrieval dates and available source update dates are retained. Original unrevised publication vintages cannot be guaranteed by retrospective official endpoints.'))
    print(json.dumps(dict(counts)),flush=True)


if __name__=='__main__':main()
