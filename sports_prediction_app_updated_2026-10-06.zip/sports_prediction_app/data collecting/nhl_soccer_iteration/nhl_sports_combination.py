"""One past-fitted mixture of the existing independent NHL sports forecasts."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from sklearn.metrics import log_loss, accuracy_score, brier_score_loss

from common import ROOT_OUT, REPORTS, dump, stamp, file_sha256

LABEL='nhl_sports_combination'
RESULT=ROOT_OUT/'simulation_results'/LABEL


def initialize():
    RESULT.mkdir(exist_ok=True)
    selection=json.loads((ROOT_OUT/'simulation_results/staking_model_selection/selection.json').read_bytes())['selections']['nhl']
    plan=dict(at_utc=stamp(),source=selection,
        diagnosis='The regulation-goal model beats direct logistic in2024, while their mean improves2025probability scores. Test one adaptive combination rather than choose a retrospective year-specific model.',
        estimator='Monthly expanding convex mixture w*primary+(1-w)*secondary. Fit one weight on earlier settled out-of-fit sports forecasts. Exact bounds0and1compete with bounded optimum. No market prices or returns.',
        training='Underlying models use expanding2021+history. Combination archive starts2024. Until100prior forecasts and10of each class, preserve primary weight1. First readiness and every training label clock are recorded.',
        gate='2024/25pooled logloss and Brier improve over primary,2025logloss improves, pooled winner accuracy>=52%. No parameter grid.',
        strategy='Only after probability gate: keep original pre12closest-prior quotes, one expected-log-growth outcome, primary/secondary relative advantage>=10%,flat$20,annual$2000cash-only. Combination replaces only primary. Select providers on2025higherSharpe and positive return,2024Sharpe no worse.',
        evaluation='2026is repeatedly inspected retrospective rolling evidence, not untouched holdout.',app_changed=False)
    path=RESULT/'plan.json'
    if path.exists(): assert all(json.loads(path.read_bytes())[k]==v for k,v in plan.items() if k!='at_utc')
    else: dump(path,plan)
    return plan


def source(evaluation=False):
    spec=initialize()['source'];path=ROOT_OUT/spec['source']
    assert file_sha256(path)==spec['source_sha256']
    parts=[pd.read_parquet(path)]
    if evaluation:parts.append(pd.read_parquet(path.with_name('evaluation_predictions.parquet')))
    p=pd.concat(parts,ignore_index=True);p=p[p.variant.eq(spec['variant'])].copy()
    assert p.game_id.is_unique and p.train_label_max.lt(p.prediction_time).all()
    assert p.calibration_label_max.lt(p.prediction_time).all()
    return p


def rolling(p):
    out=[];fits=[]
    for fold,test in p.groupby(p.prediction_time.dt.strftime('%Y-%m')):
        boundary=pd.Timestamp(fold+'-01',tz='UTC');train=p[p.available_time.lt(boundary)]
        counts=train.target.value_counts();ready=len(train)>=100 and len(counts)==2 and counts.min()>=10
        weight=1.
        if ready:
            y=train.target.to_numpy(int);a=train.p1.to_numpy();b=train.second_p1.to_numpy()
            def loss(w):
                pr=np.clip(w*a+(1-w)*b,1e-12,1-1e-12)
                return float(np.mean(-y*np.log(pr)-(1-y)*np.log1p(-pr)))
            opt=minimize_scalar(loss,bounds=(0,1),method='bounded');assert opt.success
            _,weight=min((loss(w),w) for w in [0.,float(opt.x),1.])
        f=test.copy();f['combination_p1']=weight*f.p1+(1-weight)*f.second_p1
        f['primary_weight']=weight;f['combination_ready']=ready
        f['combination_last_label']=train.available_time.max();f['combination_boundary']=boundary
        assert not len(train) or train.available_time.max()<test.prediction_time.min()
        out.append(f);fits.append(dict(fold=fold,ready=bool(ready),prior_games=len(train),games=len(test),primary_weight=weight,
            last_label=None if train.empty else str(train.available_time.max())))
    f=pd.concat(out,ignore_index=True)
    for c in ['combination_last_label','combination_boundary']:f[c]=pd.to_datetime(f[c],utc=True,format='mixed').astype('datetime64[ns, UTC]')
    return f,pd.DataFrame(fits)


def metrics(p):
    rows=[]
    for label,col in [('primary','p1'),('secondary','second_p1'),('combination','combination_p1')]:
        for year,f in [('pooled',p)]+list(p.groupby(p.prediction_time.dt.year)):
            y=f.target.to_numpy(int);pr=f[col].to_numpy()
            rows.append(dict(variant=label,year=year,games=len(f),accuracy=accuracy_score(y,pr>=.5),
                logloss=log_loss(y,np.c_[1-pr,pr],labels=[0,1]),brier=brier_score_loss(y,pr)))
    return pd.DataFrame(rows)


def accounts(p,stage,providers=None):
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    transfer.RESULT=RESULT;quotes=quote_inputs(RESULT/(stage+'_quote_quality.json'),revision='closest_v62')
    rows=[];bets=[];days=[];checks=[]
    for variant in ['primary','combination']:
        f=p.copy()
        if variant=='combination':f['p1']=f.combination_p1;f['p0']=1-f.p1
        normalized=transfer.normalize('nhl',f,quotes,True);lookup=f.set_index('game_id').loc[normalized.game_id]
        normalized['secondary_probability']=np.where(normalized.side.eq(0),lookup.second_p0,lookup.second_p1)
        normalized=normalized[np.minimum(normalized.probability,normalized.secondary_probability)/normalized.price>=1.10]
        for provider,g in normalized.groupby('provider'):
            if providers is not None and provider not in providers:continue
            for year in sorted(p.prediction_time.dt.year.unique()):
                m,b,l,d=engine.simulate(g,int(year),'all_selected_outcomes','flat20_cash_only',5.,2000.)
                key=dict(sport='nhl',provider=provider,variant=variant,year=int(year))
                rows.append(key|m);checks.append(key|engine.validate(b,l,d,'flat20_cash_only',5.,2000.))
                if len(b):bets.append(b.assign(**key))
                days.append(d.assign(**key))
    a=pd.DataFrame(rows);a.to_csv(RESULT/(stage+'_annual.csv'),index=False)
    if bets:pd.concat(bets,ignore_index=True).to_parquet(RESULT/(stage+'_bets.parquet'),index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/(stage+'_daily.parquet'),index=False)
    dump(RESULT/(stage+'_cash_validation.json'),dict(status='PASS',checks=checks))
    return a


def run():
    assert not (RESULT/'validation.json').exists()
    p,fits=rolling(source());p.to_parquet(RESULT/'development_predictions.parquet',index=False);fits.to_csv(RESULT/'rolling_weights.csv',index=False)
    prefix,_=rolling(source()[lambda f:f.prediction_time.lt(pd.Timestamp('2025-01-01',tz='UTC'))])
    pd.testing.assert_frame_equal(prefix.set_index('game_id').sort_index(),p.set_index('game_id').loc[prefix.game_id].sort_index(),check_exact=True)
    m=metrics(p);m.to_csv(RESULT/'development_metrics.csv',index=False);s=m.set_index(['variant','year'])
    probability_gate=bool(all(s.loc[('combination','pooled'),c]<s.loc[('primary','pooled'),c] for c in ['logloss','brier']) and
        s.loc[('combination',2025),'logloss']<s.loc[('primary',2025),'logloss'] and s.loc[('combination','pooled'),'accuracy']>=.52)
    choices={};a=None
    if probability_gate:
        a=accounts(p,'development')
        for provider,g in a.groupby('provider'):
            g=g.set_index(['variant','year']);x,y=g.loc[('combination',2025)],g.loc[('primary',2025)]
            choices[provider]=bool(x.sharpe>y.sharpe and x.return_pct>0)
            if ('primary',2024) in g.index and pd.notna(g.loc[('primary',2024),'sharpe']):
                choices[provider]&=bool(g.loc[('combination',2024),'sharpe']>=g.loc[('primary',2024),'sharpe'])
    selection=dict(at_utc=stamp(),probability_gate=probability_gate,providers=choices,adopted=False)
    dump(RESULT/'selection.json',selection)
    if any(choices.values()):
        both,_=rolling(source(True));earlier=both[both.prediction_time.dt.year.lt(2026)]
        pd.testing.assert_frame_equal(earlier.set_index('game_id').sort_index(),p.set_index('game_id').sort_index(),check_exact=True)
        new=both[both.prediction_time.dt.year.eq(2026)].copy();new.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
        metrics(new).to_csv(RESULT/'evaluation_metrics.csv',index=False)
        accounts(new,'evaluation',[k for k,v in choices.items() if v])
    dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),selection=selection,
        earlier_prefix_replays=len(prefix),future_labels_excluded=True,market_data_excluded_from_probability_fit=True,
        single_weight_fits=len(fits),evaluated2026=any(choices.values()),app_changed=False))
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL]=dict(plan=initialize(),selection=selection);dump(path,old)
    if a is not None:
        parts=[a];ev=RESULT/'evaluation_annual.csv'
        if ev.exists():parts.append(pd.read_csv(ev))
        path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/annual.csv'
        pd.concat([old[old.source_result_file.ne(key)],pd.concat(parts).assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    print(m.to_string(index=False),flush=True);print(json.dumps(selection),flush=True)


def finish():
    from final_pipeline import cleanup,validate
    proof=json.loads((RESULT/'validation.json').read_bytes());assert proof['status']=='PASS'
    m=pd.read_csv(RESULT/'development_metrics.csv');selection=proof['selection']
    def table(f):return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(str(x) for x in row)+' |' for row in f.itertuples(index=False,name=None)])
    lines=['# NHL sports-model combination','',
        'The goal-based model leads in 2024 probability quality; the direct classifier catches up in 2025. A single expanding, monthly mixture weight tests whether their different errors provide complementary information. All underlying models train on earlier history from 2021; the combination archive begins in 2024. Before 100 earlier forecasts and ten examples of each outcome exist, the original primary forecast is preserved. No price or return enters the weight fit.','',
        'Each fitted weight uses only results known before the monthly boundary. Removing all 2025 data reproduces every 2024 combined forecast exactly. The model gate requires lower pooled logloss and Brier, lower 2025 logloss and at least 52% pooled winner accuracy. Selection: '+json.dumps(selection)+'.','',table(m),'']
    for stage in ['development','evaluation']:
        path=RESULT/(stage+'_annual.csv')
        if path.exists():
            assert json.loads((RESULT/(stage+'_cash_validation.json')).read_bytes())['status']=='PASS'
            a=pd.read_csv(path);lines +=[stage.capitalize()+' unchanged fixed-$20 accounts:', '',table(a[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'']
    if (RESULT/'margin_validation.json').exists():
        margin=json.loads((RESULT/'margin_validation.json').read_bytes());assert margin['status']=='PASS'
        lines+=['Separate strategy test using the unchanged original forecasts: replace the 10% relative advantage with the existing five-percentage-point absolute allowance. Require min(primary,secondary) - price >=0.05, keeping the fixed $20 stake and original side selection. This tests whether a relative hurdle accepts small absolute differences on cheap outcomes. No margin sweep. Each provider must improve 2025 Sharpe with positive return and no worse drawdown or 2024 Sharpe before a new 2026 evaluation. Selection: '+json.dumps(margin['choices'])+'.','',
            table(pd.read_csv(RESULT/'margin_annual.csv')[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'']
    lines+=['Betting, when the model qualifies, keeps the existing pre-12 timing, closest preceding quote no older than 24 hours, both-model 10% relative-advantage requirement, one outcome and annual $2,000 cash-only account. Combined probability replaces only the primary probability. Daily calendar Sharpe includes idle days and uses sqrt(365.25). Providers remain separate, no added costs. Polymarket token prices are historical references, not verified executable US asks.','',
        '2026 remains repeatedly inspected retrospective rolling research, not an untouched holdout. No app or retained-model change. Reproduce nhl_sports_combination.py run then finish; forecasts, monthly weights, proper scores and decisions are retained. No new source calls or fitted model packages are created.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    cleanup();check=validate();receipt=dict(status='PASS',at_utc=stamp(),validation=proof,app_validation=check,adopted=False,goal_achieved=False)
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(path.read_bytes());m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']),latest_simulation_update=receipt);dump(path,m)


def margin():
    """Try the previously used absolute allowance on original NHL forecasts."""
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    assert not json.loads((RESULT/'selection.json').read_bytes())['probability_gate']
    assert not (RESULT/'margin_validation.json').exists()
    dump(RESULT/'margin_plan.json',dict(at_utc=stamp(),
        diagnosis='The10%relative hurdle permits small absolute advantages on cheap outcomes. Test the existing five-point price-error allowance instead, without fitting a new threshold.',
        rule='min(primary,secondary)-price>=0.05; fixed20cash-only, existing one-side choice and pre12quote rules. Compare original10%relative hurdle on the same forecast population.',
        models='Unchanged original primary and secondary; rejected learned mixture is not used.',
        gate='2025higherSharpe,positive return,no worse drawdown;2024Sharpe no worse where defined. No threshold or stake search.',
        evaluation='2026 retrospective rolling only for qualifying providers.',app_changed=False))
    quotes=quote_inputs(RESULT/'margin_quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    annual=[];bets=[];days=[];checks=[];choices={}
    for stage in ['development','evaluation']:
        if stage=='evaluation' and not any(choices.values()):break
        p=source(stage=='evaluation')
        if stage=='evaluation':p=p[p.prediction_time.dt.year.eq(2026)]
        f=transfer.normalize('nhl',p,quotes,True);ix=p.set_index('game_id').loc[f.game_id]
        f['secondary_probability']=np.where(f.side.eq(0),ix.second_p0,ix.second_p1)
        lower=np.minimum(f.probability,f.secondary_probability)
        for variant,mask in [('relative10',lower/f.price>=1.10),('absolute5',lower-f.price>=.05)]:
            for provider,h in f[mask].groupby('provider'):
                if stage=='evaluation' and not choices.get(provider):continue
                for year in sorted(p.prediction_time.dt.year.unique()):
                    m,b,l,d=engine.simulate(h,int(year),'all_selected_outcomes','flat20_cash_only',5.,2000.)
                    key=dict(sport='nhl',provider=provider,variant=variant,year=int(year))
                    annual.append(key|m);checks.append(key|engine.validate(b,l,d,'flat20_cash_only',5.,2000.))
                    if len(b):bets.append(b.assign(**key))
                    days.append(d.assign(**key))
        if stage=='development':
            a=pd.DataFrame(annual)
            for provider,h in a.groupby('provider'):
                h=h.set_index(['variant','year']);x,y=h.loc[('absolute5',2025)],h.loc[('relative10',2025)]
                passed=x.sharpe>y.sharpe and x.return_pct>0 and x.max_drawdown_pct<=y.max_drawdown_pct
                if pd.notna(h.loc[('relative10',2024),'sharpe']):passed &= h.loc[('absolute5',2024),'sharpe']>=h.loc[('relative10',2024),'sharpe']
                choices[provider]=bool(passed)
            dump(RESULT/'margin_selection.json',dict(at_utc=stamp(),choices=choices,adopted=False))
    a=pd.DataFrame(annual);a.to_csv(RESULT/'margin_annual.csv',index=False)
    positions=pd.concat(bets,ignore_index=True);positions.to_parquet(RESULT/'margin_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'margin_daily.parquet',index=False)
    attribution=[]
    for (provider,year),group in positions.groupby(['provider','year']):
        before=group[group.variant.eq('relative10')].set_index('game_id');after=group[group.variant.eq('absolute5')].set_index('game_id')
        common=before.index.intersection(after.index)
        assert np.allclose(before.loc[common,['side','price','stake','profit']],after.loc[common,['side','price','stake','profit']],rtol=0,atol=1e-10)
        for label,part in [('removed',before.loc[before.index.difference(after.index)]),('added',after.loc[after.index.difference(before.index)])]:
            attribution.append(dict(provider=provider,year=int(year),change=label,bets=len(part),profit=float(part.profit.sum()),
                mean_probability=float(part.probability.mean()) if len(part) else None,win_rate=float(part.won.mean()) if len(part) else None,
                mean_price=float(part.price.mean()) if len(part) else None))
    pd.DataFrame(attribution).to_csv(RESULT/'margin_change_attribution.csv',index=False)
    dump(RESULT/'margin_validation.json',dict(status='PASS',at_utc=stamp(),choices=choices,checks=checks,
        original_forecasts_unchanged=True,common_positions_exact=True,evaluated2026=any(choices.values()),adopted=False))
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/margin_annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL+'/margin']=dict(plan=json.loads((RESULT/'margin_plan.json').read_bytes()),choices=choices,adopted=False);dump(path,old)
    print(a[['provider','variant','year','funded_games','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['run','margin','finish']);globals()[parser.parse_args().stage]()
