"""Supplement league player rows using independently verified dated identities.

Never propagate a Maker UUID-to-person assumption between fixtures. Reused or
mutable club identities can refer to different dated native league players.
Unresolved supplementary records remain in final raw source tables and the
join audit; an existing complete league participant set is never duplicated.
"""
import collections
import hashlib
import json
import re

import pandas as pd

from common import PROJECT,ROOT_OUT,read_db,dump,stamp
from laliga_retained_facts import page_props,namekey


def uuid_conflicts(games,evidence):
    """Describe conflicting static links without using them to merge people."""
    links=collections.defaultdict(set)
    for game in games:
        for row in game['players']:
            if row['opta_player_id']:links[row['maker_player_id']].add(row['opta_player_id'])
    for row in evidence.itertuples():
        if row.league_official_player_id.startswith('p'):
            links[row.maker_player_id].add(row.league_official_player_id)
    return {key:sorted(value) for key,value in links.items() if len(value)>1}


def reconcile(games,fresh,players,out):
    with read_db(ROOT_OUT/'soccer_additional.sqlite') as db:
        direct={r['game_id']:r for r in [json.loads(b) for b, in db.execute("SELECT body FROM games WHERE league='La Liga'")]}
    old=players.set_index(['game_id','side','official_player_id'])
    lookups={};sources={};checked=[];evidence=[];issues=[];participation=[]
    original={r['game_id']:r for r in games}
    for game in games:
        gid=game['game_id']
        if gid not in direct:continue
        report=direct[gid];source=report['sources'][0]
        blob=(PROJECT/source['raw_file']).read_bytes();assert hashlib.sha256(blob).hexdigest()==source['sha256']
        page=page_props(blob);match=page['match'];meta=game['match']
        assert str(match['id'])==str(meta['official_game_id'])
        assert [match['away_score'],match['home_score']]==[meta['scoreA'],meta['scoreB']]
        sides={}
        for side,native in [('A','away'),('B','home')]:
            assert str(match[native+'_team']['id'])==str(meta['team'+side+'_id'])
            roster=[]
            for group in ['starts','subs']:
                for i,row in enumerate(page['data']['lineups'][native][group]):
                    ids=set(re.findall(r'/(p\d+)/',str(row.get('photos',{}))));assert len(ids)<=1
                    pid=next(iter(ids)) if ids else 'lineup:'+str(match['id'])+':'+str(row['id'])
                    person=row['person'];labels=[person.get(k) for k in ['name','nickname']]
                    labels+=[' '.join([person.get('firstname') or '',person.get('lastname') or ''])]
                    names={namekey(s) for s in labels if s}
                    roster.append(dict(official_player_id=pid,names=names,raw_name=person['name'],
                        shirt_number=row.get('shirt_number'),started=group=='starts',
                        pointer='/props/pageProps/data/lineups/'+native+'/'+group+'/'+str(i)))
            assert len({r['official_player_id'] for r in roster})==len(roster)
            sides[side]=roster
        lookups[gid]=sides;sources[gid]=source;checked.append(gid)
    keep=[];links=collections.defaultdict(set)
    for i,row in fresh.iterrows():
        gid=row.game_id;side=row.side;native=row.official_player_id
        if gid not in lookups:
            # Only this fixture's explicit Opta asset ID is used. A UUID with
            # no cross-source identity remains in its native namespace.
            keep.append(i)
            continue
        roster=lookups[gid][side]
        exact=[r for r in roster if r['official_player_id']==native and not native.startswith('maker:')]
        if exact:
            found=exact;basis='Same-game explicit Opta asset ID in both official responses'
        else:
            found=[r for r in roster if namekey(row.player_name) in r['names'] and
                r['shirt_number']==row.shirt_number and r['started']==bool(row.started)]
            basis='Unique exact full name or explicit nickname plus same dated team, shirt and starter status'
        if len(found)!=1:
            issues.append(dict(game_id=gid,side=side,maker_player_id=row.maker_player_id,player_name=row.player_name,
                shirt_number=row.shirt_number,reason='Supplementary identity needs additional evidence; complete direct league participant record preserved',
                source_json=json.dumps(dict(maker=original[gid]['source'],league=sources[gid]),sort_keys=True)))
            continue
        match=found[0];pid=match['official_player_id'];key=(gid,side,pid)
        assert key in old.index,'Verified direct participant missing from source merge'
        assert match['started']==bool(row.started),'Contradictory dated starter status'
        if match['shirt_number']!=row.shirt_number:
            issues.append(dict(game_id=gid,side=side,maker_player_id=row.maker_player_id,player_name=row.player_name,
                shirt_number=row.shirt_number,reason='Native ID matches but dated shirt differs; retain direct source pending review',
                source_json=json.dumps(dict(maker=original[gid]['source'],league=sources[gid]),sort_keys=True)))
            continue
        fresh.at[i,'official_player_id']=pid;keep.append(i)
        prior=old.loc[key]
        if pd.notna(prior.played) and bool(prior.played)!=bool(row.played):
            # Maker False means it supplies no entry evidence; it is not an
            # explicit assertion of nonparticipation. A complete direct league
            # substitution history can establish the appearance independently.
            direct_person=[p for p in direct[gid]['players'] if p['side']==side and p['official_player_id']==pid]
            assert len(direct_person)==1
            person=direct_person[0]
            assert direct[gid]['minutes_complete'] and person['played'] is True
            assert bool(prior.played) and not bool(row.played) and pd.isna(row.minutes)
            assert person['minutes']>0 and prior.minutes>0
            fresh.at[i,'played']=True
            participation.append(dict(game_id=gid,side=side,maker_player_id=row.maker_player_id,
                league_official_player_id=pid,maker_played=False,resolved_played=True,
                league_regulation_minutes=person['minutes'],source_json=json.dumps(sources[gid],sort_keys=True),
                basis='Complete official league substitution sequence proves participation; Maker has no entry or minutes evidence'))
        links[row.maker_player_id].add(pid)
        evidence.append(dict(game_id=gid,side=side,maker_player_id=row.maker_player_id,
            maker_reported_native_id=native,league_official_player_id=pid,maker_name=row.player_name,
            league_name=match['raw_name'],shirt_number=row.shirt_number,started=bool(row.started),basis=basis,
            maker_pointer=row.maker_lineup_pointer,league_pointer=match['pointer'],
            source_json=json.dumps(dict(maker=original[gid]['source'],league=sources[gid]),sort_keys=True)))
    linked=fresh.loc[keep].copy()
    assert not linked.duplicated(['game_id','side','official_player_id']).any()
    for gid in checked:
        have=set(linked[linked.game_id.eq(gid)].set_index(['side','official_player_id']).index)
        prior=set(players[players.game_id.eq(gid)].set_index(['side','official_player_id']).index)
        assert have.issubset(prior),'Supplement cannot duplicate the direct participant set'
    ev=pd.DataFrame(evidence);pending=pd.DataFrame(issues)
    ev.to_parquet(out/'maker_dated_identity_evidence.parquet',index=False)
    pd.DataFrame(participation).to_csv(out/'maker_dated_participation_reconciliation.csv',index=False)
    pending.to_csv(out/'maker_dated_identity_pending.csv',index=False)
    conflict=uuid_conflicts(games,ev)
    audit=dict(status='PASS',at_utc=stamp(),direct_game_ids=checked,
        verified_dated_links=len(ev),pending_supplementary_rows=len(pending),
        participation_proven_by_complete_direct_report=len(participation),
        mutable_or_reused_uuid_native_conflicts=conflict,dated_only_identity=True,
        original_direct_player_records_retained=True,raw_supplementary_rows_preserved=True,
        unknown_stats_not_replaced_with_zero=True)
    dump(out/'maker_dated_identity_validation.json',audit)
    return linked.drop(columns=['maker_player_id','shirt_number','maker_lineup_pointer']),audit
