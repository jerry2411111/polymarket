"""Retain official native-team/franchise evidence for historical identity repair."""
from common import OfficialClient, ROOT_OUT, dump, stamp


def main():
    data, source = OfficialClient().get(
        'https://api.nhle.com/stats/rest/en/team',
        'Verify Utah native team IDs and shared franchise identity', 'nhl_team_identity')
    rows = [r for r in data['data'] if r['id'] in [53, 59, 68]]
    ids = {r['id']:r for r in rows}
    assert ids[59]['franchiseId'] == ids[68]['franchiseId'] == 40
    assert ids[53]['franchiseId'] != 40
    dump(ROOT_OUT/'nhl_utah_identity_evidence.json', dict(
        at_utc=stamp(), rows=rows, source=source,
        dated_announcement_url='https://www.nhl.com/utah/news/utah-s-nhl-franchise-officially-named-the-utah-mammoth-release-5-7-25',
        announcement_date='2025-05-07', conservative_available_at_utc='2025-05-08T00:00:00Z',
        status='Evidence collected; prior model snapshots unchanged',
        interpretation='Native IDs59 and68 share franchise40. Arizona53 is franchise28, so no automatic franchise-history merge is justified. A dated player transfer can preserve player history separately.'))


if __name__=='__main__':main()
