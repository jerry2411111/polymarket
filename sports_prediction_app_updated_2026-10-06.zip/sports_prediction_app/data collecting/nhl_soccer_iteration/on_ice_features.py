"""Causal role-specific on-ice quality of the recently observed NHL roster."""
import collections,json
import numpy as np
import pandas as pd
from common import ROOT_OUT,OUT,PREVIOUS,read_db,dump,stamp

def main(base=None, games=None, history_keys=None, save=True):
    with read_db(ROOT_OUT/'nhl_on_ice.sqlite') as c:records=[json.loads(b) for b, in c.execute('SELECT body FROM games')]
    if games is None:
        with read_db(PREVIOUS/'expanded.sqlite') as c:games=pd.read_sql_query("SELECT * FROM nhl_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30' AND phase IN ('Regular Season','Playoffs')",c)
    else:games=games.copy()
    keys={}
    for r in games.itertuples():
        for side,native in zip(['A','B'],json.loads(r.native_team_ids_json)):
            keys[(r.game_id,side)]=history_keys[(r.game_id,side)] if history_keys is not None else str(native)
    groups=collections.defaultdict(list)
    for game in records:
        for r in game['players']:
            if (r['game_id'],r['side']) not in keys:continue
            r=dict(r);r['available_time']=pd.Timestamp(r['available_at_utc']);r['team_key']=keys[(r['game_id'],r['side'])]
            groups[(r['game_id'],r['side'])].append(r)
    queue=sorted(groups.values(),key=lambda x:x[0]['available_time']);at=0
    team_history=collections.defaultdict(lambda:collections.deque(maxlen=30));ph=collections.defaultdict(lambda:collections.deque(maxlen=30));lastteam={};out=[]
    games.prediction_time=pd.to_datetime(games.prediction_time,utc=True)
    fields=['mapped_attempts_for','mapped_attempts_against','mapped_goals_for','mapped_goals_against','mapped_model_xg_for','mapped_model_xg_against']
    for g in games.sort_values(['prediction_time','game_id']).to_dict('records'):
        cutoff=g['prediction_time']
        while at<len(queue) and queue[at][0]['available_time']<cutoff:
            rs=queue[at];at+=1;team=rs[0]['team_key'];team_history[team].append(rs)
            for r in rs:ph[r['official_player_id']].append(r);lastteam[r['official_player_id']]=team
        sides=[];sources=[]
        for side in ['A','B']:
            team=keys[(g['game_id'],side)];history=list(team_history[team]);weights=collections.defaultdict(float)
            for rs in history[-5:]:
                for r in rs:
                    if lastteam[r['official_player_id']]==team:weights[r['official_player_id']]+=r['shift_seconds']
            f={};roles=collections.defaultdict(list)
            for pid,w in weights.items():
                h=list(ph[pid]);roles['defence' if h[-1]['position']=='D' else 'forward'].append((pid,w,h));sources.extend(r['available_time'] for r in h)
            for role in ['forward','defence']:
                for field in fields:
                    for span in [8,30]:
                        values=[]
                        for pid,w,h in roles[role]:
                            valid=[r for r in h[-span:] if r[field] is not None and r['shift_seconds']>0]
                            if valid:values.append((w,3600*sum(r[field] for r in valid)/sum(r['shift_seconds'] for r in valid)))
                        f[role+'_'+field+'_per60_'+str(span)]=sum(w*x for w,x in values)/sum(w for w,x in values) if values else np.nan
                quality=[(w,np.mean([r['mapped_game_fraction'] for r in h if r['mapped_game_fraction'] is not None])) for pid,w,h in roles[role]]
                f[role+'_mapping_fraction']=sum(w*x for w,x in quality)/sum(w for w,x in quality) if quality else np.nan
            sides.append(f)
        row=dict(game_id=g['game_id'],onice_source_max_available_utc=max(sources) if sources else None);assert not sources or max(sources)<cutoff
        for key in sides[0]:row['f_onice_'+key+'_diff']=sides[1][key]-sides[0][key]
        out.append(row)
    if base is None:base=pd.read_parquet(ROOT_OUT/'nhl_tuning_v3/nhl_features.parquet')
    extra=pd.DataFrame(out);f=base.merge(extra,on='game_id',validate='one_to_one')
    if not save:return f
    f.to_parquet(OUT/'nhl_features.parquet',index=False)
    dump(OUT/'onice_feature_audit.json',dict(at_utc=stamp(),games=len(f),source_games=len(records),source_player_facts=sum(len(r['players']) for r in records),added_features=len(extra.columns)-2,total_features=len([c for c in f if c.startswith('f_')]),future_input_violations=0,missing_pct={c:100*f[c].isna().mean() for c in extra if c.startswith('f_')},scope='Partial mapped attempts and internal prior-year xG while observed skaters are on the ice. Mapping fraction is retained as an input. Recent roster uses prior five games only.'))
    print(json.dumps(dict(games=len(f),features=len([c for c in f if c.startswith('f_')]),source_games=len(records))),flush=True)
    return f

if __name__=='__main__':main()
