"""Derive absent integer zeros only from complete official team/player counts.

No network calls: original official responses already acquired are replayed.
Partial participant sets or unequal counts do not support a zero inference.
"""
import collections
import hashlib
import json
import math
from pathlib import Path

import pandas as pd

from common import ROOT_OUT,PREVIOUS,PROJECT,dump,read_db,stamp
from collect_players import FIELDS

RUN=ROOT_OUT/'sparse_player_v26'
ADDITIVE=['goals','assists','shots','shots_on_target','key_passes','passes_completed',
          'interceptions','recoveries','tackles_won','aerials_won','saves',
          'final_third_passes_completed']


def load():
    with read_db(PREVIOUS/'expanded.sqlite') as c:
        games={r['game_id']:dict(r) for r in c.execute("SELECT * FROM soccer_games WHERE league='Premier League' AND date BETWEEN '2021-01-01' AND '2026-09-30'")}
    with read_db(ROOT_OUT/'player_detail.sqlite') as c:
        players=[json.loads(b) for b, in c.execute('SELECT body FROM player_match_detail')]
    with read_db(PREVIOUS/'collection.sqlite') as c:
        sources={r['url']:dict(r) for r in c.execute("SELECT * FROM requests WHERE status=200 AND url LIKE '%prem%'")}
    return games,players,sources


def original(source):
    path=Path(source['raw_file'])
    if not path.is_absolute():path=PREVIOUS/path
    if not path.exists():
        raw=source['raw_file'].replace('\\','/')
        mapping=json.loads((PROJECT/'final_models/sources/path_map.json').read_bytes())
        for old,new in mapping.items():
            old,new=old.replace('\\','/'),new.replace('\\','/')
            if raw.startswith(old):raw=new+raw[len(old):];break
        path=PROJECT/raw
    blob=path.read_bytes();assert hashlib.sha256(blob).hexdigest()==source['sha256']
    return json.loads(blob),str(path.resolve())


def merge_proved_zeros(players, audit_dir=None):
    audit_dir=RUN if audit_dir is None else audit_dir
    assert json.loads((RUN/'pl_zero_validation.json').read_bytes())['status']=='PASS'
    cells=pd.read_parquet(RUN/'pl_zero_proofs.parquet')
    idx=['game_id','side','official_player_id'];joined=players.set_index(idx).copy()
    assert not joined.index.duplicated().any()
    changed=[];conflicts=[];counts={}
    for field,proof in cells.groupby('field'):
        keys=pd.MultiIndex.from_frame(proof[idx]);assert keys.isin(joined.index).all()
        old=joined.loc[keys,field]
        bad=old.notna()&old.ne(0)
        for key,value in old[bad].items():
            conflicts.append(dict(game_id=key[0],side=key[1],official_player_id=key[2],field=field,prior_value=float(value),proof_value=0.))
        fill=old.isna();joined.loc[keys[fill],field]=0.
        counts[field]=int(fill.sum())
        for key in keys[fill]:changed.append(dict(game_id=key[0],side=key[1],official_player_id=key[2],field=field))
    dump(audit_dir/'pl_merge_conflicts.json',conflicts)
    assert not conflicts,'Explicit older value conflicts with a new complete-count zero proof; reconcile before modeling'
    pd.DataFrame(changed).to_parquet(audit_dir/'pl_feature_filled_cells.parquet',index=False)
    audit=dict(at_utc=stamp(),proved_cells=len(cells),newly_known_cells=len(changed),
        newly_known_by_field=counts,previous_known_zero_cells=len(cells)-len(changed),conflicts=0,
        raw_values_changed=False,player_rows_unchanged=len(joined)==len(players))
    dump(audit_dir/'pl_feature_merge.json',audit)
    return joined.reset_index(),audit


def main():
    RUN.mkdir(exist_ok=True)
    games,players,sources=load();groups=collections.defaultdict(list)
    for r in players:
        if r['game_id'] in games:groups[(r['game_id'],r['side'])].append(r)
    proofs=[];audit=[];issues=[];source_links=[];mark=10
    for n,(gid,g) in enumerate(sorted(games.items()),1):
        base='https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v3/matches/'+str(g['official_game_id'])
        if base+'/stats' not in sources or base+'/lineups' not in sources:
            issues.append(dict(game_id=gid,reason='Retained official team/lineup response requires acquisition'));continue
        team_source,lineup_source=sources[base+'/stats'],sources[base+'/lineups']
        teams,team_path=original(team_source);lineup,lineup_path=original(lineup_source)
        native=json.loads(g['native_team_ids_json'])
        for side,key,nid in zip(['A','B'],['away_team','home_team'],native):
            group=groups[(gid,side)];byid={str(r['player_id']):r for r in group};assert len(byid)==len(group)
            official=lineup[key];assert str(official['teamId'])==str(nid)
            roster={str(p['id']) for p in official['players']}
            starters={str(p['id']) for p in official['players'] if p.get('position')!='Substitute'}
            team=next(r for r in teams if str(r['teamId'])==str(nid));stats=team['stats']
            active=[r for r in group if r['raw_stats'].get('gameStarted')==1 or r['raw_stats'].get('totalSubOn')==1 or (r['minutes'] is not None and r['minutes']>0)]
            active_ids={str(r['player_id']) for r in active}
            observed_starters={str(r['player_id']) for r in active if r['raw_stats'].get('gameStarted')==1}
            subs=active_ids-starters
            complete=(len(starters)==11 and observed_starters==starters and active_ids<=roster
                      and stats.get('subsMade') is not None and len(subs)==stats['subsMade'])
            if not complete:
                issues.append(dict(game_id=gid,side=side,reason='No complete starting/substitution count proof',official_starters=len(starters),observed_starters=len(observed_starters),observed_substitutes=len(subs),official_substitutions=stats.get('subsMade')))
            for field in ADDITIVE:
                total=stats.get(FIELDS[field]);known=[r[field] for r in active if r[field] is not None]
                assert all(v>=0 and float(v).is_integer() for v in known)
                summed=math.fsum(known)
                supported=complete and total is not None and summed==total
                omitted=[r for r in active if r[field] is None]
                audit.append(dict(game_id=gid,side=side,date=g['date'],field=field,
                    complete_participants=complete,participants=len(active),known_players=len(known),
                    missing_players=len(omitted),known_sum=summed,team_total=total,
                    zero_inference_supported=supported))
                if not supported:continue
                for r in omitted:
                    proofs.append(dict(game_id=gid,official_game_id=g['official_game_id'],side=side,
                        official_player_id=str(r['player_id']),player_name=r['player_name'],league='Premier League',
                        date=g['date'],available_at_utc=r['available_at_utc'],field=field,
                        raw_value=None,derived_value=0.,team_total=total,known_sum=summed,participants=len(active),
                        official_substitutes=int(stats['subsMade']),player_source_sha256=r['source']['sha256'],
                        player_source_raw_file=r['source']['raw_file'],player_source_url=r['source']['url'],
                        team_source_sha256=team_source['sha256'],team_source_raw_file=team_path,team_source_url=team_source['url'],
                        lineup_source_sha256=lineup_source['sha256'],lineup_source_raw_file=lineup_path))
            source_links.append(dict(game_id=gid,side=side,team_source=team_source,lineup_source=lineup_source))
        if n*100>=mark*len(games) or n==len(games):
            progress=dict(stage='official_sparse_count_reconciliation',processed=n,total=len(games),percent=round(n*100/len(games),1),proven_zero_cells=len(proofs))
            print(json.dumps(progress),flush=True);dump(RUN/'source_progress.json',progress);mark+=10
    pd.DataFrame(proofs).to_parquet(RUN/'pl_zero_proofs.parquet',index=False)
    pd.DataFrame(audit).to_parquet(RUN/'pl_count_reconciliation.parquet',index=False)
    dump(RUN/'pl_source_links.json',source_links);dump(RUN/'pl_count_issues.json',issues)
    summary=dict(at_utc=stamp(),games=len(games),proved_zero_cells=len(proofs),
        counts_by_field=dict(collections.Counter(r['field'] for r in proofs)),
        source_issues=len(issues),network_requests=0,raw_nulls_preserved=True)
    dump(RUN/'pl_count_summary.json',summary);print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
