"""Causal NHL shot-quality estimates and player/goalie event performance."""
import json
import hashlib
import pickle
import sqlite3
import math
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder,StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss,brier_score_loss
from threadpoolctl import threadpool_limits
from common import PROJECT,PREVIOUS,OUT,ROOT_OUT,read_db,dump

def enrich_events():
    with read_db(PREVIOUS/'expanded.sqlite') as c:
        shots=pd.read_sql_query('SELECT * FROM nhl_shot_events',c)
        games=pd.read_sql_query('SELECT * FROM nhl_games',c)
    with read_db(PREVIOUS/'collection.sqlite') as c:
        sources=c.execute("SELECT url,raw_file,sha256 FROM requests WHERE url LIKE '%/play-by-play' AND status=200").fetchall()
    mapping=games.set_index('official_game_id').game_id.to_dict();extra=[];mark=10
    for n,s in enumerate(sources,1):
        path=(PREVIOUS/s['raw_file']).resolve();raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==s['sha256']
        d=json.loads(raw);gid=mapping.get(str(d['id']))
        if not gid:continue
        ids=[str(d['awayTeam']['id']),str(d['homeTeam']['id'])]
        for event in d.get('plays',[]):
            if event.get('typeDescKey') not in {'goal','shot-on-goal','missed-shot'} or event.get('periodDescriptor',{}).get('periodType')=='SO':continue
            det=event.get('details',{});owner=str(det.get('eventOwnerTeamId'))
            if owner not in ids:continue
            home=owner==ids[1];situation=str(event.get('situationCode',''));valid=len(situation)==4 and situation.isdigit()
            extra.append(dict(game_id=gid,event_id=event['eventId'],defending_goalie_present=int(situation[0 if home else 3]) if valid else np.nan,
                              attackers=int(situation[2 if home else 1]) if valid else np.nan,defenders=int(situation[1 if home else 2]) if valid else np.nan,
                              period_type=event.get('periodDescriptor',{}).get('periodType'),source_raw_file=path.relative_to(PROJECT).as_posix(),source_sha256=s['sha256']))
        if n*100>=mark*len(sources):print('NHL_EVENT_ENRICHMENT',mark,'percent',n,'/',len(sources),flush=True);mark+=10
    extra=pd.DataFrame(extra);assert not extra.duplicated(['game_id','event_id']).any()
    shots=shots.merge(extra,on=['game_id','event_id'],how='left',validate='one_to_one')
    assert shots.source_raw_file.notna().all()
    shots=shots.merge(games[['game_id','date','start_time','available_time','phase']],on='game_id',validate='many_to_one')
    shots['start_time']=pd.to_datetime(shots.start_time,utc=True,format='mixed');shots['available_time']=pd.to_datetime(shots.available_time,utc=True,format='mixed')
    shots['year']=shots.start_time.dt.year;shots['goal']=shots.result.eq('goal').astype(int)
    shots['log_distance']=np.log1p(shots.distance_ft);shots['distance_angle']=shots.log_distance*shots.angle_degrees/90
    shots['shot_type']=shots.shot_type.fillna('unknown').astype(str)
    shots.to_parquet(OUT/'nhl_shot_detail.parquet',index=False)
    return shots,games

@threadpool_limits.wrap(limits=2)
def fit_shots(shots):
    nums=['log_distance','angle_degrees','distance_angle','inner_slot','repeat_shot_3s','manpower_advantage','attackers','defenders']
    output=[];audits=[];model_dir=OUT/'shot_models';model_dir.mkdir(exist_ok=True)
    eligible=shots.phase.isin(['Regular Season','Playoffs'])&shots.defending_goalie_present.eq(1)&shots.distance_ft.notna()&shots.angle_degrees.notna()
    for year in sorted(shots.year.unique()):
        cutoff=pd.Timestamp(f'{year}-01-01',tz='UTC')
        train=shots[eligible&shots.available_time.lt(cutoff)]
        test=shots[shots.year.eq(year)].copy();test['model_xg']=np.nan;test['shot_model_fit_before_utc']=None
        if len(train)<10000:
            output.append(test);continue
        transform=ColumnTransformer([('numeric',Pipeline([('impute',SimpleImputer(strategy='median',add_indicator=True)),('scale',StandardScaler())]),nums),('type',OneHotEncoder(handle_unknown='ignore'),['shot_type'])])
        model=Pipeline([('inputs',transform),('logistic',LogisticRegression(C=.5,max_iter=1000))])
        model.fit(train[nums+['shot_type']],train.goal)
        usable=test.defending_goalie_present.eq(1)&test.distance_ft.notna()&test.angle_degrees.notna()
        p=model.predict_proba(test.loc[usable,nums+['shot_type']])[:,1]
        test.loc[usable,'model_xg']=p;test.loc[usable,'shot_model_fit_before_utc']=cutoff.isoformat()
        (model_dir/f'prior_to_{year}.pkl').write_bytes(pickle.dumps(model,protocol=5))
        audit=dict(year=int(year),fit_cutoff_utc=cutoff.isoformat(),training_shots=len(train),training_last_available_utc=train.available_time.max().isoformat(),test_shots=int(usable.sum()),test_goal_rate=float(test.loc[usable,'goal'].mean()),predicted_goal_rate=float(p.mean()),log_loss=float(log_loss(test.loc[usable,'goal'],np.column_stack([1-p,p]),labels=[0,1])),brier=float(brier_score_loss(test.loc[usable,'goal'],p)))
        assert train.available_time.max()<cutoff and test.loc[usable,'start_time'].ge(cutoff).all()
        audits.append(audit);output.append(test);print('NHL_SHOT_MODEL',json.dumps(audit),flush=True)
    f=pd.concat(output,ignore_index=True);f.to_parquet(OUT/'nhl_shot_detail.parquet',index=False)
    dump(OUT/'shot_model_audit.json',audits)
    return f

def summarize(shots,games):
    rows=[];goalies=[];shooters=[]
    for (gid,side),f in shots.groupby(['game_id','side'],sort=False):
        eligible=f.defending_goalie_present.eq(1);valid=f.model_xg.notna()
        regular=f.period_type.eq('REG');ev=f.attackers.eq(5)&f.defenders.eq(5)
        sufficient=valid[eligible].mean()>=.95 if eligible.any() else False
        row=dict(game_id=gid,side=side,xg=float(f.loc[valid,'model_xg'].sum()) if sufficient else np.nan,
                 xg_even_strength=float(f.loc[valid&ev,'model_xg'].sum()) if sufficient else np.nan,
                 goals_nonempty=int(f.loc[eligible,'goal'].sum()),unblocked_nonempty=int(eligible.sum()),modelled_shots=int(valid.sum()),
                 regulation_goals=int(f.loc[regular,'goal'].sum()),empty_net_attempts=int(f.defending_goalie_present.eq(0).sum()))
        rows.append(row)
        for pid,g in f[f.goalie_id.notna()].groupby('goalie_id'):
            usable=g.model_xg.notna();coverage=usable.mean()
            goalies.append(dict(game_id=gid,defending_side='B' if side=='A' else 'A',goalie_id=str(int(pid)),unblocked_against=len(g),shots_on_goal_against=int(g.result.isin(['goal','shot-on-goal']).sum()),goals_against=int(g.goal.sum()),model_xg_against=float(g.model_xg.sum()) if coverage>=.95 else np.nan,modelled_shot_fraction=float(coverage)))
        for pid,g in f[f.shooter_id.notna()].groupby('shooter_id'):
            shooters.append(dict(game_id=gid,side=side,player_id=str(int(pid)),unblocked_attempts=len(g),goals=int(g.goal.sum()),model_xg=float(g.model_xg.sum()) if g.model_xg.notna().mean()>=.95 else np.nan))
    summary=pd.DataFrame(rows)
    opp=summary[['game_id','side','xg','xg_even_strength','goals_nonempty']].copy();opp.side=opp.side.map({'A':'B','B':'A'});opp=opp.rename(columns={k:k+'_against' for k in ['xg','xg_even_strength','goals_nonempty']})
    # A sparse goals-only report may have no opponent shot row. Preserve the
    # observed side instead of dropping a whole shutout through an inner join.
    summary=summary.merge(opp,on=['game_id','side'],how='left',validate='one_to_one')
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='nhl_regulation_score_repairs'").fetchone():
            repairs=pd.read_sql_query('SELECT * FROM nhl_regulation_score_repairs',db)
            summary=summary.set_index(['game_id','side'])
            for r in repairs.itertuples():
                for side in ['A','B']:summary.loc[(r.game_id,side),'regulation_goals']=getattr(r,'regulation_score'+side)
            summary=summary.reset_index()
    summary['model_goals_saved']=summary.xg_against-summary.goals_nonempty_against
    summary['finishing_residual']=summary.goals_nonempty-summary.xg
    with sqlite3.connect(OUT/'granular.sqlite') as c:
        summary.to_sql('nhl_team_shot_quality',c,if_exists='replace',index=False)
        pd.DataFrame(goalies).to_sql('nhl_goalie_game_quality',c,if_exists='replace',index=False)
        pd.DataFrame(shooters).to_sql('nhl_shooter_game_quality',c,if_exists='replace',index=False)
    dump(OUT/'shot_quality_coverage.json',dict(shot_events=len(shots),team_games=len(summary),goalie_games=len(goalies),shooter_games=len(shooters),team_xg_missing_pct=100*summary.xg.isna().mean(),meaning='Internally estimated goal probability from shot geometry/context, fit only on earlier years; not an official NHL xG statistic. Empty-net/shootout shots excluded from xG fitting and goalkeeper quality. First year has no prior-year fit.'))

if __name__=='__main__':
    if (OUT/'nhl_shot_detail.parquet').exists():
        s=pd.read_parquet(OUT/'nhl_shot_detail.parquet')
        with read_db(PREVIOUS/'expanded.sqlite') as db:g=pd.read_sql_query('SELECT * FROM nhl_games',db)
    else:s,g=enrich_events()
    s=fit_shots(s);summarize(s,g)
