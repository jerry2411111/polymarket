"""Past-only reliability of the fixed model pick; no price or side refitting."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, brier_score_loss

from common import ROOT_OUT,REPORTS,dump,stamp,file_sha256
from backtest import quote_inputs
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine

LABEL='winner_confidence_calibration'
RESULT=ROOT_OUT/'simulation_results'/LABEL


def reliability(p):
    p=p.copy();cols=['p0','p1']+(['p2'] if p.sport.iloc[0]=='soccer' else [])
    p['model_pick']=p[cols].to_numpy().argmax(axis=1)
    p['pick_probability']=p[cols].max(axis=1)
    p['pick_correct']=p.model_pick.eq(p.target)
    p['confidence_logit']=np.log(p.pick_probability.clip(1e-8,1-1e-8)/(1-p.pick_probability.clip(1e-8,1-1e-8)))
    parts=[];fits=[]
    for month,test in p.groupby(p.prediction_time.dt.strftime('%Y-%m')):
        boundary=pd.Timestamp(month+'-01',tz='UTC');train=p[p.available_time.lt(boundary)]
        counts=train.pick_correct.value_counts();ready=len(train)>=100 and len(counts)==2 and counts.min()>=10
        t=test.copy();slope=intercept=None
        if ready:
            model=LogisticRegression(C=1.,max_iter=1000).fit(train[['confidence_logit']],train.pick_correct.astype(int))
            t['sizing_probability']=model.predict_proba(test[['confidence_logit']])[:,1]
            slope=float(model.coef_[0,0]);intercept=float(model.intercept_[0])
            replay=1/(1+np.exp(-(intercept+slope*t.confidence_logit)))
            assert np.allclose(replay,t.sizing_probability,rtol=0,atol=1e-12)
        else:t['sizing_probability']=t.pick_probability
        t['reliability_ready']=ready;t['reliability_last_label']=train.available_time.max()
        assert not len(train) or train.available_time.max()<t.prediction_time.min()
        parts.append(t);fits.append(dict(month=month,prior_forecasts=len(train),ready=bool(ready),slope=slope,intercept=intercept,last_label=str(train.available_time.max())))
    return pd.concat(parts,ignore_index=True),pd.DataFrame(fits)


def scores(p):
    rows=[]
    for year,f in [('pooled',p)]+list(p.groupby(p.prediction_time.dt.year)):
        y=f.pick_correct.to_numpy(int)
        for variant,col in [('raw','pick_probability'),('calibrated','sizing_probability')]:
            q=f[col].to_numpy()
            rows.append(dict(year=str(year),variant=variant,games=len(f),logloss=log_loss(y,np.c_[1-q,q],labels=[0,1]),
                brier=brier_score_loss(y,q),mean_probability=q.mean(),actual_pick_win_rate=y.mean()))
    return pd.DataFrame(rows)


def run():
    RESULT.mkdir(exist_ok=True);assert not (RESULT/'validation.json').exists()
    plan=dict(at_utc=stamp(),hypothesis='Stake sizing needs P(the fixed argmax is correct), whose conditional reliability can differ from the original multiclass calibration. Weak-confidence development winners lost money; re-estimate confidence, not outcome.',
        model='One logistic curve:correct_pick~intercept+logit(original_top_probability),L2 C1,no price or team predictors. Monthly expanding earlier out-of-fit forecasts from2024. Require100earlier forecasts and10correct/incorrect; otherwise preserve original confidence.',
        invariant='Original model argmax and all original class probabilities remain unchanged. Calibrated confidence is a separate sizing field. A low corrected confidence causes zero stake, never an opposite-side purchase.',
        model_gate='Improve pooled2024/25winner-correctness logloss AND Brier and2025logloss against original top probability.',
        bet_rule='Unchanged5dollars per corrected confidence percentage point above51,annual2000cash only,pre12priorquotes<=24h; no costs.',
        bet_gate='2025Sharpe improves with positive return and no worse drawdown;2024Sharpe not worse where defined. Only qualifiers reach2026.',
        evaluation='2026 is repeatedly inspected retrospective rolling research. No new threshold or hyperparameter grid.',app_changed=False)
    dump(RESULT/'plan.json',plan)
    allp={};hashes={};proper=[];choices={};fit_parts=[]
    for sport,folder in [('nhl','feature_revisions/nhl_player_strength'),('soccer','soccer_source_count_rates')]:
        path=ROOT_OUT/'simulation_results'/folder/'development_predictions.parquet';hashes[str(path.relative_to(ROOT_OUT))]=file_sha256(path)
        p=pd.read_parquet(path);p=p[p.variant.eq('candidate')].copy()
        assert p.game_id.is_unique and p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
        f,fits=reliability(p);s=scores(f);proper.append(s.assign(sport=sport));fit_parts.append(fits.assign(sport=sport))
        early=p[p.prediction_time.dt.year.eq(2024)];prefix,_=reliability(early)
        pd.testing.assert_frame_equal(prefix.set_index('game_id').sort_index(),f.set_index('game_id').loc[prefix.game_id].sort_index(),check_exact=True)
        ix=s.set_index(['variant','year']);passed=all(ix.loc[('calibrated','pooled'),k]<ix.loc[('raw','pooled'),k] for k in ['logloss','brier']) and ix.loc[('calibrated','2025'),'logloss']<ix.loc[('raw','2025'),'logloss']
        choices[sport]=bool(passed);allp[sport]=f
    pd.concat(proper).to_csv(RESULT/'development_probability_metrics.csv',index=False)
    pd.concat(fit_parts).to_csv(RESULT/'development_fits.csv',index=False)
    pd.concat(allp.values()).to_parquet(RESULT/'development_predictions.parquet',index=False)
    dump(RESULT/'probability_selection.json',dict(at_utc=stamp(),choices=choices,used2026=False))
    annual=[];positions=[];days=[];checks=[];account_choices={}
    quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    def account(sport,p,stage):
        f=transfer.normalize(sport,p,quotes,pick_growth=False)
        f['sizing_probability']=f.game_id.map(p.set_index('game_id').sizing_probability)
        assert f.sizing_probability.notna().all()
        cols=['p0','p1']+(['p2'] if sport=='soccer' else [])
        for provider,g in f.groupby('provider'):
            if stage=='evaluation' and not account_choices.get((sport,provider),False):continue
            for variant in ['raw','calibrated']:
                h=g.copy()
                if variant=='raw':h['sizing_probability']=h.probability
                h=h[h.sizing_probability.gt(.51)]
                for year in sorted(p.prediction_time.dt.year.unique()):
                    m,b,l,d=engine.simulate(h,int(year),'all_selected_outcomes','calibrated_dollars_cash_only',5.,2000.)
                    meta=dict(sport=sport,provider=provider,variant=variant,year=int(year))
                    annual.append(meta|m);checks.append(meta|engine.validate(b,l,d,'calibrated_dollars_cash_only',5.,2000.))
                    if len(b):
                        assert b.side.eq(b[cols].to_numpy().argmax(axis=1)).all()
                        positions.append(b.assign(**meta))
                    days.append(d.assign(**meta))
    for sport,f in allp.items():
        if choices[sport]:account(sport,f,'development')
    if annual:
        a=pd.DataFrame(annual)
        for (sport,provider),g in a.groupby(['sport','provider']):
            ix=g.set_index(['variant','year']);old,new=ix.loc[('raw',2025)],ix.loc[('calibrated',2025)]
            passed=new.sharpe>old.sharpe and new.return_pct>0 and new.max_drawdown_pct<=old.max_drawdown_pct
            if ('raw',2024) in ix.index and pd.notna(ix.loc[('raw',2024),'sharpe']):passed &= ix.loc[('calibrated',2024),'sharpe']>=ix.loc[('raw',2024),'sharpe']
            account_choices[sport,provider]=bool(passed)
    dump(RESULT/'account_selection.json',dict(at_utc=stamp(),choices=[dict(sport=k[0],provider=k[1],passed=v) for k,v in account_choices.items()],used2026=False,adopted=False))
    evs=[]
    for sport,folder in [('nhl','feature_revisions/nhl_player_strength'),('soccer','soccer_source_count_rates')]:
        if not any(v for k,v in account_choices.items() if k[0]==sport):continue
        path=ROOT_OUT/'simulation_results'/folder/'evaluation_predictions.parquet';hashes[str(path.relative_to(ROOT_OUT))]=file_sha256(path)
        new=pd.read_parquet(path);new=new[new.variant.eq('candidate')]
        f,fits=reliability(pd.concat([allp[sport],new],ignore_index=True))
        earlier=f[f.prediction_time.dt.year.lt(2026)].set_index('game_id');old=allp[sport].set_index('game_id')
        assert np.array_equal(earlier.loc[old.index,'sizing_probability'],old.sizing_probability)
        ev=f[f.prediction_time.dt.year.eq(2026)];evs.append(ev);account(sport,ev,'evaluation')
        fits.to_csv(RESULT/(sport+'_all_fits.csv'),index=False)
    if evs:pd.concat(evs).to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
    if annual:
        pd.DataFrame(annual).to_csv(RESULT/'annual.csv',index=False)
        pd.concat(positions).to_parquet(RESULT/'bets.parquet',index=False);pd.concat(days).to_parquet(RESULT/'daily.parquet',index=False)
    for name,sha in hashes.items():assert file_sha256(ROOT_OUT/name)==sha
    proof=dict(status='PASS',at_utc=stamp(),source_hashes=hashes,probability_gates=choices,cash_checks=checks,
        all_bets_follow_original_model_pick=True,earlier_only_calibration=True,prefix_replay=True,app_changed=False,adopted=False)
    dump(RESULT/'validation.json',proof)
    def table(f):
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+[
            '| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in f.itertuples(index=False,name=None)])
    lines=['# Winner confidence reliability','',plan['hypothesis'],'',plan['model'],'',plan['invariant'],'',
        table(pd.concat(proper)),'','Probability gates: '+json.dumps(choices)+'.','']
    if annual:lines+=[table(pd.DataFrame(annual)[['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'']
    lines+=['Every fitted reliability curve uses earlier settled out-of-fit predictions, independently of price and profitability. Removing2025reproduces2024confidences. Model-score and account gates precede2026replay; no fitted trial artifact is promoted.2026remains repeatedly inspected retrospective evidence. Original forecasts, native IDs, price meaning, pre12timing and NBA/MLBapp remain unchanged.','',
        'Sharpe uses actual calendar daily returns andsqrt365.25; idle days included. Paper raw-price execution limitations remain unchanged. Reproduce winner_confidence_calibration.py.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';d=json.loads(path.read_bytes());d[LABEL]=dict(plan=plan,validation=proof,account_selection=json.loads((RESULT/'account_selection.json').read_bytes()));dump(path,d)
    if annual:
        path=ROOT_OUT/'simulation_results/experiment_results.csv';d=pd.read_csv(path,low_memory=False);key=LABEL+'/annual.csv'
        pd.concat([d[d.source_result_file.ne(key)],pd.DataFrame(annual).assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(pd.concat(proper).to_string(index=False),flush=True);print(json.dumps(dict(probability_gates=choices)),flush=True)
    if annual:print(pd.DataFrame(annual)[['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


if __name__=='__main__':run()
