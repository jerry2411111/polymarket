"""Expand retained official La Liga pages after the unavailable keyed API.

Source-native rosters, regulation minutes, reconciled goals and team statistics.
Retained official match-page JSON is reused; uncovered games are requested
from documented official calendar links and saved before normalization.
"""
import argparse,collections,concurrent.futures,hashlib,json,re,sqlite3,unicodedata
from common import ROOT_OUT,PREVIOUS,PROJECT,OfficialClient,read_db,dump,stamp
from soccer_additional_facts import LIGUE_FIELDS
PARSER_VERSION=3


def namekey(value):return ''.join(c for c in unicodedata.normalize('NFKD',str(value)).casefold() if c.isalpha())


def parse(game,page,source,allow_stoppage_clock=False):
    match=page['match'];assert str(match['id'])==str(game['official_game_id'])
    assert match['status']=='FullTime',('La Liga not fulltime',match['status'])
    rows=[];teams=[];byname=collections.defaultdict(set);byid={};starters=[];managers=set();teamids=json.loads(game['native_team_ids_json'])
    for side,native,tid in zip(['A','B'],['away','home'],teamids):
        assert str(match[native+'_team']['id'])==str(tid) and match[native+'_score']==game['score'+side]
        common=dict(game_id=game['game_id'],official_game_id=game['official_game_id'],league='La Liga',date=game['date'],available_at_utc=game['available_time'],side=side,team_id=str(tid))
        lineup=page['data']['lineups'][native];assert len(lineup['starts'])==11
        for manager in lineup.get('manager',[]):
            managers.add((str(tid),namekey(manager['person']['name'])))
        for group in ['starts','subs']:
            for p in lineup[group]:
                ids=set(re.findall(r'/(p\d+)/',str(p.get('photos',{}))))
                assert len(ids)<=1,'Conflicting asset native IDs'
                pid=next(iter(ids)) if ids else f"lineup:{match['id']}:{p['id']}"
                r=common|dict(official_player_id=pid,source_lineup_id=str(p['id']),id_namespace='opta_player_asset' if ids else 'laliga_lineup_record',
                    player_name=p['person']['name'],position=p.get('position'),started=group=='starts',played=None,minutes=None,goals=None,assists=None,
                    minutes_basis='Regulation clock including fractional minute but excluding first/second-half stoppage time; derived from official substitution and red-card events.',source=source,
                    lineup_pointer='/props/pageProps/data/lineups/'+native+'/'+group)
                assert pid not in byid;byid[pid]=r;rows.append(r)
                if group=='starts':starters.append(pid)
                person=p['person']
                for label in [person.get('name'),person.get('nickname'),' '.join([person.get('firstname') or '',person.get('lastname') or ''])]:
                    if label:byname[(str(tid),namekey(label))].add(pid)
        raw=page['data']['stats'].get(native) or {}
        teams.append(common|{name:raw.get(field) for name,field in LIGUE_FIELDS.items()}|dict(raw_stats=raw,source=source))
    def actor(p):
        candidates=byname[(str(p['team']['id']),namekey(p['person']['name']))]
        assert len(candidates)==1,'No unique exact dated lineup name: '+p['person']['name']
        return next(iter(candidates))
    goals=collections.Counter();assists=collections.Counter();side_goals=collections.Counter();transitions=[];issues=[];excluded_staff=[];clock_recoveries=[];assist_complete=True;goal_complete=True;appearance_complete=True
    for i,e in enumerate(page['events']):
        kind=e['match_event_kind']['collection'];label=e['match_event_kind']['name']
        if kind not in ['goal','substitution','booking']:continue
        if e.get('period') not in ['FirstHalf','SecondHalf']:continue
        try:
            if kind=='booking' and label not in ['Second Yellow','Straight Red']:continue
            if kind=='booking' and (str(e['lineup']['team']['id']),namekey(e['lineup']['person']['name'])) in managers:
                excluded_staff.append(dict(event_index=i,name=e['lineup']['person']['name'],reason='Exact manager identity in this official dated lineup; does not reduce player time.'));continue
            pid=actor(e['lineup']);r=byid[pid]
            if kind=='goal':
                credited=('B' if r['side']=='A' else 'A') if label=='Own' else r['side'];side_goals[credited]+=1
                if label!='Own':
                    goals[pid]+=1
                    if 'assist' not in e:assist_complete=False
                    elif e['assist']:
                        aid=actor(e['assist']);assert byid[aid]['side']==r['side'];assists[aid]+=1
            else:
                minute=e.get('minute');second=e.get('second')
                if allow_stoppage_clock and not (isinstance(minute,(int,float)) and isinstance(second,(int,float))):
                    # Regulation exposure excludes stoppage time. A documented
                    # 45+N/90+N event maps exactly to45/90 regardless of omitted
                    # seconds; do not invent precision for ordinary minutes.
                    clock=re.fullmatch(r'(45|90)\+(\d+)',str(e.get('clock','')))
                    boundary=45 if e['period']=='FirstHalf' else 90
                    if clock and int(clock[1])==boundary and int(clock[2])>0 and e.get('time')==boundary+int(clock[2]):
                        minute,second=boundary,0
                        clock_recoveries.append(dict(event_index=i,event_id=e['id'],period=e['period'],
                            raw_clock=e['clock'],raw_time=e['time'],raw_minute=e.get('minute'),raw_second=e.get('second'),
                            regulation_minute=boundary,source_modified_utc=e.get('date_source'),
                            basis='Stoppage excluded from regulation exposure; boundary exact, event seconds remain unknown'))
                assert isinstance(minute,(int,float)) and isinstance(second,(int,float)),'No explicit event minute/second'
                when=minute+second/60
                if e['period']=='FirstHalf':assert when>=0;when=min(45.,when)
                else:assert when>=45;when=min(90.,when)
                if kind=='substitution':
                    off=actor(e['lineup_off']);assert byid[off]['side']==r['side'];transitions.append((when,i,'sub',off,pid))
                else:transitions.append((when,i,'red',pid,None))
        except (KeyError,AssertionError,TypeError) as exc:
            issues.append(dict(event_index=i,kind=kind,reason=str(exc)))
            if kind=='goal':goal_complete=False;assist_complete=False
            elif kind=='substitution':appearance_complete=False
            else:appearance_complete=False
    goal_complete=goal_complete and all(side_goals[s]==game['score'+s] for s in ['A','B'])
    if not goal_complete:issues.append(dict(field='goals',reason='Recorded player goals do not reconcile with official final scores',counted=dict(side_goals)))
    active={pid:0. for pid in starters};minutes=collections.Counter();played=set(starters);minutes_complete=appearance_complete
    try:
        for at,_,kind,off,on in sorted(transitions):
            if kind=='red' and off not in active:continue # A bench dismissal does not subtract playing time.
            assert off in active and on not in active,'Event sequence contradicts prior active players'
            minutes[off]+=at-active.pop(off)
            if on:active[on]=at;played.add(on)
        for pid,at in active.items():minutes[pid]+=90-at
        assert all(0<=v<=90 for v in minutes.values())
    except AssertionError as exc:minutes_complete=False;appearance_complete=False;issues.append(dict(field='minutes',reason=str(exc)))
    for r in rows:
        pid=r['official_player_id'];r['played']=pid in played if appearance_complete else (True if r['started'] else None)
        r['minutes']=float(minutes[pid]) if minutes_complete else None
        r['goals']=goals[pid] if goal_complete else None;r['assists']=assists[pid] if goal_complete and assist_complete else None
    return dict(game_id=game['game_id'],official_game_id=game['official_game_id'],league='La Liga',date=game['date'],players=rows,teams=teams,sources=[source],
                issues=issues,excluded_staff_events=excluded_staff,goal_counts_reconcile=goal_complete,minutes_complete=minutes_complete,parser_version=PARSER_VERSION,
                caveat='Player goals are zero only after complete event counts reconcile with official scores. Team/player sparse source omissions stay null. These facts are for later games, never current-game inputs.',
                **({'regulation_clock_recoveries':clock_recoveries} if allow_stoppage_clock else {}))


def page_props(blob):
    hit=re.search(rb'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',blob,re.S)
    assert hit,'Official structured match document not found'
    return json.loads(hit[1])['props']['pageProps']


def source_index(games):
    mapping=json.loads((PROJECT/'final_models/sources/path_map.json').read_text());pages={};urls={}
    with read_db(PROJECT/'collected data/result/soccer_statistics.sqlite') as c:
        sources=[dict(r) for r in c.execute("SELECT * FROM source_manifest WHERE status=200 AND (endpoint LIKE 'https://www.laliga.com/en-GB/match/%' OR endpoint LIKE 'https://www.laliga.com/en-GB/laliga-easports/results/%') ORDER BY retrieved_at_utc DESC")]
    for s in sources:
        raw=s['raw_file'].replace('\\','/')
        for old,new in mapping.items():
            old,new=old.replace('\\','/'),new.replace('\\','/')
            if raw.startswith(old):raw=new+raw[len(old):];break
        path=PROJECT/raw
        if not path.exists():continue
        blob=path.read_bytes();assert hashlib.sha256(blob).hexdigest()==s['sha256']
        page=page_props(blob);source=dict(url=s['endpoint'],request_id=s['request_id'],raw_file=raw,sha256=s['sha256'],retrieved_at_utc=s['retrieved_at_utc'],reused=True)
        if page.get('match'):
            mid=str(page['match']['id'])
            if mid in games:pages.setdefault(mid,source)
        for m in page.get('matches',[]):
            mid=str(m['id'])
            if mid not in games or not m.get('slug'):continue
            g=games[mid];away,home=json.loads(g['native_team_ids_json'])
            assert str(m['away_team']['id'])==str(away) and str(m['home_team']['id'])==str(home)
            assert m['away_score']==g['scoreA'] and m['home_score']==g['scoreB']
            urls.setdefault(mid,dict(url='https://www.laliga.com/en-GB/match/'+m['slug'],calendar_source=source))
    return pages,urls


def main():
    p=argparse.ArgumentParser();p.add_argument('--all',action='store_true');p.add_argument('--retry',action='store_true');p.add_argument('--retained-only',action='store_true');p.add_argument('--workers',type=int,default=4);a=p.parse_args()
    with read_db(PREVIOUS/'expanded.sqlite') as c:games={str(r['official_game_id']):dict(r) for r in c.execute("SELECT * FROM soccer_games WHERE league='La Liga' AND date BETWEEN '2021-01-01' AND '2026-09-30'")}
    pages,urls=source_index(games);db=sqlite3.connect(ROOT_OUT/'soccer_additional.sqlite',timeout=60)
    done={r[0] for r in db.execute("SELECT game_id FROM games WHERE league='La Liga' AND json_extract(body,'$.parser_version')=?",(PARSER_VERSION,))}
    ordered=sorted(games.values(),key=lambda g:(g['date'],g['game_id']))
    wanted=ordered if a.all else [ordered[i] for i in [0,len(ordered)//2,-1]]
    tasks=[g for g in wanted if (a.retry or g['game_id'] not in done) and (not a.retained_only or str(g['official_game_id']) in pages)];client=OfficialClient(per_second=2)
    counts=collections.Counter();mark=10
    print(json.dumps(dict(stage='laliga_official_facts',expected_games=len(wanted),remaining=len(tasks),retained_pages=len(pages),documented_match_urls=len(urls))),flush=True)
    def fetch(g):
        mid=str(g['official_game_id']);source=None
        try:
            if mid in pages:
                source=pages[mid];blob=(PROJECT/source['raw_file']).read_bytes();assert hashlib.sha256(blob).hexdigest()==source['sha256']
            else:
                assert mid in urls,'Official match URL requires calendar recovery'
                blob,source=client.get(urls[mid]['url'],'Dated La Liga player lineup, substitutions, goals and team statistics: '+mid,kind='official_laliga_match',document=True)
                assert blob,'Official document acquisition requires retry: '+source['return_status']
                source['calendar_source']=urls[mid]['calendar_source']
            return g,parse(g,page_props(blob),source),None
        except (AssertionError,KeyError,ValueError,TypeError) as exc:return g,None,dict(reason=type(exc).__name__+': '+str(exc),source=source)
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
        for n,(g,row,error) in enumerate(pool.map(fetch,tasks),1):
            with db:
                if row:
                    db.execute('INSERT OR REPLACE INTO games VALUES (?,?,?)',('La Liga',g['game_id'],json.dumps(row,allow_nan=False)))
                    db.execute("DELETE FROM issues WHERE league='La Liga' AND game_id=?",(g['game_id'],))
                    counts['games']+=1;counts['player_rows']+=len(row['players']);counts['games_with_derivation_issues']+=bool(row['issues'])
                else:
                    db.execute('INSERT OR REPLACE INTO issues VALUES (?,?,?)',('La Liga',g['game_id'],json.dumps(error)));counts['game_issues']+=1
            if n*100>=mark*len(tasks) or n==len(tasks):
                v=dict(at_utc=stamp(),processed=n,total=len(tasks),percent=round(100*n/len(tasks),1),counts=dict(counts),scope='retained official pages' if a.retained_only else 'full history');dump(ROOT_OUT/('laliga_retained_progress.json' if a.retained_only else 'laliga_additional_progress.json'),v);print(json.dumps(v),flush=True);mark+=10
    dump(ROOT_OUT/'laliga_additional_sources.json',dict(at_utc=stamp(),counts=dict(counts),retained_pages=len(pages),documented_match_urls=len(urls),
         unmatched_official_game_ids=sorted(set(games)-set(pages)-set(urls))))
    print(json.dumps(dict(counts)),flush=True);db.close()


if __name__=='__main__':main()
