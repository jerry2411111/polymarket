"""Freeze the two user-selected US strategies without changing the sports app."""
import argparse,json,pickle,shutil,sys,re
from pathlib import Path
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from sklearn.linear_model import LogisticRegression
from common import ROOT_OUT,PROJECT,REPORTS,dump,stamp,file_sha256
from us_market_data import RESULT as STUDY
import models

WORK=ROOT_OUT/'_work/us_baseline_export'
DEST=ROOT_OUT/'retained_models/us_strategy_baselines'
CHOICES={'nhl':('sports_baseline','edge_bucket_max2',6),'soccer':('meta_gate','meta_gt_0.55',1)}

def prepare():
    assert not DEST.exists(),'Existing frozen baselines must not be overwritten'
    WORK.mkdir(parents=True,exist_ok=True)
    import nhl_winner_stability as nhl
    nhl.WORK=WORK/'nhl';nhl.RESULT=WORK/'nhl_audit'
    if not (nhl.WORK/'nhl_features.parquet').exists():nhl.build()
    print('NHL baseline features ready',flush=True)
    if (WORK/'soccer/soccer_features.parquet').exists():return
    import loss_case_revision as case
    import soccer_laliga_current_history as soccer
    import soccer_current_roster as identity
    from pl_sparse_statistics import merge_proved_zeros
    case.WORK=WORK/'soccer_sources';case.RESULT=WORK/'soccer_audit';case.RESULT.mkdir(exist_ok=True)
    if not (case.WORK/'sources_ready.json').exists():case.sources()
    g,o,p,labels,keys,meta=case.load_sources()
    p,_=merge_proved_zeros(p,audit_dir=WORK/'soccer_zero_audit')
    soccer.WORK=WORK/'soccer_sources';soccer.RESULT=WORK/'soccer_audit'
    cg,co,cp,cl,_=soccer.clock_repairs(g,o,p,labels)
    identity.RESULT=WORK/'soccer_audit';linked=identity.person_links(cp)
    latest=pd.to_datetime(linked.available_at_utc,utc=True,format='mixed').groupby(linked.game_id).max()
    cg['available_time']=pd.concat([cg.available_time,cg.game_id.map(latest)],axis=1).max(axis=1)
    co['available_time']=co.game_id.map(cg.set_index('game_id').available_time)
    frame,_=soccer.model_frame(cg,co,linked,cl,keys,meta)
    folder=WORK/'soccer';folder.mkdir(exist_ok=True)
    frame.reset_index().to_parquet(folder/'soccer_features.parquet',index=False)
    print('Soccer baseline features ready',len(frame),flush=True)

def fit():
    assert not DEST.exists()
    forecasts=pd.read_parquet(STUDY/'base_predictions.parquet');checks=[]
    for sport in CHOICES:
        folder=WORK/sport;source=folder/(sport+'_features.parquet')
        data=pd.read_parquet(source).sort_values(['prediction_time','game_id']).reset_index(drop=True)
        data=pd.concat([data,pd.get_dummies(data.league,prefix='league',dtype=float)],axis=1)
        reference=forecasts[forecasts.sport.eq(sport)];fold=reference.fold.max();cut=pd.Timestamp(fold+'-01',tz='UTC')
        spec=models.CANDIDATES['granular_logistic_strong'] if sport=='nhl' else json.loads((ROOT_OUT/'simulation_results/soccer_laliga_current_history/experiment_plan.json').read_bytes())['recipe']
        cols=models.columns(data,spec);assert len(cols)==(37 if sport=='nhl' else 41)
        X=lambda g:g[cols].replace([np.inf,-np.inf],np.nan).astype(float)
        prior=data[data.available_time.lt(cut)]
        cal=prior[prior.prediction_time.ge(cut-pd.Timedelta(days=180))]
        train=prior[prior.available_time.lt(cal.prediction_time.min())]
        test=reference[reference.fold.eq(fold)];test_input=data.set_index('game_id').loc[test.game_id]
        with threadpool_limits(limits=4):
            old=models.make_model(spec,sport);models.fit_model(old,X(train),train,spec,cal.prediction_time.min())
            calibrator=models.calibration_fit(old.predict_proba(X(cal)),cal.target.astype(int),spec.get('calibration','temperature'))
            fitted=models.make_model(spec,sport);models.fit_model(fitted,X(prior),prior,spec,cut)
            got=models.apply_calibration(fitted.predict_proba(X(test_input)),calibrator)
        expected=test[['p0','p1']+(['p2'] if sport=='soccer' else [])].to_numpy()
        error=float(np.max(np.abs(got-expected)))
        assert error<1e-10,(sport,error)
        bundle=dict(model=fitted,calibrator=calibrator,columns=cols,recipe=spec,boundary=cut,training_games=len(prior),train_label_max=prior.available_time.max(),source_sha256=file_sha256(source),role='Sports forecast; exact last historical monthly fit, not a new October deployment')
        (folder/'sports_model.pkl').write_bytes(pickle.dumps(bundle,protocol=5))
        checks.append(dict(component=sport+'_sports',fold=fold,replayed_forecasts=len(test),maximum_probability_error=error,training_games=len(prior)))
        print('Exact sports replay',checks[-1],flush=True)
    # Refit the exact saved soccer confidence model, including its preprocessing.
    from us_market_experiments import CONTEXT,preprocessor,calibrate,apply_temp
    f=pd.read_parquet(STUDY/'entry_dataset.parquet');g=f[f.sport.eq('soccer')&f.entry_hours.eq(1)].copy()
    g=g[g[['q0','q1','q2']].notna().all(axis=1)].sort_values('entry')
    p=g[['p0','p1','p2']].to_numpy();side=p.argmax(axis=1);q=g[['q0','q1','q2']].to_numpy()
    g['confidence']=p.max(axis=1);g['selected_quote']=q[np.arange(len(g)),side];g['edge']=g.confidence-g.selected_quote
    g['entropy']=-np.sum(p*np.log(np.clip(p,1e-8,1)),axis=1);ordered=np.sort(p,axis=1);g['margin']=ordered[:,-1]-ordered[:,-2]
    g['home_pick']=(side==1).astype(float);g['correct']=(side==g.target.to_numpy()).astype(int)
    g['activity']=[r['quote_changes'+str(s)] for r,s in zip(g.to_dict('records'),side)]
    g['age']=[r['quote_age_minutes'+str(s)] for r,s in zip(g.to_dict('records'),side)]
    cols=['confidence','selected_quote','edge','entropy','margin','home_pick','activity','age']+CONTEXT
    saved=pd.read_parquet(STUDY/'market_model_predictions.parquet');saved=saved[saved.sport.eq('soccer')&saved.model.eq('meta_gate')&saved.entry_hours.eq(1)]
    fold=saved.second_stage_fold.max();cut=pd.Timestamp(fold,tz='UTC');test=saved[saved.second_stage_fold.eq(fold)]
    prior=g[g.exit.lt(cut)].sort_values('entry');cal=prior.tail(60);train=prior.iloc[:-60];train=train[train.exit.lt(cal.entry.min())]
    with threadpool_limits(limits=1):
        fitted=preprocessor(LogisticRegression(C=.02,max_iter=2000,random_state=37)).fit(train[cols],train.correct)
        temperature=calibrate(fitted.predict_proba(cal[cols]),cal.correct)
        got=apply_temp(fitted.predict_proba(g.set_index('game_id').loc[test.game_id,cols]),temperature)[:,1]
    error=float(np.max(np.abs(got-test.meta_confidence.to_numpy())));assert error<1e-12,error
    (WORK/'soccer/confidence_model.pkl').write_bytes(pickle.dumps(dict(model=fitted,temperature=temperature,columns=cols,boundary=cut,training_games=len(train),calibration_games=len(cal),training_label_max=train.exit.max(),calibration_label_max=cal.exit.max()),protocol=5))
    g.to_parquet(WORK/'soccer/confidence_inputs.parquet',index=False)
    checks.append(dict(component='soccer_confidence',fold=fold,replayed_forecasts=len(test),maximum_probability_error=error,training_games=len(train),calibration_games=len(cal)))
    dump(WORK/'model_replay.json',dict(status='PASS',at_utc=stamp(),checks=checks));print(checks[-1],flush=True)

def publish():
    assert not DEST.exists(),'Do not overwrite a frozen baseline'
    proof=json.loads((WORK/'model_replay.json').read_bytes());assert proof['status']=='PASS'
    annual=pd.read_csv(STUDY/'us_annual.csv');bets=pd.read_parquet(STUDY/'us_bets.parquet');daily=pd.read_parquet(STUDY/'us_daily.parquet')
    forecasts=pd.read_parquet(STUDY/'base_predictions.parquet');market=pd.read_parquet(STUDY/'market_model_predictions.parquet')
    DEST.mkdir();index={};protected=json.loads((STUDY/'protocol.json').read_bytes())['protected_sha256']
    for sport,(model,rule,h) in CHOICES.items():
        folder=DEST/sport;folder.mkdir()
        for name in ['sports_model.pkl',sport+'_features.parquet']+(['confidence_model.pkl','confidence_inputs.parquet'] if sport=='soccer' else []):shutil.copy2(WORK/sport/name,folder/name)
        def choose(f):return f[f.sport.eq(sport)&f.model.eq(model)&f.rule.eq(rule)&f.entry_hours.eq(h)]
        a=choose(annual);b=choose(bets);d=choose(daily)
        a.to_csv(folder/'annual.csv',index=False);b.to_parquet(folder/'bets.parquet',index=False);d.to_parquet(folder/'daily.parquet',index=False)
        forecasts[forecasts.sport.eq(sport)].to_parquet(folder/'sports_forecasts.parquet',index=False)
        market[market.sport.eq(sport)&market.model.eq(model)&market.entry_hours.eq(h)].to_parquet(folder/'entry_forecasts.parquet',index=False)
        metrics=json.loads(a[a.year.eq(2026)].to_json(orient='records'))[0]
        config=dict(baseline_id=sport+'_us_'+('meta55_pre1' if sport=='soccer' else 'edge_band_cap2_pre6')+'_v1',user_selected=True,selected_at_utc=stamp(),deployment='Research baseline only; NBA/MLB app unchanged',model=model,rule=rule,entry_hours=h,metrics2026=metrics,
            training='Expanding 2021+ sports history; monthly UTC refits; earlier-only 180-day base calibration; features as of pre12',
            selection='argmax of sports outcome probabilities; p>.51 and confidence r>.55; no bet before confidence model readiness' if sport=='soccer' else 'argmax sports probability; p>.60 and q>.50; first two qualifying bets per UTC day in each floor((p-q)/.04) band',
            confidence_training='Monthly; minimum200 earlier OOS US-priced examples; last60 for calibration; earlier fitting labels purged before first calibration entry' if sport=='soccer' else None,
            stake='5*max(100*p-51,0) USD; fixed-dollar sizing on initial $2000; concurrent requests share available cash; no borrowing',
            prices='Official US /v1/price-history; longPrice is YES display price normally best ask, shortPrice is NO display price normally1-YES best bid. Latest prior observation in [T-12h,entry]. Assume stake fills at display price; historical depth not established.',
            settlement='Hold to recorded official-result availability; open positions at cost; no cost deduction',
            sharpe='sqrt(365.25)*mean(calendar daily return)/sampleSD; 2026 account Jan1-Sep29 includes idle days',
            evaluation='Retrospectively compared 2026 strategies; not untouched holdout. No eligible primary US coverage established for2024/25.',
            important='The 74-bet soccer baseline is not the 154-bet baseline-then-meta comparison; no fallback added.' if sport=='soccer' else 'Do not replace this37-input model with the older34-input retained logistic.',
            reference_folder=str(STUDY.relative_to(PROJECT)))
        dump(folder/'config.json',config);index[sport]=dict(baseline_id=config['baseline_id'],folder=sport,metrics2026=metrics)
    runtime=DEST/'runtime';runtime.mkdir()
    for name in ['models.py','context_preprocessing.py']:shutil.copy2(Path(__file__).parent/name,runtime/name)
    dump(DEST/'validation.json',proof)
    for name,digest in protected.items():assert file_sha256(PROJECT/name)==digest,name
    text='''# Selected NHL and soccer research baselines

These are the two exact strategies selected by the user on October 3, 2026 (America/Chicago). They are retained for future comparisons; the running NBA/MLB app is unchanged.

| Baseline | Entry | Bets | Win rate | Return | Sharpe | Max drawdown |
|---|---:|---:|---:|---:|---:|---:|
| Soccer: sports winner + confidence r > 55% | pre1 | 74 | 79.7297% | 35.7865% | 3.324021 | 3.2268% |
| NHL: sports winner + two bets per edge band/day | pre6 | 113 | 73.4513% | 49.5835% | 2.062372 | 16.7932% |

Soccer buys the sports model argmax when p > .51 and the second model r > .55. There is no fallback before the second model is ready. NHL requires p > .60 and q > .50, taking the first two qualifying bets per UTC day in each fixed floor((p-q)/.04) band. Neither strategy requires p > q. Stake is $5 per percentage point above51%, from a $2000 starting account; use available cash only and hold until result availability.

Buy prices are official Polymarket US historical display prices: YES longPrice is normally best ask; NO shortPrice normally1-YES best bid. Soccer uses outcome YES contracts; NHL maps both sides of its binary contract. Assume the full stake fills at that quoted price. Historical depth/fillability is not established. Use latest prior quotes inside the final12pregame hours; do not substitute international quotes or midpoint prices. No extra cost deduction.

Sports training expands from2021 and refits monthly. Each game uses its own historical pre12 inputs. Base calibration is trailing180days with earlier-only fitting. Soccer confidence training uses earlier OOS predictions and US prices, at least200 prior cases, reserving the latest60 for calibration. The saved pickle files are the exact September2026 fits replayed against archived predictions, not October/live refits. Full rolling2024-2026 forecasts are also retained. Soccer's confidence-model evaluation is July-September2026; Sharpe includes all272calendar days from Jan1 through Sep29. NHL bets run March-September2026. 2026has been inspected retrospectively and is not an untouched holdout. The complete soccer baseline-then-meta comparison returned21.20% with Sharpe0.98; it is separate and is not this selected74-bet baseline.

Each sport has config.json, fitted model files, final feature data, forecasts, annual.csv, bets.parquet and daily.parquet. validation.json records exact September probability replay. manifest.json records hashes. Keep outcome mapping0=away/TeamA,1=home/TeamB,2=regulation draw for soccer. Model inputs must follow the saved columns order. Soccer confidence probabilities use softmax(log(predict_proba)/temperature). Sports probabilities use the saved calibrator and runtime/models.py apply_calibration. Load only these trusted local pickles in the project's Python environment, with data collecting/nhl_soccer_iteration and the frozen runtime directory on the import path.

Reproduce from historical_expansion using final_models/.venv/Scripts/python.exe and data collecting/nhl_soccer_iteration/us_save_baselines.py: prepare, fit, publish (separate commands). Publication refuses to overwrite an existing baseline. Future retraining/experiments must use a new version; do not replace these benchmark files. Raw US evidence and acquisition scripts remain in the referenced research study and common raw folder.
'''
    text=re.sub(r'(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])',' ',text)
    (DEST/'README.md').write_text(text,encoding='utf-8')
    buying='''# Purchase and sizing rules for the four selected baselines

p is the sports model probability of its selected outcome; q is the purchase price per $1 payout share. Soccer r is the second model probability that the sports selection is correct.

| Baseline | Purchase rule | Stake sizing | Contract side |
|---|---|---|---|
| NBA | Buy the predicted winner at pre12; no p>q requirement | 1% of current account equity per bet; maximum aggregate open cost20% | Buy the selected team's outcome. In a binary TeamA-wins contract, YES represents TeamA and NO represents TeamB; verify the actual outcome mapping. |
| MLB | Buy the predicted winner only when q<=p-.05; confirmed pregame pitchers and batting orders | 1% of current account equity per bet; maximum aggregate open cost20%; one purchase per game | Buy the selected team's full-game winning outcome, using the actual contract mapping. NO on TeamA represents TeamB only in the corresponding binary full-game winner contract. |
| Soccer Sharpe3.32 | At pre1 buy the sports argmax when p>.51 and r>.55; no price-discount requirement | $5*max(100p-51,0), fixed-dollar sizing from the $2000 starting account, limited by cash. Use p, not r. | YES on the selected home-win, away-win or regulation-draw contract. NO on one team includes both the opponent winning and a draw, so is never substituted for opponent YES. |
| NHL Sharpe2.06 | At pre6 buy sports argmax when p>.60 and q>.50; first two qualifying bets per UTC day in each floor((p-q)/.04) band; no p>q requirement | $5*max(100p-51,0), fixed-dollar sizing from the $2000 starting account, limited by cash | Buy the predicted winner: YES on the long/affirmative team or NO for the opposing team in a binary full-game winner contract including the tie-break outcome. NO does not mean betting against our prediction. |

All four hold until recorded result/settlement. No borrowing or reuse of unsettled cash. Concurrent NHL/soccer stakes are scaled proportionally if cash is insufficient; they do not carry an additional20% aggregate open-cost cap. At p=.65, NHL/soccer request$70 even if the account has grown. At $2000 current equity NBA/MLB request$20.

Price and decimal odds move oppositely: decimal odds=1/q. A higher price is more expensive; higher decimal odds are cheaper. NBA/soccer/NHL may buy above p if their listed conditions hold. MLB requires a five-percentage-point discount. These are saved backtest rules; NBA's app display of below-probability price guidance does not change its historical winner-only simulation.

The saved NBA/MLB historical simulations used international Polymarket token observations, not verified executable asks. The NHL/soccer study uses Polymarket US history: YES longPrice normally derives from best ask, and NO shortPrice normally from1-YES best bid. Full-stake fills at those display prices are assumed; historical depth is unverified. NBA/MLB app current quotes use US data. No extra spread/cost deduction was applied.
'''
    buying=re.sub(r'(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])',' ',buying)
    (DEST/'BUY_RULES.md').write_text(buying,encoding='utf-8')
    import sklearn
    dump(DEST/'environment.json',dict(python=sys.version,numpy=np.__version__,pandas=pd.__version__,scikit_learn=sklearn.__version__))
    hashes={str(p.relative_to(DEST)):file_sha256(p) for p in DEST.rglob('*') if p.is_file()}
    dump(DEST/'manifest.json',dict(created_at_utc=stamp(),user_selected=True,baselines=index,sha256=hashes,source_script_sha256={p.name:file_sha256(p) for p in Path(__file__).parent.glob('us_*.py')},app_changed=False))
    registry=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(registry.read_bytes());m['scripts'][Path(__file__).name]=file_sha256(Path(__file__));m['retained_scripts']=len(m['scripts']);m['selected_us_baselines']=dict(path=str(DEST.relative_to(ROOT_OUT)),baseline_ids=[v['baseline_id'] for v in index.values()],manifest_sha256=file_sha256(DEST/'manifest.json'));m['updated_utc']=stamp();dump(registry,m)
    continuation=ROOT_OUT/'research_continuation.json';state=json.loads(continuation.read_bytes());state['selected_us_baselines']=m['selected_us_baselines'];state['last_action']='User-selected NHL Sharpe2.06 and soccer Sharpe3.32 strategies frozen as research baselines, exact last monthly fits replayed, app unchanged.';dump(continuation,state)
    catalog=REPORTS/'catalog.md';s=catalog.read_text(encoding='utf-8');s+='\n## User-selected US strategy baselines\n\n`retained_models/us_strategy_baselines/README.md` identifies the exact NHL pre6 band-cap and soccer pre1 meta55 baselines, model weights, dated feature data and forecast/account tables. Existing app tables are unchanged.\n';catalog.write_text(s,encoding='utf-8')
    from final_pipeline import discard_work,cleanup
    discard_work(WORK);cleanup();print('Published frozen baselines:',DEST,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['prepare','fit','publish']);globals()[p.parse_args().stage]()
