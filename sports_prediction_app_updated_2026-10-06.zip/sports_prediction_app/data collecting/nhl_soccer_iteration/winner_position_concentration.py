"""Same predicted winners, bounded position sizes selected before later testing."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from common import ROOT_OUT, REPORTS, dump, stamp, file_sha256
from backtest import quote_inputs
import nhl_winner_classifier as nhl
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine

LABEL='winner_position_concentration'
RESULT=ROOT_OUT/'simulation_results'/LABEL
RULES={'confidence5':('dollars_cash_only',None),
       'confidence5_max20':('dollars_cash_only',20.),
       'one_percent_equity':('fixed1pct_cap20',None)}


def main():
    RESULT.mkdir(exist_ok=True);assert not (RESULT/'validation.json').exists()
    plan=dict(at_utc=stamp(),
        hypothesis='Large linear-confidence stakes concentrate losses when confident favourites lose. Test reducing concentration without altering which team is predicted or importing prices into the forecast.',
        sources={'nhl':'Existing logistic, p>60percent and own outcome price>50percent; currentmarketagreement reference.',
                 'soccer':'Corrected clock_identity model,homewinner argmax,p>51percent;homefilter selectedon2025.'},
        variants={'confidence5':'Existing5dollars perpercentagepointabove51.',
                  'confidence5_max20':'Same confidence rule capped at20dollars, the existing1percent-of-starting2000benchmark.',
                  'one_percent_equity':'Existing1percentcurrentequity stake with20percenttotalopencost cap; no amount grid.'},
        gate='Each alternative must improve2025Sharpe withpositive return and no worse2024Sharpe where defined. Recordproviderdecisions before2026; only qualifying alternatives evaluated later.',
        account='Annual2000cash;no costs;holdofficialsettlement;UTCdailyreturns includeidle;Sharpe sqrt365.25.',
        limitation='Repeatedly inspected2026is retrospective research. PMhistoricaltokenprices are not verifiedUSexecutable asks;KalshiYESaskcloses remainseparate.',app_changed=False)
    dump(RESULT/'plan.json',plan)
    quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    rows=[];bets=[];days=[];checks=[];choices={}
    for stage in ['development','evaluation']:
        for sport in ['nhl','soccer']:
            if sport=='nhl':
                p=nhl.inputs(stage);p=p[p.variant.eq('logistic')]
            else:
                p=pd.read_parquet(ROOT_OUT/'simulation_results/soccer_laliga_current_history'/(stage+'_predictions.parquet'))
                p=p[p.variant.eq('clock_identity')]
            assert p.game_id.is_unique and p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
            f=transfer.normalize(sport,p,quotes,pick_growth=False)
            f=f[f.probability.gt(.60)&f.price.gt(.5)] if sport=='nhl' else f[f.side.eq(1)&f.probability.gt(.51)]
            for provider,g in f.groupby('provider'):
                for rule,(sizing,cap) in RULES.items():
                    if stage=='evaluation' and rule!='confidence5' and not choices.get((sport,provider,rule),False):continue
                    for year in sorted(p.prediction_time.dt.year.unique()):
                        m,b,l,d=engine.simulate(g,int(year),'all_selected_outcomes',sizing,5.,2000.,per_bet_cap_dollars=cap)
                        key=dict(sport=sport,provider=provider,variant=rule,year=int(year),stage=stage)
                        rows.append(key|m);checks.append(key|engine.validate(b,l,d,sizing,5.,2000.,per_bet_cap_dollars=cap))
                        if len(b):
                            cols=['p0','p1']+(['p2'] if sport=='soccer' else [])
                            assert b.side.eq(b[cols].to_numpy().argmax(axis=1)).all()
                            bets.append(b.assign(**key))
                        days.append(d.assign(**key))
        if stage=='development':
            for (sport,provider),g in pd.DataFrame(rows).groupby(['sport','provider']):
                ix=g.set_index(['variant','year']);ctrl=ix.loc[('confidence5',2025)]
                for rule in RULES.keys()-{'confidence5'}:
                    c=ix.loc[(rule,2025)];a=ix.loc[('confidence5',2024),'sharpe'];b=ix.loc[(rule,2024),'sharpe']
                    choices[sport,provider,rule]=bool(c.sharpe>ctrl.sharpe and c.return_pct>0 and (pd.isna(a) or b>=a))
            dump(RESULT/'selection.json',dict(at_utc=stamp(),choices=[dict(sport=k[0],provider=k[1],variant=k[2],qualified=v) for k,v in choices.items()],used2026=False,adopted=False))
    a=pd.DataFrame(rows);a.to_csv(RESULT/'annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/'bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'daily.parquet',index=False)
    replays=0
    for sport,path,variant in [('nhl',ROOT_OUT/'simulation_results/nhl_winner_classifier/agreement_annual.csv','market_agreement'),
                               ('soccer',ROOT_OUT/'simulation_results/soccer_winner_home_context/annual.csv','home_only')]:
        old=pd.read_csv(path);old=old[old.variant.eq(variant)].set_index(['provider','year'])
        ctrl=a[a.sport.eq(sport)&a.variant.eq('confidence5')].set_index(['provider','year']);common=old.index.intersection(ctrl.index)
        for c in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
            assert np.allclose(old.loc[common,c],ctrl.loc[common,c],rtol=0,atol=1e-9,equal_nan=True)
        replays+=len(common)
    proof=dict(status='PASS',at_utc=stamp(),checks=checks,control_rows_replayed=replays,every_purchase_model_argmax=True,app_changed=False,adopted=False)
    dump(RESULT/'validation.json',proof)
    cols=['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']
    table='\n'.join(['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']+['| '+' | '.join(f'{v:.6f}' if isinstance(v,float) else str(v) for v in row)+' |' for row in a[cols].itertuples(index=False,name=None)])
    (REPORTS/(LABEL+'.md')).write_text('\n\n'.join(['# Winner-only position concentration',json.dumps(plan,indent=2),table,'Independent cash,sourceclock,winneridentity,andbaseline replays passed. No application/model adoption.'])+'\n',encoding='utf8')
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL]=dict(plan=plan,selection=json.loads((RESULT/'selection.json').read_bytes()),validation=proof);dump(path,old)
    from final_pipeline import cleanup
    cleanup();path=ROOT_OUT/'retention/retained_artifacts.json';d=json.loads(path.read_bytes());d['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))};d.update(updated_utc=stamp(),retained_scripts=len(d['scripts']));dump(path,d)
    print(a[cols].to_string(index=False),flush=True)


if __name__=='__main__':main()
