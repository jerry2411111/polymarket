"""Official PL goal-event reconciliation for goalkeeper shot-quality scope.

The route is documented by the current official site's footballApi client.
An absent ownGoals statistic is never interpreted as zero: a complete event
list must reconcile with both official final scores and native team IDs.
"""
import argparse
import collections
import json

import pandas as pd

from common import OfficialClient,PROJECT,PREVIOUS,ROOT_OUT,read_db,dump,stamp,file_sha256

FOLDER=ROOT_OUT/'soccer_keeper_v81'


def load_events(game):
    url=f"https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v1/matches/{game['official_game_id']}/events"
    with read_db(ROOT_OUT/'acquisition.sqlite') as db:
        r=db.execute("SELECT * FROM request_audit WHERE url=? AND return_status='200' ORDER BY request_number DESC LIMIT 1",(url,)).fetchone()
    if r is None:return None,None,'Official event response needs collection'
    source=dict(r);path=PROJECT/source['raw_file'];assert file_sha256(path)==source['sha256']
    data=json.loads(path.read_bytes());native=json.loads(game['native_team_ids_json'])
    if not isinstance(data,dict):return None,source,'Event response not a team mapping'
    for label,key,score in [('A','awayTeam','scoreA'),('B','homeTeam','scoreB')]:
        team=data.get(key,{})
        if str(team.get('id'))!=str(native[0 if label=='A' else 1]):return None,source,'Native team ID mismatch'
        goals=team.get('goals')
        if not isinstance(goals,list) or len(goals)!=game[score]:return None,source,'Event goals do not reconcile with official final score'
        if any(g.get('goalType') not in ['Goal','Own','Penalty'] for g in goals):return None,source,'Unrecognized goal type needs interpretation'
        if any(g.get('period') not in ['FirstHalf','SecondHalf'] for g in goals):return None,source,'Non-regulation goal needs separate scope'
    return data,source,None


def reconcile(row,game):
    data,source,error=load_events(game)
    if error:return dict(status=error,source=source)
    own_key='awayTeam' if row.side=='A' else 'homeTeam';opp_key='homeTeam' if row.side=='A' else 'awayTeam'
    own=data[own_key];goals=data[opp_key]['goals'];own_goals=[g for g in goals if g['goalType']=='Own']
    proof=dict(status='verified goal totals',source=source,team_own_goals=len(own_goals),
        goals_pointer='/'+opp_key+'/goals',official_opponent_score=len(goals),
        goal_counts={k:len(data[k]['goals']) for k in ['awayTeam','homeTeam']})
    # A keeper listed as a starting goalkeeper, present for >=90 minutes,
    # with no substitution/red-card event, has full regulated exposure.
    evidence=json.loads(row.derivation_json)['role_evidence'];s=evidence['source']
    path=PROJECT/s['raw_file'];assert file_sha256(path)==s['sha256'];lineup=json.loads(path.read_bytes())
    key='away_team' if row.side=='A' else 'home_team';players=lineup[key]['players']
    starts=[p for p in players if str(p.get('id'))==str(row.official_player_id) and p.get('position')=='Goalkeeper']
    subs=own.get('subs');cards=own.get('cards')
    full=(len(starts)==1 and row.minutes>=90 and isinstance(subs,list) and isinstance(cards,list)
        and not any(str(s.get(k))==str(row.official_player_id) for s in subs for k in ['playerOnId','playerOffId'])
        and not any(str(c.get('playerId'))==str(row.official_player_id) and c.get('type')!='Yellow' for c in cards))
    proof.update(full_match_exposure=bool(full),lineup_source=s)
    if full:
        proof.update(goals_conceded=len(goals),goals_conceded_excluding_own=len(goals)-len(own_goals),
            own_goal_basis='Complete official goal list and uninterrupted starting goalkeeper exposure')
    elif len(starts)==1 and isinstance(subs,list) and isinstance(cards,list):
        departures=[s for s in subs if str(s.get('playerOffId'))==str(row.official_player_id)]
        departures += [c for c in cards if str(c.get('playerId'))==str(row.official_player_id) and c.get('type') in ['StraightRed','SecondYellow']]
        returns=[s for s in subs if str(s.get('playerOnId'))==str(row.official_player_id)]
        if len(departures)==1 and not returns and departures[0].get('timestamp') and all(g.get('timestamp') for g in goals):
            fmt='%Y%m%dT%H%M%S%z';end=pd.to_datetime(departures[0]['timestamp'],format=fmt,utc=True)
            times=[pd.to_datetime(g['timestamp'],format=fmt,utc=True) for g in goals]
            assert all(abs((end-t).total_seconds())<6*3600 for t in times),'Goal/departure dates disagree'
            if not any(t==end for t in times):
                faced=[g for g,t in zip(goals,times) if t<end]
                proof.update(goals_conceded=len(faced),goals_conceded_excluding_own=sum(g['goalType']!='Own' for g in faced),
                    own_goal_basis='Official starting role; all valid goals timestamped before keeper departure',
                    departure=departures[0],exposure_end_utc=end.isoformat())
        if 'goals_conceded_excluding_own' not in proof and not own_goals and pd.notna(row.goals_conceded):
            proof.update(goals_conceded=float(row.goals_conceded),goals_conceded_excluding_own=float(row.goals_conceded),
                own_goal_basis='Complete official goal list proves zero own goals')
        if 'goals_conceded_excluding_own' not in proof:proof['status']='Keeper exposure at goal events needs recovery'
    elif not own_goals and pd.notna(row.goals_conceded):
        proof.update(goals_conceded=float(row.goals_conceded),goals_conceded_excluding_own=float(row.goals_conceded),
            own_goal_basis='Complete official goal list proves zero own goals')
    else:proof['status']='Keeper exposure at goal events needs recovery'
    return proof


def collect():
    q=pd.read_parquet(ROOT_OUT/'soccer_goalkeeper_shot_difficulty.parquet')
    selected=q[q.status.str.startswith(('own-goal','conceded goals'))]
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games={r['game_id']:dict(r) for r in db.execute("SELECT * FROM soccer_games WHERE league='Premier League'")}
    pending=selected.drop_duplicates('game_id');c=OfficialClient(per_second=3);sources=[];threshold=10
    for i,row in enumerate(pending.itertuples(),1):
        url=f'https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v1/matches/{row.official_game_id}/events'
        _,source=c.get(url,f'{row.date} official goal events for keeper own-goal reconciliation','official_goal_events')
        sources.append(source)
        while 100*i/len(pending)>=threshold:
            print(json.dumps(dict(stage='official_keeper_goal_events',percent=threshold,complete=i,total=len(pending))),flush=True);threshold+=10
    results=[]
    for row in selected.itertuples():
        proof=reconcile(row,games[row.game_id]);results.append(dict(game_id=row.game_id,side=row.side,player_id=row.official_player_id,proof=proof))
    counts=collections.Counter(r['proof']['status'] for r in results)
    report=dict(at_utc=stamp(),rows=len(results),games=len(pending),counts=dict(counts),sources=sources,records=results)
    dump(FOLDER/'pl_goal_event_recovery.json',report)
    print(json.dumps({k:v for k,v in report.items() if k not in ['sources','records']}),flush=True)


def validate():
    """Replay published derivations from immutable goal lists and final calendars."""
    from soccer_keeper_quality import calendar_record
    q=pd.read_parquet(ROOT_OUT/'soccer_goalkeeper_shot_difficulty.parquet')
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games={r['game_id']:dict(r) for r in db.execute("SELECT * FROM soccer_games WHERE league='Premier League'")}
    calendars={};count=0;departures=0;raw_omissions=0;blocked=[]
    for row in q.itertuples():
        proof=json.loads(row.derivation_json).get('official_event_proof')
        if not proof:continue
        if row.status!='usable':
            blocked.append(dict(game_id=row.game_id,side=row.side,status=proof['status']));continue
        if row.game_id not in calendars:calendars[row.game_id]=calendar_record(games[row.game_id])
        cal,_=calendars[row.game_id];source=proof['source'];path=PROJECT/source['raw_file']
        assert file_sha256(path)==source['sha256'];events=json.loads(path.read_bytes())
        for key in ['awayTeam','homeTeam']:
            assert str(events[key]['id'])==str(cal[key]['id'])
            assert len(events[key]['goals'])==cal[key]['score']
        opp='homeTeam' if row.side=='A' else 'awayTeam';faced=events[opp]['goals']
        if proof.get('exposure_end_utc'):
            end=pd.Timestamp(proof['exposure_end_utc']);departures+=1
            faced=[g for g in faced if pd.to_datetime(g['timestamp'],format='%Y%m%dT%H%M%S%z',utc=True)<end]
        own=sum(g['goalType']=='Own' for g in faced)
        if proof['full_match_exposure'] or proof.get('exposure_end_utc'):
            assert row.goals_conceded==len(faced)
            assert row.goals_conceded_excluding_own==len(faced)-own
        else:
            assert own==0 and row.goals_conceded_excluding_own==row.goals_conceded
        assert abs(row.goals_prevented-(row.xgot_conceded-row.goals_conceded_excluding_own))<1e-12
        raw_omissions+=int(pd.isna(row.team_own_goals));count+=1
    result=dict(at_utc=stamp(),status='PASS',recovered_rows=count,dated_calendar_replays=len(calendars),
        keeper_departure_replays=departures,raw_own_goal_omissions_preserved=raw_omissions,remaining=blocked,
        output_sha256=file_sha256(ROOT_OUT/'soccer_goalkeeper_shot_difficulty.parquet'))
    dump(FOLDER/'pl_goal_event_validation.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--validate',action='store_true');a=p.parse_args()
    validate() if a.validate else collect()
