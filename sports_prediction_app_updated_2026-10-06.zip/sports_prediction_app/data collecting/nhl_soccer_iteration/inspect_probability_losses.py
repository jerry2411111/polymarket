"""Reconcile probability-band losses and test bounded stakes with fixed forecasts.

Uses completed rolling-forecast simulations, never fitted-in-sample predictions.
One risk cap ($20 = 1% of starting cash), not a tuned probability-band exclusion.
"""
import argparse
import json
import numpy as np
import pandas as pd
from common import ROOT_OUT, PREVIOUS, dump, stamp, file_sha256, read_db
import test_confidence_dollars as engine
from final_pipeline import cleanup

SIM = ROOT_OUT/'simulation_results'
OUT = SIM/'probability_loss_diagnosis'
KEY = ['sport','provider','year','rule']
BINS = [0,.4,.5,.6,.7,.8,1.00000001]
LABELS = ['under40','40to50','50to60','60to70','70to80','80plus']


def diagnostic(frame):
    f=frame.copy()
    f['probability_band']=pd.cut(f.probability,BINS,labels=LABELS,right=False,include_lowest=True)
    f['gross_lost_stake']=np.where(f.won,0.,f.stake)
    f['gross_winning_profit']=np.maximum(f.profit,0)
    f['realized_profit']=np.where(f.unsettled_at_end,0.,f.profit)
    f['won_stake']=np.where(f.won,f.stake,0.)
    f['probability_stake']=f.probability*f.stake
    f['price_stake']=f.price*f.stake
    f['unit_return']=f.won.astype(float)/f.price-1
    f['brier']=(f.won.astype(float)-f.probability)**2
    cols=dict(bets=('game_id','size'),staked_dollars=('stake','sum'),
        gross_lost_stake_dollars=('gross_lost_stake','sum'),gross_winning_profit_dollars=('gross_winning_profit','sum'),
        cohort_net_profit_dollars=('profit','sum'),in_year_realized_profit_dollars=('realized_profit','sum'),
        mean_probability=('probability','mean'),win_rate=('won','mean'),mean_purchase_price=('price','mean'),
        mean_return_per_dollar=('unit_return','mean'),brier=('brier','mean'),
        won_stake=('won_stake','sum'),probability_stake=('probability_stake','sum'),price_stake=('price_stake','sum'),
        min_stake=('stake','min'),max_stake=('stake','max'),unsettled_bets=('unsettled_at_end','sum'))
    g=f.groupby(KEY+['probability_band'],observed=True).agg(**cols).reset_index()
    totals=f.groupby(KEY).agg(total_lost=('gross_lost_stake','sum'),total_stake=('stake','sum')).reset_index()
    g=g.merge(totals,on=KEY,validate='many_to_one')
    g['gross_loss_share_pct']=100*g.gross_lost_stake_dollars/g.total_lost.replace(0,np.nan)
    g['stake_share_pct']=100*g.staked_dollars/g.total_stake
    g['stake_weighted_roi_pct']=100*g.cohort_net_profit_dollars/g.staked_dollars
    g['stake_weighted_win_rate']=g.won_stake/g.staked_dollars
    g['stake_weighted_probability']=g.probability_stake/g.staked_dollars
    g['stake_weighted_price']=g.price_stake/g.staked_dollars
    # Binomial uncertainty is descriptive; sports outcomes need not be independent.
    n=g.bets; w=g.win_rate; z=1.96; den=1+z*z/n
    center=(w+z*z/(2*n))/den
    width=z*np.sqrt(w*(1-w)/n+z*z/(4*n*n))/den
    g['win_rate_wilson_lower']=center-width;g['win_rate_wilson_upper']=center+width
    actual=f.groupby(KEY).agg(profit=('profit','sum'),realized=('realized_profit','sum'),stake=('stake','sum'))
    replay=g.groupby(KEY)[['cohort_net_profit_dollars','in_year_realized_profit_dollars','staked_dollars']].sum()
    assert np.allclose(actual.to_numpy(),replay.to_numpy(),rtol=0,atol=1e-7)
    return g.drop(columns=['won_stake','probability_stake','price_stake','total_lost','total_stake'])


def main():
    assert not (OUT/'validation.json').exists(),'Completed results already exist'
    OUT.mkdir(exist_ok=True)
    sources={name:SIM/name/'bets.parquet' for name in ['starting_account_staking','probability_price_staking']}
    saved={name:pd.read_parquet(path) for name,path in sources.items()}
    starting=saved['starting_account_staking'];priced=saved['probability_price_staking']
    original=[]
    for amount in [5,20]:
        b=starting[starting.selection.eq('winner_above51')&starting.sizing.eq('dollars_cash_only')&starting.match_budget.eq(amount*100)].copy()
        original.append(b.assign(rule=f'confidence_fixed{amount}'))
    original.append(priced[priced.sizing.eq('edge_dollars_cash_only')].assign(rule='price_edge_fixed5'))
    original=pd.concat(original,ignore_index=True)
    diagnostic(original).to_csv(OUT/'probability_bands.csv',index=False)
    # These are complete opportunity sets: the 1%-equity NBA/MLB comparator
    # funds every eligible opportunity, while the fixed-price-edge run funds
    # every NHL/soccer candidate. Verify against the saved eligible counts.
    bases=starting[starting.selection.eq('winner_above51')&starting.sizing.eq('fixed1pct_cap20')].copy()
    bases=pd.concat([bases,priced[priced.sizing.eq('edge_dollars_cash_only')]],ignore_index=True)
    assert not bases.duplicated(['sport','provider','year','game_id']).any()
    for name,b in [('starting_account_staking',bases[bases.sport.isin(['nba','mlb'])]),
                   ('probability_price_staking',bases[bases.sport.isin(['nhl','soccer'])])]:
        a=pd.read_csv(SIM/name/'annual.csv')
        a=a[a.sizing.eq('fixed1pct_cap20')&a.selection.eq('winner_above51')] if name.startswith('starting') else a[a.sizing.eq('edge_dollars_cash_only')]
        assert a.unfunded_games.eq(0).all()
        expected=a.set_index(['sport','provider','year']).eligible_games.sort_index()
        observed=b.groupby(['sport','provider','year']).size().sort_index()
        assert expected.equals(observed)
    unit=bases.copy();unit['stake']=1.;unit['profit']=unit.won.astype(float)/unit.price-1
    unit['rule']='complete_opportunities_one_dollar_each'
    diagnostic(unit).to_csv(OUT/'opportunity_probability_bands.csv',index=False)
    largest=original.sort_values('profit').groupby(KEY,sort=False).head(20)
    largest[['sport','provider','year','rule','game_id','entry','teamA','teamB','side','probability','price','stake','profit','source_utc','quote_age_hours','unsettled_at_end']].to_csv(OUT/'largest_losses.csv',index=False)
    plan=dict(at_utc=stamp(),sources={name:file_sha256(path) for name,path in sources.items()},
        initial_cash=2000,fixed_dollars_do_not_compound=True,probability_bands=LABELS,
        diagnosis='Distinguish total losing stake, net profit, investment-weighted ROI and equal-dollar returns. Reconcile every bin. Complete opportunity set prevents early ruin from being mistaken for a full-season calibration result.',
        reaction='Keep all probability bands. Cap each requested stake at$20(1%of starting$2000), retaining the original available-cash rule. For NBA/MLB separately test the already-used5percentage-point price advantage with that same cap. No band boundary, cap or edge threshold search.',
        original_rules=['fixed$20or$5for each point above51(NBA/MLB)','fixed$5for each point above actual purchase price(NHL/soccer)'],
        selection='Choose a revision on2025 only if return positive, Sharpe higher and max drawdown lower than its same-rule original. Save choices before2026simulation;2026has been inspected many times and is retrospective evidence.',
        model_training='Unchanged saved rolling forecasts; all prior dated model and quote validations retained.',
        annual_account='Fresh$2000per year. Cash-only, no borrowing, unsettled stakes cannot be spent again. Mark open positions at cost; realized P&L reconciles year-end account. Cohort profit includes later settlements and is separately labelled.',
        all_opportunities_recovered=True,app_changed=False)
    dump(OUT/'plan.json',plan)
    records=[];bets=[];days=[];checks=[];frozen={}
    for year in [2025,2026]:
        for (sport,provider),g in bases.groupby(['sport','provider']):
            configs=[(f'confidence_fixed{x}','dollars_cash_only',x) for x in [5,20]] if sport in ['nba','mlb'] else [('price_edge_fixed5','edge_dollars_cash_only',5)]
            for rule,sizing,amount in configs:
                variants=['original','cap20']+(['cap20_edge5'] if sport in ['nba','mlb'] else [])
                for revision in variants:
                    cap=None if revision=='original' else 20.
                    data=g[g.edge.ge(.05)] if revision.endswith('edge5') else g
                    m,b,l,d=engine.simulate(data,year,'all_selected_outcomes',sizing,amount,2000.,cap)
                    key=dict(sport=sport,provider=provider,year=year,rule=rule,revision=revision)
                    checks.append(key|engine.validate(b,l,d,sizing,amount,2000.,cap))
                    records.append(key|m)
                    if len(b):bets.append(b.assign(**key))
                    days.append(d.assign(**key))
                    if revision=='original':
                        prior=original[original.sport.eq(sport)&original.provider.eq(provider)&original.year.eq(year)&original.rule.eq(rule)].sort_values('game_id')
                        now=b.sort_values('game_id')
                        assert list(prior.game_id)==list(now.game_id)
                        assert np.allclose(prior[['stake','profit']],now[['stake','profit']],rtol=0,atol=1e-7)
        if year==2025:
            a=pd.DataFrame(records)
            for key,g in a.groupby(['sport','provider','rule']):
                ref=g[g.revision.eq('original')].iloc[0]
                good=g[g.revision.ne('original')&g.return_pct.gt(0)&g.sharpe.gt(ref.sharpe)&g.max_drawdown_pct.lt(ref.max_drawdown_pct)]
                # Ruined-account active-period Sharpe is not a valid comparator.
                if ref.return_pct<=-99.999:
                    good=g[g.revision.ne('original')&g.return_pct.gt(0)&g.max_drawdown_pct.lt(ref.max_drawdown_pct)]
                best=good.sort_values(['sharpe','revision'],ascending=[False,True]).iloc[0] if len(good) else None
                frozen['/'.join(key)] = dict(revision=None if best is None else str(best.revision),selected_on_year=2025)
            dump(OUT/'frozen_choices.json',dict(at_utc=stamp(),choices=frozen))
        print(json.dumps(dict(stage='probability_loss_reaction',finished_year=year)),flush=True)
    a=pd.DataFrame(records)
    a['selected_on2025']=[r.revision==frozen['/'.join([r.sport,r.provider,r.rule])]['revision'] for r in a.itertuples()]
    a['sharpe_valid_full_period']=a.return_pct.gt(-99.999)&a.undefined_post_ruin_days.eq(0)
    a.to_csv(OUT/'reaction_annual.csv',index=False)
    b=pd.concat(bets,ignore_index=True);b.to_parquet(OUT/'reaction_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(OUT/'reaction_daily.parquet',index=False)
    expanded=b.copy();expanded['rule']=expanded.rule+'__'+expanded.revision
    diagnostic(expanded).to_csv(OUT/'reaction_probability_bands.csv',index=False)
    assert all(file_sha256(sources[name])==h for name,h in plan['sources'].items())
    dump(OUT/'validation.json',dict(status='PASS',at_utc=stamp(),checks=checks,
        original_bets_reproduced_exactly=True,source_hashes_unchanged=True,complete_opportunity_sets_verified=True,
        bin_profit_reconciled=True,annual_cash_independently_replayed=True,app_changed=False,adopted=False))
    path=SIM/'experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=OUT.name+'/reaction_annual.csv'
    pd.concat([old[~old.source_result_file.eq(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=SIM/'experiment_decisions.json';old=json.loads(path.read_bytes());old[OUT.name]=dict(plan=plan,frozen=frozen,adopted=False);dump(path,old)
    cleanup()
    print(a[a.year.eq(2026)][['sport','provider','rule','revision','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct','selected_on2025']].to_string(index=False),flush=True)


def context_test():
    """Test the NHL preseason concentration found in the 2025 loss audit."""
    import transfer_stake_sizing as transfer
    assert (OUT/'validation.json').exists()
    assert not (OUT/'context_validation.json').exists()
    b=pd.read_parquet(SIM/'probability_price_staking/bets.parquet')
    b=b[b.sizing.eq('edge_dollars_cash_only')].copy()
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        g=pd.read_sql_query('SELECT game_id,phase,official_game_id,source_request_id,home_away FROM nhl_games',db)
        soccer=pd.read_sql_query('SELECT game_id,home_away FROM soccer_games',db)
    nhl=b[b.sport.eq('nhl')].merge(g,on='game_id',validate='many_to_one')
    assert nhl.phase.notna().all() and nhl.official_game_id.notna().all()
    # Official NHL game-type digit: 01 preseason, 02 regular season, 03 playoffs.
    nhl['official_type']=nhl.official_game_id.astype(str).str.slice(4,6)
    assert nhl.official_type.isin(['01','02','03']).all()
    assert nhl.phase.str.lower().str.contains('pre').eq(nhl.official_type.eq('01')).all()
    nhl['rule']='price_edge_fixed5__'+nhl.phase
    diagnostic(nhl).to_csv(OUT/'nhl_phase_probability_bands.csv',index=False)
    nhl[['game_id','phase','official_game_id','source_request_id']].drop_duplicates().to_csv(OUT/'nhl_phase_evidence.csv',index=False)
    # Diagnose every model outcome, not just the price-selected bets. This
    # distinguishes broad calibration error from error conditional on price.
    selections=json.loads((SIM/'staking_model_selection/selection.json').read_bytes())
    transfer.RESULT=SIM/'transferred_account_staking'
    calibration=[]
    for sport in ['nhl','soccer']:
        p=transfer.get_forecasts(sport,selections['selections'][sport])
        for side in range(3 if sport=='soccer' else 2):
            f=pd.DataFrame(dict(sport=sport,provider='all_forecasts_no_price_filter',year=p.prediction_time.dt.year,
                game_id=p.game_id,probability=p['p'+str(side)],won=p.target.eq(side)))
            f=f[f.year.isin([2025,2026])].copy()
            f['band']=pd.cut(f.probability,BINS,labels=LABELS,right=False)
            a=f.groupby(['sport','provider','year','band'],observed=True).agg(bets=('game_id','size'),
                mean_probability=('probability','mean'),win_rate=('won','mean')).reset_index()
            calibration.append(a.assign(side=side))
    pd.concat(calibration,ignore_index=True).to_csv(OUT/'all_forecast_calibration.csv',index=False)
    sb=b[b.sport.eq('soccer')].merge(soccer,on='game_id',validate='many_to_one')
    assert sb.home_away.notna().all()
    sb['bought_role']=[r.home_away.split(';')[int(r.side)] if r.side<2 else 'Draw' for r in sb.itertuples()]
    sb['rule']='price_edge_fixed5__'+sb.bought_role
    diagnostic(sb).to_csv(OUT/'soccer_role_probability_bands.csv',index=False)
    plan=dict(at_utc=stamp(),hypothesis='Five preseason losses account for most lost stakes in the NHL2025Polymarket70-80%band; smaller regular-season stakes won frequently. Test abstaining on preseason with the same model, quotes and$5edge sizing, not a probability threshold.',
        official_phase='NHL official game ID digits4:6 are01preseason/02regular/03playoffs; assert these agree with stored official phase.',
        sport='nhl',data_and_model_unchanged=True,dollars_per_edge_point=5,initial_cash=2000,
        train_selection='2025phase-loss diagnosis; evaluate2026after writing2025decision.2026repeatedly inspected, not an untouched test.',
        no_new_price_or_probability_threshold=True,keep_preseason_in_dataset=True,app_changed=False)
    dump(OUT/'context_plan.json',plan)
    records=[];bets=[];days=[];checks=[];choices={}
    for year in [2025,2026]:
        for provider,g in nhl.groupby('provider'):
            for rule in ['all_phases','competitive_games_only']:
                data=g if rule=='all_phases' else g[g.official_type.ne('01')]
                m,positions,l,d=engine.simulate(data,year,'all_selected_outcomes','edge_dollars_cash_only',5.,2000.)
                key=dict(sport='nhl',provider=provider,year=year,rule=rule)
                records.append(key|m);checks.append(key|engine.validate(positions,l,d,'edge_dollars_cash_only',5.,2000.))
                bets.append(positions.assign(**key));days.append(d.assign(**key))
                if rule=='all_phases':
                    old=g[g.year.eq(year)].sort_values('game_id');now=positions.sort_values('game_id')
                    assert np.allclose(old[['stake','profit']],now[['stake','profit']],rtol=0,atol=1e-7)
        if year==2025:
            a=pd.DataFrame(records)
            for provider,g in a.groupby('provider'):
                original=g[g.rule.eq('all_phases')].iloc[0];new=g[g.rule.eq('competitive_games_only')].iloc[0]
                choices[provider]=bool(new.return_pct>0 and new.sharpe>original.sharpe and new.max_drawdown_pct<original.max_drawdown_pct)
            dump(OUT/'context_frozen_choices.json',dict(at_utc=stamp(),chosen_on2025=choices))
    a=pd.DataFrame(records);a.to_csv(OUT/'nhl_phase_reaction_annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(OUT/'nhl_phase_reaction_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(OUT/'nhl_phase_reaction_daily.parquet',index=False)
    dump(OUT/'context_validation.json',dict(status='PASS',at_utc=stamp(),checks=checks,
        all_phase_baseline_reproduced=True,phase_known_before_outcome=True,adopted=False,app_changed=False))
    path=SIM/'experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=OUT.name+'/nhl_phase_reaction_annual.csv'
    pd.concat([old[~old.source_result_file.eq(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=SIM/'experiment_decisions.json';old=json.loads(path.read_bytes());old[OUT.name+'/context']=dict(plan=plan,choices=choices,adopted=False);dump(path,old)
    cleanup()
    print(a[['provider','year','rule','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False))


def write_report():
    def table(frame):
        headers=list(frame.columns)
        def value(x):
            if isinstance(x,(float,np.floating)):return f'{x:.2f}' if np.isfinite(x) else 'NA'
            return str(x)
        return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+
            ['| '+' | '.join(value(x) for x in row)+' |' for row in frame.itertuples(index=False,name=None)])
    bands=pd.read_csv(OUT/'probability_bands.csv')
    current=bands[bands.provider.eq('polymarket')&bands.year.eq(2026)&bands.rule.ne('confidence_fixed20')]
    cols=['sport','probability_band','bets','gross_loss_share_pct','in_year_realized_profit_dollars','mean_probability','win_rate','stake_weighted_roi_pct']
    display=current[cols].copy();display['mean_probability']*=100;display['win_rate']*=100
    display=display.rename(columns={'gross_loss_share_pct':'Share of losing stakes %','in_year_realized_profit_dollars':'Net realized $','mean_probability':'Forecast %','win_rate':'Win %','stake_weighted_roi_pct':'ROI on stakes %'})
    a=pd.read_csv(OUT/'reaction_annual.csv')
    selected=a[a.provider.eq('polymarket')&a.rule.eq('confidence_fixed20')&a.revision.eq('cap20_edge5')]
    u=SIM/'uncertainty_buffer_staking'
    b=pd.read_csv(u/'annual.csv');fixed=pd.read_csv(u/'fixed_stake_annual.csv');shares=pd.read_csv(u/'fixed_shares_annual.csv')
    comparison=pd.concat([
        b[b.provider.eq('polymarket')&b.rule.isin(['baseline','buffer5','consensus'])],
        fixed[fixed.provider.eq('polymarket')&fixed.rule.eq('relative_advantage10_flat20')],
        shares[shares.provider.eq('polymarket')&shares.rule.eq('all_positive_edge_flat40shares')],
    ],ignore_index=True)
    report='''# Probability losses and strategy revisions

All account experiments start with $2,000 per year. Fixed-dollar stakes do not grow with equity. Available cash limits simultaneous positions; unsettled money cannot be spent again. No costs or spread assumptions were added. Prices remain provider-specific historical references: international Polymarket token histories and Kalshi YES asks; these tests do not establish executable US fills. 2026 covers available records through September 29, not a full year.

## What the losses show

Count losing stakes and net profit separately. A probability band can have many losing bets and still contribute positive net profit. Dollar-weighted results also differ from equal-dollar results when stakes depend on forecast confidence or edge. The complete-opportunity audit avoids judging an entire season from the few bets funded before an account was exhausted.

- NBA: the original $20 per confidence point exhausted the account. In the full 2026 $5-per-point comparison every probability band made money; the 80%+ band contributed $1,778.80. The early bankruptcy sample is not evidence that high-confidence forecasts are inherently bad. There was also an early overpayment problem: the original 60-70% band averaged 64.70% predicted probability but a 71.71-cent purchase price.
- MLB: in the $5-per-point comparison the 50-60% and 60-70% bands lost $256.48 and $34.50 in 2026; 70%+ contributed $694.07, though this latter group contains only 31 bets. The corresponding lower bands lost money in 2025 too. This supports checking price advantage rather than mechanically betting more whenever confidence increases.
- NHL: lower-probability bets contribute most gross lost stakes, but positive net profits. In Polymarket 2025 the 70-80% band won 82.22% of bets yet lost $225.11 because the larger stakes lost: stake-weighted win rate was only 51.13%. Five preseason losses supplied most of that band's gross losses. Excluding every preseason game nevertheless reduced overall 2025 return and Sharpe, so that blanket exclusion was rejected.
- Soccer: the 50-60% price-selected band lost money in both years. Official home/away mapping shows the home bets in that band averaged 55.10% forecast probability versus 45.57% actual wins in 2025, and 54.45% versus 37.14% in 2026. Errors move between competitions, so these results do not justify removing a particular league. Below-50% bets are often profitable despite low win rates.

### 2026 Polymarket loss decomposition

NBA/MLB below use $5 per point above 51%; NHL/soccer use $5 per point of probability above price. These are different named sizing rules, not the user's original $20 rule. Both $20 and $5 diagnostics, plus Kalshi and 2025, are retained in probability_bands.csv. Interval labels are left-inclusive and right-exclusive.

'''+table(display)+'''

## Reactions actually tested

The risk-cap test holds the models fixed and caps each proposed stake at $20, then separately applies the already-used five-percentage-point purchase-price advantage. This reduces losses but does not alone produce Sharpe 3.

'''+table(selected[['sport','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']])+'''

For NHL/soccer, baseline means $5 per point of positive price advantage on one originally selected outcome. buffer5 subtracts five probability points before calculating that stake. consensus uses the lower of NHL's two saved probabilities. relative_advantage10_flat20 buys $20 only when estimated return is at least 10%; NHL requires both forecasts to meet that requirement. all_positive_edge_flat40shares buys 40 shares, costing 40 times the purchase price, so a 50-cent outcome still costs $20.

'''+table(comparison[['sport','year','rule','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']])+'''

The NHL fixed-$20 agreement rule improved 2025 Sharpe to 2.84 and drawdown to 6.37%, then returned 37.41% with Sharpe 2.11 and drawdown 12.09% in 2026. This is useful risk evidence, not achievement of the target. The fixed-share soccer rule improved 2025 Sharpe to 1.84 but fell to 0.38 and 5.51% return in 2026. It is not a reliable solution. A larger return can be driven by a few longshot wins; flattening their payouts exposes that dependence.

A further monthly expanding logistic reliability check used only previously settled forecast/price pairs. It compared model probability plus price and outcome role against price and role alone, on identical model-selected outcomes. Soccer's 2026 Polymarket binary probability loss improved from 0.57320 to 0.56633, but the price-only control was slightly better at 0.56628, and strategy Sharpe fell from 1.36 to 1.14. None of these reliability candidates passed the 2025 joint probability/strategy adoption gate. The price-only control still uses the sports model's original outcome selection; it is not a wholly model-free betting strategy.

## Out-of-sample interpretation and next direction

Underlying model forecasts use expanding 2021+ sports history. The reliability fits train on earlier out-of-fit forecasts and only labels available before each monthly boundary. Strategy comparisons freeze 2025 choices before computing their new 2026 account results. However, many earlier experiments have already inspected 2026: prediction-level walk-forward testing does not make strategy-selection performance on that year an untouched holdout. No target threshold was used to choose a 2026 winner.

Keep the original app and model baselines. Do not adopt the failed price-calibration layer or remove whole probability bands/leagues based on these returns. For NHL, retain the fixed-$20, two-model value check as a research comparator. For soccer, turn back to conditional forecast errors: opponent-adjusted shot difficulty and dated squad uncertainty are the next data/model audit, rather than another price threshold or adding raw keeper save counts already tested unsuccessfully. The selected 39-input model already contains many attack, passing and roster summaries; adding the same statistics again is not a new hypothesis.

The Sharpe >3 and return >20% goal remains unmet for NHL/soccer. Future results after the protocol's prospective boundary must use a recipe frozen before those matches; any revision starts a new forward evaluation and cannot rewrite the prior record. No future collection or betting process is claimed to be running.

## Files and validation

- probability_bands.csv: actual funded dollar loss, profit and probability bands for both providers and years.
- opportunity_probability_bands.csv: complete candidate set with equal $1 weights, independent of early account ruin.
- largest_losses.csv: dated games and source quote times for the largest actual losses.
- reaction_annual.csv and reaction_bets.parquet: risk-cap and price-filter comparisons.
- nhl_phase_reaction_annual.csv: rejected blanket preseason exclusion.
- ../uncertainty_buffer_staking/: margin, agreement, fixed-dollar and fixed-share tests, including unsuccessful variants.
- ../rolling_price_reliability/: earlier-only reliability predictions, coefficients, coverage and comparisons.

All original funded bets were replayed exactly before comparison. Independent event-ledger checks reconcile daily cash and open positions, probability bins sum to the full cohort, and price timestamps precede entry. Open positions remain valued at cost: cohort profit includes eventual settlements while in-year realized profit reconciles annual account return. Daily Sharpe includes idle calendar days; ruined accounts' active-period Sharpe is explicitly invalid as a full-year measure.
'''
    (OUT/'review.md').write_text(report,encoding='utf-8')
    protocol=dict(at_utc=stamp(),prediction_oos='Expanding dated sports fits and purged calibration; labels available before forecast only.',
        strategy_development_end='2025-12-31',retrospective_evaluation='2026-01-01 through2026-09-29; repeatedly inspected, not untouched.',
        prospective_earliest_utc='2026-10-04T00:00:00Z',prospective_process_running=False,
        forward_rules='Freeze recipe/hash before its first forecast; store forecast and quote before game; score only when official result available. No retrospective changes. A new recipe opens a new evaluation.',
        adoption='Earlier-period probability improvement beyond price control and stable later-period risk/return; report sample size, uncertainty and all failed variants. Do not select solely for target2026Sharpe.',
        current_target_achieved=False)
    dump(SIM/'evaluation_protocol.json',protocol)
    print(json.dumps(dict(report=str(OUT/'review.md'),protocol=str(SIM/'evaluation_protocol.json'))))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--context',action='store_true');parser.add_argument('--report',action='store_true')
    args=parser.parse_args()
    write_report() if args.report else (context_test() if args.context else main())
