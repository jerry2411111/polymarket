"""Rebuild retained NHL predictors with a documented Utah identity transition.

Native game, team and quote IDs remain untouched. Only the key used to look up
earlier team history changes. The same-franchise link is available before the
first forecast using native team68; Arizona53 is never mapped to this franchise.
"""
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from common import PROJECT, ROOT_OUT, dump, stamp
import features
import nhl_roles
import on_ice_features
import mechanism_features
from models import META, columns, CANDIDATES

RUN=ROOT_OUT/'retained_models/nhl'
OLD=RUN/'nhl_features.parquet'


def identity_evidence():
    evidence=json.loads((ROOT_OUT/'nhl_utah_identity_evidence.json').read_bytes())
    source=evidence['source'];raw=(PROJECT/source['raw_file']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==source['sha256']
    rows={r['id']:r for r in json.loads(raw)['data']}
    assert rows[59]['franchiseId']==rows[68]['franchiseId']==40
    assert rows[53]['franchiseId']!=40
    return evidence


def history_keys(games, repaired):
    available=pd.Timestamp(identity_evidence()['conservative_available_at_utc'])
    keys={};audit=[]
    for g in games.itertuples():
        for side,native in zip(['A','B'],json.loads(g.native_team_ids_json)):
            native=str(native);key=native
            if repaired and native=='68':
                assert g.prediction_time>=available,'Identity must be public before forecast'
                key='59'
                audit.append(dict(game_id=g.game_id,date=g.date,side=side,native_team_id=native,
                    history_team_id=key,franchise_id=40,identity_available_utc=available,
                    prediction_time=g.prediction_time))
            keys[(g.game_id,side)]=key
    return keys,audit


def derive(games,observations,players,stats,metrics,repaired=False,regulation_labels=None):
    keys,audit=history_keys(games,repaired)
    prefixed={k:'NHL:'+v for k,v in keys.items()}
    obs=observations.copy()
    obs['team_key']=[prefixed[(r.game_id,r.side)] for r in obs.itertuples()]
    print(json.dumps(dict(stage='identity_features',repaired=repaired,part='team_and_roster')),flush=True)
    base,_=features.build('nhl',games,obs,players,prefixed,stats,metrics)
    print(json.dumps(dict(stage='identity_features',repaired=repaired,part='role_contributions')),flush=True)
    role=nhl_roles.main(base=base,games=games,history_keys=keys,save=False)
    print(json.dumps(dict(stage='identity_features',repaired=repaired,part='on_ice')),flush=True)
    onice=on_ice_features.main(base=role,games=games,history_keys=keys,save=False)
    f=mechanism_features.build('nhl',frame=onice,save=False)
    for c in [c for c in f if c.startswith('f_mech_')]:f[c.replace('f_mech_','f_gran_')]=f[c]
    for role_name in ['forward','defence']:
        for measure in ['mapped_model_xg','mapped_attempts']:
            a=f'f_onice_{role_name}_{measure}_for_per60_30_diff'
            b=f'f_onice_{role_name}_{measure}_against_per60_30_diff'
            f[f'f_gran_onice_{role_name}_{measure}_net_per60_diff']=f[a]-f[b]
        c=f'f_onice_{role_name}_mapping_fraction_diff'
        f[c.replace('f_onice_','f_gran_onice_')]=f[c]
    old=pd.read_parquet(OLD)
    labels=['regulation_scoreA','regulation_scoreB']
    label_source=old[['game_id']+labels] if regulation_labels is None else regulation_labels[['game_id']+labels]
    assert not label_source.game_id.duplicated().any()
    f=f.merge(label_source,on='game_id',how='left',validate='one_to_one')
    assert f[labels].notna().all().all(),'Missing regulation labels must be acquired before model fitting'
    used=columns(old,CANDIDATES['granular_regulation_ot'])
    order=META+['phase','scoreA','scoreB']+labels+used+[
        'source_max_available_utc','role_source_max_available_utc','onice_source_max_available_utc']
    f=f[order].copy()
    for c in ['source_max_available_utc','role_source_max_available_utc','onice_source_max_available_utc']:
        f[c]=pd.to_datetime(f[c],utc=True)
        assert (f[c].isna()|f[c].lt(f.prediction_time)).all()
    return f,audit


def differences(a,b):
    a=a.set_index('game_id').sort_index();b=b.set_index('game_id').sort_index()
    assert a.index.equals(b.index)
    rows=[]
    for c in a:
        if c not in b:continue
        if pd.api.types.is_numeric_dtype(a[c]):equal=np.isclose(a[c],b[c],equal_nan=True,rtol=0,atol=1e-12)
        else:equal=(a[c].eq(b[c])|(a[c].isna()&b[c].isna())).to_numpy()
        if not np.all(equal):rows.append(dict(column=c,changed=int((~equal).sum()),first_changed_game=a.index[np.where(~equal)[0][0]]))
    return rows


def main():
    from common import read_db
    games,obs,players,_,stats,metrics,_=features.sources('nhl')
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        labels=pd.read_sql_query('SELECT game_id,side,regulation_goals FROM nhl_team_shot_quality',db)
    labels=labels.pivot(index='game_id',columns='side',values='regulation_goals').rename(columns={'A':'regulation_scoreA','B':'regulation_scoreB'}).reset_index()
    fixed,audit=derive(games,obs,players,stats,metrics,repaired=True,regulation_labels=labels)
    fixed.to_parquet(RUN/'nhl_features.parquet',index=False)
    pd.DataFrame(audit).to_parquet(RUN/'identity_application_audit.parquet',index=False)
    print(json.dumps(dict(games=len(fixed),identity_links=len(audit),next_step='Refit final models after changed input data.')),flush=True)

if __name__=='__main__':main()
