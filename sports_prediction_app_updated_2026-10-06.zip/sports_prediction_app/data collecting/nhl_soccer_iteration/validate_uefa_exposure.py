"""Replay retained official metadata, lineups and event pages; conserve minutes."""
import hashlib,json
from pathlib import Path
from common import PROJECT,PREVIOUS,ROOT_OUT,read_db,dump,stamp
from collect_uefa_exposure import parse


def source(s):
    path=Path(s['raw_file']);path=path if path.is_absolute() else PROJECT/path
    blob=path.read_bytes();assert hashlib.sha256(blob).hexdigest()==s['sha256']
    return json.loads(blob)


def main():
    with read_db(PREVIOUS/'expanded.sqlite') as c:games={r['game_id']:dict(r) for r in c.execute("SELECT * FROM soccer_games WHERE league='UEFA Champions League'")}
    counts=dict(games=0,players=0,known_minutes=0,source_hashes=0,partial_games=0);examples=[]
    with read_db(ROOT_OUT/'uefa_exposure.sqlite') as c:
        for record in c.execute('SELECT body FROM games ORDER BY game_id'):
            body=json.loads(record[0]);s=body['sources'];events=[]
            for page in s['events']:events.extend(source(page))
            replay=parse(games[body['game_id']],source(s['match']),source(s['lineup']),events,s)
            assert replay==body,body['game_id']
            ids=[p['official_player_id'] for p in body['players']];assert len(ids)==len(set(ids))
            for p in body['players']:
                if p['minutes'] is not None:
                    assert 0<=p['minutes']<=90
                    assert p['played'] or p['minutes']==0
                    counts['known_minutes']+=1
                assert p['assists'] is None
            counts['games']+=1;counts['players']+=len(ids);counts['partial_games']+=bool(body['issues']);counts['source_hashes']+=2+len(s['events'])
            if len(examples)<12:examples.append(dict(game_id=body['game_id'],date=body['date'],players=len(ids),issues=body['issues'],official_url='https://www.uefa.com/uefachampionsleague/match/'+str(games[body['game_id']]['official_game_id'])+'/'))
    report=dict(at_utc=stamp(),status='PASS',counts=counts,examples=examples,meaning='Exact raw-hash replay, native IDs, official score reconciliation and regulation-minute conservation. Recorded action counts are not asserted to be a complete box score.')
    dump(ROOT_OUT/'uefa_exposure_validation.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
