"""Separate model accuracy from purchased-outcome accuracy, without refitting.

The user requests an explicit predicted-winner control. Preserve the prior
price-selected results and replay both choices at the same fixed dollar stake.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, REPORTS, dump, stamp, file_sha256
from backtest import quote_inputs
import transfer_stake_sizing as transfer
import test_confidence_dollars as engine

LABEL = 'pick_vs_purchase'
RESULT = ROOT_OUT / 'simulation_results' / LABEL
SOURCES = {
    'nhl': ('feature_revisions/nhl_player_strength',
            'nhl_paired_price_signal/reference_evaluation_bets.parquet'),
    'soccer': ('soccer_source_count_rates', 'soccer_source_count_rates/bets.parquet'),
}


def main():
    RESULT.mkdir(exist_ok=True)
    assert not (RESULT / 'validation.json').exists(), 'Preserve the completed audit'
    plan = dict(at_utc=stamp(), question='Why does bought-outcome win rate differ from model winner accuracy?',
        forecasts='Unchanged current NHL primary and corrected-count soccer candidate; monthly expanding 2021+ training and forecasts from 2024.',
        comparisons=['Exact original funded games: model argmax versus purchased outcome',
                     'All games with a usable quote for the model argmax: buy it without a price-value filter',
                     'Original 2026 funded games with both required quotes: compare choices at identical fixed $20 stakes'],
        account='Annual $2000, flat $20 per bet, only available cash; no reuse before recorded settlement; pre12 prior quote no older than 24 hours; no added fees or spreads.',
        evidence='Polymarket retained international token prices; Kalshi recorded YES ask close; not asserted executable US asks.',
        selection='Descriptive user-requested control, no optimization or adoption. The common cohort uses prior strategy selections and is an attribution diagnostic, not an independent deployable rule.',
        evaluation='2026 repeatedly inspected retrospective rolling evidence, not untouched holdout.', app_changed=False)
    dump(RESULT / 'plan.json', plan)
    quotes = quote_inputs(RESULT / 'quote_quality.json', revision='closest_v62')
    transfer.RESULT = RESULT
    metrics, details, annual, bets, daily, validation, coverage = [], [], [], [], [], [], []
    hashes = {}

    def account(f, sport, provider, variant, year):
        m, b, l, d = engine.simulate(f, year, 'all_selected_outcomes', 'flat20_cash_only', 5., 2000.)
        key = dict(sport=sport, provider=provider, variant=variant, year=year)
        validation.append(key | engine.validate(b, l, d, 'flat20_cash_only', 5., 2000.))
        annual.append(key | m)
        if len(b):
            bets.append(b.assign(**key))
        daily.append(d.assign(**key))
        return b

    for sport, (folder, saved) in SOURCES.items():
        root = ROOT_OUT / 'simulation_results'
        paths = [root / folder / (stage + '_predictions.parquet') for stage in ['development', 'evaluation']]
        paths.append(root / saved)
        for path in paths:
            hashes[str(path.relative_to(ROOT_OUT))] = file_sha256(path)
        p = pd.concat([pd.read_parquet(path) for path in paths[:2]], ignore_index=True)
        p = p[p.variant.eq('candidate')].copy()
        assert p.game_id.is_unique
        assert p.train_label_max.lt(p.prediction_time).all()
        assert p.calibration_label_max.lt(p.prediction_time).all()
        columns = ['p0', 'p1'] + (['p2'] if sport == 'soccer' else [])
        p['model_pick'] = p[columns].to_numpy().argmax(axis=1)
        winners = transfer.normalize(sport, p, quotes, pick_growth=False)
        assert winners.side.eq(winners[columns].to_numpy().argmax(axis=1)).all()
        original = pd.read_parquet(paths[2])
        original = original[original.year.eq(2026)].copy()
        if sport == 'soccer':
            original = original[original.variant.eq('candidate')].copy()
        for provider, w in winners.groupby('provider'):
            for year in [2024, 2025, 2026]:
                sample = p[p.prediction_time.dt.year.eq(year)]
                quoted = w[w.year.eq(year)]
                coverage.append(dict(sport=sport, provider=provider, year=year,
                    forecast_games=len(sample), quoted_winner_games=len(quoted),
                    unquoted_winner_games=len(sample)-len(quoted),
                    all_forecast_accuracy_pct=100*sample.model_pick.eq(sample.target).mean(),
                    quoted_winner_accuracy_pct=100*quoted.won.mean()))
                account(w, sport, provider, 'winner_all_quoted', year)
        for provider, old in original.groupby('provider'):
            old = old.copy()
            raw = p.set_index('game_id').loc[old.game_id]
            assert np.array_equal(old.target, raw.target)
            assert np.allclose(old[columns], raw[columns], rtol=0, atol=1e-12)
            assert old.side.eq(old.target).eq(old.won).all()
            old['model_pick'] = old[columns].to_numpy().argmax(axis=1)
            old['picked_won'] = old.model_pick.eq(old.target)
            old['purchased_model_pick'] = old.side.eq(old.model_pick)
            same = old.purchased_model_pick
            detail = old[['game_id', 'teamA', 'teamB', 'target', 'model_pick', 'side', 'picked_won',
                          'won', 'purchased_model_pick', 'probability', 'price', 'stake', 'profit'] + columns]
            details.append(detail.assign(sport=sport, provider=provider, year=2026))
            winner = winners[winners.provider.eq(provider) & winners.year.eq(2026)].set_index('game_id')
            common = old.game_id[old.game_id.isin(winner.index)]
            metrics.append(dict(sport=sport, provider=provider, year=2026, games=len(old),
                bought_wins=int(old.won.sum()), bought_win_rate_pct=100*old.won.mean(),
                model_pick_wins=int(old.picked_won.sum()), model_pick_accuracy_pct=100*old.picked_won.mean(),
                purchases_on_model_pick=int(same.sum()), purchases_on_other_outcome=int((~same).sum()),
                changed_correct_pick_to_loss=int((~same & old.picked_won & ~old.won).sum()),
                changed_wrong_pick_to_win=int((~same & ~old.picked_won & old.won).sum()),
                purchased_mean_probability=old.probability.mean(), purchased_mean_price=old.price.mean(),
                winner_quote_available=len(common), winner_quote_unavailable=len(old)-len(common)))
            a = old.set_index('game_id').loc[common].reset_index()
            b = winner.loc[common].reset_index()
            for c in ['game_id', 'entry', 'exit', 'target']:
                assert np.array_equal(a[c], b[c]), c
            ba = account(a, sport, provider, 'prior_choice_common_flat20', 2026)
            bb = account(b, sport, provider, 'winner_common_flat20', 2026)
            # Report funding differences if cash constraints differ; never imply
            # an identical funded cohort unless the actual ledgers prove it.
            both = set(ba.game_id) & set(bb.game_id)
            validation.append(dict(sport=sport, provider=provider, common_eligible_games=len(common),
                prior_choice_funded=len(ba), winner_funded=len(bb), both_funded=len(both),
                identical_funded_games=set(ba.game_id)==set(bb.game_id)))
        print(json.dumps(dict(sport=sport,stage='audit_and_accounts_complete')), flush=True)

    m = pd.DataFrame(metrics); a = pd.DataFrame(annual)
    m.to_csv(RESULT / 'same_game_accuracy.csv', index=False)
    a.to_csv(RESULT / 'annual.csv', index=False)
    pd.DataFrame(coverage).to_csv(RESULT / 'quote_coverage.csv', index=False)
    pd.concat(details, ignore_index=True).to_parquet(RESULT / 'outcome_choice_evidence.parquet', index=False)
    pd.concat(bets, ignore_index=True).to_parquet(RESULT / 'bets.parquet', index=False)
    pd.concat(daily, ignore_index=True).to_parquet(RESULT / 'daily.parquet', index=False)
    for name, sha in hashes.items():
        assert file_sha256(ROOT_OUT / name) == sha
    proof = dict(status='PASS', at_utc=stamp(), source_hashes=hashes, checks=validation,
        no_new_fit=True, source_forecasts_unchanged=True, app_changed=False, adopted=False)
    dump(RESULT / 'validation.json', proof)
    path = ROOT_OUT / 'simulation_results/experiment_results.csv'
    existing = pd.read_csv(path, low_memory=False)
    key = LABEL + '/annual.csv'
    pd.concat([existing[existing.source_result_file.ne(key)], a.assign(source_result_file=key)],
              ignore_index=True).to_csv(path, index=False)
    path = ROOT_OUT / 'simulation_results/experiment_decisions.json'
    decisions = json.loads(path.read_bytes())
    decisions[LABEL] = dict(plan=plan, decision=proof)
    dump(path, decisions)
    def table(frame):
        return '\n'.join(['| '+' | '.join(frame.columns)+' |', '| '+' | '.join(['---']*len(frame.columns))+' |'] +
            ['| '+' | '.join(f'{v:.4f}' if isinstance(v, float) else str(v) for v in row)+' |' for row in frame.itertuples(index=False, name=None)])
    text = ['# Model pick and purchased outcome', '',
        'The reported value strategy chooses the outcome with the highest positive expected log growth, which need not be the model argmax. Compare the choices on exact game IDs before discussing win rate. No predictions are refitted or selected using this audit.', '',
        table(m), '', 'Fixed-$20 controls, each provider and year starting with $2000:', '',
        table(a[['sport','provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]), '',
        'winner_all_quoted buys only the model argmax whenever its retained pre12 quote is usable, regardless of price. It never substitutes a quoted alternative when the model pick lacks a quote. Common comparisons restrict to the original funded games with a quoted model pick and use $20 for both choices. Check funding differences in validation.json. This common cohort diagnoses the prior policy; it is not a new independently selected strategy.', '',
        'Cash and outcomes reconcile independently. Calendar-day Sharpe uses sqrt(365.25), idle days included; open holdings are carried at cost until recorded settlement. No added costs. International Polymarket token prices and Kalshi YES ask closes retain their distinct source meaning. 2026 is retrospective, repeatedly inspected evidence. NBA/MLB app and baseline results are unchanged.', '',
        'Reproduce: audit_pick_vs_purchase.py. Source hashes, quote coverage and per-game choice evidence accompany the result.']
    (REPORTS / (LABEL + '.md')).write_text('\n'.join(text)+'\n', encoding='utf8')
    from final_pipeline import cleanup
    cleanup()
    manifest = ROOT_OUT / 'retention/retained_artifacts.json'
    kept = json.loads(manifest.read_bytes())
    kept['scripts'] = {p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    kept.update(updated_utc=stamp(), retained_scripts=len(kept['scripts']), latest_choice_audit=str(RESULT))
    dump(manifest, kept)
    print(m.to_string(index=False), flush=True)
    print(a[a.year.eq(2026)][['sport','provider','variant','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False), flush=True)


if __name__ == '__main__':
    main()
