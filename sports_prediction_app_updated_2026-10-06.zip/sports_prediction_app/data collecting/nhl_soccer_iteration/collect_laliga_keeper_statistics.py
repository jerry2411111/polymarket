"""Fixture-specific La Liga keepers from the official FC Barcelona/Opta API.

No current biography determines a historical role. Missing payloads are recorded
for recovery from another source. Individual usable rows survive other errors.
"""
import argparse
import collections
import concurrent.futures
import json
import math
import sqlite3
import pandas as pd
from common import ROOT_OUT, OfficialClient, read_db, dump, stamp
from laliga_club_archive import BASE, games, sid

FOLDER = ROOT_OUT/'soccer_keeper_v81/laliga'
FIELDS = {'minutes': 'mins_played', 'saves': 'saves',
          'goals_conceded': 'goals_conceded',
          'keeper_xgot_conceded': 'expected_goals_on_target_conceded'}
PILOT = ['HIST_LAL_16391', 'HIST_LAL_22290', 'HIST_LAL_87884']


def check_fixture(game, index, fixture):
    assert sid(fixture['id']) == index['club_fixture_id']
    assert fixture['altIds']['opta'] == index['opta_match_id']
    assert fixture['status'] == 'C' and fixture['phase'] == 'F'
    assert not fixture.get('extraTime') and not fixture.get('shootout')
    assert pd.Timestamp(fixture['kickoff']['millis'], unit='ms', tz='UTC') == pd.Timestamp(game['timestamp'])
    assert [sid(t['team']['id']) for t in fixture['teams']] == [index['club_home_id'], index['club_away_id']]
    assert [t['score'] for t in fixture['teams']] == [game['scoreB'], game['scoreA']]


def normalize_player(game, index, person, side, pointer, fixture_source, stats, source):
    pid = person['altIds']['opta']
    assert pid.startswith('p') and pid[1:].isdigit()
    assert sid(stats['entity']['id']) == sid(person['id'])
    assert stats['entity']['altIds']['opta'] == pid
    assert source['url'] == BASE+'/stats/player/'+sid(person['id'])+'?fixtures='+index['club_fixture_id']+'&altIds=true'
    cells = {}; pointers = {}
    for i, cell in enumerate(stats['stats']):
        name = cell['name']; assert name not in cells
        value = cell.get('value')
        assert value is None or (isinstance(value, (int, float)) and math.isfinite(value))
        cells[name] = value; pointers[name] = '/stats/'+str(i)+'/value'
    for field in ['appearances', 'game_started']:
        assert cells.get(field) in (None, 0, 1), 'Fixture filter returned multiple appearances'
    minutes = cells.get('mins_played')
    if minutes is None or minutes == 0:
        return None, dict(player_id=pid, side=side, field='minutes',
                          reason='explicit_zero_minutes' if minutes == 0 else 'no_reported_minutes',
                          starter='/lineup/' in pointer, source=source, role_source=fixture_source, role_pointer=pointer)
    assert 0 < minutes <= 110
    values = {field: cells.get(native) for field, native in FIELDS.items()}
    for value in values.values(): assert value is None or value >= 0
    field_evidence = {field: dict(pointer=pointers.get(native), native_field=native,
                                 raw_value=values[field], basis='reported' if native in cells else 'not reported')
                      for field, native in FIELDS.items()}
    native_teams = json.loads(game['native_team_ids_json'])
    row = dict(game_id=game['game_id'], official_game_id=str(game['official_game_id']),
               league='La Liga', date=game['date'], side=side,
               team_id=str(native_teams[0 if side == 'A' else 1]), official_player_id=pid,
               id_namespace='opta_player_asset', player_name=person['name']['display'],
               available_at_utc=str(game['available_time']), **values, source=source,
               role_evidence=dict(source=fixture_source, pointer=pointer+'/matchPosition',
                                  raw_value='G', club_player_id=sid(person['id']),
                                  club_fixture_id=index['club_fixture_id'], opta_match_id=index['opta_match_id'],
                                  source_provider='FC Barcelona / Opta', source_class='official club API, republished Opta'),
               field_evidence=field_evidence)
    return row, None


def collect(game, index, client):
    record = dict(game_id=game['game_id'], date=game['date'], players=[], issues=[],
                  index={k:v for k,v in index.items() if k != 'index_sources'}, parser_version=1)
    fixture, source = client.get(BASE+'/fixtures/'+index['club_fixture_id']+'?pageSize=1&altIds=true&detail=2',
                                 'Dated goalkeeper roles, native teams and final result '+game['game_id'], 'official_laliga_keeper_fixture')
    record['fixture_source'] = source
    if fixture is None:
        record['issues'].append(dict(reason='fixture_http_error', source=source)); return record
    try:check_fixture(game, index, fixture)
    except (AssertionError,KeyError,ValueError,TypeError) as exc:
        record['issues'].append(dict(reason='fixture_schema_or_identity_error',error=repr(exc),source=source));return record
    sections = fixture.get('teamLists') or []
    for side, team in [('A', index['club_away_id']), ('B', index['club_home_id'])]:
        matched = [(i,s) for i,s in enumerate(sections) if s and sid(s['teamId']) == team]
        if len(matched) != 1:
            record['issues'].append(dict(side=side, reason='dated_lineup_not_supplied', source=source)); continue
        i, section = matched[0]
        if len(section['lineup']) != 11 or len({sid(p['id']) for group in ['lineup','substitutes'] for p in section.get(group,[])}) != sum(len(section.get(group,[])) for group in ['lineup','substitutes']):
            record['issues'].append(dict(side=side,reason='lineup_schema_requires_recovery',source=source));continue
        for group in ['lineup', 'substitutes']:
            for j, person in enumerate(section.get(group, [])):
                if person.get('matchPosition') != 'G': continue
                pointer = '/teamLists/'+str(i)+'/'+group+'/'+str(j)
                data, stats_source = client.get(BASE+'/stats/player/'+sid(person['id'])+'?fixtures='+index['club_fixture_id']+'&altIds=true',
                                                'Fixture-filtered keeper minutes, saves and goals conceded '+game['game_id']+' '+person['name']['display'], 'official_laliga_keeper_statistics')
                if data is None:
                    record['issues'].append(dict(side=side, player_id=person['altIds']['opta'], reason='statistic_http_error', source=stats_source)); continue
                try:
                    row, issue = normalize_player(game,index,person,side,pointer,source,data,stats_source)
                    if row: record['players'].append(row)
                    if issue: record['issues'].append(issue)
                except (AssertionError, KeyError, ValueError, TypeError) as exc:
                    record['issues'].append(dict(side=side,player_id=person['altIds']['opta'],reason='player_schema_or_identity_error',error=repr(exc),source=stats_source))
        if not any(p['side'] == side for p in record['players']):
            record['issues'].append(dict(side=side,reason='no_positive_minute_dated_keeper',source=source))
    record['complete_sides'] = sorted({p['side'] for p in record['players']})
    return record


def connect():
    FOLDER.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(FOLDER/'statistics.sqlite',timeout=60)
    db.execute('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY, body TEXT NOT NULL)')
    return db


def coverage():
    with read_db(FOLDER/'statistics.sqlite') as db:records=[json.loads(b) for b, in db.execute('SELECT body FROM games')]
    players=[p for r in records for p in r['players']]
    reasons=collections.Counter(i['reason'] for r in records for i in r['issues'])
    result=dict(at_utc=stamp(),checked_games=len(records),usable_games=sum(bool(r['players']) for r in records),
                two_sided_games=sum(set(p['side'] for p in r['players'])=={'A','B'} for r in records),
                keeper_appearances=len(players),issue_counts=dict(reasons),
                dates=[min(p['date'] for p in players),max(p['date'] for p in players)] if players else [],
                scope='Official club API republishes Opta; empty dated lineups require recovery from another official source, not a claim that data do not exist.')
    dump(FOLDER/'coverage.json',result); print(json.dumps(result),flush=True)


def main(pilot=False,year=None,retry=False,workers=3):
    index=json.loads((ROOT_OUT/'laliga_club_archive_index.json').read_bytes())
    wanted=games(); tasks=[i for i in index['matches'] if i['game_id'] in wanted]
    if pilot: tasks=[i for i in tasks if i['game_id'] in PILOT]
    else:
        assert json.loads((FOLDER/'pilot_validation.json').read_bytes())['status']=='PASS'
    if year:tasks=[i for i in tasks if i['date'].startswith(str(year))]
    db=connect(); done={gid:json.loads(b) for gid,b in db.execute('SELECT game_id,body FROM games')}
    tasks=[i for i in tasks if i['game_id'] not in done or retry]
    tasks.sort(key=lambda i:(i['date'],i['game_id']))
    client=OfficialClient(per_second=3);last=-1
    print(json.dumps(dict(stage='laliga_keeper_collection',year=year,requested=len(tasks),previously_checked=len(done))),flush=True)
    def one(index):
        try:return collect(wanted[index['game_id']],index,client)
        except Exception as exc:
            return dict(game_id=index['game_id'],date=index['date'],players=[],issues=[dict(reason='fixture_schema_or_identity_error',error=repr(exc))],parser_version=1)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        for n,record in enumerate(pool.map(one,tasks),1):
            with db:db.execute('INSERT OR REPLACE INTO games VALUES(?,?)',[record['game_id'],json.dumps(record,allow_nan=False)])
            pct=int(n*100/len(tasks))//10*10
            progress=dict(at_utc=stamp(),state='running' if n<len(tasks) else 'complete',year=year,processed=n,total=len(tasks),percent=round(100*n/len(tasks),1))
            dump(FOLDER/'collection_progress.json',progress)
            if pct>last:last=pct;print(json.dumps(progress),flush=True)
    db.close();coverage()


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');p.add_argument('--year',type=int);p.add_argument('--retry',action='store_true');p.add_argument('--workers',type=int,default=3)
    a=p.parse_args();main(a.pilot,a.year,a.retry,a.workers)
