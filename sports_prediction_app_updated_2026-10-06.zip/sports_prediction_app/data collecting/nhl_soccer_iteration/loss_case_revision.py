"""Trace large historical losses to raw player features before revising models.

Work products live in _work and are removed after publishing a validated result.
Earlier losses may motivate a hypothesis; later results never choose a cutoff.
"""
import argparse
import json
import numpy as np
import pandas as pd
from common import ROOT_OUT, PROJECT, read_db, dump, stamp, file_sha256

LABEL = 'loss_case_revision'
WORK = ROOT_OUT/'_work'/LABEL
RESULT = ROOT_OUT/'simulation_results'/LABEL
FIELDS = ['distance_covered_km','challenges_won','shots_at_goal']


def load_sources():
    meta=json.loads((WORK/'sources_ready.json').read_bytes())
    frames=[pd.read_pickle(WORK/(name+'.pkl')) for name in ['games','observations','players','labels']]
    keys={(game,side):value for game,side,value in meta['keys']}
    return (*frames,keys,meta)


def sources():
    import team_context_features as context
    import additional_soccer_features as additional
    import uefa_exposure_features as exposure
    assert not (WORK/'sources_ready.json').exists()
    WORK.mkdir(parents=True, exist_ok=True)
    RESULT.mkdir(exist_ok=True)
    for module in [context, additional, exposure]:
        module.OUT = WORK
    g,o,p,keys,stats,metrics,evidence,labels = context.context_sources(
        include_exposure=True, include_uefa_exposure=True)
    for name, frame in [('games',g),('observations',o),('players',p),('labels',labels)]:
        # Internal Python cache preserves mixed nullable source types exactly;
        # only normalized, audited results are published as Parquet/CSV.
        frame.to_pickle(WORK/(name+'.pkl'))
    dump(WORK/'sources_ready.json',dict(at_utc=stamp(),stats=stats,metrics=metrics,
        keys=[[game,side,value] for (game,side),value in keys.items()],evidence=evidence))
    print(json.dumps(dict(stage='sources_ready',games=len(g),players=len(p))),flush=True)


def trace():
    """Independent replay of observed rosters and per-player rate denominators."""
    import collections
    g=pd.read_pickle(WORK/'games.pkl')
    p=pd.read_pickle(WORK/'players.pkl')
    meta=json.loads((WORK/'sources_ready.json').read_bytes())
    keys={(game,side):value for game,side,value in meta['keys']}
    bets=pd.read_parquet(ROOT_OUT/'simulation_results/feature_revisions/soccer_additional_club_history/bets.parquet')
    bets=bets[bets.variant.eq('candidate')&bets.provider.eq('polymarket')&bets.year.eq(2025)]
    selected=set(bets.nsmallest(20,'profit').game_id)
    lookup=collections.defaultdict(list)
    for r in p.to_dict('records'):lookup[r['game_id'],r['side']].append(r)
    events=g.sort_values(['available_time','game_id']).to_dict('records');pos=0
    hist=collections.defaultdict(lambda:collections.deque(maxlen=60))
    phist=collections.defaultdict(lambda:collections.deque(maxlen=30));last_team={}
    rows=[];evidence=[]
    fields=['distance_covered_km','challenges_won','shots_at_goal','goals','key_passes']
    for r in g.sort_values(['prediction_time','game_id']).itertuples():
        while pos<len(events) and events[pos]['available_time']<r.prediction_time:
            past=events[pos];pos+=1
            for side in ['A','B']:
                team=keys[past['game_id'],side];observed=[]
                for pl in lookup[past['game_id'],side]:
                    minutes=pl.get('minutes')
                    if minutes is not None and np.isfinite(minutes) and minutes>0:
                        pid=pl['player_id'];phist[pid].append(pl);last_team[pid]=team;observed.append((pid,minutes))
                hist[team].append(observed)
        if r.game_id not in selected:continue
        for side in ['A','B']:
            team=keys[r.game_id,side];weights=collections.defaultdict(float)
            for game in list(hist[team])[-5:]:
                for pid,minutes in game:
                    if last_team.get(pid)==team:weights[pid]+=minutes
            for field in fields:
                for pid,weight in weights.items():
                    obs=[z for z in phist[pid] if z.get(field) is not None and np.isfinite(z[field])]
                    if not obs:continue
                    numerator=sum(z[field] for z in obs);denominator=sum(z['minutes'] for z in obs)
                    rows.append(dict(game_id=r.game_id,cutoff=r.prediction_time,side=side,team_key=team,
                        player_id=pid,player_name=obs[-1]['player_name'],field=field,weight=weight,
                        observation_games=len(obs),numerator=numerator,minutes=denominator,
                        per90=90*numerator/denominator,
                        max_source_available=max(pd.Timestamp(z['available_at_utc']) for z in obs)))
                    for z in obs:
                        evidence.append(dict(forecast_game_id=r.game_id,side=side,field=field,player_id=pid,
                            source_game_id=z['game_id'],official_player_id=z['official_player_id'],
                            player_name=z['player_name'],source_league=z['league'],
                            source_value=z[field],source_minutes=z['minutes'],
                            minutes_basis=z.get('minutes_basis'),available_at_utc=z['available_at_utc']))
    a=pd.DataFrame(rows);assert a.max_source_available.lt(a.cutoff).all()
    a.to_csv(RESULT/'development_player_rate_trace.csv',index=False)
    pd.DataFrame(evidence).to_parquet(RESULT/'development_player_rate_evidence.parquet',index=False)
    print(a[a.game_id.eq('EPL_20251122_SUN_FUL')].sort_values('per90',ascending=False).head(25).to_string(index=False),flush=True)


def coverage_features(g,p,keys):
    """Estimate a team rate without assigning one observed player the whole team.

    Missing raw facts stay missing. Unknown players receive the earlier observed
    population rate in this explicitly modelled feature, not fabricated counts.
    No pseudo-minute constant or return-selected threshold is introduced.
    """
    import collections
    lookup=collections.defaultdict(list)
    keep=['game_id','side','player_id','minutes','available_at_utc']+FIELDS
    for row in p[keep].to_dict('records'):lookup[row['game_id'],row['side']].append(row)
    hist=collections.defaultdict(lambda:collections.deque(maxlen=5))
    phist=collections.defaultdict(lambda:collections.deque(maxlen=30));last_team={}
    numerator=collections.Counter();denominator=collections.Counter()
    events=g.sort_values(['available_time','game_id']).to_dict('records');pos=0
    rows=[];features=[]
    for r in g.sort_values(['prediction_time','game_id']).itertuples():
        while pos<len(events) and events[pos]['available_time']<r.prediction_time:
            old=events[pos];pos+=1
            for side in ['A','B']:
                team=keys[old['game_id'],side];observed=[]
                for pl in lookup[old['game_id'],side]:
                    minutes=pl['minutes']
                    if minutes is None or not np.isfinite(minutes) or minutes<=0:continue
                    assert pd.Timestamp(pl['available_at_utc'])<=old['available_time']
                    pid=pl['player_id'];phist[pid].append(pl);last_team[pid]=team;observed.append((pid,minutes))
                    for field in FIELDS:
                        value=pl[field]
                        if value is not None and np.isfinite(value):
                            numerator[field]+=value;denominator[field]+=minutes
                hist[team].append(observed)
        values={};result={'game_id':r.game_id}
        for side in ['A','B']:
            team=keys[r.game_id,side];weights=collections.defaultdict(float)
            for game in hist[team]:
                for pid,minutes in game:
                    if last_team.get(pid)==team:weights[pid]+=minutes
            total=sum(weights.values())
            for field in FIELDS:
                prior=90*numerator[field]/denominator[field] if denominator[field] else np.nan
                observed=[];clocks=[]
                for pid,weight in weights.items():
                    obs=[z for z in phist[pid] if z[field] is not None and np.isfinite(z[field])]
                    if not obs:continue
                    rate=90*sum(z[field] for z in obs)/sum(z['minutes'] for z in obs)
                    observed.append((weight,rate));clocks.extend(pd.Timestamp(z['available_at_utc']) for z in obs)
                covered=sum(w for w,v in observed)
                raw=sum(w*v for w,v in observed)/covered if covered else np.nan
                adjusted=prior+sum(w*(v-prior) for w,v in observed)/total if total and np.isfinite(prior) else prior
                fraction=covered/total if total else 0.
                assert 0<=fraction<=1+1e-10
                if covered:assert np.isclose(adjusted,prior+fraction*(raw-prior),atol=1e-10)
                assert not clocks or max(clocks)<r.prediction_time
                values[side,field]=adjusted
                rows.append(dict(game_id=r.game_id,cutoff_utc=r.prediction_time,side=side,field=field,
                    roster_players=len(weights),observed_players=len(observed),recent_roster_minutes=total,
                    covered_roster_minutes=covered,covered_fraction=fraction,observed_rate_per90=raw,
                    earlier_population_rate_per90=prior,coverage_adjusted_rate_per90=adjusted,
                    latest_player_source_utc=max(clocks) if clocks else None))
        for field in FIELDS:result['f_ctx_roster_'+field+'_rate_diff']=values['B',field]-values['A',field]
        features.append(result)
    return pd.DataFrame(features).set_index('game_id'),pd.DataFrame(rows)


def build():
    import features
    from soccer_clock_recovery import aliases
    from soccer_club_history_model import summaries, FIELDS as score_fields
    assert not (WORK/'features_ready.json').exists()
    g,o,p,labels,keys,meta=load_sources()
    base,checks=features.build('soccer',g,o,p,keys,meta['stats'],meta['metrics'])
    base['observation_available_time']=base.available_time
    base['available_time']=base.game_id.map(labels.set_index('game_id').available_time)
    base=aliases(base).set_index('game_id')
    extra_path=ROOT_OUT/'soccer_additional_club_results.parquet'
    extra=pd.read_parquet(extra_path).rename(columns={'regulation_scoreA':'scoreA','regulation_scoreB':'scoreB'})
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
        registry={(code,str(native)):json.loads(body)['team_id'] for code,native,body in db.execute('SELECT * FROM _eu_team_identity')}
    for row in extra.itertuples():
        for side in ['A','B']:
            native=str(getattr(row,'team'+side+'_id'));keys[row.game_id,side]=registry.get(('UCL',native),'UEFA Champions League:'+native)
    for col in ['start_time','available_time']:extra[col]=pd.to_datetime(extra[col],utc=True,format='mixed')
    history=pd.concat([g,extra],ignore_index=True)
    base[score_fields]=summaries(g,history,keys).loc[base.index,score_fields]
    adjusted,coverage=coverage_features(g,p,keys)
    # Reconstruct original measured-only aggregation from independent replay.
    for field in FIELDS:
        c='f_ctx_roster_'+field+'_rate_diff'
        pivot=coverage[coverage.field.eq(field)].pivot(index='game_id',columns='side',values='observed_rate_per90').loc[base.index]
        assert np.allclose(pivot.B-pivot.A,base[c],atol=1e-10,rtol=0,equal_nan=True)
    candidate=base.copy();candidate[adjusted.columns]=adjusted.loc[base.index]
    assert candidate.drop(columns=adjusted.columns).equals(base.drop(columns=adjusted.columns))
    cut=pd.Timestamp('2025-01-01',tz='UTC');early=g[g.prediction_time.lt(cut)]
    pg=g[g.available_time.lt(cut) | g.game_id.isin(early.game_id)]
    pp=p[p.game_id.isin(pg.game_id)]
    prefix,_=coverage_features(pg,pp,keys)
    pd.testing.assert_frame_equal(prefix.loc[early.game_id],adjusted.loc[early.game_id],check_exact=True)
    for name,f in [('reference',base),('candidate',candidate)]:
        folder=WORK/name;folder.mkdir(exist_ok=True);f.reset_index().to_parquet(folder/'soccer_features.parquet',index=False)
    coverage.to_parquet(RESULT/'roster_coverage_audit.parquet',index=False)
    changed={c:int((~np.isclose(base[c],candidate[c],atol=1e-12,equal_nan=True)).sum()) for c in adjusted}
    proof=dict(status='PASS',at_utc=stamp(),games=len(base),player_rows=len(p),changed_columns=changed,
        original_rates_independently_reproduced=True,prefix_invariant_rows=len(early),raw_data_unchanged=True,
        source_hashes={name:file_sha256(WORK/(name+'.pkl')) for name in ['games','observations','players','labels']},
        candidate_feature_sha256=file_sha256(WORK/'candidate/soccer_features.parquet'),
        reference_feature_sha256=file_sha256(WORK/'reference/soccer_features.parquet'))
    dump(WORK/'features_ready.json',proof);dump(RESULT/'feature_validation.json',proof)
    print(json.dumps(proof),flush=True)


def train():
    import copy
    import pickle
    import models
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    from sklearn.metrics import log_loss
    import soccer_club_history_model as paired
    assert (WORK/'features_ready.json').exists() and not (RESULT/'validation.json').exists()
    source=ROOT_OUT/'simulation_results/feature_revisions/soccer_additional_club_history'
    recipe=json.loads((source/'experiment_plan.json').read_bytes())['recipe']
    plan=dict(at_utc=stamp(),hypothesis='In the largest2025loss, one Fulham substitute with one recent roster minute represents the whole observed physical-stat pool. Weight observed player deviations from the earlier population rate by their share of ALL recent roster minutes.',
        formula='Adjusted team rate=earlier population rate+sum(observed player recent-minute weight*(player per90 rate-population rate))/sum(all roster recent-minute weights). Difference=home minus away.',
        changed_columns=['f_ctx_roster_'+field+'_rate_diff' for field in FIELDS],recipe=recipe,
        unchanged='All other36inputs, prior club history, raw observations, model learner and hyperparameters, monthly expanding2021+ fits and purged180day calibration.',
        gate='Lower pooled2024/25 multiclass logloss AND Brier on the same games. No betting profit used to choose model. Evaluate2026only after gate.',
        staking='Keep$5per percentage point of positive model-price advantage. Test existing$20per-bet maximum, chosen only if2025Sharpe higher, drawdown lower and return positive. No threshold grid.',
        selection='One quoted outcome by unchanged expected-log-growth rule; pre12 closest preceding quote up to24h old; cash only; hold to official result; providers separate.',
        initial_cash=2000,no_cost_assumptions=True,app_changed=False,
        evaluation='2026is retrospective after repeated research, never described as an untouched strategy holdout.')
    dump(RESULT/'experiment_plan.json',plan)
    all_dev=[];replays=[]
    for variant in ['reference','candidate']:
        name='coverage_'+variant;models.OUT=WORK/variant;models.CANDIDATES[name]=copy.deepcopy(recipe)
        dev=models.run('soccer','development',[name]);dev['variant']=variant;all_dev.append(dev)
        pack=pickle.loads((models.OUT/'model_runs/soccer/development'/(name+'.pkl')).read_bytes())
        frame=pd.read_parquet(models.OUT/'soccer_features.parquet')
        matrix=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
        sample=dev[dev.fold.eq(pack['boundary'].strftime('%Y-%m'))].head(20)
        x=matrix.loc[sample.game_id,pack['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
        actual=models.apply_calibration(pack['model'].predict_proba(x),pack['calibrator'])
        assert np.allclose(actual,sample[['p0','p1','p2']],atol=1e-12,rtol=0)
        assert dev.train_label_max.lt(dev.prediction_time).all() and dev.calibration_label_max.lt(dev.prediction_time).all()
        replays.append(dict(variant=variant,forecasts=len(dev),replays=len(sample),inputs=len(pack['columns'])))
    control,candidate=all_dev
    old=pd.read_parquet(source/'development_predictions.parquet');old=old[old.variant.eq('candidate')].set_index('game_id')
    replay=control.set_index('game_id').loc[old.index]
    assert np.allclose(old[['p0','p1','p2']],replay[['p0','p1','p2']],atol=1e-12,rtol=0),'Reference source reconstruction changed forecasts'
    joined=pd.concat(all_dev,ignore_index=True)
    joined.to_parquet(RESULT/'development_predictions.parquet',index=False)
    models.metrics(joined).to_csv(RESULT/'development_metrics.csv',index=False)
    scores=[]
    for variant,f in joined.groupby('variant'):
        prob=f[['p0','p1','p2']].to_numpy();y=f.target.to_numpy(int)
        scores.append(dict(variant=variant,games=len(f),log_loss=log_loss(y,prob,labels=[0,1,2]),
            brier=float(np.mean(np.sum((prob-np.eye(3)[y])**2,axis=1)))))
    lookup={r['variant']:r for r in scores}
    passed=all(lookup['candidate'][key]<lookup['reference'][key] for key in ['log_loss','brier'])
    paired.RESULT=RESULT;paired_result=paired.paired_comparison(candidate,control)
    decision=dict(at_utc=stamp(),passed=bool(passed),scores=scores,paired=paired_result,adopted=False)
    dump(RESULT/'selection.json',decision)
    print(json.dumps(decision),flush=True)
    transfer.RESULT=RESULT;quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62')
    records=[];betrows=[];days=[];checks=[];choices={};candidate_outcomes=None
    for variant,f in joined.groupby('variant'):
        normalized=transfer.normalize('soccer',f,quotes,pick_growth=True)
        if variant=='candidate':candidate_outcomes=normalized
        for provider,h in normalized.groupby('provider'):
            for year in sorted(h.year.unique()):
                for rule in (['edge','cap20'] if variant=='candidate' and year==2025 else ['edge']):
                    cap=20. if rule=='cap20' else None
                    m,b,l,d=engine.simulate(h,int(year),'all_selected_outcomes','edge_dollars_cash_only',5.,2000.,cap)
                    key=dict(sport='soccer',provider=provider,variant=variant,year=int(year),rule=rule)
                    records.append(key|m);betrows.append(b.assign(**key));days.append(d.assign(**key))
                    checks.append(key|engine.validate(b,l,d,'edge_dollars_cash_only',5.,2000.,cap))
    a=pd.DataFrame(records)
    for provider,h in a[a.variant.eq('candidate')&a.year.eq(2025)].groupby('provider'):
        ref=h[h.rule.eq('edge')].iloc[0];cap=h[h.rule.eq('cap20')].iloc[0]
        choices[provider]='cap20' if cap.return_pct>0 and cap.sharpe>ref.sharpe and cap.max_drawdown_pct<ref.max_drawdown_pct else 'edge'
    dump(RESULT/'staking_selection.json',dict(at_utc=stamp(),choices=choices,selection_year=2025,adopted=False))
    if passed:
        name='coverage_candidate';models.OUT=WORK/'candidate';dump(models.OUT/'soccer_selection.json',dict(selected_candidates=[name]))
        test=models.run('soccer','evaluation',[name]);test['variant']='candidate'
        reference=pd.read_parquet(source/'evaluation_predictions.parquet');reference=reference[reference.variant.eq('candidate')].copy();reference['variant']='reference'
        evaluation=pd.concat([reference,test],ignore_index=True);evaluation.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
        models.metrics(evaluation).to_csv(RESULT/'evaluation_metrics.csv',index=False)
        for variant,f in evaluation.groupby('variant'):
            norm=transfer.normalize('soccer',f,quotes,pick_growth=True)
            for provider,h in norm.groupby('provider'):
                for rule in (list(dict.fromkeys(['edge',choices[provider]])) if variant=='candidate' else ['edge']):
                    cap=20. if rule=='cap20' else None
                    m,b,l,d=engine.simulate(h,2026,'all_selected_outcomes','edge_dollars_cash_only',5.,2000.,cap)
                    key=dict(sport='soccer',provider=provider,variant=variant,year=2026,rule=rule)
                    records.append(key|m);betrows.append(b.assign(**key));days.append(d.assign(**key))
                    checks.append(key|engine.validate(b,l,d,'edge_dollars_cash_only',5.,2000.,cap))
    a=pd.DataFrame(records);a.to_csv(RESULT/'annual.csv',index=False)
    pd.concat(betrows,ignore_index=True).to_parquet(RESULT/'bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'daily.parquet',index=False)
    dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),reference3961forecasts_reproduced=True,
        feature_validation=json.loads((WORK/'features_ready.json').read_bytes()),forecast_replays=replays,
        cash_checks=checks,development_gate_passed=bool(passed),evaluated2026=bool(passed),adopted=False,app_changed=False))
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL]=dict(plan=plan,decision=decision,staking_choices=choices,adopted=False);dump(path,old)
    print(a[['provider','variant','year','rule','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].round(4).to_string(index=False),flush=True)


def evidence():
    """Verify the traced raw measurements and describe NHL loss clusters."""
    import hashlib
    from common import PREVIOUS
    traced=pd.read_parquet(RESULT/'development_player_rate_evidence.parquet')
    picked=traced[traced.forecast_game_id.eq('EPL_20251122_SUN_FUL')&traced.player_id.eq('EU_PL:631786')&traced.field.isin(FIELDS)]
    proof=[]
    with read_db(ROOT_OUT/'granular.sqlite') as db, read_db(ROOT_OUT/'bundesliga_minutes.sqlite') as minute_db:
        for r in picked.itertuples():
            row=dict(db.execute('SELECT * FROM bundesliga_players_match_statistics WHERE game_id=? AND official_player_id=?',(r.source_game_id,r.official_player_id)).fetchone())
            ev=json.loads(row['field_evidence'])[r.field];src=ev['source']
            raw=(PROJECT/src['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==src['sha256']
            value=json.loads(raw)
            for part in ev['pointer'].strip('/').split('/'):
                part=part.replace('~1','/').replace('~0','~');value=value[int(part)] if isinstance(value,list) else value[part]
            assert float(value)==r.source_value==row[r.field]
            record=json.loads(minute_db.execute('SELECT body FROM games WHERE game_id=?',(r.source_game_id,)).fetchone()[0])
            pl=next(z for z in record['players'] if z['official_player_id']==r.official_player_id)
            assert pl['minutes']==r.source_minutes
            ms=pl['source'];blob=(PROJECT/ms['raw_file']).read_bytes();assert hashlib.sha256(blob).hexdigest()==ms['sha256']
            ls=pl['lineup_source'];blob2=(PROJECT/ls['raw_file']).read_bytes();assert hashlib.sha256(blob2).hexdigest()==ls['sha256']
            from collect_bundesliga_minutes import parse
            with read_db(PREVIOUS/'expanded.sqlite') as game_db:
                game=dict(game_db.execute('SELECT * FROM soccer_games WHERE game_id=?',(r.source_game_id,)).fetchone())
            replay=parse(game,json.loads(blob),json.loads(blob2),ms,ls)
            rp=next(z for z in replay['players'] if z['official_player_id']==r.official_player_id)
            assert rp['minutes']==r.source_minutes and rp['minutes_complete']
            proof.append(dict(forecast_game_id=r.forecast_game_id,player_id=r.player_id,player_name=r.player_name,
                source_game_id=r.source_game_id,field=r.field,raw_value=value,normalized_value=r.source_value,
                source_minutes=r.source_minutes,minutes_basis=r.minutes_basis,
                statistics_source=src,statistics_pointer=ev['pointer'],minutes_source=ms,lineup_source=ls,
                raw_value_matches=True,minutes_parser_replayed=True))
    dump(RESULT/'raw_case_validation.json',dict(status='PASS',at_utc=stamp(),examples=proof,
        public_validation_urls=['https://fcbayern.com/en/news/matchreports/2025/04/match-report-bundesliga-md29-fc-bayern-v-fsv-mainz-260425',
          'https://www.bundesliga.com/de/bundesliga/news/jonah-kusi-asare-fc-bayern-munchen-leihe-fc-fulham-33861'],
        finding='Valid native measurements and regulation-minute definitions became an unreliable whole-team feature because the denominator omitted unmeasured roster members. Public club report corroborates the88th-minute substitution.'))
    source=ROOT_OUT/'simulation_results/uncertainty_buffer_staking/fixed_stake_bets.parquet'
    f=pd.read_parquet(source);f=f[f.sport.eq('nhl')&f.rule.eq('relative_advantage10_flat20')].copy()
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games=pd.read_sql_query('SELECT game_id,official_game_id,phase,scoreA,scoreB,source_request_id,source_pointer FROM nhl_games',db)
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        q=pd.read_sql_query('SELECT * FROM nhl_regulation_goal_statistics',db)
    f=f.merge(games,on='game_id',validate='many_to_one');assert f.side.eq(f.target).eq(f.won).all()
    assert f.target.eq(np.where(f.scoreA.gt(f.scoreB),0,1)).all()
    f['signed_final_margin']=np.where(f.side.eq(0),f.scoreA-f.scoreB,f.scoreB-f.scoreA)
    regulation=q.pivot(index='game_id',columns='side',values='regulation_goals')
    f['regulation_scoreA']=f.game_id.map(regulation.A);f['regulation_scoreB']=f.game_id.map(regulation.B)
    f['regulation_tied']=f.regulation_scoreA.eq(f.regulation_scoreB).where(f.regulation_scoreA.notna()&f.regulation_scoreB.notna())
    f['month']=f.entry.dt.strftime('%Y-%m')
    f['expected_win_variance']=f.probability*(1-f.probability)
    monthly=f.groupby(['provider','year','month']).agg(bets=('game_id','size'),wins=('won','sum'),
        predicted_wins=('probability','sum'),expected_win_variance=('expected_win_variance','sum'),
        average_price=('price','mean'),mean_forecast=('probability','mean'),win_rate=('won','mean'),
        total_stake=('stake','sum'),cohort_profit=('profit','sum')).reset_index()
    monthly['win_count_residual_sd']=(monthly.wins-monthly.predicted_wins)/np.sqrt(monthly.expected_win_variance)
    monthly.to_csv(RESULT/'nhl_monthly_loss_clusters.csv',index=False)
    f.to_parquet(RESULT/'nhl_loss_case_evidence.parquet',index=False)
    margins=f[~f.won].groupby(['provider','year','signed_final_margin','regulation_tied'],dropna=False).agg(
        losses=('game_id','size'),lost_stakes=('stake','sum')).reset_index()
    margins.to_csv(RESULT/'nhl_losing_result_types.csv',index=False)
    dump(RESULT/'nhl_loss_validation.json',dict(status='PASS',at_utc=stamp(),source_sha256=file_sha256(source),
        all_bets_fixed20=bool(np.allclose(f.stake,20)),official_winner_matches=True,rows=len(f),
        regulation_missing=int(f.regulation_tied.isna().sum()),
        interpretation='Final margin and regulation tie are retrospective outcomes only, never entry filters. Monthly expected variance assumes independent correct forecasts; this diagnostic does not prove chance or causation and is not adjusted for month selection.',
        revision='No NHL month or losing-team exclusion selected. Preserve fixed20two-model10%advantage comparator; inspect conditional forecast errors before a new revision.'))


def risk():
    """Existing20%aggregate exposure limit, now combined with price-edge sizing."""
    import test_confidence_dollars as engine
    assert (RESULT/'validation.json').exists() and not (RESULT/'risk_validation.json').exists()
    source=RESULT/'bets.parquet';all=pd.read_parquet(source)
    f=all[all.variant.eq('candidate')&all.rule.eq('edge')].copy()
    annual=pd.read_csv(RESULT/'annual.csv');a=annual[annual.variant.eq('candidate')&annual.rule.eq('edge')]
    assert a.unfunded_games.eq(0).all()
    dump(RESULT/'risk_plan.json',dict(at_utc=stamp(),source_sha256=file_sha256(source),
        hypothesis='Fixed-dollar stakes grow as a fraction of equity during losses. A pre-existing20%aggregate open-cost limit stops new wagers consuming most remaining capital; do not increase the stake multiplier.',
        change='Same desired$5per probability-price point, same forecasts and opportunities. Prorate simultaneous new requests into min(cash,20%current_equity-existing_open_cost). Do not liquidate prior positions.',
        selection='2025positive return,higher Sharpe AND lower drawdown than uncapped rule.2026only if passed. No exposure-cap grid.',
        equity='Cash plus open cost; no borrowing, costs or spread assumptions.',app_changed=False))
    records=[];bets=[];days=[];checks=[];choices={}
    for year in [2025,2026]:
        for provider,g in f.groupby('provider'):
            if year==2026 and not choices[provider]:continue
            for rule,sizing in [('edge','edge_dollars_cash_only'),('open20','edge_dollars_cap20')]:
                m,b,l,d=engine.simulate(g,year,'all_selected_outcomes',sizing,5.,2000.)
                key=dict(sport='soccer',provider=provider,variant='candidate',year=year,rule=rule)
                records.append(key|m);bets.append(b.assign(**key));days.append(d.assign(**key))
                checks.append(key|engine.validate(b,l,d,sizing,5.,2000.))
                if rule=='edge':
                    old=g[g.year.eq(year)].sort_values('game_id');new=b.sort_values('game_id')
                    assert old.game_id.tolist()==new.game_id.tolist()
                    assert np.allclose(old[['stake','profit']],new[['stake','profit']],atol=1e-8,rtol=0)
                else:
                    used=l[l.spent.gt(0)];assert used.open_cost.le(.2*used.equity+1e-8).all()
            if year==2025:
                ref,new=records[-2:];choices[provider]=bool(new['return_pct']>0 and new['sharpe']>ref['sharpe'] and new['max_drawdown_pct']<ref['max_drawdown_pct'])
        if year==2025:dump(RESULT/'risk_selection.json',dict(at_utc=stamp(),choices=choices,selection_year=2025,adopted=False))
    a=pd.DataFrame(records);a.to_csv(RESULT/'risk_annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/'risk_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'risk_daily.parquet',index=False)
    dump(RESULT/'risk_validation.json',dict(status='PASS',at_utc=stamp(),checks=checks,
        baseline_exactly_reproduced=True,aggregate_cap_verified_at_each_purchase=True,choices=choices,adopted=False))
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=LABEL+'/risk_annual.csv'
    pd.concat([old[old.source_result_file.ne(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[LABEL+'/risk']=dict(plan=json.loads((RESULT/'risk_plan.json').read_bytes()),choices=choices,adopted=False);dump(path,old)
    print(a[['provider','year','rule','funded_games','return_pct','sharpe','max_drawdown_pct']].round(4).to_string(index=False),flush=True)


def scope():
    """Keep physical predictors within their native measurement competition."""
    import copy
    import pickle
    import models
    from sklearn.metrics import log_loss
    import soccer_tie_context as simulation
    import soccer_club_history_model as paired
    out=RESULT/'source_scope';out.mkdir(exist_ok=True)
    work=WORK/'source_scope';work.mkdir(exist_ok=True)
    assert not (out/'validation.json').exists()
    base=pd.read_parquet(WORK/'reference/soccer_features.parquet');frame=base.copy()
    cols=['f_ctx_roster_'+c+'_rate_diff' for c in FIELDS]
    frame.loc[frame.league.ne('Bundesliga'),cols]=np.nan
    assert frame.drop(columns=cols).equals(base.drop(columns=cols))
    assert frame.loc[frame.league.eq('Bundesliga'),cols].equals(base.loc[base.league.eq('Bundesliga'),cols])
    frame.to_parquet(work/'soccer_features.parquet',index=False)
    recipe=json.loads((RESULT/'experiment_plan.json').read_bytes())['recipe']
    dump(out/'experiment_plan.json',dict(at_utc=stamp(),hypothesis='The three physical measurements originate only in Bundesliga and become unrepresentative team proxies after transfers. Restrict these model inputs to Bundesliga; keep raw cross-league records for research. No team/outcome filter.',
        change='Three physical-rate difference predictors become NaN outside Bundesliga, handled by existing earlier-fit imputation and indicators. All raw rows and other36inputs unchanged.',
        recipe=recipe,gate='Lower2024/25 logloss AND Brier than BOTH original extra-club-history control and coverage-adjusted candidate. No2026selection or parameter search.',
        history_from='2021-01-01',forecasts_from='2024-01-01',app_changed=False,
        evaluation='2026afterdevelopmentgate only; repeatedly examined retrospective period.',
        feature_sha256=file_sha256(work/'soccer_features.parquet')))
    name='source_scope';models.OUT=work;models.CANDIDATES[name]=copy.deepcopy(recipe)
    candidate=models.run('soccer','development',[name]);candidate['variant']='candidate'
    reference=pd.read_parquet(RESULT/'development_predictions.parquet');reference=reference[reference.variant.eq('candidate')].copy();reference['variant']='coverage_reference'
    original=pd.read_parquet(RESULT/'development_predictions.parquet');original=original[original.variant.eq('reference')].copy();original['variant']='original_reference'
    joined=pd.concat([candidate,reference,original],ignore_index=True)
    joined.to_parquet(out/'development_predictions.parquet',index=False);models.metrics(joined).to_csv(out/'development_metrics.csv',index=False)
    scores={}
    for variant,f in joined.groupby('variant'):
        p=f[['p0','p1','p2']].to_numpy();y=f.target.to_numpy(int)
        scores[variant]=dict(log_loss=log_loss(y,p,labels=[0,1,2]),brier=float(np.mean(np.sum((p-np.eye(3)[y])**2,axis=1))))
    passed=all(scores['candidate'][metric]<scores[variant][metric] for metric in ['log_loss','brier'] for variant in ['coverage_reference','original_reference'])
    paired.RESULT=out;comparison=paired.paired_comparison(candidate,reference)
    dump(out/'selection.json',dict(at_utc=stamp(),passed=bool(passed),scores=scores,paired=comparison,adopted=False))
    package=pickle.loads((work/'model_runs/soccer/development'/(name+'.pkl')).read_bytes())
    matrix=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
    sample=candidate[candidate.fold.eq(package['boundary'].strftime('%Y-%m'))].head(20)
    x=matrix.loc[sample.game_id,package['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
    p=models.apply_calibration(package['model'].predict_proba(x),package['calibrator'])
    assert np.allclose(p,sample[['p0','p1','p2']],atol=1e-12,rtol=0)
    evaluation=None
    if passed:
        dump(work/'soccer_selection.json',dict(selected_candidates=[name]));test=models.run('soccer','evaluation',[name]);test['variant']='candidate'
        refs=pd.read_parquet(RESULT/'evaluation_predictions.parquet');refs['variant']=refs.variant.map({'candidate':'coverage_reference','reference':'original_reference'})
        evaluation=pd.concat([test,refs],ignore_index=True);evaluation.to_parquet(out/'evaluation_predictions.parquet',index=False)
        models.metrics(evaluation).to_csv(out/'evaluation_metrics.csv',index=False)
    simulation.RESULT=out;simulation.simulate(joined,evaluation)
    dump(out/'validation.json',dict(status='PASS',at_utc=stamp(),raw_preserved=True,other_inputs_unchanged=True,
        non_bundesliga_features_not_used=True,reference_raw_feature_sha256=file_sha256(WORK/'reference/soccer_features.parquet'),
        earlier_only_fits=bool(candidate.train_label_max.lt(candidate.prediction_time).all() and candidate.calibration_label_max.lt(candidate.prediction_time).all()),
        forecast_replays=len(sample),gate_passed=bool(passed),evaluated2026=bool(passed),adopted=False,app_changed=False))
    print(json.dumps(dict(scores=scores,passed=bool(passed))),flush=True)


def finish():
    """Publish the completed loss investigation and delete temporary fits only."""
    from common import REPORTS
    from final_pipeline import discard_work,cleanup,validate
    from publish import main as catalog
    for path in ['validation.json','raw_case_validation.json','nhl_loss_validation.json',
                 'risk_validation.json','source_scope/validation.json']:
        assert json.loads((RESULT/path).read_bytes())['status']=='PASS'
    def table(f):
        def value(v):
            return f'{v:.4f}' if isinstance(v,(float,np.floating)) else str(v)
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+
            ['| '+' | '.join(value(v) for v in row)+' |' for row in f.itertuples(index=False,name=None)])
    a=pd.read_csv(RESULT/'annual.csv')
    scope_scores=json.loads((RESULT/'source_scope/selection.json').read_bytes())
    p=pd.read_parquet(RESULT/'development_predictions.parquet');case=p[p.game_id.eq('EPL_20251122_SUN_FUL')][['variant','p0','p1','p2']]
    bets=pd.read_parquet(RESULT/'bets.parquet');casebets=bets[bets.game_id.eq('EPL_20251122_SUN_FUL')&bets.provider.eq('polymarket')&bets.rule.eq('edge')]
    monthly=pd.read_csv(RESULT/'nhl_monthly_loss_clusters.csv')
    nhl=monthly[monthly.provider.eq('polymarket')&monthly.month.isin(['2025-11','2026-02','2026-03'])]
    original=pd.read_csv(ROOT_OUT/'simulation_results/uncertainty_buffer_staking/fixed_stake_annual.csv')
    nhl_accounts=original[original.sport.eq('nhl')&original.rule.eq('relative_advantage10_flat20')&original.year.eq(2026)]
    lines=['# Loss investigation and controlled revisions','',
        'The investigation found a source-coverage error in the construction of three soccer team inputs. Correcting the example did not establish a better later-period strategy. The Sharpe3 and return20% target remains unmet. No production/app model was changed.','',
        'All model fits expand from2021 using only labels available before each monthly forecast boundary. Per-game summaries stop at the forecast time. Earlier purged180-day games fit calibration.2024/25 chooses changes;2026 was evaluated only after the written gate. Because2026 has already been inspected repeatedly, these are retrospective rolling forecasts, not an untouched strategy test.','',
        '## The Sunderland–Fulham loss','',
        'Before the22November2025 match, Fulham had4950recent observed roster minutes. Only Jonah Kusi-Asare, with one of those minutes, had the three Bundesliga physical fields. His recorded3challenges in2regulation minutes became135per90. His distance was2.4km over6regulation minutes across two prior appearances, or36km/90. The old formula divided by measured-player weights only: that one substitute therefore represented the entire Fulham team for these fields, despite covering0.0202%of the roster-minute weight. Sunderland had24.08%coverage.','',
        'Native values, player IDs and clocks were replayed against the hashed original Bundesliga rankings, lineups and commentary; the original measurements match. This is an unrepresentative aggregate, not a fabricated observation, wrong final winner or future-data leak. Regulation-only minutes also omit stoppage, making very brief cameo rates unstable.','',
        'The official Bayern report corroborates his88th-minute entry: https://fcbayern.com/en/news/matchreports/2025/04/match-report-bundesliga-md29-fc-bayern-v-fsv-mainz-260425 . The official Bundesliga announcement corroborates the Fulham loan: https://www.bundesliga.com/de/bundesliga/news/jonah-kusi-asare-fc-bayern-munchen-leihe-fc-fulham-33861 . These pages validate identity/context; they are not future model features.','',
        'The revision uses the earlier observed population rate for the unmeasured share of a team and weights measured deviations by their share of ALL recent roster minutes. The underlying raw missing values remain null; these are explicitly modelled features, not asserted player measurements. Only three inputs change; the other36inputs and learner remain unchanged.','',table(case),'',
        'p0=Sunderland, p1=Fulham, p2=draw. The original76.63%Sunderland forecast becomes32.30%. This single repaired case is not the adoption criterion. Its recorded positions are:','',
        table(casebets[['variant','side','probability','price','stake','profit']]),'',
        '## Full rolling comparison','',
        'Pooled2024/25 multiclass logloss improves0.976001 to0.975390; Brier improves0.581337 to0.580933. The paired monthly-block95%loss-change interval[-0.001941,+0.000436]includes zero and is not corrected for repeated experimentation.2024alone worsens slightly;2025improves.','',
        'In2026, winner classification accuracy falls51.37%to51.01%, and logloss worsens0.999361to1.000527. Betting results are below. edge means$5per percentage point of positive model-price difference, with one outcome selected using the unchanged expected-log-growth rule; it may be an underdog or draw. cap20 limits each bet to$20.','',
        table(a[['provider','variant','year','rule','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        'Each account starts with$2000peryear. Stakes are fixed dollar amounts rather than automatically compounded fractions. Cash and unsettled positions are accounted for chronologically, with no borrowing or reuse of unsettled money. pre12 uses the latest earlier observation, with at most24h age. Prices are international Polymarket historical token prices or Kalshi YES asks; these are not verified executable US fills. No cost/spread assumption is added. Open positions are valued at cost. Daily calendar Sharpe includes idle days and uses sqrt365.25;2026ends29September, so returns are partial-year, not annualized.','',
        'The coverage revision reduced2025Polymarket drawdown38.09%to32.51%, but2026drawdown rose46.12%to83.60%. The account reached about$352before recovering. More bets winning did not compensate for the distribution and timing of losses. It is not adopted.','',
        '## Risk revisions and source-scope test','',
        'The$20single-bet ceiling lowered2025drawdown but reduced Sharpe and return, failing the declared gate. A second test used the already established20%of-current-equity limit on total open purchase cost, without changing the requested$5peredgepoint. Existing positions were retained; only new requests were scaled into available risk capacity. It also failed2025and was not advanced to2026.','',
        table(pd.read_csv(RESULT/'risk_annual.csv')[['provider','year','rule','funded_games','return_pct','sharpe','max_drawdown_pct']]),'',
        'A further model comparison limits the three physical-stat predictors to their native Bundesliga competition. Outside that competition the model uses its existing earlier-trained missing-value handling. Original source facts are preserved. This improves logloss relative to both controls, but Brier is very slightly worse than the coverage-adjusted comparator; it fails the declared two-metric gate. No2026evaluation was performed for this candidate.','',
        table(pd.DataFrame([{'variant':k,**v} for k,v in scope_scores['scores'].items()])),'',
        '## NHL loss findings','',
        'The retained research comparator buys a fixed$20only when BOTH saved models imply at least10%expected return at the observed price. Its2026results remain:','',
        table(nhl_accounts[['provider','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        'The official final winners were rechecked for every funded bet. Losses are already$20each; increasing or decreasing the stake alone does not correct forecast errors. These entry-month cohorts show loss clusters and a concentrated positive month:','',
        table(nhl[['month','bets','wins','mean_forecast','win_rate','cohort_profit']]),'',
        'November2025had22wins against29.14expected by the model. February2026had1against3.83expected; March had38against28.16expected. Those clusters do not establish a predictable calendar rule. The entire2026Polymarket cohort earns$748.19, of which March contributes$720.87. Do not ban losing months or teams after observing their results. Official regulation ties and final margins are retained as retrospective diagnosis only, never predictors for the same game.','',
        '## Next revision and retained evidence','',
        'Keep the frozen NHL comparator and prior soccer baseline. Next inspect the large European cup disagreements, starting with whether sparse clubs receive misleading neutral strength from limited domestic/opponent history and whether already-qualified clubs rotate their squads. Verify dated source evidence before adding features. The goal is to improve forecast reliability in those cases, not to choose a price band or exclude a losing club from2026.','',
        'Reproduce with loss_case_revision.py stages sources,trace,build,evidence,train,risk,scope,finish. Consolidated forecasts, account results, raw-source replay evidence and roster coverage diagnostics remain in simulation_results/loss_case_revision. Temporary source caches, duplicate model matrices and trial fits are deleted after this publication. The final SQL source dataset remains93tables; its schema was not changed by this model experiment.','']
    report=REPORTS/'loss_case_revision.md';report.write_text('\n'.join(lines),encoding='utf8')
    code=__import__('pathlib').Path(__file__).resolve().parent
    readme=code/'README.md';text=readme.read_text(encoding='utf8');marker='## Loss-case investigation and coverage revisions'
    addition='\n\n'+marker+'\n\n'+(
        '`loss_case_revision.py` traces the largest2025losses to dated player observations, verifies raw Bundesliga values and minute derivation, and tests roster-coverage and native-competition restrictions with monthly expanding forecasts. The observed-only team denominator let a one-minute substitute represent the full Fulham physical profile. Correcting that case did not improve2026risk/return; the alternatives and risk limits are recorded without adoption. NHL losses are reconciled to official winners and grouped by entry-month and regulation/final score for diagnosis. See `reports/nhl_soccer_iteration/loss_case_revision.md`.\n\n'
        'Reproduction: run stages `sources`, `trace`, `build`, `evidence`, `train`, `risk`, `scope`, `finish` in that order. No new API calls are required: original hashed official responses are replayed. Source documentation/manual validation: https://fcbayern.com/en/news/matchreports/2025/04/match-report-bundesliga-md29-fc-bayern-v-fsv-mainz-260425 and https://www.bundesliga.com/de/bundesliga/news/jonah-kusi-asare-fc-bayern-munchen-leihe-fc-fulham-33861 .\n')
    if marker not in text:readme.write_text(text+addition,encoding='utf8')
    failure=ROOT_OUT/'simulation_results/failed_runs.json';failures=json.loads(failure.read_bytes()) if failure.exists() else []
    if not any(x.get('experiment')==LABEL and x.get('stage')=='source_cache_serialization' for x in failures):
        failures.append(dict(at_utc=stamp(),experiment=LABEL,stage='source_cache_serialization',error='ArrowInvalid: mixed boolean/float started source field',
            resolved=True,resolution='Use internal exact-type Python source cache; final published audit and forecasts retain normalized Parquet. No raw value coercion. Completed replacement verified.'))
        dump(failure,failures)
    catalog()
    if WORK.exists():discard_work(WORK)
    cleanup();verification=validate()
    path=ROOT_OUT/'retention/retained_artifacts.json';manifest=json.loads(path.read_bytes())
    manifest['scripts']={p.name:file_sha256(p) for p in sorted(code.glob('*.py'))}
    manifest.update(retained_scripts=len(manifest['scripts']),final_tables=93,current_sql_columns=2283,updated_utc=stamp())
    manifest['latest_simulation_update']=dict(at_utc=stamp(),reports=[LABEL,LABEL+'/source_scope'],datasets_unchanged=True,
        protected_app_files_verified=verification['protected_app_files'],app_health=verification['app_health'])
    dump(path,manifest)
    path=ROOT_OUT/'research_continuation.json';state=json.loads(path.read_bytes())
    state.update(current_job=None,running_jobs=[],live_sessions=[],next_action='Inspect sparse European cup club/opponent history and dated qualification/rotation evidence; latest physical-profile repair fixed an example but failed later performance. Preserve NHL fixed20agreement comparator. Reuse750existingUEFAplayer reports; do not blindly recollect.',
        report=str(report),final_sql_tables=93,final_sql_columns=2283,
        previous_goal_turn=dict(progress='Concrete raw-verified loss cause, two controlled model revisions, risk tests and NHL cohort audit; not blocked.',
            oos='Monthly chronological predictions; repeated2026research retrospective. No target attainment or app adoption.'))
    research=state.setdefault('research_state',{})
    research['previous_goal_turn_classification']='progress: completed source replay, controlled model and risk comparisons, with final evidence and cleaned temporary work.'
    if 'soccer_clock_recovery' in research:
        research['soccer_clock_recovery'].pop('live_session',None);research['soccer_clock_recovery']['next']='Completed; receipts and results retained.'
    research['loss_case_revision']=dict(status='complete',report=str(report),new_source_error='Observed-only denominator overweights sparse transferred-player measurements',
        candidate2026pm_sharpe=1.1703,candidate2026pm_return_pct=58.811,adopted=False,target_achieved=False)
    research['no_running_jobs']=True;dump(path,state)
    dump(ROOT_OUT/'retention/loss_case_completion.json',dict(status='PASS',at_utc=stamp(),report=str(report),
        result_hashes={str(p.relative_to(RESULT)):file_sha256(p) for p in RESULT.rglob('*') if p.is_file()},
        new_collection_requests=0,temporary_work_removed=not WORK.exists(),app_validation=verification))
    print(json.dumps(dict(status='PASS',report=str(report),target_achieved=False,temporary_work_removed=not WORK.exists())),flush=True)


if __name__=='__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf8')
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['sources','trace','build','train','evidence','risk','scope','finish']);args=parser.parse_args()
    globals()[args.stage]()
