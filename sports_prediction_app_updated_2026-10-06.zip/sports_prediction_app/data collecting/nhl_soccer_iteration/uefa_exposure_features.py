"""Merge UEFA dated appearances without erasing complete earlier measurements."""
import hashlib,json
import pandas as pd
from common import ROOT_OUT,OUT,read_db,dump,stamp


def merge_exposure(players):
    with read_db(ROOT_OUT/'uefa_exposure.sqlite') as c:bodies=[json.loads(b) for b, in c.execute('SELECT body FROM games')]
    assert all(b.get('parser_version')==2 for b in bodies),'Reparse all cached UEFA responses with current clock convention before use'
    index=['game_id','side','official_player_id'];fields=['game_id','side','official_player_id','official_game_id','team_id','league','date','player_name','available_at_utc','started','played','minutes','minutes_basis','position','goals','own_goals']
    raw=[p for b in bodies for p in b['players']];fresh=pd.DataFrame([{k:r.get(k) for k in fields} for r in raw])
    fresh.official_player_id=fresh.official_player_id.astype(str);players=players.copy();players.official_player_id=players.official_player_id.astype(str)
    cross=players[['league','official_player_id','player_id']].drop_duplicates()
    assert cross.groupby(['league','official_player_id']).player_id.nunique().max()==1
    cross=cross.set_index(['league','official_player_id']).player_id.to_dict()
    fresh['player_id']=[cross.get((r.league,r.official_player_id),'EU_UCL:'+r.official_player_id) for r in fresh.itertuples()]
    prior=players.set_index(index);new=fresh.set_index(index);assert not prior.index.duplicated().any() and not new.index.duplicated().any()
    joined=new.combine_first(prior)
    # Preserve verified detailed playing-time/stat definitions already present;
    # complete native event participation corrects an old null-minute=False.
    for col in ['minutes','minutes_basis','position','player_type']:
        if col in prior:
            known=prior[col].dropna();joined.loc[known.index,col]=known
    overlap=prior.index.intersection(new.index);conflicts=[]
    for col in ['played','started','goals']:
        differing=prior.loc[overlap,col].notna()&new.loc[overlap,col].notna()&prior.loc[overlap,col].ne(new.loc[overlap,col])
        for key in overlap[differing]:
            conflicts.append(dict(game_id=key[0],side=key[1],official_player_id=key[2],field=col,prior=str(prior.loc[key,col]),new=str(new.loc[key,col])))
    result=joined.reset_index();assert not result.duplicated(['game_id','side','player_id']).any()
    audit=dict(at_utc=stamp(),source_games=len(bodies),source_rows=len(fresh),added_rows=len(result)-len(players),
        added_known_minutes=int(joined.minutes.notna().sum()-prior.minutes.notna().sum()),conflicts=conflicts,
        source_sha256=hashlib.sha256((ROOT_OUT/'uefa_exposure.sqlite').read_bytes()).hexdigest(),
        policy='Exact league/native-ID join. Retain known original minutes and position. Fill omitted minutes from verified regulation events. Complete event participation takes priority over prior null-minute inference. Unreconciled goals stay null and never overwrite a known value.')
    dump(OUT/'uefa_exposure_merge_audit.json',audit)
    return result,audit
