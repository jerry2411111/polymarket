"""Causal pooled-club, opponent, shot-quality and observed-player features."""
import argparse
import collections
import json
import math
import sqlite3
import numpy as np
import pandas as pd
from common import PROJECT,PREVIOUS,OUT,ROOT_OUT,read_db,dump

LEAGUE_CODE={'Premier League':'PL','La Liga':'LAL','Bundesliga':'BUN','Serie A':'SEA','Ligue 1':'FL1','UEFA Champions League':'UCL'}

def finite(v):
    try:return float(v) if v is not None and math.isfinite(float(v)) else np.nan
    except (ValueError,TypeError):return np.nan

def sources(sport, include_preseason=False):
    with read_db(PREVIOUS/'expanded.sqlite') as c:
        games=pd.read_sql_query(f'SELECT * FROM {sport}_games',c)
        obs=pd.read_sql_query(f'SELECT * FROM {sport}_team_observations',c)
        players=pd.read_sql_query(f'SELECT * FROM {sport}_player_games',c)
    if sport=='nhl':games=games[games.phase.isin(['Regular Season','Playoffs']+(['Preseason'] if include_preseason else []))].copy()
    games=games[games.date.ge('2021-01-01')&games.date.le('2026-09-30')].copy()
    for col in ['prediction_time','available_time','start_time']:games[col]=pd.to_datetime(games[col],utc=True,format='mixed')
    registry={}
    if sport=='soccer':
        with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as c:
            for code,native,body in c.execute('SELECT * FROM _eu_team_identity'):registry[(code,str(native))]=json.loads(body)['team_id']
    keyed={};matches=0
    for g in games.to_dict('records'):
        for side,native in zip(['A','B'],json.loads(g['native_team_ids_json'])):
            raw=(LEAGUE_CODE.get(g['league']),str(native));key=registry.get(raw)
            if key:matches+=1
            keyed[(g['game_id'],side)]=key or ('NHL:'+str(native) if sport=='nhl' else g['league']+':'+str(native))
    obs=obs[obs.game_id.isin(games.game_id)].copy()
    obs['team_key']=[keyed[(r.game_id,r.side)] for r in obs.itertuples()]
    if sport=='nhl':
        with read_db(ROOT_OUT/'granular.sqlite') as c:q=pd.read_sql_query('SELECT * FROM nhl_team_shot_quality',c)
        obs=obs.merge(q,on=['game_id','side'],how='left',validate='one_to_one')
        stats=['score_for','score_against','shots_for','shots_against','sat_fraction_5v5','usat_fraction_5v5','xg','xg_against','xg_even_strength','xg_even_strength_against','model_goals_saved','finishing_residual','pp_goals','pp_opportunities','pp_goals_against','times_shorthanded','faceoff_win_fraction','player_goalie_save_fraction']
        metrics=['goals','assists','shots_on_target','blocked_shots','hits','takeaways','giveaways']
    else:
        obs['quality_xg']=obs.expected_goals.combine_first(obs.xg)
        against=obs[['game_id','side','quality_xg','expected_goals_on_target','shots_on_target','big_chances','possession_pct']].copy();against.side=against.side.map({'A':'B','B':'A'});against=against.rename(columns={c:c+'_against' for c in against if c not in ['game_id','side']})
        obs=obs.merge(against,on=['game_id','side'],how='left',validate='one_to_one')
        obs['finishing_residual']=obs.score_for-obs.quality_xg
        obs['keeper_goals_saved']=obs.keeper_xgot_conceded-obs.score_against
        stats=['score_for','score_against','quality_xg','quality_xg_against','expected_goals_on_target','expected_goals_on_target_against','shots','shots_on_target','shots_on_target_against','big_chances','big_chances_against','possession_pct','pass_accuracy_pct','box_shots','box_entries','touches_opponent_box','recoveries_attacking_third','errors_to_shot','errors_to_goal','finishing_residual','keeper_goals_saved','roster_continuity']
        metrics=['goals','assists','shots_on_target','key_passes','xg','xa','recoveries','interceptions','passes_completed']
        # Add available official PL per-match records, preserving sparse statistics.
        if (ROOT_OUT/'player_detail.sqlite').exists():
            with read_db(ROOT_OUT/'player_detail.sqlite') as c:new=pd.DataFrame([json.loads(r[0]) for r in c.execute('SELECT body FROM player_match_detail')])
            if not new.empty:
                cross=players[players.league.eq('Premier League')][['official_player_id','player_id']].drop_duplicates()
                counts=cross.groupby('official_player_id').player_id.nunique();valid=cross[cross.official_player_id.isin(counts[counts==1].index)].set_index('official_player_id').player_id.to_dict()
                new['official_player_id']=new.player_id.astype(str);new['player_id']=new.official_player_id.map(valid).fillna('EU_PL:'+new.official_player_id)
                new['player_type']=None;new['played']=pd.to_numeric(new.minutes,errors='coerce').gt(0)
                # Prefer an explicit newly retrieved field; retain old values when
                # the fresh sparse API object omits a statistic.
                shared=['game_id','side','official_player_id'];a=players.set_index(shared);b=new.set_index(shared)
                assert not a.index.duplicated().any() and not b.index.duplicated().any()
                players=b.combine_first(a).reset_index()
    players=players[players.game_id.isin(games.game_id)].copy()
    assert not players.duplicated(['game_id','player_id','side']).any()
    return games,obs,players,keyed,stats,metrics,dict(canonical_team_sides=matches,total_team_sides=2*len(games))

def build(sport,games,observations,players,keyed,stats,metrics):
    observations=observations.copy();observations['available_time']=pd.to_datetime(observations.available_time,utc=True,format='mixed');observations['start_time']=pd.to_datetime(observations.start_time,utc=True,format='mixed')
    lookup={(r['game_id'],r['side']):r for r in observations.to_dict('records')}
    player_rows=collections.defaultdict(list)
    for r in players.to_dict('records'):player_rows[(r['game_id'],r['side'])].append(r)
    events=games.sort_values(['available_time','game_id']).to_dict('records');pos=0
    history=collections.defaultdict(lambda:collections.deque(maxlen=60));p_history=collections.defaultdict(lambda:collections.deque(maxlen=30));last_team={}
    ratings=collections.defaultdict(lambda:1500.);world_saves=0.;world_shots=0.;outputs=[];audit=[]
    def ewm(rows,field):
        pairs=[(.94**i,finite(r.get(field))) for i,r in enumerate(reversed(rows))]
        pairs=[(w,v) for w,v in pairs if np.isfinite(v)]
        return sum(w*v for w,v in pairs)/sum(w for w,v in pairs) if pairs else np.nan
    def average(x):
        x=[z for z in x if np.isfinite(z)];return float(np.mean(x)) if x else np.nan
    for g in games.sort_values(['prediction_time','game_id']).to_dict('records'):
        cut=g['prediction_time']
        while pos<len(events) and events[pos]['available_time']<cut:
            past=events[pos];pos+=1;a,b=keyed[(past['game_id'],'A')],keyed[(past['game_id'],'B')]
            expected=1/(1+10**((ratings[b]+60-ratings[a])/400));winner=.5 if past['scoreA']==past['scoreB'] else float(past['scoreA']>past['scoreB']);change=20*(winner-expected)
            opponent_prior={team:(ewm(list(history[team]),'score_against'),ewm(list(history[team]),'score_for')) for team in [a,b]}
            for side,team,opponent in [('A',a,b),('B',b,a)]:
                row=dict(lookup[(past['game_id'],side)]);row['opponent_elo']=ratings[opponent]
                row['venue']=side;row['margin']=row['score_for']-row['score_against']
                olddef,oldatt=opponent_prior[opponent]
                row['attack_above_opponent']=row['score_for']-olddef;row['defence_below_opponent']=oldatt-row['score_against']
                observed_players=[]
                for p in player_rows[(past['game_id'],side)]:
                    pid=p['player_id'];minutes=finite(p.get('minutes'))
                    available=pd.Timestamp(p['available_at_utc'])
                    assert available<=past['available_time']
                    # Player statistics are entered only after their game's release.
                    if np.isfinite(minutes) and minutes>0:
                        p=dict(p,team_key=team,available_time=past['available_time']);p_history[pid].append(p);last_team[pid]=team;observed_players.append((pid,minutes))
                        saves,shots=finite(p.get('saves')),finite(p.get('shots_against'))
                        if np.isfinite(saves) and np.isfinite(shots):world_saves+=saves;world_shots+=shots
                row['observed_players']=observed_players;history[team].append(row)
            ratings[a]+=change;ratings[b]-=change
        sides={};latest=[]
        for side in ['A','B']:
            key=keyed[(g['game_id'],side)];h=list(history[key]);features={};last=h[-1] if h else None
            features['elo']=ratings[key];features['history']=len(h)
            features['rest_days']=min(120,(g['start_time']-last['start_time']).total_seconds()/86400) if last else np.nan
            features['games_7d']=sum((g['start_time']-r['start_time']).total_seconds()<7*86400 for r in h)
            for field in stats+['margin','opponent_elo','attack_above_opponent','defence_below_opponent']:
                features[field]=ewm(h,field)
            venue=[r for r in h if r['venue']==side][-15:]
            for field in ['score_for','score_against','margin']:features['venue_'+field]=average([finite(r[field]) for r in venue])
            weights=collections.defaultdict(float)
            for r in h[-5:]:
                for pid,mins in r['observed_players']:
                    if last_team.get(pid)==key:weights[pid]+=mins
            features['roster_players']=len(weights)
            for pid in weights:
                latest.extend(p['available_time'] for p in p_history[pid])
            for field in metrics:
                rates=[]
                for pid,w in weights.items():
                    obs=[(finite(p.get(field)),finite(p.get('minutes'))) for p in p_history[pid]]
                    obs=[(v,m) for v,m in obs if np.isfinite(v) and np.isfinite(m) and m>0]
                    if obs:rates.append((w,(60 if sport=='nhl' else 90)*sum(v for v,m in obs)/sum(m for v,m in obs)))
                features['roster_'+field+'_rate']=sum(w*v for w,v in rates)/sum(w for w,v in rates) if rates else np.nan
            if sport=='nhl':
                goalie_rates=[];goalie_shares=[]
                for pid,w in weights.items():
                    obs=[(finite(p.get('saves')),finite(p.get('shots_against'))) for p in p_history[pid]]
                    obs=[(s,n) for s,n in obs if np.isfinite(s) and np.isfinite(n) and n>0]
                    if obs and world_shots>0:
                        goalie_rates.append((w,(sum(s for s,n in obs)+100*world_saves/world_shots)/(sum(n for s,n in obs)+100)))
                        goalie_shares.append(w)
                features['roster_goalie_save_fraction']=sum(w*v for w,v in goalie_rates)/sum(w for w,v in goalie_rates) if goalie_rates else np.nan
                features['goalie_workload_concentration']=sum((w/sum(goalie_shares))**2 for w in goalie_shares) if goalie_shares else np.nan
            if last:latest.append(max(r['available_time'] for r in h))
            sides[side]=features
        r={k:g[k] for k in ['game_id','official_game_id','sport','league','date','target','prediction_time','available_time','start_time','phase','scoreA','scoreB']}
        for k in sides['A']:
            r['f_'+k+'_diff']=sides['B'][k]-sides['A'][k]
            if k not in ['elo','history','roster_players']:r['f_'+k+'_sum']=sides['B'][k]+sides['A'][k]
        r['f_home_elo']=sides['B']['elo'];r['f_away_elo']=sides['A']['elo']
        r['f_home_attack']=sides['B']['score_for'];r['f_away_attack']=sides['A']['score_for']
        r['f_home_defence']=sides['B']['score_against'];r['f_away_defence']=sides['A']['score_against']
        r['f_playoffs']=float('playoff' in str(g['phase']).lower())
        r['source_max_available_utc']=max(latest) if latest else None
        assert not latest or max(latest)<cut
        audit.append(dict(game_id=g['game_id'],cutoff=cut.isoformat(),max_source=r['source_max_available_utc']))
        outputs.append(r)
    return pd.DataFrame(outputs),audit

def main(sport):
    g,o,p,keys,stats,metrics,identity=sources(sport)
    frame,audits=build(sport,g,o,p,keys,stats,metrics)
    frame.to_parquet(OUT/(sport+'_features.parquet'),index=False)
    with sqlite3.connect(OUT/'granular.sqlite') as db:
        frame.assign(prediction_time=frame.prediction_time.astype(str),available_time=frame.available_time.astype(str),start_time=frame.start_time.astype(str),source_max_available_utc=frame.source_max_available_utc.astype(str)).to_sql(sport+'_model_features',db,if_exists='replace',index=False)
    fields=[c for c in frame if c.startswith('f_')]
    summary=dict(sport=sport,games=len(frame),features=len(fields),columns=fields,identity=identity,source_player_rows=len(p),first_date=frame.date.min(),last_date=frame.date.max(),future_input_violations=0,checked_forecasts=len(audits),missing_pct={c:100*frame[c].isna().mean() for c in fields})
    dump(OUT/(sport+'_feature_audit.json'),summary)
    print(json.dumps({k:v for k,v in summary.items() if k not in ['columns','missing_pct']}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--sport',choices=['soccer','nhl'],required=True);args=parser.parse_args();main(args.sport)
