"""Refresh the catalog of the retained final SQL dataset without old experiments."""
import json
import sqlite3
import pandas as pd
from common import ROOT_OUT,REPORTS,dump,stamp


def main():
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        tables=pd.read_sql_query('SELECT * FROM table_catalog',db)
        columns=pd.read_sql_query('SELECT * FROM column_catalog',db)
        missing=pd.read_sql_query('SELECT * FROM missing_report',db)
        live={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        tables=tables[tables['table'].isin(live)].copy()
        columns=columns[columns['table'].isin(set(tables['table']))].copy()
        missing=missing[missing['table'].isin(set(tables['table']))].copy()
        for record in tables.to_dict('records'):
            name=record['table'];assert name.replace('_','').isalnum()
            actual=db.execute('SELECT COUNT(*) FROM "'+name+'"').fetchone()[0]
            assert actual==record['rows'], 'Republish changed table statistics before catalog: '+name
    tables.to_csv(REPORTS/'table_catalog.csv',index=False)
    columns.to_csv(REPORTS/'column_catalog.csv',index=False)
    missing.to_csv(REPORTS/'missing_report.csv',index=False)
    publication=json.loads((ROOT_OUT/'publication.json').read_text())
    publication.update(published_at_utc=stamp(),tables=tables.to_dict('records'))
    dump(ROOT_OUT/'publication.json',publication)
    lines=['# Sports research data catalog','',
        'The SQL dataset contains the collected NHL and soccer match, player, team, source-evidence and retained model input tables listed below. Tables link by game_id and the documented native player/team identifiers. Date and availability fields control historical queries.','',
        'The final NHL and soccer model packages and consolidated rolling forecasts are in retained_models. Provider-separated simulation results are in simulation_results. Original official responses remain linked from the final facts.','',
        '| Table | Rows | Columns |','|---|---:|---:|']
    for r in tables.to_dict('records'):lines.append(f"| {r['table']} | {r['rows']} | {r['columns']} |")
    for name in tables['table']:
        lines.extend(['',f'## {name}','','| Column | Meaning | Unit | Source |','|---|---|---|---|'])
        def clean(x):return str(x).replace('|','/').replace('\n',' ')
        for r in columns[columns['table'].eq(name)].to_dict('records'):
            lines.append('| '+' | '.join(clean(r[k]) for k in ['column','meaning','unit','source'])+' |')
    lines.extend(['','## Missing values','','| Table | Column | Missing | Rows | Missing percent |','|---|---|---:|---:|---:|'])
    for r in missing.to_dict('records'):
        pct=f"{r['missing_pct']:.6f}%" if pd.notna(r['missing_pct']) else 'N/A'
        lines.append(f"| {r['table']} | {r['column']} | {r['missing']} | {r['rows']} | {pct} |")
    (REPORTS/'catalog.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    print(json.dumps(dict(tables=len(tables),columns=len(columns),at_utc=stamp())),flush=True)

if __name__=='__main__':main()
