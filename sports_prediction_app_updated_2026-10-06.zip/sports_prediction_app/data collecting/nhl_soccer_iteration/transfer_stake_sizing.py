"""Transfer the NBA-selected fixed-dollar rule to the best audited NHL/soccer forecasts.

The$5amount is selected in NBA2025, not tuned on NHL/soccer results. Compare a
single price-margin filter and fixed quarter-Kelly as explicit research controls.
"""
import argparse
import json
import pickle
import shutil
import numpy as np
import pandas as pd
import models
from common import ROOT_OUT, PREVIOUS, dump, stamp, file_sha256, read_db
from final_pipeline import cleanup, discard_work
from backtest import quote_inputs, attach, select
import test_confidence_dollars as engine

RESULT=ROOT_OUT/'simulation_results/transferred_account_staking'


def evaluation_forecasts(sport, selection):
    source=ROOT_OUT/selection['source']
    path=source.with_name('evaluation_predictions.parquet')
    if path.exists():return pd.read_parquet(path)
    assert sport=='soccer' and 'soccer_pooled_scale' in str(source)
    saved=RESULT/'soccer_evaluation_predictions.parquet'
    if saved.exists():
        proof=json.loads((RESULT/'soccer_evaluation_validation.json').read_bytes())
        assert proof['status']=='PASS' and proof['prediction_sha256']==file_sha256(saved)
        return pd.read_parquet(saved)
    work=ROOT_OUT/'_work/soccer_staking_evaluation'
    assert not work.exists(),'Inspect unfinished fitting work before restarting'
    work.mkdir(parents=True)
    try:
        recipe=json.loads((source.parent/'experiment_plan.json').read_bytes())
        original=ROOT_OUT/'retained_models/soccer/soccer_features.parquet'
        assert file_sha256(original)==recipe['feature_sha256']
        shutil.copy2(original,work/'soccer_features.parquet')
        name='soccer_pooled_scale_staking'
        models.CANDIDATES[name]=recipe['recipe'];models.OUT=work
        dump(work/'soccer_selection.json',dict(selected_candidates=[name],
            authority='User requests best predictive model followed by betting tests; staking_model_selection/selection.json chooses on2024/25probability scores, not account returns.',
            prior_combined_gate='Earlier failed decision remains unchanged; no app adoption.'))
        p=models.run('soccer','evaluation',[name]);p['variant']='candidate'
        assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
        package=pickle.loads((work/'model_runs/soccer/evaluation'/(name+'.pkl')).read_bytes())
        frame=pd.read_parquet(original);frame=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
        sample=p[p.fold.eq(package['boundary'].strftime('%Y-%m'))].head(25)
        x=frame.loc[sample.game_id,package['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
        actual=models.apply_calibration(package['model'].predict_proba(x),package['calibrator'])
        assert np.allclose(actual,sample[['p0','p1','p2']],atol=1e-12,rtol=0)
        p.to_parquet(saved,index=False)
        dump(RESULT/'soccer_evaluation_validation.json',dict(at_utc=stamp(),status='PASS',forecasts=len(p),
            prediction_sha256=file_sha256(saved),feature_sha256=file_sha256(original),replayed_forecasts=len(sample),
            prediction_cutoffs_verified=True,adopted=False,temporary_fits_removed_after_validation=True))
        return p
    finally:
        if work.exists():discard_work(work)
        cleanup()


def get_forecasts(sport,selection):
    path=ROOT_OUT/selection['source'];assert file_sha256(path)==selection['source_sha256']
    raw=pd.concat([pd.read_parquet(path),evaluation_forecasts(sport,selection)],ignore_index=True)
    raw=raw[raw.variant.eq(selection['variant'])].copy()
    if selection['component']=='secondary':raw[['p0','p1']]=raw[['second_p0','second_p1']].to_numpy()
    elif selection['component']=='mean':raw[['p0','p1']]=(raw[['p0','p1']].to_numpy()+raw[['second_p0','second_p1']].to_numpy())/2
    assert not raw.game_id.duplicated().any()
    assert raw.train_label_max.lt(raw.prediction_time).all()
    assert raw.calibration_label_max.lt(raw.prediction_time).all()
    return raw


def normalize(sport,p,quotes,pick_growth=False):
    linked,audit=attach(p,quotes)
    dump(RESULT/(sport+'_quote_matching.json'),audit)
    if pick_growth:
        winners=linked[linked.usable_price&linked.entry_age_hours.le(24)].copy()
        winners['probability']=[r['p'+str(int(r['quote_class']))] for r in winners.to_dict('records')]
        q=winners.entry_price.to_numpy();probability=winners.probability.to_numpy()
        fraction=.25*np.maximum(0.,(probability-q)/(1-q))
        winners['expected_log_growth']=probability*np.log1p(fraction*(1/q-1))+(1-probability)*np.log1p(-fraction)
        winners=winners[winners.expected_log_growth.gt(0)].sort_values(
            ['provider','game_id','expected_log_growth','quote_class'],ascending=[True,True,False,True]).drop_duplicates(['provider','game_id'])
    else:winners=pd.concat([select(g,'winner') for _,g in linked.groupby('provider')],ignore_index=True)
    # Highest probability is computed over ALL classes before quote filtering;
    # a missing draw quote cannot silently change the predicted outcome.
    k=3 if sport=='soccer' else 2
    if not pick_growth:assert winners.quote_class.eq(winners[['p'+str(i) for i in range(k)]].to_numpy().argmax(axis=1)).all()
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        names=pd.read_sql_query('SELECT game_id,teamA,teamB FROM '+sport+'_games',db).set_index('game_id')
    out=pd.DataFrame(dict(sport=sport,provider=winners.provider.to_numpy(),game_id=winners.game_id.to_numpy(),
        date=winners.date.to_numpy(),start=winners.start_time.to_numpy(),entry=winners.prediction_time.to_numpy(),exit=winners.available_time.to_numpy(),
        p0=winners.p0.to_numpy(),p1=winners.p1.to_numpy(),target=winners.target.to_numpy(int),side=winners.quote_class.to_numpy(int),
        probability=winners.probability.to_numpy(),price=winners.entry_price.to_numpy(),source_utc=winners.entry_source_utc.to_numpy(),
        available_utc=winners.entry_available_utc.to_numpy(),quote_age_hours=winners.entry_age_hours.to_numpy(),
        price_basis=winners.price_basis.to_numpy(),model_stage='pre12',fit_id=winners.fold.to_numpy()))
    if sport=='soccer':out['p2']=winners.p2.to_numpy()
    if pick_growth:out['expected_log_growth']=winners.expected_log_growth.to_numpy()
    for field in ['entry_request_id','entry_pointer','entry_contract_id']:
        if field in winners:out[field]=winners[field].to_numpy()
    for name in ['teamA','teamB']:out[name]=out.game_id.map(names[name])
    for field in ['start','entry','exit','source_utc','available_utc']:out[field]=engine.dates(out[field])
    out['won']=out.side.eq(out.target);out['edge']=out.probability-out.price;out['year']=out.entry.dt.year
    assert out.source_utc.le(out.entry).all() and out.available_utc.le(out.entry).all()
    assert out.entry.lt(out.start).all() and out.start.lt(out.exit).all()
    assert not out.duplicated(['provider','game_id']).any()
    return out


def main():
    assert not (RESULT/'validation.json').exists(),'Preserve completed transfer test'
    RESULT.mkdir(exist_ok=True)
    selection=json.loads((ROOT_OUT/'simulation_results/staking_model_selection/selection.json').read_bytes())
    earlier=json.loads((ROOT_OUT/'simulation_results/starting_account_staking/frozen_choices.json').read_bytes())
    gate=json.loads((ROOT_OUT/'simulation_results/starting_account_staking/validation.json').read_bytes())
    assert gate['status']=='PASS' and gate['transfer_nba_rule_to_other_sports']
    choice=next(r for r in earlier['choices'] if r['sport']=='nba' and r['selection']=='winner_above51')
    amount=choice['dollars_per_point'];assert amount==5 and choice['initial_cash']==2000
    plan=dict(at_utc=stamp(),steps='NBA/MLB completed first; transfer successful NBA sizing without retuning amount on NHL/soccer.',
        initial_cash=2000,dollars_per_percentage_point=amount,threshold_probability=.51,
        formula='fixed dollar stake=5*max(100*p-51,0); p is probability of highest-probability outcome across all actual classes. Dollars do not grow with account equity.',
        selection_source='starting_account_staking/frozen_choices.json: NBA2025',
        model_selection_source='staking_model_selection/selection.json',models=selection['selections'],
        variants=['Same p>51opportunities with1%equity/20%open-cost cap','Transferred fixed dollars, cash-only','Transferred fixed dollars with20%open-cost cap','Transferred fixed dollars plus p-price>=.05','Fixed quarter-Kelly with20%open-cost cap'],
        periods='2024/25 descriptive development;2026 throughSeptember29 repeatedly inspected retrospective evaluation.',
        pricing='Both providers separately;pre12 closest prior price<=24hoursold;Polymarket token historicalprice and KalshiYESaskclose retain their source meaning.',
        probabilities='Soccer remains three-way home/away/draw. No renormalization to two teams; draws correctly lose a bought team-win contract.',
        extra_fit='Selected soccer model lacked2026forecasts under its older combined return gate. Refit exact same selected recipe with2021+monthly expanding history and prior purged calibration under the new forecast-only selection; preserve old decision.',
        no_threshold_tuning=True,app_changed=False)
    dump(RESULT/'plan.json',plan)
    quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62')
    rows=[];bets=[];days=[];checks=[];metrics=[];coverage=[]
    for sport in ['nhl','soccer']:
        p=get_forecasts(sport,selection['selections'][sport])
        metrics.append(models.metrics(p).assign(selected_model=selection['selections'][sport]['model']))
        f=normalize(sport,p,quotes)
        for provider,g in f.groupby('provider'):
            for year in [2024,2025,2026]:
                total=int(p.prediction_time.dt.year.eq(year).sum());matched=int(g.year.eq(year).sum())
                coverage.append(dict(sport=sport,provider=provider,year=year,forecast_games=total,quoted_winner_games=matched,
                    missing_quote_pct=100*(1-matched/total),above51_quoted_games=int((g.year.eq(year)&g.probability.gt(.51)).sum())))
                for entry,sizing in [('winner_above51','fixed1pct_cap20'),('winner_above51','dollars_cash_only'),
                    ('winner_above51','dollars_cap20'),('winner_edge5_above51','dollars_cash_only'),('winner_above51','quarter_kelly_cap20')]:
                    summary,b,l,d=engine.simulate(g,year,entry,sizing,amount,2000.)
                    key=dict(sport=sport,provider=provider,selection=entry,sizing=sizing,year=year)
                    checks.append(key|engine.validate(b,l,d,sizing,amount,2000.));rows.append(key|summary)
                    if len(b):bets.append(b.assign(**key))
                    days.append(d.assign(**key))
            print(json.dumps(dict(stage='transferred_staking',sport=sport,provider=provider,finished=True)),flush=True)
    annual=pd.DataFrame(rows);annual.to_csv(RESULT/'annual.csv',index=False)
    pd.concat(metrics,ignore_index=True).to_csv(RESULT/'model_metrics.csv',index=False)
    pd.DataFrame(coverage).to_csv(RESULT/'coverage.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/'bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'daily.parquet',index=False)
    proof=dict(at_utc=stamp(),status='PASS',checks=checks,forecasts_selected_without_returns=True,
        transferred_amount_not_tuned=True,initial_cash=2000,prices_timestamp_aligned=True,
        source_providers_separate=True,app_changed=False,adopted=False)
    dump(RESULT/'validation.json',proof)
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=RESULT.name+'/annual.csv'
    pd.concat([old[~old.source_result_file.eq(key)],annual.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[RESULT.name]=dict(plan=plan,decision={k:v for k,v in proof.items() if k!='checks'});dump(path,old)
    cleanup()
    print(annual[annual.year.eq(2026)][['sport','provider','selection','sizing','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


def paper_test():
    global RESULT
    RESULT=ROOT_OUT/'simulation_results/probability_price_staking'
    assert not (RESULT/'validation.json').exists(),'Preserve completed test'
    RESULT.mkdir(exist_ok=True)
    selection=json.loads((ROOT_OUT/'simulation_results/staking_model_selection/selection.json').read_bytes())
    plan=dict(at_utc=stamp(),model_selection=selection['selections'],initial_cash=2000,
        hypothesis='Winner accuracy and p>51can discard underpriced underdogs/draws while buying overpriced favourites. Use calibrated outcome probability together with actual quote price.',
        outcome_choice='For each game, among all quoted actual outcomes choose highest positive expected log growth at one-quarter binary Kelly. At most one purchased outcome per game; no forced home/away restriction or soccer renormalization.',
        formula='f=.25*max((p-q)/(1-q),0); utility=p*log(1+f*(1/q-1))+(1-p)*log(1-f). All p and q observed before entry.',
        sizing=['1%equity with20%open-cost cap','quarter-Kelly with20%open-cost cap','fixed$5for each probability point p exceeds price, available-cash limit'],
        choices='Each provider/sport chooses sizing by2025Sharpe among positive-return cases; save choice before computing2026accounts. Also show all candidates, without choosing on2026.',
        source_paper='https://web.stanford.edu/~boyd/papers/pdf/kelly.pdf',
        limitations='Kelly probabilities are estimated. This per-game approximation with overlapping positions is not a full joint portfolio optimizer or a guarantee of drawdown control. Historical prices do not establish executable fills.',
        costs=0,no_new_fit=True,no_parameter_grid=True,app_changed=False)
    dump(RESULT/'plan.json',plan)
    quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62')
    data={}
    for sport in ['nhl','soccer']:
        # Reuse the verified new soccer evaluation from the transfer test.
        source=ROOT_OUT/'simulation_results/transferred_account_staking'
        old_result=RESULT
        try:
            RESULT=source;p=get_forecasts(sport,selection['selections'][sport])
        finally:RESULT=old_result
        data[sport]=normalize(sport,p,quotes,pick_growth=True)
    records=[];bets=[];days=[];checks=[];chosen={}
    for year in [2025,2026]:
        for sport,f in data.items():
            for provider,g in f.groupby('provider'):
                for sizing in ['fixed1pct_cap20','quarter_kelly_cap20','edge_dollars_cash_only']:
                    m,b,l,d=engine.simulate(g,year,'all_selected_outcomes',sizing,5.,2000.)
                    key=dict(sport=sport,provider=provider,year=year,selection='max_expected_log_growth',sizing=sizing)
                    checks.append(key|engine.validate(b,l,d,sizing,5.,2000.));records.append(key|m)
                    if len(b):bets.append(b.assign(**key))
                    days.append(d.assign(**key))
        if year==2025:
            earlier=pd.DataFrame(records)
            for (sport,provider),g in earlier.groupby(['sport','provider']):
                good=g[g.return_pct.gt(0)].sort_values(['sharpe','max_drawdown_pct','sizing'],ascending=[False,True,True])
                best=good.iloc[0] if len(good) else None
                chosen[sport+'/'+provider]=dict(sizing=str(best.sizing) if best is not None else None,
                    selection_year=2025,selection_sharpe=float(best.sharpe) if best is not None else None,
                    selection_return_pct=float(best.return_pct) if best is not None else None)
            dump(RESULT/'frozen_choices.json',dict(at_utc=stamp(),choices=chosen,no_2026_selection=True))
    a=pd.DataFrame(records)
    a['selected_on2025']=[r.sizing==chosen[r.sport+'/'+r.provider]['sizing'] for r in a.itertuples()]
    a.to_csv(RESULT/'annual.csv',index=False)
    b=pd.concat(bets,ignore_index=True);b.to_parquet(RESULT/'bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'daily.parquet',index=False)
    groups=b.groupby(['sport','provider','year','sizing','side']).agg(bets=('game_id','size'),probability=('probability','mean'),price=('price','mean'),win_rate=('won','mean')).reset_index()
    groups.to_csv(RESULT/'outcome_diagnosis.csv',index=False)
    proof=dict(at_utc=stamp(),status='PASS',checks=checks,one_outcome_per_game=True,actual_outcome_classes_preserved=True,
        providers_separate=True,selected_before2026accounts=True,no_model_refit=True,app_changed=False,adopted=False)
    dump(RESULT/'validation.json',proof)
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=RESULT.name+'/annual.csv'
    pd.concat([old[~old.source_result_file.eq(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[RESULT.name]=dict(plan=plan,decision={k:v for k,v in proof.items() if k!='checks'});dump(path,old)
    cleanup();print(a[['sport','provider','year','sizing','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct','selected_on2025']].to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--paper',action='store_true');args=parser.parse_args()
    paper_test() if args.paper else main()
