"""Integrate separately validated official actual participants into a new snapshot."""
import hashlib,json,math
import pandas as pd
from common import ROOT_OUT,PROJECT,dump,stamp,read_db
from collect_players import FIELDS
from pl_sparse_statistics import ADDITIVE,original

def merge_players(players,out):
    validation=json.loads((ROOT_OUT/'pl_lineup_recovery_validation.json').read_bytes())
    assert validation['raw_to_normalized_validation']=='PASS' and validation['participation_validation']=='PASS'
    fresh=pd.read_parquet(ROOT_OUT/'pl_lineup_recovery_validated.parquet')
    proofs=pd.read_parquet(ROOT_OUT/'pl_lineup_recovery_proofs.parquet')
    source_hashes=set()
    for r in fresh.itertuples():
        raw=(PROJECT/r.source_raw_file).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==r.source_sha256
        source_hashes.add(r.source_sha256)
    fresh['official_player_id']=fresh.player_id.astype(str)
    cross=players[players.league.eq('Premier League')][['official_player_id','player_id']].drop_duplicates()
    assert cross.groupby('official_player_id').player_id.nunique().max()==1
    mapping=cross.set_index('official_player_id').player_id.to_dict()
    fresh['player_id']=fresh.official_player_id.map(mapping).fillna('EU_PL:'+fresh.official_player_id)
    zero=[];mismatches=[]
    for p in proofs.to_dict('records'):
        links=json.loads(p['source_links_json']);team_source=links['team']
        if 'raw_file' in team_source and not 'status' in team_source:
            raw=(PROJECT/team_source['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==team_source['sha256'];teams=json.loads(raw)
        else:teams,_=original(team_source)
        active=fresh.game_id.eq(p['game_id'])&fresh.side.eq(p['side'])&fresh.played
        x=fresh[active];assert len(x)==11+p['team_substitutions'] and x.started.sum()==11 and x.minutes.sum()==990
        tid=str(x.iloc[0].team_id);stats=next(t['stats'] for t in teams if str(t['teamId'])==tid)
        for field in ADDITIVE:
            known=x[field].dropna();total=stats.get(FIELDS[field])
            assert known.ge(0).all() and (known%1==0).all()
            if total is None or math.fsum(known)!=total:
                if total is not None:mismatches.append(dict(game_id=p['game_id'],side=p['side'],field=field,player_sum=math.fsum(known),team_total=total))
                continue
            for i in fresh.index[active&fresh[field].isna()]:
                fresh.loc[i,field]=0.
                zero.append(dict(game_id=p['game_id'],side=p['side'],official_player_id=fresh.loc[i,'official_player_id'],field=field,derived_value=0.,team_total=total,team_source_sha256=team_source['sha256']))
    index=['game_id','side','official_player_id'];old=players.set_index(index)
    fresh['minutes_basis']='Verified official actual participation and reported minutes'
    keep=[c for c in fresh if c in players.columns]
    new=fresh[keep].set_index(index);assert not new.index.duplicated().any()
    overlap=old.index.intersection(new.index)
    explicit=[]
    for field in [c for c in FIELDS if c in old and c not in ['minutes','started']]:
        a,b=old.loc[overlap,field],new.loc[overlap,field]
        for key in overlap[a.notna()&b.notna()&a.ne(b)]:
            explicit.append(dict(game_id=key[0],side=key[1],official_player_id=key[2],field=field,old_value=float(old.loc[key,field]),fresh_value=float(new.loc[key,field])))
    dump(out/'explicit_player_value_conflicts.json',explicit)
    # Reconcile the former parser against the original immutable response.
    # Do not infer that a newer value is correct merely from its retrieval date.
    resolutions=[]
    with read_db(PROJECT/'collected data/result/player_depth.sqlite') as db:
        for conflict in explicit:
            key=tuple(conflict[c] for c in index);field=conflict['field'];prior=old.loc[key]
            evidence=json.loads(prior['field_evidence_json'] or '{}')
            if field=='yellow_cards':
                assert evidence[field]['pointer']=='/stats/totalYelCard'
                rid=evidence[field]['request_id']
            else:
                assert field=='assists' and field not in evidence
                endpoint='https://sdp-prem-prod.premier-league-prod.pulselive.com/api/v1/matches/'+str(prior.official_game_id)+'/players/'+key[2]+'/stats'
                source=db.execute('SELECT * FROM source_manifest WHERE endpoint=? AND status=200',(endpoint,)).fetchone()
                assert source is not None;rid=source['request_id']
            source=dict(db.execute('SELECT * FROM source_manifest WHERE request_id=?',(rid,)).fetchone())
            raw,path=original(source)
            assert str(raw['playerMetadata']['id'])==key[2]
            assert raw['stats'][FIELDS[field]]==conflict['fresh_value']
            if field=='yellow_cards':assert raw['stats']['totalYelCard']==conflict['old_value']
            resolutions.append(conflict|dict(resolution='Use explicit per-match '+FIELDS[field]+' already present in the original official response',
                prior_raw_sha256=source['sha256'],prior_raw_path=path,prior_request_id=rid,
                correct_source_pointer='/stats/'+FIELDS[field],prior_mapping=evidence.get(field)))
    dump(out/'player_value_reconciliations.json',resolutions)
    joined=new.combine_first(old)
    # A proved nonparticipant must not inherit an old announced-start flag/minute.
    for field in ['played','started','minutes','minutes_basis']:
        joined.loc[new.index,field]=new[field]
    for r in fresh.to_dict('records'):
        key=tuple(r[c] for c in index)
        value=joined.loc[key,'field_evidence_json']
        evidence=json.loads(value) if isinstance(value,str) else {}
        source_stats=json.loads(r['raw_stats_json'])
        for field,native in FIELDS.items():
            if field not in joined or pd.isna(r.get(field)):continue
            evidence[field]=dict(source_url=r['source_url'],sha256=r['source_sha256'],pointer='/stats/'+native,
                method='direct official individual match value' if native in source_stats else 'Complete actual-participant/team-total proof; see new_participant_zero_proofs.parquet')
        for field in ['played','started','minutes']:
            evidence[field]=dict(method=r['participation_basis'],proof_table='pl_lineup_recovery_proofs.parquet',sha256=r['source_sha256'])
        joined.loc[key,'field_evidence_json']=json.dumps(evidence)
    times=pd.concat([pd.to_datetime(old.available_at_utc,utc=True,format='mixed'),pd.to_datetime(new.available_at_utc,utc=True,format='mixed')],axis=1)
    joined['available_at_utc']=times.max(axis=1);result=joined.reset_index()
    assert not result.duplicated(['game_id','side','player_id']).any()
    pd.DataFrame(zero).to_parquet(out/'new_participant_zero_proofs.parquet',index=False)
    dump(out/'new_participant_field_discrepancies.json',mismatches)
    fresh.to_parquet(out/'recovered_players_with_proven_counts.parquet',index=False)
    audit=dict(at_utc=stamp(),recovered_games=fresh.game_id.nunique(),source_rows=len(fresh),actual_participants=int(fresh.played.sum()),
        original_player_rows=len(players),merged_player_rows=len(result),new_player_rows=len(result)-len(players),exact_overlap=len(overlap),
        raw_hashes_rechecked=len(source_hashes),derived_zero_cells=len(zero),unreconciled_team_field_counts=len(mismatches),
        explicit_player_value_differences=len(explicit),reconciled_player_values=len(resolutions),unresolved_player_value_conflicts=0,raw_values_unchanged=True,
        source_file_sha256=hashlib.sha256((ROOT_OUT/'pl_lineup_recovery_validated.parquet').read_bytes()).hexdigest())
    dump(out/'recovered_participant_merge.json',audit);print(json.dumps(audit),flush=True)
    return result,audit
