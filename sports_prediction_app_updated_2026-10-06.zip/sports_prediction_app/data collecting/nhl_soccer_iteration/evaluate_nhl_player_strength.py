"""Controlled player-strength comparison, with dated probability-error selection.

Four fits compare two unchanged model families with/without three new player
summaries. The all-phase cohort is identical. No return-based parameter search.
"""
import json,pickle,shutil
import numpy as np
import pandas as pd
import models
from common import ROOT_OUT,dump,stamp,file_sha256
from nhl_player_strength import WORK,FIELDS
from forecast_pairing import PRIMARY,SECOND,paired_predictions
from backtest import quote_inputs,attach,select,simulate
from cash_validation import validate_cash
from final_pipeline import discard_work

RESULT=ROOT_OUT/'simulation_results/feature_revisions/nhl_player_strength'
CONTROL={PRIMARY:'control_regulation_ot',SECOND:'control_logistic_strong'}


def pairs(raw,label):
    if label=='control':
        raw=raw[raw.variant.isin(CONTROL.values())].copy();raw.variant=raw.variant.replace({v:k for k,v in CONTROL.items()})
    else:raw=raw[raw.variant.isin([PRIMARY,SECOND])].copy()
    return paired_predictions(raw,label)


def loss(frame):
    y=frame.target.to_numpy(int);ix=np.arange(len(frame))
    return (-np.log(frame[['p0','p1']].to_numpy()[ix,y])-
            np.log(frame[['second_p0','second_p1']].to_numpy()[ix,y]))/2


def monthly_choice(frame):
    a=frame[frame.variant.eq('candidate')].sort_values('game_id').reset_index(drop=True)
    b=frame[frame.variant.eq('control')].sort_values('game_id').reset_index(drop=True)
    assert a.game_id.equals(b.game_id) and a.target.equals(b.target)
    la,lb=loss(a),loss(b);output=[];audit=[]
    for fold in sorted(a.fold.unique()):
        cut=pd.Timestamp(fold+'-01',tz='UTC');prior=a.available_time.lt(cut);test=a.fold.eq(fold)
        choose='candidate' if prior.any() and la[prior].mean()<lb[prior].mean() else 'control'
        used=(a if choose=='candidate' else b)[test].copy();used['selected_model']=choose;used['variant']='past_probability_choice'
        used['selection_source_max']=a.loc[prior,'available_time'].max() if prior.any() else pd.NaT
        assert not prior.any() or used.selection_source_max.lt(used.prediction_time).all()
        output.append(used);audit.append(dict(fold=fold,selected=choose,earlier_forecasts=int(prior.sum()),
            candidate_prior_loss=float(la[prior].mean()) if prior.any() else None,control_prior_loss=float(lb[prior].mean()) if prior.any() else None,
            last_known_outcome=a.loc[prior,'available_time'].max() if prior.any() else None))
    return pd.concat(output,ignore_index=True),audit


def forecast_metrics(p):
    rows=[]
    for (variant,year),g in p.groupby(['variant',p.prediction_time.dt.year]):
        avg=(g[['p0','p1']].to_numpy()+g[['second_p0','second_p1']].to_numpy())/2
        y=g.target.to_numpy(int);pick=avg.argmax(axis=1)
        rows.append(dict(variant=variant,year=int(year),games=len(g),mean_component_logloss=float(loss(g).mean()),
            mean_forecast_accuracy=float(np.mean(pick==y)),mean_forecast_brier=float(np.mean((avg[:,1]-y)**2)),
            mean_pick_confidence=float(avg.max(axis=1).mean())))
    return pd.DataFrame(rows)


def diagnose(frame,destination):
    """Paired whole-month uncertainty; observations within a game stay paired."""
    a=frame[frame.variant.eq('candidate')].set_index('game_id')
    b=frame[frame.variant.eq('control')].set_index('game_id').loc[a.index]
    assert a.target.equals(b.target)
    delta=loss(a)-loss(b)
    pairs=pd.DataFrame(dict(difference=delta,fold=a.fold.to_numpy(),year=a.prediction_time.dt.year.to_numpy()))
    rng=np.random.default_rng(731);summary=[]
    for year,g in pairs.groupby('year'):
        blocks=[r.difference.to_numpy() for _,r in g.groupby('fold')]
        draws=[float(np.concatenate([blocks[i] for i in rng.integers(0,len(blocks),len(blocks))]).mean()) for _ in range(3000)]
        summary.append(dict(year=int(year),games=len(g),mean_loss_difference=float(g.difference.mean()),
            monthly_block_95_interval=np.quantile(draws,[.025,.975]).tolist()))
    result=dict(at_utc=stamp(),loss_difference='candidate minus same-cohort control; negative is better',
        comparisons=summary,method='3000 paired whole-month bootstrap samples; fixed seed731. Descriptive retrospective uncertainty, not correction for all prior research trials.')
    dump(destination,result)
    return result


def accounts(p,quotes,stage):
    f,audit=attach(p,quotes);dump(RESULT/(stage+'_matching.json'),audit)
    annual=[];trades=[];curves=[];years=sorted(p.prediction_time.dt.year.unique())
    for (variant,provider),group in f.groupby(['variant','provider']):
        chosen=select(group,'expected_profit')
        secondary=np.where(chosen.quote_class.eq(0),chosen.second_p0,chosen.second_p1)
        chosen=chosen[secondary/chosen.entry_price>=1.10]
        for year in years:
            summary,t,c=simulate(chosen,int(year));meta=dict(sport='nhl',variant=variant,provider=provider,recipe='fixed',year=int(year))
            annual.append(meta|summary)
            if len(t):trades.append(t.assign(**meta))
            curves.append(c.assign(**meta))
    a=pd.DataFrame(annual);t=pd.concat(trades,ignore_index=True);c=pd.concat(curves,ignore_index=True)
    n=validate_cash(t,c)
    a.to_csv(RESULT/(stage+'_annual.csv'),index=False);t.to_parquet(RESULT/(stage+'_bets.parquet'),index=False);c.to_parquet(RESULT/(stage+'_daily.parquet'),index=False)
    return a,n


def replay(raw,stage):
    data=pd.read_parquet(WORK/'nhl_features.parquet');data=pd.concat([data,pd.get_dummies(data.league,prefix='league',dtype=float)],axis=1)
    total=0;effects=[]
    for name in [PRIMARY,SECOND]+list(CONTROL.values()):
        bundle=pickle.loads((WORK/'model_runs/nhl'/stage/(name+'.pkl')).read_bytes())
        sample=raw[raw.variant.eq(name)&raw.fold.eq(bundle['boundary'].strftime('%Y-%m'))].head(12)
        X=data.set_index('game_id').loc[sample.game_id,bundle['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
        predicted=models.apply_calibration(bundle['model'].predict_proba(X),bundle['calibrator'])
        assert np.allclose(predicted,sample[['p0','p1']],rtol=0,atol=1e-12)
        assert set(FIELDS).issubset(bundle['columns']) if name in [PRIMARY,SECOND] else not set(FIELDS)&set(bundle['columns'])
        if name in [PRIMARY,SECOND]:
            fitted=bundle['model']
            components=list(zip(['away_regulation_goals','home_regulation_goals'],fitted.models)) if hasattr(fitted,'models') else [('home_win',fitted)]
            for response,component in components:
                coefficients=np.asarray(component.steps[-1][1].coef_).reshape(-1)
                for field in FIELDS:
                    effects.append(dict(model=name,response=response,field=field,
                        coefficient_per_training_standard_deviation=float(coefficients[bundle['columns'].index(field)]),
                        link='log_expected_goals' if hasattr(fitted,'models') else 'log_odds',
                        interpretation='Conditional fitted association before temperature calibration; not causal',
                        fit_boundary=bundle['boundary'],calibration_temperature=bundle['calibrator']['temperature']))
        total+=len(sample)
    dump(RESULT/(stage+'_new_feature_effects.json'),effects)
    return total


def run():
    check=json.loads((WORK/'feature_validation.json').read_bytes());assert check['status']=='PASS'
    assert check['feature_sha256']==file_sha256(WORK/'nhl_features.parquet')
    RESULT.mkdir(parents=True,exist_ok=True)
    plan=json.loads((WORK/'plan.json').read_bytes());plan['monthly_selection_choices']=['control','candidate']
    plan['source_hashes']['nhl_regulation_score_repairs.parquet']=file_sha256(ROOT_OUT/'nhl_regulation_score_repairs.parquet')
    plan['initial_selection']='control until earlier out-of-fit forecast errors exist'
    dump(RESULT/'experiment_plan.json',plan)
    for original,name in CONTROL.items():models.CANDIDATES[name]=dict(models.CANDIDATES[original],exclude_columns=FIELDS)
    names=[PRIMARY,SECOND]+list(CONTROL.values());models.OUT=WORK
    raw=models.run('nhl','development',names)
    p=pd.concat([pairs(raw,'control'),pairs(raw,'candidate')],ignore_index=True)
    dynamic,selection=monthly_choice(p)
    reference=paired_predictions(pd.read_parquet(ROOT_OUT/'retained_models/nhl/development_predictions.parquet'),'retained')
    development=pd.concat([p,dynamic,reference],ignore_index=True)
    forecast_metrics(development).to_csv(RESULT/'development_metrics.csv',index=False)
    common=set(reference.game_id)&set(p.game_id)
    forecast_metrics(development[development.game_id.isin(common)]).to_csv(RESULT/'development_common_game_metrics.csv',index=False)
    development.to_parquet(RESULT/'development_predictions.parquet',index=False)
    diagnose(development,RESULT/'development_loss_diagnosis.json')
    scored={v:float(loss(g).mean()) for v,g in p.groupby('variant')}
    passed=scored['candidate']<scored['control']
    dump(RESULT/'selection.json',dict(at_utc=stamp(),passed=bool(passed),mean_component_logloss=scored,monthly_choices=selection))
    quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62')
    annual,days=accounts(development,quotes,'development');replays=replay(raw,'development')
    eval_annual=pd.DataFrame()
    if passed:
        dump(WORK/'nhl_selection.json',dict(selected_candidates=names))
        test_raw=models.run('nhl','evaluation',names)
        tp=pd.concat([pairs(test_raw,'control'),pairs(test_raw,'candidate')],ignore_index=True)
        dynamic,selection=monthly_choice(pd.concat([p,tp],ignore_index=True))
        old=paired_predictions(pd.read_parquet(ROOT_OUT/'retained_models/nhl/evaluation_predictions.parquet'),'retained')
        test=pd.concat([tp,dynamic[dynamic.prediction_time.dt.year.eq(2026)],old],ignore_index=True)
        test.to_parquet(RESULT/'evaluation_predictions.parquet',index=False);forecast_metrics(test).to_csv(RESULT/'evaluation_metrics.csv',index=False)
        diagnose(test,RESULT/'evaluation_loss_diagnosis.json')
        forecast_metrics(test[test.game_id.isin(old.game_id)]).to_csv(RESULT/'evaluation_common_game_metrics.csv',index=False)
        eval_annual,extra=accounts(test,quotes,'evaluation');days+=extra;replays+=replay(test_raw,'evaluation')
        dump(RESULT/'monthly_selection.json',selection)
        # Evaluation does not adopt these alternatives as final models.
        # Predictions, metrics and ledgers survive; fitted trials do not.
    for file in ['feature_validation.json','rating_fit_audit.json','release_coverage.csv']:
        if (WORK/file).exists():shutil.copy2(WORK/file,RESULT/file)
    dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),candidate_passed_probability_gate=bool(passed),independent_cash_days=days,forecast_replays=replays,
        future_label_violations=int((~raw.train_label_max.lt(raw.prediction_time)).sum()),candidate_2026_evaluated=bool(passed),goal_achieved=False,
        interpretation='2026 repeatedly researched. The declared probability-score gate is separate from the older failed weakest-year return gate. No return-based model selection.'))
    print(json.dumps(dict(probability_gate=bool(passed),development_mean_component_logloss=scored,independent_cash_days=days,forecast_replays=replays)),flush=True)
    print(pd.concat([annual,eval_annual],ignore_index=True)[['variant','provider','year','bets','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


def main(work=None,fields=None,result=None):
    global WORK,FIELDS,RESULT
    if work is not None:WORK=work
    if fields is not None:FIELDS=fields
    if result is not None:RESULT=result
    try:run()
    except Exception as exc:
        path=ROOT_OUT/'simulation_results/failed_runs.json';rows=json.loads(path.read_text()) if path.exists() else []
        rows.append(dict(at_utc=stamp(),run=WORK.name,error=repr(exc),temporary_artifacts_retained=False));dump(path,rows)
        raise
    finally:
        if WORK.exists():discard_work(WORK)


if __name__=='__main__':main()
