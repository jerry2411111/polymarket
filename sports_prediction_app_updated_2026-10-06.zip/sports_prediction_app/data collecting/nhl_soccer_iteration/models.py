"""Monthly, purged rolling fits. Candidate choice precedes 2026 evaluation."""
import argparse
import hashlib
import json
import pickle
import time
import warnings
import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from scipy.optimize import minimize_scalar,minimize
from scipy.special import softmax
from scipy.stats import skellam
from sklearn.impute import SimpleImputer
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression,PoissonRegressor
from sklearn.metrics import log_loss,accuracy_score,f1_score,recall_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler,RobustScaler
from threadpoolctl import threadpool_limits
from common import OUT,dump,stamp

CANDIDATES={
 'logistic_compact':dict(kind='logistic',features='compact',C=.1,scale='z'),
 'logistic_full':dict(kind='logistic',features='full',C=.05,scale='z'),
 'logistic_robust':dict(kind='logistic',features='compact',C=.1,scale='robust'),
 'catboost_compact':dict(kind='catboost',features='compact',depth=3,iterations=300),
 'catboost_full':dict(kind='catboost',features='full',depth=4,iterations=300),
 'poisson_compact':dict(kind='poisson',features='compact',alpha=.1),
 'poisson_full':dict(kind='poisson',features='full',alpha=1.0),
 'catboost_recent':dict(kind='catboost',features='full',depth=3,iterations=400,half_life_days=730),
 'catboost_one_year':dict(kind='catboost',features='full',depth=3,iterations=400,half_life_days=365),
 'histboost_compact':dict(kind='histboost',features='compact'),
 'elastic_net':dict(kind='elastic',features='compact',C=.1,scale='z'),
}
INITIAL_CANDIDATES=list(CANDIDATES)[:6]
CANDIDATES.update({
 'strength_logistic':dict(kind='logistic',features='strength',C=.1,scale='z'),
 'mechanism_logistic':dict(kind='logistic',features='mechanism',C=.1,scale='z'),
 'mechanism_logistic_strong':dict(kind='logistic',features='mechanism',C=.02,scale='z'),
 'mechanism_catboost_d2':dict(kind='catboost',features='mechanism',depth=2,iterations=300),
 'mechanism_catboost_d3':dict(kind='catboost',features='mechanism',depth=3,iterations=300),
 'mechanism_poisson':dict(kind='poisson',features='mechanism',alpha=.1),
 'mechanism_poisson_strong':dict(kind='poisson',features='mechanism',alpha=1.),
 'draw_logistic':dict(kind='logistic',features='draw_structure',C=.1,scale='z'),
 'draw_hurdle':dict(kind='hurdle',features='draw_structure',C=.1),
 'draw_poisson':dict(kind='poisson',features='draw_structure',alpha=.1),
 'draw_catboost':dict(kind='catboost',features='draw_structure',depth=3,iterations=300),
 'granular_logistic':dict(kind='logistic',features='granular',C=.1,scale='z'),
 'granular_logistic_strong':dict(kind='logistic',features='granular',C=.02,scale='z'),
 'granular_catboost':dict(kind='catboost',features='granular',depth=2,iterations=300),
 'granular_poisson':dict(kind='poisson',features='granular',alpha=1.),
 'context_global':dict(kind='logistic',features='context8',C=.02,scale='z'),
 'context_league':dict(kind='logistic',features='context8',C=.02,scale='league'),
 'context_league_bias':dict(kind='logistic',features='context8',C=.02,scale='league',calibration='bias'),
 'context_log_bias':dict(kind='logistic',features='context8',C=.02,scale='league_log',calibration='bias'),
 'context_poisson_bias':dict(kind='poisson',features='context8',alpha=1.,calibration='bias'),
 'granular_logistic_bias':dict(kind='logistic',features='granular',C=.02,scale='z',calibration='bias'),
 'granular_poisson_bias':dict(kind='poisson',features='granular',alpha=1.,calibration='bias'),
 'goalie_logistic':dict(kind='logistic',features='goalie10',C=.02,scale='z'),
 'goalie_poisson':dict(kind='poisson',features='goalie10',alpha=1.),
 'granular_regulation':dict(kind='poisson',features='granular',alpha=1.,regulation=True),
 'granular_regulation_ot':dict(kind='poisson',features='granular',alpha=1.,regulation=True,learn_overtime=True),
 'state_logistic':dict(kind='logistic',features='state13',C=.02,scale='z'),
 'state_regulation_ot':dict(kind='poisson',features='state13',alpha=1.,regulation=True,learn_overtime=True),
 'chance_logistic':dict(kind='logistic',features='chance17',C=.02,scale='z'),
 'chance_regulation_ot':dict(kind='poisson',features='chance17',alpha=1.,regulation=True,learn_overtime=True),
 'chance_catboost':dict(kind='catboost',features='chance17',depth=2,iterations=300),
 'workload_logistic':dict(kind='logistic',features='workload24',C=.02,scale='z'),
 'workload_regulation_ot':dict(kind='poisson',features='workload24',alpha=1.,regulation=True,learn_overtime=True),
 'relative_logistic':dict(kind='logistic',features='relative27',C=.02,scale='z'),
 'relative_regulation_ot':dict(kind='poisson',features='relative27',alpha=1.,regulation=True,learn_overtime=True),
})
META=['game_id','official_game_id','sport','league','date','prediction_time','available_time','start_time','target']

def columns(frame,spec):
    allcols=[c for c in frame if (c.startswith('f_') or c.startswith('league_')) and c not in spec.get('exclude_columns',[])]
    if spec['features']=='relative27':
        from mechanism_features import STRENGTH
        return [c for c in allcols if c in STRENGTH or c.startswith('league_') or c.startswith('f_gran_') or c.startswith('f_relative_')]
    if spec['features']=='workload24':
        from mechanism_features import STRENGTH
        return [c for c in allcols if c in STRENGTH or c.startswith('league_') or c.startswith('f_gran_') or c.startswith('f_work_')]
    if spec['features']=='chance17':
        from mechanism_features import STRENGTH
        old_quality=['xg','goals_saved_above_model','finishing_residual','even_strength_expected']
        return [c for c in allcols if c in STRENGTH or c.startswith('league_') or c.startswith('f_chance_') or
                (c.startswith('f_gran_') and not any(term in c for term in old_quality))]
    if spec['features']=='state13':
        from mechanism_features import STRENGTH
        return [c for c in allcols if c in STRENGTH or c.startswith('league_') or c.startswith('f_gran_') or c.startswith('f_state_')]
    if spec['features']=='goalie10':
        from mechanism_features import STRENGTH
        return [c for c in allcols if c in STRENGTH or c.startswith('league_') or c.startswith('f_gran_') or c.startswith('f_rotation_')]
    if spec['features']=='context8':
        from mechanism_features import STRENGTH
        return [c for c in allcols if c in STRENGTH or c.startswith('league_') or c.startswith('f_ctx_')]
    if spec['features']=='granular':
        from mechanism_features import STRENGTH
        return [c for c in allcols if c in STRENGTH or c.startswith('league_') or c.startswith('f_gran_')]
    if spec['features'] in ['strength','mechanism','draw_structure']:
        from mechanism_features import STRENGTH
        return [c for c in allcols if c in STRENGTH or c.startswith('league_') or (spec['features']=='mechanism' and c.startswith('f_mech_')) or (spec['features']=='draw_structure' and c.startswith('f_draw_'))]
    if spec['features']=='full':return allcols
    terms=['elo','rest_days','games_7d','score_for','score_against','margin','xg','shots_on_target','shots_for','shots_against','big_chances','possession','roster_goals_rate','roster_assists_rate','roster_key_passes_rate','roster_shots_on_target_rate','goalie','playoffs','home_attack','away_attack','home_defence','away_defence']
    return [c for c in allcols if c.startswith('league_') or any(t in c for t in terms)]

class DrawThenWinner:
    """A binary draw forecast and a conditional home/away forecast.

    This separates low-score/balanced-match information from the direction of
    team strength. Both components fit earlier labels only. Probability, not a
    forced minimum number of draw picks, is the objective.
    """
    def __init__(self,C):self.C=C
    def fit(self,X,y):
        self.draw_columns=[c for c in X if c.startswith('f_draw_') or c.startswith('league_')]
        self.winner_columns=[c for c in X if not c.startswith('f_draw_')]
        def build():return make_pipeline(SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True),StandardScaler(),LogisticRegression(C=self.C,max_iter=1500))
        self.draw=build();self.winner=build();labels=np.asarray(y,int);decisive=labels!=2
        self.draw.fit(X[self.draw_columns],(labels==2).astype(int))
        self.winner.fit(X.loc[decisive,self.winner_columns],labels[decisive])
        self.classes_=np.arange(3);return self
    def predict_proba(self,X):
        d=self.draw.predict_proba(X[self.draw_columns])[:,1]
        h=self.winner.predict_proba(X[self.winner_columns])[:,1]
        return np.column_stack([(1-d)*(1-h),(1-d)*h,d])


class PoissonModel:
    def __init__(self,alpha,sport,regulation=False,learn_overtime=False,score_targets=None,observed_scale=False):
        self.alpha=alpha;self.sport=sport;self.regulation=regulation;self.learn_overtime=learn_overtime
        self.score_targets=score_targets
        self.observed_scale=observed_scale
    def fit(self,X,frame,sample_weight=None):
        self.models=[]
        targets=['regulation_scoreA','regulation_scoreB'] if self.regulation else ['scoreA','scoreB']
        if getattr(self,'score_targets',None) is not None:targets=list(self.score_targets)
        if self.regulation:assert self.sport=='nhl' and frame[targets].notna().all().all()
        for target in targets:
            pre=[StandardScaler(),SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True)] if self.observed_scale else [SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True),StandardScaler()]
            model=make_pipeline(*pre,PoissonRegressor(alpha=self.alpha,max_iter=600))
            kwargs={'poissonregressor__sample_weight':sample_weight} if sample_weight is not None else {}
            model.fit(X,frame[target].astype(float),**kwargs);self.models.append(model)
        self.overtime_model=None
        if self.learn_overtime:
            assert self.regulation
            from mechanism_features import STRENGTH
            tied=frame.regulation_scoreA.eq(frame.regulation_scoreB)
            self.ot_columns=[c for c in X if c in STRENGTH]
            if tied.sum()>=100 and frame.loc[tied,'target'].nunique()==2:
                pre=[StandardScaler(),SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True)] if self.observed_scale else [SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True),StandardScaler()]
                self.overtime_model=make_pipeline(*pre,LogisticRegression(C=.05,max_iter=1500))
                kwargs={}
                if sample_weight is not None:
                    tied_weights=np.asarray(sample_weight)[tied];tied_weights=tied_weights/tied_weights.mean()
                    kwargs['logisticregression__sample_weight']=tied_weights
                self.overtime_model.fit(X.loc[tied,self.ot_columns],frame.loc[tied,'target'].astype(int),**kwargs)
        return self
    def predict_proba(self,X):
        a,b=[np.clip(m.predict(X),.05,15) for m in self.models]
        draw=skellam.pmf(0,a,b);away=skellam.sf(0,a,b);home=skellam.cdf(-1,a,b)
        if self.sport=='soccer':p=np.column_stack([away,home,draw])
        else:
            # Legacy variants retain final-score training. Regulation variants
            # remove OT/SO additions from goal targets before allocating ties.
            overtime=getattr(self,'overtime_model',None)
            home_extra=overtime.predict_proba(X[self.ot_columns])[:,1] if overtime is not None else .5
            p=np.column_stack([away+draw*(1-home_extra),home+draw*home_extra])
        return p/p.sum(axis=1,keepdims=True)

def make_model(spec,sport):
    if spec['kind']=='hurdle':
        assert sport=='soccer';return DrawThenWinner(spec['C'])
    if spec['kind']=='poisson':return PoissonModel(spec['alpha'],sport,spec.get('regulation',False),spec.get('learn_overtime',False),spec.get('score_targets'),spec.get('observed_scale',False))
    if spec['kind']=='histboost':return HistGradientBoostingClassifier(max_iter=250,max_leaf_nodes=7,learning_rate=.05,l2_regularization=5,min_samples_leaf=50,early_stopping=False,random_state=42)
    if spec['kind']=='catboost':
        return CatBoostClassifier(iterations=spec['iterations'],depth=spec['depth'],learning_rate=.035,l2_leaf_reg=15,loss_function='MultiClass' if sport=='soccer' else 'Logloss',random_seed=42,thread_count=4,verbose=False,allow_writing_files=False)
    logistic=LogisticRegression(C=spec['C'],max_iter=1500) if spec['kind']!='elastic' else LogisticRegression(C=spec['C'],l1_ratio=.5,solver='saga',max_iter=2000,random_state=42)
    if spec.get('scale') in ['league','league_log']:
        from context_preprocessing import CompetitionScale
        if spec.get('preserve_unit_columns'):
            from context_preprocessing import UnitAwareStandardScale
            imputer=SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True).set_output(transform='pandas')
            return make_pipeline(CompetitionScale(signed_log=spec['scale']=='league_log',pooled_variance_floor=spec.get('pooled_variance_floor',False)),imputer,UnitAwareStandardScale(tuple(spec['preserve_unit_columns'])),logistic)
        return make_pipeline(CompetitionScale(signed_log=spec['scale']=='league_log'),SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True),StandardScaler(),logistic)
    return make_pipeline(SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True),StandardScaler() if spec['scale']=='z' else RobustScaler(),logistic)

def fit_model(model,X,frame,spec,asof):
    kwargs={}
    if spec.get('half_life_days'):
        weights=np.exp2(-(asof-frame.available_time).dt.total_seconds().to_numpy()/86400/spec['half_life_days'])
        if spec.get('normalize_sample_weight'):weights=weights/weights.mean()
        kwargs['sample_weight']=weights
    if spec['kind']=='poisson':return model.fit(X,frame,**kwargs)
    if kwargs and hasattr(model,'steps'):
        assert spec['kind'] in ['logistic','elastic'],'Weighted custom model requires explicit handling'
        kwargs={model.steps[-1][0]+'__sample_weight':kwargs['sample_weight']}
    return model.fit(X,frame.target.astype(int),**kwargs)

def temperature_fit(p,y):
    logits=np.log(np.clip(p,1e-8,1));k=p.shape[1]
    # Mild regularisation discourages extreme confidence corrections on small
    # trailing calibration sets. Its strength is fixed before evaluation.
    loss=lambda t:log_loss(y,softmax(logits/t,axis=1),labels=list(range(k)))+.01*np.log(t)**2
    return float(minimize_scalar(loss,bounds=(.65,2.5),method='bounded').x)


def calibration_fit(p,y,kind='temperature',context=None):
    if kind=='temperature':return dict(temperature=temperature_fit(p,y),bias=[0.]*p.shape[1],kind=kind)
    if kind=='roster_shrink':
        assert p.shape[1]==2 and context is not None
        turnover=np.asarray(context,float)
        assert len(turnover)==len(p) and (np.isnan(turnover)|((turnover>=0)&(turnover<=1))).all()
        # Unknown turnover means ordinary temperature calibration; it is not
        # asserted to be a measured zero in the feature dataset.
        observed=np.where(np.isfinite(turnover),turnover,0.)
        logits=np.log(np.clip(p,1e-8,1))
        def loss(theta):
            base=softmax(logits/np.exp(theta[0]),axis=1)
            weight=theta[1]*observed[:,None]
            probability=(1-weight)*base+weight*.5
            return log_loss(y,probability,labels=[0,1])+.01*theta[0]**2+.01*theta[1]**2
        initial=[np.log(temperature_fit(p,y)),0.]
        fit=minimize(loss,initial,method='L-BFGS-B',bounds=[(np.log(.65),np.log(2.5)),(0.,1.)])
        assert fit.success,fit.message
        return dict(temperature=float(np.exp(fit.x[0])),bias=[0.,0.],kind=kind,
                    roster_shrink=float(fit.x[1]),unknown_context='ordinary temperature calibration')
    assert kind=='bias';logits=np.log(np.clip(p,1e-8,1));k=p.shape[1]
    def unpack(theta):
        bias=np.r_[0.,theta[1:]];bias-=bias.mean()
        return np.exp(theta[0]),bias
    def loss(theta):
        t,b=unpack(theta)
        return log_loss(y,softmax(logits/t+b,axis=1),labels=list(range(k)))+.01*np.log(t)**2+.01*np.dot(b,b)
    fit=minimize(loss,np.zeros(k),method='L-BFGS-B',bounds=[(np.log(.65),np.log(2.5))]+[(-1.5,1.5)]*(k-1))
    assert fit.success,fit.message
    t,b=unpack(fit.x);return dict(temperature=float(t),bias=b.tolist(),kind=kind)


def apply_calibration(p,calibrator,context=None):
    base=softmax(np.log(np.clip(p,1e-8,1))/calibrator['temperature']+np.asarray(calibrator['bias']),axis=1)
    if calibrator['kind']=='roster_shrink':
        assert context is not None and base.shape[1]==2
        turnover=np.asarray(context,float)
        assert len(turnover)==len(p) and (np.isnan(turnover)|((turnover>=0)&(turnover<=1))).all()
        weight=calibrator['roster_shrink']*np.where(np.isfinite(turnover),turnover,0.)[:,None]
        return (1-weight)*base+weight*.5
    return base

def metrics(p):
    result=[]
    for (sport,variant,year),g in p.groupby(['sport','variant',p.prediction_time.dt.year]):
        k=3 if sport=='soccer' else 2;prob=g[[f'p{i}' for i in range(k)]].to_numpy();y=g.target.to_numpy(int)
        pick=prob.argmax(axis=1);recall=recall_score(y,pick,labels=list(range(k)),average=None,zero_division=0)
        result.append(dict(sport=sport,variant=variant,year=int(year),games=len(g),accuracy=accuracy_score(y,pick),log_loss=log_loss(y,prob,labels=list(range(k))),brier=np.mean(np.sum((prob-np.eye(k)[y])**2,axis=1)),
                           macro_f1=f1_score(y,pick,labels=list(range(k)),average='macro',zero_division=0),balanced_accuracy=float(recall.mean()),
                           **{'recall_class_'+str(i):float(v) for i,v in enumerate(recall)},**{'predicted_class_'+str(i)+'_pct':100*float(np.mean(pick==i)) for i in range(k)}))
    return pd.DataFrame(result)

def run(sport,stage,candidate_names,refit='monthly'):
    source=OUT/(sport+'_features.parquet');digest=hashlib.sha256(source.read_bytes()).hexdigest()
    data=pd.read_parquet(source).sort_values(['prediction_time','game_id']).reset_index(drop=True)
    assert data.start_time.min()>=pd.Timestamp('2021-01-01',tz='UTC'),'Requested primary training window starts in 2021; older exploratory runs must remain separate'
    data=pd.concat([data,pd.get_dummies(data.league,prefix='league',dtype=float)],axis=1)
    data['fold']=data.prediction_time.dt.strftime('%Y-%m-%d' if refit=='daily' else '%Y-%m')
    years=[2024,2025] if stage=='development' else [2026]
    candidates={k:CANDIDATES[k] for k in candidate_names}
    config=dict(sport=sport,stage=stage,source_sha256=digest,candidates=candidates,started_utc=stamp(),years=years,calibration_days=180,refit=refit,method='Purged trailing monthly calibration then refit on every label available before the '+refit+' boundary; calibrator trained only on out-of-fit observations.')
    if stage=='evaluation':
        chosen=json.loads((OUT/(sport+'_selection.json')).read_text())
        assert all(c in chosen['selected_candidates'] for c in candidates),'Evaluation candidates must be selected on development data first'
    folder=OUT/'model_runs'/sport/stage;folder.mkdir(parents=True,exist_ok=True)
    old=folder/'specification.json'
    if old.exists():
        previous=json.loads(old.read_text())
        assert previous['source_sha256']==digest and previous['candidates']==candidates and previous.get('refit','monthly')==refit,'Feature/candidate/refit change needs a distinct run folder'
    else:dump(old,config)
    allpaths=[];count=0;begin=time.monotonic();calibration_cache={}
    folds=sorted(data.loc[data.prediction_time.dt.year.isin(years),'fold'].unique())
    for fold in folds:
        boundary=pd.Timestamp(fold if refit=='daily' else fold+'-01',tz='UTC');test=data[data.fold.eq(fold)]
        prior=data[data.available_time.lt(boundary)]
        calibration_boundary=pd.Timestamp(fold[:7]+'-01',tz='UTC')
        calibration_prior=data[data.available_time.lt(calibration_boundary)]
        calibration=calibration_prior[calibration_prior.prediction_time.ge(calibration_boundary-pd.Timedelta(days=180))]
        assert len(calibration)>=80
        training=calibration_prior[calibration_prior.available_time.lt(calibration.prediction_time.min())]
        assert len(training)>=500
        assert training.available_time.max()<calibration.prediction_time.min()
        assert prior.available_time.max()<test.prediction_time.min()
        for name,spec in candidates.items():
            path=folder/(fold+'_'+name+'.parquet');allpaths.append(path)
            if path.exists():count+=1;continue
            cols=columns(data,spec)
            X=lambda frame:frame[cols].replace([np.inf,-np.inf],np.nan).astype(float)
            fitted=make_model(spec,sport)
            context=lambda frame:frame[spec['calibration_context']] if spec.get('calibration_context') else None
            with threadpool_limits(limits=4):
                cache_key=(fold[:7],name)
                if cache_key not in calibration_cache:
                    fit_model(fitted,X(training),training,spec,calibration.prediction_time.min())
                    calibration_cache[cache_key]=calibration_fit(fitted.predict_proba(X(calibration)),calibration.target.astype(int),spec.get('calibration','temperature'),context(calibration))
                calibrator=calibration_cache[cache_key];temp=calibrator['temperature']
                fitted=make_model(spec,sport)
                fit_model(fitted,X(prior),prior,spec,boundary)
                raw=fitted.predict_proba(X(test));p=apply_calibration(raw,calibrator,context(test))
            assert np.isfinite(p).all() and np.allclose(p.sum(axis=1),1)
            out=test[META].copy();out['learner']=spec['kind'];out['variant']=name
            for i in range(p.shape[1]):out['p'+str(i)]=p[:,i]
            out['fold']=fold;out['temperature']=temp;out['train_games']=len(prior);out['calibration_games']=len(calibration)
            out['calibration_kind']=calibrator['kind'];out['calibration_bias_json']=json.dumps(calibrator['bias'])
            if spec.get('calibration_context'):
                out['calibration_roster_shrink']=calibrator['roster_shrink']
                out['calibration_context']=context(test)
            out['train_label_max']=prior.available_time.max();out['calibration_train_label_max']=training.available_time.max();out['calibration_prediction_min']=calibration.prediction_time.min();out['calibration_label_max']=calibration.available_time.max()
            out.to_parquet(path,index=False)
            # Keep only the latest fitted artifact for each recipe; every forecast
            # remains in its immutable monthly result file.
            with (folder/(name+'.pkl')).open('wb') as f:pickle.dump(dict(model=fitted,temperature=temp,calibrator=calibrator,columns=cols,boundary=boundary,source_sha256=digest),f)
            count+=1
            print(json.dumps(dict(stage=stage,sport=sport,fold=fold,candidate=name,complete=count,total=len(folds)*len(candidates),elapsed_seconds=round(time.monotonic()-begin))),flush=True)
            dump(OUT/(sport+'_model_progress.json'),dict(stage=stage,complete=count,total=len(folds)*len(candidates),percent=100*count/(len(folds)*len(candidates)),fold=fold,candidate=name))
    allpred=pd.concat([pd.read_parquet(p) for p in allpaths],ignore_index=True)
    allpred.to_parquet(OUT/(sport+'_'+stage+'_predictions.parquet'),index=False)
    scores=metrics(allpred);scores.to_csv(OUT/(sport+'_'+stage+'_metrics.csv'),index=False)
    print(scores.to_string(index=False),flush=True)
    return allpred

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--sport',choices=['soccer','nhl'],required=True);p.add_argument('--stage',choices=['development','evaluation'],default='development');p.add_argument('--candidates',nargs='+',default=INITIAL_CANDIDATES);p.add_argument('--refit',choices=['monthly','daily'],default='monthly');a=p.parse_args();run(a.sport,a.stage,a.candidates,a.refit)
