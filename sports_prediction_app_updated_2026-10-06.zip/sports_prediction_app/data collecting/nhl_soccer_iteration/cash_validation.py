"""Reconcile final simulation cash ledgers."""
import numpy as np
import pandas as pd

def validate_cash(bets,daily):
    count=0
    keys=['sport','provider','recipe','year']+(['variant'] if 'variant' in daily else [])
    for account,g in daily.groupby(keys,dropna=False):
        mask=pd.Series(True,index=bets.index)
        for column,value in zip(keys,account):
            mask&=bets[column].isna() if pd.isna(value) else bets[column].eq(value)
        t=bets[mask]
        for r in g.itertuples():
            cut=pd.Timestamp(r.date,tz='UTC')+pd.Timedelta(days=1);entered=t[t.decision_time.le(cut)];paid=entered[entered.settlement_time.le(cut)]
            cash=10000-entered.stake.sum()+paid.payout.sum();opened=entered[entered.settlement_time.gt(cut)].stake.sum()
            assert np.isclose(cash,r.cash,atol=1e-6,rtol=0) and np.isclose(opened,r.open_cost,atol=1e-6,rtol=0)
            assert np.isclose(cash+opened,r.nav,atol=1e-6,rtol=0) and cash>=-1e-6;count+=1
    return count
