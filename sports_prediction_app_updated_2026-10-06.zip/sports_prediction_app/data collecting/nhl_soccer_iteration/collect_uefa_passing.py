"""Official UEFA passing reports with native lineup IDs and reconciliation."""
import argparse
import concurrent.futures
import datetime as dt
import difflib
import functools
import hashlib
import io
import json
import math
import re
import sqlite3
import unicodedata
from pathlib import Path
from zoneinfo import ZoneInfo
import pandas as pd
from pypdf import PdfReader
from common import PROJECT,PREVIOUS,ROOT_OUT,OfficialClient,read_db,dump,stamp

FIELDS=['long_passes_completed','long_passes','medium_passes_completed','medium_passes','short_passes_completed','short_passes','passes_completed','passes']

def normal(s):return ''.join(c for c in unicodedata.normalize('NFKD',s).casefold() if c.isalnum())


@functools.lru_cache(maxsize=1)
def documented_aliases():
    path=ROOT_OUT/'uefa_player_aliases.json'
    if not path.exists():return {}
    return {r['player_id']:r for r in json.loads(path.read_text())['records'] if r['state']=='verified'}


def name_check(player,printed):
    names=[(field,player[field]) for field in ['internationalName','clubShirtName','nationalShirtName'] if player.get(field)]
    for field in ['name','shortName']:
        names.extend(('translations/'+field+'/'+lang,name) for lang,name in player.get('translations',{}).get(field,{}).items() if name)
    # Historical names can survive only in another official language field.
    # Transliteration is an exact character mapping, never a name-based join.
    letters=dict(zip('абвгдеёжзийклмнопрстуфхцчшщъыьэюя',
                     ['a','b','v','g','d','e','e','zh','z','i','y','k','l','m','n','o','p','r','s','t','u','f','kh','ts','ch','sh','shch','','y','','e','yu','ya']))
    for pointer,name in list(names):
        if any(c in letters for c in name.casefold()):names.append((pointer+' (Cyrillic transliteration)',''.join(letters.get(c,c) for c in name.casefold())))
    score=max((difflib.SequenceMatcher(None,normal(printed),normal(name)).ratio() for _,name in names),default=0)
    for pointer,name in names:
        if normal(printed)==normal(name):return score,dict(method='exact_official_name',pointer=pointer,official_name=name)
        words=[normal(w) for w in re.split(r'[\s-]+',printed) if normal(w)]
        complete=[normal(w) for w in re.split(r'[\s-]+',name) if normal(w)]
        if len(words)>=2 and complete and words[0]==complete[0] and all(word in complete for word in words):
            return score,dict(method='official_full_name_with_extra_components',pointer=pointer,official_name=name)
    alias=documented_aliases().get(str(player['id']))
    if alias and normal(printed)==normal(alias['alias']):
        assert player['birthDate']==alias['expected_birth_date'],'Alias birth date disagrees'
        raw=PROJECT/alias['source']['raw_file'];assert hashlib.sha256(raw.read_bytes()).hexdigest()==alias['source']['sha256']
        return score,dict(method='documented_native_id_alias',alias_evidence=alias)
    assert score>=.80 or any(normal(n) and (normal(printed) in normal(n) or normal(n) in normal(printed)) for _,n in names),'Name/lineup discrepancy: '+printed+' / '+str(player.get('internationalName'))
    return score,dict(method='existing_name_similarity_check',similarity=score)


def report_url(game):
    # June preliminaries already belong to the next official season.
    season=str(game['season']);match=re.fullmatch(r'(\d{4})-(\d{2}|\d{4})',season)
    assert match,'Unrecognized official season: '+season
    start=int(match[1]);end=int(match[2]);end=end if end>=100 else start//100*100+end
    assert end==start+1
    return f'https://www.uefa.com/newsfiles/UCL/{end}/{game["official_game_id"]}_TPD.pdf'

def spaced_text(reader):
    lines=[]
    for page in reader.pages:
        current=[];position=None
        def visit(text,cm,tm,font,size):
            nonlocal current,position
            token=text.strip()
            if not token:return
            y=tm[4]*cm[1]+tm[5]*cm[3]+cm[5]
            if position is not None and abs(y-position)>4:
                lines.append(' '.join(current));current=[]
            if not current:position=y
            current.append(token)
        page.extract_text(visitor_text=visit)
        if current:lines.append(' '.join(current))
    return '\n'.join(lines)

def parse(blob,lineup,game,source):
    assert str(lineup['matchId'])==str(game['official_game_id'])
    native=json.loads(game['native_team_ids_json'])
    assert [str(lineup[key]['team']['id']) for key in ['awayTeam','homeTeam']]==list(map(str,native))
    reader=PdfReader(io.BytesIO(blob));text='\n'.join(p.extract_text(extraction_mode='layout') for p in reader.pages)
    if 'PCPA' in text:text=spaced_text(reader)
    assert 'Passing Distribution' in text and 'Total passes received:' in text
    section=-1;rows=[];totals=[];jerseys=[]
    for line in text.splitlines():
        if re.search(r'\bFrom\s+(?:PT|TP)\b',line):
            section+=1;jerseys=list(map(int,re.findall(r'\b\d+\b',line.split('PC')[0])));continue
        if section not in [0,1]:continue
        side='B' if section==0 else 'A';native='homeTeam' if side=='B' else 'awayTeam';team=lineup[native]
        if 'Total passes received:' in line:
            parts=line.split();numbers=parts[-9:-1]
            assert len(numbers)==8 and all(x.isdigit() for x in numbers)
            totals.append((side,dict(zip(FIELDS,map(int,numbers)))))
            continue
        match=re.match(r'^\s*(.*?)\s+(\d+)\s+(\d+)\s*[\'\u2019](\d{2})[\"\u201d]\s+(.*?)\s*$',line)
        if not match:continue
        name,jersey,mins,sec,tail=match.groups();parts=tail.split()
        assert parts[-1].endswith('%') and len(parts)>=9
        numbers=list(map(int,parts[-9:-1]));assert len(numbers)==8
        candidates=[p for kind in ['field','bench'] for p in team.get(kind,[]) if int(p['jerseyNumber'])==int(jersey)]
        assert len(candidates)==1,'Ambiguous jersey mapping'
        p=candidates[0]['player'];official=p.get('internationalName') or p.get('translations',{}).get('name',{}).get('EN')
        similarity,name_evidence=name_check(p,name)
        values=dict(zip(FIELDS,numbers))
        discrepancies=[]
        for a,b in [('long_passes_completed','long_passes'),('medium_passes_completed','medium_passes'),('short_passes_completed','short_passes'),('passes_completed','passes')]:assert values[a]<=values[b]
        for suffix,field in [('passes','passes'),('passes_completed','passes_completed')]:
            total=sum(values[x+'_'+suffix] for x in ['long','medium','short'])
            if total!=values[field]:discrepancies.append(dict(field=field,printed_total=values[field],distance_categories_sum=total))
        accuracy=float(parts[-1][:-1]);expected=100*values['passes_completed']/values['passes'] if values['passes'] else 0
        assert abs(accuracy-expected)<=1.01,'Printed accuracy does not reconcile'
        recipients=[j for j in jerseys if j!=int(jersey)];network={}
        assert len(parts[:-9])==len(recipients),'Incomplete recipient columns'
        for j,value in zip(recipients,parts[:-9]):
            candidates_to=[x for kind in ['field','bench'] for x in team.get(kind,[]) if int(x['jerseyNumber'])==j]
            assert len(candidates_to)==1
            # A printed dash is accepted as no completed passes only when the
            # complete matrix row also reconciles to the explicit PC total.
            network[str(candidates_to[0]['player']['id'])]=0 if value=='-' else int(value)
        complete=sum(network.values())==values['passes_completed']
        if not complete:
            discrepancies.append(dict(field='recipient_matrix',printed_pc=values['passes_completed'],recipient_sum=sum(network.values())))
            network={pid:(None if parts[:-9][j]=='-' else n) for j,(pid,n) in enumerate(network.items())}
        fractions=[n/values['passes_completed'] for n in network.values() if n is not None and n>0] if complete else []
        entropy=-sum(x*math.log(x) for x in fractions) if complete else None
        row=dict(game_id=game['game_id'],official_game_id=game['official_game_id'],side=side,team_id=str(team['team']['id']),official_player_id=str(p['id']),player_name=official,jersey=int(jersey),date=game['date'],league=game['league'],minutes=int(mins)+int(sec)/60,minutes_basis='UEFA report elapsed playing time including stoppage',started=any(str(x['player']['id'])==str(p['id']) for x in team.get('field',[])),pass_accuracy_pct=accuracy,available_at_utc=game['available_time'],source=source,raw_line=line,**values)
        row['passes_to_player_json']=json.dumps(network,sort_keys=True);row['passing_entropy']=entropy;row['passer_concentration']=sum(x*x for x in fractions) if complete else None;row['stat_discrepancies_json']=json.dumps(discrepancies);row['name_match_similarity']=similarity
        row['name_match_evidence']=name_evidence;row['position']=p.get('fieldPosition');row['played']=row['minutes']>0;row['parser_version']=2
        rows.append(row)
    assert section==1 and len(totals)==2 and len(rows)>=22,'Incomplete passing report'
    for side,total in totals:
        for field,value in total.items():
            summed=sum(r[field] for r in rows if r['side']==side)
            if summed!=value:
                for r in rows:
                    if r['side']==side:r['stat_discrepancies_json']=json.dumps(json.loads(r['stat_discrepancies_json'])+[dict(field='team_'+field,printed_total=value,player_sum=summed)])
    # Preserve the report's publication stamp when present. A later revision
    # must not be assigned to an earlier forecast.
    times=re.findall(r'(\d{2}:\d{2}:\d{2})\s*CET',text)
    dates=re.findall(r'\b(\d{1,2}\s+[A-Za-z]{3}\s+\d{4})\b',text)
    published=None
    if times and dates:
        try:published=dt.datetime.strptime(dates[-1]+' '+times[-1],'%d %b %Y %H:%M:%S').replace(tzinfo=ZoneInfo('Europe/Zurich')).astimezone(dt.UTC)
        except ValueError:pass
    for r in rows:
        r['report_published_utc']=published.isoformat() if published else None
        if published:r['available_at_utc']=max(pd.Timestamp(r['available_at_utc']),pd.Timestamp(published)).isoformat()
    return rows

def sources():
    mapping=json.loads((PROJECT/'final_models/sources/path_map.json').read_text());reports={};lineups={}
    with read_db(PROJECT/'collected data/result/player_depth.sqlite') as db:
        for r in db.execute("SELECT request_id,endpoint,raw_file,sha256,retrieved_at_utc FROM source_manifest WHERE status=200 AND endpoint LIKE '%uefa%TPD.pdf'"):
            item=dict(r);raw=item['raw_file'].replace('\\','/')
            for old,new in mapping.items():
                old,new=old.replace('\\','/'),new.replace('\\','/')
                if raw.startswith(old):raw=new+raw[len(old):];break
            item['raw_file']=str(PROJECT/raw);item['url']=item['endpoint'];reports[item['endpoint']]=item
    with read_db(PREVIOUS/'collection.sqlite') as db:
        for r in db.execute("SELECT * FROM requests WHERE status=200 AND url LIKE '%uefa%/lineups'"):lineups[r['url']]=dict(r)
    return reports,lineups

def run(limit,retry_unavailable=False):
    cached,lineups=sources();client=OfficialClient()
    with read_db(PREVIOUS/'expanded.sqlite') as db:games=pd.read_sql_query("SELECT * FROM soccer_games WHERE league='UEFA Champions League' AND date>='2021-01-01' ORDER BY date,game_id",db).to_dict('records')
    db=sqlite3.connect(ROOT_OUT/'uefa_passing.sqlite',timeout=60)
    db.executescript('CREATE TABLE IF NOT EXISTS reports(game_id TEXT PRIMARY KEY,body TEXT);CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,reason TEXT,source_json TEXT);')
    done={r[0] for r in db.execute('SELECT game_id FROM reports')};games=[g for g in games if g['game_id'] not in done]
    if not retry_unavailable:
        unavailable={r[0]:json.loads(r[1]) for r in db.execute("SELECT game_id,source_json FROM issues WHERE reason LIKE '%unavailable: 404'")}
        games=[g for g in games if g['game_id'] not in unavailable or unavailable[g['game_id']].get('url')!=report_url(g)]
    if limit:games=games[:limit]
    print(json.dumps(dict(stage='uefa_passing_start',tasks=len(games),already_done=len(done))),flush=True)
    def fetch(g):
        source=None
        try:
            lu='https://match.uefa.com/v5/matches/'+str(g['official_game_id'])+'/lineups';ls=lineups[lu]
            raw=Path(ls['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==ls['sha256'];lineup=json.loads(raw)
            assert str(lineup['matchId'])==str(g['official_game_id'])
            url=report_url(g)
            if url in cached:
                source=cached[url];blob=Path(source['raw_file']).read_bytes();assert hashlib.sha256(blob).hexdigest()==source['sha256']
            else:blob,source=client.get(url,g['date']+' UEFA match '+str(g['official_game_id'])+' player passing totals',kind='official_uefa_passing_report',document=True)
            if blob is None:raise ValueError('Official report unavailable: '+source['return_status'])
            source=dict(source,lineup_raw_file=ls['raw_file'],lineup_sha256=ls['sha256'])
            return g,parse(blob,lineup,g,source),None,source
        except Exception as e:return g,None,type(e).__name__+': '+str(e),source
    nrows=0;ok=0;errors=0;milestone=10
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        for n,(g,rows,error,source) in enumerate(pool.map(fetch,games),1):
            with db:
                if rows:
                    db.execute('INSERT OR REPLACE INTO reports VALUES (?,?)',(g['game_id'],json.dumps(rows)));db.execute('DELETE FROM issues WHERE game_id=?',(g['game_id'],));ok+=1;nrows+=len(rows)
                else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?,?)',(g['game_id'],error,json.dumps(source)));errors+=1
            if n*100>=len(games)*milestone or n==len(games):
                report=dict(stage='uefa_passing',processed=n,total=len(games),percent=round(n*100/len(games),1),normalized_reports=ok,player_rows=nrows,issues=errors,latest_date=g['date'],at_utc=stamp());dump(ROOT_OUT/'uefa_collection_progress.json',report);print(json.dumps(report),flush=True);milestone+=10
    print(json.dumps(dict(stage='uefa_passing_done',reports=ok,player_rows=nrows,issues=errors)),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int);p.add_argument('--retry-unavailable',action='store_true');a=p.parse_args();run(a.limit,a.retry_unavailable)
