"""One prior-only regulation-tie correction; unchanged NHL scoring fits and bets.

The correction is fitted on the existing purged calibration games, never on the
forecast month. It is a research candidate, not an adopted model or app change.
"""
import json
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from scipy.special import expit, logit
from scipy.stats import skellam
from sklearn.metrics import log_loss
from threadpoolctl import threadpool_limits

import models
from common import ROOT_OUT, dump, stamp, file_sha256
from backtest import quote_inputs, attach, select, simulate
from cash_validation import validate_cash
from final_pipeline import cleanup
from test_nhl_preprocessing import loss_comparison

RESULT = ROOT_OUT/'simulation_results/nhl_tie_distribution'
NAME = 'prior_regulation_tie_offset'


def components(fitted, x):
    away, home = [np.clip(m.predict(x), .05, 15) for m in fitted.models]
    tie = skellam.pmf(0, away, home)
    away_win = skellam.sf(0, away, home)
    home_win = skellam.cdf(-1, away, home)
    ot = fitted.overtime_model.predict_proba(x[fitted.ot_columns])[:, 1]
    return dict(tie=tie, away=away_win, home=home_win, ot=ot)


def corrected(c, offset):
    tie = expit(logit(c['tie'])+offset)
    ratio = (1-tie)/(1-c['tie'])
    probability = np.column_stack([
        ratio*c['away']+tie*(1-c['ot']),
        ratio*c['home']+tie*c['ot']])
    assert np.isfinite(probability).all() and (probability > 0).all()
    assert np.allclose(probability.sum(axis=1), 1, rtol=0, atol=1e-12)
    assert np.allclose(ratio*c['home']/(ratio*c['away']), c['home']/c['away'])
    return probability, tie


def source_audit(frame):
    """Verify every used tie label against the previously replayed raw goals."""
    path = ROOT_OUT/'nhl_regulation_goal_statistics.parquet'
    proof = json.loads((ROOT_OUT/'simulation_results/nhl_goal_target_diagnosis/label_validation.json').read_bytes())
    assert proof['status'] == 'PASS' and file_sha256(path) == proof['source_sha256']
    labels = pd.read_parquet(path).pivot(index='game_id', columns='side', values='regulation_goals')
    labels = labels.loc[frame.game_id]
    for side in ['A', 'B']:
        assert np.array_equal(labels[side], frame['regulation_score'+side])
    decisive = frame.regulation_scoreA.ne(frame.regulation_scoreB)
    assert frame.loc[decisive, 'target'].eq(
        frame.loc[decisive, 'regulation_scoreB'].gt(frame.loc[decisive, 'regulation_scoreA']).astype(int)).all()
    return dict(games=len(frame), label_source_sha256=proof['source_sha256'],
                raw_validation='nhl_goal_target_diagnosis/label_validation.json',
                all_regulation_scores_match=True, decisive_winners_match=True)


def forecasts(frame, stage):
    original = pd.read_parquet(ROOT_OUT/'retained_models/nhl'/(stage+'_predictions.parquet'))
    retained = original[original.variant.eq('granular_regulation_ot')].copy()
    spec = models.CANDIDATES['granular_regulation_ot']
    data = pd.concat([frame, pd.get_dummies(frame.league, prefix='league', dtype=float)], axis=1)
    cols = models.columns(data, spec)
    assert len(cols) == 34
    output, diagnostics = [], []
    for fold, old in retained.groupby('fold', sort=True):
        boundary = pd.Timestamp(fold+'-01', tz='UTC')
        prior = data[data.available_time.lt(boundary)]
        calibration = prior[prior.prediction_time.ge(boundary-pd.Timedelta(days=180))]
        training = prior[prior.available_time.lt(calibration.prediction_time.min())]
        test = data.set_index('game_id').loc[old.game_id]
        assert training.available_time.max() < calibration.prediction_time.min()
        assert calibration.available_time.max() < boundary <= test.prediction_time.min()
        assert prior.available_time.max() < test.prediction_time.min()
        x = lambda f: f[cols].replace([np.inf, -np.inf], np.nan).astype(float)
        with threadpool_limits(limits=4):
            prefit = models.make_model(spec, 'nhl')
            models.fit_model(prefit, x(training), training, spec, calibration.prediction_time.min())
            c = components(prefit, x(calibration))
            raw, unchanged_tie = corrected(c, 0.)
            assert np.allclose(raw, prefit.predict_proba(x(calibration)), atol=1e-12, rtol=0)
            observed = calibration.regulation_scoreA.eq(calibration.regulation_scoreB).to_numpy(int)
            assert 0 < observed.mean() < 1
            offset = brentq(lambda z: expit(logit(c['tie'])+z).mean()-observed.mean(), -30., 30.)
            revised, fitted_tie = corrected(c, offset)
            assert np.isclose(fitted_tie.mean(), observed.mean(), rtol=0, atol=1e-12)
            calibrator = models.calibration_fit(revised, calibration.target.astype(int))
            old_calibrator = models.calibration_fit(raw, calibration.target.astype(int))
            assert np.isclose(old_calibrator['temperature'], old.temperature.iloc[0], rtol=0, atol=1e-8)
            fitted = models.make_model(spec, 'nhl')
            models.fit_model(fitted, x(prior), prior, spec, boundary)
            c = components(fitted, x(test))
            old_raw, old_tie = corrected(c, 0.)
            assert np.allclose(old_raw, fitted.predict_proba(x(test)), rtol=0, atol=1e-12)
            replay = models.apply_calibration(old_raw, old_calibrator)
            assert np.allclose(replay, old[['p0', 'p1']], rtol=0, atol=1e-9)
            revised, revised_tie = corrected(c, offset)
            probability = models.apply_calibration(revised, calibrator)
        out = old.copy()
        out['variant'] = 'candidate'
        out[['p0', 'p1']] = probability
        out['temperature'] = calibrator['temperature']
        out['tie_offset'] = offset
        out['raw_tie_probability'] = old_tie
        out['corrected_tie_probability'] = revised_tie
        out['actual_regulation_tie'] = test.regulation_scoreA.eq(test.regulation_scoreB).to_numpy(int)
        out['tie_calibration_games'] = len(calibration)
        out['tie_calibration_label_max'] = calibration.available_time.max()
        output.append(out)
        diagnostics.append(dict(fold=fold, training_games=len(training), refit_games=len(prior),
            calibration_games=len(calibration), forecast_games=len(test), offset=float(offset),
            calibration_predicted_tie=float(unchanged_tie.mean()), calibration_observed_tie=float(observed.mean()),
            forecast_tie_before=float(old_tie.mean()), forecast_tie_after=float(revised_tie.mean()),
            forecast_observed_tie=float(out.actual_regulation_tie.mean()),
            train_label_max=str(training.available_time.max()), calibration_prediction_min=str(calibration.prediction_time.min()),
            calibration_label_max=str(calibration.available_time.max()), prediction_min=str(test.prediction_time.min())))
        print(json.dumps(dict(stage=stage, fold=fold, forecasts=len(test), tie_offset=round(float(offset), 5))), flush=True)
    candidate = pd.concat(output, ignore_index=True)
    retained['variant'] = 'retained'
    assert candidate.game_id.tolist() == retained.game_id.tolist()
    secondary = original[original.variant.eq('granular_logistic_strong')][['game_id', 'p0', 'p1']].rename(
        columns={'p0':'second_p0', 'p1':'second_p1'})
    p = pd.concat([candidate, retained], ignore_index=True).merge(secondary, on='game_id', validate='many_to_one')
    p.to_parquet(RESULT/(stage+'_predictions.parquet'), index=False)
    models.metrics(p).to_csv(RESULT/(stage+'_metrics.csv'), index=False)
    pd.DataFrame(diagnostics).to_csv(RESULT/(stage+'_folds.csv'), index=False)
    tie_metrics = []
    for year, g in candidate.groupby(candidate.prediction_time.dt.year):
        for name, field in [('retained', 'raw_tie_probability'), ('candidate', 'corrected_tie_probability')]:
            tie_metrics.append(dict(year=int(year), variant=name, games=len(g),
                mean_probability=float(g[field].mean()), observed_rate=float(g.actual_regulation_tie.mean()),
                brier=float(np.square(g[field]-g.actual_regulation_tie).mean()),
                logloss=float(log_loss(g.actual_regulation_tie, g[field], labels=[0, 1]))))
    pd.DataFrame(tie_metrics).to_csv(RESULT/(stage+'_tie_metrics.csv'), index=False)
    return p


def accounts(p, quotes, stage, years):
    joined, audit = attach(p, quotes)
    dump(RESULT/(stage+'_matching.json'), audit)
    annual, trades, curves = [], [], []
    for (provider, variant), g in joined.groupby(['provider', 'variant']):
        chosen = select(g, 'expected_profit')
        second = np.where(chosen.quote_class.eq(0), chosen.second_p0, chosen.second_p1)
        chosen = chosen[second/chosen.entry_price >= 1.10]
        for year in years:
            s, t, c = simulate(chosen, year)
            meta = dict(sport='nhl', provider=provider, variant=variant, recipe='fixed', year=year)
            annual.append(meta|s)
            if len(t): trades.append(t.assign(**meta))
            curves.append(c.assign(**meta))
    a = pd.DataFrame(annual)
    t, c = pd.concat(trades, ignore_index=True), pd.concat(curves, ignore_index=True)
    cash = validate_cash(t, c)
    reference = pd.read_csv(ROOT_OUT/'simulation_results/current/annual.csv')
    for r in a[a.variant.eq('retained')].itertuples():
        old = reference[reference.sport.eq('nhl')&reference.provider.eq(r.provider)&reference.year.eq(r.year)].iloc[0]
        for field in ['bets', 'win_rate_pct', 'return_pct', 'sharpe', 'max_drawdown_pct']:
            assert np.isclose(getattr(r, field), old[field], atol=1e-10, rtol=0, equal_nan=True)
    a.to_csv(RESULT/(stage+'_annual.csv'), index=False)
    t.to_parquet(RESULT/(stage+'_bets.parquet'), index=False)
    c.to_parquet(RESULT/(stage+'_daily.parquet'), index=False)
    return a, cash


def main():
    assert not (RESULT/'validation.json').exists(), 'Completed experiment must not be overwritten'
    RESULT.mkdir(exist_ok=True)
    source = ROOT_OUT/'retained_models/nhl/nhl_features.parquet'
    digest = file_sha256(source)
    frame = pd.read_parquet(source)
    proof = source_audit(frame)
    plan = dict(at_utc=stamp(), hypothesis='Independent goal counts underpredict regulation ties; test one earlier-only log-odds tie intercept.',
        formula='d_new=expit(logit(d_old)+offset); rescale both regulation-win probabilities by (1-d_new)/(1-d_old); retain conditional overtime winner; refit final temperature on earlier calibration only.',
        offset_fit='Match tie frequency on the existing purged trailing180day calibration games, using goal models fitted before those games. One offset; no hyperparameter search.',
        history='2021 onward; monthly expanding forecasts from2024; all labels strictly before prediction.',
        source_sha256=digest, source_validation=proof,
        selection='Probability-only: lower winner logloss in each2024/25year and pooled, plus >=52% pooled winner accuracy. Returns cannot select the model. Evaluate2026 only if this gate passes.',
        accuracy_definition='Fraction of ALL evaluated games with argmax probability matching the official final winner; not a betting probability floor.',
        fixed='Same34inputs, both Poisson goal models and overtime logistic; same secondary model; pre12 closest prior quote<=24hage; both p/price>=1.10;1%NAV,20%open-cost cap; separate providers; no costs.',
        inference='Tie labels are actual regulation draws, not inferred from close final scores. Already replayed official goal events are the source.',
        caveat='2026 is repeatedly researched retrospective evidence, not untouched confirmation. No automatic adoption; app unchanged.')
    dump(RESULT/'plan.json', plan)
    p = forecasts(frame, 'development')
    loss = loss_comparison(p)
    metric = models.metrics(p)
    annual_loss = metric.pivot(index='year', columns='variant', values='log_loss')
    candidate = p[p.variant.eq('candidate')]
    accuracy = float((candidate[['p0','p1']].to_numpy().argmax(axis=1)==candidate.target.to_numpy()).mean())
    passed = bool(annual_loss.candidate.lt(annual_loss.retained).all() and loss['paired_loss_change'] < 0 and accuracy >= .52)
    quotes = quote_inputs(RESULT/'quote_quality.json', revision='closest_v62')
    a, cash = accounts(p, quotes, 'development', [2024, 2025])
    decision = dict(at_utc=stamp(), status='PASS', development_probability_gate_passed=passed,
        loss=loss, overall_winner_accuracy=accuracy, calibration_and_fit_cutoffs_verified=True,
        baseline_forecasts_replayed=len(candidate), baseline_accounts_replayed=True, cash_days=cash,
        evaluated2026=False, adopted=False, no_fit_files_written=True)
    print(a.to_string(index=False), flush=True)
    if passed:
        ep = forecasts(frame, 'evaluation')
        ea, ec = accounts(ep, quotes, 'evaluation', [2026])
        decision.update(evaluated2026=True, evaluation_loss=loss_comparison(ep), evaluation_cash_days=ec)
        print(ea.to_string(index=False), flush=True)
    assert file_sha256(source) == digest
    dump(RESULT/'validation.json', decision)
    ledger_path = ROOT_OUT/'simulation_results/experiment_results.csv'
    ledger = pd.read_csv(ledger_path, low_memory=False)
    for stage in ['development']+(['evaluation'] if passed else []):
        for kind in ['metrics', 'annual', 'tie_metrics']:
            key = RESULT.name+'/'+stage+'_'+kind+'.csv'
            ledger = pd.concat([ledger[~ledger.source_result_file.eq(key)],
                pd.read_csv(RESULT/(stage+'_'+kind+'.csv')).assign(source_result_file=key)], ignore_index=True)
    ledger.to_csv(ledger_path, index=False)
    path = ROOT_OUT/'simulation_results/experiment_decisions.json'
    records = json.loads(path.read_bytes())
    records[RESULT.name] = dict(plan=plan, decision=decision)
    dump(path, records)
    cleanup()
    print(json.dumps(decision), flush=True)


if __name__ == '__main__':
    main()
