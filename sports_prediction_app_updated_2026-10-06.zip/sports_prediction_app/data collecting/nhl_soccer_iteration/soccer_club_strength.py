"""Test earlier official UEFA club coefficients alongside dated sports history."""
import argparse
import json
import copy
import pickle
import numpy as np
import pandas as pd
from common import ROOT_OUT,PROJECT,read_db,dump,stamp,file_sha256

LABEL='soccer_club_strength'
WORK=ROOT_OUT/'_work'/LABEL
RESULT=ROOT_OUT/'simulation_results/feature_revisions'/LABEL
FEATURES=['f_ctx_uefa_log_strength_diff','f_ctx_uefa_log_strength_sum']
ASSOCIATIONS={'Premier League':'ENG','La Liga':'ESP','Bundesliga':'GER','Serie A':'ITA','Ligue 1':'FRA'}


def coefficients(games,ranking,registry):
    from features import LEAGUE_CODE
    snapshots={}
    for year,f in ranking.groupby('ranking_season_year'):
        assert f.available_after_utc.nunique()==1
        values=f.groupby('country_code').association_floor
        assert values.nunique().eq(1).all()
        snapshots[int(year)]=(pd.Timestamp(f.available_after_utc.iloc[0]),
            f.set_index('uefa_club_id').to_dict('index'),values.first().to_dict())
    rows=[];audit=[]
    for r in games.itertuples():
        allowed=[year for year,(clock,_,_) in snapshots.items() if clock<r.prediction_time]
        assert allowed,'The2020snapshot must precede every2021forecast'
        year=max(allowed);clock,clubs,floors=snapshots[year];parts={}
        for side,native in zip(['A','B'],json.loads(r.native_team_ids_json)):
            identity=registry.get((LEAGUE_CODE[r.league],str(native)),{})
            uid=str(native) if r.league=='UEFA Champions League' else identity.get('uefa_id')
            if uid is None and str(identity.get('team_id','')).startswith('EU_UEFA_CLUB:'):
                uid=identity['team_id'].split(':')[-1]
            uid=str(uid) if uid is not None else None
            observed=clubs.get(uid)
            country=observed['country_code'] if observed else ASSOCIATIONS.get(r.league)
            if observed:
                value=observed['seeding_coefficient'];basis='dated_official_club_and_association_floor'
            elif country in floors:
                value=floors[country];basis='documented_association_floor_no_ranked_club_match'
            else:
                value=np.nan;basis='native_club_not_in_eligible_snapshot_and_association_unverified'
            parts[side]=value
            audit.append(dict(game_id=r.game_id,cutoff_utc=r.prediction_time,side=side,league=r.league,
                native_team_id=str(native),uefa_club_id=uid,ranking_season_year=year,
                ranking_available_after_utc=clock,country_code=country,seeding_coefficient=value,basis=basis,
                source_request_number=observed['source_request_number'] if observed else None))
        # Log transform reduces the leverage of high coefficients. Undefined
        # source matches remain NaN for the unchanged earlier-only imputer.
        a,b=np.log1p(parts['A']),np.log1p(parts['B'])
        rows.append(dict(game_id=r.game_id,**{FEATURES[0]:b-a,FEATURES[1]:b+a}))
    return pd.DataFrame(rows).set_index('game_id'),pd.DataFrame(audit)


def build():
    import loss_case_revision as case
    assert not WORK.exists() and not (RESULT/'validation.json').exists()
    RESULT.mkdir(exist_ok=True)
    case.WORK=WORK;case.RESULT=RESULT
    case.sources();case.build()
    g=pd.read_pickle(WORK/'games.pkl')
    ranking=pd.read_parquet(ROOT_OUT/'soccer_uefa_club_coefficients.parquet')
    proof=json.loads((ROOT_OUT/'retention/uefa_club_coefficients_validation.json').read_bytes())
    assert proof['status']=='PASS' and proof['output_sha256']==file_sha256(ROOT_OUT/'soccer_uefa_club_coefficients.parquet')
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
        registry={(code,str(native)):json.loads(body) for code,native,body in db.execute('SELECT * FROM _eu_team_identity')}
    features,audit=coefficients(g,ranking,registry)
    baseline=pd.read_parquet(WORK/'candidate/soccer_features.parquet').set_index('game_id')
    frame=baseline.join(features,validate='one_to_one')
    assert frame.drop(columns=FEATURES).equals(baseline)
    cut=pd.Timestamp('2025-01-01',tz='UTC');early=g[g.prediction_time.lt(cut)]
    prefix,_=coefficients(early,ranking[pd.to_datetime(ranking.available_after_utc,utc=True).lt(cut)],registry)
    pd.testing.assert_frame_equal(prefix,features.loc[prefix.index],check_exact=True)
    models_dir=WORK/'club_strength';models_dir.mkdir();frame.reset_index().to_parquet(models_dir/'soccer_features.parquet',index=False)
    audit.to_parquet(RESULT/'coefficient_feature_evidence.parquet',index=False)
    count=audit.groupby(['league','basis']).size().rename('team_sides').reset_index();count.to_csv(RESULT/'source_coverage.csv',index=False)
    dump(RESULT/'coefficient_feature_validation.json',dict(status='PASS',at_utc=stamp(),games=len(frame),
        source_rows=len(ranking),source_sha256=proof['output_sha256'],feature_sha256=file_sha256(models_dir/'soccer_features.parquet'),
        unchanged_existing_inputs=True,prefix_invariant_games=len(prefix),
        snapshot_before_forecast=bool(audit.ranking_available_after_utc.lt(audit.cutoff_utc).all()),
        missing_pct={c:100*float(frame[c].isna().mean()) for c in FEATURES},
        basis='Annual club coefficient, floored by supplied association contribution. Unknown club identity in a domestic league uses only its documented association floor; club points are not invented.'))
    print(count.to_string(index=False),flush=True)


def train():
    import models
    from sklearn.metrics import log_loss
    import soccer_club_history_model as paired
    import soccer_tie_context as simulation
    work=WORK/'club_strength'
    assert (RESULT/'coefficient_feature_validation.json').exists() and not (RESULT/'validation.json').exists()
    prior=ROOT_OUT/'simulation_results/loss_case_revision'
    recipe=json.loads((prior/'experiment_plan.json').read_bytes())['recipe']
    recipe=copy.deepcopy(recipe);recipe['preserve_unit_columns']+=FEATURES
    dump(RESULT/'experiment_plan.json',dict(at_utc=stamp(),hypothesis='Sparse European-club histories start at neutral Elo and may misstate strength across associations. Add two log-coefficient team-strength inputs from official historical UEFA snapshots with conservative source-update clocks.',
        new_features=FEATURES,recipe=recipe,reference='Coverage-adjusted latest39-input soccer recipe; same physical-coverage correction in control and candidate.',
        train_from='2021-01-01',predictions_from='2024-01-01',gate='Lower pooled2024/25multiclass logloss AND Brier than coverage-adjusted comparator and original additional-club-history comparator. No price or return model selection.',
        availability='Require official lastUpdateDate and conservative season completion before forecast; do not backdate later API revisions.',
        staking='Unchanged$5per percentage point of positive model-price difference, one outcome by unchanged expected-log-growth selection, pre12, cashonly$2000annual reset, providers separated, no costs.',
        evaluation='2026only after development gate; repeatedly inspected retrospective period, not untouched.',app_changed=False))
    name='official_club_strength';models.CANDIDATES[name]=recipe;models.OUT=work
    candidate=models.run('soccer','development',[name]);candidate['variant']='candidate'
    references=pd.read_parquet(prior/'development_predictions.parquet')
    references['variant']=references.variant.map({'candidate':'coverage_reference','reference':'original_reference'})
    joined=pd.concat([candidate,references],ignore_index=True)
    joined.to_parquet(RESULT/'development_predictions.parquet',index=False);models.metrics(joined).to_csv(RESULT/'development_metrics.csv',index=False)
    scores={}
    for variant,f in joined.groupby('variant'):
        p=f[['p0','p1','p2']].to_numpy();y=f.target.to_numpy(int)
        scores[variant]=dict(log_loss=log_loss(y,p,labels=[0,1,2]),brier=float(np.mean(np.sum((p-np.eye(3)[y])**2,axis=1))))
    passed=all(scores['candidate'][metric]<scores[v][metric] for v in ['coverage_reference','original_reference'] for metric in ['log_loss','brier'])
    paired.RESULT=RESULT;delta=paired.paired_comparison(candidate,references[references.variant.eq('coverage_reference')])
    dump(RESULT/'selection.json',dict(at_utc=stamp(),passed=bool(passed),scores=scores,paired=delta,adopted=False))
    package=pickle.loads((work/'model_runs/soccer/development'/(name+'.pkl')).read_bytes())
    frame=pd.read_parquet(work/'soccer_features.parquet');matrix=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
    sample=candidate[candidate.fold.eq(package['boundary'].strftime('%Y-%m'))].head(20)
    x=matrix.loc[sample.game_id,package['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
    replay=models.apply_calibration(package['model'].predict_proba(x),package['calibrator'])
    assert np.allclose(replay,sample[['p0','p1','p2']],atol=1e-12,rtol=0)
    assert candidate.train_label_max.lt(candidate.prediction_time).all() and candidate.calibration_label_max.lt(candidate.prediction_time).all()
    evaluation=None
    if passed:
        dump(work/'soccer_selection.json',dict(selected_candidates=[name]));test=models.run('soccer','evaluation',[name]);test['variant']='candidate'
        refs=pd.read_parquet(prior/'evaluation_predictions.parquet');refs['variant']=refs.variant.map({'candidate':'coverage_reference','reference':'original_reference'})
        evaluation=pd.concat([test,refs],ignore_index=True);evaluation.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
        models.metrics(evaluation).to_csv(RESULT/'evaluation_metrics.csv',index=False)
    simulation.RESULT=RESULT;simulation.simulate(joined,evaluation)
    dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),development_gate_passed=bool(passed),
        evaluated2026=bool(passed),inputs=len(package['columns']),forecast_replays=len(sample),
        feature_proof=json.loads((RESULT/'coefficient_feature_validation.json').read_bytes()),adopted=False,app_changed=False))
    print(json.dumps(dict(passed=bool(passed),scores=scores)),flush=True)


def diagnose():
    """Retain all-game diagnostics plus a independently dated squad example.

    The example explains omitted information; it is never a bespoke trade
    exclusion or a substitute for collecting a systematic historical source.
    """
    import re
    from html import unescape
    from sklearn.metrics import log_loss
    from common import OfficialClient
    rows=[]
    for period in ['development','evaluation']:
        frame=pd.read_parquet(RESULT/(period+'_predictions.parquet'))
        for (variant,league),g in frame.groupby(['variant','league']):
            p=g[['p0','p1','p2']].to_numpy();y=g.target.to_numpy(int)
            rows.append(dict(period=period,variant=variant,league=league,games=len(g),
                log_loss=log_loss(y,p,labels=[0,1,2]),accuracy=float(np.mean(p.argmax(axis=1)==y)),
                mean_draw_probability=float(g.p2.mean()),observed_draw_fraction=float(np.mean(y==2))))
    pd.DataFrame(rows).to_csv(RESULT/'competition_metrics.csv',index=False)
    bets=pd.read_parquet(RESULT/'bets.parquet');f=bets[bets.variant.eq('candidate')&bets.year.eq(2025)].copy()
    f['edge_bucket']=pd.cut(f.edge,[-1,0,.05,.10,.20,.30,1]).astype(str)
    f.groupby(['provider','edge_bucket']).agg(bets=('won','size'),wins=('won','sum'),
        win_rate=('won','mean'),mean_probability=('probability','mean'),mean_price=('price','mean'),
        stake=('stake','sum'),profit=('profit','sum')).reset_index().to_csv(RESULT/'development_edge_diagnosis.csv',index=False)

    game='UCL_20250129_LIV_PSV';cut=pd.Timestamp('2025-01-29T08:00:00Z')
    OfficialClient.HOSTS.add('www.liverpoolfc.com');client=OfficialClient()
    url='https://www.liverpoolfc.com/news/liverpool-name-21-man-squad-ucl-trip-psv-eindhoven'
    raw,source=client.get(url,'Verify complete travelling squad published before PSV Liverpool pre12 entry','official_loss_case_validation',document=True)
    assert source['return_status']=='200';body=raw.decode('utf8')
    published=pd.Timestamp(re.search(r'"datePublished":"([^"]+)"',body)[1])
    modified=pd.Timestamp(re.search(r'"dateModified":"([^"]+)"',body)[1])
    assert published<cut and modified<cut
    match=re.search(r'<strong>Liverpool squad:</strong>\s*([^<]+)</p>',body)
    assert match
    squad=[unescape(x.strip().rstrip('.')) for x in match[1].split(',')];assert len(squad)==21
    # Explicit native-ID/name crosswalk for this manual validation only. These
    # names match the earlier official player rows; no fuzzy production joins.
    present={'EU_PL:243298':'Gakpo','EU_PL:122798':'Robertson','EU_PL:214285':'Tsimikas',
        'EU_PL:447203':'Nunez','EU_PL:441428':'Quansah','EU_PL:492777':'Bradley',
        'EU_PL:444884':'Elliott','EU_PL:158983':'Endo','EU_PL:223541':'Chiesa','EU_PL:500058':'Danns'}
    assert set(present.values()).issubset(set(squad))
    games=pd.read_pickle(WORK/'games.pkl');meta=json.loads((WORK/'sources_ready.json').read_bytes())
    keys={(a,b):c for a,b,c in meta['keys']};team=keys[game,'A'];history=[]
    for r in games[games.available_time.lt(cut)].itertuples():
        for side in ['A','B']:
            if keys[r.game_id,side]==team:history.append(dict(game_id=r.game_id,side=side,available_time=r.available_time))
    last=pd.DataFrame(history).sort_values('available_time').tail(5)
    players=pd.read_pickle(WORK/'players.pkl').merge(last[['game_id','side']],on=['game_id','side'])
    players=players[players.minutes.gt(0)]
    assert pd.to_datetime(players.available_at_utc,utc=True).lt(cut).all()
    roster=players.groupby(['player_id','player_name']).minutes.sum().rename('recent_pool_minutes').reset_index()
    roster['travelling_squad_name']=roster.player_id.map(present)
    roster['in_announced_travelling_squad']=roster.travelling_squad_name.notna()
    roster['game_id']=game;roster['cutoff_utc']=cut;roster['source_request_number']=source['request_number']
    roster.to_parquet(RESULT/'rotation_case_roster.parquet',index=False)
    missing=roster[~roster.in_announced_travelling_squad]
    assert len(roster)==21 and len(missing)==11
    p=pd.read_parquet(RESULT/'development_predictions.parquet')
    forecasts=p[p.game_id.eq(game)][['variant','p0','p1','p2']].to_dict('records')
    b=bets[bets.game_id.eq(game)&bets.provider.eq('polymarket')]
    public_context='https://www.liverpoolfc.com/news/psv-eindhoven-v-liverpool-champions-league-team-news'
    raw2,src2=client.get(public_context,'Validate rotation context and check later page revision clock','official_loss_case_validation',document=True)
    modified2=pd.Timestamp(re.search(r'"dateModified":"([^"]+)"',raw2.decode('utf8'))[1])
    assert modified2>cut
    dump(RESULT/'rotation_case_validation.json',dict(status='PASS',at_utc=stamp(),game_id=game,
        forecast_cutoff_utc=cut,published_at_utc=published,last_modified_utc=modified,
        squad_source=source,squad=squad,all_source_clocks_before_cutoff=True,
        preceding_game_ids=last.game_id.tolist(),recent_pool_players=len(roster),
        recent_pool_players_not_in_travelling_squad=len(missing),
        recent_pool_minute_share_not_travelling=float(missing.recent_pool_minutes.sum()/roster.recent_pool_minutes.sum()),
        forecasts=forecasts,positions=b[['variant','side','probability','price','stake','profit']].to_dict('records'),
        context_page_source=src2,context_page_modified_utc=modified2,
        context_page_excluded_as_pregame_evidence=True,
        qualification='The separate squad announcement has both publication and modification before entry. The general team-news page was updated after entry, so it is contextual only.',
        used_for_model_or_trade_filter=False,
        interpretation='Recent player-pool strength assumes prior contributors remain available. A dated official squad announcement contradicts that assumption for this game. It is evidence of an omitted pregame input, not proof that rotation caused the loss or that a squad feature will improve overall returns.'))
    print(json.dumps(dict(status='PASS',recent_players_not_travelling=len(missing),
        recent_minutes_not_travelling_pct=100*float(missing.recent_pool_minutes.sum()/roster.recent_pool_minutes.sum()))),flush=True)


def finish():
    from pathlib import Path
    from common import REPORTS
    from final_pipeline import discard_work,cleanup,validate
    from publish import main as catalog
    for path in [RESULT/'validation.json',RESULT/'cash_validation.json',RESULT/'rotation_case_validation.json',
                 ROOT_OUT/'retention/uefa_club_coefficients_validation.json',ROOT_OUT/'retention/uefa_coefficients_public_validation.json']:
        assert json.loads(path.read_bytes())['status']=='PASS'
    selection=json.loads((RESULT/'selection.json').read_bytes())
    evidence=json.loads((RESULT/'rotation_case_validation.json').read_bytes())
    proof=json.loads((RESULT/'coefficient_feature_validation.json').read_bytes())
    a=pd.read_csv(RESULT/'annual.csv')
    def table(frame):
        def fmt(x):return f'{x:.4f}' if isinstance(x,(float,np.floating)) else str(x)
        return '\n'.join(['| '+' | '.join(frame.columns)+' |','| '+' | '.join(['---']*len(frame.columns))+' |']+
            ['| '+' | '.join(map(fmt,row))+' |' for row in frame.itertuples(index=False,name=None)])
    score=pd.DataFrame([{'model':k,**v} for k,v in selection['scores'].items()])
    public='https://www.liverpoolfc.com/news/liverpool-name-21-man-squad-ucl-trip-psv-eindhoven'
    lines=['# Soccer club strength and loss investigation','',
        'Historical UEFA club rankings improve the earlier probability scores but do not improve later forecast loss or meet the Sharpe target. The experiment is not adopted. The NBA/MLB app and frozen research baselines are preserved.','',
        '## What changed and why','',
        'Sparse European club histories can make neutral initial Elo ratings misleading when clubs from different associations meet. We collected seven official UEFA five-season ranking snapshots, 2020–2026, containing 2,968 club records. The two new model inputs are the home-minus-away difference and sum of log(1 + club seeding coefficient). The existing 39-input recipe, including its three corrected roster-coverage features, becomes 41 inputs. There is no price predictor.','',
        'The official public website uses `https://comp.uefa.com/v2/coefficients`, with `coefficientRange=OVERALL`, `coefficientType=MEN_CLUB`, `seasonYear`, `page`, `pagesize=500`, and `language=EN`. This official website service is not a promised stable developer API. Seven full pages plus seven empty terminal pages verify pagination. Original responses are saved before normalization. Every normalized row was replayed against its raw response; nine selected values from 2021, 2024 and 2025 agree with three official published reports. Documentation and exact source URLs are in the collector README and validation receipts.','',
        'Some historical tables were revised much later than their season ended. A snapshot enters a forecast only after BOTH season completion and its recorded API lastUpdateDate. Publication and retrieval clocks remain separate. This avoids backdating a later revision, although it intentionally understates when an earlier version may first have been available. Own club points, association floor, reported total and the final floored coefficient are separate columns.','',
        'Native UEFA IDs link clubs. A known domestic association with no matching ranked club uses only its documented association floor, not invented club points. Unknown cup-club identity and association remain missing for the existing earlier-fitted imputer. Source coverage by competition and each feature missing percentage are retained.','',
        table(pd.read_csv(RESULT/'source_coverage.csv')),'',
        '## Rolling comparison','',
        'Training expands from 2021. Forecasts start in 2024, with monthly refits and earlier purged calibration games. All training and calibration labels precede each forecast. The 2024–2025 joint logloss/Brier gate was written before fitting. The candidate passed both metrics against both controls; its paired logloss change is −0.003930, with an unadjusted monthly-block 95% interval [−0.007793, −0.000451]. This interval is not corrected for repeated experiments.','',
        table(score),'',
        'The Champions League development logloss improves from about 0.9571 to 0.9392. In 2026, overall candidate logloss is 1.001317 versus 1.000527 for the coverage control; overall accuracy is unchanged at 51.01%. Thus the earlier gain does not carry forward. 2026 has already been examined in previous research and is a retrospective rolling evaluation, not an untouched strategy holdout.','',
        '## Same betting rule, chronological accounts','',
        'Each year starts with $2,000. Request $5 per percentage point of positive model probability minus price; use the unchanged expected-log-growth choice of one outcome, which can be an underdog or draw. The stake stays in dollars as the account changes. Buy at pre-12 using the latest earlier quote no older than 24 hours; settle at official result availability. Cash is not borrowed and unsettled proceeds are not reused. No costs or spread assumptions are added. Providers stay separate.','',
        table(a[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        'Polymarket inputs are international historical token prices, not verified executable US quotes. Kalshi inputs are YES asks. Open positions are marked at purchase cost. Sharpe uses actual calendar daily returns including idle days and sqrt(365.25); 2026 ends on September 29, so returns are partial-year, not annualized. The high 2026 drawdowns prevent treating the positive account returns as a satisfactory strategy.','',
        '## A losing case with missing pregame information','',
        'For Liverpool at PSV on January 29, 2025, the revised model assigned Liverpool 56.48% against a $0.31 historical quote. Its $127.41 purchase lost. This was not just an unexplained score upset: the model used recent contributors without incorporating a documented change in available players.','',
        f'[Liverpool’s official travelling squad]({public}) was published at 16:54 UTC and last modified at 19:49:43 UTC on January 28, both before the January 29 08:00 UTC pre-12 decision. Eleven of the 21 players in the model’s five-game recent pool were absent from that complete travelling list. They account for {100*evidence["recent_pool_minute_share_not_travelling"]:.2f}% of the pool’s recorded minutes. The case audit preserves native player IDs, names, earlier minutes, squad membership and source clocks.','',
        'The separate general team-news article was modified after the decision and is excluded as pregame evidence. The earlier squad announcement independently supports the omission. Rotation is a plausible omitted input, not proof of the true win probability or that this loss was inevitable. We do not remove this match or retrofit its squad into the full backtest.','',
        'The next model revision should collect systematically dated squad availability, then discount unavailable player contributions before forecasting. News chosen only because a game lost would create selection bias. Missing announcements cannot be interpreted as full squad availability. The present evidence justifies testing that feature, not a winning claim.','',
        '## Retention and validation','',
        'The new SQL table is `soccer_uefa_club_coefficients`. The catalog contains the fields, units, source and missing percentages. Raw evidence, published source tables, experiment forecasts, cash validation and reproducing code remain. Trial fits, duplicate feature matrices and internal source caches are deleted after validation. Reproduce with `collect_uefa_coefficients.py`, its `--validate-public` option, then `soccer_club_strength.py build`, `train`, `diagnose`, and `finish`.','',
        'NHL is unchanged by this soccer experiment. Its retained fixed-$20 dual-model agreement comparator remains at 2026 Polymarket return +37.41%, Sharpe 2.11 and maximum drawdown 12.09%. The aggregate winner classifier and selected-bet win rate are different quantities. No losing team or calendar month was filtered using later outcomes.','']
    report=REPORTS/(LABEL+'.md');report.write_text('\n'.join(lines),encoding='utf8')
    code=Path(__file__).resolve().parent;readme=code/'README.md';body=readme.read_text(encoding='utf8')
    marker='## Official historical club rankings and rotation evidence'
    if marker not in body:
        body+='\n\n'+marker+'\n\n'+(
            '`collect_uefa_coefficients.py` collects official 2020–2026 UEFA club coefficient snapshots with raw-first storage, pagination and native club IDs. The API update clock gates historical model use. `soccer_club_strength.py` builds two dated strength inputs, runs monthly expanding comparisons, diagnoses losses and publishes/cleans the completed run. Nine values from three official dated reports are independently checked.\n\n'
            'Run the collector, then `collect_uefa_coefficients.py --validate-public`, then `soccer_club_strength.py build`, `train`, `diagnose`, `finish`. See `reports/nhl_soccer_iteration/soccer_club_strength.md`.\n\n'
            'Current official documentation and service: https://www.uefa.com/nationalassociations/uefarankings/club/ ; https://comp.uefa.com/v2/coefficients ; https://documents.uefa.com/r/Regulations-of-the-UEFA-Champions-League-2026/27/D.2-Reference-periods-for-rankings-Online ; https://documents.uefa.com/r/Regulations-of-the-UEFA-Champions-League-2026/27/D.4-Club-coefficient-calculation-Online . The official browser client supplies endpoint parameters; exact discovery URLs and hashes are in `retention/uefa_coefficients_source_probe.json`. The current regulations explain the concept; historical values come from the API, not recalculation using current rules.\n\n'
            'Manual validation: https://www.uefa.com/uefachampionsleague/news/026b-12a6cf1883a5-902841e42354-1000--2021-22-group-stage-as-it-stands/ ; https://es.uefa.com/uefachampionsleague/news/0270-14127d1d4632-c8e93067d4dd-1000--ranking-uefa-clasificacion-novedades-equipos/ ; https://www.realmadrid.com/es-ES/noticias/futbol/primer-equipo/actualidad/el-real-madrid-cierra-la-temporada-lider-del-ranking-uefa-03-06-2025 .\n\n'
            'Dated squad case: '+public+' ; https://www.liverpoolfc.com/news/psv-eindhoven-v-liverpool-champions-league-team-news . The latter page has a post-decision modification and is excluded from pregame evidence. Neither page is a selectively added model feature.\n')
        readme.write_text(body,encoding='utf8')
    # Full coverage evidence is already preserved by the preceding source
    # correction. Remove this exact duplicate only after content/hash replay.
    duplicate=RESULT/'roster_coverage_audit.parquet';canonical=ROOT_OUT/'simulation_results/loss_case_revision/roster_coverage_audit.parquet'
    if duplicate.exists():
        pd.testing.assert_frame_equal(pd.read_parquet(duplicate),pd.read_parquet(canonical),check_exact=True)
        dump(RESULT/'roster_coverage_reference.json',dict(path=str(canonical.relative_to(ROOT_OUT)),sha256=file_sha256(canonical),duplicate_exactly_replayed=True))
        resolved=duplicate.resolve();assert resolved.parent==RESULT.resolve() and resolved.is_relative_to(ROOT_OUT.resolve())
        assert not duplicate.is_symlink() and not duplicate.is_junction()
        resolved.unlink()
    failures_path=ROOT_OUT/'simulation_results/failed_runs.json';failures=json.loads(failures_path.read_bytes())
    if not any(x.get('experiment')==LABEL and x.get('stage')=='public_page_parser' for x in failures):
        failures.append(dict(at_utc=stamp(),experiment=LABEL,stage='public_page_parser',resolved=True,
            errors=['Optional bs4 dependency absent','HTMLParser received bytes instead of decoded text','Finish imported a nested path guard as a module function'],
            resolution='Use stdlib HTMLParser with decoded visible text; all nine name/value pairs verified. Finish validates the absolute duplicate target inside its research folder directly.'))
        dump(failures_path,failures)
    catalog()
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        tables=db.execute('SELECT COUNT(*) FROM table_catalog').fetchone()[0]
        columns=db.execute('SELECT COUNT(*) FROM column_catalog').fetchone()[0]
    verification=validate()
    hashes={str(p.relative_to(RESULT)):file_sha256(p) for p in RESULT.rglob('*') if p.is_file()}
    if WORK.exists():discard_work(WORK)
    cleanup()
    manifest_path=ROOT_OUT/'retention/retained_artifacts.json';manifest=json.loads(manifest_path.read_bytes())
    manifest['scripts']={p.name:file_sha256(p) for p in sorted(code.glob('*.py'))}
    manifest.update(retained_scripts=len(manifest['scripts']),final_tables=tables,current_sql_columns=columns,updated_utc=stamp())
    manifest['latest_simulation_update']=dict(at_utc=stamp(),report=str(report),result=str(RESULT.relative_to(ROOT_OUT)),
        new_table='soccer_uefa_club_coefficients',protected_app_files_verified=verification['protected_app_files'],app_health=verification['app_health'])
    dump(manifest_path,manifest)
    state_path=ROOT_OUT/'research_continuation.json';state=json.loads(state_path.read_bytes())
    state.update(current_job=None,running_jobs=[],live_sessions=[],terminal_sessions=[],final_sql_tables=tables,final_sql_columns=columns,
        next_action='Systematically acquire pre-decision squad availability/rotation evidence for soccer. The Liverpool PSV loss has a complete official prior squad list showing 11 recent-pool contributors absent; do not cherry-pick losses as training rows. The official coefficient candidate improves earlier loss but fails later probabilities and risk. Preserve NHL fixed20 agreement comparator; no app changes.',report=str(report),
        previous_goal_turn=dict(progress='Collected and raw-replayed2968official club rankings; evaluated41-input rolling model and same accounts; verified a dated omitted-squad cause; no target attainment.',oos='2024/25selection;2026repeated retrospective rolling evaluation. No adoption.'))
    research=state.setdefault('research_state',{})
    research['soccer_latest_best_probability_candidate']=dict(result=str(RESULT.relative_to(ROOT_OUT)),earlier_loss=selection['scores']['candidate']['log_loss'],
        earlier_reference_loss=selection['scores']['coverage_reference']['log_loss'],evaluation2026_accuracy=.5100864553314121,
        pm2026_return_pct=float(a.loc[a.provider.eq('polymarket')&a.variant.eq('candidate')&a.year.eq(2026),'return_pct'].iloc[0]),
        pm2026_sharpe=float(a.loc[a.provider.eq('polymarket')&a.variant.eq('candidate')&a.year.eq(2026),'sharpe'].iloc[0]),adopted=False,app_changed=False)
    research['no_running_jobs']=True;research['previous_goal_turn_classification']='progress: new dated official data, controlled model/account evaluation and concrete loss evidence; not blocked.'
    dump(state_path,state)
    receipt=dict(status='PASS',at_utc=stamp(),report=str(report),result_hashes=hashes,source_rows=2968,
        public_value_replays=9,rolling_forecast_replays=20,temporary_work_removed=not WORK.exists(),
        final_sql_tables=tables,final_sql_columns=columns,app_validation=verification,target_achieved=False)
    dump(ROOT_OUT/'retention/club_strength_completion.json',receipt)
    dump(ROOT_OUT/'retention/current_update_receipt.json',receipt)
    print(json.dumps({k:v for k,v in receipt.items() if k not in ['result_hashes','app_validation']}),flush=True)


if __name__=='__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf8')
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['build','train','diagnose','finish']);a=p.parse_args();globals()[a.stage]()
