"""Past-only on-ice shot contribution test; no price-based player fitting.

Event-weighted effects are not per-minute RAPM. Actual ten-skater membership
controls teammate/opponent composition; pre-event score controls score effects.
Each historical game receives total regression weight one.
"""
import argparse,json,pickle,shutil
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.linear_model import Ridge
from threadpoolctl import threadpool_limits
from common import ROOT_OUT,REPORTS,read_db,dump,stamp,file_sha256
import nhl_player_strength as roster
from nhl_joint_chances import WORK,RESULT,EVENTS,COVERAGE
from forecast_pairing import PRIMARY,SECOND,paired_predictions

FIELDS=['f_gran_joint_onice_attempt_share','f_gran_joint_onice_chance_quality']
CONTROL={PRIMARY:'joint_control_regulation_ot',SECOND:'joint_control_logistic_strong'}


class Ratings:
    def __init__(self,events,games):
        self.frame=events[events.game_id.isin(games.game_id)].copy().reset_index(drop=True)
        self.frame['at']=pd.to_datetime(self.frame.available_at_utc,utc=True)
        self.frame['signed']=np.where(self.frame.shooting_side.eq('B'),1.,-1.)
        self.frame['quality']=self.frame.signed*self.frame.model_xg
        self.frame['weight']=1/self.frame.groupby('game_id').game_id.transform('size')
        self.ids=sorted(set(pid for c in ['skaterA_ids_json','skaterB_ids_json'] for raw in self.frame[c] for pid in json.loads(raw)))
        lookup={p:i for i,p in enumerate(self.ids)};rr=[];cc=[];vv=[]
        for side,sign in [('A',-1.),('B',1.)]:
            for i,raw in enumerate(self.frame['skater'+side+'_ids_json']):
                for p in json.loads(raw):rr.append(i);cc.append(lookup[p]);vv.append(sign)
        membership=sparse.coo_matrix((vv,(rr,cc)),shape=(len(self.frame),len(self.ids))).tocsr()
        assert np.asarray(membership.sum(axis=1)).max()==0 and np.asarray(abs(membership).sum(axis=1)).min()==10
        context=np.clip(self.frame.home_score_margin_before.to_numpy(float),-3,3)/3
        self.X=sparse.hstack([membership,sparse.csr_matrix(context[:,None])],format='csr');self.audits=[]

    def fit(self,boundary,ids):
        prior=self.frame['at'].lt(boundary);n=self.frame.loc[prior,'game_id'].nunique()
        if n<100:return None,None
        output={};counts=[];checks=[]
        for field,target in zip(FIELDS,['signed','quality']):
            mask=(prior&self.frame[target].notna()).to_numpy();counts.append(int(mask.sum()))
            if self.frame.loc[mask,'game_id'].nunique()<100:output[field]=None;continue
            # Restrict the regression vocabulary to earlier observed players.
            # Future all-zero columns otherwise perturb iterative solver rounding.
            whole=self.X[mask];seen=np.flatnonzero(np.asarray(abs(whole).sum(axis=0)).ravel()>0)
            X=whole[:,seen];y=self.frame.loc[mask,target].to_numpy();w=self.frame.loc[mask,'weight'].to_numpy()
            with threadpool_limits(limits=2):model=Ridge(alpha=20,fit_intercept=True,solver='lsqr',tol=1e-10).fit(X,y,sample_weight=w)
            residual=y-model.predict(X);error=float(max(abs(np.asarray(X.T@(w*residual)).ravel()-20*model.coef_)))
            assert error<1e-4 and abs((w*residual).sum())<1e-6
            coefficients=np.zeros(self.X.shape[1]);coefficients[seen]=model.coef_
            lookup=dict(zip(self.ids,coefficients[:-1]));output[field]=np.array([lookup.get(str(pid),0.) if role=='skater' else 0. for role,pid in ids])
            checks.append(dict(field=field,events=int(mask.sum()),games=int(self.frame.loc[mask,'game_id'].nunique()),source_max=self.frame.loc[mask,'at'].max(),score_context_coefficient=float(coefficients[-1]),normal_equation_error=error))
        output['training_games']=int(n)
        audit=dict(fold=boundary.strftime('%Y-%m'),training_games=int(n),checks=checks);self.audits.append(audit)
        return output,audit

    def predict(self,vector,fitted):
        return {field:float(vector@fitted[field]) if fitted[field] is not None else np.nan for field in FIELDS}


def build():
    proof=json.loads((RESULT/'source_validation.json').read_bytes());assert proof['status']=='PASS'
    for t in proof['tables']:assert file_sha256(ROOT_OUT/(t['table']+'.parquet'))==t['sha256']
    plan=dict(at_utc=stamp(),hypothesis='Whole-game player usage blurs teammates and opponents. Actual verified on-ice pairs may better distinguish player contribution when identifying mispriced games.',
        fields=FIELDS,history='2021 onward; monthly expanding fits;2024/25 development before any2026 evaluation',
        player_estimation='Two Ridge alpha20 regressions: signed shot opportunity and signed prior-year internal xG. Exact five-on-five regulation events, ten native skaters with+home/-away coefficients, clipped pre-shot score-margin control. Each game total weight1. Not duration-based or causal RAPM.',
        roster='Unchanged five-observation dated roster/usage pool; no future starters. Unknown player coefficient0is shrinkage, not a fabricated observed statistic.',
        win_model='Unchanged primary regulation-Poisson/OT and secondary strong logistic with all existing player-strength inputs plus only two new features. No market predictors.',
        selection='Candidate pooled mean component logloss AND pooled primary logloss must both improve on identical2024/25control forecasts. No cutoff or regularization search.2026is repeatedly inspected retrospective evaluation.',
        betting='Unchanged one-side maximum expected-log-growth selection, followed by both p/price>=1.10, fixed$20, starting$2000, cash only,pre12latest prior quote age<=24h. Providers separated.',
        limitations='Conditional shot-opportunity effects omit zone starts and duration. Source event clocks are historical; source revision vintage not guaranteed. Incomplete participant events are individually documented.',
        source_hashes={t['table']:t['sha256'] for t in proof['tables']})
    if (RESULT/'experiment_plan.json').exists():
        old=json.loads((RESULT/'experiment_plan.json').read_bytes());assert all(old[k]==v for k,v in plan.items() if k!='at_utc')
    else:dump(RESULT/'experiment_plan.json',plan)
    games,players,rosters,keys=roster.load();events=pd.read_parquet(ROOT_OUT/(EVENTS+'.parquet'))
    rating=Ratings(events,games)
    extra,audit=roster.derive(games,players,rosters,keys,save=False,rating_provider=rating,fields=FIELDS)
    dump(RESULT/'rating_fit_audit.json',rating.audits)
    cut=pd.Timestamp('2025-01-01',tz='UTC');early=games[games.prediction_time.lt(cut)].copy()
    prefix,_=roster.derive(early,players[players.game_id.isin(early.game_id)],rosters[pd.to_datetime(rosters.available_at_utc,utc=True,format='mixed').lt(cut)],keys,False,Ratings(events,early),FIELDS)
    pd.testing.assert_frame_equal(prefix.set_index('game_id'),extra.set_index('game_id').loc[prefix.game_id],check_exact=False,rtol=0,atol=1e-10)
    extra.to_parquet(WORK/'joint_features.parquet',index=False)
    import features,nhl_identity_features
    g,o,p,_,stats,metrics,_=features.sources('nhl',include_preseason=True)
    needed=['game_id','side','available_at_utc','player_id','official_player_id','minutes','position','saves','shots_against']+metrics
    p=roster.apply_repairs(p[list(dict.fromkeys(needed+['played']))])
    base,_=nhl_identity_features.derive(g,o,p,stats,metrics,repaired=True,regulation_labels=games)
    earlier=pd.read_parquet(ROOT_OUT/'nhl_roster_strength_features.parquet')[['game_id']+roster.FIELDS]
    frame=base.merge(earlier,on='game_id',validate='one_to_one').merge(extra[['game_id']+FIELDS],on='game_id',validate='one_to_one')
    frame.to_parquet(WORK/'nhl_features.parquet',index=False)
    dump(RESULT/'feature_validation.json',dict(status='PASS',at_utc=stamp(),**audit,prefix_invariant_rows=len(prefix),feature_sha256=file_sha256(WORK/'nhl_features.parquet'),
        additional_fields=FIELDS,past_roster_and_rating_cutoffs_checked=True,complete_source_games=int(rating.frame.game_id.nunique()),source_events=len(rating.frame)))
    print(json.dumps(dict(stage='joint_features_built',games=len(frame),prefix_invariant_rows=len(prefix))),flush=True)


def paired(raw,label):
    mapping=CONTROL if label=='control' else {PRIMARY:PRIMARY,SECOND:SECOND}
    f=raw[raw.variant.isin(mapping.values())].copy();f.variant=f.variant.replace({v:k for k,v in mapping.items()})
    return paired_predictions(f,label)


def account_test(predictions,stage):
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    transfer.RESULT=RESULT;quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62')
    summaries=[];bets=[];days=[];checks=[]
    for variant,p in predictions.groupby('variant'):
        f=transfer.normalize('nhl',p,quotes,True);idx=p.set_index('game_id').loc[f.game_id]
        f['secondary_probability']=np.where(f.side.eq(0),idx.second_p0,idx.second_p1)
        f=f[np.minimum(f.probability,f.secondary_probability)/f.price>=1.10].copy()
        for provider,g in f.groupby('provider'):
            for year in sorted(p.prediction_time.dt.year.unique()):
                m,b,l,d=engine.simulate(g,int(year),'all_selected_outcomes','flat20_cash_only',5.,2000.)
                key=dict(sport='nhl',provider=provider,variant=variant,year=int(year))
                checks.append(key|engine.validate(b,l,d,'flat20_cash_only',5.,2000.));summaries.append(key|m)
                if len(b):bets.append(b.assign(**key))
                days.append(d.assign(**key))
    a=pd.DataFrame(summaries);a.to_csv(RESULT/(stage+'_annual.csv'),index=False)
    b=pd.concat(bets,ignore_index=True);b.to_parquet(RESULT/(stage+'_bets.parquet'),index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/(stage+'_daily.parquet'),index=False)
    dump(RESULT/(stage+'_cash_validation.json'),dict(status='PASS',checks=checks))
    # Exact reconstruction of the earlier fixed20 comparator is required.
    original=pd.read_parquet(ROOT_OUT/'simulation_results/uncertainty_buffer_staking/fixed_stake_bets.parquet')
    original=original[original.sport.eq('nhl')&original.rule.eq('relative_advantage10_flat20')]
    ref=b[b.variant.eq('control')&b.year.isin(original.year.unique())].copy()
    old=original[original.year.isin(ref.year.unique())].copy()
    keys=['provider','year','game_id'];ref=ref.sort_values(keys);old=old.sort_values(keys)
    assert ref[keys].values.tolist()==old[keys].values.tolist()
    assert np.allclose(ref[['stake','profit','price','probability']],old[['stake','profit','price','probability']],atol=1e-8,rtol=0)
    return a


def train():
    import models
    from evaluate_nhl_player_strength import loss,diagnose,forecast_metrics
    check=json.loads((RESULT/'feature_validation.json').read_bytes());assert check['status']=='PASS' and file_sha256(WORK/'nhl_features.parquet')==check['feature_sha256']
    models.OUT=WORK
    for base,name in CONTROL.items():models.CANDIDATES[name]=dict(models.CANDIDATES[base],exclude_columns=FIELDS)
    names=[PRIMARY,SECOND]+list(CONTROL.values());decided=False;replayed=0;annual=[]
    for stage in ['development','evaluation']:
        if stage=='evaluation':
            if not decided:break
            dump(WORK/'nhl_selection.json',dict(selected_candidates=names))
        raw=models.run('nhl',stage,names)
        p=pd.concat([paired(raw,'candidate'),paired(raw,'control')],ignore_index=True)
        # Same underlying current control probabilities must be reproduced.
        source=ROOT_OUT/'simulation_results/feature_revisions/nhl_player_strength'/(stage+'_predictions.parquet')
        old=pd.read_parquet(source);old=old[old.variant.eq('candidate')].set_index('game_id')
        control=p[p.variant.eq('control')].set_index('game_id').loc[old.index]
        assert np.allclose(control[['p0','p1','second_p0','second_p1']],old[['p0','p1','second_p0','second_p1']],rtol=0,atol=1e-12)
        assert p.train_label_max.lt(p.prediction_time).all() and p.calibration_label_max.lt(p.prediction_time).all()
        p.to_parquet(RESULT/(stage+'_predictions.parquet'),index=False)
        forecast_metrics(p).to_csv(RESULT/(stage+'_metrics.csv'),index=False);diagnose(p,RESULT/(stage+'_paired_loss.json'))
        frame=pd.read_parquet(WORK/'nhl_features.parquet');frame=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
        for name in names:
            package=pickle.loads((WORK/'model_runs/nhl'/stage/(name+'.pkl')).read_bytes())
            sample=raw[raw.variant.eq(name)&raw.fold.eq(package['boundary'].strftime('%Y-%m'))].head(10)
            x=frame.loc[sample.game_id,package['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
            out=models.apply_calibration(package['model'].predict_proba(x),package['calibrator'])
            assert np.allclose(out,sample[['p0','p1']],rtol=0,atol=1e-12);replayed+=len(sample)
            assert set(FIELDS).issubset(package['columns']) if name in [PRIMARY,SECOND] else not set(FIELDS)&set(package['columns'])
        if stage=='development':
            scores={}
            for v,g in p.groupby('variant'):
                y=g.target.to_numpy(int);primary=-np.log(g[['p0','p1']].to_numpy()[np.arange(len(g)),y])
                scores[v]=dict(component_logloss=float(loss(g).mean()),primary_logloss=float(primary.mean()))
            decided=all(scores['candidate'][metric]<scores['control'][metric] for metric in scores['control'])
            dump(RESULT/'selection.json',dict(at_utc=stamp(),passed=bool(decided),scores=scores,adopted=False))
        annual.append(account_test(p,stage))
    dump(RESULT/'model_validation.json',dict(status='PASS',at_utc=stamp(),development_gate_passed=bool(decided),evaluation_run=bool(decided),
        original_control_forecasts_equal=True,original_fixed20_cash_replayed=True,forecast_replays=replayed,app_changed=False,adopted=False))
    print(pd.concat(annual)[['variant','provider','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


def diagnose_losses():
    """Use actual official outcomes, with causal limits and no hindsight filter."""
    path=ROOT_OUT/'simulation_results/uncertainty_buffer_staking/fixed_stake_bets.parquet'
    old=pd.read_parquet(path);old=old[old.sport.eq('nhl')&old.rule.eq('relative_advantage10_flat20')].copy()
    from common import PREVIOUS
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games=pd.read_sql_query('SELECT game_id,official_game_id,phase,scoreA,scoreB FROM nhl_games',db)
    old=old.merge(games,on='game_id',validate='many_to_one')
    assert old.won.eq(np.where(old.side.eq(0),old.scoreA>old.scoreB,old.scoreB>old.scoreA)).all()
    old['probability_band']=pd.cut(old.probability,[0,.4,.5,.6,.7,1],right=False).astype(str)
    old['dollar_expected_profit']=old.stake*(old.probability/old.price-1)
    old['dollar_expectation_error']=old.profit-old.dollar_expected_profit
    rows=[]
    for grouping in ['phase','probability_band']:
        for (provider,year,band),f in old.groupby(['provider','year',grouping]):
            rows.append(dict(provider=provider,year=int(year),grouping=grouping,group=band,bets=len(f),wins=int(f.won.sum()),
                win_rate_pct=100*float(f.won.mean()),mean_probability=float(f.probability.mean()),mean_price=float(f.price.mean()),
                losing_stakes=float(f.loc[~f.won,'stake'].sum()),profit=float(f.profit.sum()),predicted_profit=float(f.dollar_expected_profit.sum()),
                forecast_minus_win_rate=float(f.probability.mean()-f.won.mean()),
                interpretation='Retrospective group diagnostics, not evidence that a specific observed loss was predictable. No team/month ban or subgroup threshold fitted.'))
    pd.DataFrame(rows).to_csv(RESULT/'loss_groups.csv',index=False)
    cases=old[old.provider.eq('polymarket')&old.year.eq(2025)&~old.won].nlargest(12,'probability').copy()
    candidates=pd.read_parquet(RESULT/'development_predictions.parquet');c=candidates[candidates.variant.eq('candidate')].set_index('game_id')
    cases['candidate_probability']=[c.loc[r.game_id,'p'+str(int(r.side))] for r in cases.itertuples()]
    cases['probability_change']=cases.candidate_probability-cases.probability
    cases['public_verification_url']='https://www.nhl.com/gamecenter/'+cases.official_game_id.astype(str)
    cases.to_csv(RESULT/'earlier_high_confidence_losses.csv',index=False)
    both=pd.read_parquet(ROOT_OUT/'simulation_results/uncertainty_buffer_staking/fixed_stake_bets.parquet')
    both=both[both.sport.eq('nhl')]
    merged=both[both.rule.eq('relative_advantage10_edge_dollars')].merge(both[both.rule.eq('relative_advantage10_flat20')],on=['provider','year','game_id'],suffixes=('_edge','_flat'),validate='one_to_one')
    assert merged.won_edge.eq(merged.won_flat).all() and np.allclose(merged.price_edge,merged.price_flat)
    merged['extra_stake']=merged.stake_edge-merged.stake_flat;merged['extra_profit']=merged.profit_edge-merged.profit_flat
    merged.groupby(['provider','year','won_edge'])[['extra_stake','extra_profit']].sum().to_csv(RESULT/'stake_attribution.csv')
    dump(RESULT/'loss_validation.json',dict(status='PASS',at_utc=stamp(),source_sha256=file_sha256(path),official_scores_replayed=True,highest_confidence_earlier_loss_cases=len(cases),
        losing_cases_do_not_select_model=True,explanation='Preseason high-confidence misses suggest roster/deployment uncertainty. Exact contribution model is a falsifiable hypothesis; losses alone do not identify causal errors.',
        stake_attribution='Same original selected markets and prices; compare actual stake/profit differences, not an independently changed opportunity set.'))
    frame=pd.read_parquet(WORK/'nhl_features.parquet')
    earlier=frame[frame.prediction_time.lt(pd.Timestamp('2026-01-01',tz='UTC'))]
    earlier[FIELDS+roster.FIELDS].corr().to_csv(RESULT/'feature_correlations.csv')
    effects=[]
    for name in [PRIMARY,SECOND]:
        package=pickle.loads((WORK/'model_runs/nhl/development'/(name+'.pkl')).read_bytes());model=package['model']
        parts=list(zip(['away_regulation_goals','home_regulation_goals'],model.models)) if hasattr(model,'models') else [('home_win',model)]
        for response,part in parts:
            coefficients=np.asarray(part.steps[-1][1].coef_).reshape(-1)
            for field in FIELDS:effects.append(dict(model=name,response=response,field=field,coefficient_per_training_sd=float(coefficients[package['columns'].index(field)]),
                fit_boundary=package['boundary'],interpretation='Conditional link-scale coefficient before calibration; not causal.'))
    dump(RESULT/'new_feature_effects.json',effects)


def finish():
    from final_pipeline import discard_work,cleanup,validate
    validation=json.loads((RESULT/'model_validation.json').read_bytes());assert validation['status']=='PASS'
    source=json.loads((RESULT/'source_validation.json').read_bytes());choice=json.loads((RESULT/'selection.json').read_bytes())
    diagnose_losses()
    report=REPORTS/'nhl_joint_chances.md'
    lines=['# NHL on-ice player contribution and loss diagnosis','',
        'The test asks whether whole-game player averages obscure useful information about the actual teammates and opponents on the ice. It adds two player contribution inputs to the existing NHL models and leaves purchase timing and fixed-dollar stakes unchanged. It does not retrospectively exclude losing teams or months.','',
        f"Published {source['matched_events']:,} verified five-on-five regulation events from 8,477 acquired games. The expanded preseason report collector recovered 4,000 event memberships; {source['unresolved_events']} events ({source['unresolved_pct']:.6f}%) still need repair. Every unresolved identity/reason is retained in nhl_five_on_five_event_coverage. A404from one report URL does not establish global unavailability.",'',
        'Two retrieved official report URLs contain the wrong year and are rejected. Another dated API roster gives two players the same jersey number; that report is held for identity repair. Exact verified shift membership can still support events in those games. No date or identity conflict is silently accepted.','',
        'The event table joins the native shooter, ten skaters, two goalies, regulation clock and score before the event. Original play-by-play, shifts and report hashes remain traceable. Source SQL and Parquet were compared exactly. Internal shot xG uses strictly earlier years, so2021has no xG observation; it is not invented0.','',
        'The player layer fits monthly Ridge20 regressions of signed shot opportunity and signed internal xG, controlling the ten actual skaters and the clipped score difference before the shot. Each historical game has total weight1. These are contributions conditional on an observed opportunity, not per-minute causal adjusted plus-minus. Earlier dated player usage and roster releases estimate the forecast roster; actual future lineups never enter.','',
        'The game layer keeps the original regulation-Poisson/overtime model and strongly regularized logistic check. Imputation, standardization, calibration and monthly expanding2021+training are unchanged. A truncated-history replay verifies that later data do not change earlier features. Every control forecast and the existing fixed20cash account must reproduce the previous version.','',
        'Selection requires lower pooled2024/25 primary log loss and lower mean two-component log loss. No parameter grid or betting-return selection chooses the model.2026is evaluated only if that gate passes and is retrospective because it has already been inspected repeatedly.','',
        '|2024/25 forecast metric|Control|New on-ice inputs|','|---|---:|---:|']
    for metric in ['primary_logloss','component_logloss']:
        lines.append(f"|{metric}|{choice['scores']['control'][metric]:.9f}|{choice['scores']['candidate'][metric]:.9f}|")
    lines+=['',f"Earlier-period model gate: {'passed' if choice['passed'] else 'failed'}. The app and retained baseline are unchanged.",'',
        'Betting remains one selected outcome per game, using the original maximum expected-log-growth ranking, then requiring both models to imply at least10%expected return at the recorded purchase price. Stake$20from a$2,000 starting account, cash only, latest prior pre12quote no more than24hours old, hold to official settlement. Providers stay separate. No added cost or spread assumptions. Annual accounts reset. Open positions retain cost value until settlement; Sharpe is based on daily account returns, so this is not a continuous market-value risk estimate.','',
        '|Provider|Year|Model|Bets|Win rate|Return|Daily Sharpe|Max drawdown|','|---|---:|---|---:|---:|---:|---:|---:|']
    for stage in ['development','evaluation']:
        path=RESULT/(stage+'_annual.csv')
        if not path.exists():continue
        for r in pd.read_csv(path).itertuples():
            lines.append(f'|{r.provider}|{r.year}|{r.variant}|{r.funded_games}|{r.win_rate_pct:.2f}%|{r.return_pct:.2f}%|{r.sharpe:.3f}|{r.max_drawdown_pct:.2f}%|')
    lines+=['',
        'loss_groups.csv records confidence and phase calibration, lost stakes and net contributions. earlier_high_confidence_losses.csv contains12earlier high-confidence losing examples, official results, purchase clocks and the new forecast change. stake_attribution.csv separates added dollars lost from added dollars earned when replacing fixed20with the previous edge-proportional sizing. Observed error groups diagnose a hypothesis; they do not prove individual surprise results were avoidable.','',
        'Why this revision was rejected: the new summaries remain closely correlated with each other and the existing player xG-strength input (see earlier-history feature_correlations.csv). They change some high-confidence misses only slightly: the losing Winnipeg example moves from80.89%to79.26%. Conditional shot contributions also omit actual shared-ice duration and still rely on the unchanged estimated forecast roster. The result gives no evidence that this extra pair of strength averages fixes roster uncertainty or improves calibration.','',
        'The next mechanism to investigate is actual time exposure and dated deployment: distinguish frequent chance creation per minute from better chance share when an opportunity occurs, and check whether the forecast roster was known to differ from the historical usage pool. Do not tune stake cutoffs from2026losses or delete preseason as a group;2025preseason bets were profitable overall.','',
        'Sources and method references: https://api-web.nhle.com/v1/gamecenter/{game_id}/play-by-play ; https://api.nhle.com/stats/rest/en/shiftcharts ; https://www.nhl.com/scores/htmlreports/{season}/PL{game_id_suffix}.HTM . Native original request URLs and evidence are in the coverage source_json and source_repair_queue.json. NHL report website access fills on-ice participant fields absent from the play-by-play API.','',
        'Method motivation: https://arxiv.org/abs/1201.0317 . That paper models time exposure and additional context; this experiment uses conditional event contributions and does not claim to reproduce its full methodology.','',
        'Reproduce: collect_nhl_event_players.py --include-preseason ; nhl_joint_chances.py collect ; nhl_joint_chances.py publish ; nhl_joint_player_model.py build ; nhl_joint_player_model.py train ; nhl_joint_player_model.py finish . Forecasts, cash results, source data and audits survive cleanup; temporary matrices and rejected fits are removed.','',
        'The Sharpe3and return>20%research target remains unmet. No new model is adopted by this experiment.']
    report.write_text('\n'.join(lines)+'\n',encoding='utf8')
    # Do not erase incomplete source work or publication evidence.
    for table in source['tables']:assert file_sha256(ROOT_OUT/(table['table']+'.parquet'))==table['sha256']
    decisions_path=ROOT_OUT/'simulation_results/experiment_decisions.json';decisions=json.loads(decisions_path.read_bytes())
    for path in sorted(RESULT.glob('*.json')):
        decisions[path.relative_to(ROOT_OUT/'simulation_results').as_posix()]=json.loads(path.read_bytes())
    dump(decisions_path,decisions)
    result_path=ROOT_OUT/'simulation_results/experiment_results.csv';consolidated=pd.read_csv(result_path)
    prefix=RESULT.relative_to(ROOT_OUT/'simulation_results').as_posix()+'/'
    consolidated=consolidated[~consolidated.source_result_file.str.startswith(prefix,na=False)]
    additions=[]
    for pattern in ['*_annual.csv','*_metrics.csv']:
        for path in sorted(RESULT.glob(pattern)):
            part=pd.read_csv(path);part['source_result_file']=prefix+path.name;part['sport']='nhl';additions.append(part)
    pd.concat([consolidated]+additions,ignore_index=True).to_csv(result_path,index=False)
    if WORK.exists():discard_work(WORK)
    cleanup();app=validate()
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        table_count=db.execute('SELECT COUNT(*) FROM table_catalog').fetchone()[0]
        column_count=db.execute('SELECT COUNT(*) FROM column_catalog').fetchone()[0]
    manifest_path=ROOT_OUT/'retention/retained_artifacts.json';manifest=json.loads(manifest_path.read_bytes())
    from pathlib import Path
    code=Path(__file__).parent
    manifest['scripts']={p.name:file_sha256(p) for p in sorted(code.glob('*.py'))}
    manifest.update(updated_utc=stamp(),retained_scripts=len(manifest['scripts']),final_tables=table_count,current_sql_columns=column_count,
        latest_dataset_update=dict(tables=source['tables'],report=str(report)),latest_simulation_update=dict(result=str(RESULT.relative_to(ROOT_OUT)),adopted=False,report=str(report)))
    dump(manifest_path,manifest)
    receipt=dict(status='PASS',at_utc=stamp(),source=source,model=validation,selection=choice,app_validation=app,temporary_work_removed=True,goal_achieved=False,report=str(report))
    dump(ROOT_OUT/'retention/nhl_joint_chances_completion.json',receipt)
    p=ROOT_OUT/'research_continuation.json';state=json.loads(p.read_bytes())
    state.update(at_utc=stamp(),current_job=None,live_sessions=[],running_jobs=[],last_action='Recovered4000 NHL event memberships; published565163 verified on-ice events; completed controlled joint player model test and cash replay.',
        next_action='Joint conditional-event ratings rejected: earlier loss worse, new summaries correlated with existing xG-strength and insufficiently change high-confidence errors. Investigate verified shared-ice duration and dated deployment differences, not another strength average or2026loss-based filter. Repair606explicit on-ice conflicts; soccer still needs role/replacement-quality evidence. No baseline/app change.',report=str(report),final_sql_tables=table_count,final_sql_columns=column_count)
    state.setdefault('research_state',{})['nhl_joint_chances']=receipt;dump(p,state)
    print(json.dumps(dict(status='PASS',model_gate=choice['passed'],adopted=False,report=str(report))),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['build','train','finish']);a=p.parse_args()
    {'build':build,'train':train,'finish':finish}[a.stage]()
