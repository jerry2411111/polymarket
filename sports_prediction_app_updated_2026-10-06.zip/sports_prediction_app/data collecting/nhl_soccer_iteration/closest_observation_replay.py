"""Prefer closest recorded price after enforcing its full availability cutoff."""
import argparse,hashlib,json
import pandas as pd
from common import ROOT_OUT,PROJECT,dump,stamp
from validate_hourly_prices import evaluate

RUN=ROOT_OUT/'closest_observations_v62'


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--year',type=int,choices=[2024,2025,2026]);args=parser.parse_args()
    RUN.mkdir(exist_ok=True)
    plan=dict(at_utc=stamp(),reason='v61 preferred later availability. A completed v2 bucket can outrank a closer CLOB point because its conservative end time is later despite an older source timestamp. The user requests the closest previous recorded odds.',
        selection='First require source timestamp and availability<=originalpre12decision. Then choose the later source timestamp. This prefers a closer actual CLOB point over an older timestamped aggregate even when its conservative bucket completion is later. Preserve an existing finer point when it is closer.',
        period=[2024,2025],source='hourly_prices_v61 raw-validated official responses',no_new_requests=True,unchanged='All existing sports forecasts,buy rules,stakes,officialoutcomes,app and originaloutputs.',
        caveat='Exact historical points do not establish executable offers. This is a source-timing correction,not a strategy threshold search.')
    if not (RUN/'plan.json').exists():dump(RUN/'plan.json',plan)
    for year in ([args.year] if args.year else [2024,2025]):
        source=ROOT_OUT/'hourly_prices_v61'/str(year);folder=RUN/str(year);folder.mkdir(exist_ok=True)
        assert json.loads((source/'validation.json').read_bytes())['status']=='PASS'
        if year==2026:dump(folder/'fixed_data_replay_plan.json',dict(at_utc=stamp(),reason='Apply identical source-timestamp correction to2026retained predictions; data correctness replay regardless of return. No new model or strategy selected.',selection=plan['selection']))
        f=pd.read_parquet(source/'quotes.parquet');assert f.status.isin(['recovered','empty_before_cutoff']).all()
        gap_path=source/'gap_probe.json'
        gap_recoveries=0
        if gap_path.exists():
            for item in json.loads(gap_path.read_bytes())['responses']:
                if item['kind']!='clob_seven_days' or not item['latest_causal_point']:continue
                meta=item['source'];raw=(PROJECT/meta['raw_file']).read_bytes();assert meta['return_status']=='200' and hashlib.sha256(raw).hexdigest()==meta['sha256']
                body=json.loads(raw);point=item['latest_causal_point'];at=pd.Timestamp(point['timestamp'],unit='s',tz='UTC')
                chosen=f.game_id.eq(item['game_id'])&f.class_index.eq(item['class_index'])&f.status.eq('empty_before_cutoff');assert chosen.sum()==1
                cut=f.loc[chosen,'decision_utc'].iloc[0];eligible=[(p['t'],i,p) for i,p in enumerate(body['history']) if pd.Timestamp(p['t'],unit='s',tz='UTC')<=cut]
                t,i,p=max(eligible);assert t==point['timestamp'] and p['p']==point['price']
                for c,value in dict(new_source_utc=at,new_available_utc=at,new_price=p['p'],new_age_hours=(cut-at).total_seconds()/3600,new_pointer='/history/'+str(i)+'/p',source_json=json.dumps(meta),status='recovered',history_rows=len(body['history'])).items():f.loc[chosen,c]=value
                gap_recoveries+=1
        recovered=f[f.status.eq('recovered')]
        assert recovered.new_source_utc.le(recovered.decision_utc).all() and recovered.new_available_utc.le(recovered.decision_utc).all()
        f['later_availability_than_old']=f.replace_old;f['replace_old']=f.new_source_utc.gt(f.entry_source_utc)
        f.to_parquet(folder/'quotes.parquet',index=False)
        dump(folder/'selection_validation.json',dict(status='PASS',at_utc=stamp(),source_sha256=hashlib.sha256((source/'quotes.parquet').read_bytes()).hexdigest(),outcomes=len(f),later_recorded_prices=int(f.replace_old.sum()),additional_tick_preference=int((f.replace_old&~f.later_availability_than_old).sum()),kept_closer_original_points=int((~f.replace_old&f.status.eq('recovered')).sum()),empty_new_histories=int(f.status.eq('empty_before_cutoff').sum()),wider_window_gap_recoveries=gap_recoveries,observation_older_than_24h=int(f.new_age_hours.gt(24).sum())))
        dump(folder/'complete.json',dict(state='selection verified; cash replay pending',at_utc=stamp()))
        evaluate(f,folder,year,None)


if __name__=='__main__':main()
