"""Rolling Dixon-Coles score forecasts; low-score rho learns earlier OOS rates."""
import json
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.optimize import minimize,minimize_scalar
from scipy.stats import skellam
from sklearn.preprocessing import OneHotEncoder
from threadpoolctl import threadpool_limits
from common import ROOT_OUT,dump,stamp
from us_market_data import RESULT,predictions
from us_market_research import protocol,probability_scores

class GoalRates:
    """log rate = league intercept + home effect + team attack + opponent defence."""
    def design(self,g,fit=False):
        away=pd.DataFrame(dict(attack=g.teamA.to_numpy(),defence=g.teamB.to_numpy(),competition=g.league.to_numpy()))
        home=pd.DataFrame(dict(attack=g.teamB.to_numpy(),defence=g.teamA.to_numpy(),competition=g.league.to_numpy()))
        f=pd.concat([away,home],ignore_index=True)
        if fit:self.encoder=OneHotEncoder(handle_unknown='ignore',sparse_output=True).fit(f)
        x=self.encoder.transform(f)
        return sparse.hstack([x,sparse.csr_matrix(np.r_[np.zeros(len(g)),np.ones(len(g))][:,None])],format='csr')
    def fit(self,g,cut):
        x=self.design(g,True);y=np.r_[g.scoreA,g.scoreB].astype(float)
        age=(cut-pd.to_datetime(g.available_time,utc=True)).dt.total_seconds().to_numpy()/86400
        w=np.tile(np.exp(-np.log(2)*age/365),2)
        n=x.shape[1];pen=np.full(n,5.);pen[-1]=.1
        def loss(b):
            eta=x@b;lam=np.exp(eta);err=w*(lam-y)
            return float(np.sum(w*(lam-y*eta))+.5*np.dot(pen*b,b)),np.asarray(x.T@err).ravel()+pen*b
        fitted=minimize(loss,np.zeros(n),jac=True,method='L-BFGS-B',bounds=[(-3,3)]*n,options=dict(maxiter=400,ftol=1e-10,gtol=1e-6))
        assert fitted.success,fitted.message
        self.coef=fitted.x;self.training_games=len(g);self.training_label_max=str(g.available_time.max())
        self.fit_cutoff=str(cut);return self
    def predict(self,g):
        rate=np.exp(self.design(g)@self.coef);return rate[:len(g)],rate[len(g):]

def low_score_tau(a,h,away,home,rho):
    return np.where((away==0)&(home==0),1-a*h*rho,
        np.where((away==0)&(home==1),1+a*rho,
        np.where((away==1)&(home==0),1+h*rho,
        np.where((away==1)&(home==1),1-rho,1.))))

def probabilities(a,h,rho):
    # Truncated-score grids are unnecessary: Skellam sums the complete Poisson support.
    lo=-1/np.maximum(a,h)+1e-9;hi=1/(a*h)-1e-9
    local=np.clip(rho,lo,hi)
    delta=np.exp(-a-h)*a*h*local
    q=np.column_stack([skellam.sf(0,a,h)+delta,skellam.sf(0,h,a)+delta,skellam.pmf(0,a,h)-2*delta])
    assert np.all(q>=0) and np.allclose(q.sum(axis=1),1,atol=1e-10)
    return q,local

def main():
    protocol();assert not (RESULT/'dc_validation.json').exists(),'Preserve completed score-model study'
    games=pd.read_parquet(ROOT_OUT/'games.parquet')
    g=pd.read_parquet(ROOT_OUT/'retained_models/soccer/soccer_features.parquet')
    g=g.merge(games[['game_id','teamA','teamB']],on='game_id',validate='one_to_one')
    # These source scores have already been normalized to regulation. Validate against labels.
    assert (np.where(g.scoreA>g.scoreB,0,np.where(g.scoreB>g.scoreA,1,2))==g.target).all()
    base=predictions();base=base[base.sport.eq('soccer')].copy()
    corrected=base.set_index('game_id')
    for field in ['prediction_time','available_time','start_time']:
        g[field]=pd.to_datetime(g[field],utc=True)
        g[field]=g.game_id.map(corrected[field]).fillna(g[field])
    assert g.prediction_time.lt(g.start_time).all() and g.start_time.lt(g.available_time).all()
    out=[];warm=[];fits=[]
    for month in pd.period_range('2023-01','2026-09',freq='M'):
        cut=pd.Timestamp(str(month),tz='UTC');end=cut+pd.offsets.MonthBegin(1)
        train=g[g.available_time.lt(cut)]
        test=g[g.prediction_time.ge(cut)&g.prediction_time.lt(end)]
        if len(train)<200 or not len(test):continue
        with threadpool_limits(limits=1):model=GoalRates().fit(train,cut)
        a,h=model.predict(test);rho=0.;calmax=None;caln=0
        if warm:
            cal=pd.concat(warm,ignore_index=True);cal=cal[pd.to_datetime(cal.available_time,utc=True).lt(cut)]
            if len(cal)>=100:
                ca,ch=cal.rateA.to_numpy(),cal.rateB.to_numpy();ya,yh=cal.scoreA.to_numpy(),cal.scoreB.to_numpy()
                weights=np.exp(-np.log(2)*(cut-pd.to_datetime(cal.available_time,utc=True)).dt.total_seconds().to_numpy()/86400/365)
                bounds=(max(-.2,float((-1/np.maximum(ca,ch)).max())+1e-7),min(.2,float((1/(ca*ch)).min())-1e-7))
                result=minimize_scalar(lambda r:-float(np.sum(weights*np.log(low_score_tau(ca,ch,ya,yh,r)))),bounds=bounds,method='bounded',options={'xatol':1e-10})
                assert result.success;rho=float(result.x);calmax=cal.available_time.max();caln=len(cal)
        q,local=probabilities(a,h,rho)
        result=test[['game_id','sport','league','date','start_time','prediction_time','available_time','target','scoreA','scoreB']].copy()
        result['rateA']=a;result['rateB']=h;result['rho']=local;result[['p0','p1','p2']]=q
        result['train_label_max']=train.available_time.max();result['calibration_label_max']=calmax
        result['fold']=str(month);result['model']='dixon_coles';result['training_games']=len(train)
        assert result.train_label_max.lt(result.prediction_time).all()
        warm.append(result.copy())
        if month.year>=2024:out.append(result)
        fits.append(dict(fold=str(month),training_games=len(train),calibration_games=caln,train_label_max=str(train.available_time.max()),calibration_label_max=str(calmax),rho=rho,rho_prediction_bounds_clipped=int(np.sum(local!=rho))))
        if month.month%3==0:print('Dixon-Coles',str(month),'training',len(train),'test',len(test),'rho',round(rho,4),flush=True)
    dc=pd.concat(out,ignore_index=True);dc.to_parquet(RESULT/'dixon_coles_predictions.parquet',index=False)
    paired=base.merge(dc[['game_id','p0','p1','p2']],on='game_id',suffixes=('','_dc'),validate='one_to_one')
    variants=[('sports_baseline',paired[['p0','p1','p2']].to_numpy()),('dixon_coles',paired[['p0_dc','p1_dc','p2_dc']].to_numpy())]
    for w in [.25,.5,.75]:variants.append((f'ensemble_{w}',w*variants[0][1]+(1-w)*variants[1][1]))
    frames=[];metrics=[];cals=[]
    for name,q in variants:
        z=paired[base.columns].copy();z[['p0','p1','p2']]=q;z['model']=name;frames.append(z)
        m,c=probability_scores(z,name,['p0','p1','p2']);metrics.append(m);cals.append(c)
    pd.concat(frames,ignore_index=True).to_parquet(RESULT/'soccer_model_predictions.parquet',index=False)
    pd.concat(metrics,ignore_index=True).to_csv(RESULT/'soccer_model_comparison.csv',index=False)
    pd.concat(cals,ignore_index=True).to_csv(RESULT/'soccer_model_calibration.csv',index=False)
    pd.DataFrame(fits).to_csv(RESULT/'dixon_coles_fits.csv',index=False)
    # Candidate forecasts and the deterministic fitting recipe are retained.
    # No unadopted fitted model is promoted into the production model store.
    dump(RESULT/'dc_validation.json',dict(status='PASS',at_utc=stamp(),rolling_months=len(fits),forecast_games=len(dc),matched_baseline_games=len(paired),unmatched_baseline_games=len(base)-len(paired),source_scores_match_labels=True,fit_scope='2021+ earlier only;2023 OOS rates warm up rho; forecasts from2024',primary_paper='https://doi.org/10.1111/1467-9876.00065'))
    print(pd.concat(metrics,ignore_index=True).to_string(index=False),flush=True)

if __name__=='__main__':main()
