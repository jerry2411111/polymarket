"""Bounded, causal US-only research, isolated from the deployed NBA/MLB app."""
import argparse,json,math,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import log_loss,accuracy_score,precision_score,recall_score
from common import ROOT_OUT,PROJECT,dump,stamp,file_sha256
from us_market_data import RESULT,predictions

def protocol():
    p=RESULT/'protocol.json'
    if p.exists():return json.loads(p.read_text())
    plan=dict(created_at_utc=stamp(),provider='polymarket_us',comparison_provider='polymarket_international_reference_only',
        entry_hours=[12,6,3,1],market_window='[official_start-12h, entry]; entry < official_start; no carry-in quote before window',
        coverage='Primary additionally requires market.createdAt <= quote timestamp; pre-creation observations remain separate diagnostics, never backfilled with international quotes.',
        history='Expanding available 2021+ official sports observations; saved monthly rolling baseline predictions start2024. All second-stage fits monthly on earlier settled OOS forecasts; min200 historical examples, last60 purged calibration observations.',
        base_models=dict(nhl='37-input C=.02 logistic, original temperature calibration',soccer='Corrected clock_identity C=.02 multinomial,41inputs, original calibration'),
        account=dict(initial_cash=2000,baseline_stake='5*max(100*p-51,0)',hold='official result availability',cash='No borrowing; concurrent requests proportionally scaled to available cash',valuation='Open contracts at cost until settlement; idle calendar days included; sqrt365.25; no cost deduction',end='2026-09-30T00:00:00Z'),
        experiments=dict(A=dict(edge_thresholds=[0,.02,.04,.06,.08],buckets=['negative','0-.02','.02-.04','.04-.06','.06-.10','.10+']),
            B='Market-only, unchanged sports-only, C=.02 linear market+sport logistic',C='Ridge alpha10 predicting Y-q on earlier matched observations',
            D=dict(meta='C=.02 logistic on earlier OOS first-stage predictions only',thresholds=[.55,.60,.65,.70],combined='edge>.04 and meta>.60'),
            E='Edge slope K estimated from earlier mean baseline dollars / mean positive edge; caps100 dollars; uncertainty lambda0,.5,1 using paired sports/DC disagreement for soccer only, sensitivity not formal posterior SD',
            F='q12,q9,q6,q3,q1 only when actually observable; no unavailable movements filled',G='convergence>0 or signed agreement>0; fixed splits',
            H='Quote count/changes and age, split by previous-data median only; no historical trade/volume/depth assumed',
            I='NHL depth2 HistGradientBoosting residual regression100iterations,l2=10,minleaf30; fixed market offset',
            J='Use earlier dated projected-goalie reports, never final actual goalie as pregame input; report coverage before testing',
            K=dict(model='Dixon-Coles team attack/defence Poisson with historical low-score dependence',ridge=5.,half_life_days=365,ensembles=[.25,.5,.75]),
            L='Fixed confidence/edge/context diagnostics, no team removals or loss-conditioned exclusions',
            M='Compare baseline risk versus20percent same-day capital,100dollar per-bet cap, and maximum3 same-competition bets/day; no leverage increase'),
        selection='No return-driven base-model selection. Compare paired earlier proper scores. Thresholds above frozen before US P&L. Do not declare an adopted US rule without positive prior-period evidence and >=100 funded bets;2026 is previously inspected retrospective evidence.',
        seeds=37,target=dict(sharpe_gt=3,return_pct_gt=20),app_changes=False)
    plan['protected_sha256']={str(f.relative_to(PROJECT)):file_sha256(f) for folder in ['sports_app','final_models/nba','final_models/mlb'] for f in (PROJECT/folder).glob('*') if f.suffix in ('.py','.pkl','.parquet','.json')}
    dump(p,plan);return plan

def probability_scores(frame,model,pcols):
    rows=[];cal=[]
    for year,f in frame.groupby(pd.to_datetime(frame.prediction_time,utc=True).dt.year):
        q=f[pcols].to_numpy(float);y=f.target.to_numpy(int);pick=q.argmax(axis=1);k=q.shape[1]
        assert np.allclose(q.sum(axis=1),1,atol=1e-8) and (q>=0).all()
        r=dict(model=model,sport=str(f.iloc[0].sport),year=int(year),games=len(f),accuracy_pct=100*float((pick==y).mean()),
            brier=float(np.mean((q[:,1]-y)**2)) if k==2 else float(np.mean(np.sum((q-np.eye(k)[y])**2,axis=1))),
            logloss=float(log_loss(y,q,labels=list(range(k)))),draw_recall=None,draw_precision=None,predicted_draw_frequency=None,actual_draw_frequency=None)
        if k==3:r.update(draw_recall=float(recall_score(y==2,pick==2,zero_division=0)),draw_precision=float(precision_score(y==2,pick==2,zero_division=0)),predicted_draw_frequency=float((pick==2).mean()),actual_draw_frequency=float((y==2).mean()),draw_brier=float(np.mean((q[:,2]-(y==2))**2)))
        rows.append(r)
        for side in range(k):
            for lo,hi in zip(np.arange(0,1,.1),np.arange(.1,1.01,.1)):
                mask=(q[:,side]>=lo)&(q[:,side]<(hi if hi<.999 else 1.01))
                if mask.any():cal.append(dict(model=model,sport=r['sport'],year=int(year),side=side,lower=lo,upper=hi,games=int(mask.sum()),mean_probability=float(q[mask,side].mean()),win_rate=float((y[mask]==side).mean())))
    return pd.DataFrame(rows),pd.DataFrame(cal)

def baseline():
    protocol();assert not (RESULT/'baseline_validation.json').exists(),'Preserve completed baseline replay'
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    quotes=quote_inputs(RESULT/'reference_quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    p=predictions();p.to_parquet(RESULT/'base_predictions.parquet',index=False)
    rows=[];positions=[];days=[];checks=[];metrics=[];calibration=[]
    for sport,g in p.groupby('sport'):
        assert g.game_id.is_unique
        assert g.train_label_max.lt(g.prediction_time).all() and g.calibration_label_max.lt(g.prediction_time).all()
        f=transfer.normalize(sport,g,quotes,pick_growth=False)
        reference=ROOT_OUT/'simulation_results'/('nhl_winner_classifier/agreement_annual.csv' if sport=='nhl' else 'soccer_winner_home_context/annual.csv')
        saved=pd.read_csv(reference)
        for variant in (['floor_control','market_agreement'] if sport=='nhl' else ['control','home_only']):
            subset=f[f.probability.gt(.60 if sport=='nhl' else .51)]
            if variant=='market_agreement':subset=subset[subset.price.gt(.5)]
            if variant=='home_only':subset=subset[subset.side.eq(1)]
            for provider,z in subset.groupby('provider'):
                for year in [2024,2025,2026]:
                    old=saved[saved.variant.eq(variant)&saved.provider.eq(provider)&saved.year.eq(year)]
                    if not len(old):continue
                    m,b,l,d=engine.simulate(z,year,'all_selected_outcomes','dollars_cash_only',5.,2000.)
                    for c in ['funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']:
                        assert np.isclose(m[c] if m[c] is not None else np.nan,old.iloc[0][c],atol=1e-9,rtol=0,equal_nan=True),(sport,provider,variant,year,c,m[c],old.iloc[0][c])
                    key=dict(sport=sport,provider='polymarket_international' if provider=='polymarket' else provider,variant=variant,year=year)
                    rows.append(key|m);checks.append(key|engine.validate(b,l,d,'dollars_cash_only',5.,2000.))
                    if len(b):positions.append(b.assign(**key))
                    days.append(d.assign(**key))
        m,c=probability_scores(g,'sports_baseline',['p0','p1']+(['p2'] if sport=='soccer' else []));metrics.append(m);calibration.append(c)
    pd.DataFrame(rows).to_csv(RESULT/'reference_baseline_annual.csv',index=False)
    pd.concat(positions,ignore_index=True).to_parquet(RESULT/'reference_baseline_bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'reference_baseline_daily.parquet',index=False)
    pd.concat(metrics,ignore_index=True).to_csv(RESULT/'base_model_metrics.csv',index=False)
    pd.concat(calibration,ignore_index=True).to_csv(RESULT/'base_calibration.csv',index=False)
    dump(RESULT/'baseline_validation.json',dict(status='PASS',at_utc=stamp(),checks=checks,rows_reproduced=len(rows),models_unchanged=True))
    print(pd.DataFrame(rows)[['sport','provider','variant','year','funded_games','return_pct','sharpe']].to_string(index=False),flush=True)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('stage',choices=['protocol','baseline']);args=a.parse_args();globals()[args.stage]()
