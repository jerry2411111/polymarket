"""Fetch fixture-filtered official player actions, preserving absent values."""
import argparse,collections,concurrent.futures,json,sqlite3
from common import ROOT_OUT,OfficialClient,dump,stamp
from laliga_club_archive import BASE,sid
from collect_laliga_club_facts import raw_stats,connect
from soccer_additional_facts import LIGUE_FIELDS

FIELDS=LIGUE_FIELDS|{'minutes_reported':'mins_played','appearances_reported':'appearances','starts_reported':'game_started','goals_reported':'goals','assists_reported':'goal_assist'}

def parse(body,player,source):
    assert sid(body['entity']['id'])==player['club_player_id']
    assert body['entity']['altIds']['opta']==player['official_player_id']
    raw=raw_stats(body['stats'])
    assert raw.get('appearances',0) in [0,1] and raw.get('game_started',0) in [0,1], 'Fixture filter may not have applied'
    if raw.get('mins_played') is not None:assert 0<=raw['mins_played']<=110
    row={k:player[k] for k in ['game_id','official_game_id','club_fixture_id','club_player_id','official_player_id','player_name','league','date','available_at_utc','side','team_id','club_team_id']}
    row.update({k:raw.get(v) for k,v in FIELDS.items()});row.update(raw_stats=raw,source=source,source_class='official_club_API',source_provider='FC Barcelona / Opta',fixture_filter=player['club_fixture_id'])
    return row

def run(limit=3,workers=5):
    db=connect();db.executescript('CREATE TABLE IF NOT EXISTS player_statistics(game_id TEXT,official_player_id TEXT,body TEXT NOT NULL,PRIMARY KEY(game_id,official_player_id));CREATE TABLE IF NOT EXISTS player_issues(game_id TEXT,official_player_id TEXT,body TEXT NOT NULL,PRIMARY KEY(game_id,official_player_id));')
    records=[json.loads(r[0]) for r in db.execute('SELECT body FROM games ORDER BY game_id')]
    if limit:
        records.sort(key=lambda r:r['date']);records=[records[i] for i in sorted(set(round(i*(len(records)-1)/max(1,limit-1)) for i in range(min(limit,len(records)))))]
    done=set(db.execute('SELECT game_id,official_player_id FROM player_statistics'))
    tasks=[p for r in records for p in r['players'] if p['played'] is not False and (p['game_id'],p['official_player_id']) not in done]
    client=OfficialClient(per_second=3);counts=collections.Counter();mark=10
    def fetch(p):
        source=None
        try:
            j,source=client.get(BASE+f'/stats/player/{p["club_player_id"]}?fixtures={p["club_fixture_id"]}&altIds=true','Fixture-specific La Liga passing, shooting, defending and goalkeeper actions: '+p['game_id']+' player '+p['official_player_id'],kind='official_club_player_statistics')
            assert j is not None,source['return_status'];return p,parse(j,p,source),None
        except (AssertionError,KeyError,ValueError,TypeError) as exc:return p,None,dict(reason=type(exc).__name__+': '+str(exc),source=source)
    print(json.dumps(dict(stage='laliga_club_player_statistics',games=len(records),tasks=len(tasks))),flush=True)
    dump(ROOT_OUT/'laliga_club_player_progress.json',dict(at_utc=stamp(),total=len(tasks),processed=0,percent=0 if tasks else 100,counts={}))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        for n,(p,row,error) in enumerate(pool.map(fetch,tasks),1):
            with db:
                if row:db.execute('INSERT OR REPLACE INTO player_statistics VALUES (?,?,?)',(p['game_id'],p['official_player_id'],json.dumps(row)));db.execute('DELETE FROM player_issues WHERE game_id=? AND official_player_id=?',(p['game_id'],p['official_player_id']));counts['player_rows']+=1;counts['empty_stats']+=not bool(row['raw_stats'])
                else:db.execute('INSERT OR REPLACE INTO player_issues VALUES (?,?,?)',(p['game_id'],p['official_player_id'],json.dumps(error)));counts['acquisition_issues']+=1
            if n*100>=mark*len(tasks) or n==len(tasks):
                progress=dict(at_utc=stamp(),total=len(tasks),processed=n,percent=round(n*100/len(tasks),1),counts=dict(counts));dump(ROOT_OUT/'laliga_club_player_progress.json',progress);print(json.dumps(progress),flush=True);mark+=10
    db.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int,default=3);p.add_argument('--workers',type=int,default=5);a=p.parse_args();run(a.limit,a.workers)
