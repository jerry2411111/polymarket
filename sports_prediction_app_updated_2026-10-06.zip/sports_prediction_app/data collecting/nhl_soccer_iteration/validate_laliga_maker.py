"""Exact raw replay for every normalized official-club field and match identity."""
import hashlib
import json
import pandas as pd
from common import ROOT_OUT,PROJECT,read_db,dump,stamp
from laliga_maker_api import FIELDS


def pointer(body,path):
    for part in path.strip('/').split('/'):
        body=body[int(part)] if isinstance(body,list) else body[part]
    return body


def main():
    with read_db(ROOT_OUT/'laliga_maker.sqlite') as c:
        records=[json.loads(r[0]) for r in c.execute('SELECT body FROM fixtures ORDER BY game_id')]
        acquisition_issues=[dict(game_id=r[0],**json.loads(r[1])) for r in c.execute('SELECT * FROM issues')]
    index=json.loads((ROOT_OUT/'laliga_maker_index.json').read_bytes());indices={r['game_id']:r for r in index['matched']}
    cells=0;hashes=set();people=0;issues=[];complete=0;reported=0;examples=[]
    for record in records:
        source=record['source'];b=(PROJECT/source['raw_file']).read_bytes()
        assert hashlib.sha256(b).hexdigest()==source['sha256'];body=json.loads(b);hashes.add(source['sha256'])
        game=indices[record['game_id']];native=body['game']
        assert native['id']==game['maker_game_id']
        assert pd.Timestamp(native['time'])==pd.Timestamp(game['start_time'])
        assert [native['awayScore'],native['homeScore']]==[game['scoreA'],game['scoreB']]
        assert pd.Timestamp(game['available_at_utc'])>=pd.Timestamp(game['start_time'])+pd.Timedelta(hours=6)
        assert len({(p['side'],p['maker_player_id']) for p in record['players']})==len(record['players'])
        for side,field in [('A','awayTeam'),('B','homeTeam')]:
            assert native[field]['id']==game['fixture'][field]['id']
        for row in record['players']+record['teams']:
            raw=pointer(body,row['source_pointer']) if row['source_pointer'] else None
            raw=raw or {};assert row['raw_stats']==raw
            for key,native_key in FIELDS.items():assert row[key]==raw.get(native_key),(record['game_id'],key);cells+=1
            if 'maker_player_id' in row:
                lineup=pointer(body,row['lineup_pointer']);assert lineup['player']['id']==row['maker_player_id']
                assert lineup['player']['name']==row['player_name']
                assert bool(lineup['starting'])==row['started'] and not lineup.get('manager')
                aliases={lineup['player']['id'],lineup['player'].get('playerMaster')}-{None}
                entered=any(e.get('type',{}).get('type')=='PlayerOn' and
                    (e.get('team') or {}).get('id')==row['maker_team_id'] and
                    (e.get('relatedPlayer') or {}).get('id') in aliases for e in body['events']['data'])
                expected_played=bool(row['started'] or entered or raw.get('minsPlayed',0)>0 or raw.get('totalSubOn',0)>0)
                assert row['played']==expected_played,'Player/master event identity must be reconciled'
                if row['source_pointer']:
                    si=row['source_pointer'].rsplit('/stats',1)[0]
                    assert pointer(body,si)['player']['id']==row['maker_player_id']
                people+=1
                if row['minutes_reported'] is not None:reported+=1
        issues.extend(dict(game_id=record['game_id'],**e) for e in record['issues'])
        if not record['issues']:complete+=1
        examples.append(dict(game_id=record['game_id'],date=game['date'],teams=[game['teamA'],game['teamB']],score=[game['scoreA'],game['scoreB']],
            source_url=source['url'],public_verification_url='https://www.elchecf.es/partidos/'+native['slug'],request_number=source['request_number'],
            retrieval_time=source['retrieved_at_utc'],player_rows=len(record['players']),discrepancies=record['issues'],
            field_example=dict(side=record['teams'][0]['side'],pointer=record['teams'][0]['source_pointer']+'/totalPass',
                raw_value=record['teams'][0]['raw_stats'].get('totalPass'),normalized_field='passes',normalized_value=record['teams'][0]['passes'],matches=True)))
    with read_db(ROOT_OUT/'acquisition.sqlite') as c:
        requests=[dict(r) for r in c.execute("SELECT return_status,count(*) AS requests FROM request_audit WHERE url LIKE 'https://www.elchecf.es/api/%' GROUP BY return_status")]
    report=dict(at_utc=stamp(),status='PASS',scope='Exact identity and literal raw-to-normalized values; field gaps remain explicit and do not imply complete source lineups.',
        games=len(records),player_rows=people,reported_minutes_rows=reported,source_hashes=len(hashes),normalized_cells=cells,
        games_without_recorded_field_issues=complete,field_issues=issues,acquisition_issues=acquisition_issues,
        request_summary=requests,approximate_credits='Not advertised for the public website JSON API; no paid API key used',
        validation_examples=examples,validated_game_ids=[r['game_id'] for r in records],
        source_class='Official Elche public JSON API; public client route definitions retained; no credentials used',
        excluded='Current season widgets, rolling head-to-head summaries, biography team assignments, undocumented physical-unit fields')
    dump(ROOT_OUT/'laliga_maker_validation.json',report)
    print(json.dumps({k:report[k] for k in ['status','games','player_rows','reported_minutes_rows','normalized_cells','games_without_recorded_field_issues']}),flush=True)


if __name__=='__main__':main()
