"""Verified regulation on-ice intervals and their complete chance numerators.

Intervals use native shift boundaries; exact duplicate shifts collapse without
double-counting time. Nonidentical overlapping shifts remain explicit repair
flags. Unassigned shots invalidate neighboring interval numerators, never0.
"""
import argparse,collections,hashlib,json,sqlite3
import numpy as np
import pandas as pd
from common import ROOT_OUT,PREVIOUS,PROJECT,REPORTS,read_db,dump,stamp,file_sha256

NAME='nhl_duration_chances'
WORK=ROOT_OUT/'_work'/NAME
RESULT=ROOT_OUT/'simulation_results/feature_revisions'/NAME
INTERVALS='nhl_verified_ice_intervals'
COVERAGE='nhl_ice_interval_coverage'
VERSION='interval-v2'


def clock(value):
    m,s=map(int,value.split(':'));return 60*m+s


def normalize(game,shifts,shots,events,raw,positions):
    """Neither team result nor purchased side selects source inclusion."""
    assert str(raw['id'])==str(game['official_game_id'])
    assert raw['gameDate']==game['date']
    native=[str(raw['awayTeam']['id']),str(raw['homeTeam']['id'])]
    assert native==list(map(str,json.loads(game['native_team_ids_json'])))
    byevent={int(r['event_id']):r for r in events}
    shotmap={int(r['event_id']):r for r in shots}
    plays=sorted(raw['plays'],key=lambda r:r['sortOrder'])
    scores=[0,0];goal_times=collections.defaultdict(list);checks=0;manpower=collections.defaultdict(list)
    for p in plays:
        pdsc=p['periodDescriptor'];period=pdsc['number'];t=clock(p['timeInPeriod']);kind=p['typeDescKey'];detail=p.get('details',{})
        if pdsc['periodType']=='SO':continue
        situation=str(p.get('situationCode',''))
        if pdsc['periodType']=='REG' and len(situation)==4:manpower[period].append((t,situation))
        if kind=='goal':
            side=native.index(str(detail['eventOwnerTeamId']));scores[side]+=1
            if 'awayScore' in detail:
                assert scores==[detail['awayScore'],detail['homeScore']];checks+=1
            if pdsc['periodType']=='REG':goal_times[period].append((t,side,p['eventId']))
    delta=[game['scoreA']-scores[0],game['scoreB']-scores[1]]
    assert delta==[0,0] or (raw['periodDescriptor']['periodType']=='SO' and scores[0]==scores[1] and delta in [[1,0],[0,1]])
    roles={pid:v for pid,v in positions.items() if isinstance(v,str) and v in ['C','L','R','D','G','LW','RW','F']};sides={r['player_id']:r['side'] for r in shifts['rows']}
    for e in events:
        for side in ['A','B']:
            for pid in json.loads(e['skater'+side+'_ids_json']):
                assert pid not in roles or roles[pid]!='G';roles[pid]='S';sides[pid]=side
            pid=e['goalie'+side+'_id'];assert pid not in roles or roles[pid]=='G';roles[pid]='G';sides[pid]=side
    shift_periods=collections.defaultdict(list)
    for r in shifts['rows']:
        if 1<=r['period']<=3 and r['end_seconds']>r['start_seconds']:
            assert 0<=r['start_seconds']<r['end_seconds']<=1200
            shift_periods[r['period']].append(r)
    allrows=[];rejects=[];duplicates=0;conflicting=[];assigned=set();score=[0,0]
    relevant={int(p['eventId']) for p in plays if p['periodDescriptor']['periodType']=='REG' and str(p.get('situationCode',''))=='1551' and int(p['eventId']) in shotmap}
    # Shootouts and empty-net events do not determine whether a five-on-five
    # interval has an earlier-year chance model.
    xg_known=bool(relevant) and all(pd.notna(shotmap[eid]['model_xg']) for eid in relevant)
    for period in [1,2,3]:
        unique={};byplayer=collections.defaultdict(list);boundaries={0,1200}
        for r in shift_periods[period]:
            key=(r['player_id'],r['start_seconds'],r['end_seconds'])
            if key in unique:duplicates+=1;continue
            unique[key]=r;byplayer[r['player_id']].append(r);boundaries.update([r['start_seconds'],r['end_seconds']])
        overlaps=[]
        for pid,rs in byplayer.items():
            rs=sorted(rs,key=lambda r:(r['start_seconds'],r['end_seconds']))
            for i,a in enumerate(rs):
                for b in rs[i+1:]:
                    if b['start_seconds']>=a['end_seconds']:break
                    overlaps.append((min(a['start_seconds'],b['start_seconds']),max(a['end_seconds'],b['end_seconds'])))
                    conflicting.append(dict(player_id=pid,period=period,shift_ids=[a['shift_id'],b['shift_id']],bounds=[[a['start_seconds'],a['end_seconds']],[b['start_seconds'],b['end_seconds']]]))
        for t,_,_ in goal_times[period]:boundaries.add(t)
        times=sorted(boundaries);rows=[];goals=collections.Counter(side for t,side,_ in goal_times[period] if t==0)
        score=[score[k]+goals[k] for k in [0,1]]
        for start,end in zip(times,times[1:]):
            active=collections.defaultdict(set);reasons=set()
            for r in unique.values():
                if r['start_seconds']<=start and r['end_seconds']>=end:active[r['side']].add(r['player_id'])
            skaters={};goalies={}
            for side in ['A','B']:
                if any(pid not in roles for pid in active[side]):reasons.add('unknown_player_role')
                skaters[side]=sorted(pid for pid in active[side] if roles.get(pid) not in [None,'G'])
                goalies[side]=sorted(pid for pid in active[side] if roles.get(pid)=='G')
                if len(skaters[side])!=5 or len(goalies[side])!=1:reasons.add('outside_exact_five_skater_one_goalie')
            if any(a<end and b>start for a,b in overlaps):reasons.add('nonidentical_same_player_shift_overlap')
            if any(start<t<end and code!='1551' for t,code in manpower[period]):reasons.add('interior_play_manpower_conflict')
            row=dict(game_id=game['game_id'],period=period,start_seconds=start,end_seconds=end,duration_seconds=end-start,
                skaterA_ids_json=json.dumps(skaters['A']),skaterB_ids_json=json.dumps(skaters['B']),goalieA_id=goalies['A'][0] if len(goalies['A'])==1 else None,
                goalieB_id=goalies['B'][0] if len(goalies['B'])==1 else None,scoreA_before=score[0],scoreB_before=score[1],
                attemptsA=0,attemptsB=0,goalsA=0,goalsB=0,xgA=0. if xg_known else None,xgB=0. if xg_known else None,
                event_ids_json=[],rejection_reasons_json=reasons,usable=False)
            rows.append(row)
            for t,side,_ in goal_times[period]:
                if t==end:score[side]+=1
        # Inspect every source attempt in a nominal five-on-five situation,
        # including the606events without verified event-participant sets.
        for play in plays:
            eid=int(play['eventId'])
            if eid not in shotmap or play['periodDescriptor']['periodType']!='REG' or play['periodDescriptor']['number']!=period:continue
            shot=shotmap[eid];t=int(shot['seconds']);possible=[i for i,r in enumerate(rows) if r['start_seconds']<=t<=r['end_seconds']]
            if str(play.get('situationCode',''))!='1551':
                for i in possible:
                    # A boundary power-play event does not invalidate an
                    # adjacent subsequent even-strength interval.
                    if rows[i]['start_seconds']<t<rows[i]['end_seconds']:rows[i]['rejection_reasons_json'].add('interior_nonfive_shot')
                continue
            event=byevent.get(eid);valid=[]
            if event:
                for i in possible:
                    r=rows[i]
                    same=all(r['skater'+side+'_ids_json']==event['skater'+side+'_ids_json'] and r['goalie'+side+'_id']==event['goalie'+side+'_id'] for side in ['A','B'])
                    if same and not r['rejection_reasons_json'] and r['scoreB_before']-r['scoreA_before']==event['home_score_margin_before']:valid.append(i)
            if valid:
                # With identical valid lineups at a boundary, the elapsed
                # interval receives the event, consistent with end-of-shift shots.
                i=valid[0];r=rows[i];side=shot['side'];r['attempts'+side]+=1;r['goals'+side]+=int(shot['result']=='goal')
                if xg_known:r['xg'+side]+=float(shot['model_xg'])
                r['event_ids_json'].append(eid);assigned.add(eid)
            else:
                reason='no_verified_event_participants' if event is None else 'event_lineup_or_score_does_not_match_usable_interval'
                rejects.append(dict(event_id=eid,period=period,seconds=t,reason=reason,neighboring_intervals=[[rows[i]['start_seconds'],rows[i]['end_seconds']] for i in possible]))
                for i in possible:rows[i]['rejection_reasons_json'].add('unassigned_five_on_five_attempt')
        for r in rows:
            r['usable']=not r['rejection_reasons_json']
            # A subsequently rejected interval cannot retain a partial
            # numerator that could be mistaken for a complete measured count.
            if not r['usable']:
                for side in ['A','B']:
                    for name in ['attempts','goals','xg']:r[name+side]=None
            r['event_ids_json']=json.dumps(r['event_ids_json']);r['rejection_reasons_json']=json.dumps(sorted(r['rejection_reasons_json']))
        allrows.extend(rows)
    assert sum(r['duration_seconds'] for r in allrows)==3600
    usable=[r for r in allrows if r['usable']]
    counted={eid for r in usable for eid in json.loads(r['event_ids_json'])}
    assert sum(len(json.loads(r['event_ids_json'])) for r in usable)==len(counted)
    assert sum(r['attemptsA']+r['attemptsB'] for r in usable)==len(counted)
    eligible=sum(p['eventId'] in shotmap and p['periodDescriptor']['periodType']=='REG' and str(p.get('situationCode',''))=='1551' for p in plays)
    coverage=dict(game_id=game['game_id'],official_game_id=str(game['official_game_id']),date=game['date'],phase=game['phase'],available_at_utc=game['available_time'],
        intervals=len(allrows),usable_intervals=len(usable),usable_seconds=sum(r['duration_seconds'] for r in usable),outside_usable_seconds=3600-sum(r['duration_seconds'] for r in usable),
        eligible_attempts=int(eligible),counted_attempts=len(counted),uncounted_attempts=int(eligible)-len(counted),
        exact_duplicate_shifts=duplicates,nonidentical_overlap_records=len(conflicting),xg_model_available=xg_known,
        event_rejections_json=json.dumps(rejects),shift_conflicts_json=json.dumps(conflicting),goal_progressions_checked=checks)
    return allrows,coverage


def collect(limit=None):
    WORK.mkdir(parents=True,exist_ok=True);RESULT.mkdir(parents=True,exist_ok=True)
    source_names=['nhl_shifts.sqlite','nhl_five_on_five_event_players.parquet','nhl_shot_detail.parquet']
    hashes={n:file_sha256(ROOT_OUT/n) for n in source_names}
    event_groups={k:g.to_dict('records') for k,g in pd.read_parquet(ROOT_OUT/source_names[1]).groupby('game_id',sort=False)}
    shot_groups={k:g.to_dict('records') for k,g in pd.read_parquet(ROOT_OUT/source_names[2]).groupby('game_id',sort=False)}
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games={r['game_id']:dict(r) for r in db.execute("SELECT * FROM nhl_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30' AND phase IN ('Regular Season','Playoffs','Preseason')")}
        ps=pd.read_sql_query('SELECT game_id,official_player_id,position FROM nhl_player_games',db)
    positions={gid:dict(zip(p.official_player_id.astype(str),p.position)) for gid,p in ps.groupby('game_id')}
    signature=hashlib.sha256((VERSION+json.dumps(hashes,sort_keys=True)).encode()).hexdigest()
    dump(RESULT/'source_plan.json',dict(at_utc=stamp(),signature=signature,hashes=hashes,
        scope='Every acquired2021-2026regular-season, playoff and preseason game with shift and event evidence. No result or quote-based source selection.',
        method='Constant native lineup intervals; exact duplicate shifts collapsed; conflicting overlapping versions rejected. Shots match verified official event participants and pre-event score. Any unassigned shot invalidates its possible neighboring interval counts. No unknown numerator becomes0.',
        limitations='No inferred missing shift duration. Nonusable seconds include legitimate special teams and unknown coverage, not solely missing data. No causal identification claim.',
        official_sources=['https://api-web.nhle.com/v1/gamecenter/{game_id}/play-by-play','https://api.nhle.com/stats/rest/en/shiftcharts','https://www.nhl.com/scores/htmlreports/{season}/PL{suffix}.HTM'],
        method_reference='https://arxiv.org/abs/1201.0317'))
    cache=sqlite3.connect(WORK/'normalized.sqlite');cache.execute('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,signature TEXT,body TEXT)')
    with read_db(ROOT_OUT/'nhl_shifts.sqlite') as db:tasks=[(gid,b) for gid,b in db.execute('SELECT game_id,body FROM games ORDER BY game_id') if gid in games and gid in shot_groups]
    if limit:tasks=tasks[:limit]
    notice=10
    for n,(gid,body) in enumerate(tasks,1):
        found=cache.execute('SELECT signature FROM games WHERE game_id=?',(gid,)).fetchone()
        if not found or found[0]!=signature:
            shot_rows=shot_groups[gid];sources={(r['source_raw_file'],r['source_sha256']) for r in shot_rows};assert len(sources)==1
            path,sha=next(iter(sources));raw=(PROJECT/path).read_bytes();assert hashlib.sha256(raw).hexdigest()==sha
            shifts=json.loads(body);rows,coverage=normalize(games[gid],shifts,shot_rows,event_groups.get(gid,[]),json.loads(raw),positions.get(gid,{}))
            coverage['source_json']=json.dumps(dict(shifts=shifts['sources'],play_by_play=dict(raw_file=path,sha256=sha),event_players_file=source_names[1],event_players_sha256=hashes[source_names[1]]),sort_keys=True)
            with cache:cache.execute('INSERT OR REPLACE INTO games VALUES(?,?,?)',(gid,signature,json.dumps(dict(intervals=rows,coverage=coverage),allow_nan=False)))
        percent=100*n/len(tasks)
        if percent>=notice or n==len(tasks):
            progress=dict(at_utc=stamp(),stage=NAME,complete=n,total=len(tasks),percent=round(percent,1));dump(RESULT/'source_progress.json',progress);print(json.dumps(progress),flush=True);notice+=10
    cache.close();dump(WORK/'collection_complete.json',dict(at_utc=stamp(),pilot=bool(limit),games=len(tasks),signature=signature,hashes=hashes))


def publish():
    import pyarrow as pa
    import pyarrow.parquet as pq
    proof=json.loads((WORK/'collection_complete.json').read_bytes());assert not proof['pilot']
    for name,digest in proof['hashes'].items():assert file_sha256(ROOT_OUT/name)==digest
    writer=None;cover=[];count=0;event_type=collections.Counter();buffer=[]
    shots=pd.read_parquet(ROOT_OUT/'nhl_shot_detail.parquet',columns=['game_id','event_id','result'])
    kind={(r.game_id,int(r.event_id)):r.result for r in shots.itertuples()}
    def typed(rows):
        frame=pd.DataFrame(rows)
        for col in ['attemptsA','attemptsB','goalsA','goalsB']:frame[col]=frame[col].astype('Int64')
        for col in ['xgA','xgB']:frame[col]=frame[col].astype('Float64')
        for col in ['goalieA_id','goalieB_id']:frame[col]=frame[col].astype('string')
        assert (frame.duration_seconds==frame.end_seconds-frame.start_seconds).all() and frame.duration_seconds.gt(0).all()
        assert frame.loc[~frame.usable,['attemptsA','attemptsB','goalsA','goalsB','xgA','xgB']].isna().all().all()
        assert frame.loc[frame.usable,['attemptsA','attemptsB','goalsA','goalsB']].notna().all().all()
        return frame
    means={
      'game_id':('Canonical official game join key','identifier'), 'period':('Regulation period1,2or3','period'),
      'start_seconds':('Elapsed period clock at interval start','seconds'), 'end_seconds':('Elapsed period clock at interval end','seconds'),
      'duration_seconds':('End minus start; disjoint intervals partition all3600regulation seconds','seconds'),
      'skaterA_ids_json':('Native away skaters active for the entire interval','JSON array of IDs'),
      'skaterB_ids_json':('Native home skaters active for the entire interval','JSON array of IDs'),
      'goalieA_id':('Unique native away goalie; NULL if no unique goalie is recorded','identifier'),
      'goalieB_id':('Unique native home goalie; NULL if no unique goalie is recorded','identifier'),
      'scoreA_before':('Away goals before interval; goal events at the end belong to the elapsed interval','goals'),
      'scoreB_before':('Home goals before interval','goals'),
      'attemptsA':('Complete verified away unblocked attempts in a usable interval; NULL otherwise','attempts'),
      'attemptsB':('Complete verified home unblocked attempts in a usable interval; NULL otherwise','attempts'),
      'goalsA':('Verified away goals among interval attempts; NULL for a rejected interval','goals'),
      'goalsB':('Verified home goals among interval attempts; NULL for a rejected interval','goals'),
      'xgA':('Sum of earlier-year internal shot probabilities for away attempts; NULL if interval or model unavailable','expected goals'),
      'xgB':('Sum of earlier-year internal shot probabilities for home attempts; NULL if interval or model unavailable','expected goals'),
      'event_ids_json':('Native attempt events assigned before final interval validation; use only when usable=true','JSON array of IDs'),
      'rejection_reasons_json':('Explicit interval conflicts or outside-five-on-five status; no silent data imputation','JSON array'),
      'usable':('Exactly five identified skaters and one goalie per side, no conflicting shift versions, and complete verified attempt numerator','boolean'),
      'official_game_id':('Native NHL game identity','identifier'), 'date':('Official calendar game date','YYYY-MM-DD'),
      'phase':('Regular Season, Playoffs or Preseason','category'), 'available_at_utc':('Conservative completed-game data availability cutoff; historical revision vintage not guaranteed','UTC timestamp'),
      'intervals':('Disjoint intervals covering regulation','intervals'), 'usable_intervals':('Intervals passing all time and numerator checks','intervals'),
      'usable_seconds':('Verified five-on-five time eligible for rate estimates','seconds'),
      'outside_usable_seconds':('Regulation time outside usable intervals, including legitimate power plays/empty nets and source conflicts; not solely missing time','seconds'),
      'eligible_attempts':('All source attempts with exact1551manpower in regulation','attempts'),
      'counted_attempts':('Eligible attempts inside fully usable intervals','attempts'),
      'uncounted_attempts':('Eligible attempts whose precise usable exposure cannot yet be established','attempts'),
      'exact_duplicate_shifts':('Exact native player/start/end duplicates collapsed to one time interval','rows'),
      'nonidentical_overlap_records':('Pairs of conflicting overlapping shifts of the same player; union excluded pending repair','pairs'),
      'xg_model_available':('Every eligible regulation five-on-five attempt has earlier-year internal xG; unrelated empty-net and shootout events do not erase coverage','boolean'),
      'event_rejections_json':('Native event IDs, exact failure and possibly affected interval boundaries','JSON array'),
      'shift_conflicts_json':('Native shift/player IDs and differing overlap bounds for repair','JSON array'),
      'goal_progressions_checked':('Goal score increments replayed against original official play-by-play','events'),
      'source_json':('Raw official shift/play-by-play files, hashes and verified event-player dataset link','JSON object')}
    source='Official NHL shiftcharts and gamecenter play-by-play, plus verified NHL event reports. nhl_duration_chances.py derives interval exposure and verified counts. Internal xG uses earlier years and is not an official NHL statistic.'
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as sql,read_db(WORK/'normalized.sqlite') as cache:
        def flush():
            nonlocal writer,count,buffer
            if not buffer:return
            frame=typed(buffer);table=pa.Table.from_pandas(frame,preserve_index=False)
            if writer is None:writer=pq.ParquetWriter(ROOT_OUT/(INTERVALS+'.parquet'),table.schema,compression='zstd')
            writer.write_table(table);frame.to_sql(INTERVALS,sql,if_exists='replace' if count==0 else 'append',index=False,chunksize=5000)
            count+=len(frame);buffer=[]
        for gid,body in cache.execute('SELECT game_id,body FROM games ORDER BY game_id'):
            obj=json.loads(body);c=obj['coverage'];rows=obj['intervals'];cover.append(c);buffer.extend(rows)
            counted={eid for r in rows if r['usable'] for eid in json.loads(r['event_ids_json'])}
            for r in rows:
                for eid in json.loads(r['event_ids_json']):event_type[(kind[(gid,eid)],'usable' if r['usable'] else 'assigned_interval_later_rejected')]+=1
            for r in json.loads(c['event_rejections_json']):event_type[(kind[(gid,r['event_id'])],'unassigned')]+=1
            assert len(counted)==c['counted_attempts'] and sum(r['duration_seconds'] for r in rows)==3600
            if len(buffer)>=20000:flush()
        flush();writer.close();coverage=pd.DataFrame(cover);coverage.to_sql(COVERAGE,sql,if_exists='replace',index=False)
        coverage.to_parquet(ROOT_OUT/(COVERAGE+'.parquet'),index=False)
        sql.execute('CREATE UNIQUE INDEX IF NOT EXISTS '+INTERVALS+'_key ON '+INTERVALS+'(game_id,period,start_seconds)')
        sql.execute('CREATE UNIQUE INDEX IF NOT EXISTS '+COVERAGE+'_key ON '+COVERAGE+'(game_id)')
        for name in [INTERVALS,COVERAGE]:
            for cat in ['table_catalog','column_catalog','missing_report']:sql.execute('DELETE FROM '+cat+' WHERE "table"=?',(name,))
            cols=[r[1] for r in sql.execute('PRAGMA table_info('+name+')')];n=sql.execute('SELECT COUNT(*) FROM '+name).fetchone()[0]
            null_counts=sql.execute('SELECT '+','.join('SUM("'+c+'" IS NULL)' for c in cols)+' FROM '+name).fetchone()
            sql.execute('INSERT INTO table_catalog VALUES(?,?,?)',(name,n,len(cols)))
            for col,null in zip(cols,null_counts):
                meaning,unit=means[col];sql.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(name,col,meaning,unit,source))
                sql.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(name,col,n,null,100*null/n))
    # Full streaming equality, not a small sample.
    with read_db(ROOT_OUT/'granular.sqlite') as sql:
        offset=0
        for batch in pq.ParquetFile(ROOT_OUT/(INTERVALS+'.parquet')).iter_batches(batch_size=20000):
            frame=batch.to_pandas();replay=pd.read_sql_query('SELECT * FROM '+INTERVALS+' WHERE rowid>? ORDER BY rowid LIMIT ?',sql,params=(offset,len(frame)))
            pd.testing.assert_frame_equal(frame,replay,check_dtype=False,check_exact=True);offset+=len(frame)
        pd.testing.assert_frame_equal(coverage,pd.read_sql_query('SELECT * FROM '+COVERAGE+' ORDER BY rowid',sql),check_dtype=False,check_exact=True)
    assert offset==count
    audit=pd.DataFrame([dict(result=k[0],status=k[1],events=v) for k,v in event_type.items()]);audit.to_csv(RESULT/'event_rejection_by_type.csv',index=False)
    coverage.assign(year=coverage.date.str[:4]).groupby(['year','phase'])[['eligible_attempts','counted_attempts','usable_seconds','outside_usable_seconds']].sum().to_csv(RESULT/'source_coverage_by_year_phase.csv')
    tables=[dict(table=name,rows=(count if name==INTERVALS else len(coverage)),sha256=file_sha256(ROOT_OUT/(name+'.parquet'))) for name in [INTERVALS,COVERAGE]]
    validation=dict(status='PASS',at_utc=stamp(),normalizer_version=VERSION,tables=tables,all_game_time_partitions_checked=True,all_counts_have_verified_events=True,all_sql_parquet_equal=True,
        eligible_attempts=int(coverage.eligible_attempts.sum()),counted_attempts=int(coverage.counted_attempts.sum()),uncounted_pct=float(100*coverage.uncounted_attempts.sum()/coverage.eligible_attempts.sum()),
        source_hashes=proof['hashes'],rejected_intervals_have_null_counts=True)
    dump(RESULT/'source_validation.json',validation)
    from publish import main as catalog
    catalog();print(json.dumps(validation),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['collect','publish'],nargs='?',default='collect');p.add_argument('--limit',type=int);a=p.parse_args()
    collect(a.limit) if a.stage=='collect' else publish()
