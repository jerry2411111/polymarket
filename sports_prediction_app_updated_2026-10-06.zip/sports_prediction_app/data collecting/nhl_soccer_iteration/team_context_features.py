"""Causal team-play features with all recovered official soccer player facts.

Source omissions remain null. Ratios require both components. Different source
definitions are not relabelled as identical physical or event measurements.
"""
import argparse,collections,hashlib,json
import numpy as np
import pandas as pd
from common import file_sha256,ROOT_OUT,OUT,read_db,dump,stamp
from additional_soccer_features import enriched_sources
from features import build,LEAGUE_CODE

TEAM_RAW={'possession_pct':'possession_percentage','box_shots':'attempts_ibox','box_entries':'pen_area_entries',
          'final_third_entries':'final_third_entries','recoveries_attacking_third':'poss_won_att_3rd'}
PLAYER_TOTALS=['passes','passes_completed','long_passes','long_passes_completed','xg','xa','saves']


def context_sources(include_exposure=False,include_uefa_exposure=False,include_club_recovery=False,include_maker_recovery=False,include_pl_zero_recovery=False,include_pl_lineup_recovery=False,include_ligue_xg=False,apply_clock_corrections=True):
    g,o,p,keys,stats,metrics,evidence=enriched_sources(include_exposure=include_exposure);extra=[]
    for file,table in [('uefa_passing.sqlite','reports'),('seriea_players.sqlite','games')]:
        with read_db(ROOT_OUT/file) as c:
            for body, in c.execute('SELECT body FROM '+table):
                for row in json.loads(body):
                    if file.startswith('seriea'):
                        if row['parser_version']!=4:continue
                        row=dict(row,played=row['did_play'],position=row['role'])
                        if row['goal_counts_reconcile']:row['goals']=row['recorded_goals']
                    else:row=dict(row,played=row['minutes'] is not None and row['minutes']>0)
                    extra.append(row)
    cross=p[['league','official_player_id','player_id']].drop_duplicates()
    assert cross.groupby(['league','official_player_id']).player_id.nunique().max()==1
    cross=cross.set_index(['league','official_player_id']).player_id.to_dict()
    include=['game_id','side','league','official_player_id','player_name','minutes','minutes_basis','available_at_utc',
             'started','played','position','goals','passes','passes_completed','long_passes','long_passes_completed']
    fresh=[]
    for r in extra:
        row={k:r.get(k) for k in include};native=str(row['official_player_id']);row['official_player_id']=native
        row['player_id']=cross.get((row['league'],native),'EU_'+LEAGUE_CODE[row['league']]+':'+native);fresh.append(row)
    index=['game_id','side','official_player_id'];old=p.set_index(index);new=pd.DataFrame(fresh).set_index(index)
    assert not new.index.duplicated().any();p=new.combine_first(old)
    for col in ['minutes','minutes_basis','position']:
        known=old[col].dropna();p.loc[known.index,col]=known
    p=p.reset_index();p=p[p.game_id.isin(g.game_id)].copy()
    if include_uefa_exposure:
        from uefa_exposure_features import merge_exposure
        p,uefa_audit=merge_exposure(p)
        evidence['uefa_exposure']=uefa_audit
    if include_club_recovery:
        from laliga_recovered_features import merge_club_players,PLAYER_FEATURES
        p,club_audit=merge_club_players(p)
        evidence['laliga_club_recovery']=club_audit
        metrics.extend(field for field in PLAYER_FEATURES if field not in metrics)
    if include_maker_recovery:
        assert include_club_recovery
        from laliga_maker_features import merge_players
        p,maker_audit=merge_players(p)
        evidence['laliga_maker_recovery']=maker_audit
    if include_pl_zero_recovery:
        assert include_maker_recovery
        from pl_sparse_statistics import merge_proved_zeros
        p,pl_audit=merge_proved_zeros(p,audit_dir=OUT if include_pl_lineup_recovery else None)
        evidence['pl_proved_zero_recovery']=pl_audit
    if include_pl_lineup_recovery:
        assert include_pl_zero_recovery
        from pl_lineup_feature_recovery import merge_players
        p,recovery=merge_players(p,OUT)
        evidence['pl_lineup_recovery']=recovery
    assert not p.duplicated(['game_id','side','player_id']).any()
    with read_db(ROOT_OUT/'soccer_additional.sqlite') as c:records=[json.loads(b) for b, in c.execute('SELECT body FROM games')]
    if include_club_recovery:
        from laliga_recovered_features import records as club_records
        recovered,_=club_records()
        assert not set(r['game_id'] for r in records)&set(r['game_id'] for r in recovered)
        records.extend(recovered)
    if include_maker_recovery:
        from laliga_maker_features import records as maker_records
        recovered=maker_records()
        assert not set(r['game_id'] for r in records)&set(r['game_id'] for r in recovered)
        records.extend(recovered)
    teamrows=[]
    for record in records:
        for r in record['teams']:
            row={k:v for k,v in r.items() if k in ['game_id','side'] or isinstance(v,(int,float)) or v is None}
            if record.get('league')=='Ligue 1' and not include_ligue_xg:
                row.pop('xg',None)  # Frozen baseline recipe; recovery is evaluated explicitly.
            for col,native in TEAM_RAW.items():
                if native in r.get('raw_stats',{}):row[col]=r['raw_stats'][native]
            teamrows.append(row)
    idx=['game_id','side'];o=pd.DataFrame(teamrows).set_index(idx).combine_first(o.set_index(idx))
    # Aggregate only explicitly supplied player totals with complete appearance
    # evidence; absent individual actions are never silently filled with zero.
    aggregation=collections.Counter()
    for key,group in p.groupby(idx,sort=False):
        active=group[pd.to_numeric(group.minutes,errors='coerce').gt(0)]
        if active.empty:continue
        complete=active.started.eq(True).sum()==11 and active.minutes.sum()>=990
        if not complete:continue
        for col in PLAYER_TOTALS:
            if col not in active or active[col].isna().any():continue
            name='expected_goals' if col=='xg' else col
            value=float(active[col].sum())
            if name not in o:o[name]=np.nan
            if pd.isna(o.loc[key,name]):o.loc[key,name]=value;aggregation[name]+=1
    o=o.reset_index()
    def ratio(a,b):return a/b.where(b>0)
    for field in ['passes','passes_completed','long_passes','final_third_passes','final_third_passes_completed','aerials_won','aerials_lost','interceptions','tackles']:
        if field not in o:o[field]=np.nan
    o['quality_xg']=o.expected_goals.combine_first(o.xg)
    swap=o[['game_id','side','shots','shots_on_target','quality_xg','passes']].copy();swap.side=swap.side.map({'A':'B','B':'A'})
    swap=swap.rename(columns={c:c+'_opponent' for c in swap if c not in idx});o=o.merge(swap,on=idx,validate='one_to_one')
    derived={
        'shot_share':ratio(o.shots,o.shots+o.shots_opponent),
        'on_target_share':ratio(o.shots_on_target,o.shots_on_target+o.shots_on_target_opponent),
        'passing_completion':ratio(o.passes_completed,o.passes),
        'direct_passing_fraction':ratio(o.long_passes,o.passes),
        'final_third_completion':ratio(o.final_third_passes_completed,o.final_third_passes),
        'box_attempt_fraction':ratio(o.box_shots,o.shots),
        'box_entries_per100_passes':100*ratio(o.box_entries,o.passes),
        'aerial_win_fraction':ratio(o.aerials_won,o.aerials_won+o.aerials_lost),
        'defensive_actions_per100_opponent_passes':100*ratio(o.interceptions+o.tackles,o.passes_opponent),
        'attacking_recoveries_per100_opponent_passes':100*ratio(o.recoveries_attacking_third,o.passes_opponent),
    }
    for name,value in derived.items():o['context8_'+name]=value;stats.append('context8_'+name)
    o['quality_xg_against']=o.quality_xg_opponent;o['finishing_residual']=o.score_for-o.quality_xg
    for field in ['passes','long_passes','long_passes_completed']:
        if field not in metrics:metrics.append(field)
    # Player reports occasionally have a later modeled release than the result.
    # Delay observation ingestion, but retain original result availability for
    # expanding model fits instead of hiding already-known game labels.
    if include_club_recovery:
        from laliga_recovered_features import correct_clocks
        g,o,p=correct_clocks(g,o,p)
    labels=g[['game_id','available_time']].copy();p['available_at_utc']=pd.to_datetime(p.available_at_utc,utc=True,format='mixed')
    latest=p.groupby('game_id').available_at_utc.max();g=g.copy()
    g['available_time']=pd.concat([g.available_time,g.game_id.map(latest)],axis=1).max(axis=1)
    o['available_time']=o.game_id.map(g.set_index('game_id').available_time)
    evidence.update(extra_official_player_rows=len(fresh),source_player_rows=len(p),complete_player_total_fills=dict(aggregation))
    evidence['input_hashes'].update({file:file_sha256(ROOT_OUT/file) for file in ['uefa_passing.sqlite','seriea_players.sqlite']})
    if include_club_recovery:
        evidence['input_hashes'].update({file:file_sha256(ROOT_OUT/file) for file in ['laliga_club.sqlite','laliga_clock_audit.json','laliga_club_validation.json']})
    if include_maker_recovery:
        evidence['input_hashes'].update({file:file_sha256(ROOT_OUT/file) for file in ['laliga_maker.sqlite','laliga_maker_validation.json']})
    if include_pl_zero_recovery:
        from pl_sparse_statistics import RUN as pl_run
        evidence['input_hashes']['pl_zero_proofs.parquet']=hashlib.sha256((pl_run/'pl_zero_proofs.parquet').read_bytes()).hexdigest()
    # Apply only verified native terminal-event clock corrections after every
    # player feed is merged. Frozen baseline matrices remain immutable.
    if apply_clock_corrections and (ROOT_OUT/'retention/soccer_match_phases_validation.json').exists():
        from soccer_clock_recovery import corrections,apply
        fixes=corrections()
        if len(fixes):
            g,o,p,labels,audit=apply(g,o,p,labels,fixes)
            evidence['native_terminal_clock_repairs']=audit
    return g,o,p,keys,stats,metrics,evidence,labels


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--include-exposure',action='store_true');parser.add_argument('--include-uefa-exposure',action='store_true');parser.add_argument('--include-club-recovery',action='store_true');parser.add_argument('--include-maker-recovery',action='store_true');parser.add_argument('--include-pl-zero-recovery',action='store_true');args=parser.parse_args()
    g,o,p,keys,stats,metrics,evidence,labels=context_sources(include_exposure=args.include_exposure,include_uefa_exposure=args.include_uefa_exposure,include_club_recovery=args.include_club_recovery,include_maker_recovery=args.include_maker_recovery,include_pl_zero_recovery=args.include_pl_zero_recovery,include_pl_lineup_recovery=getattr(args,'include_pl_lineup_recovery',False));f,audit=build('soccer',g,o,p,keys,stats,metrics)
    f['observation_available_time']=f.available_time;f['available_time']=f.game_id.map(labels.set_index('game_id').available_time)
    aliases=[]
    for col in [c for c in f if c.startswith('f_context8_') and c.endswith('_diff')]:
        name=col.replace('f_context8_','f_ctx_');f[name]=f[col];aliases.append(dict(column=name,source_column=col))
    for field in ['quality_xg','quality_xg_against','finishing_residual','shots_on_target','big_chances','roster_goals_rate','roster_assists_rate','roster_key_passes_rate']:
        name='f_ctx_'+field+'_diff';source='f_'+field+'_diff';f[name]=f[source];aliases.append(dict(column=name,source_column=source))
    if args.include_exposure:
        for field in ['roster_distance_covered_km_rate','roster_challenges_won_rate','roster_shots_at_goal_rate','roster_players']:
            name='f_ctx_'+field+'_diff';source='f_'+field+'_diff';f[name]=f[source];aliases.append(dict(column=name,source_column=source))
    if args.include_club_recovery:
        from laliga_recovered_features import PLAYER_FEATURES
        for field in PLAYER_FEATURES:
            source='f_roster_'+field+'_rate_diff';name='f_ctx_roster_'+field+'_rate_diff'
            f[name]=f[source];aliases.append(dict(column=name,source_column=source))
    f.to_parquet(OUT/'soccer_features.parquet',index=False)
    o.to_parquet(OUT/'soccer_context_team_observations.parquet',index=False)
    dump(OUT/'soccer_context_feature_audit.json',dict(at_utc=stamp(),games=len(f),columns=aliases,evidence=evidence,
        future_input_violations=0,delayed_observations=int(f.observation_available_time.gt(f.available_time).sum()),
        missing_pct={r['column']:float(100*f[r['column']].isna().mean()) for r in aliases},
        definitions='Per-game team-play ratios; both components required. Earlier completed games only. Source-specific raw measurements retained.'))
    print(json.dumps(dict(games=len(f),features=len(aliases),player_rows=len(p),filled_team_totals=evidence['complete_player_total_fills'])),flush=True)


if __name__=='__main__':main()
