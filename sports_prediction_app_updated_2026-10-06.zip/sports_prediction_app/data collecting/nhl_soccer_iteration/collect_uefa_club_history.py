"""Additional official UEFA club results for sparse opponent histories.

Europa/Conference results enrich prior team histories; they do not become
priced research opportunities or acquire invented market odds. Original native
IDs and API responses are retained, including unresolved score/clock records.
"""
import argparse
import collections
import json
import re
import sqlite3
import sys
from pathlib import Path
from urllib.parse import urlencode
import pandas as pd
from common import ROOT_OUT, PROJECT, OfficialClient, dump, stamp, file_sha256
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from uefa_regulation_scores import score

TABLE='soccer_additional_club_results'
DB=ROOT_OUT/'uefa_additional_club_history.sqlite'
PROOF=ROOT_OUT/'retention/uefa_additional_club_history_validation.json'
COMPETITIONS=[(14,'UEFA Europa League','uefaeuropaleague',2021),(2019,'UEFA Conference League','uefaconferenceleague',2022)]
BASE='https://match.uefa.com/v5/matches'
SUSPENDED_EVIDENCE={'2046324':'https://nk-rijeka.hr/rijeka-sparta-10-adu-adjei-odlucio-utakmicu-koja-je-trajala-1325-minuta/'}


def connect():
    db=sqlite3.connect(DB)
    db.executescript('CREATE TABLE IF NOT EXISTS matches(game_id TEXT PRIMARY KEY,body TEXT NOT NULL);'
        'CREATE TABLE IF NOT EXISTS pages(url TEXT PRIMARY KEY,body TEXT NOT NULL);'
        'CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,body TEXT NOT NULL);')
    return db


def normalize(m,source,index,cid,league,slug,client):
    native=str(m['id']);a=m['awayTeam'];b=m['homeTeam']
    assert str(m['competition']['id'])==str(cid) and m['status']=='FINISHED'
    assert all(t['typeTeam']=='DOMESTIC' and not t.get('isPlaceHolder') for t in [a,b]),'Expected official DOMESTIC club-team type'
    assert a['id']!=b['id']
    ko=m['kickOffTime'];start=pd.Timestamp(ko['dateTime']);assert start.tzinfo
    assert '2021-01-01'<=ko['date']<='2026-09-30'
    sources=[source];result=score(m)
    if result['scores'] is None:
        detail,s=client.get(BASE+'/'+native,'Resolve ambiguous historical regulation score '+native,'official_match_metadata')
        assert isinstance(detail,dict) and str(detail['id'])==native
        result=score(detail);sources.append(s)
    assert result['scores'] is not None,'Regulation score requires native event replay'
    end=m.get('fullTimeAt');reported=pd.Timestamp(end) if end else pd.NaT
    basis='official_fullTimeAt'
    if pd.isna(reported):
        # Availability for modelling, explicitly not a fabricated final whistle.
        reported=start.normalize()+pd.Timedelta(days=1);basis='conservative_next_utc_day_no_source_final_clock'
    elif not 1<=(reported-start).total_seconds()/3600<=12:
        events=[];seen=set()
        for offset in range(0,5000,500):
            page,s=client.get(BASE+'/'+native+'/events?'+urlencode(dict(filter='ALL',limit=500,offset=offset,order='ASC')),
                'Recover contemporaneous end clock '+native,'official_match_events')
            assert isinstance(page,list);sources.append(s)
            ids=[str(e['id']) for e in page];assert not set(ids)&seen
            seen.update(ids);events.extend(page)
            if len(page)<500:break
        else:raise AssertionError('End-clock event pagination unfinished')
        terminals=[e for e in events if e.get('timestamp') and e.get('type') in ['FULL_TIME','END_PHASE']
            and e.get('phase') in ['SECOND_HALF','EXTRA_TIME_SECOND_HALF','PENALTY']
            and 1<=(pd.Timestamp(e['timestamp'])-start).total_seconds()/3600<=12]
        if terminals:
            reported=max(pd.Timestamp(e['timestamp']) for e in terminals)
            basis='native_terminal_event_after_invalid_metadata_clock'
        elif native in SUSPENDED_EVIDENCE:
            # A long elapsed time can be a real suspension. This match's
            # official club report explicitly confirms play over two days.
            client.HOSTS.add('nk-rijeka.hr')
            body,s=client.get(SUSPENDED_EVIDENCE[native],'Verify Rijeka-Sparta resumed the following day','official_club_match_report',document=True)
            assert body and b'1325' in body;sources.append(s)
            resumed=[pd.Timestamp(e['timestamp']) for e in events if e.get('type')=='START_PHASE' and e.get('phase')=='SECOND_HALF' and e.get('timestamp')]
            ends=[pd.Timestamp(e['timestamp']) for e in events if e.get('type')=='FULL_TIME' and e.get('phase')=='SECOND_HALF' and e.get('timestamp')]
            assert len(resumed)==len(ends)==1 and ends[0]==reported
            assert resumed[0].date()>start.date() and 30<=(reported-resumed[0]).total_seconds()/60<=150
            basis='official_fullTimeAt_verified_next_day_resumption'
        else:raise AssertionError('No native contemporaneous end clock')
    assert reported>start
    sa,sb=result['scores']
    return dict(game_id='HIST_'+m['competition']['code']+'_'+native,official_game_id=native,
        competition_id=str(cid),league=league,date=ko['date'],season_year=int(m['seasonYear']),
        start_time=start.isoformat(),available_time=reported.isoformat(),raw_full_time=end,
        availability_basis=basis,teamA_id=str(a['id']),teamB_id=str(b['id']),
        teamA=a.get('translations',{}).get('displayOfficialName',{}).get('EN') or a['internationalName'],
        teamB=b.get('translations',{}).get('displayOfficialName',{}).get('EN') or b['internationalName'],
        regulation_scoreA=sa,regulation_scoreB=sb,match_type=m.get('type'),
        public_url='https://www.uefa.com/'+slug+'/match/'+native+'/',
        score_basis=result['score_basis'],score_evidence_json=json.dumps(result,sort_keys=True),
        source_json=json.dumps(dict(responses=sources,pointer='/'+str(index)),sort_keys=True))


def publish(f):
    definitions={
        'game_id':('Canonical historical UEFA match identifier','identifier'),
        'official_game_id':('Native UEFA match identifier','identifier'),
        'competition_id':('Native competition identifier:14 Europa,2019 Conference','identifier'),
        'league':('Actual UEFA competition name; history source, not a priced market','category'),
        'date':('Official local match calendar date','YYYY-MM-DD'),
        'season_year':('UEFA ending season year','year'),
        'start_time':('Official kickoff time','UTC timestamp'),
        'available_time':('Causal history availability; see availability_basis','UTC timestamp'),
        'raw_full_time':('Original API final clock, preserved even if absent or invalid','UTC timestamp or null'),
        'availability_basis':('Official final clock, verified native terminal event, or explicitly conservative next-day availability','category'),
        'teamA_id':('Native UEFA away-club ID','identifier'),
        'teamB_id':('Native UEFA home-club ID','identifier'),
        'teamA':('Official away-club name','text'),
        'teamB':('Official home-club name','text'),
        'regulation_scoreA':('Away goals in90minutes plus stoppage; excludes extra time and penalties','goals'),
        'regulation_scoreB':('Home goals in90minutes plus stoppage; excludes extra time and penalties','goals'),
        'match_type':('Official first-leg,second-leg,single or group classification','category'),
        'public_url':('Official public match verification page','URL'),
        'score_basis':('Official regular score or reconciled phase-specific goal timeline','text'),
        'score_evidence_json':('Original regular/total values and phase reconciliation','JSON'),
        'source_json':('Exact API request URL, timestamp, raw file, hash and item pointer','JSON')}
    assert set(definitions)==set(f)
    f.to_parquet(ROOT_OUT/(TABLE+'.parquet'),index=False);f.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        f.to_sql(TABLE,db,if_exists='replace',index=False)
        for name in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+name+' WHERE [table]=?',(TABLE,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(TABLE,len(f),len(f.columns)))
        for c in f:
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(TABLE,c,*definitions[c],'Official match.uefa.com API; competition IDs confirmed in official fixture-page metadata.'))
            db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(TABLE,c,len(f),int(f[c].isna().sum()),100*f[c].isna().mean()))
    from publish import main
    main()


def main():
    client=OfficialClient(per_second=2);db=connect();requests=[];complete=[];milestone=10
    status_counts=collections.Counter();nonfinished=[]
    jobs=[(cid,name,slug,year) for cid,name,slug,first in COMPETITIONS for year in range(first,2028)]
    # Re-read the official website metadata on every collection/replay.
    docs=[]
    for cid,name,slug,first in COMPETITIONS:
        body,s=client.get('https://www.uefa.com/'+slug+'/fixtures-results/',
            'Confirm official '+name+' competition identifier','official_api_discovery',document=True)
        assert body and re.search(r"window.competitionId\s*=\s*'"+str(cid)+"'",body.decode('utf8'))
        docs.append(s)
    for j,(cid,league,slug,year) in enumerate(jobs,1):
        offset=0;seen=set();finished=0
        while True:
            assert offset<10000,'Unexpectedly large calendar; inspect pagination'
            params=dict(competitionId=cid,seasonYear=year,fromDate='2021-01-01',toDate='2026-09-30',order='ASC',limit=500,offset=offset)
            url=BASE+'?'+urlencode(params)
            data,source=client.get(url,'Collect '+league+' season'+str(year)+' dated club history','official_club_history')
            assert isinstance(data,list),'Calendar request failed; retry instead of skipping'
            requests.append(source);ids=[str(m['id']) for m in data]
            assert len(ids)==len(set(ids)) and not seen.intersection(ids),'Repeated calendar page'
            seen.update(ids)
            with db:
                db.execute('INSERT OR REPLACE INTO pages VALUES(?,?)',(url,json.dumps(dict(source=source,rows=len(data)))))
                for i,m in enumerate(data):
                    assert str(m['competition']['id'])==str(cid) and int(m['seasonYear'])==year
                    status_counts[m['status']]+=1
                    if m['status']!='FINISHED':
                        nonfinished.append(dict(id=str(m['id']),status=m['status'],date=m['kickOffTime']['date']))
                        continue
                    finished+=1;key='HIST_'+m['competition']['code']+'_'+str(m['id'])
                    try:
                        row=normalize(m,source,i,cid,league,slug,client)
                        db.execute('INSERT OR REPLACE INTO matches VALUES(?,?)',(key,json.dumps(row)))
                        db.execute('DELETE FROM issues WHERE game_id=?',(key,))
                    except (AssertionError,KeyError,ValueError,TypeError) as exc:
                        db.execute('INSERT OR REPLACE INTO issues VALUES(?,?)',(key,json.dumps(dict(reason=repr(exc),source=source,pointer='/'+str(i),resolution='Requires source replay; not labelled unavailable'))))
            # Continue even when an API caps page size below requested limit.
            if not data:break
            offset+=len(data)
        complete.append(dict(competition_id=cid,season_year=year,listed=len(seen),finished=finished))
        while 100*j/len(jobs)>=milestone:
            print(json.dumps(dict(stage='uefa_additional_history',percent=milestone,complete_seasons=j,total_seasons=len(jobs))),flush=True)
            milestone+=10
        dump(ROOT_OUT/'retention/uefa_additional_club_progress.json',dict(at_utc=stamp(),complete_seasons=complete,total_seasons=len(jobs)))
    f=pd.DataFrame([json.loads(b) for b, in db.execute('SELECT body FROM matches ORDER BY game_id')])
    issues=[dict(game_id=k,**json.loads(v)) for k,v in db.execute('SELECT * FROM issues')];db.close()
    assert f.official_game_id.is_unique
    assert len(f)+len(issues)==sum(x['finished'] for x in complete)
    # Replay every normalized row's original identities, clocks and score.
    cache={};replayed=0
    for r in f.itertuples():
        source=json.loads(r.source_json);s=source['responses'][0];key=s['raw_file']
        if key not in cache:
            p=PROJECT/key;assert file_sha256(p)==s['sha256'];cache[key]=json.loads(p.read_bytes())
        m=cache[key][int(source['pointer'][1:])]
        assert str(m['id'])==r.official_game_id
        assert [str(m['awayTeam']['id']),str(m['homeTeam']['id'])]==[r.teamA_id,r.teamB_id]
        assert pd.Timestamp(m['kickOffTime']['dateTime'])==pd.Timestamp(r.start_time)
        if score(m)['scores'] is not None:assert score(m)['scores']==[r.regulation_scoreA,r.regulation_scoreB]
        replayed+=1
    publish(f)
    missing_clock_checks=[]
    for r in f[f.raw_full_time.isna()].itertuples():
        meta,s=client.get(BASE+'/'+r.official_game_id,'Check detailed metadata for missing final clock','official_match_metadata')
        events,e=client.get(BASE+'/'+r.official_game_id+'/events?filter=ALL&limit=500&offset=0&order=ASC',
            'Check native terminal events for missing final clock','official_match_events')
        assert isinstance(meta,dict) and isinstance(events,list) and len(events)<500
        terminal=[dict(id=x.get('id'),type=x.get('type'),phase=x.get('phase'),timestamp=x.get('timestamp')) for x in events if x.get('type') in ['END_PHASE','FULL_TIME']]
        assert meta.get('fullTimeAt') is None and not any(x['phase'] in ['SECOND_HALF','EXTRA_TIME_SECOND_HALF'] for x in terminal), 'New terminal evidence requires an explicit historical clock repair'
        missing_clock_checks.append(dict(game_id=r.game_id,metadata_source=s,event_source=e,
            detail_fullTimeAt=None,terminal_events=terminal,conservative_availability_kept=r.available_time))
    dump(ROOT_OUT/'retention/uefa_missing_clock_probe.json',dict(at_utc=stamp(),checks=missing_clock_checks,
        interpretation='Detailed metadata and native events both lack a terminal clock. No actual final-whistle time invented.'))
    proof=dict(at_utc=stamp(),status='PASS' if not issues else 'PENDING_SOURCE_RECONCILIATION',rows=len(f),raw_replays=replayed,
        first_date=f.date.min(),last_date=f.date.max(),complete_pagination=True,finished_expected=sum(x['finished'] for x in complete),
        unresolved=issues,calendar_response_count=len(requests),seasons=complete,official_documentation_sources=docs,
        all_listed_status_counts=dict(status_counts),nonfinished_records=nonfinished,
        missing_percent={c:float(100*f[c].isna().mean()) for c in f if f[c].isna().any()},
        missing_final_clock_followup='retention/uefa_missing_clock_probe.json',
        public_verification_urls=['https://www.uefa.com/uefaeuropaleague/match/2040996/',
            'https://www.uefa.com/uefaconferenceleague/match/2041007/',SUSPENDED_EVIDENCE['2046324']],
        counts_by_league=f.league.value_counts().to_dict(),availability_basis=f.availability_basis.value_counts().to_dict(),
        output_sha256=file_sha256(ROOT_OUT/(TABLE+'.parquet')),no_market_prices_added=True,no_app_changes=True)
    dump(PROOF,proof)
    from final_pipeline import cleanup
    cleanup();print(json.dumps({k:v for k,v in proof.items() if k not in ['unresolved','seasons','official_documentation_sources']}),flush=True)
    if issues:print(json.dumps(dict(unresolved=issues),ensure_ascii=True),flush=True)


if __name__=='__main__':main()
