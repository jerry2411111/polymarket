"""Recover official Ligue 1 team shot-quality values from retained original responses."""
import collections,hashlib,json,sqlite3
import pandas as pd
from common import ROOT_OUT,PROJECT,PREVIOUS,REPORTS,read_db,dump,stamp
from soccer_additional_facts import ligue_expected_goals

TABLE='ligue1_teams_match_statistics'
SOURCE='Official Ligue 1 championship-match API, /home/stats/expectedGoals or /away/stats/expectedGoals. Source URL, raw path, retrieval time and SHA256 are retained in source; native field pointer in xg_pointer. Definitions: https://ligue1.com/fr/articles/l1_article_497-le-meilleur-tutoriel-pour-comprendre-les-expected-goals'
DESCR={
 'xg_raw':('Unchanged official expectedGoals value, including ambiguous historical zeros.','expected goals'),
 'xg':('Official expected goals when positive and consistent with the shot count; explicit zero with zero shots is zero. Ambiguous zero placeholders and source disagreements are NULL. No value is estimated.','expected goals'),
 'xg_status':('Per-value interpretation: populated, explicit_zero_with_zero_shots, ambiguous_zero_placeholder, not_supplied, invalid_source_value or shot_count_disagreement.','category'),
 'xg_pointer':('Exact JSON pointer to the native expectedGoals field in the retained official response.','JSON pointer')}


def main():
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games={r['game_id']:dict(r) for r in db.execute("SELECT * FROM soccer_games WHERE league='Ligue 1'")}
    with read_db(ROOT_OUT/'soccer_additional.sqlite') as db:
        records=[json.loads(b) for b, in db.execute("SELECT body FROM games WHERE league='Ligue 1'")]
    rows=[];updates=[];examples=[];seen=set();counts=collections.Counter();raw_cells=0
    for i,record in enumerate(records):
        game=games[record['game_id']];ids=list(map(str,json.loads(game['native_team_ids_json'])))
        for row in record['teams']:
            s=row['source'];blob=(PROJECT/s['raw_file']).read_bytes()
            assert hashlib.sha256(blob).hexdigest()==s['sha256']
            raw=json.loads(blob);native='away' if row['side']=='A' else 'home';side_index=0 if native=='away' else 1
            assert str(raw['id'])==str(game['official_game_id']) and raw['period']=='fullTime'
            assert pd.Timestamp(raw['date'])==pd.Timestamp(game['start_time'])
            team=raw[native];assert ids[side_index]==str(row['team_id'])
            assert team['clubId']==f"l1_championship_club_{raw['season']}_{ids[side_index]}"
            if team['clubIdentity'].get('shortId') is not None:
                assert str(team['clubIdentity']['shortId'])==ids[side_index]
            score=team['score'];score=score.get('fullTime',score.get('total')) if isinstance(score,dict) else score
            assert score==game['score'+row['side']]
            assert row['raw_stats']==team['stats']
            fields=ligue_expected_goals(team['stats'],native);row.update(fields)
            if row['xg'] is not None:assert row['xg']==row['xg_raw']
            counts[(row['date'][:4],row['xg_status'])]+=1;raw_cells+=1;seen.add(s['sha256'])
            output=dict(row);output['source']=json.dumps(output['source'],sort_keys=True)
            output['raw_stats']=json.dumps(output['raw_stats'],sort_keys=True);rows.append(output)
            year=row['date'][:4]
            if row['xg_status']=='populated' and year not in {e['year'] for e in examples}:
                examples.append(dict(year=year,game_id=row['game_id'],date=row['date'],side=row['side'],
                    team=team['clubIdentity']['officialName'],opponent=raw['home' if native=='away' else 'away']['clubIdentity']['officialName'],
                    score=score,raw_value=row['xg_raw'],normalized_value=row['xg'],pointer=row['xg_pointer'],source=s,match=True))
        record['xg_parser_version']=1;updates.append(record)
        if (i+1)%200==0:print(json.dumps(dict(stage='verify_official_responses',complete=i+1,total=len(records))),flush=True)
    frame=pd.DataFrame(rows);assert not frame.duplicated(['game_id','side']).any()
    with sqlite3.connect(ROOT_OUT/'soccer_additional.sqlite') as db:
        db.executemany("UPDATE games SET body=? WHERE league='Ligue 1' AND game_id=?",
                       [(json.dumps(r,allow_nan=False),r['game_id']) for r in updates])
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        old=pd.read_sql_query('SELECT * FROM '+TABLE,db).set_index(['game_id','side']).sort_index()
        now=frame.set_index(['game_id','side']).sort_index()
        for c in old:
            if c in DESCR:continue
            if c in ['source','raw_stats']:assert all(json.loads(a)==json.loads(b) for a,b in zip(old[c],now[c]))
            else:pd.testing.assert_series_equal(old[c],now[c],check_dtype=False,check_names=False)
        frame.to_sql(TABLE,db,if_exists='replace',index=False,chunksize=1000)
        for name,(meaning,unit) in DESCR.items():
            db.execute('DELETE FROM column_catalog WHERE "table"=? AND "column"=?',(TABLE,name))
            db.execute('INSERT INTO column_catalog("table","column",meaning,unit,source) VALUES(?,?,?,?,?)',(TABLE,name,meaning,unit,SOURCE))
        db.execute('DELETE FROM missing_report WHERE "table"=?',(TABLE,))
        for name in frame:
            missing=int(frame[name].isna().sum())
            db.execute('INSERT INTO missing_report("table","column",rows,missing,missing_pct) VALUES(?,?,?,?,?)',(TABLE,name,len(frame),missing,100*missing/len(frame)))
        db.execute('UPDATE table_catalog SET rows=?,columns=? WHERE "table"=?',(len(frame),len(frame.columns),TABLE))
    frame.to_parquet(ROOT_OUT/(TABLE+'.parquet'),index=False);frame.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    coverage=pd.DataFrame([dict(year=y,status=s,rows=n) for (y,s),n in sorted(counts.items())])
    coverage.to_csv(REPORTS/'ligue1_xg_coverage.csv',index=False)
    result=dict(status='PASS',at_utc=stamp(),raw_responses=len(seen),raw_cells=raw_cells,games=len(records),rows=len(frame),
                populated=int(frame.xg.notna().sum()),missing=int(frame.xg.isna().sum()),missing_pct=100*frame.xg.isna().mean(),
                no_unrelated_values_changed=True,network_requests=0,examples=examples,
                limitation='Current official historical responses do not establish the original publication vintage of xG model revisions. Modeled completed-game availability is retained; source retrieval timestamps remain explicit.')
    dump(ROOT_OUT/'retention/ligue1_xg_validation.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ['examples','limitation']}),flush=True)
    from publish import main as catalog
    catalog()


def build_feature_revision():
    """Change only the three existing shot-quality contrasts; replay old inputs first."""
    import numpy as np
    import team_context_features
    work=ROOT_OUT/'_work/ligue_xg';work.mkdir(parents=True,exist_ok=True)
    team_context_features.OUT=work
    g,o,p,keys,stats,metrics,evidence,labels=team_context_features.context_sources(include_exposure=True,include_uefa_exposure=True)
    del p
    baseline=pd.read_parquet(ROOT_OUT/'retained_models/soccer/soccer_features.parquet')
    g=g[g.game_id.isin(baseline.game_id)].copy();assert len(g)==len(baseline)
    g['available_time']=g.game_id.map(baseline.set_index('game_id').observation_available_time)
    old=o[['game_id','side','quality_xg','quality_xg_against','finishing_residual']].copy()
    new=old.copy().set_index(['game_id','side'])
    with read_db(ROOT_OUT/'granular.sqlite') as db:
        recovered=pd.read_sql_query('SELECT game_id,side,xg,available_at_utc FROM '+TABLE+' WHERE xg IS NOT NULL',db)
    changed=0
    scores=g.set_index('game_id')[['scoreA','scoreB']]
    for r in recovered.itertuples():
        if r.game_id not in set(g.game_id):continue
        assert pd.Timestamp(r.available_at_utc)<=g.set_index('game_id').at[r.game_id,'available_time']
        key=(r.game_id,r.side);other=(r.game_id,'B' if r.side=='A' else 'A')
        before=new.at[key,'quality_xg'];assert pd.isna(before) or np.isclose(before,r.xg,rtol=0,atol=1e-12)
        changed+=int(pd.isna(before));new.at[key,'quality_xg']=r.xg
        new.at[other,'quality_xg_against']=r.xg
        new.at[key,'finishing_residual']=scores.at[r.game_id,'score'+r.side]-r.xg
    new=new.reset_index()

    def derive(games,observations):
        fields=['quality_xg','quality_xg_against','finishing_residual']
        lookup=observations.set_index(['game_id','side'])[fields].to_dict('index')
        events=list(games.sort_values(['available_time','game_id']).itertuples());cursor=0;history=collections.defaultdict(lambda:collections.deque(maxlen=60));out=[]
        for game in games.sort_values(['prediction_time','game_id']).itertuples():
            while cursor<len(events) and events[cursor].available_time<game.prediction_time:
                e=events[cursor];cursor+=1
                for side in ['A','B']:history[keys[e.game_id,side]].append((lookup[e.game_id,side],e.available_time))
            record={'game_id':game.game_id};latest=[];values={}
            for side in ['A','B']:
                h=list(history[keys[game.game_id,side]])
                values[side]={}
                for field in fields:
                    pairs=[(.94**i,r[field]) for i,(r,at) in enumerate(reversed(h)) if pd.notna(r[field])]
                    values[side][field]=sum(w*v for w,v in pairs)/sum(w for w,v in pairs) if pairs else np.nan
                    latest.extend(at for r,at in h if pd.notna(r[field]))
            for field in fields:
                record['f_'+field+'_diff']=values['B'][field]-values['A'][field]
                record['f_'+field+'_sum']=values['B'][field]+values['A'][field]
            record['xg_source_max_available_utc']=max(latest) if latest else pd.NaT
            assert not latest or max(latest)<game.prediction_time;out.append(record)
        return pd.DataFrame(out).set_index('game_id')

    original=derive(g,old);revised=derive(g,new)
    used=[c for c in original if c.startswith('f_')]
    b=baseline.set_index('game_id');diff=~np.isclose(original.loc[b.index,used],b[used],equal_nan=True,rtol=0,atol=1e-10)
    if diff.any():
        issues=[]
        for i,j in zip(*np.where(diff)):
            issues.append(dict(game_id=b.index[i],column=used[j],old=float(b.iloc[i][used[j]]),replay=float(original.loc[b.index[i],used[j]])))
        # Preserve an honest discrepancy rather than mixing another data revision into this test.
        pd.DataFrame(issues).to_csv(work/'control_replay_discrepancies.csv',index=False)
        raise AssertionError(f'Frozen baseline replay differs in {len(issues)} cells; inspect before fitting.')
    candidate=baseline.copy();modified=[]
    for field in ['quality_xg','quality_xg_against','finishing_residual']:
        for suffix in ['diff','sum']:
            name='f_'+field+'_'+suffix;candidate[name]=candidate.game_id.map(revised[name]);modified.append(name)
        alias='f_ctx_'+field+'_diff';candidate[alias]=candidate['f_'+field+'_diff'];modified.append(alias)
    candidate['xg_source_max_available_utc']=candidate.game_id.map(revised.xg_source_max_available_utc)
    prefix=g[g.prediction_time.lt(pd.Timestamp('2025-01-01',tz='UTC'))]
    early=derive(prefix,new[new.game_id.isin(prefix.game_id)])
    pd.testing.assert_frame_equal(early,revised.loc[early.index],check_exact=True)
    unaffected=[c for c in baseline if c not in modified]
    pd.testing.assert_frame_equal(candidate[unaffected],baseline[unaffected],check_exact=True)
    delta=~np.isclose(candidate[modified],baseline[modified],equal_nan=True,rtol=0,atol=1e-10)
    candidate.to_parquet(work/'soccer_features.parquet',index=False)
    result=dict(status='PASS',at_utc=stamp(),rows=len(candidate),recovered_team_values=changed,
        control_replayed_cells=len(original)*len(used),prefix_invariant_rows=len(prefix),
        changed_feature_cells=int(delta.sum()),changed_game_rows=int(delta.any(axis=1).sum()),
        changed_model_inputs=3,other_columns_unchanged=True,
        fields=modified,feature_sha256=hashlib.sha256((work/'soccer_features.parquet').read_bytes()).hexdigest())
    dump(work/'feature_validation.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--build-features',action='store_true');args=parser.parse_args()
    if args.build_features:build_feature_revision()
    else:main()
