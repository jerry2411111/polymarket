"""Replay official starting elevens/substitutions through regulation and extra time.

Exposure excludes stoppage time, retains event clock precision, and never uses
current biography club IDs. Original official elapsed seconds remain separate.
"""
import collections,json
from collect_uefa_exposure import reconcile_aliases

BOUNDS={'FIRST_HALF':(0,45),'SECOND_HALF':(45,90),'EXTRA_TIME_FIRST_HALF':(90,105),'EXTRA_TIME_SECOND_HALF':(105,120)}


def minute(event):
    begin,end=BOUNDS[event['phase']];t=event['time']
    assert isinstance(t.get('minute'),(int,float)) and isinstance(t.get('second'),(int,float)) and 0<=t['second']<60,'Exact official substitution clock requires repair'
    if t.get('injuryMinute',0)>0:return float(end)
    return min(float(end),max(float(begin),t['minute']-1+t['second']/60))


def derive(game,lineup,events,sources):
    events,aliases=reconcile_aliases(events);mid=str(game['official_game_id']);native=json.loads(game['native_team_ids_json'])
    assert str(lineup['matchId'])==mid and all(str(e['matchId'])==mid for e in events)
    phases=['FIRST_HALF','SECOND_HALF']
    # Some post-match cards are mislabelled as extra time. Require a playing
    # phase boundary, not a card alone, before extending exposure to120minutes.
    if any(e.get('phase') in ['EXTRA_TIME_FIRST_HALF','EXTRA_TIME_SECOND_HALF'] and e['type'] in ['START_PHASE','END_PHASE'] for e in events):phases+=['EXTRA_TIME_FIRST_HALF','EXTRA_TIME_SECOND_HALF']
    total=BOUNDS[phases[-1]][1];boundary={(e['type'],e.get('phase')) for e in events}
    complete=all(any(e.get('phase')==p for e in events) for p in phases) and (('END_PHASE',phases[-1]) in boundary or ('FULL_TIME',phases[-1]) in boundary)
    identities={};sides={};issues=[]
    for e in events:
        if e.get('phase') in BOUNDS and e.get('phase') not in phases:
            issues.append(dict(event_id=e['id'],field='phase_without_playing_boundary',reason='Event assigned to an extra phase without a start/end boundary; no extra duration inferred'))
    for side,label,tid in zip(['A','B'],['awayTeam','homeTeam'],native):
        section=lineup[label];assert str(section['team']['id'])==str(tid) and len(section['field'])==11
        rows=[]
        for group in ['field','bench']:
            for slot in section[group]:
                p=slot['player'];pid=str(p['id']);assert pid not in identities
                row=dict(game_id=game['game_id'],official_game_id=mid,league=game['league'],date=game['date'],side=side,team_id=str(tid),
                    team_key='EU_UEFA_CLUB:'+str(tid),official_player_id=pid,player_name=p.get('internationalName') or p['translations']['name']['EN'],
                    started=group=='field',lineup_group=group,game_minutes_regulation_extra=total,available_at_utc=game['available_time'])
                identities[pid]=row;rows.append(row)
        sides[side]=rows
    unknown=collections.defaultdict(list);transitions=collections.defaultdict(list)
    for i,e in enumerate(events):
        if e.get('phase') not in phases or e['type'] not in ['SUBSTITUTION','RED_CARD','RED_YELLOW_CARD']:continue
        actor=e.get('primaryActor') or {};person=actor.get('person') or {};pid=str(person.get('id') or person.get('person',{}).get('id'))
        if actor.get('type')=='COACH' and pid not in identities:continue
        try:
            at=minute(e)
            if pid not in identities:
                # An unknown dismissal at the final boundary changes no
                # remaining exposure; preserve its identity issue explicitly.
                if e['type']!='SUBSTITUTION' and at==total:
                    issues.append(dict(event_id=e['id'],field='terminal_dismissal_identity',reason='Unknown actor at final playing-time boundary; no remaining minutes affected'));continue
                tid=str((actor.get('team') or {}).get('id'));affected=[['A','B'][native.index(tid)]] if tid in native else ['A','B']
                for side in affected:unknown[side].append('Unknown transition actor '+pid+' event '+str(e['id']))
                continue
            side=identities[pid]['side'];on=None
            if e['type']=='SUBSTITUTION':
                on=str(e['secondaryActor']['person']['id']);assert on in identities and identities[on]['side']==side,'Substitute missing or cross-team native identity'
            transitions[side].append((at,i,pid,on,e))
        except (AssertionError,KeyError,TypeError,ValueError) as exc:
            affected=[identities[pid]['side']] if pid in identities else ['A','B']
            for side in affected:unknown[side].append(type(exc).__name__+': '+str(exc)+' event '+str(e['id']))
    output=[];checks=[]
    for side,rows in sides.items():
        active={r['official_player_id']:0. for r in rows if r['started']};played=set(active);minutes=collections.Counter();dismissed=[];proof=[];error=None
        try:
            assert complete,'Full paginated feed lacks required completed phase boundaries'
            assert not unknown[side],'; '.join(unknown[side])
            observed=set()
            for at,_,off,on,e in sorted(transitions[side]):
                if (at,off,on) in observed:
                    issues.append(dict(event_id=e['id'],field='duplicate_exposure_transition',reason='Same native off/on IDs at the same normalized exposure time; raw event preserved, duration counted once'))
                    continue
                observed.add((at,off,on))
                if on is None and off not in active:continue # bench dismissal has no field exposure
                assert off in active and (on is None or on not in played),'Transition sequence contradicts dated active-player state'
                minutes[off]+=at-active.pop(off)
                if on is not None:active[on]=at;played.add(on)
                else:dismissed.append(at)
                proof.append(dict(event_id=e['id'],event_type=e['type'],phase=e['phase'],raw_time=e['time'],minute_excluding_stoppage=at,off_player_id=off,on_player_id=on))
            for pid,at in active.items():minutes[pid]+=total-at
            expected=11*total-sum(total-at for at in dismissed)
            assert abs(sum(minutes.values())-expected)<1e-7 and all(0<=v<=total for v in minutes.values())
            checks.append(dict(side=side,expected_team_minutes=expected,derived_team_minutes=sum(minutes.values()),dismissals=len(dismissed)))
        except (AssertionError,KeyError,TypeError,ValueError) as exc:
            error=type(exc).__name__+': '+str(exc);issues.append(dict(side=side,field='minutes_regulation_extra',reason=error))
        for r in rows:
            pid=r['official_player_id'];r.update(minutes_regulation_extra=float(minutes[pid]) if error is None else None,
                appeared=pid in played if error is None else (True if r['started'] else None),exposure_complete=error is None,
                minutes_basis='Official event minute/second; one-based minute normalized to elapsed regulation plus extra time, excluding stoppage. Zero only for a verified unused bench player in a complete feed.',
                transition_evidence_json=json.dumps(proof,sort_keys=True),source_json=json.dumps(sources,sort_keys=True));output.append(r)
    return dict(players=output,checks=checks,issues=issues,aliases=aliases,event_count=len(events),regulation_extra_minutes=total,version=2)
