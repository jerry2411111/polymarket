"""Public official Elche JSON API; no credentials or present-day widgets used.

Routes and parameter names are read from the official site's current client.
The upstream subscription API is not accessed after its anonymous401 response.
The website's own public /api endpoints require no credentials and return the
same dated match facts. Raw bodies precede transformation in OfficialClient.
"""
import argparse
import collections
import concurrent.futures
import hashlib
import json
import re
import sqlite3
from urllib.parse import urlencode
import pandas as pd

from common import OfficialClient,ROOT_OUT,PROJECT,PREVIOUS,dump,read_db,stamp
from laliga_retained_facts import page_props
from laliga_club_archive import games,label,calendar_teams
from laliga_club_players import FIELDS

DB=ROOT_OUT/'laliga_maker.sqlite'
HOST='https://www.elchecf.es'
OfficialClient.HOSTS.add('www.elchecf.es')
FIELDS={k:re.sub(r'_([a-z])',lambda m:m[1].upper(),v) for k,v in FIELDS.items()}


def connect():
    c=sqlite3.connect(DB,timeout=60)
    c.executescript('CREATE TABLE IF NOT EXISTS fixtures(game_id TEXT PRIMARY KEY,body TEXT NOT NULL); CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,body TEXT NOT NULL);')
    return c


def endpoint(path,**kwargs):return HOST+'/api/'+path+'?'+urlencode(dict(locale='es',**kwargs))


def discover():
    client=OfficialClient(2);wanted=games();native=calendar_teams()
    # Native season IDs come from real returned official match metadata.
    seed=json.loads((ROOT_OUT/'elche_discovery.json').read_bytes())['source']
    b=(PROJECT/seed['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==seed['sha256']
    d=page_props(b)['data'];seeds=[d['game']]+d['stats']['lastGames']
    editions={r['edition']['id']:r['edition'] for r in seeds if r['competition']['id']==d['game']['competition']['id']}
    fixtures=[];sources=[]
    for eid,edition in editions.items():
        offset=0;seen=set();total=None
        while True:
            url=endpoint('football_list/football_competition_match/variant_b',activeTab='results',editionId=eid,offset=offset,limit=100)
            body,s=client.get(url,'Official La Liga season result index: '+edition['name'],'official_club_archive_index')
            assert body is not None,s['return_status']
            if total is None:total=body['total']
            assert body['total']==total
            rows=body['data'];assert rows or offset>=total
            for r in rows:
                assert r['id'] not in seen and r['edition']['id']==eid
                seen.add(r['id']);fixtures.append(dict(fixture=r,source=s))
            sources.append(s);offset+=len(rows)
            if offset>=total:assert offset==total;break
        print(json.dumps(dict(stage='maker_archive_index',edition=edition['name'],games=total)),flush=True)
    corrected={r['game_id']:r['verified_start_utc'] for r in json.loads((ROOT_OUT/'laliga_clock_audit.json').read_bytes())['records']}
    byclock=collections.defaultdict(list)
    for gid,g in wanted.items():byclock[pd.Timestamp(corrected.get(gid,g['timestamp']))].append(g)
    aliases={key:{label(n) for n in v['names']} for key,v in native.items()}
    cross={};matched=[];issues=[]
    for item in fixtures:
        f=item['fixture']
        if not f.get('time'):continue
        if not '2021-01-01'<=f['date']<='2026-09-30':continue
        candidates=[]
        for g in byclock[pd.Timestamp(f['time'])]:
            a,b=json.loads(g['native_team_ids_json'])
            good=True
            for tid,key in [(a,'awayTeam'),(b,'homeTeam')]:
                t=f[key];names={label(t[n]) for n in ['name','nickname','shortName'] if t.get(n)}
                good=good and bool(names&aliases[tid])
            if good and [f['awayScore'],f['homeScore']]==[g['scoreA'],g['scoreB']]:candidates.append(g)
        if len(candidates)!=1:
            issues.append(dict(maker_game_id=f['id'],date=f['date'],slug=f['slug'],candidates=len(candidates),reason='No unique native-team names, exact clock and score match'));continue
        g=candidates[0];a,b=json.loads(g['native_team_ids_json'])
        for native_id,key in [(a,'awayTeam'),(b,'homeTeam')]:
            uid=f[key]['id'];assert uid not in cross or cross[uid]==native_id
            cross[uid]=native_id
        matched.append(dict(game_id=g['game_id'],official_game_id=g['official_game_id'],maker_game_id=f['id'],slug=f['slug'],
            date=f['date'],start_time=f['time'],available_at_utc=max(pd.Timestamp(g['available_time']),pd.Timestamp(f['time'])+pd.Timedelta(hours=6)).isoformat(),
            teamA=g['teamA'],teamB=g['teamB'],teamA_id=a,teamB_id=b,scoreA=g['scoreA'],scoreB=g['scoreB'],fixture=f,index_source=item['source']))
    assert len({m['game_id'] for m in matched})==len(matched)
    out=dict(at_utc=stamp(),editions=editions,index_sources=sources,seed_source=seed,matched=matched,unmatched=issues,team_crosswalk=cross)
    dump(ROOT_OUT/'laliga_maker_index.json',out)
    print(json.dumps(dict(matched=len(matched),unmatched=len(issues))),flush=True)


def opta_id(person):
    values=[person.get('imageMainUrl') or '',(person.get('image') or {}).get('url') or '']
    ids=set()
    for value in values:ids.update(re.findall(r'/(p\d+)/',value))
    assert len(ids)<=1,ids
    return next(iter(ids),None)


def parse(body,match,source):
    g=body['game'];assert g['id']==match['maker_game_id']
    assert pd.Timestamp(g['time'])==pd.Timestamp(match['start_time'])
    assert [g['awayScore'],g['homeScore']]==[match['scoreA'],match['scoreB']]
    assert g['competition']['id']=='1de31796-d3cc-4875-b7be-971186f64b84'
    assert body['events']['total']==len(body['events']['data']),'Incomplete dated event page'
    players=[];teams=[];managers=[];issues=[]
    for side,prefix in [('A','away'),('B','home')]:
        key=prefix+'Team';team=g[key];assert team['id']==match['fixture'][key]['id']
        lineup=body['lineups'][key];roster=[r for r in lineup if not r.get('manager')]
        starters=sum(r['starting'] for r in roster)
        assert starters<=11
        if starters!=11:issues.append(dict(side=side,reason='Official dated lineup contains fewer than11 starters',starters=starters))
        assert len({r['player']['id'] for r in roster})==len(roster)
        stats=body['stats'][key+'PlayersStats'];stat_map={r['player']['id']:(i,r) for i,r in enumerate(stats)}
        assert len(stat_map)==len(stats)
        unlinked=set(stat_map)-set(r['player']['id'] for r in roster)
        for pid in sorted(unlinked):issues.append(dict(side=side,maker_player_id=pid,reason='Statistic identity not in dated lineup; retained in raw, requires identity repair'))
        # A club-local player and its explicit master identity can be used in
        # different sections of the SAME official response. Resolve only this
        # documented relation, with an injective alias map; never match names.
        aliases={}
        for member in roster:
            person=member['player'];pid=person['id']
            for native in [pid,person.get('playerMaster')]:
                if native:
                    assert native not in aliases or aliases[native]==pid,'Ambiguous native player/master identity'
                    aliases[native]=pid
        entered={aliases.get(r['relatedPlayer']['id'],r['relatedPlayer']['id']) for r in body['events']['data'] if r.get('type',{}).get('type')=='PlayerOn' and (r.get('team') or {}).get('id')==team['id'] and r.get('relatedPlayer')}
        shared=dict(game_id=match['game_id'],official_game_id=match['official_game_id'],maker_game_id=g['id'],league='La Liga',date=match['date'],
            timestamp_utc=g['time'],available_at_utc=match['available_at_utc'],side=side,team_id=match['team'+side+'_id'],
            team_name=match['team'+side],maker_team_id=team['id'],source=source,source_class='official_club_public_JSON_API',source_provider='Elche CF / LaLiga Maker, publishing dated match statistics')
        team_item=body['stats'].get(key+'Stats') or {};raw_team=team_item.get('stats') or {}
        assert raw_team,'No supplied team statistics'
        teams.append(shared|{k:raw_team.get(v) for k,v in FIELDS.items()}|dict(raw_stats=raw_team,source_pointer='/stats/'+key+'Stats/stats'))
        for li,r in enumerate(lineup):
            person=r['player'];pid=person['id']
            base=shared|dict(maker_player_id=pid,master_player_id=person.get('playerMaster'),player_name=person['name'],
                player_slug=person.get('slug'),opta_player_id=opta_id(person),lineup_pointer='/lineups/'+key+'/'+str(li))
            if r.get('manager'):
                managers.append(base);continue
            si,item=stat_map.get(pid,(None,{}));raw=item.get('stats') or {}
            played=bool(r['starting'] or pid in entered)
            if raw.get('minsPlayed',0)>0 or raw.get('totalSubOn',0)>0:
                if not played:issues.append(dict(side=side,maker_player_id=pid,reason='Explicit reported minutes/substitution prove participation; official event feed omits entry'))
                played=True
            if raw.get('gameStarted') is not None:assert bool(raw['gameStarted'])==bool(r['starting'])
            if played and raw.get('minsPlayed') is None:issues.append(dict(side=side,maker_player_id=pid,reason='Participant has no reported minutes'))
            if raw.get('minsPlayed') is not None:assert 0<=raw['minsPlayed']<=110
            row=base|dict(started=bool(r['starting']),played=played,shirt_number=r.get('shirtNumber'),formation_place=r.get('formationPlace'),
                **{k:raw.get(v) for k,v in FIELDS.items()},raw_stats=raw,
                source_pointer='/stats/'+key+'PlayersStats/'+str(si)+'/stats' if si is not None else None)
            players.append(row)
    assert players and teams
    return dict(game_id=match['game_id'],date=match['date'],match=match,source=source,players=players,teams=teams,managers=managers,issues=issues)


def collect(limit=3,workers=3,keepers=False,year=None):
    idx=json.loads((ROOT_OUT/'laliga_maker_index.json').read_bytes())
    if keepers:
        with read_db(ROOT_OUT/'granular.sqlite') as db:
            covered=pd.read_sql_query("SELECT game_id,side FROM soccer_goalkeeper_game_observations WHERE league='La Liga'",db)
        sides=covered.groupby('game_id').side.nunique()
        pending={r['game_id'] for r in idx['matched'] if sides.get(r['game_id'],0)<2}
    else:pending={r['game_id'] for r in json.loads((ROOT_OUT/'laliga_combined_coverage.json').read_bytes())['pending']}
    matches=[r for r in idx['matched'] if r['game_id'] in pending]
    if year:matches=[r for r in matches if r['date'].startswith(str(year))]
    matches.sort(key=lambda r:(r['date'],r['game_id']))
    if limit:matches=[matches[i] for i in sorted(set(round(i*(len(matches)-1)/max(1,limit-1)) for i in range(min(limit,len(matches)))))]
    db=connect();done={r[0] for r in db.execute('SELECT game_id FROM fixtures')};tasks=[m for m in matches if m['game_id'] not in done]
    client=OfficialClient(2);counts=collections.Counter();mark=10
    def fetch(m):
        source=None
        try:
            body,source=client.get(endpoint('live/layout/football_match',slug=m['slug']),'Historical dated La Liga lineup and player/team statistics: '+m['game_id'],'official_club_match_statistics')
            assert body is not None,source['return_status']
            return m,parse(body,m,source),None
        except (AssertionError,ValueError,KeyError,TypeError) as exc:return m,None,dict(reason=type(exc).__name__+': '+str(exc),source=source)
    print(json.dumps(dict(stage='laliga_maker_collection',total=len(tasks),index_matched=len(idx['matched']),scope='keeper recovery' if keepers else 'original missing player reports',year=year)),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        for n,(m,row,error) in enumerate(pool.map(fetch,tasks),1):
            with db:
                if row:
                    db.execute('INSERT OR REPLACE INTO fixtures VALUES (?,?)',(m['game_id'],json.dumps(row)));db.execute('DELETE FROM issues WHERE game_id=?',(m['game_id'],));counts['games']+=1;counts['players']+=len(row['players']);counts['field_issues']+=len(row['issues'])
                else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?)',(m['game_id'],json.dumps(error)));counts['acquisition_or_schema_issues']+=1
            if n*100>=mark*len(tasks) or n==len(tasks):
                progress=dict(at_utc=stamp(),processed=n,total=len(tasks),percent=round(n*100/len(tasks),1),counts=dict(counts),year=year,scope='keeper recovery' if keepers else 'original missing player reports')
                dump(ROOT_OUT/'laliga_maker_progress.json',progress);print(json.dumps(progress),flush=True);mark+=10
    db.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--discover',action='store_true');parser.add_argument('--all',action='store_true');parser.add_argument('--limit',type=int,default=3);parser.add_argument('--keepers',action='store_true');parser.add_argument('--year',type=int)
    args=parser.parse_args()
    if args.discover:discover()
    else:collect(0 if args.all else args.limit,keepers=args.keepers,year=args.year)
