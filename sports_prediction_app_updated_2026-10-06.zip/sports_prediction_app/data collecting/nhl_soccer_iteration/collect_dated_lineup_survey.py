"""Fixed-calendar official lineup survey, independent of prices and results.

The game API has actual participants but no publication-dated projected lines,
scratches or injuries. Official article HTML is used only for those fields.
"""
import hashlib, html, json, re
from html.parser import HTMLParser
import pandas as pd
from common import ROOT_OUT, OfficialClient, dump, stamp
from collect_nhl_opening_rosters import StructuredArticle, namekey
from nhl_roster_aliases import read_source

RUN=ROOT_OUT/'dated_lineup_survey_v71'
PREFIX='https://www.nhl.com/news/'
DISCOVERED={'NHL_20250405_PHI_MTL':PREFIX+'philadephia-flyers-montreal-canadiens-game-preview-april-5'}
STATUS_WORDS='Scratched|Injured|Injuries|Injures|Suspended|Unavailable|(?:NHL )?COVID(?:\\s*-*\\s*19)?\\s+protocol(?:s| list)?|Taxi squad'


class Blocks(HTMLParser):
    def __init__(self):
        super().__init__(); self.blocks=[]; self.tag=None; self.parts=[]
    def handle_starttag(self, tag, attrs):
        if tag in {'p','h1','h2','h3','h4','h5','h6'}:
            self.tag=tag;self.parts=[]
        elif tag=='br' and self.tag:self.parts.append('\n')
    def handle_endtag(self, tag):
        if tag==self.tag:
            self.blocks.append((tag,''.join(self.parts).strip()));self.tag=None;self.parts=[]
    def handle_data(self, data):
        if self.tag:self.parts.append(data)


def parse(blob,game):
    text=blob.decode('utf8');p=StructuredArticle();p.feed(text)
    articles=[x for x in p.items if isinstance(x,dict) and x.get('@type')=='NewsArticle']
    if len(articles)!=1:return None,'not_one_article'
    a=articles[0]
    tags=re.findall(r'"content_tags"\s*:\s*"([^"]*)"',text)
    tagids={x for group in tags for x in re.findall(r'gameid-(\d+)',group)}
    game_pointer='content_tags/gameid-'+str(game['official_game_id'])
    if tagids!={str(game['official_game_id'])}:
        if tagids or not game.get('_allow_unique_schedule_match',False):return None,'native_game_tag_mismatch'
        canonical=re.findall(r'<link\s+rel="canonical"\s+href="([^"]+)"',text)
        d=pd.Timestamp(game['date']);slug=lambda x:re.sub('[^a-z0-9]+','-',x.lower()).strip('-')
        expected=PREFIX+slug(game['teamA'])+'-'+slug(game['teamB'])
        datepart='-'+d.strftime('%B').lower()+'-'+str(d.day)
        if len(canonical)!=1 or not canonical[0].startswith(expected) or not re.search(re.escape(datepart)+r'(?:-\d{4})?$',canonical[0]):return None,'tagless_canonical_date_or_team_mismatch'
        local_date=pd.Timestamp(a['datePublished']).tz_convert('America/New_York').date()
        if not (d-pd.Timedelta(days=1)).date()<=local_date<=d.date():return None,'tagless_publication_date_mismatch'
        game_pointer='canonical_url_date+both_lineup_headings;unique_official_schedule_pair'
    published=pd.Timestamp(a['datePublished']);modified=pd.Timestamp(a.get('dateModified',a['datePublished']));available=max(published,modified)
    start=pd.Timestamp(game['start_time']);cutoff=pd.Timestamp(game['prediction_time'])
    # Source publication validates URL identity; current revisions are not
    # backdated to their earlier initial publication.
    if not start-pd.Timedelta(days=3)<=published<=start:return None,'article_date_mismatch'
    blocks=Blocks();blocks.feed(text)
    lines=[]
    for _,b in blocks.blocks:
        # A wrapped injury explanation is still one status paragraph.
        if re.match(r'^\*?('+STATUS_WORDS+r'):',b,re.I):
            segments=re.split(r'\s*Status report\s*',b,flags=re.I)
            normalized=' '.join(segments[0].split())
            lines.extend(x.strip() for x in re.split(r'(?<!\*)(?=\*?(?:'+STATUS_WORDS+r'):)',normalized,flags=re.I) if x.strip())
            if len(segments)>1:lines.append('Status report')
        else:lines.extend(s.strip() for s in b.splitlines() if s.strip())
    # Legacy pages can put both teams in one multiline paragraph. Split
    # adjacent status labels within each resulting line too, not just at
    # the beginning of an HTML block (e.g. "MaattaInjured: Andersson").
    expanded=[]
    for line in lines:
        if re.match(r'^\*?('+STATUS_WORDS+r'):',line,re.I):
            expanded.extend(x.strip() for x in re.split(r'(?<!\*)(?=\*?(?:'+STATUS_WORDS+r'):)',line,flags=re.I) if x.strip())
        else:expanded.append(line)
    lines=expanded
    markers=[]
    for i,s in enumerate(lines):
        m=re.fullmatch(r'(.+?) (?:projected|expected) (?:lineup|lines)',s,re.I)
        if m:
            name=namekey(m.group(1));sides=[side for side in ['A','B'] if namekey(game['team'+side]).endswith(name) or (game['team'+side]=='Utah Hockey Club' and name=='utah')]
            if len(sides)==1:markers.append((i,sides[0]))
    if len(markers)!=2 or {s for _,s in markers}!={'A','B'}:return None,'lineup_team_heading_mismatch'
    players=[];groups=[];issues=[]
    for m,(idx,side) in enumerate(markers):
        end=markers[m+1][0] if m+1<len(markers) else len(lines)
        ordinal=0
        for line in lines[idx+1:end]:
            if line.lower().startswith('status report') or line=='Latest News':break
            category='projected';body=line
            label=re.match(r'^\*?('+STATUS_WORDS+r'):\s*(.*)',line,re.I)
            if label:
                category=label.group(1).lower();category='injured' if category in ['injuries','injures'] else category
                if 'covid' in category and 'protocol' in category:category='covid_protocol'
                elif category=='taxi squad':category='taxi_squad'
                body=label.group(2).lstrip(': ')
            ordinal+=1
            groups.append(dict(side=side,source_group_number=ordinal,report_status=category,source_group_text=line))
            if body.strip().lower() in {'none','none.'}:continue
            # Strip parenthesized injury descriptions for name splitting;
            # original complete status group is retained separately.
            pieces=re.split(r'\s*-{2,}\s*|\s+[\u2013\u2014-]\s+|/',body) if category=='projected' else re.split(r'[,;]\s*(?![^()]*\))|(?<=\))\s+(?=[A-Z])',body)
            for order,piece in enumerate(pieces,1):
                if not piece.strip():continue # empty formatting separator, not an absent named player
                name=re.sub(r'\s*\([^)]*\)','',piece).strip().strip('*')
                if not name and category!='projected':
                    issues.append(dict(side=side,source_group_number=ordinal,source_player_index=order,report_status=category,source_text=piece,issue='Source status description has no player name; preserved separately, not a zero or invented identity'))
                    continue
                # Stop prose escaping the lineup section; never turn it into
                # fake player observations.
                if not name or len(name.split())>5 or any(z in name for z in ['...',';',':']):
                    issues.append(dict(side=side,source_group_number=ordinal,source_player_index=order,report_status=category,source_text=piece,issue='Unparsed source fragment: preserve separately and do not fabricate a player'))
                    continue
                players.append(dict(side=side,source_group_number=ordinal,source_player_index=order,report_status=category,player_name_raw=name,source_group_text=line))
    f=pd.DataFrame(players)
    counts=f[f.report_status.eq('projected')].groupby('side').size()
    for side in ['A','B']:
        if not 18<=counts.get(side,0)<=24:issues.append(dict(side=side,source_group_number=0,source_player_index=0,report_status='projected',source_text=str(int(counts.get(side,0))),issue='Projected participant count outside18-24; preserve reported rows but do not assume a complete team projection'))
    return dict(article_title=a['headline'],official_game_id=str(game['official_game_id']),source_game_pointer=game_pointer,published_at_utc=published.isoformat(),modified_at_utc=modified.isoformat(),available_at_utc=available.isoformat(),
        lead_hours=(start-available).total_seconds()/3600,available_by_pre12=bool(available<=cutoff),players=players,groups=groups,source_issues=issues),'parsed'


def source_games():
    """Use retained source facts, not a disposable model experiment snapshot."""
    from common import PREVIOUS, read_db
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        g=pd.read_sql_query("SELECT * FROM nhl_games WHERE phase IN ('Regular Season','Playoffs')",db)
    for name in ['start_time','prediction_time']:
        g[name]=pd.to_datetime(g[name],utc=True)
    return g


def selection():
    g=source_games()
    g=g[g.date.ge('2024-01-01')&g.date.lt('2026-01-01')].copy()
    g['quarter']=pd.to_datetime(g.date).dt.to_period('Q').astype(str)
    sides=pd.concat([g.assign(team=g['team'+s]) for s in ['A','B']]).sort_values(['start_time','game_id'])
    ids=sides.groupby(['team','quarter'],sort=False).head(1).game_id
    # Deliberately exclude target, scores and odds from acquisition manifest.
    cols=['game_id','official_game_id','date','teamA','teamB','native_team_ids_json','start_time','prediction_time','quarter']
    return g[g.game_id.isin(ids)][cols].sort_values(['start_time','game_id']).reset_index(drop=True)


def urls(game):
    d=pd.Timestamp(game['date']);slug=lambda x: re.sub('[^a-z0-9]+','-',x.lower()).strip('-')
    root=PREFIX+slug(game['teamA'])+'-'+slug(game['teamB'])+'-game-preview-'+d.strftime('%B').lower()+'-'+str(d.day)
    result=[root,root+'-'+str(d.year),root.rsplit('-'+d.strftime('%B').lower()+'-',1)[0]]
    if str(game['official_game_id'])[4:6]=='03':
        playoff=PREFIX+slug(game['teamA'])+'-'+slug(game['teamB'])+'-game-'+str(int(str(game['official_game_id'])[-1]))+'-preview'
        dated=playoff+'-'+d.strftime('%B').lower()+'-'+str(d.day)
        result=[playoff,dated,dated+'-'+str(d.year)]+result
    if game['game_id'] in DISCOVERED:result.insert(0,DISCOVERED[game['game_id']])
    return result


def main():
    RUN.mkdir(exist_ok=True);g=selection();g.to_parquet(RUN/'selected_games.parquet',index=False)
    plan=RUN/'plan.json'
    if not plan.exists():dump(plan,dict(at_utc=stamp(),selection='First scheduled observed game per club and calendar quarter in2024/25; deduplicate games. No outcomes, forecasts or prices in selection.',games=len(g),
        api_insufficiency='Official historical game API exposes actual participants and postgame scratches, but no publication-dated projected lineup/injury report. Use official article HTML only for these omitted pregame fields.',
        robots_source='https://www.nhl.com/robots.txt',cutoff='Maximum official publication/modification timestamp <= start minus12hours. Later reports retained for later-as-of use, never current pre12.',
        no_model_or_strategy_changed=True))
    c=OfficialClient(per_second=2);records=[];players=[];groups=[];last=0
    for idx,row in g.iterrows():
        game=row.to_dict();path=RUN/(game['game_id']+'.json')
        r=None
        if path.exists():
            saved=json.loads(path.read_bytes())
            for attempt in saved['attempts']:
                if attempt['source']['return_status']!='200':continue
                data,reason=parse(read_source(attempt['source']),game)
                if data:
                    r=dict(game_id=game['game_id'],**data,source=attempt['source'],attempts=saved['attempts']);dump(path,r);break
        if r is None:
            attempts=[];r=None
            for url in urls(game):
                blob,source=c.get(url,'Calendar-sampled official projected lines, injuries and scratches; validate date and teams','nhl_dated_lineup',document=True)
                data,reason=parse(blob,game) if blob else (None,'HTTP_'+source['return_status'])
                attempts.append(dict(source=source,parse_status=reason))
                if data:
                    r=dict(game_id=game['game_id'],**data,source=source);break
            if r is None:r=dict(game_id=game['game_id'],players=[],groups=[],parse_status='needs_source_discovery')
            r['attempts']=attempts;dump(path,r)
        summary={k:v for k,v in r.items() if k not in ['players','groups','attempts','source']}
        summary.update({k:game[k] for k in ['date','quarter','teamA','teamB','native_team_ids_json','start_time','prediction_time']})
        summary['source_json']=json.dumps(r.get('source'),sort_keys=True);summary['attempts_json']=json.dumps(r['attempts'],sort_keys=True)
        summary['parse_status']='parsed' if r.get('source') else 'needs_source_discovery'
        records.append(summary)
        for table,key in [(players,'players'),(groups,'groups')]:
            for v in r[key]:table.append(dict(game_id=game['game_id'],**v))
        progress=int((idx+1)*100/len(g))//10*10
        if progress>last:
            last=progress;status=dict(progress_pct=progress,processed=idx+1,total=len(g),articles=sum(x['parse_status']=='parsed' for x in records),player_entries=len(players));dump(RUN/'progress.json',status);print(json.dumps(status),flush=True)
    for name,data in [('reports',records),('players',players),('groups',groups)]:
        f=pd.DataFrame(data);f.to_parquet(RUN/(name+'.parquet'),index=False);f.to_csv(RUN/(name+'.csv'),index=False)
    f=pd.DataFrame(records);p=pd.DataFrame(players)
    report=dict(at_utc=stamp(),selected_games=len(f),parsed_reports=int(f.parse_status.eq('parsed').sum()),needs_discovery=int(f.parse_status.ne('parsed').sum()),
        pre12_eligible_reports=int(f.available_by_pre12.fillna(False).sum()),player_entries=len(p),by_status=p.report_status.value_counts().to_dict())
    dump(RUN/'summary.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
