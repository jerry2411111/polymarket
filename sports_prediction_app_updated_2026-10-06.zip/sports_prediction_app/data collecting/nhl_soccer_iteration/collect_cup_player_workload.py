"""Dated UEFA cup player actions/exposure for games used by workload history."""
import argparse,concurrent.futures,hashlib,json,sqlite3,sys
from pathlib import Path
from urllib.parse import urlencode
import pandas as pd
from common import ROOT_OUT,PROJECT,OfficialClient,read_db,dump,stamp
from collect_uefa_matchstats import fetch_verified,FIELDS
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from uefa_regulation_scores import score
from cup_player_exposure import derive

RUN=ROOT_OUT/'soccer_cup_players_v74';CALENDAR=ROOT_OUT/'soccer_cup_workload_v73'


def with_exposure(g,client):
    gid,record,error,sources=fetch_verified(g,client)
    if record is None:return gid,record,error,sources
    try:
        events=[];es=[];seen=set();root='https://match.uefa.com/v5/matches/'+g['official_game_id']+'/events?'
        for offset in range(0,10000,500):
            d,s=client.get(root+urlencode(dict(filter='ALL',limit=500,offset=offset,order='ASC')),'Official cup substitutions and phase boundaries for earlier player workload '+g['date'],'official_match_events')
            assert isinstance(d,list),'Event response needs recovery'
            ids={str(e['id']) for e in d};assert len(ids)==len(d) and not seen.intersection(ids),'Overlapping event pages'
            seen.update(ids);events.extend(d);es.append(s)
            if len(d)<500:break
        else:raise AssertionError('Unexhausted event pagination')
        s=sources['lineup'];b=(PROJECT/s['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==s['sha256']
        record['workload_exposure']=derive(g,json.loads(b),events,dict(lineup=s,events=es));record['workload_events_sources']=es
        return gid,record,None,sources
    except Exception as exc:
        # Keep valid native action statistics even when exposure needs repair.
        record['workload_exposure_error']=type(exc).__name__+': '+str(exc)
        return gid,record,None,sources


def games():
    f=pd.read_parquet(CALENDAR/'soccer_features.parquet');ids={gid for v in f.cup_extra_games_json for gid in json.loads(v)}
    calendar=pd.read_parquet(CALENDAR/'games.parquet');chosen=calendar[calendar.game_id.isin(ids)].copy();assert chosen.workload_eligible.all()
    # One documented extra-time final is a parser pilot even if no next tracked
    # fixture makes it contribute to the frozen workload window.
    pilot_extra=calendar[calendar.official_game_id.eq('2033450')]
    chosen=pd.concat([chosen,pilot_extra]).drop_duplicates('game_id').sort_values(['date','game_id'])
    sources={};out=[]
    for g in chosen.to_dict('records'):
        s=json.loads(g['source_json']);raw=s['raw_file']
        if raw not in sources:
            b=(PROJECT/raw).read_bytes();assert hashlib.sha256(b).hexdigest()==s['sha256'];sources[raw]=json.loads(b)
        m=sources[raw][int(g['source_pointer'][1:])];assert str(m['id'])==g['official_game_id']
        result=score(m);assert result['scores'] is not None,'Completed regulation result requires reconciliation'
        g['scoreA'],g['scoreB']=result['scores'];g['regulation_score_evidence']=result;g['used_by_workload_model']=g['game_id'] in ids;out.append(g)
    return out


def main(full=False):
    RUN.mkdir(exist_ok=True);assert (RUN/'definitions.json').exists(),'Read current official definitions before collection'
    if full:assert json.loads((RUN/'pilot_validation.json').read_bytes())['status']=='PASS'
    requested=games();pd.DataFrame(requested).drop(columns='regulation_score_evidence').to_parquet(RUN/'requested_games.parquet',index=False)
    if not full:
        chosen={}
        for g in requested:
            if g['date'][:4] in ['2021','2024','2026']:chosen.setdefault((g['league'],g['date'][:4]),g)
            if g['official_game_id']=='2033450':chosen[('extra_time','2022')]=g
        requested=list(chosen.values())
    requested.sort(key=lambda r:(r['date'],r['game_id']))
    dump(RUN/('full_plan.json' if full else 'pilot_plan.json'),dict(at_utc=stamp(),games=[g['game_id'] for g in requested],
        selection='All additional cup fixtures contributing to pre12 historical rest/seven-day-count windows, fixed before results/model test; pilot first percompetition/year2021/24/26 plus documented2022extra-timefinal.',
        meaning='Dated actual earlier player workload including stoppage/extra time, not current-game starters. Exact official native player IDs only; later current-club biographies are not historical roster evidence.'))
    db=sqlite3.connect(RUN/'match_statistics.sqlite',timeout=60)
    db.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT);CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,checked_utc TEXT,reason TEXT,sources TEXT);')
    done={r[0] for r in db.execute("SELECT game_id FROM games WHERE json_extract(body,'$.workload_exposure.version')>=1")};tasks=[g for g in requested if g['game_id'] not in done];initial=len(requested)-len(tasks);mark=(initial*100//len(requested)//10+1)*10
    client=OfficialClient(per_second=2);counts=dict(games=0,players=0,known_elapsed_seconds=0,issues=0)
    print(json.dumps(dict(stage='cup_player_workload',pilot=not full,tasks=len(tasks),retained=initial)),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for n,(gid,record,error,sources) in enumerate(pool.map(lambda g:with_exposure(g,client),tasks),1):
            with db:
                if record:
                    db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(gid,json.dumps(record,allow_nan=False)));db.execute('DELETE FROM issues WHERE game_id=?',(gid,))
                    counts['games']+=1;counts['players']+=len(record['players']);counts['known_elapsed_seconds']+=sum(r['played_seconds_including_stoppage'] is not None for r in record['players'])
                else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?,?,?)',(gid,stamp(),error,json.dumps(sources)));counts['issues']+=1
            while (n+initial)*100>=mark*len(requested):
                p=dict(at_utc=stamp(),stage='cup_player_workload',pilot=not full,processed=n+initial,total=len(requested),percent=mark,counts=counts.copy())
                dump(RUN/'collection_progress.json',p);print(json.dumps(p),flush=True);mark+=10
    records=[json.loads(b) for b, in db.execute('SELECT body FROM games')];issues=[dict(game_id=g,reason=r) for g,r in db.execute('SELECT game_id,reason FROM issues')];db.close()
    for actor in ['players','teams']:
        rows=[r for g in records for r in g[actor]]
        if rows:pd.DataFrame(rows).to_parquet(RUN/('cup_match_'+actor+'.parquet'),index=False)
    exposures=[r for g in records for r in g.get('workload_exposure',{}).get('players',[])]
    if exposures:pd.DataFrame(exposures).to_parquet(RUN/'cup_player_exposure.parquet',index=False)
    summary=dict(at_utc=stamp(),pilot=not full,requested=len(requested),retained_games=len(records),issues=issues,
        known_player_seconds=sum(r['played_seconds_including_stoppage'] is not None for g in records for r in g['players']),
        exposure_rows=len(exposures),known_regulation_extra_minutes=sum(r['minutes_regulation_extra'] is not None for r in exposures),
        exposure_issues=[dict(game_id=g['game_validation']['game_id'],issues=g.get('workload_exposure',{}).get('issues',[]),error=g.get('workload_exposure_error')) for g in records if g.get('workload_exposure_error') or g.get('workload_exposure',{}).get('issues')])
    dump(RUN/('collection_full_summary.json' if full else 'collection_pilot_summary.json'),summary);print(json.dumps(summary),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--full',action='store_true');a=p.parse_args();main(a.full)
