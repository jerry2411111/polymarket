"""Expand official national-team player actions using validated UEFA schemas."""
import argparse,concurrent.futures,hashlib,json,sqlite3
import pandas as pd
from common import ROOT_OUT,PROJECT,OfficialClient,read_db,dump,stamp
from collect_uefa_matchstats import fetch_verified,FIELDS,PARSER_VERSION

RUN=ROOT_OUT/'nations_actions_v41'


def main(full=False):
 RUN.mkdir(exist_ok=True)
 if full:assert json.loads((RUN/'pilot_validation.json').read_bytes())['status']=='PASS'
 with read_db(ROOT_OUT/'nations_league.sqlite') as c:games=[json.loads(b) for b, in c.execute('SELECT body FROM calendar')]
 games=sorted([g for g in games if '2021-01-01'<=g['date']<='2026-09-30' and g['scoreA'] is not None and g['scoreB'] is not None],key=lambda g:(g['date'],g['game_id']))
 if not full:games=[next(g for g in games if g['date'].startswith(y)) for y in ['2021','2024','2026']]
 client=OfficialClient(2)
 definitions,source=client.get('https://compstats.uefa.com/v2/definitions','Read current official UEFA statistic definitions before Nations League expansion','official_api_definitions',refresh=not full)
 assert isinstance(definitions,list)
 dump(RUN/'definitions.json',dict(source=source,fields=[r for r in definitions if r['name'] in FIELDS]))
 db=sqlite3.connect(RUN/'match_statistics.sqlite',timeout=60)
 db.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT);CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,checked_utc TEXT,reason TEXT,sources TEXT);')
 done={r[0] for r in db.execute("SELECT game_id FROM games WHERE json_extract(body,'$.parser_version')=?",(PARSER_VERSION,))};tasks=[g for g in games if g['game_id'] not in done]
 initial=len(games)-len(tasks);mark=(initial*100//len(games)//10+1)*10;counts=dict(games=0,players=0,issues=0)
 print(json.dumps(dict(stage='nations_matchstats',pilot=not full,tasks=len(tasks),retained=initial)),flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  for n,(gid,record,error,sources) in enumerate(pool.map(lambda g:fetch_verified(g,client),tasks),1):
   with db:
    if record:
     db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(gid,json.dumps(record,allow_nan=False)));db.execute('DELETE FROM issues WHERE game_id=?',(gid,));counts['games']+=1;counts['players']+=len(record['players'])
    else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?,?,?)',(gid,stamp(),error,json.dumps(sources)));counts['issues']+=1
   if (n+initial)*100>=mark*len(games) or n==len(tasks):
    progress=dict(at_utc=stamp(),stage='nations_matchstats',pilot=not full,processed=n+initial,total=len(games),percent=round((n+initial)*100/len(games),1),counts=counts)
    dump(RUN/'collection_progress.json',progress);print(json.dumps(progress),flush=True);mark+=10
 records=[json.loads(b) for b, in db.execute('SELECT body FROM games')];issues=[dict(game_id=g,reason=r) for g,r in db.execute('SELECT game_id,reason FROM issues')]
 for actor in ['players','teams']:
  f=pd.DataFrame([r for g in records for r in g[actor]])
  if not f.empty:f.to_parquet(RUN/('nations_match_'+actor+'.parquet'),index=False)
 dump(RUN/'collection_summary.json',dict(at_utc=stamp(),pilot=not full,games=len(records),target_games=len(games),issues=issues,fields=FIELDS))
 print(json.dumps(dict(games=len(records),issues=issues)),flush=True);db.close()


if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--full',action='store_true');args=p.parse_args();main(args.full)
