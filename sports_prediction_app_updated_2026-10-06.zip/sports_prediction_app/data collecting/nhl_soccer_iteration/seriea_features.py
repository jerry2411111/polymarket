"""Use earlier observed Serie A players, never the future game's lineup."""
import collections,json
import numpy as np
import pandas as pd
from common import OUT,ROOT_OUT,PREVIOUS,PROJECT,read_db,dump,stamp
from features import LEAGUE_CODE

def main():
    with read_db(ROOT_OUT/'seriea_players.sqlite') as c:players=[r for b, in c.execute("SELECT body FROM games WHERE json_extract(body,'$[0].parser_version')=4") for r in json.loads(b)]
    with read_db(PREVIOUS/'expanded.sqlite') as c:games=pd.read_sql_query("SELECT * FROM soccer_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30'",c)
    registry={}
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as c:
        for code,native,body in c.execute('SELECT * FROM _eu_team_identity'):registry[(code,str(native))]=json.loads(body)['team_id']
    keys={}
    for r in games.itertuples():
        for side,tid in zip(['A','B'],json.loads(r.native_team_ids_json)):keys[(r.game_id,side)]=registry.get((LEAGUE_CODE[r.league],str(tid)),r.league+':'+str(tid))
    events=collections.defaultdict(list)
    for r in players:
        if r['minutes'] is not None and r['minutes']>0:
            r['available_time']=pd.Timestamp(r['available_at_utc']);r['team_key']=keys[(r['game_id'],r['side'])]
            events[(r['game_id'],r['side'])].append(r)
    queue=sorted(events.values(),key=lambda rs:rs[0]['available_time']);pos=0;team_history=collections.defaultdict(lambda:collections.deque(maxlen=30));player_history=collections.defaultdict(lambda:collections.deque(maxlen=30));lastteam={};rows=[]
    fields=['recorded_goals','recorded_assists','recorded_shots','recorded_yellow_cards','recorded_red_cards']
    games.prediction_time=pd.to_datetime(games.prediction_time,utc=True,format='mixed')
    for g in games.sort_values(['prediction_time','game_id']).to_dict('records'):
        cut=g['prediction_time']
        while pos<len(queue) and queue[pos][0]['available_time']<cut:
            rs=queue[pos];pos+=1;team=rs[0]['team_key'];team_history[team].append(rs)
            for r in rs:player_history[r['official_player_id']].append(r);lastteam[r['official_player_id']]=team
        sides=[];sources=[]
        for side in ['A','B']:
            team=keys[(g['game_id'],side)];history=list(team_history[team]);weights=collections.defaultdict(float);f={}
            for rs in history[-5:]:
                for r in rs:
                    if lastteam[r['official_player_id']]==team:weights[r['official_player_id']]+=r['minutes']
            f['observed_players']=len(weights)
            for field in fields:
                for window in [5,30]:
                    pairs=[]
                    for pid,w in weights.items():
                        old=list(player_history[pid])[-window:];sources.extend(r['available_time'] for r in old)
                        if field=='recorded_goals':old=[r for r in old if r['goal_counts_reconcile']]
                        if old:pairs.append((w,90*sum(r[field] for r in old)/sum(r['minutes'] for r in old)))
                    f['roster_'+field+'_per90_'+str(window)]=sum(w*v for w,v in pairs)/sum(w for w,v in pairs) if pairs else np.nan
            known=[r['minutes'] for rs in history[-5:] for r in rs]
            f['observed_minutes_mean']=np.mean(known) if known else np.nan
            f['observed_minutes_std']=np.std(known,ddof=1) if len(known)>1 else np.nan
            sides.append(f)
        row=dict(game_id=g['game_id'],seriea_source_max_available_utc=max(sources) if sources else None)
        assert not sources or max(sources)<cut
        for field in sides[0]:
            row['f_seriea_'+field+'_diff']=sides[1][field]-sides[0][field]
            row['f_seriea_'+field+'_sum']=sides[1][field]+sides[0][field]
        rows.append(row)
    base=pd.read_parquet(OUT/'soccer_features.parquet');extra=pd.DataFrame(rows)
    result=base.merge(extra,on='game_id',validate='one_to_one');result.to_parquet(OUT/'soccer_features.parquet',index=False)
    dump(OUT/'seriea_feature_audit.json',dict(created_utc=stamp(),games=len(result),source_player_rows=len(players),source_games=len(events)//2,added_features=len([x for x in extra if x.startswith('f_')]),future_input_violations=0,policy='Prior dated rosters and recorded events; conservative extra 24h release delay; no future lineup; source goals used only when feed reconciles with official game score.',missing_pct={x:100*result[x].isna().mean() for x in extra if x.startswith('f_')}))
    print(json.dumps(dict(games=len(result),features=len([x for x in result if x.startswith('f_')]),source_player_rows=len(players))),flush=True)

if __name__=='__main__':main()
