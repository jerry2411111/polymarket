"""Test recovered dated goalkeeper history with fixed rolling/trading settings.

No current-game starter is used. The previous five collected team games weight
observed keepers; the last twenty eligible appearances supply rates shrunk by
900 minutes toward the earlier competition mean. These are descriptive keeper
and defence statistics, not shot-difficulty-adjusted keeper ability.
"""
import argparse
import collections
import json

import numpy as np
import pandas as pd

from common import PROJECT, PREVIOUS, ROOT_OUT, read_db, dump, stamp, file_sha256
from features import LEAGUE_CODE

LABEL = 'recovered_keeper_history'
FIELDS = ['saves', 'goals_conceded']
QUALITY = False


def inputs():
    path = ROOT_OUT/'soccer_goalkeeper_game_observations.parquet'
    check = json.loads((ROOT_OUT/'soccer_keeper_v81/keeper_validation.json').read_bytes())
    assert check['status'] == 'PASS' and check['source_sha256'] == file_sha256(path)
    obs = pd.read_parquet(path)
    obs['available_at_utc'] = pd.to_datetime(obs.available_at_utc, utc=True, format='mixed')
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games = pd.read_sql_query('SELECT * FROM soccer_games', db)
    games = games[games.date.between('2021-01-01', '2026-09-30')].copy()
    games['available_time'] = pd.to_datetime(games.available_time, utc=True, format='mixed')
    registry = {}
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
        for code, native, body in db.execute('SELECT * FROM _eu_team_identity'):
            registry[code, str(native)] = json.loads(body)['team_id']
    keys = {}
    for game in games.itertuples():
        for side, native in zip(['A', 'B'], json.loads(game.native_team_ids_json)):
            keys[game.game_id, side] = registry.get((LEAGUE_CODE[game.league], str(native)), game.league+':'+str(native))
    obs = obs[obs.game_id.isin(games.game_id)].copy()
    obs['team_key'] = [keys[g, s] for g, s in zip(obs.game_id, obs.side)]
    # Keep native namespaces separate unless an explicit identity mapping exists.
    obs['player_key'] = obs.id_namespace.astype(str)+':'+obs.official_player_id.astype(str)
    assert not obs.duplicated(['game_id', 'side', 'player_key']).any()
    if QUALITY:
        path=ROOT_OUT/'soccer_goalkeeper_shot_difficulty.parquet'
        proof=json.loads((ROOT_OUT/'soccer_keeper_v81/shot_difficulty_validation.json').read_bytes())
        assert proof['status']=='PASS' and proof['output_sha256']==file_sha256(path)
        assert proof['source_sha256']==check['source_sha256']
        quality=pd.read_parquet(path)
        shared=['game_id','side','official_player_id','id_namespace']
        obs=obs.merge(quality[shared+['goals_prevented']],on=shared,how='left',validate='one_to_one')
        check=dict(check,shot_difficulty=proof)
    return games, obs, keys, check


def derive(forecasts, games, obs, keys):
    events = list(obs.sort_values(['available_at_utc', 'game_id', 'side', 'player_key']).to_dict('records'))
    matches = list(games.sort_values(['available_time', 'game_id']).to_dict('records'))
    team_games = collections.defaultdict(lambda: collections.deque(maxlen=5))
    match_keepers = collections.defaultdict(list)
    player_history = collections.defaultdict(list)
    last_team = {}; last_appearance = {}
    league_totals = collections.defaultdict(lambda: [0., 0.])
    league_cutoff = {}
    i = j = 0; rows = []
    for game in forecasts.sort_values(['prediction_time', 'game_id']).itertuples():
        cut = game.prediction_time
        while j < len(matches) and matches[j]['available_time'] < cut:
            event = matches[j]; j += 1
            for side in ['A', 'B']:
                team_games[keys[event['game_id'], side]].append((event['game_id'], side, event['available_time']))
        while i < len(events) and events[i]['available_at_utc'] < cut:
            event = events[i]; i += 1
            player_history[event['player_key']].append(event)
            match_keepers[event['game_id'], event['side']].append(event)
            appearance = (event['date'], event['game_id'])
            if event['player_key'] not in last_appearance or appearance >= last_appearance[event['player_key']]:
                last_appearance[event['player_key']] = appearance
                last_team[event['player_key']] = event['team_key']
            for field in FIELDS:
                if pd.notna(event[field]):
                    pair = league_totals[event['league'], field]
                    pair[0] += event[field]; pair[1] += event['minutes']
                    league_cutoff[event['league'], field] = event['available_at_utc']
        sides = {}; latest = []; evidence = {}
        for side in ['A', 'B']:
            team = keys[game.game_id, side]; history = list(team_games[team])
            weights = collections.defaultdict(float)
            for gid, past_side, at in history:
                latest.append(at)
                people = [p for p in match_keepers[gid, past_side] if last_team[p['player_key']] == team]
                # Per-match weights sum to one; extra time never overweights a game.
                exposure = sum(p['minutes'] for p in people)
                for p in people:
                    weights[p['player_key']] += p['minutes']/exposure
                    latest.append(p['available_at_utc'])
            values = {}; used = {}; observed_weights = {}
            for field in FIELDS:
                prior_total, prior_minutes = league_totals[game.league, field]
                prior = 90*prior_total/prior_minutes if prior_minutes else np.nan
                if prior_minutes:
                    latest.append(league_cutoff[game.league, field])
                rates = []
                for pid, weight in weights.items():
                    # Late corrections become eligible only after their release;
                    # recency itself follows the match date, not retrieval order.
                    appearances = sorted(player_history[pid], key=lambda p: (p['date'], p['game_id']))[-20:]
                    observed = [p for p in appearances if pd.notna(p[field])]
                    if not observed:
                        continue
                    minutes = sum(p['minutes'] for p in observed)
                    total = sum(p[field] for p in observed)
                    rate = (90*total+900*prior)/(minutes+900) if np.isfinite(prior) else 90*total/minutes
                    rates.append((weight, rate))
                    latest.extend(p['available_at_utc'] for p in observed)
                    used[pid] = [p['game_id'] for p in appearances]
                values[field] = sum(w*r for w, r in rates)/sum(w for w, _ in rates) if rates else np.nan
                observed_weights[field]=sum(w for w,_ in rates)
            numerator=observed_weights['goals_prevented'] if QUALITY else sum(weights.values())
            values['coverage'] = numerator/len(history) if history else 0.
            assert 0 <= values['coverage'] <= 1+1e-12
            sides[side] = values
            evidence[side] = dict(team_key=team, past_team_games=[gid for gid, _, _ in history],
                keeper_weights=dict(weights), keeper_history=used, rates=values)
        row = dict(game_id=game.game_id, keeper_source_max_utc=max(latest) if latest else pd.NaT)
        assert not latest or max(latest) < cut
        for field in FIELDS+['coverage']:
            row['f_ctx_keeper_'+field+'_diff'] = sides['B'][field]-sides['A'][field]
            row['f_ctx_keeper_'+field+'_sum'] = sides['B'][field]+sides['A'][field]
        # JSON audit uses explicit null for unobserved rates.
        for side in evidence:
            evidence[side]['rates'] = {k: v if np.isfinite(v) else None for k, v in evidence[side]['rates'].items()}
        row['keeper_history_json'] = json.dumps(evidence, sort_keys=True, allow_nan=False)
        rows.append(row)
    frame = pd.DataFrame(rows).set_index('game_id')
    frame['keeper_source_max_utc'] = pd.to_datetime(frame.keeper_source_max_utc, utc=True).dt.as_unit('ns')
    for column in frame:
        if column.startswith('f_'):
            frame[column] = frame[column].astype(float)
    return frame


def build():
    work = ROOT_OUT/'_work'/LABEL; work.mkdir(parents=True, exist_ok=True)
    games, obs, keys, check = inputs()
    baseline = pd.read_parquet(ROOT_OUT/'retained_models/soccer/soccer_features.parquet')
    facts = derive(baseline, games, obs, keys)
    cut = pd.Timestamp('2025-01-01', tz='UTC')
    prefix = baseline[baseline.prediction_time.lt(cut)]
    replay = derive(prefix, games[games.available_time.lt(cut)], obs[obs.available_at_utc.lt(cut)], keys)
    pd.testing.assert_frame_equal(replay, facts.loc[replay.index], check_exact=True)
    # Independent direct filtering replays complete history for 12 cutoffs,
    # detecting state/update-order mistakes as well as future data dependence.
    picked = baseline.sort_values(['prediction_time', 'game_id']).iloc[np.linspace(0, len(baseline)-1, 12, dtype=int)]
    for row in picked.itertuples():
        one = baseline[baseline.game_id.eq(row.game_id)]
        actual = derive(one, games[games.available_time.lt(row.prediction_time)], obs[obs.available_at_utc.lt(row.prediction_time)], keys)
        pd.testing.assert_frame_equal(actual, facts.loc[actual.index], check_exact=True)
    candidate = baseline.merge(facts, left_on='game_id', right_index=True, validate='one_to_one')
    pd.testing.assert_frame_equal(candidate[baseline.columns], baseline, check_exact=True)
    feature = work/'soccer_features.parquet'; candidate.to_parquet(feature, index=False)
    fields = [c for c in facts if c.startswith('f_')]
    coverage = []
    for (league, year), group in candidate.groupby(['league', candidate.prediction_time.dt.year]):
        coverage.append(dict(league=league, year=int(year), games=len(group),
            both_teams_observed=int(group[fields].notna().all(axis=1).sum()),
            missing_rate_pct=100*group[fields].isna().mean().mean()))
    pd.DataFrame(coverage).to_csv(work/'keeper_feature_coverage.csv', index=False)
    report = dict(status='PASS', at_utc=stamp(), rows=len(candidate), added_model_inputs=len(fields),
        fields=fields, native_keeper_rows=len(obs), source_validation=check['source_sha256'],
        prefix_invariant_rows=len(prefix), direct_cutoff_replays=len(picked),
        current_game_lineup_used=False, other_columns_unchanged=True,
        feature_sha256=file_sha256(feature),
        definition='Prior5collectedteamgames; prior20keeperappearances;900minute earliercompetition shrinkage; observed current-team weights; native namespaces; raw missing fields stay null.')
    if QUALITY:
        report.update(shot_difficulty_validation=check['shot_difficulty'],
            definition='Prior5teamgames keeper pool; last20eligible appearances; own-goal-adjusted xGOT residual per90minutes shrunk with900priorcompetitionminutes; quality-observation coverage; no current actual lineup.')
    dump(work/'feature_validation.json', report)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--test', action='store_true')
    parser.add_argument('--label',default=LABEL); parser.add_argument('--shot-difficulty',action='store_true')
    parser.add_argument('--preserve-rare-units',action='store_true'); args = parser.parse_args()
    LABEL=args.label
    QUALITY=args.shot_difficulty
    if QUALITY:FIELDS=['goals_prevented']
    assert LABEL.replace('_','').isalnum()
    assert not (ROOT_OUT/'simulation_results/feature_revisions'/LABEL).exists(), 'Preserve completed experiment results; specify a new revision label'
    build()
    if args.test:
        if args.preserve_rare_units:
            import models
            spec=dict(models.CANDIDATES['context_league'])
            spec['preserve_unit_columns']=['f_ctx_keeper_'+field+'_'+op for field in FIELDS+['coverage'] for op in ['diff','sum']]
            models.CANDIDATES['context_league']=spec
        from compare_feature_revision import main
        hypothesis=('Earlier own-goal-adjusted keeper goals prevented controls for measured shot difficulty and improves probabilities beyond team form; only verified measured scope is used.' if QUALITY else
            'Expanded same-game verified La Liga keeper coverage and earlier keeper history improve probabilities, with unchanged baseline and buying rules.')
        if args.preserve_rare_units:
            hypothesis+=' Do not rescale imputed keeper columns by prevalence: preserve their earlier observed competition units and unscaled missing indicators; all baseline columns retain original transformations.'
        main(LABEL,hypothesis)
    from final_pipeline import cleanup
    cleanup()
