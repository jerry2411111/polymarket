"""Merge verified native player facts and derive past-only soccer inputs.

New identities use exact league/native-ID crosswalks; names never join records.
Physical team measurements keep their source units. Fresh sparse statistics do
not erase a known older normalized field from the same completed match.
"""
import collections,hashlib,json
import numpy as np
import pandas as pd
from common import file_sha256,ROOT_OUT,OUT,read_db,dump,stamp
from features import sources,build,LEAGUE_CODE

PLAYER_ACTIONS=['shots','passes_completed','key_passes','interceptions','recoveries',
                'tackles_won','aerials_won','clearances','saves','touches_opponent_box',
                'final_third_passes_completed','duels_won','duels_lost','crosses_completed']
TEAM_PHYSICAL=['distance_covered_km','sprints','pass_accuracy_pct','possession_pct']


def enriched_sources(include_exposure=False):
    games,obs,players,keys,stats,metrics,identity=sources('soccer')
    path=ROOT_OUT/'soccer_additional.sqlite'
    with read_db(path) as c:records=[json.loads(r[0]) for r in c.execute('SELECT body FROM games')]
    old_cross=players[['league','official_player_id','player_id']].drop_duplicates()
    old_cross['official_player_id']=old_cross.official_player_id.astype(str)
    counts=old_cross.groupby(['league','official_player_id']).player_id.nunique()
    assert counts.max()==1,'Conflicting canonical player identity requires repair'
    cross=old_cross.set_index(['league','official_player_id']).player_id.to_dict()
    rows=[];teamrows=[];audit=collections.Counter();provenance=[]
    columns=['game_id','official_game_id','league','date','available_at_utc','side','team_id',
             'official_player_id','player_name','position','started','played','minutes',
             'minutes_basis','goals','assists','xg','xa','shots_on_target']+PLAYER_ACTIONS
    if include_exposure:columns+=['distance_covered_km','challenges_won','shots_at_goal']
    for g in records:
        for r in g['players']:
            row={k:r.get(k) for k in columns};native=str(r['official_player_id'])
            row['official_player_id']=native;key=(g['league'],native)
            row['player_id']=cross.get(key,'EU_'+LEAGUE_CODE[g['league']]+':'+native)
            audit['exact_native_crosswalk' if key in cross else 'source_namespaced_identity']+=1
            row['player_type']='goalkeeper' if str(r.get('position')).upper() in ['1','GOALKEEPER','G'] else None
            rows.append(row)
            provenance.append(dict(game_id=r['game_id'],player_id=row['player_id'],official_player_id=native,
                                   source_url=r['source']['url'],source_sha256=r['source']['sha256']))
        for r in g['teams']:
            teamrows.append({k:r[k] for k in ['game_id','side']+TEAM_PHYSICAL if k in r})
    new=pd.DataFrame(rows);index=['game_id','side','official_player_id']
    players.official_player_id=players.official_player_id.astype(str)
    a=players.set_index(index);b=new.set_index(index)
    assert not a.index.duplicated().any() and not b.index.duplicated().any()
    merged=b.combine_first(a).reset_index()
    # Preserve more complete exact playing-time conventions already acquired.
    # Derived La Liga regulation-only minutes fill omissions but do not overwrite
    # previously verified elapsed minutes including stoppage time.
    for col in ['minutes','minutes_basis','position','player_type']:
        if col in a:
            older=a[col].dropna();joined=merged.set_index(index)
            joined.loc[older.index,col]=older
            merged=joined.reset_index()
    exposure_evidence={}
    if include_exposure:
        with read_db(ROOT_OUT/'bundesliga_minutes.sqlite') as c:exposures=[json.loads(b) for b, in c.execute('SELECT body FROM games')]
        raw_rows=[r for game in exposures for r in game['players']]
        fresh=pd.DataFrame([{k:r.get(k) for k in ['game_id','official_game_id','league','date','available_at_utc','side','team_id','official_player_id','player_name','position','started','played','minutes','minutes_basis','goals']} for r in raw_rows])
        prior=merged.set_index(index)
        native_ids=merged[['league','official_player_id','player_id']].drop_duplicates().set_index(['league','official_player_id']).player_id.to_dict()
        fresh['player_id']=[native_ids.get((r.league,r.official_player_id),'EU_BUN:'+r.official_player_id) for r in fresh.itertuples()]
        fresh=fresh.set_index(index);assert not fresh.index.duplicated().any()
        conflicts=[]
        overlap=prior.index.intersection(fresh.index)
        for field in ['played','started']:
            mask=prior.loc[overlap,field].notna()&fresh.loc[overlap,field].notna()&prior.loc[overlap,field].ne(fresh.loc[overlap,field])
            for key in overlap[mask]:conflicts.append(dict(game_id=key[0],side=key[1],official_player_id=key[2],field=field,prior=bool(prior.loc[key,field]),derived=bool(fresh.loc[key,field])))
        joined=fresh.combine_first(prior)
        # This new research branch consistently prefers verified regulation
        # minutes where supplied. Existing source rows and frozen studies retain
        # their original elapsed-minute conventions; they are not overwritten.
        for col in ['position','player_type']:
            known=prior[col].dropna();joined.loc[known.index,col]=known
        merged=joined.reset_index()
        exposure_evidence=dict(games=len(exposures),source_rows=len(fresh),added_known_minutes=int(joined.minutes.notna().sum()-prior.minutes.notna().sum()),conflicts=conflicts,
             minutes_convention='Prefer verified new regulation minutes for Bundesliga; original elapsed minutes survive only where the derived record is incomplete. Raw source fields and prior study features remain unchanged.')
        dump(OUT/'bundesliga_exposure_merge_audit.json',exposure_evidence)
    assert not merged.duplicated(['game_id','side','player_id']).any()
    extra=pd.DataFrame(teamrows).set_index(['game_id','side'])
    original=obs.set_index(['game_id','side']);obs=extra.combine_first(original).reset_index()
    for col in TEAM_PHYSICAL:
        if col not in stats:stats.append(col)
    for col in PLAYER_ACTIONS:
        if col not in metrics:metrics.append(col)
    if include_exposure:
        metrics.extend(c for c in ['distance_covered_km','challenges_won','shots_at_goal'] if c not in metrics)
    pd.DataFrame(provenance).to_parquet(OUT/'soccer_additional_player_crosswalk.parquet',index=False)
    return games,obs,merged,keys,stats,metrics,dict(identity=identity,joined_player_rows=len(rows),counts=dict(audit),
        exposure=exposure_evidence,input_hashes={name:file_sha256(ROOT_OUT/name) for name in ['soccer_additional.sqlite','player_detail.sqlite']+(['bundesliga_minutes.sqlite'] if include_exposure else [])})


def main():
    g,o,p,k,stats,metrics,evidence=enriched_sources()
    frame,audit=build('soccer',g,o,p,k,stats,metrics)
    selected=['quality_xg','quality_xg_against','finishing_residual','keeper_goals_saved',
              'shots_on_target','big_chances','pass_accuracy_pct','possession_pct']
    selected+=['roster_'+field+'_rate' for field in PLAYER_ACTIONS]
    # Separate overall pressing/workload proxies from per-player action rates.
    selected+=['distance_covered_km','sprints']
    aliases=[]
    for field in selected:
        old='f_'+field+'_diff';new='f_gran_'+field+'_diff'
        assert old in frame;frame[new]=frame[old];aliases.append(dict(column=new,source_column=old))
    frame.to_parquet(OUT/'soccer_features.parquet',index=False)
    dump(OUT/'soccer_additional_feature_audit.json',dict(at_utc=stamp(),games=len(frame),features=len(aliases),
        evidence=evidence,columns=aliases,source_player_rows=len(p),future_input_violations=0,
        cutoff='Only earlier completed matches with available_time strictly before the prediction cutoff. Roster weights use previous five games; player rates use up to thirty appearances.',
        missing_pct={c['column']:float(100*frame[c['column']].isna().mean()) for c in aliases},
        source_max_available_checks=len(audit)))
    print(json.dumps(dict(games=len(frame),additional_compact_features=len(aliases),source_players=len(p))),flush=True)


if __name__=='__main__':main()
