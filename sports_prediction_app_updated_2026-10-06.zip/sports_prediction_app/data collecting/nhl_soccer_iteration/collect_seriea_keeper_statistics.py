"""Official dated goalkeeper statistics with native lineup and result checks.

The official ranking response can have stale status metadata and duplicate stat
IDs. Those defects are retained explicitly; neither is silently interpreted as
missing games, zero statistics, or a reason to discard a valid other player.
"""
import argparse,collections,concurrent.futures,hashlib,json,math,sqlite3
from pathlib import Path
import pandas as pd
from common import ROOT_OUT,PROJECT,PREVIOUS,OfficialClient,read_db,dump,stamp
from discover_soccer_keeper_sources import RUN

FOLDER=RUN/'seriea'
PARSER_VERSION=3
FIELDS={'saves':'saves','minutes_reported':'minutes','goals_conceded_raw':'goalsConceded',
        'shots_on_target_faced_raw':'shotsOnGoalConceded','saves_inside_box_raw':'savedIbox',
        'saves_outside_box_raw':'savedObox','penalty_saves_raw':'penaltySave',
        'xgot_faced_raw':'expectedGoalsOnTargetConceded'}


def original(source):
    p=Path(source['raw_file']);p=p if p.is_absolute() else PROJECT/p
    body=p.read_bytes();assert hashlib.sha256(body).hexdigest()==source['sha256']
    return json.loads(body)


def sources():
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games={r['game_id']:dict(r) for r in db.execute("SELECT * FROM soccer_games WHERE league='Serie A' AND date BETWEEN '2021-01-01' AND '2026-09-30' ORDER BY date,game_id")}
    with read_db(ROOT_OUT/'seriea_players.sqlite') as db:
        players={gid:json.loads(body) for gid,body in db.execute('SELECT game_id,body FROM games')}
    repaired=FOLDER/'source_repairs.sqlite'
    if repaired.exists():
        with read_db(repaired) as db:
            players.update({gid:json.loads(body) for gid,body in db.execute('SELECT game_id,body FROM players')})
    return games,players


def endpoint(players):
    s=players[0]['source']['lineup'];url=s.get('url',s.get('endpoint'))
    assert '/matches/' in url and url.endswith('/lineups')
    return url.replace('/matches/','/match/').rsplit('/',1)[0]+'/ranking'


def normalize(game,people,data,source,calendar_source=None):
    lineup_source=people[0]['source']['lineup'];feed_source=people[0]['source']['feed']
    lineup=original(lineup_source);feed=original(feed_source)
    assert data['matchId']==lineup['matchId']==feed['matchId']==game['official_game_id']
    assert feed['status']=='FINISHED' and feed['pagination']['isLastPage']
    assert people and all(p['parser_version']==4 for p in people),'Prior lineup parser version is unverified'
    event_counts=all(p['goal_counts_reconcile'] for p in people)
    finals=[(i,e) for i,e in enumerate(feed['events']) if e['type'] in ['full-time','end-second-half']
            and e.get('providerAwayScore') is not None and e.get('providerHomeScore') is not None]
    final_score_agrees=bool(finals) and all([e['providerAwayScore'],e['providerHomeScore']]==[game['scoreA'],game['scoreB']] for _,e in finals)
    calendar_source=calendar_source or people[0]['source'].get('calendar')
    if calendar_source is not None:
        calendar=original(calendar_source)
        index=int(calendar_source['source_pointer'].split('/')[-1])
        result=calendar['matches'][index]
        assert result['matchId']==game['official_game_id']
        assert result['status']=='FINISHED' and result['phase']=='FULL_TIME'
        assert pd.Timestamp(result['matchDateUtc'])==pd.Timestamp(game['timestamp'])
        assert [result['away']['teamId'],result['home']['teamId']]==json.loads(game['native_team_ids_json'])
        for a,b in [('providerAwayScore','providerHomeScore'),('awayScorePush','homeScorePush')]:
            assert [result[a],result[b]]==[game['scoreA'],game['scoreB']]
    assert event_counts or final_score_agrees or calendar_source is not None,'Final score requires independent official result verification'
    result_source=calendar_source or feed_source
    rows=[];issues=[];unlinked=[];raw_fields=0
    if not event_counts:
        issues.append(dict(kind='incomplete_individual_goal_events',reason='Independent official final result verified; individual event counts do not reconcile and are not used.',
            final_score_pointers=[f'/events/{i}' for i,_ in finals]))
    if not all(p.get('lineup_complete',True) for p in people):
        issues.append(dict(kind='partial_native_lineup',reason='Only native goalkeeper entries corroborated by positive ranking minutes are retained; no missing outfield players are reconstructed.',
            published_starters={side:len(lineup[side]['fielded']) for side in ['away','home']}))
    if data.get('status')!='FINISHED' or data.get('phase')!='FULL_TIME':
        issues.append(dict(kind='stale_status_metadata',raw_status=data.get('status'),raw_phase=data.get('phase'),reason='Independent official final result establishes completion; ranking metadata preserved.'))
    byid={p['official_player_id']:p for p in people}
    for side,native,tid in zip(['A','B'],['away','home'],json.loads(game['native_team_ids_json'])):
        assert lineup[native]['teamId']==data[native]['teamId']==tid
        roster={p['playerId']:(p,group) for group in ['fielded','benched'] for p in lineup[native][group]}
        entries=data[native]['players'];seen=set();parsed=[]
        for index,item in enumerate(entries):
            pid=item['player']['playerId'];assert pid not in seen;seen.add(pid)
            assert item['team']['teamId']==tid
            grouped=collections.defaultdict(list)
            for j,field in enumerate(item['stats']):grouped[field['statsId']].append((j,field))
            stats={};pointers={};duplicate_fields=[];conflict_fields=[]
            for name,values in grouped.items():
                raw=[r.get('statsValue') for _,r in values]
                if len(values)>1:
                    if all(x==raw[0] for x in raw):duplicate_fields.append(name)
                    else:conflict_fields.append(name);continue
                value=raw[0]
                if value is None:continue
                if name in FIELDS.values():
                    assert isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value),(name,value)
                elif isinstance(value,(int,float)):
                    assert math.isfinite(value),(name,value)
                # Other official dimensions can be strings (for example an
                # average-position coordinate pair). Retain them as raw values.
                stats[name]=value;pointers[name]=[f'/{native}/players/{index}/stats/{j}/statsValue' for j,_ in values]
            if duplicate_fields:issues.append(dict(kind='identical_stat_duplicates',player_id=pid,fields=duplicate_fields))
            if conflict_fields:issues.append(dict(kind='conflicting_stat_duplicates',player_id=pid,fields=conflict_fields))
            if pid not in roster:
                unlinked.append(dict(game_id=game['game_id'],side=side,ranking_player_id=pid,source_pointer=f'/{native}/players/{index}',
                    provider_id=item['player'].get('providerId'),player_name=item['player'].get('shortName'),minutes=stats.get('minutes'),saves=stats.get('saves'),reason='Ranking native player ID absent from dated lineup; identity repair required before player-history use.'))
                continue
            person,group=roster[pid];assert pid in byid
            parsed.append((pid,person,group,stats,pointers,index,conflict_fields))
        for pid,person,group,stats,pointers,index,conflicts in parsed:
            if person.get('roleLabel')!='Goalkeeper':continue
            p=byid[pid]
            minutes=stats.get('minutes')
            if not p['did_play']:
                if minutes is not None and minutes>0:issues.append(dict(kind='keeper_participation_stat_conflict',player_id=pid,raw_minutes=minutes,reason='Ranking shows participation but lineup places player on unused bench; requires source repair'))
                continue
            if minutes is None or minutes<=0:
                issues.append(dict(kind='keeper_participation_stat_conflict',player_id=pid,raw_minutes=minutes));continue
            fields={field:stats.get(native_field) for field,native_field in FIELDS.items()}
            assert all(v is None or v>=0 for v in fields.values())
            own_changes=[e for e in person.get('events',[]) if e['type'] in ['substitution-in','substitution-out','red-card','second-yellow-card']]
            repair=p.get('keeper_report_repair')
            full=bool((group=='fielded' or repair) and not own_changes and not p['minutes_issues'] and p['minutes']==90 and minutes>=90)
            if repair:issues.append(dict(kind='keeper_starter_source_repair',player_id=pid,proof=repair))
            goals=fields['goals_conceded_raw'];basis='official goalkeeper statistic' if goals is not None else None
            opponent=game['scoreB' if side=='A' else 'scoreA']
            if goals is None and (full or opponent==0):
                goals=float(opponent);basis='official final score with verified full-match goalkeeper' if full else 'official team clean sheet'
            if full and goals is not None and goals!=opponent:
                issues.append(dict(kind='keeper_conceded_score_conflict',player_id=pid,raw_goals=goals,official_opponent_goals=opponent))
                # Keep the raw field but do not feed a conflicting normalized value.
                goals=None;basis=None
            row=dict(game_id=game['game_id'],official_game_id=game['official_game_id'],league=game['league'],date=game['date'],
                available_at_utc=p['available_at_utc'],side=side,team_id=tid,official_player_id=pid,
                player_name=person.get('shortName'),position='Goalkeeper',started=bool(group=='fielded' or repair),
                minutes_regulation=p['minutes'],full_match_verified=full,**fields,
                goals_conceded=goals,goals_conceded_basis=basis,
                raw_status=data.get('status'),raw_phase=data.get('phase'),
                raw_stats_json=json.dumps(stats,sort_keys=True),field_pointers_json=json.dumps({field:pointers.get(native_field) for field,native_field in FIELDS.items()},sort_keys=True),
                lineup_pointer=f'/{native}/{group}/'+str(next(i for i,r in enumerate(lineup[native][group]) if r['playerId']==pid)),
                source_json=json.dumps(source,sort_keys=True),lineup_source_json=json.dumps(lineup_source,sort_keys=True),result_source_json=json.dumps(result_source,sort_keys=True))
            raw_fields+=sum(v is not None for v in fields.values());rows.append(row)
    return dict(game_id=game['game_id'],date=game['date'],parser_version=PARSER_VERSION,players=rows,unlinked_players=unlinked,issues=issues,source=source,
        lineup_source=lineup_source,result_source=result_source,feed_source=feed_source,calendar_source=calendar_source,raw_numeric_fields=raw_fields,
        validation=dict(native_match_id=True,team_ids=True,final_feed=bool(final_score_agrees),calendar_result=calendar_source is not None,official_final_score_reconciled=True))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');parser.add_argument('--year',type=int);parser.add_argument('--workers',type=int,default=3);args=parser.parse_args()
    FOLDER.mkdir(exist_ok=True);games,players=sources()
    if args.pilot:ids=[r['game']['game_id'] for r in json.loads((RUN/'seriea_keeper_pilot_requests.json').read_bytes())['records']]
    else:
        assert json.loads((FOLDER/'pilot_validation.json').read_bytes())['status']=='PASS'
        ids=[gid for gid,g in games.items() if args.year is None or g['date'].startswith(str(args.year))]
    db=sqlite3.connect(FOLDER/'statistics.sqlite',timeout=60)
    db.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT NOT NULL); CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,body TEXT NOT NULL);')
    done={r[0] for r in db.execute("SELECT game_id FROM games WHERE json_extract(body,'$.parser_version')=?",[PARSER_VERSION])};tasks=[gid for gid in ids if gid not in done]
    client=OfficialClient(2)
    def fetch(gid):
        source=None
        try:
            data,source=client.get(endpoint(players[gid]),'Official dated Serie A player keeper statistics: '+games[gid]['date']+' '+games[gid]['official_game_id'],kind='official_keeper_match_statistics')
            assert data is not None,source['return_status']
            return normalize(games[gid],players[gid],data,source),None
        except Exception as exc:return None,dict(game_id=gid,reason=type(exc).__name__+': '+str(exc),source=source)
    counts=collections.Counter();mark=10
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(fetch,gid):gid for gid in tasks}
        for n,future in enumerate(concurrent.futures.as_completed(futures),1):
            gid=futures[future]
            try:record,error=future.result()
            except Exception as exc:record,error=None,dict(game_id=gid,reason=type(exc).__name__+': '+str(exc))
            with db:
                if record:
                    db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',[gid,json.dumps(record)]);db.execute('DELETE FROM issues WHERE game_id=?',[gid])
                    counts['games']+=1;counts['keeper_rows']+=len(record['players']);counts['unlinked_player_rows']+=len(record['unlinked_players']);counts['raw_numeric_fields']+=record['raw_numeric_fields']
                else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?)',[gid,json.dumps(error)]);counts['acquisition_or_validation_issues']+=1
            if n*100>=mark*len(tasks) or n==len(tasks):
                status=dict(at_utc=stamp(),year=args.year,pilot=args.pilot,processed=n,total=len(tasks),percent=round(100*n/len(tasks),1),counts=dict(counts))
                dump(FOLDER/'collection_progress.json',status);print(json.dumps(status),flush=True);mark+=10
    records=[json.loads(b) for b, in db.execute('SELECT body FROM games')]
    dump(FOLDER/'coverage.json',dict(at_utc=stamp(),retained_games=len(records),keeper_rows=sum(len(r['players']) for r in records),pending_requests=db.execute('SELECT count(*) FROM issues').fetchone()[0],earliest=min((r['date'] for r in records),default=None),latest=max((r['date'] for r in records),default=None)))
    db.close()


if __name__=='__main__':main()
