"""Training-only per-competition scaling; no source values are overwritten."""
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator,TransformerMixin
from sklearn.preprocessing import StandardScaler


class UnitAwareStandardScale(StandardScaler):
    """Keep specified already-normalized fields and their binary indicators in units.

    Median-imputing a rare observation then estimating its variance over all
    rows shrinks variance with coverage. Do not divide these fields a second
    time; CompetitionScale already estimates their observed within-league SD.
    Other fields receive exactly the ordinary StandardScaler transformation.
    """
    def __init__(self, preserve_columns=()):
        super().__init__()
        self.preserve_columns=preserve_columns

    def fit(self,X,y=None,sample_weight=None):
        super().fit(X,y,sample_weight=sample_weight)
        names=list(X.columns)
        preserve=set(self.preserve_columns)
        preserve.update('missingindicator_'+c for c in self.preserve_columns)
        for i,name in enumerate(names):
            if name in preserve:
                self.mean_[i]=0.
                self.scale_[i]=1.
        return self


class CompetitionScale(BaseEstimator,TransformerMixin):
    def __init__(self,signed_log=False,pooled_variance_floor=False):
        self.signed_log=signed_log
        self.pooled_variance_floor=pooled_variance_floor
    def _values(self,X):
        a=X[self.numeric_].astype(float)
        if self.signed_log:a=np.sign(a)*np.log1p(np.abs(a))
        return a
    def _group(self,X):
        return X[self.leagues_].idxmax(axis=1) if self.leagues_ else pd.Series('__all__',index=X.index)
    def fit(self,X,y=None):
        self.leagues_=[c for c in X if c.startswith('league_')];self.numeric_=[c for c in X if c not in self.leagues_]
        a=self._values(X);group=self._group(X)
        self.global_mean_=a.mean();self.global_sd_=a.std(ddof=0).replace(0,1).fillna(1)
        self.means_=a.groupby(group).mean();self.sds_=a.groupby(group).std(ddof=0).replace(0,1).fillna(1)
        if self.pooled_variance_floor:
            # A tiny variance estimated from a few league observations must
            # not amplify new values more than the pooled observed scale.
            # No labels, future values or new tuning constant are used.
            self.sds_=self.sds_.clip(lower=self.global_sd_,axis=1)
        return self
    def transform(self,X):
        out=X.astype(float).copy();a=self._values(X);groups=self._group(X)
        for league,indices in groups.groupby(groups).groups.items():
            mean=self.means_.loc[league].fillna(self.global_mean_) if league in self.means_.index else self.global_mean_
            sd=self.sds_.loc[league] if league in self.sds_.index else self.global_sd_
            out.loc[indices,self.numeric_]=(a.loc[indices]-mean)/sd
        return out
