"""Add an exact official report alias, resolving all IDs from native records."""
import argparse,json
import pandas as pd
from common import OfficialClient,PREVIOUS,read_db,dump,stamp
from collect_nhl_opening_rosters import RUN,namekey
from nhl_roster_aliases import candidates,report_headings,name_from_heading,verify_proof,repair


def register(native,side,full_name):
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        rows=db.execute('SELECT game_id FROM nhl_games WHERE official_game_id=?',(native,)).fetchall()
    assert len(rows)==1
    game_id=rows[0]['game_id'];year=int(native[:4]);code='TH' if side=='B' else 'TV';teamkey='homeTeam' if side=='B' else 'awayTeam'
    c=OfficialClient(per_second=2)
    raw,source=c.get(f'https://www.nhl.com/scores/htmlreports/{year}{year+1}/{code}{native[4:]}.HTM',
                     'Verify exact dated roster alias '+full_name,'nhl_roster_alias_identity',document=True)
    box,boxsource=c.get('https://api-web.nhle.com/v1/gamecenter/'+native+'/boxscore','Verify native team/sweater/player alias '+full_name,'nhl_roster_alias_identity')
    found=[(i,name_from_heading(h)) for i,h in enumerate(report_headings(raw)) if namekey(name_from_heading(h)[1])==namekey(full_name)]
    assert len(found)==1;index,(number,name)=found[0]
    people=[p for group in box['playerByGameStats'][teamkey].values() if isinstance(group,list) for p in group if p.get('sweaterNumber')==number]
    assert len(people)==1;p=people[0]
    proof=dict(official_player_id=str(p['playerId']),official_game_id=native,game_id=game_id,side=side,team_id=str(box[teamkey]['id']),
               sweater_number=number,report_name=name,report_header_index=index,report_source=source,box_source=boxsource,position=p['position'])
    assert verify_proof(proof)
    cat=candidates();key=namekey(name)
    cat[key]=[r for r in cat.get(key,[]) if r['official_game_id']!=native]+[proof]
    dump(RUN/'report_alias_candidates.json',cat)
    # Correct a derived canonical link if an earlier manual registration used
    # a display match label rather than the registry's native-backed join key.
    # The original reports/API objects and native game IDs remain unchanged.
    fixes=[]
    for path in RUN.glob('*/full.parquet'):
        f=pd.read_parquet(path)
        for idx,r in f.iterrows():
            value=r.get('identity_evidence_json')
            if value is None or pd.isna(value):continue
            e=json.loads(value)
            if e.get('official_game_id')==native and e.get('official_player_id')==proof['official_player_id'] and e['game_id']!=game_id:
                fixes.append(dict(season=r.season,player_name=r.player_name_raw,before=e['game_id'],after=game_id))
                e['game_id']=game_id;f.loc[idx,'identity_evidence_json']=json.dumps(e,sort_keys=True)
        f.to_parquet(path,index=False);f.to_csv(path.with_suffix('.csv'),index=False)
    ledger=RUN/'alias_repairs.json'
    if ledger.exists():
        values=json.loads(ledger.read_bytes())
        for r in values:
            e=r['proof']
            if e.get('official_game_id')==native:e['game_id']=game_id
        dump(ledger,values)
    if fixes:dump(RUN/'alias_registry_link_corrections.json',dict(at_utc=stamp(),corrections=fixes,raw_and_native_ids_unchanged=True))
    repair();print(json.dumps(dict(official_game_id=native,canonical_game_id=game_id,official_player_id=proof['official_player_id'],corrected_links=len(fixes))),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--game',required=True);p.add_argument('--side',choices=['A','B'],required=True);p.add_argument('--name',required=True);a=p.parse_args();register(a.game,a.side,a.name)
