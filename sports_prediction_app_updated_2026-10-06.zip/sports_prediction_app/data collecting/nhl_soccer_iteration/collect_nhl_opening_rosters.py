"""Dated official opening roster release, cross-checked against native API IDs.

Season roster API objects have no membership effective dates. A dated league
press release establishes the snapshot, never today's club or a future lineup.
"""
import argparse,hashlib,html,json,re,unicodedata
from html.parser import HTMLParser
import pandas as pd
from common import OfficialClient,PROJECT,ROOT_OUT,PREVIOUS,read_db,dump,stamp

RUN=ROOT_OUT/'opening_rosters_v49'
RELEASES={
 '20202021':'https://www.nhl.com/news/nhl-opening-night-rosters-for-2020-21-season-320209828',
 '20212022':'https://www.nhl.com/news/nhl-opening-night-rosters-for-2021-22-season-326757164',
 '20222023':'https://www.nhl.com/news/nhl-2022-23-season-opening-night-rosters-336238202',
 '20232024':'https://www.nhl.com/news/nhl-opening-night-rosters-for-2023-24-season',
 '20242025':'https://www.nhl.com/news/nhl-announces-opening-night-rosters-for-2024-25-season',
 '20252026':'https://www.nhl.com/news/2025-2026-nhl-opening-day-rosters-announced'}


class StructuredArticle(HTMLParser):
    def __init__(self):super().__init__();self.capture=False;self.text=[];self.items=[]
    def handle_starttag(self,tag,attrs):
        if tag=='script' and dict(attrs).get('type')=='application/ld+json':self.capture=True;self.text=[]
    def handle_data(self,text):
        if self.capture:self.text.append(text)
    def handle_endtag(self,tag):
        if tag=='script' and self.capture:
            self.items.append(json.loads(''.join(self.text)));self.capture=False


def plain(value):
    value=re.sub(r'\[([^\]]+)\]\([^)]*\)',r'\1',value)
    return html.unescape(re.sub(r'[#*_]', '',value)).strip()


def namekey(value):
    # Mechanical accent/punctuation normalization, not spelling-distance or
    # nickname matching. Native IDs and original names stay in output.
    return ''.join(c for c in unicodedata.normalize('NFKD',value).casefold() if c.isalnum() and not unicodedata.combining(c))


def teamkey(value):return ''.join(c for c in unicodedata.normalize('NFKD',value).casefold() if not unicodedata.combining(c)).strip()


def parse_release(blob,team_names):
    parser=StructuredArticle();parser.feed(blob.decode('utf8'))
    candidates=[x for x in parser.items if isinstance(x,dict) and x.get('@type')=='NewsArticle']
    assert len(candidates)==1
    article=candidates[0];body=article['articleBody'];blocks={};current=None
    registry={teamkey(n):n for n in team_names}
    assert len(registry)==len(team_names)
    # Some historical article bodies concatenate a bold club heading directly
    # after the previous paragraph; isolate only verified team headings.
    body=re.sub(r'\*\*([^*]+)\*\*',lambda m:'\n'+m.group(0)+'\n' if teamkey(m.group(1)) in registry else m.group(0),body)
    for line in body.splitlines():
        simple=plain(line)
        if teamkey(simple) in registry:current=registry[teamkey(simple)];blocks[current]=[]
        elif current:blocks[current].append(line)
    parsed=[]
    for team,lines in blocks.items():
        chunk=plain(' '.join(lines))
        labels=list(re.finditer(r'(Injured and/or Non-Roster|Injured reserve|Injured|Taxi squad)\s*:',chunk,re.I))
        assert labels,(team,'No explicit status boundary')
        parts=[('active_roster',chunk[:labels[0].start()])]
        statuses={'injured and/or non-roster':'injured_or_non_roster','injured reserve':'injured_reserve','injured':'injured','taxi squad':'taxi_squad'}
        for i,label in enumerate(labels):parts.append((statuses[label.group(1).lower()],chunk[label.end():labels[i+1].start() if i+1<len(labels) else len(chunk)]))
        for status,text in parts:
            names=[x.strip(' .\r\n\\') for x in text.split(',') if x.strip(' .\r\n\\')]
            if names==['None']:continue
            for name in names:
                assert 2<=len(name.split())<=5,(team,name)
                occurrence=1+sum(r['team_name']==team and r['player_name_raw']==name for r in parsed)
                parsed.append(dict(team_name=team,player_name_raw=name,roster_status=status,source_name_occurrence=occurrence))
    assert len(blocks)>=16,'Incomplete or changed article structure must be investigated'
    # Current text may have been edited after first publication. Using the
    # later timestamp prevents backdating a revised article to publication.
    available=max(pd.Timestamp(article['datePublished']),pd.Timestamp(article.get('dateModified',article['datePublished'])))
    return parsed,dict(headline=article['headline'],date_published=article['datePublished'],date_modified=article.get('dateModified'),
        conservative_available_at_utc=available.isoformat(),clubs=len(blocks),structured_path='NewsArticle.articleBody')


def main():
    p=argparse.ArgumentParser();p.add_argument('--season',default='20252026',choices=list(RELEASES));p.add_argument('--full',action='store_true');args=p.parse_args()
    RUN.mkdir(exist_ok=True);client=OfficialClient(per_second=2)
    if args.full:
        pilot=json.loads((RUN/'20252026/pilot_validation.json').read_bytes())
        assert pilot['status']=='PASS' and pilot['cleared_for_full_collection']
    history_names={};global_names={}
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        for pid,name,team in db.execute('SELECT DISTINCT official_player_id,player_name,team_id FROM nhl_player_games'):
            history_names.setdefault((namekey(name),str(team)),set()).add(str(pid))
            global_names.setdefault(namekey(name),set()).add(str(pid))
    data,team_source=client.get('https://api.nhle.com/stats/rest/en/team','Opening-roster native team identity','nhl_team_identity')
    teams={r['fullName']:r for r in data['data']}
    blob,source=client.get(RELEASES[args.season],args.season+' dated league opening roster release','nhl_opening_roster_release',document=True)
    assert blob is not None
    rows,metadata=parse_release(blob,teams);listed=sorted(set(r['team_name'] for r in rows))
    selected=listed if args.full else ['Anaheim Ducks','Boston Bruins','Carolina Hurricanes']
    expected=[r for r in rows if r['team_name'] in selected]
    assert set(selected)<=set(listed)
    result=[];api_notes=[];next_milestone=10
    for i,team in enumerate(selected,1):
        info=teams[team];abbrev=info['triCode']
        roster,api_source=client.get(f'https://api-web.nhle.com/v1/roster/{abbrev}/{args.season}',args.season+' opening release native player identities '+team,'nhl_season_roster_identity')
        assert roster is not None
        index={}
        for group in ['forwards','defensemen','goalies']:
            for number,person in enumerate(roster[group]):
                full=person['firstName']['default']+' '+person['lastName']['default']
                index.setdefault(namekey(full),[]).append((person,full,'/'+group+'/'+str(number)))
        api_notes.append(dict(team_name=team,keys=list(roster),players=sum(len(roster[g]) for g in ['forwards','defensemen','goalies']),
            has_membership_effective_dates=False,source=api_source))
        for row in expected:
            if row['team_name']!=team:continue
            matched=index.get(namekey(row['player_name_raw']),[])
            item=row|dict(season=args.season,team_id=str(info['id']),official_player_id=None,player_name_api=None,position=None,
                identity_verified=False,identity_reason='Exact source name not uniquely present in season roster; needs documented alias or native player link',
                available_at_utc=metadata['conservative_available_at_utc'],release_source_json=json.dumps(source,sort_keys=True),
                    identity_source_json=json.dumps(api_source,sort_keys=True),identity_pointer=None,
                    identity_candidates_json=json.dumps([str(x[0]['id']) for x in matched]))
            if len(matched)==1:
                person,full,pointer=matched[0]
                item.update(official_player_id=str(person['id']),player_name_api=full,position=person['positionCode'],identity_verified=True,
                    identity_reason='Full source name equal after mechanical accent/punctuation normalization, same official native team and season roster; no fuzzy or nickname matching',identity_pointer=pointer)
            else:
                candidates=history_names.get((namekey(row['player_name_raw']),str(info['id'])),set())
                if not candidates:candidates=global_names.get(namekey(row['player_name_raw']),set())
                if len(candidates)==1:
                    pid=next(iter(candidates))
                    person,person_source=client.get(f'https://api-web.nhle.com/v1/player/{pid}/landing','Verify native identity for dated roster '+row['player_name_raw'],'nhl_player_identity')
                    if person is not None:
                        full=person['firstName']['default']+' '+person['lastName']['default']
                        assert str(person['playerId'])==pid
                        if namekey(full)==namekey(row['player_name_raw']):
                            item.update(official_player_id=pid,player_name_api=full,position=person['position'],identity_verified=True,
                                identity_reason='Full release name equals unique native player landing identity after mechanical accent/punctuation normalization. Candidate from official game records; membership comes only from dated release, not current team.',
                                identity_source_json=json.dumps(person_source,sort_keys=True),identity_pointer='/',identity_candidates_json=json.dumps([pid]))
            result.append(item)
        percent=int(100*i/len(selected))
        if percent>=next_milestone or i==len(selected):
            print(json.dumps(dict(stage='opening_roster_identity',season=args.season,clubs=i,total_clubs=len(selected),percent=percent,verified=sum(r['identity_verified'] for r in result),rows=len(result))),flush=True)
            next_milestone=10*(percent//10+1)
    folder=RUN/args.season;folder.mkdir(exist_ok=True)
    label='full' if args.full else 'pilot'
    f=pd.DataFrame(result);f.to_parquet(folder/(label+'.parquet'),index=False);f.to_csv(folder/(label+'.csv'),index=False)
    dump(folder/(label+'_source.json'),dict(release=source,team_source=team_source,metadata=metadata,api_notes=api_notes,
        api_insufficiency='Season roster API contains identity/physical fields but no effective membership dates. The historical statement comes solely from the dated official structured NewsArticle. injured_or_non_roster is not classified as a definite injury.',
        date_policy='Use later of published and modified timestamps; never apply this snapshot before that timestamp or for the whole season as though continuously current.'))
    dump(folder/(label+'_collection.json'),dict(at_utc=stamp(),season=args.season,clubs=len(selected),rows=len(f),verified=int(f.identity_verified.sum()),
        unmatched=int((~f.identity_verified).sum()),unmatched_pct=float(100*(~f.identity_verified).mean()),available_at_utc=metadata['conservative_available_at_utc'],state='collected; independent raw/source validation required before model use'))
    print(json.dumps(dict(season=args.season,rows=len(f),verified=int(f.identity_verified.sum()),unmatched=f[~f.identity_verified][['team_name','player_name_raw','roster_status']].to_dict('records'))),flush=True)


if __name__=='__main__':main()
