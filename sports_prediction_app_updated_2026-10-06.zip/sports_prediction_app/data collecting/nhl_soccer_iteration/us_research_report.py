"""Consolidated report, paired diagnostics, catalog and prospective decision."""
import html,json,math,re,sqlite3
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import log_loss
from common import ROOT_OUT,PROJECT,REPORTS,dump,stamp,file_sha256
from us_market_data import RESULT,predictions,DOCS
from us_market_experiments import winners

def table(frame):
    def value(x):
        if pd.isna(x):return '—'
        if isinstance(x,(float,np.floating)):return f'{x:.4f}'
        return str(x).replace('|','/')
    return '\n'.join(['| '+' | '.join(map(str,frame.columns))+' |','| '+' | '.join(['---']*len(frame.columns))+' |']+['| '+' | '.join(value(x) for x in r)+' |' for r in frame.itertuples(index=False,name=None)])

def prose(text):
    """Space generated prose without corrupting URLs, equations or field names."""
    for path in RESULT.iterdir():
        if path.is_file():
            for prefix in ['in','and','See']:
                text=text.replace(prefix+path.name,prefix+' '+path.name)
            for suffix in ['for','and']:
                text=text.replace(path.name+suffix,path.name+' '+suffix)
    protected=[]
    def save(m):
        protected.append(m.group());return '\x00'+chr(0xE000+len(protected)-1)+'\x00'
    text=re.sub(r'https?://\S+|(?:gateway\.)polymarket\.us/\S+|\d{4}-\d{2}-\d{2}T[\d:.+-]+|\b[A-Za-z0-9_]+\.(?:csv|parquet|json|md|html)\b|\b[a-z]+[A-Za-z0-9]*_[A-Za-z0-9_]+\b|\b[pqr]\d+\b',save,text)
    text=re.sub(r'(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])',' ',text)
    replacements={'The75':'The 75','The 75%multinomial':'The 75% multinomial','25%Dixon':'25% Dixon',
        'atT-':'at T-','entryT-':'entry T-','byT-':'by T-','reachesSharpe':'reaches Sharpe',
        'achievedSharpe':'achieved Sharpe','Seeall':'See all','SeeREADME':'See README',
        'for reproduction':'for reproduction','inpaired':'in paired','andcalendar':'and calendar',
        'p-qdoes':'p-q does','Positivep-q':'Positive p-q','usesp_home':'uses p_home',
        'onlylogit':'only logit','andmeta':'and meta','inhistorical':'in historical',
        'inentry':'in entry','andlinear':'and linear','andDixon':'and Dixon','E:edge':'E: edge',
        'A:edge':'A: edge','B/C/I:market':'B/C/I: market','D:meta':'D: meta',
        'F/G:intrawindow':'F/G: intrawindow','H:quote':'H: quote','J:dated':'J: dated',
        'K:soccer':'K: soccer','L:conditional':'L: conditional','M:fixed':'M: fixed',
        'withC=':'with C=','fitsY-q':'fits Y-q','withridge':'with ridge','with$':'with $',
        'isq_home':'is q_home','andmissing':'and missing','andcatalog':'and catalog',
        'andhistorical':'and historical','rangeof':'range of',
        'NHLmarket':'NHL market','coversJanuary':'covers January','.550':'. 550','SD.2026':'SD. 2026','years.2026':'years. 2026'}
    for old,new in replacements.items():text=text.replace(old,new)
    for i,value in enumerate(protected):
        token='\x00'+chr(0xE000+i)+'\x00'
        text=re.sub(r'(?<=\w)'+re.escape(token),' '+token,text)
        text=re.sub(re.escape(token)+r'(?=\w)',token+' ',text)
        text=text.replace(token,value)
    return text

def render_html(text):
    """Render this report's headings, tables and paragraphs without dependencies."""
    def inline(value):
        value=html.escape(value)
        value=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',value)
        value=re.sub(r'`([^`]+)`',r'<code>\1</code>',value)
        return re.sub(r'https?://[^\s<>]+',lambda m:'<a href="'+m.group()+'">'+m.group()+'</a>',value)
    lines=text.splitlines();out=[];i=0
    while i<len(lines):
        s=lines[i]
        if not s.strip():i+=1;continue
        if s.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].startswith('|'):
                cells=[c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',c) for c in cells):rows.append(cells)
                i+=1
            out.append('<table><thead><tr>'+''.join('<th>'+inline(c)+'</th>' for c in rows[0])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+inline(c)+'</td>' for c in row)+'</tr>' for row in rows[1:])+'</tbody></table>');continue
        heading=re.match(r'^(#{1,6}) (.*)',s)
        if heading:
            level=len(heading[1]);out.append(f'<h{level}>'+inline(heading[2])+f'</h{level}>');i+=1;continue
        if s.startswith('- '):
            items=[]
            while i<len(lines) and lines[i].startswith('- '):items.append('<li>'+inline(lines[i][2:])+'</li>');i+=1
            out.append('<ul>'+''.join(items)+'</ul>');continue
        paragraph=[s];i+=1
        while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','- ')):paragraph.append(lines[i]);i+=1
        out.append('<p>'+inline(' '.join(paragraph))+'</p>')
    return '\n'.join(out)

def paired_diagnostics():
    f=pd.read_parquet(RESULT/'market_model_predictions.parquet');rows=[];meta=[]
    control=pd.read_parquet(RESULT/'meta_market_control_predictions.parquet')
    for (sport,h),g in f.groupby(['sport','entry_hours']):
        k=2 if sport=='nhl' else 3;pcols=['p'+str(i) for i in range(k)]
        base=g[g.model.eq('sports_baseline')].set_index('game_id');market=g[g.model.eq('market_only')].set_index('game_id')
        for model,z in g.groupby('model'):
            ix=base.index.intersection(market.index).intersection(z.game_id)
            if not len(ix):continue
            z=z.set_index('game_id').loc[ix];b=base.loc[ix];m=market.loc[ix];y=z.target.to_numpy(int)
            for name,data in [(model,z),('sports_on_same_games',b),('market_on_same_games',m)]:
                p=data[pcols].to_numpy();rows.append(dict(sport=sport,entry_hours=int(h),comparison=model,model=name,games=len(ix),accuracy_pct=100*float((p.argmax(axis=1)==y).mean()),logloss=float(log_loss(y,p,labels=list(range(k)))),brier=float(np.mean((p[:,1]-y)**2)) if k==2 else float(np.mean(np.sum((p-np.eye(k)[y])**2,axis=1)))))
        gate=g[g.model.eq('meta_gate')].set_index('game_id');marketgate=control[control.sport.eq(sport)&control.entry_hours.eq(h)].set_index('game_id')
        ix=gate.index.intersection(marketgate.index)
        if len(ix):
            z=gate.loc[ix];p=z[pcols].to_numpy();side=p.argmax(axis=1);y=(side==z.target.to_numpy(int)).astype(int)
            price=z[['q'+str(i) for i in range(k)]].to_numpy()[np.arange(len(z)),side]
            candidates={'full_meta':z.meta_confidence.to_numpy(),'market_only_meta':marketgate.loc[ix].meta_confidence.to_numpy(),'raw_selected_us_price':price,'base_confidence':p.max(axis=1)}
            for name,r in candidates.items():meta.append(dict(sport=sport,entry_hours=int(h),forecast=name,games=len(z),mean_probability=float(r.mean()),win_rate=float(y.mean()),brier=float(np.mean((r-y)**2)),logloss=float(log_loss(y,r,labels=[0,1]))))
    pd.DataFrame(rows).to_csv(RESULT/'paired_model_comparison.csv',index=False);pd.DataFrame(meta).to_csv(RESULT/'meta_probability_scores.csv',index=False)
    # Sampling uncertainty: paired monthly blocks on proper scores, no best-profit selection.
    s=pd.read_parquet(RESULT/'soccer_model_predictions.parquet');base=s[s.model.eq('sports_baseline')].set_index('game_id');rng=np.random.default_rng(37);ci=[]
    for model,g in s.groupby('model'):
        if model=='sports_baseline':continue
        g=g[pd.to_datetime(g.prediction_time,utc=True).dt.year.lt(2026)].set_index('game_id');b=base.loc[g.index];y=g.target.to_numpy(int)
        diff=-np.log(g[['p0','p1','p2']].to_numpy()[np.arange(len(g)),y])+np.log(b[['p0','p1','p2']].to_numpy()[np.arange(len(g)),y])
        blocks=pd.DataFrame(dict(fold=g.fold.to_numpy(),delta=diff)).groupby('fold').delta.agg(['sum','count']).to_numpy();sample=[]
        for _ in range(1000):
            chosen=blocks[rng.integers(0,len(blocks),size=len(blocks))];sample.append(chosen[:,0].sum()/chosen[:,1].sum())
        ci.append(dict(model=model,earlier_logloss_change=float(diff.mean()),monthly_block_ci_low=float(np.quantile(sample,.025)),monthly_block_ci_high=float(np.quantile(sample,.975)),folds=len(blocks)))
    pd.DataFrame(ci).to_csv(RESULT/'soccer_probability_uncertainty.csv',index=False)

def coverage_and_spread():
    p=predictions();f=pd.read_parquet(RESULT/'entry_dataset.parquet');coverage=pd.read_csv(RESULT/'us_coverage.csv')
    for ix,r in coverage.iterrows():
        n=int((p.sport.eq(r.sport)&(pd.to_datetime(p.start_time,utc=True)-pd.Timedelta(hours=r.entry_hours)).dt.year.eq(r.year)).sum())
        coverage.loc[ix,'baseline_forecasts']=n;coverage.loc[ix,'missing_winner_quote_pct']=100*(1-r.selected_winner_prices/n) if n else np.nan
    coverage.to_csv(RESULT/'us_coverage.csv',index=False)
    missing=[]
    for (sport,h),g in f.groupby(['sport','entry_hours']):
        # Draw slots are not applicable to NHL, not missing observations.
        for field in ['q0','q1']+(['q2'] if sport=='soccer' else []):
            for year,z in g.groupby(g.entry.dt.year):missing.append(dict(sport=sport,entry_hours=int(h),year=int(year),column=field,missing=int(z[field].isna().sum()),rows=len(z),missing_pct=100*float(z[field].isna().mean()),denominator='Matched US event/forecast rows; includes pre-creation exclusions'))
    pd.DataFrame(missing).to_csv(RESULT/'missing_columns.csv',index=False)
    with sqlite3.connect(RESULT/'acquisition.sqlite') as c:
        c.row_factory=sqlite3.Row;audit={r['request_number']:dict(r) for r in c.execute('SELECT * FROM request_audit')}
    cache={};spread=[]
    for r in f.to_dict('records'):
        for side in range(2 if r['sport']=='nhl' else 3):
            rid=r.get('quote_request'+str(side))
            if pd.isna(rid):continue
            if rid not in cache:cache[rid]=json.loads((PROJECT/audit[rid]['raw_file']).read_bytes())['history']
            point=cache[rid][int(r['quote_pointer'+str(side)].rsplit('/',1)[-1])]
            value=float(point['longPrice'])+float(point['shortPrice'])-1
            spread.append(dict(game_id=r['game_id'],sport=r['sport'],entry_hours=r['entry_hours'],side=side,entry=r['entry'],exit=r['exit'],spread_state=value,quote_timestamp=pd.Timestamp(point['timestamp'],unit='s',tz='UTC'),source_request_number=int(rid)))
    spread=pd.DataFrame(spread);spread.to_parquet(RESULT/'historical_spread_state.parquet',index=False)
    diagnostics=[]
    for (sport,h),g in f.groupby(['sport','entry_hours']):
        z=winners(g);z=z.merge(spread[spread.sport.eq(sport)&spread.entry_hours.eq(h)][['game_id','side','spread_state']],on=['game_id','side'],validate='one_to_one')
        z['prior_spread_median']=np.nan
        for month,ix in z.groupby(z.entry.dt.strftime('%Y-%m')).groups.items():
            prior=z[z.exit.lt(pd.Timestamp(month,tz='UTC'))]
            if len(prior)>=30:z.loc[ix,'prior_spread_median']=prior.spread_state.median()
        z['group']=np.where(z.prior_spread_median.isna(),'no_prior_reference',np.where(z.spread_state>z.prior_spread_median,'wider','narrower_or_equal'))
        for group,v in z.groupby('group'):diagnostics.append(dict(sport=sport,entry_hours=int(h),group=group,games=len(v),mean_spread=float(v.spread_state.mean()),win_rate=float(v.won.mean()),mean_y_minus_q=float((v.won-v.price).mean()),mean_unit_return=float((v.won/v.price-1).mean())))
    pd.DataFrame(diagnostics).to_csv(RESULT/'spread_state_diagnostics.csv',index=False)
    return coverage

def make_report():
    paired_diagnostics();coverage=coverage_and_spread()
    # Empty cash simulations are not observed market performance.
    observed=coverage.set_index(['sport','entry_hours','year']).selected_winner_prices
    for prefix in ['us','meta_market_control','overall_sequence']:
        path=RESULT/(prefix+'_annual.csv');annual=pd.read_csv(path)
        annual['eligible_us_games']=[int(observed.get((r.sport,r.entry_hours,r.year),0)) for r in annual.itertuples()]
        annual['performance_observed']=annual.eligible_us_games.gt(0)
        annual.loc[~annual.performance_observed,['return_pct','sharpe','max_drawdown_pct']]=np.nan
        annual.to_csv(path,index=False)
    a=pd.read_csv(RESULT/'us_annual.csv');control=pd.read_csv(RESULT/'meta_market_control_annual.csv');a26=a[a.year.eq(2026)]
    overall=pd.read_csv(RESULT/'overall_sequence_annual.csv');overall=overall[overall.year.eq(2026)]
    refs=pd.read_csv(RESULT/'reference_baseline_annual.csv');metrics=pd.read_csv(RESULT/'base_model_metrics.csv');soccer=pd.read_csv(RESULT/'soccer_model_comparison.csv')
    paired=pd.read_csv(RESULT/'paired_model_comparison.csv');meta=pd.read_csv(RESULT/'meta_probability_scores.csv');ci=pd.read_csv(RESULT/'soccer_probability_uncertainty.csv')
    columns=['entry_hours','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct','mean_edge']
    display=['model','rule']+columns
    baseline=a26[a26.rule.eq('us_baseline')].sort_values('entry_hours',ascending=False)
    soccer_gate=a26[a26.sport.eq('soccer')&a26.model.eq('meta_gate')&a26.rule.eq('meta_gt_0.55')].sort_values('entry_hours',ascending=False)
    nhl_candidate=a26[a26.sport.eq('nhl')&a26.rule.eq('edge_bucket_max2')].sort_values('entry_hours',ascending=False)
    hits=a26[a26.sharpe.gt(3)&a26.return_pct.gt(20)].sort_values('sharpe',ascending=False)
    evidence=dict(created_at_utc=stamp(),research_target=dict(sharpe_gt=3,return_pct_gt=20),numerical_target_hits=hits[display+['sport']].to_dict('records'),
        defensible_multi_period_target_achieved=False,adopted_strategy=None,
        reason='The full available soccer sequence, retaining the existing baseline before meta readiness, has best Sharpe 0.979475 at one-hour entry and return 21.197684%. No eligible primary US prices were established for 2024/25. The shorter meta-only result is not the overall result.',
        overall_target_achieved=False,stop_soccer_on_target=False,
        overall_sequence=json.loads(overall.to_json(orient='records')),
        nba_mlb_app_changed=False,next_test='Freeze soccer meta r>.55 at T-1h and NHL existing p>.60,q>.50 at T-6h for prospective paper-only observation from2026-10-04; preserve price-only controls. Review after both six months and200 settled qualifying bets; do not tune along the way.')
    dump(RESULT/'research_decision.json',evidence)
    ablation=[]
    choices=[('Existing US baseline','sports_baseline','us_baseline'),('US market winner','market_only','market_winner'),
        ('Positive model edge','sports_baseline','baseline_edge_gt_0.00'),('Edge above4pp','sports_baseline','baseline_edge_gt_0.04'),
        ('Linear market residual','linear_residual','model_edge04'),('Direct Y-q residual','direct_residual','model_edge04'),
        ('Meta confidence55','meta_gate','meta_gt_0.55'),('Edge-based size','sports_baseline','edge_sizing'),
        ('Converging market','sports_baseline','converging_edge'),('Nonlinear residual','nonlinear_residual','model_edge04'),
        ('Without goalie update','linear_without_goalie','model_edge04'),('Cluster cap','sports_baseline','edge_bucket_max2')]
    for sport,h in [('nhl',6),('soccer',1)]:
        for label,model,rule in choices:
            z=a26[a26.sport.eq(sport)&a26.entry_hours.eq(h)&a26.model.eq(model)&a26.rule.eq(rule)]
            if len(z):ablation.append(dict(sport=sport,ablation=label,**z.iloc[0][columns].to_dict()))
    pd.DataFrame(ablation).to_csv(RESULT/'ablation.csv',index=False)
    parts=['# NHL and soccer — US Polymarket research',
        'Completed '+stamp()+'. The numerical target is Sharpe >3 and account return >20%. No strategy has established that target across independent US periods. Soccer has promising numerical hits in a small retrospective sample; NHL does not reach Sharpe3. NBA/MLB app code and retained baselines were preserved.',
        '## Overall stopping criterion',
        'The target applies to the complete chronological account, including losses and idle periods. It is not satisfied by the best month, year, competition or post-warmup segment. In response to the requested overall check, one fixed bridge was tested: use the unchanged existing baseline until the meta-model has enough earlier observations, then use r > 0.55 with the same winner and stake rules. No return-based change of threshold or switching date is allowed. Each of the four original entry horizons is reported below.',
        table(overall[['sport','entry_hours','quoted_games','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),
        'Soccer at one-hour entry: 154 funded bets, return +21.20%, Sharpe 0.98 and maximum drawdown 21.45%. The shorter meta-only segment has 74 bets and Sharpe 3.32, but the full sequence does not meet the target. Soccer is not marked complete. Neither sport has established the requested overall target. The full-sequence bridge is a diagnostic specified after the user clarification, not a previously frozen out-of-sample strategy.',
        'The available US cohort is limited to 2026. We have not established eligible US prices for 2024/25, so those years cannot be represented as tested idle years or replaced with international prices. The report distinguishes full coverage of the available matched cohort from full coverage of the requested 2024-onward period.',
        '## Sources, periods and account definitions',
        'Official US market metadata: gateway.polymarket.us/v1/events; prices: gateway.polymarket.us/v1/price-history. International Polymarket is used only in the explicitly named reference baseline files. Full pagination returned1,093NHL and7,993soccer event records, including competitions outside this study. The frozen matched cohort contains1,016NHL and520soccer games. Quotes for2,576contracts produced2,546,786valid pregame outcome observations. Every normalized price and timestamp replayed exactly against the original response. Existing official league reports supply outcomes, not market-provider scores.',
        'Primary quotes must fall between official T-12h and the entry timestamp, inclusive, and strictly before T. The most recent qualifying observation is selected; no forward quote, interpolation or old carry-in quote is used. A market creation timestamp must precede its price observation.550NHLmarket records were created after their games; their earlier returned histories remain diagnostic evidence only. This is an unresolved import/provenance issue, not proof that the API fabricated prices. Five custom windows were empty; complete-history checks did not recover a point at or before any of the four eligible entry times.',
        'Base models use expanding2021+official history and monthly chronological fits, with saved predictions from2024. The NHL reference has37inputs/C=.02 logistic; soccer has41inputs/C=.02multinomial with corrected source clocks and observed-value/competition preprocessing. All prior scaler, imputer and calibrator restrictions remain intact. Revised models reuse base forecasts fixed byT-12, while market/dated-goalie information may update through their own entry horizon. Thus later entry does not silently use a later final score or actual starter.',
        'Each annual account starts with$2,000. Stake dollars remain fixed to this starting balance; ordinary size is5*max(100*p-51,0). Concurrent requests share available cash; unsettled money is unavailable. Positions carry cost until the official result-availability timestamp. Daily returns include idle UTC days; Sharpe=sqrt(365.25)*mean(daily return)/sample SD.2026coversJanuary1–September29,272calendar days. Actual new US trading coverage begins within2026. No costs are subtracted. Prices are historical book-derived display prices; historical depth/fillability was not established.',
        '2024/2025primary US return/Sharpe are unavailable, not zero-performance years. Sports-model probability evaluations and international reference backtests remain available for those years.2026has already been inspected repeatedly and is retrospective. Matching is conservative: unmatched events, absent saved model forecasts and schedule/identity disagreements are recorded in unmatched.json; this is not a claim to cover every US-listed game.',
        '### US entry coverage',table(coverage),
        '## NHL',
        '### Existing baseline',
        'p=P(home win | earlier sports X)=sigmoid(beta0+beta*X), then historical temperature calibration. Select argmax(p_away,p_home), require selected p>.60 and selected q>.50. Stake5*max(100*p-51,0), hold to result. This rule does not require p>q. The original international-price accounts reproduced exactly:',
        table(refs[refs.sport.eq('nhl')&refs.provider.eq('polymarket_international')&refs.variant.eq('market_agreement')][['year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),
        '### US Polymarket baseline — entry comparison',table(baseline[baseline.sport.eq('nhl')][columns]),
        '### Best defensible interpretation',
        'The unmodified rule is profitable on this US sample, but no tested NHL rule reachesSharpe3. Among variants with at least100bets, the highest retrospective Sharpe usesT-6h and permits at most two qualifying bets per UTC day in each fixed4percentage-point model-edge bucket. This changes concentration, not the chosen team. It is not promoted from its2026ranking. Exact edge is e=p-q_US; fixed bucket=floor(e/.04). First qualifying entries are funded chronologically; stake remains5*max(100*p-51,0).',
        table(nhl_candidate[columns]),
        '### NHL sequential ablations atT-6h',table(pd.DataFrame(ablation)[lambda x:x.sport.eq('nhl')].drop(columns='sport')),
        'The positive-edge filter reduces exposure and drawdown but is not monotonic evidence of calibrated alpha. The negative-edge reference bucket itself was profitable: market agreement sometimes carried information that the sports model underestimated. Edge sizing amplified model errors and drawdowns; it was not a free improvement from assigning more dollars to large disagreement.',
        '## Soccer',
        '### Existing baseline',
        'The original multinomial model predicts away/home/draw probabilities. Its reference buys only the overall argmax when that outcome is home and p>.51, at the same fixed-dollar size. A missing draw quote never changes argmax to a team. International reference reproduction:',
        table(refs[refs.sport.eq('soccer')&refs.provider.eq('polymarket_international')&refs.variant.eq('home_only')][['year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),
        '### US reference — entry comparison',table(baseline[baseline.sport.eq('soccer')][columns]),
        '### Draw model and probability quality',
        'Dixon–Coles uses log(lambda)=league intercept + home effect + scoring-team attack + opponent defence. Penalized Poisson fits use all earlier2021+games, ridge5and365-day half-life weights. A low-score rho is estimated only from earlier out-of-sample rate forecasts, warmed up from2023. The four Dixon–Coles corrections are applied; Skellam sums compute complete home/away/draw probabilities without truncating the score grid. All goals are regulation scores checked against official targets. This is a two-stage regularized Dixon–Coles implementation, not a claim of the original paper’s joint maximum-likelihood fit.',
        table(soccer[['model','year','games','accuracy_pct','draw_recall','draw_precision','predicted_draw_frequency','draw_brier','brier','logloss']]),
        'The75%multinomial/25%Dixon–Coles blend was selected solely on pooled2024/25logloss, before US account results. Draw probability scores improve slightly in earlier periods, but draw argmax recall becomes lower. Better draw Brier is not equivalent to recognizing draws. The blend does not beat the original sports model’s winner-staking return on the US cohort. Paired monthly-block uncertainty:',table(ci),
        '### Promising US candidate — confidence gate',
        'Keep k*=argmax_k p_base,k. Estimate r=P(Y=k* | W) with C=.02logistic trained on earlier settled out-of-sample base forecasts. W contains base confidence, selected US price, p-q, entropy, top-two probability gap, home-pick flag, quote changes/age, earlier Elo/rest/congestion/margin/xG and missing-data indicators. Preprocessing is fitted on earlier data. Monthly second-stage fits require200prior games; the final60are reserved for chronological calibration, and overlapping training labels are purged.',
        'Forecast equation: r=temperature_scale(sigmoid(alpha+beta*W)); edge audit: e=p_base,k*-q_US,k*. TRADE if r>.55 and p_base,k*>.51; this meta-only candidate intentionally does not add a positive-e filter. Stake S=5*max(100*p_base,k*-51,0), limited by cash; entryT-1h. It always buys the original sports model’s selected outcome. The exact coefficients are reproducible from the dated input table and fixed recipe; no2026returns enter fitting.',
        table(soccer_gate[columns]),
        'The one-hour row passes the numerical target with74bets, below the frozen100-bet deployment minimum. It therefore remains a prospective-test candidate. Its average base-model probability is below the purchase price, so its profit is not explained by the original p-q threshold. The meta-model identifies a conditional subset that won more often than either the base confidence or purchase price implied.',
        '### Does the meta gate add to market information?',
        'A separate required attribution control uses only logit(selected US price), the identical chronological training/calibration split and the same thresholds. This is not a new tuned strategy. At one hour andr>.55the price-only control has64bets andSharpe2.84 versus74bets/Sharpe3.32for the full gate. Much of the benefit is market-favourite information; incremental sports alpha is not yet established.',
        table(control[control.year.eq(2026)&control.sport.eq('soccer')&control.rule.eq('meta_gt_0.55')][columns]),table(meta),
        '### Soccer sequential ablations atT-1h',table(pd.DataFrame(ablation)[lambda x:x.sport.eq('soccer')].drop(columns='sport')),
        '## Model-versus-market comparisons',
        'The linear residual uses logit(p_home)=alpha+beta_q*logit(q_home_US)+gamma*X, withC=.02regularization, sports base logit/context and a prior-only temperature calibrator. Soccer uses a softmax with log normalized outcome prices and sports probabilities; a separate version substitutes the earlier-chosen75/25ensemble. Direct residual regression fitsY-q withridge10, then clips/normalizes/calibrates. NHL nonlinear residual isq_home+g(X,q), with a depth2,100-iteration strongly regularized gradient booster and chronological calibration. No hyperparameter search was used.',
        'Purchase prices are never normalized. For proper forecast scores, NHL market-only usesp_home=q_homeandp_away=1-q_home; soccer normalizes the three US ask-derived outcome values to sum1. Raw selected-price calibration remains separately reported. Ask-derived marginal purchase prices need not form a probability vector.',
        table(paired[paired.entry_hours.eq(1)&paired.comparison.isin(['linear_residual','nonlinear_residual','soccer_residual_ensemble'])]),
        '## Entry-time conclusion',
        '**No entry horizon is established as strongest out of sample.** On this retrospective sample, NHL reference/cluster-control results favor6hours; soccer’s unfiltered winner rule favors3hours very slightly, while the full meta gate favors1hour. These are different comparisons, not a universal optimum. Raw quote coverage changes little between6/3/1hours. Later prices, goalie-report availability, and movement may all change; matched-cohort tables prevent treating a change in coverage as model skill. Seeall US rows inus_annual.csvandpaired_model_comparison.csv.',
        '## What created the improvement?',
        '- NHL concentration limits reduced clusters of losses while leaving the sports probabilities unchanged. They did not reach the target.\n- Soccer’s largest improvement came from conditional selection, not a better overall sports classifier or increased leverage. The market-only confidence gate explains a substantial share.\n- Positivep-qdoes not increase profit monotonically across all buckets. Large disagreement can be model error.\n- Dixon–Coles/ensembles offer modest probability-score changes, not stronger draw identification or a proven trading improvement.\n- Edge sizing produced larger concentration/drawdown in losing model regions.\n- Movement, convergence, activity, same-day caps, home-favourite caps and league/signal-bucket concentration are reported separately; no elaborate combined winner was optimized.',
        '## What worked',
        'Exact baseline reproduction; strict US-only quote alignment; chronological meta selection; a modest earlier-period soccer probability ensemble; lower NHL concentration risk. Every test retained the fixed parameter definitions and all losses.',
        '## What failed',
        'No NHL variant achievedSharpe3. No strategy has multi-period US validation. Unconditional positive-edge filters and edge sizing were not reliable across these cohorts. Dixon–Coles did not fix draw recall. Historical US trade counts, traded volume and depth were not supplied by the price-history endpoint. Book spread is evaluated only as an observed state, never deducted as an assumed cost.',
        '## NHL best model',
        'Retain the reproduced sports logistic as the reference. The market-conditioned and goalie/nonlinear alternatives have too little US training/evaluation history to replace it defensibly. Their paired proper scores and model-versus-market controls are inpaired_model_comparison.csv. Dated goalie uncertainty uses previous shot workload and shrunk prior xG-minus-goals ratings, never the actual eventual starter. It is an expected-goalie proxy, not a validated probability distribution of confirmed starters.',
        '## Soccer best model',
        'The75/25ensemble is the earlier-selected probability-score candidate; the existing corrected multinomial plus the confidence gate is the promising betting candidate. They are different results and are not conflated. A numerically higher retrospective return does not select a replacement model.',
        '## Best entry horizon',
        'Proposed prospective comparison: NHL6hours; soccer1hour; retain12/6/3/1paper controls. No single horizon is validated across years.',
        '## Evidence supporting genuine alpha',
        'Source values replay exactly; all features/quotes precede entry; models and calibration only use earlier labels; repeated-calendar/market-only controls are provided. The soccer confidence rule has similar positive results at neighboring horizons, not one isolated threshold. These are supporting checks, not proof of persistence.',
        '## Evidence suggesting overfitting',
        '2026was inspected repeatedly. There is no eligible pre2026UStest period. The full meta gate has74bets at its most promising horizon; multiple fixed ablations were compared. Market-only selection captures much of its gain. Confidence intervals and later validation must dominate the ranking of one historical table.',
        '## Recommended strategy',
        'No new strategy is deployed. Keep the original references. Carry the simple soccer winner/meta55/fixed-dollar rule and the NHL reference into a frozen prospective paper test, with explicit market-only and existing-baseline controls. Do not present the highest2026row as an independently validated optimum.',
        '## Next untouched prospective test',evidence['next_test'],
        '## Complete experiment files and limitations',
        'A:edge_buckets.csv and coarse filters inus_annual.csv. B/C/I:market_model_predictions.parquet,market_fit_audit.csv,paired_model_comparison.csv. D:meta_probability_scores.csv andmeta_market_control_annual.csv. E:edge_sizing_slopes.csv,confidence/edge/100-dollar-cap/0.5and1disagreement-buffer rules inus_annual.csv. The buffer uses two-model dispersion, not a calibrated posterior SD; no confidence-interval claim is attached. F/G:intrawindow anchors,convergence/signed movement inentry_dataset andconditional_diagnostics.csv. H:quote changes/age andhistorical_spread_state.parquet/spread_state_diagnostics.csv. J:dated goalie feature/source times andlinear-with/without-goalie ablation. K:soccer_model_comparison.csv,draw diagnostics/calibration andDixon–Coles fit audit. L:conditional_diagnostics.csv. M:fixed exposure/concentration ablations. All account outputs include bets,prices,probabilities,stakes,outcomes,P&L andcalendar equity.',
        '## Official documentation and research source',
        '\n'.join('- '+u for u in DOCS[:3])+ '\n- https://doi.org/10.1111/1467-9876.00065',
        'SeeREADME.mdfor reproduction commands andcatalog.csvfor output fields/sources. The full requested year/horizon tables are retained even where coverage is zero; missingness is inus_coverage.csvandmissing_columns.csv.']
    text='\n\n'.join(prose(part) if not part.startswith('|') else part for part in parts)+'\n'
    (RESULT/'research_report.md').write_text(text,encoding='utf-8')
    # Export a simple standalone HTML report; no external scripts or data transmission.
    body=render_html(text)
    (RESULT/'research_report.html').write_text('<!doctype html><meta charset="utf-8"><title>US sports market research</title><style>body{font:16px/1.55 system-ui;max-width:1200px;margin:40px auto;padding:20px;color:#15222f}table{border-collapse:collapse;font-size:13px;display:block;overflow:auto}td,th{border:1px solid #cbd5df;padding:7px}th{background:#edf3f8}pre{white-space:pre-wrap}</style>'+body,encoding='utf-8')
    make_catalog()
    print('Research report written',RESULT,flush=True)

def make_catalog():
    descriptions={
        'us_price_points':'Official US pregame long/short display prices; raw request/pointer retained',
        'contracts':'US event/market/side identity matched to official game and saved forecast',
        'entry_dataset':'One game and entry horizon; as-of sports context and strictly prior US quotes',
        'market_model_predictions':'One causal model forecast per game/horizon; second-stage lineage where applicable',
        'us_bets':'Funded simulated positions, source quotes, outcome and cash profit',
        'us_daily':'Calendar-day cash plus open cost and return by independent account',
        'dixon_coles_predictions':'Chronological soccer goal rates, low-score dependence and result probabilities',
        'historical_spread_state':'Same-source longPrice+shortPrice-1, used as a state variable only',
        'meta_market_control_predictions':'Chronological correctness probabilities fitted from US price alone',
        'meta_market_control_bets':'Market-only confidence control positions with original sports winner selection',
        'meta_market_control_daily':'Calendar equity for the price-only confidence controls',
        'overall_sequence_decisions':'One decision for every quoted game; existing baseline before meta readiness, meta gate afterward',
        'overall_sequence_bets':'Positions from the complete available sequence, including the early baseline period',
        'overall_sequence_daily':'Full chronological account equity including early losses and idle days'}
    paths=sorted(RESULT.glob('*.parquet'))+[p for p in sorted(RESULT.glob('*.csv')) if p.stem not in ['catalog','tables','us_bets']]
    formats={p.stem:p for p in paths}
    for path in paths:
        descriptions.setdefault(path.stem,path.stem.replace('_',' ').capitalize()+'; retained research evidence')
    records=[];tables=[]
    for name,desc in descriptions.items():
        p=formats.get(name,RESULT/(name+'.parquet'));f=pd.read_parquet(p) if p.suffix=='.parquet' else pd.read_csv(p)
        tables.append(dict(table=name,file=p.name,rows=len(f),columns=len(f.columns),description=desc))
        for col in f:
            unit='text or category';source='Derived from dated official sports data / causal research pipeline';meaning=col.replace('_',' ')
            if col in ['game_id','official_game_id','teamA','teamB','league','date','start','start_time','target','scoreA','scoreB','available_time','exit']:
                source='Existing official NHL/league soccer reports; games.parquet and retained dated forecasts'
            if col.startswith('q') or col in ['price','timestamp','raw_pointer','raw_field','request_number','source_utc','available_utc','contract_id','market_id','market_created_at','spread_state']:
                source='Official Polymarket US /v1/price-history; /v1/events identity; acquisition.sqlite raw response pointer'
            if re.fullmatch(r'p[012]',col):meaning='Probability of '+{'p0':'Team A / away win','p1':'Team B / home win','p2':'regulation draw (soccer only)'}[col];unit='probability 0–1'
            if col=='probability':meaning='Model probability of the selected argmax outcome';unit='probability 0–1'
            if col=='price':meaning='US price used to purchase one paying-one-dollar outcome share';unit='USD/share'
            if col=='side':meaning='Outcome class:0Team A/away,1Team B/home,2draw for soccer';unit='integer code'
            if col=='target':meaning='Actual official outcome class using the same mapping as side';unit='integer code'
            if col=='edge':meaning='Selected model probability minus actual US purchase price';unit='probability points (decimal)'
            if re.fullmatch(r'q[012]',col):meaning='Latest valid US price of outcome '+col[1]+' at/before entry, inside12hours';unit='USD/share'
            if re.fullmatch(r'q[012]_at\d+',col):meaning='As-of US price for outcome'+col[1]+' at the named pregame hour; null when unavailable or later than entry';unit='USD/share'
            if col.startswith('diagnostic_unverified'):meaning='API-returned price before the metadata creation check; excluded from primary accounts';unit='USD/share'
            if any(t in col for t in ['timestamp','_time','_utc','label_max','training_end','calibration_end']):unit='UTC timestamp'
            if 'hours' in col:unit='hours'
            if 'minutes' in col:unit='minutes'
            if col in ['stake','profit','payout','equity','cash','open_cost','proposed_stake','entry_equity','proposed_dollars']:unit='USD'
            if 'return' in col or col in ['edge','sigma_proxy']:unit='decimal fraction'
            if col.startswith('f_') or col in ['xg_diff','goalie_quality_diff','goalie_uncertainty','lineup_available','feature_missing_fraction']:
                source='Earlier official game/player observations; retained feature matrices; dated NHL reports for goalie update'
                unit='Historical feature units; standardized using training observations only in model'
            records.append(dict(table=name,column=col,dtype=str(f[col].dtype),meaning=meaning,unit=unit,source=source,missing=int(f[col].isna().sum()),rows=len(f),missing_pct=100*float(f[col].isna().mean()) if len(f) else None))
    pd.DataFrame(records).to_csv(RESULT/'catalog.csv',index=False);pd.DataFrame(tables).to_csv(RESULT/'tables.csv',index=False)
    readme='''# US sports market research

Read research_report.html or research_report.md. Full annual/horizon comparisons are in us_annual.csv; original international and Kalshi baselines are isolated in reference_baseline_*.

Run from the historical_expansion project, using final_models/.venv/Scripts/python.exe and scripts under data collecting/nhl_soccer_iteration:

1. us_market_data.py probe, then discover, match, history (each command separately).
2. us_market_research.py baseline.
3. us_soccer_dixon_coles.py.
4. us_market_experiments.py prepare, fit_models, accounts, market_meta_control, overall_sequence (separately).
5. us_research_validation.py raw.
6. us_research_report.py, then us_research_validation.py final.
7. final_pipeline.py cleanup, then us_research_validation.py retain.

Completed baseline/model/account outputs refuse accidental overwrite. Reproduce in a new explicitly named output location by changing the shared RESULT constant; never delete the original baseline artifacts. Requests cache original official responses and audit hashes. Public endpoints used here require no API key; no keys are hard-coded. Price data is US only in revised accounts. No orders are submitted and the NBA/MLB app is unchanged.

Join game_id + entry_hours + model for forecast comparisons; add rule + year for independent simulated accounts. side maps0=away/Team A,1=home/Team B,2=soccer draw. Request IDs join acquisition.sqlite/request_audit. The request_log view exposes only request number, type, purpose and status. Raw paths/hashes are internal evidence. tables.csv describes the data structure; catalog.csv lists fields, units, sources and missing percentages. Not-applicable NHL draw fields are excluded from missing_columns.csv. The current catalog includes all study tables without adding them to the NBA/MLB production database.

All base predictions from2024use prior2021+history. Residual/meta fits additionally require earlier US-price observations, so no simulated US fitting before that evidence exists. 2026is retrospective. Open positions are valued at cost until result availability; historical depth is unavailable, and these are research returns without cost deductions.
'''
    (RESULT/'README.md').write_text(readme,encoding='utf-8')
    catalog=REPORTS/'catalog.md'
    marker='\n## US Polymarket research extension\n'
    addition=marker+'Separate research tables and their complete field/source/missingness catalog: `collected data/result/nhl_soccer_iteration/simulation_results/us_market_revision/catalog.csv`. Structure: `tables.csv`. US prices and original international reference outputs remain distinct. Production NBA/MLB tables are unchanged.\n'
    if catalog.exists():
        text=catalog.read_text(encoding='utf-8')
        if marker not in text:catalog.write_text(text+addition,encoding='utf-8')

if __name__=='__main__':make_report()
