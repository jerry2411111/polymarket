"""Pair the two retained NHL forecasts by verified game ID."""
PRIMARY="granular_regulation_ot"
SECOND="granular_logistic_strong"

def paired_predictions(predictions,label):
    primary=predictions[predictions.variant.eq(PRIMARY)].copy()
    second=predictions[predictions.variant.eq(SECOND)][['game_id','p0','p1']].rename(columns={'p0':'second_p0','p1':'second_p1'})
    result=primary.merge(second,on='game_id',validate='one_to_one')
    assert len(result)==len(primary)
    result['variant']=label
    return result
