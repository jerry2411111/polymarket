"""Reacquire current official team totals for specific detected discrepancies."""
import json
from common import ROOT_OUT,OfficialClient,dump


def main():
    report=json.loads((ROOT_OUT/'pl_lineup_recovery_validation.json').read_bytes())
    tasks={r['game_id']:r['team_source']['url'] for r in report['count_discrepancies']}
    path=ROOT_OUT/'pl_lineup_recovery_team_refresh.json';saved=json.loads(path.read_bytes()) if path.exists() else {}
    client=OfficialClient(4)
    for gid,url in tasks.items():
        body,source=client.get(url,'Reconcile updated player totals with current official team totals: '+gid,'official_statistic_reconciliation',refresh=True)
        assert body is not None,source['return_status'];saved[gid]=source;dump(path,saved)
        print(json.dumps(dict(game_id=gid,status=source['return_status'],request_number=source['request_number'])),flush=True)


if __name__=='__main__':main()
