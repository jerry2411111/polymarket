"""Official UEFA observed match phases, distinct from regulation draws.

Replay already retained responses. Never treat a first-leg aggregate winner
as that game's outcome or a pregame predictor. No match-duration heuristics.
"""
import argparse
import concurrent.futures
import hashlib
import json
import sqlite3
from pathlib import Path
import pandas as pd
from common import ROOT_OUT,PROJECT,PREVIOUS,OfficialClient,dump,stamp,file_sha256,read_db

TABLE='soccer_match_phase_observations'
EXTRA={'EXTRA_TIME_FIRST_HALF','EXTRA_TIME_SECOND_HALF'}
RECOVERY=ROOT_OUT/'retention/soccer_phase_recovery_sources.json'


def raw(source):
    path=Path(source['raw_file'])
    if not path.is_absolute():path=PROJECT/path
    if not path.exists():
        normalized=source['raw_file'].replace('\\','/')
        marker='collected data/'
        if marker in normalized:path=PROJECT/marker/normalized.split(marker,1)[1]
        if not path.exists():
            mapping=json.loads((PROJECT/'final_models/sources/path_map.json').read_bytes())
            mapped=mapping.get(source['raw_file']) or mapping.get(normalized)
            if mapped:path=PROJECT/mapped
    blob=path.read_bytes();assert hashlib.sha256(blob).hexdigest()==source['sha256']
    return json.loads(blob)


def collect():
    frames=[];details={}
    for name,db_file,table in [('uefa_match_statistics_sources','uefa_exposure.sqlite','games'),
                              ('nations_match_statistics_sources','nations_league.sqlite','details')]:
        frames.append(pd.read_parquet(ROOT_OUT/(name+'.parquet')))
        with sqlite3.connect('file:'+str(ROOT_OUT/db_file)+'?mode=ro',uri=True) as db:
            for game_id,body in db.execute('SELECT game_id,body FROM '+table):details[game_id]=json.loads(body)
    sources=pd.concat(frames,ignore_index=True);assert sources.game_id.is_unique
    # Match phase does not require a complete advanced-statistics payload.
    # Recover fixtures omitted by that separate publication using already saved
    # official match metadata, with the same native identity/score/clock checks.
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        fixtures=pd.read_sql_query("SELECT * FROM soccer_games WHERE league='UEFA Champions League' AND date BETWEEN '2021-01-01' AND '2026-09-30'",db)
    supplements=[]
    for game in fixtures[~fixtures.game_id.isin(sources.game_id)].itertuples():
        detail=details.get(game.game_id);assert detail and detail.get('sources',{}).get('match')
        source=detail['sources']['match'];match=raw(source);match=match[0] if isinstance(match,list) else match
        assert str(match['id'])==str(game.official_game_id)
        assert [str(match[k]['id']) for k in ['awayTeam','homeTeam']]==list(map(str,json.loads(game.native_team_ids_json)))
        assert pd.Timestamp(match['kickOffTime']['dateTime'])==pd.Timestamp(game.start_time)
        assert detail['goals_reconcile'] and detail['metadata_regular_score_agrees'] and not detail['issues']
        assert match['score']['regular']==dict(away=game.scoreA,home=game.scoreB)
        public='https://www.uefa.com/uefachampionsleague/match/'+str(game.official_game_id)+'/statistics/'
        proof=dict(native_id_match=True,score_match=True,start_match=True,regulation_scores=match['score']['regular'],
            score_evidence='Native regular-score object independently reconciled by retained full event parser',public_url=public)
        supplements.append(dict(game_id=game.game_id,official_game_id=str(game.official_game_id),date=game.date,
            source_links=json.dumps(dict(match=source)),game_validation=json.dumps(proof),public_url=public))
    if supplements:sources=pd.concat([sources,pd.DataFrame(supplements)],ignore_index=True)
    assert sources.game_id.is_unique
    recovered=json.loads(RECOVERY.read_bytes()) if RECOVERY.exists() else {}
    rows=[];issues=[];raw_count=0;milestone=10;native_matches={};clock_corrections=[]
    for i,r in enumerate(sources.itertuples(),1):
        links=json.loads(r.source_links);source=links['match'];match=raw(source);raw_count+=1
        if isinstance(match,list):assert len(match)==1;match=match[0]
        native_matches[str(match['id'])]=match
        assert str(match['id'])==str(r.official_game_id) and match['status']=='FINISHED'
        assert match['kickOffTime']['date']==r.date
        native=[str(match[k]['id']) for k in ['awayTeam','homeTeam']]
        proof=json.loads(r.game_validation)
        assert proof['native_id_match'] and proof['score_match'] and proof['start_match']
        scores=proof['regulation_scores'];a,b=scores['away'],scores['home']
        type_=match.get('type');round_=match.get('round',{})
        mode=round_.get('mode');events=[];event_sources=[]
        recovery=recovered.get(r.game_id,{})
        event_records=recovery['sources'] if recovery.get('complete_pagination') else details.get(r.game_id,{}).get('sources',{}).get('events',[])
        for s in event_records:
            page=raw(s);assert isinstance(page,list);raw_count+=1
            assert all(str(e['matchId'])==str(r.official_game_id) for e in page)
            events.extend(page);event_sources.append(s)
        # Native scorer phases independently establish extra time even if no
        # event feed was retained; zero extra-time goals alone establish nothing.
        scorer=match.get('playerEvents',{}).get('scorers',[])
        extra_events=[dict(pointer='/events/'+str(j),id=e.get('id'),type=e.get('type'),phase=e.get('phase'))
                      for j,e in enumerate(events) if e.get('phase') in EXTRA]
        extra_scorers=[dict(pointer='/playerEvents/scorers/'+str(j),id=e.get('id'),phase=e.get('phase'))
                       for j,e in enumerate(scorer) if e.get('phase') in EXTRA]
        boundaries=[dict(id=e.get('id'),type=e.get('type'),phase=e.get('phase')) for e in events if e.get('type')=='FULL_TIME']
        reasons={key:value.get('reason') for key,value in match.get('winner',{}).items()}
        own_reason=reasons.get('aggregate') if type_=='SECOND_LEG' else reasons.get('match')
        # Aggregate results shown on a first-leg payload are future relative
        # to that first leg; exclude them from all own-match label decisions.
        future_aggregate=type_=='FIRST_LEG' and 'aggregate' in reasons
        if extra_events or extra_scorers:
            extra=True;basis='Official actual match events/scorers have an extra-time phase'
        elif own_reason=='WIN_ON_EXTRA_TIME':
            extra=True;basis='Official winner reason for this deciding match explicitly says extra time'
        elif ('FIRST_HALF' in {e.get('phase') for e in events} and
              'SECOND_HALF' in {e.get('phase') for e in events} and
              any(e['phase']=='SECOND_HALF' for e in boundaries)):
            extra=False;basis='Official full-time boundary in second half; no extra-time events'
        elif type_=='FIRST_LEG' and round_.get('modeDetail')=='KNOCK_OUT_TWO_LEGS':
            extra=False;basis='Official first leg of a two-leg tie; aggregate future winner ignored'
        elif mode=='GROUP':
            extra=False;basis='Official finished group-stage match; no knockout extra time'
        else:
            extra=None;basis='Requires complete native phase evidence; penalties alone do not prove extra time'
        if type_=='FIRST_LEG':assert extra is not True,'Impossible first-leg extra-time evidence'
        penalty=bool(match['score'].get('penalty'))
        if extra is None:issues.append(dict(game_id=r.game_id,reason=basis))
        final_clock=match.get('fullTimeAt');clock_proof=None
        kickoff=pd.Timestamp(match['kickOffTime']['dateTime'])
        reported=pd.Timestamp(final_clock) if final_clock else pd.NaT
        elapsed=(reported-kickoff).total_seconds()/3600 if pd.notna(reported) else None
        if elapsed is None or not 1<=elapsed<=12:
            # Two historical feeds contain later maintenance FULL_TIME events.
            # Use only a dated end boundary of the actual final playing phase,
            # never a regulation boundary when extra time actually occurred.
            assert extra is not None and not penalty,'Unresolved terminal phase requires official recovery'
            terminal='EXTRA_TIME_SECOND_HALF' if extra else 'SECOND_HALF'
            valid=[e for e in events if e.get('phase')==terminal and e.get('type') in ['FULL_TIME','END_PHASE']
                   and e.get('timestamp') and 1<=(pd.Timestamp(e['timestamp'])-kickoff).total_seconds()/3600<=12]
            assert valid,'No contemporaneous terminal event; do not invent an end clock'
            final_event=max(valid,key=lambda e:pd.Timestamp(e['timestamp']))
            final_clock=final_event['timestamp']
            clock_proof=dict(game_id=r.game_id,raw_fullTimeAt=match.get('fullTimeAt'),
                normalized_end_time=final_clock,event_id=final_event['id'],event_type=final_event['type'],phase=terminal,
                reason='Reported fullTimeAt lies outside the match day; native contemporaneous final-phase end supersedes a later maintenance event.',
                event_sources=event_sources)
            clock_corrections.append(clock_proof)
        league='UEFA Champions League' if str(match['competition']['id'])=='1' else 'UEFA Nations League'
        assert str(match['competition']['id']) in ['1','2014']
        rows.append(dict(game_id=r.game_id,official_game_id=str(r.official_game_id),league=league,date=r.date,
            start_time=match['kickOffTime']['dateTime'],available_time=final_clock,
            teamA_id=native[0],teamB_id=native[1],match_type=type_,round_name=round_.get('metaData',{}).get('name'),
            round_mode=round_.get('modeDetail') or mode,regulation_scoreA=a,regulation_scoreB=b,
            draw_after_90=a==b,went_to_extra_time=extra,penalty_shootout=penalty,
            extra_time_basis=basis,future_aggregate_excluded=future_aggregate,
            source_json=json.dumps(dict(match=source,events=event_sources,public_url=r.public_url,
                regulation_score_proof=proof,extra_events=extra_events,extra_scorers=extra_scorers,
                full_time_boundaries=boundaries,own_match_reason=own_reason,clock_correction=clock_proof),sort_keys=True)))
        if i*100>=milestone*len(sources) or i==len(sources):
            print(json.dumps(dict(stage='soccer_phase_raw_replay',complete=i,total=len(sources),percent=round(i*100/len(sources),1))),flush=True)
            milestone+=10
    # An isolated native event may have an incorrect phase. Reconcile positive
    # second-leg labels against independently validated regulation scores of
    # BOTH games, the current score total and the official aggregate reason.
    # No eventual aggregate information is used as a forecast feature.
    by_native={r['official_game_id']:r for r in rows};phase_corrections=[]
    for row in rows:
        if row['match_type']!='SECOND_LEG' or row['went_to_extra_time'] is not True:continue
        m=native_matches[row['official_game_id']]
        ids=[str(x['id']) for x in m.get('relatedMatches',[]) if x.get('type')=='FIRST_LEG']
        assert len(ids)==1 and ids[0] in by_native
        prior=by_native[ids[0]]
        assert prior['teamA_id']==row['teamB_id'] and prior['teamB_id']==row['teamA_id']
        aggregate={'away':int(prior['regulation_scoreB'])+int(row['regulation_scoreA']),
                   'home':int(prior['regulation_scoreA'])+int(row['regulation_scoreB'])}
        if aggregate['away']==aggregate['home']:continue
        evidence=json.loads(row['source_json'])
        assert (evidence['own_match_reason']=='WIN_ON_AGGREGATE' and
                aggregate==m['score']['aggregate'] and m['score']['total']==m['score']['regular'] and
                m['score']['regular']=={'away':row['regulation_scoreA'],'home':row['regulation_scoreB']}), 'Conflicting extra-time label needs further official recovery'
        correction=dict(game_id=row['game_id'],first_leg_game_id=prior['game_id'],
            validated_regulation_aggregate=aggregate,reason='Unequal regulation aggregate, unchanged regulation/total score and official WIN_ON_AGGREGATE disagree with stray extra-time phase tags.',
            first_leg_score_proof=json.loads(prior['source_json'])['regulation_score_proof'])
        evidence['phase_correction']=correction
        row['went_to_extra_time']=False;row['extra_time_basis']='Official scores of both legs plus own-match aggregate winner reconcile erroneous native extra-time phase tags'
        row['source_json']=json.dumps(evidence,sort_keys=True);phase_corrections.append(correction)
    frame=pd.DataFrame(rows)
    for name in ['draw_after_90','went_to_extra_time','penalty_shootout','future_aggregate_excluded']:frame[name]=frame[name].astype('boolean')
    assert frame.game_id.is_unique
    assert frame.loc[frame.match_type.eq('FIRST_LEG'),'went_to_extra_time'].eq(False).all()
    assert frame.start_time.notna().all()
    report=dict(at_utc=stamp(),status='PASS',rows=len(frame),raw_responses_replayed=raw_count,
        extra_time_true=int(frame.went_to_extra_time.sum()),extra_time_false=int(frame.went_to_extra_time.eq(False).sum()),
        extra_time_unresolved=int(frame.went_to_extra_time.isna().sum()),
        future_first_leg_aggregate_excluded=int(frame.future_aggregate_excluded.sum()),
        source_regulation_draws=int(frame.draw_after_90.sum()),extra_time_without_regulation_draw=int((frame.went_to_extra_time&~frame.draw_after_90).sum()),
        issues=issues,phase_corrections=phase_corrections,clock_corrections=clock_corrections,
        metadata_only_recovered_games=[x['game_id'] for x in supplements],raw_replay_network_requests=0,used_as_predictors=False)
    publish(frame)
    report['output_sha256']=file_sha256(ROOT_OUT/(TABLE+'.parquet'))
    dump(ROOT_OUT/'retention/soccer_match_phases_validation.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='issues'}),flush=True)


def recover(limit=None):
    """Recover native event feeds only for unresolved phase labels."""
    frame=pd.read_parquet(ROOT_OUT/(TABLE+'.parquet'))
    pending=frame[frame.went_to_extra_time.isna()]
    if limit is not None:pending=pending.head(limit)
    client=OfficialClient(per_second=2)
    with sqlite3.connect(ROOT_OUT/'acquisition.sqlite') as db:
        request_start=db.execute('SELECT COALESCE(MAX(request_number),0) FROM request_audit').fetchone()[0]
    recovered=json.loads(RECOVERY.read_bytes()) if RECOVERY.exists() else {}
    def one(game):
        sources=[];seen=set()
        for offset in range(0,10000,500):
            url='https://match.uefa.com/v5/matches/'+game.official_game_id+'/events?filter=ALL&limit=500&offset='+str(offset)+'&order=ASC'
            data,source=client.get(url,'Verify actual extra-time phase for '+game.game_id,'official_match_phase_recovery')
            if not isinstance(data,list):return game.game_id,dict(error='Official event response requires retry',sources=sources+[source])
            assert all(str(e.get('matchId'))==game.official_game_id for e in data)
            ids={str(e['id']) for e in data};assert not seen.intersection(ids),'Overlapping native event pages'
            seen.update(ids);sources.append(source)
            if len(data)<500:return game.game_id,dict(at_utc=stamp(),sources=sources,native_events=len(seen),complete_pagination=True)
        raise AssertionError('Unexhausted event pagination')
    milestone=10
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for i,(game_id,record) in enumerate(pool.map(one,pending.itertuples()),1):
            recovered[game_id]=record;dump(RECOVERY,recovered)
            if i*100>=milestone*len(pending) or i==len(pending):
                print(json.dumps(dict(stage='soccer_phase_recovery',complete=i,total=len(pending),percent=round(i*100/len(pending),1))),flush=True)
                milestone+=10
    with sqlite3.connect(ROOT_OUT/'acquisition.sqlite') as db:
        statuses=dict(db.execute('SELECT return_status,COUNT(*) FROM request_audit WHERE request_number>? AND request_type=? GROUP BY return_status',(request_start,'official_match_phase_recovery')))
    receipt=dict(at_utc=stamp(),games_attempted=len(pending),requests_made=sum(statuses.values()),return_statuses=statuses,
        raw_first=True,complete_event_responses=sum(bool(v.get('complete_pagination')) for v in recovered.values()))
    dump(ROOT_OUT/'retention/soccer_phase_recovery_validation.json',receipt)
    print(json.dumps(receipt),flush=True)
    return recovered


def publish(frame):
    meanings={
      'game_id':('Canonical collected fixture ID','identifier'),'official_game_id':('UEFA native fixture ID','identifier'),
      'league':('Actual UEFA competition','text'),'date':('Official fixture calendar date','YYYY-MM-DD'),
      'start_time':('Official kickoff','UTC timestamp'),'available_time':('Official final-whistle clock, or contemporaneous final-phase end event when the reported clock is invalid; correction and raw clock preserved in source_json','UTC timestamp'),
      'teamA_id':('Native away team ID','identifier'),'teamB_id':('Native home team ID','identifier'),
      'match_type':('Official SINGLE, FIRST_LEG or SECOND_LEG classification','category'),
      'round_name':('Official competition round','text'),'round_mode':('Official group or knockout leg format','category'),
      'regulation_scoreA':('Previously validated away goals through 90 minutes plus stoppage','goals'),
      'regulation_scoreB':('Previously validated home goals through 90 minutes plus stoppage','goals'),
      'draw_after_90':('Verified regulation scores are equal; not equivalent to extra time','boolean'),
      'went_to_extra_time':('Actual extra-time occurrence, verified by own-match phase or winner evidence; unknown remains null','nullable boolean'),
      'penalty_shootout':('Finished official match score contains a penalty shoot-out result','boolean'),
      'extra_time_basis':('Exact reason the observed extra-time label is known or unresolved','text'),
      'future_aggregate_excluded':('First-leg payload includes the eventual aggregate winner; excluded from own-match label logic and prohibited as a predictor','boolean'),
      'source_json':('Raw source URLs/paths/hashes, official regulation score proof and phase event evidence; target evidence only','JSON')}
    origin='Official UEFA match/phase APIs, immutable raw responses and previously reconciled official regulation scores. First-leg aggregate winners never supply a predictor or own-match label. Current IFAB Law10 and UEFA Champions League Article21 define draw versus extra time; historical occurrence uses actual native phase evidence.'
    assert set(frame)==set(meanings)
    frame.to_parquet(ROOT_OUT/(TABLE+'.parquet'),index=False);frame.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        frame.to_sql(TABLE,db,if_exists='replace',index=False)
        db.execute('CREATE UNIQUE INDEX '+TABLE+'_game ON '+TABLE+'(game_id)')
        for name in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+name+' WHERE "table"=?',(TABLE,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(TABLE,len(frame),len(frame.columns)))
        for c in frame:
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(TABLE,c,*meanings[c],origin))
            n=int(frame[c].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(TABLE,c,len(frame),n,100*n/len(frame)))
        db.commit();assert db.execute('SELECT COUNT(*) FROM '+TABLE).fetchone()[0]==len(frame)
    from publish import main
    main()


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--recover',action='store_true');parser.add_argument('--limit',type=int)
    args=parser.parse_args()
    if args.recover:recover(args.limit)
    collect()
