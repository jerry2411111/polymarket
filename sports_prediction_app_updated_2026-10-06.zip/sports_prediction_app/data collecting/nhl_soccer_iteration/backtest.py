"""Provider-separated, annual cash accounting and time/identity-checked prices."""
import collections
import heapq
import json
import math
import sqlite3
import numpy as np
import pandas as pd
from common import PROJECT,PREVIOUS,OUT,ROOT_OUT,read_db,dump

END=pd.Timestamp('2026-09-30',tz='UTC')

def quote_inputs(audit_path=None,revision='original'):
    """Original reproduces frozen studies; new research uses closest_v62."""
    assert revision in ['original','closest_v62']
    with read_db(PROJECT/'collected data/result/player_depth.sqlite') as db:
        games=pd.read_sql_query("SELECT game_id,sport,league,official_game_id,native_team_ids_json,target FROM games WHERE sport IN ('nhl','soccer')",db)
        parts=[]
        for provider in ['polymarket','kalshi']:
            q=pd.read_sql_query('SELECT * FROM '+provider+'_quotes WHERE hours_before=12',db)
            q=q.merge(games,on='game_id',validate='many_to_one');q['provider']=provider;parts.append(q)
    q=pd.concat(parts,ignore_index=True)
    q['entry_available_utc']=pd.to_datetime(q.entry_available_utc,utc=True,format='mixed')
    q['entry_source_utc']=pd.to_datetime(q.entry_source_utc,utc=True,format='mixed')
    q['decision_utc']=pd.to_datetime(q.decision_utc,utc=True,format='mixed')
    q['official_game_id']=q.official_game_id.astype(str)
    q['year']=q.decision_utc.dt.year
    if revision=='closest_v62':
        from validate_hourly_prices import overlay
        updates=[]
        for year in [2024,2025,2026]:
            folder=ROOT_OUT/'closest_observations_v62'/str(year)
            assert json.loads((folder/'validation.json').read_bytes())['status']=='PASS'
            updates.append(pd.read_parquet(folder/'quotes.parquet'))
        q=overlay(q,pd.concat(updates,ignore_index=True))
    quality=[]
    for (sport,provider,year),f in q.groupby(['sport','provider','year']):
        quality.append(dict(sport=sport,provider=provider,year=int(year),rows=len(f),games=f.game_id.nunique(),quotes_older_than_24h=int((f.entry_age_hours>24).sum()),quotes_older_than_24h_pct=100*(f.entry_age_hours>24).mean(),max_age_hours=float(f.entry_age_hours.max()),price_basis=sorted(f.price_basis.dropna().unique().tolist())))
    dump(audit_path or OUT/'quote_quality.json',quality)
    return q

def attach(predictions,quotes):
    metadata=[]
    for sport in ['nhl','soccer']:
        with read_db(PREVIOUS/'expanded.sqlite') as db:
            g=pd.read_sql_query(f'SELECT game_id,native_team_ids_json,scoreA,scoreB FROM {sport}_games',db)
            metadata.append(g)
    g=pd.concat(metadata).drop_duplicates('game_id')
    p=predictions.merge(g,on='game_id',validate='many_to_one')
    p['official_game_id']=p.official_game_id.astype(str)
    join=['sport','league','official_game_id']+(['provider'] if 'provider' in p else [])
    f=p.merge(quotes,on=join,suffixes=('','_quote'),validate='many_to_many')
    def orientation(r):
        a,b=json.loads(r.native_team_ids_json),json.loads(r.native_team_ids_json_quote)
        a,b=list(map(str,a)),list(map(str,b))
        if a==b:return False
        if a==b[::-1]:return True
        raise ValueError('Unmatched official team IDs: '+r.game_id)
    swap=f.apply(orientation,axis=1)
    f['quote_class']=f.class_index.astype(int)
    f.loc[swap&f.quote_class.isin([0,1]),'quote_class']=1-f.loc[swap&f.quote_class.isin([0,1]),'quote_class']
    official_quote_target=f.target_quote.copy()
    official_quote_target.loc[swap&official_quote_target.isin([0,1])]=1-official_quote_target.loc[swap&official_quote_target.isin([0,1])]
    f['result_agrees']=f.target.eq(official_quote_target)
    f['causal_quote']=f.entry_available_utc.le(f.prediction_time)&f.entry_source_utc.le(f.prediction_time)
    f['target_time_agrees']=f.decision_utc.eq(f.prediction_time)
    f['usable_price']=f.entry_price.gt(0)&f.entry_price.lt(1)&f.result_agrees&f.causal_quote&f.target_time_agrees
    audit=dict(rows=len(f),reoriented_rows=int(swap.sum()),result_conflicts=int((~f.result_agrees).sum()),future_quote_rows=int((~f.causal_quote).sum()),target_time_conflicts=int((~f.target_time_agrees).sum()))
    return f,audit

def select(frame,rule='edge_winner',fresh=True):
    f=frame[frame.usable_price].copy()
    if fresh:f=f[f.entry_age_hours<=24]
    f['probability']=[r['p'+str(int(r['quote_class']))] for r in f.to_dict('records')]
    # Missing draw quotes do not turn a three-outcome game into a two-outcome one.
    f['pick']=[int(np.argmax([r['p0'],r['p1']]+([r['p2']] if r['sport']=='soccer' else []))) for r in f.to_dict('records')]
    if rule=='market_favourite':
        f=f.sort_values(['game_id','entry_price'],ascending=[True,False]).drop_duplicates('game_id')
    elif rule=='winner':f=f[f.quote_class.eq(f.pick)]
    elif rule=='edge_winner':f=f[f.quote_class.eq(f.pick)&(f.probability-f.entry_price>=.05)]
    elif rule=='edge_any':f=f[f.probability-f.entry_price>=.05]
    elif rule=='expected_profit':f=f[f.probability/f.entry_price>=1.10]
    elif rule=='expected_profit_winner':f=f[f.quote_class.eq(f.pick)&(f.probability/f.entry_price>=1.10)]
    elif rule=='expected_profit_consensus':
        favourite=f.sort_values('entry_price',ascending=False).drop_duplicates('game_id').set_index('game_id').quote_class
        f=f[f.quote_class.eq(f.pick)&f.quote_class.eq(f.game_id.map(favourite))&(f.probability/f.entry_price>=1.10)]
    elif rule=='consensus_value':
        favourite=f.sort_values('entry_price',ascending=False).drop_duplicates('game_id').set_index('game_id').quote_class
        f=f[f.quote_class.eq(f.pick)&f.quote_class.eq(f.game_id.map(favourite))&(f.probability-f.entry_price>=.05)]
    else:raise ValueError(rule)
    assert not f.duplicated(['game_id','quote_class']).any()
    return f

def simulate(f,year,stake_fraction=.01,sizing='fixed'):
    start=pd.Timestamp(f'{year}-01-01',tz='UTC');end=min(pd.Timestamp(f'{year+1}-01-01',tz='UTC'),END)
    f=f[f.prediction_time.ge(start)&f.prediction_time.lt(end)].copy()
    assert f.available_time.gt(f.prediction_time).all()
    times=collections.defaultdict(list)
    for r in f.to_dict('records'):times[r['prediction_time']].append(r)
    # Include daily closing checkpoints; funds settle only at recorded availability.
    for at in pd.date_range(start+pd.Timedelta(days=1),end,freq='D'):times[at]
    cash=10000.;opened=0.;pending=[];serial=0;trades=[];curves=[];peak=10000.;dd=0.;capacity_count=0
    for at,rows in sorted(times.items()):
        while pending and pending[0][0]<=at:
            _,_,cost,payout=heapq.heappop(pending);opened-=cost;cash+=payout
        nav=cash+opened
        if rows:
            assert all(r['entry_available_utc']<=at and r['entry_source_utc']<=at for r in rows)
            if sizing=='fixed':wanted=[stake_fraction*nav]*len(rows)
            elif sizing=='equal_payout':wanted=[2*stake_fraction*nav*r['entry_price'] for r in rows]
            elif sizing=='probability_weighted':wanted=[2*stake_fraction*nav*r['probability'] for r in rows]
            elif sizing=='capped_equal_risk':
                # A unit stake pays Y/price - 1, with model-estimated standard
                # deviation sqrt(p*(1-p))/price. Do not increase any position
                # above the baseline stake to achieve the risk budget.
                assert all(0<=r['probability']<=1 and 0<r['entry_price']<1 for r in rows)
                wanted=[stake_fraction*nav*min(1.,r['entry_price']/math.sqrt(max(1e-12,r['probability']*(1-r['probability'])))) for r in rows]
            elif sizing=='probability_split':
                bygame=collections.defaultdict(list)
                for r in rows:bygame[r['game_id']].append(r)
                for group in bygame.values():assert abs(sum(r['probability'] for r in group)-1)<1e-8
                wanted=[stake_fraction*nav*r['probability'] for r in rows]
            elif sizing=='quarter_kelly':wanted=[nav*min(.125,max(0,.25*(r['probability']-r['entry_price'])/(1-r['entry_price']))) for r in rows]
            elif sizing=='margin_quarter_kelly':
                # Separate sizing input; never overwrite the model probability.
                assert all(0<=r['sizing_probability']<=1 for r in rows)
                wanted=[nav*min(stake_fraction,max(0,.25*(r['sizing_probability']-r['entry_price'])/(1-r['entry_price']))) for r in rows]
            else:raise ValueError(sizing)
            room=max(0,min(cash,.20*nav-opened));scale=min(1,room/sum(wanted)) if sum(wanted)>0 else 0
            if scale<1:capacity_count+=1
            for r,want in zip(rows,wanted):
                cost=want*scale
                if cost<=1e-8:continue
                win=r['quote_class']==r['target']
                # Optional predeclared exit study supplies its observed payout
                # per share; ordinary win/lose settlement remains unchanged.
                payout_per_share=r.get('payout_per_share',float(win))
                assert 0<=payout_per_share<=1
                payout=cost/r['entry_price']*payout_per_share
                cash-=cost;opened+=cost;serial+=1;heapq.heappush(pending,(r['available_time'],serial,cost,payout))
                trades.append(dict(game_id=r['game_id'],decision_time=at,settlement_time=r['available_time'],class_index=r['quote_class'],probability=r['probability'],price=r['entry_price'],quote_source_utc=r['entry_source_utc'],quote_available_utc=r['entry_available_utc'],quote_age_hours=r['entry_age_hours'],stake=cost,payout=payout,won=win,unit_return=payout_per_share/r['entry_price']-1,price_basis=r['price_basis'],exit_basis=r.get('exit_basis','official_result_settlement')))
        nav=cash+opened;peak=max(peak,nav);dd=max(dd,1-nav/peak)
        assert cash>=-1e-6 and opened>=-1e-6
        if at.hour==0 and at.minute==0 and at>start:curves.append(dict(date=(at-pd.Timedelta(days=1)).date().isoformat(),nav=nav,cash=cash,open_cost=opened))
    curve=pd.DataFrame(curves);returns=curve.nav.div(curve.nav.shift(1,fill_value=10000))-1
    sd=returns.std(ddof=1);sharpe=math.sqrt(365.25)*returns.mean()/sd if sd>0 else None
    summary=dict(year=year,bets=len(trades),games=len({r['game_id'] for r in trades}),win_rate_pct=100*np.mean([r['won'] for r in trades]) if trades else None,return_pct=100*(float(curve.nav.iloc[-1])/10000-1),sharpe=sharpe,max_drawdown_pct=100*dd,average_bet_return_pct=100*np.mean([r['unit_return'] for r in trades]) if trades else None,daily_observations=len(returns),active_days=int((returns.abs()>1e-12).sum()),unsettled_positions=len(pending),capacity_scaling_batches=capacity_count)
    return summary,pd.DataFrame(trades),curve

def evaluate(predictions,prefix,variants=('edge_winner',),years=(2024,2025,2026),quote_revision='original'):
    q=quote_inputs(OUT/(prefix+'_quote_quality.json'),revision=quote_revision);f,audit=attach(predictions,q);dump(OUT/(prefix+'_matching_audit.json'),audit|dict(quote_revision=quote_revision))
    summaries=[];trades=[];curves=[]
    for (sport,learner,variant,provider),part in f.groupby(['sport','learner','variant','provider']):
        for rule in variants:
            chosen=select(part,rule)
            for year in years:
                s,t,c=simulate(chosen,year);meta=dict(sport=sport,learner=learner,variant=variant,provider=provider,rule=rule)
                summaries.append(meta|s)
                if not t.empty:trades.append(t.assign(**meta,year=year))
                curves.append(c.assign(**meta,year=year))
    pd.DataFrame(summaries).to_csv(OUT/(prefix+'_annual.csv'),index=False)
    if trades:pd.concat(trades,ignore_index=True).to_parquet(OUT/(prefix+'_bets.parquet'),index=False)
    pd.concat(curves,ignore_index=True).to_parquet(OUT/(prefix+'_daily.parquet'),index=False)
    return pd.DataFrame(summaries)

if __name__=='__main__':
    p=pd.read_parquet(PREVIOUS/'predictions.parquet')
    result=evaluate(p,'preserved_baselines',('edge_winner','winner','market_favourite'))
    print(result[(result.year==2026)&(result.provider=='polymarket')&result.rule.eq('edge_winner')].to_string(index=False))
