"""Separate observed regulation goals with/without a defending goalkeeper.

These are training-label diagnostics, not features known before that game.
Winner and overtime labels always remain the actual official result.
"""
import argparse,hashlib,json,pickle,shutil,sqlite3
import numpy as np
import pandas as pd
from common import ROOT_OUT,PROJECT,read_db,dump,stamp,file_sha256
from final_pipeline import discard_work

RESULT=ROOT_OUT/'simulation_results/nhl_goal_target_diagnosis'
TABLE='nhl_regulation_goal_statistics'


def build():
    f=pd.read_parquet(ROOT_OUT/'retained_models/nhl/nhl_features.parquet')
    s=pd.read_parquet(ROOT_OUT/'nhl_shot_detail.parquet',columns=['game_id','side','event_id','period','period_type','goal','defending_goalie_present','source_raw_file','source_sha256'])
    groups=dict(tuple(s[s.game_id.isin(f.game_id)].groupby('game_id')))
    rows=[];sources=0;checked=0
    for number,g in enumerate(f.to_dict('records'),1):
        group=groups[g['game_id']];refs=group[['source_raw_file','source_sha256']].drop_duplicates();assert len(refs)==1
        ref=refs.iloc[0];path=PROJECT/ref.source_raw_file
        blob=path.read_bytes();assert hashlib.sha256(blob).hexdigest()==ref.source_sha256
        raw=json.loads(blob);sources+=1
        assert str(raw['id'])==str(g['official_game_id'])
        counts={'A':[0,0],'B':[0,0]};events=[]
        goal_events=group[group.goal.eq(1)&group.period.le(3)&group.period_type.eq('REG')].set_index('event_id')
        for i,event in enumerate(raw['plays']):
            if event['typeDescKey']!='goal' or event['periodDescriptor']['periodType']!='REG' or event['periodDescriptor']['number']>3:continue
            owner=event['details']['eventOwnerTeamId'];side='A' if owner==raw['awayTeam']['id'] else 'B'
            assert owner in [raw['awayTeam']['id'],raw['homeTeam']['id']]
            situation=str(event['situationCode']);assert len(situation)==4 and situation[0] in '01' and situation[3] in '01'
            present=int(situation[3 if side=='A' else 0])
            row=goal_events.loc[event['eventId']];assert row.side==side and row.defending_goalie_present==present
            counts[side][0]+=1;counts[side][1]+=1-present;checked+=1
            if not present:events.append(dict(event_id=event['eventId'],pointer='/plays/'+str(i),side=side,situation_code=situation))
        for side in ['A','B']:
            total,empty=counts[side];assert total==g['regulation_score'+side]
            rows.append(dict(game_id=g['game_id'],official_game_id=str(g['official_game_id']),date=g['date'],side=side,
                available_at_utc=str(g['available_time']),regulation_goals=total,empty_net_goals=empty,
                nonempty_regulation_goals=total-empty,source_raw_file=ref.source_raw_file,source_sha256=ref.source_sha256,
                empty_net_events_json=json.dumps([e for e in events if e['side']==side],sort_keys=True)))
        if number%max(1,len(f)//10)==0 or number==len(f):
            print(json.dumps(dict(stage='native_goal_source_replay',games=number,total=len(f),percent=round(100*number/len(f),1))),flush=True)
    frame=pd.DataFrame(rows);assert not frame.duplicated(['game_id','side']).any()
    target=ROOT_OUT/(TABLE+'.parquet');frame.to_parquet(target,index=False);frame.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    meanings={
        'game_id':('Canonical game identifier','identifier'), 'official_game_id':('Native NHL game identifier','identifier'),
        'date':('Official game date','YYYY-MM-DD'), 'side':('A is away, B is home','A/B'),
        'available_at_utc':('Conservative historical label availability; not a contemporaneous retrieval archive','UTC timestamp'),
        'regulation_goals':('Official goals through regulation, excluding overtime and shootout','goals'),
        'empty_net_goals':('Regulation goals with defending goalkeeper absent in official situation code','goals'),
        'nonempty_regulation_goals':('Regulation goals less verified empty-net goals; a research training target, never the official winner label','goals'),
        'source_raw_file':('Original official play-by-play response','path'), 'source_sha256':('Original response content hash','SHA-256'),
        'empty_net_events_json':('Native event IDs, pointers and situation codes supporting the subtraction','JSON array')}
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        frame.to_sql(TABLE,db,if_exists='replace',index=False)
        for cat in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+cat+' WHERE "table"=?',[TABLE])
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',[TABLE,len(frame),len(frame.columns)])
        for field,(meaning,unit) in meanings.items():
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',[TABLE,field,meaning,unit,'Official NHL play-by-play API; full raw replay and reconciliation to retained official regulation scores.'])
            missing=int(frame[field].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',[TABLE,field,len(frame),missing,100*missing/len(frame)])
    RESULT.mkdir(exist_ok=True)
    validation=dict(at_utc=stamp(),status='PASS',rows=len(frame),games=len(f),raw_responses=sources,raw_goal_events_replayed=checked,
                    source_sha256=file_sha256(target),all_regulation_scores_reconciled=True,official_winner_labels_unchanged=True,
                    field_role='Historical training targets only; current-game values are never predictors.')
    dump(RESULT/'label_validation.json',validation);print(json.dumps(validation),flush=True)
    return f,frame


def evaluate():
    import models
    from backtest import quote_inputs,attach,select,simulate
    from cash_validation import validate_cash
    work=ROOT_OUT/'_work/nhl_nonempty_targets';assert not work.exists();work.mkdir(parents=True)
    try:
        validation=json.loads((RESULT/'label_validation.json').read_bytes());assert validation['status']=='PASS'
        path=ROOT_OUT/(TABLE+'.parquet');assert file_sha256(path)==validation['source_sha256']
        labels=pd.read_parquet(path).pivot(index='game_id',columns='side',values='nonempty_regulation_goals')
        f=pd.read_parquet(ROOT_OUT/'retained_models/nhl/nhl_features.parquet')
        for side in ['A','B']:f['nonempty_regulation_score'+side]=f.game_id.map(labels[side])
        assert f[['nonempty_regulation_scoreA','nonempty_regulation_scoreB']].notna().all().all()
        f.to_parquet(work/'nhl_features.parquet',index=False)
        name='nonempty_regulation_ot';spec=models.CANDIDATES['granular_regulation_ot']|dict(score_targets=['nonempty_regulation_scoreA','nonempty_regulation_scoreB'])
        models.CANDIDATES[name]=spec;models.OUT=work
        plan=dict(at_utc=stamp(),hypothesis='Late empty-net goals may distort independent scoring-rate estimates. Change only Poisson goal-count training targets; preserve actual winner and actual overtime labels.',
            spec=spec,history='2021 onward; monthly expanding predictions from2024; earlier purged180day calibration to actual official winners.',
            control='Exact retained primary regulation/OT forecasts and unchanged retained logistic secondary. Same feature columns, preprocessing and regularization.',
            gate='Lower pooled2024/25 primary logloss AND higher weaker-year Polymarket Sharpe, >=30bets eachyear. No2026candidate unless passed.',
            bets='Unchanged both-model p/price>=1.10;closest_v62 pre12;1%NAV;20%open-cost cap;official settlement;providers separate;no costs.',
            caveat='Subtracting goals is not a replacement outcome label. Final-result calibration must absorb the approximation;2026 is repeatedly researched retrospective evaluation.')
        dump(RESULT/'experiment_plan.json',plan)
        predictions=models.run('nhl','development',[name]);predictions['variant']='candidate'
        baseline=pd.read_parquet(ROOT_OUT/'retained_models/nhl/development_predictions.parquet')
        control=baseline[baseline.variant.eq('granular_regulation_ot')].copy();control['variant']='retained'
        p=pd.concat([predictions,control],ignore_index=True)
        secondary=baseline[baseline.variant.eq('granular_logistic_strong')][['game_id','p0','p1']].rename(columns={'p0':'second_p0','p1':'second_p1'})
        assert predictions.game_id.tolist()==control.game_id.tolist()
        m=models.metrics(p);m.to_csv(RESULT/'development_metrics.csv',index=False)
        p=p.merge(secondary,on='game_id',validate='many_to_one');p.to_parquet(RESULT/'development_predictions.parquet',index=False)
        quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62');joined,audit=attach(p,quotes);dump(RESULT/'matching.json',audit)
        annual=[];trades=[];curves=[]
        for (provider,variant),group in joined.groupby(['provider','variant']):
            chosen=select(group,'expected_profit');second=np.where(chosen.quote_class.eq(0),chosen.second_p0,chosen.second_p1)
            chosen=chosen[second/chosen.entry_price>=1.10].copy()
            for year in [2024,2025]:
                summary,t,c=simulate(chosen,year);meta=dict(sport='nhl',provider=provider,variant=variant,recipe='fixed',year=year)
                annual.append(meta|summary)
                if len(t):trades.append(t.assign(**meta))
                curves.append(c.assign(**meta))
        a=pd.DataFrame(annual);t=pd.concat(trades,ignore_index=True);c=pd.concat(curves,ignore_index=True)
        cash=validate_cash(t,c);a.to_csv(RESULT/'development_annual.csv',index=False);t.to_parquet(RESULT/'development_bets.parquet',index=False);c.to_parquet(RESULT/'development_daily.parquet',index=False)
        scores={}
        for variant,group in m.groupby('variant'):
            account=a[a.variant.eq(variant)&a.provider.eq('polymarket')]
            scores[variant]=dict(logloss=float(np.average(group.log_loss,weights=group.games)),minimum_sharpe=float(account.sharpe.min()),minimum_bets=int(account.bets.min()))
        candidate,old=scores['candidate'],scores['retained']
        passed=candidate['logloss']<old['logloss'] and candidate['minimum_sharpe']>old['minimum_sharpe'] and candidate['minimum_bets']>=30
        fitted=pickle.loads((work/'model_runs/nhl/development'/ (name+'.pkl')).read_bytes())
        data=pd.concat([f,pd.get_dummies(f.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
        sample=predictions[predictions.fold.eq(fitted['boundary'].strftime('%Y-%m'))].head(20)
        x=data.loc[sample.game_id,fitted['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
        assert np.allclose(models.apply_calibration(fitted['model'].predict_proba(x),fitted['calibrator']),sample[['p0','p1']],rtol=0,atol=1e-12)
        assert predictions.train_label_max.lt(predictions.prediction_time).all()
        result=dict(at_utc=stamp(),status='PASS',development_gate_passed=bool(passed),comparison=scores,forecast_replays=len(sample),cash_days=cash,
                    forecasts=len(predictions),evaluated2026=False,next_action='Evaluate fixed2026candidate' if passed else 'Reject this goal-target change; retain baseline',adopted=False)
        dump(RESULT/'validation.json',result);print(json.dumps(result),flush=True);print(a.to_string(index=False),flush=True)
        decisions_path=ROOT_OUT/'simulation_results/experiment_decisions.json';decisions=json.loads(decisions_path.read_bytes())
        for file in ['experiment_plan.json','label_validation.json','validation.json']:decisions['nhl_goal_target_diagnosis/'+file]=json.loads((RESULT/file).read_bytes())
        dump(decisions_path,decisions)
        ledger_path=ROOT_OUT/'simulation_results/experiment_results.csv';ledger=pd.read_csv(ledger_path,low_memory=False)
        for file in ['development_annual.csv','development_metrics.csv']:
            key='nhl_goal_target_diagnosis/'+file;ledger=ledger[~ledger.source_result_file.eq(key)]
            ledger=pd.concat([ledger,pd.read_csv(RESULT/file).assign(source_result_file=key)],ignore_index=True)
        ledger.to_csv(ledger_path,index=False)
    finally:
        if work.exists():discard_work(work)


def verify():
    import models
    from threadpoolctl import threadpool_limits
    plan=json.loads((RESULT/'experiment_plan.json').read_bytes());spec=plan['spec']
    frame=pd.read_parquet(ROOT_OUT/'retained_models/nhl/nhl_features.parquet')
    goals=pd.read_parquet(ROOT_OUT/(TABLE+'.parquet')).pivot(index='game_id',columns='side',values='nonempty_regulation_goals')
    for side in ['A','B']:frame['nonempty_regulation_score'+side]=frame.game_id.map(goals[side])
    frame=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1)
    columns=models.columns(frame,spec);assert not any('nonempty_regulation' in c or c=='target' for c in columns)
    predictions=pd.read_parquet(RESULT/'development_predictions.parquet')
    candidate=predictions[predictions.variant.eq('candidate')];replays=0
    for fold in ['2024-01','2025-01']:
        boundary=pd.Timestamp(fold+'-01',tz='UTC')
        prior=frame[frame.available_time<boundary]
        calibration=prior[prior.prediction_time>=boundary-pd.Timedelta(days=180)]
        train=prior[prior.available_time<calibration.prediction_time.min()]
        X=lambda f:f[columns].replace([np.inf,-np.inf],np.nan).astype(float)
        with threadpool_limits(limits=4):
            fit=models.fit_model(models.make_model(spec,'nhl'),X(train),train,spec,calibration.prediction_time.min())
            calibrator=models.calibration_fit(fit.predict_proba(X(calibration)),calibration.target.astype(int),spec.get('calibration','temperature'))
            fit=models.fit_model(models.make_model(spec,'nhl'),X(prior),prior,spec,boundary)
            sample=candidate[candidate.fold.eq(fold)].head(20)
            actual=models.apply_calibration(fit.predict_proba(X(frame.set_index('game_id').loc[sample.game_id])),calibrator)
        assert np.allclose(actual,sample[['p0','p1']],rtol=0,atol=1e-12);replays+=len(sample)
        assert train.available_time.max()<calibration.prediction_time.min() and prior.available_time.max()<sample.prediction_time.min()
    paired=candidate.merge(predictions[predictions.variant.eq('retained')],on='game_id',suffixes=('_candidate','_retained'),validate='one_to_one')
    assert paired.target_candidate.eq(paired.target_retained).all()
    index=paired.target_candidate.to_numpy(int);row=np.arange(len(paired))
    loss={k:-np.log(paired[['p0_'+k,'p1_'+k]].to_numpy()[row,index]) for k in ['candidate','retained']}
    delta=loss['candidate']-loss['retained']
    blocks=pd.DataFrame(dict(fold=paired.fold_candidate,delta=delta)).groupby('fold').delta.agg(['sum','count'])
    sample=np.random.default_rng(731).integers(0,len(blocks),size=(3000,len(blocks)))
    means=blocks['sum'].to_numpy()[sample].sum(axis=1)/blocks['count'].to_numpy()[sample].sum(axis=1)
    audit=dict(at_utc=stamp(),status='PASS',independent_model_calibrator_refits=2,forecast_replays=replays,
               current_game_targets_excluded_from_predictors=True,paired_games=len(paired),paired_loss_change=float(delta.mean()),
               monthly_block_95_interval=np.quantile(means,[.025,.975]).tolist(),multiple_testing_adjusted=False)
    dump(RESULT/'independent_validation.json',audit);print(json.dumps(audit),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--evaluate',action='store_true');p.add_argument('--verify',action='store_true');a=p.parse_args()
    if a.verify:verify()
    elif a.evaluate:evaluate();verify()
    else:build()
