"""Recover dated player exposure from the official match commentary API.

The statistics branch omits older player minutes. Its English match branch
contains native-ID substitutions and dismissals; clocks are minute-resolution
regulation time, with stoppage excluded. Raw branches and lineup hashes are kept.
"""
import argparse,collections,concurrent.futures,hashlib,json,re,sqlite3
import pandas as pd
from common import PROJECT,ROOT_OUT,PREVIOUS,OfficialClient,read_db,dump,stamp


def parse(game,document,lineup,source,lineup_source,staff_evidence=None):
    assert document['matchStatus']=='FINAL_WHISTLE'
    assert document['dflDatalibraryMatchId']==game['official_game_id']
    assert pd.Timestamp(document['plannedKickOff']).date()==pd.Timestamp(game['start_time']).date()
    rows=[];issues=[];staff_events=[];applied_evidence=[];events=document['liveBlogEntries'];events=list(events.items()) if isinstance(events,dict) else list(enumerate(events))
    kinds=collections.Counter(e['entryType'] for _,e in events)
    meaningful=[(key,e) for key,e in events if e['entryType'] in ['sub','goal','ownGoal','redCard','secondYellowCard','yellowRedCard']]
    event_time=[pd.Timestamp(e['entryDate']) for _,e in meaningful if e.get('entryDate')]
    available=max([pd.Timestamp(game['available_time'])]+event_time)
    goal_counts=collections.Counter();player_goals=collections.Counter()
    for _,e in meaningful:
        if e['entryType'] not in ['goal','ownGoal']:continue
        side=e['side'];credited=('home' if side=='away' else 'away') if e['entryType']=='ownGoal' else side
        goal_counts[credited]+=1
        if e['entryType']=='goal':player_goals[e['detail']['scorer']['dflDatalibraryObjectId']]+=1
    reconciled=all(goal_counts[native]==game['score'+side] for side,native in [('A','away'),('B','home')])
    for side,native,tid in zip(['A','B'],['away','home'],json.loads(game['native_team_ids_json'])):
        assert str(document['teams'][native]['dflDatalibraryClubId'])==str(tid)
        assert document['score'][native]['live']==game['score'+side]
        roster={};active={};played=set();minutes=collections.Counter();dismissals=[]
        coaches={p['dflDatalibraryObjectId']:p for p in lineup[native].get('coaches',{}).get('persons',[])}
        for section in ['startingEleven','bench']:
            for p in lineup[native].get(section,{}).get('persons',[]):
                pid=p['dflDatalibraryObjectId'];assert pid not in roster
                roster[pid]=(p,section=='startingEleven')
                if section=='startingEleven':active[pid]=0.;played.add(pid)
        assert len(active)==11
        transitions=sorted([(key,e) for key,e in meaningful if e.get('side')==native and e['entryType'] in ['sub','redCard','secondYellowCard','yellowRedCard']],key=lambda item:item[1]['order'])
        complete=True;used=[];row_available=available
        try:
            for key,e in transitions:
                clock=e['playtime'];at=float(clock['minute']);assert 0<=at<=130
                section=e['matchSection'];assert section in ['FIRST_HALF','HALF','SECOND_HALF','AFTER_MATCH'],section
                at=min(45.,at) if section in ['FIRST_HALF','HALF'] else min(90.,at)
                if e['entryType']=='sub':
                    off=e['detail']['out']['dflDatalibraryObjectId'];on=e['detail']['in']['dflDatalibraryObjectId']
                    assert off in active and on in roster and on not in played,'Inconsistent native-ID substitution sequence'
                    minutes[off]+=at-active.pop(off);active[on]=at;played.add(on)
                else:
                    off=e['detail']['person']['dflDatalibraryObjectId']
                    if off in coaches and off not in roster:
                        staff_events.append(dict(side=side,event_id=str(key),person_id=off,name=coaches[off]['name'],reason='Native ID exactly matches the dated official coach lineup; no player minutes removed.'))
                        continue
                    name=e['detail']['person'].get('name','')
                    commentary=[(str(cid),comment) for cid,comment in events if comment.get('side')==native and comment['entryType']=='freetext'
                                and re.search(r'coaching staff,\s*'+re.escape(name)+r'\b',comment.get('detail',{}).get('text',''),re.I)] if name else []
                    if off not in roster and commentary:
                        staff_events.append(dict(side=side,event_id=str(key),person_id=off,name=name,commentary_event_id=commentary[0][0],
                            reason='Official same-match commentary explicitly identifies this named person as coaching staff; no player minutes removed.'))
                        continue
                    proof=next((r for r in staff_evidence or [] if r.get('state')=='verified' and r['game_id']==game['game_id']
                                and r['side']==side and r['person_id']==off and r['event_id']==str(key)),None)
                    if off not in roster and proof:
                        from verify_bundesliga_staff import normal,document_text
                        assert normal(proof['person_name'])==normal(name)
                        blob=(PROJECT/proof['source']['raw_file']).read_bytes()
                        assert hashlib.sha256(blob).hexdigest()==proof['source']['sha256']
                        assert all(normal(v) in normal(document_text(blob)) for v in proof['required_identity_phrases'])
                        assert proof['event_source']['sha256']==source['sha256']
                        # A later disciplinary announcement establishes the
                        # repair only after its published day. Earlier club
                        # identity articles do not delay the match observations.
                        known=pd.Timestamp(proof['source_published_date'],tz='UTC')+pd.Timedelta(days=1)
                        row_available=max(row_available,known);applied_evidence.append(proof)
                        used.append(dict(event_id=str(key),native_type=e['entryType'],person_id=off,minute=at,raw_clock=clock,
                                         player_minutes_removed=False,staff_identity_source=proof['source']))
                        staff_events.append(dict(side=side,event_id=str(key),person_id=off,name=name,source=proof['source'],
                            reason='Official dated identity evidence verifies coaching staff for this native person and match; no player minutes removed.'))
                        continue
                    if off not in roster:
                        # Staff cannot be silently classified as a player or
                        # ignored when the source does not establish identity.
                        raise AssertionError('Dismissed person absent from dated roster: '+off)
                    if off in active:minutes[off]+=at-active.pop(off);dismissals.append(at)
                used.append(dict(event_id=str(key),native_type=e['entryType'],minute=at,raw_clock=clock))
            for pid,at in active.items():minutes[pid]+=90-at
            assert all(0<=value<=90 for value in minutes.values())
            assert abs(sum(minutes.values())-(990-sum(90-at for at in dismissals)))<1e-8
        except (KeyError,AssertionError,TypeError,ValueError) as exc:
            complete=False;issues.append(dict(side=side,reason=type(exc).__name__+': '+str(exc)))
        for pid,(p,started) in roster.items():
            rows.append(dict(game_id=game['game_id'],official_game_id=game['official_game_id'],league='Bundesliga',date=game['date'],side=side,team_id=str(tid),
                official_player_id=pid,player_name=p['name'],position=p.get('role'),started=started,played=(pid in played) if complete else (True if started else None),
                minutes=float(minutes[pid]) if complete else None,goals=player_goals[pid] if reconciled else None,available_at_utc=row_available.isoformat(),
                minutes_basis='Derived from official event minute; regulation minutes excluding stoppage, minute resolution',minutes_complete=complete,goals_reconcile=reconciled,
                source=source,lineup_source=lineup_source,transition_events=used))
    if not reconciled:issues.append(dict(field='goals',reason='Recorded goals do not reconcile with the official final score'))
    result=dict(game_id=game['game_id'],official_game_id=game['official_game_id'],date=game['date'],players=rows,issues=issues,event_types=dict(kinds),sources=[source,lineup_source])
    if staff_events:result['excluded_staff_events']=staff_events
    if applied_evidence:result['staff_identity_evidence']=applied_evidence
    return result


def write_cumulative_progress():
    with read_db(ROOT_OUT/'bundesliga_minutes.sqlite') as db:
        records=[json.loads(b) for b, in db.execute('SELECT body FROM games')]
        errors=db.execute('SELECT count(*) FROM issues').fetchone()[0]
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        total=db.execute("SELECT count(*) FROM soccer_games WHERE league='Bundesliga' AND date>='2021-01-01'").fetchone()[0]
    report=dict(at_utc=stamp(),stage='bundesliga_minutes',scope='Cumulative retained history; last repair block is recorded separately',
        processed=len(records),total=total,percent=round(100*len(records)/total,1),games=len(records),
        player_rows=sum(len(r['players']) for r in records),complete_minutes_rows=sum(p['minutes_complete'] for r in records for p in r['players']),
        request_or_schema_issues=errors,retained_event_issues=sum(len(r['issues']) for r in records),
        earliest_date=min(r['date'] for r in records),latest_date=max(r['date'] for r in records))
    dump(ROOT_OUT/'bundesliga_minutes_progress.json',report)


def main():
    p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');p.add_argument('--limit',type=int);p.add_argument('--retry',action='store_true');p.add_argument('--repair-existing',action='store_true');a=p.parse_args()
    with read_db(PREVIOUS/'expanded.sqlite') as c:games={r['game_id']:dict(r) for r in c.execute("SELECT * FROM soccer_games WHERE league='Bundesliga' AND date>='2021-01-01' ORDER BY date")}
    with read_db(ROOT_OUT/'soccer_additional.sqlite') as c:records={r['game_id']:r for b, in c.execute("SELECT body FROM games WHERE league='Bundesliga'") for r in [json.loads(b)]}
    db=sqlite3.connect(ROOT_OUT/'bundesliga_minutes.sqlite',timeout=60)
    db.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT); CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,reason TEXT,source_json TEXT);')
    done=set() if a.retry else {r[0] for r in db.execute('SELECT game_id FROM games')}
    if a.repair_existing:
        bad={r[0] for r in db.execute("SELECT game_id FROM games WHERE json_array_length(body,'$.issues')>0")}
        done-=bad
    tasks=[g for gid,g in games.items() if gid in records and gid not in done]
    if a.pilot:
        selected={}
        for g in tasks:selected.setdefault(g['date'][:4],g)
        tasks=list(selected.values())
    if a.limit:tasks=tasks[:a.limit]
    client=OfficialClient(per_second=3)
    staff_path=ROOT_OUT/'bundesliga_verified_staff.json'
    staff_evidence=json.loads(staff_path.read_text())['records'] if staff_path.exists() else []
    def get(g):
        source=None
        try:
            old=records[g['game_id']];ls=next(s for s in old['sources'] if '/lineup.json' in s['url'])
            raw=(PROJECT/ls['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==ls['sha256'];lineup=json.loads(raw)
            url=ls['url'].rsplit('/',1)[0].replace('/all/','/en/')+'.json'
            document,source=client.get(url,'Dated Bundesliga player exposure, '+g['date']+' '+g['official_game_id'],'official_match_events')
            assert document is not None,'Official match document requires retry: '+source['return_status']
            return g,parse(g,document,lineup,source,ls,staff_evidence=staff_evidence),None,source
        except Exception as exc:return g,None,type(exc).__name__+': '+str(exc),source
    ok=0;errors=0;players=0;complete_rows=0;milestone=10
    print(json.dumps(dict(stage='bundesliga_minutes_start',tasks=len(tasks),retained=len(done))),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for n,(g,result,error,source) in enumerate(pool.map(get,tasks),1):
            with db:
                if result:
                    db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(g['game_id'],json.dumps(result)))
                    db.execute('DELETE FROM issues WHERE game_id=?',(g['game_id'],));ok+=1;players+=len(result['players']);complete_rows+=sum(r['minutes_complete'] for r in result['players'])
                else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?,?)',(g['game_id'],error,json.dumps(source)));errors+=1
            if 100*n>=len(tasks)*milestone or n==len(tasks):
                report=dict(at_utc=stamp(),stage='bundesliga_minutes',processed=n,total=len(tasks),percent=round(100*n/len(tasks),1),games=ok,player_rows=players,complete_minutes_rows=complete_rows,request_or_schema_issues=errors,latest_date=g['date'])
                progress_name='bundesliga_minutes_repair_progress.json' if a.repair_existing else 'bundesliga_minutes_progress.json'
                dump(ROOT_OUT/progress_name,report);print(json.dumps(report),flush=True);milestone+=10
    db.close()
    if a.repair_existing:write_cumulative_progress()


if __name__=='__main__':main()
