"""Test earlier-result qualification certificates on corrected soccer inputs."""
import argparse
import copy
import json
import numpy as np
import pandas as pd
from common import ROOT_OUT,REPORTS,dump,stamp,file_sha256
from uefa_qualification import TABLE,PROOF

LABEL='soccer_qualification'
WORK=ROOT_OUT/'_work'/LABEL
RESULT=ROOT_OUT/'simulation_results'/LABEL
REFERENCE=ROOT_OUT/'simulation_results/soccer_source_count_rates'
FIELDS=['f_ctx_direct_qualification_certificate_diff','f_ctx_direct_qualification_certificate_sum',
        'f_ctx_elimination_certificate_diff','f_ctx_elimination_certificate_sum']


def prepare():
    import soccer_source_count_rates as source
    source.WORK=WORK;source.RESULT=RESULT/'source_replay';source.RESULT.mkdir(parents=True,exist_ok=True)
    source.build()


def build():
    RESULT.mkdir(exist_ok=True)
    assert (RESULT/'source_replay/feature_validation.json').exists()
    proof=json.loads(PROOF.read_bytes());assert proof['status']=='PASS' and proof['sql_parquet_equal']
    path=ROOT_OUT/(TABLE+'.parquet');assert file_sha256(path)==proof['output_sha256']
    facts=pd.read_parquet(path);base=pd.read_parquet(WORK/'squad/soccer_features.parquet').set_index('game_id')
    # This control is the corrected-count candidate of the preceding study.
    previous=json.loads((REFERENCE/'feature_validation.json').read_bytes())
    assert file_sha256(WORK/'squad/soccer_features.parquet')==previous['candidate_hash'],'Reconstructed corrected-source input changed'
    recipe=copy.deepcopy(json.loads((REFERENCE/'experiment_plan.json').read_bytes())['recipe'])
    recipe['preserve_unit_columns']+=FIELDS
    dump(RESULT/'experiment_plan.json',dict(at_utc=stamp(),recipe=recipe,
        hypothesis='Previously secured advancement/elimination can distinguish fixture context from average team strength without assuming a future lineup or match result.',
        new_fields=FIELDS,source_table=TABLE,source_sha256=proof['output_sha256'],
        semantics='Home-minus-away and sum of conservative points certificates. A false flag means not certified by the sufficient bound. It does not imply no incentive, especially old-group Europa League or seeding possibilities.',
        scope='Every eligible Champions League group fixture2021onward, not just known losses. Other competitions/phases have structural zero for these certificate features.',
        unchanged='Source-count-corrected41-input model, imputation/scaling regularization calibration, monthly expanding2021+training, pre12cash policy. Four new inputs, no hyperparameter grid.',
        gate='Lower rolling2024/25logloss AND Brier on identical games before2026evaluation. No current or final group standings are predictors.',
        evaluation='2026 repeatedly inspected retrospective rolling evaluation, not pristine holdout.',app_changed=False))
    g=pd.read_pickle(WORK/'games.pkl').set_index('game_id');facts['prediction_time']=pd.to_datetime(facts.prediction_time,utc=True,format='mixed')
    by={native:h.set_index('side') for native,h in facts.groupby('official_game_id')}
    changed=base.copy()
    for c in FIELDS:changed[c]=0.
    audit=[]
    for gid,r in g[g.league.eq('UEFA Champions League')].iterrows():
        native=str(r.official_game_id)
        if native not in by:continue
        f=by[native];assert set(f.index)=={'A','B'}
        assert list(map(str,json.loads(r.native_team_ids_json)))==[f.loc['A','team_id'],f.loc['B','team_id']]
        assert (f.prediction_time==r.prediction_time).all()
        for stem,field in [('direct_qualification_certificate','direct_qualification_certified'),('elimination_certificate','elimination_certified')]:
            a,b=float(f.loc['A',field]),float(f.loc['B',field])
            changed.loc[gid,'f_ctx_'+stem+'_diff']=b-a;changed.loc[gid,'f_ctx_'+stem+'_sum']=b+a
        audit.append(dict(game_id=gid,official_game_id=native,prediction_time=r.prediction_time,
            qualificationA=bool(f.loc['A','direct_qualification_certified']),qualificationB=bool(f.loc['B','direct_qualification_certified']),
            eliminationA=bool(f.loc['A','elimination_certified']),eliminationB=bool(f.loc['B','elimination_certified'])))
    assert len(audit)==facts.official_game_id.nunique()
    assert changed.drop(columns=FIELDS).equals(base)
    work=WORK/'qualification';work.mkdir(exist_ok=True);changed.reset_index().to_parquet(work/'soccer_features.parquet',index=False)
    pd.DataFrame(audit).to_parquet(RESULT/'feature_evidence.parquet',index=False)
    dump(RESULT/'feature_validation.json',dict(status='PASS',at_utc=stamp(),all_games=len(base),group_games=len(audit),
        new_columns=FIELDS,source_future_score_replays=proof['future_result_poison_replays'],original_inputs_identical=True,
        native_identity_and_cutoff_verified=True,prior_proved_zeros_retained=True,feature_sha256=file_sha256(work/'soccer_features.parquet')))
    print(json.dumps(dict(stage='features',games=len(base),group_games=len(audit))),flush=True)


def train():
    import models
    import soccer_squad_model as runner
    recipe=json.loads((REFERENCE/'experiment_plan.json').read_bytes())['recipe']
    models.OUT=WORK/'squad';models.CANDIDATES['qualified_count_control']=recipe
    ref=models.run('soccer','development',['qualified_count_control']).set_index('game_id')
    saved=pd.read_parquet(REFERENCE/'development_predictions.parquet');saved=saved[saved.variant.eq('candidate')].set_index('game_id')
    assert set(ref.index)==set(saved.index)
    assert np.allclose(ref.loc[saved.index,['p0','p1','p2']],saved[['p0','p1','p2']],rtol=0,atol=1e-12)
    dump(RESULT/'control_replay.json',dict(status='PASS',at_utc=stamp(),forecasts=len(saved),source_counts_corrected=True))
    # The common runner uses WORK/squad; pass a small wrapper path containing
    # the new matrix without moving or overwriting either control matrix.
    wrapper=WORK/'experiment';folder=wrapper/'squad';folder.mkdir(parents=True,exist_ok=True)
    import shutil
    shutil.copy2(WORK/'qualification/soccer_features.parquet',folder/'soccer_features.parquet')
    runner.WORK=wrapper;runner.RESULT=RESULT;runner.REFERENCE=REFERENCE
    runner.train()


def finish():
    from pathlib import Path
    from final_pipeline import discard_work,cleanup,validate
    for name in ['feature_validation','control_replay','validation','cash_validation']:
        assert json.loads((RESULT/(name+'.json')).read_bytes())['status']=='PASS'
    selection=json.loads((RESULT/'selection.json').read_bytes());proof=json.loads(PROOF.read_bytes())
    a=pd.read_csv(RESULT/'annual.csv');p=pd.read_parquet(RESULT/'development_predictions.parquet')
    case=p[p.game_id.eq('UCL_20250129_LIV_PSV')][['variant','p0','p1','p2','target']]
    def table(f):
        def fmt(x):return f'{x:.6f}' if isinstance(x,(float,np.floating)) else str(x)
        return '\n'.join(['| '+' | '.join(f.columns)+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(map(fmt,row))+' |' for row in f.itertuples(index=False,name=None)])
    scores=pd.DataFrame([dict(variant=k,**v) for k,v in selection['scores'].items()])
    lines=['# Soccer qualification context','',
        'The new date-queryable source table derives conservative advancement/elimination certificates from earlier official group results. It does not read the current result, final standings or a future lineup, and does not label a team unmotivated. Every acquired Champions League group fixture is included, independently of its odds or outcome.','',
        f"Coverage: {proof['games']} games and {proof['team_rows']} team rows, {proof['earliest_date']} through {proof['latest_date']}. {proof['direct_certificates']} direct-qualification certificates; {proof['elimination_certificates']} elimination certificates. Full old groups have six games per team, modern league phases eight. Closed calendars reconcile exactly; the current season contains its completed first matchday. SQL/Parquet equality and {proof['future_result_poison_replays']} future-result perturbations pass.",'',
        'The conservative worst rank counts every other team that could still equal or exceed current points. The best-rank bound counts teams already strictly above the maximum attainable points. Tied possibilities are not declared settled. False means not established by this sufficient test; old group elimination can still leave a Europa League incentive.','',
        '## Public validation','']
    for example in proof['public_examples']:
        lines.append(f"- Native match {example['official_game_id']}, club {example['team_id']}: {example['points']} earlier points and worst-rank bound {example['worst_rank_upper_bound']}; official pre-match confirmation: {example['public_source']['url']}")
    lines+=['','Official documentation URLs:']+[str(x['url']) for x in proof['documentation']]
    lines+=['','## Controlled model comparison','',
        'Four inputs are added: home-minus-away and sum of the two certificates. The count-corrected41-input control, statistical preprocessing, regularization, monthly expanding history from2021 and purged calibration are otherwise unchanged. All3,961 earlier control forecasts replay exactly. A lower2024/25logloss and Brier are required before2026evaluation.','',table(scores),'',
        'Earlier gate: '+str(selection['passed'])+'. Paired probability-loss diagnostic: '+json.dumps(selection['paired'])+'.','',
        'Liverpool at PSV is shown for interpretation, not selected for a special penalty:','',table(case),'',
        '## Unchanged account rule','',
        'Annual starting cash$2,000; stake$5per positive probability-minus-price percentage point, one existing expected-log-growth choice, official settlement before cash reuse, pre12closest preceding source quote no more than24hoursold. No added fee assumptions. Providers remain separate; historical Polymarket token prices are not verified executable US asks. Sharpe uses daily calendar returns including idle days, annualized by sqrt(365.25).','',
        table(a[['provider','variant','year','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']]),'',
        'Repeatedly inspected2026is retrospective rolling research, not an untouched holdout. No automatic model/app adoption. The source table remains useful regardless of forecast performance.','',
        'Reproduce uefa_qualification.py collect and publish, then soccer_qualification_model.py prepare, build, train, finish. Source data, exact raw request pointers/hashes, per-date group evidence, model forecasts and simulations remain; completed temporary inputs and fits are removed. The SQL catalog includes every new field, unit, source and missing percentage.']
    (REPORTS/(LABEL+'.md')).write_text('\n'.join(lines)+'\n',encoding='utf8')
    if WORK.exists():discard_work(WORK)
    cleanup();check=validate()
    receipt=dict(status='PASS',at_utc=stamp(),selection=selection,source_validation=str(PROOF),app_validation=check,adopted=False,goal_achieved=False)
    dump(ROOT_OUT/'retention'/(LABEL+'_completion.json'),receipt)
    path=ROOT_OUT/'retention/retained_artifacts.json';m=json.loads(path.read_bytes());m['scripts']={p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    m.update(updated_utc=stamp(),retained_scripts=len(m['scripts']),final_tables=102,current_sql_columns=2453,latest_simulation_update=receipt);dump(path,m)
    print(a[['provider','variant','year','funded_games','return_pct','sharpe','max_drawdown_pct']].to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['prepare','build','train','finish']);args=parser.parse_args();globals()[args.stage]()
