"""Narrow native-ID corrections corroborated by a dated national association report."""
import copy,html,re


def correct_events(game,events,client):
    if game['official_game_id']!='2040075':return events,[]
    url='https://www.scottishfa.co.uk/en/news/scotland-suffer-narrow-defeat-away-to-portugal'
    client.HOSTS.add('www.scottishfa.co.uk')
    blob,source=client.get(url,'Verify UEFA reversed McLean/Gauld substitution against dated Scottish FA report','official_match_correction',document=True)
    assert blob is not None,'Official correction evidence could not be retrieved'
    text=html.unescape(re.sub('<[^>]+>',' ',blob.decode('utf8')));text=re.sub(r'\s+',' ',text)
    assert 'McLean (Gauld 74' in text and '8 September 2024' in text
    out=copy.deepcopy(events);matches=[e for e in out if e['id'].replace('-','')=='c96d38c9c5fc4a7e8b34627a518ea125']
    assert len(matches)==1
    e=matches[0];a=e['primaryActor']['person']['id'];b=e['secondaryActor']['person']['id']
    assert [str(a),str(b)] in [['250053140','250023609'],['250023609','250053140']]
    if str(a)=='250053140':e['primaryActor'],e['secondaryActor']=e['secondaryActor'],e['primaryActor']
    return out,[dict(event_id=e['id'],field='substitution_direction',raw_off_id=str(a),raw_on_id=str(b),
        normalized_off_id='250023609',normalized_on_id='250053140',off_name='Kenny McLean',on_name='Ryan Gauld',
        reason='Scottish FA dated match report identifies McLean replaced by Gauld at 74 minutes; UEFA clock retained.',source=source)]
