"""Audit and acquire prices after dated NHL projected-lineup information.

No forecast, stake, app file, or existing pre12 baseline is changed here.
"""
import argparse
import concurrent.futures
import json
import math
import urllib.parse
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT_OUT, PROJECT, REPORTS, OfficialClient, read_db, dump, stamp, file_sha256

RESULT = ROOT_OUT / 'simulation_results/nhl_lineup_entry'
DOCS = [
    'https://docs.polymarket.com/api-reference/markets/get-prices-history',
    'https://docs.polymarket.com/api-reference/markets/get-a-tokens-price-history',
    'https://docs.polymarket.com/api-reference/rate-limits',
    'https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps',
    'https://docs.kalshi.com/api-reference/historical/get-historical-market-candlesticks',
    'https://docs.kalshi.com/api-reference/market/get-market-candlesticks',
    'https://docs.kalshi.com/getting_started/rate_limits',
]


class Client(OfficialClient):
    HOSTS = OfficialClient.HOSTS | {'clob.polymarket.com', 'data-api.polymarket.com', 'external-api.kalshi.com'}


def prepare():
    RESULT.mkdir(parents=True, exist_ok=True)
    with read_db(ROOT_OUT / 'granular.sqlite') as db:
        reports = pd.read_sql_query('SELECT * FROM nhl_dated_lineup_reports', db)
        players = pd.read_sql_query("SELECT * FROM nhl_dated_lineup_players WHERE report_status='projected'", db)
    assert not reports.official_game_id.duplicated().any()
    groups = {str(k): v for k, v in players.groupby('official_game_id')}
    rows = []
    for r in reports.to_dict('records'):
        g = groups.get(str(r['official_game_id']), players.iloc[:0])
        issues = []
        for side in ['A', 'B']:
            s = g[g.side.eq(side)]
            if not 18 <= len(s) <= 24:
                issues.append(side + ': projected count outside 18..24')
            if not s.identity_verified.eq(1).all() or s.official_player_id.isna().any():
                issues.append(side + ': unresolved projected identity')
            if s.identity_or_status_conflict.ne(0).any() or s.official_player_id.duplicated().any():
                issues.append(side + ': projected identity/status conflict')
        for issue in json.loads(r['source_issues_json']):
            # Issues confined to named injury/scratch sections do not invalidate
            # the independently complete projected participant list.
            if issue.get('report_status') == 'projected':
                issues.append('projected source fragment requires review')
        at = max(pd.Timestamp(r['published_at_utc']), pd.Timestamp(r['modified_at_utc']))
        assert at == pd.Timestamp(r['available_at_utc'])
        start = pd.Timestamp(r['start_time'])
        info = max(at, pd.Timestamp(r['prediction_time']))
        if info >= start:
            issues.append('current article version not available before start')
        rows.append({k: r[k] for k in ['game_id', 'official_game_id', 'date', 'teamA', 'teamB',
                    'native_team_ids_json', 'start_time', 'prediction_time', 'source_json']} |
                    dict(information_time=info, article_available_at_utc=at,
                         usable_projected_lineup=not issues,
                         review_reasons_json=json.dumps(sorted(set(issues))),
                         projected_players=len(g), published_lead_hours=(start-at).total_seconds()/3600))
    ready = pd.DataFrame(rows)
    ready.to_parquet(RESULT / 'lineup_readiness.parquet', index=False)
    counts = ready.assign(year=ready.date.str[:4]).groupby('year').agg(
        reports=('game_id', 'size'), usable=('usable_projected_lineup', 'sum'),
        before_start=('published_lead_hours', lambda s: int(s.gt(0).sum())),
        before_pre12=('published_lead_hours', lambda s: int(s.ge(12).sum())))
    counts.to_csv(RESULT / 'lineup_readiness_by_year.csv')
    from backtest import quote_inputs
    quotes = quote_inputs(RESULT / 'existing_quote_quality.json', revision='closest_v62')
    quotes = quotes[quotes.sport.eq('nhl') & quotes.year.isin([2024, 2025])].copy()
    q = quotes.merge(ready, on='official_game_id', suffixes=('_quote', ''), validate='many_to_one')
    # Map by official identity and native teams, never by a name/date guess.
    if 'native_team_ids_json_quote' in q:
        for r in q.itertuples():
            assert json.loads(r.native_team_ids_json_quote) == json.loads(r.native_team_ids_json)
    q = q[q.usable_projected_lineup].copy()
    keep = ['provider', 'game_id', 'official_game_id', 'date', 'teamA', 'teamB', 'native_team_ids_json',
            'start_time', 'information_time', 'article_available_at_utc', 'source_json',
            'class_index', 'entry_contract_id', 'entry_request_id', 'entry_pointer']
    q = q[keep].sort_values(['provider', 'information_time', 'official_game_id', 'class_index'])
    assert not q.duplicated(['provider', 'official_game_id', 'class_index']).any()
    q.to_parquet(RESULT / 'contract_manifest.parquet', index=False)
    plan = dict(at_utc=stamp(), purpose='Test feasibility of using match-specific published projected lineups and genuinely subsequent pre-match prices.',
                history='2021 onward lineup evidence; price feasibility uses only 2024/25 before any 2026 experiment.',
                selection='First chronological game per provider and calendar quarter for pilot; no outcomes, probabilities or profitability used.',
                information='max(pre12, article publication, article modification). Projected is not confirmed. Unresolved projected identities/status conflicts require review.',
                prices='Hourly CLOB samples; V2 three-hour fallback with full bucket completion and no resolution point. Kalshi hourly recorded YES ask close after an entire post-information candle. No invented spread or costs.',
                entry='First time both outcomes have usable post-information observations. Choose first observations irrespective of outcome or eventual profit. Source and availability must precede match start.',
                docs=DOCS, providers='kept separate', new_model_evaluated=False, app_changed=False)
    dump(RESULT / 'source_plan.json', plan)
    print(json.dumps(dict(stage='prepared', years=counts.reset_index().to_dict('records'),
                         contracts=len(q), provider_games=q.groupby('provider').official_game_id.nunique().to_dict())), flush=True)
    review_sources()


def review_sources():
    with read_db(ROOT_OUT / 'granular.sqlite') as db:
        p = pd.read_sql_query("SELECT game_id,official_game_id,side,player_name_raw,source_group_text,official_player_id,identity_verified,identity_or_status_conflict,available_at_utc,source_json FROM nhl_dated_lineup_players WHERE report_status='projected' AND (identity_verified=0 OR identity_or_status_conflict<>0)", db)
    p.to_parquet(RESULT / 'projected_identity_repair_queue.parquet', index=False)
    p.groupby(['player_name_raw','identity_verified','identity_or_status_conflict'], dropna=False).agg(
        rows=('game_id','size'), games=('game_id','nunique')).reset_index().sort_values('rows', ascending=False).to_csv(
            RESULT / 'projected_identity_review.csv', index=False)
    dump(RESULT / 'repair_queue_scope.json', dict(at_utc=stamp(), rows=len(p), games=p.game_id.nunique(),
        description='Unresolved projected identity or overlapping source status, retained for repair; not declared unavailable. Verify aliases with official native links or exact dated names/jerseys. Separate Markdown-only fragments from people after raw replay.',
        ambiguity='Do not merge Elias Nils Pettersson with another Elias Pettersson without native identity and role evidence.',
        normalized_source_tables_changed=False, timing_cohort_frozen=True))


def point(t, price, available, resolution, pointer, meta, basis):
    if price is None:
        return None
    p = float(price)
    assert np.isfinite(p) and 0 <= p <= 1
    return dict(source_utc=pd.Timestamp(t, unit='s', tz='UTC'), price=p,
                available_utc=pd.Timestamp(available, unit='s', tz='UTC'), resolution_seconds=int(resolution),
                pointer=pointer, request_number=meta['request_number'], source_json=json.dumps(meta), price_basis=basis)


def polymarket(client, r):
    lo = math.ceil(pd.Timestamp(r['information_time']).timestamp())
    hi = math.ceil(pd.Timestamp(r['start_time']).timestamp())
    requests = []
    url = 'https://clob.polymarket.com/prices-history?' + urllib.parse.urlencode(
        dict(market=r['entry_contract_id'], startTs=lo, endTs=hi, fidelity=60))
    body, meta = client.get(url, 'NHL post-lineup pre-match hourly prices ' + r['game_id'], kind='GET lineup price window')
    requests.append(meta)
    points = []
    if body is not None:
        assert isinstance(body.get('history'), list)
        for i, x in enumerate(body['history']):
            z = point(x['t'], x['p'], x['t'], 0, f'/history/{i}/p', meta, 'polymarket_clob_hourly_historical_price')
            if z and lo <= x['t'] < hi:
                points.append(z)
    if points:
        return points, requests
    params = dict(token_id=r['entry_contract_id'], start=lo, end=hi, bucket_seconds=10800)
    seen = set()
    while True:
        url = 'https://data-api.polymarket.com/v2/prices-history?' + urllib.parse.urlencode(params)
        body, meta = client.get(url, 'NHL post-lineup pre-match retained three-hour prices ' + r['game_id'], kind='GET lineup retained price window')
        requests.append(meta)
        if body is None:
            return points, requests
        assert isinstance(body.get('data'), list)
        for i, x in enumerate(body['data']):
            res = int(x['resolution_seconds'])
            if res <= 0:
                continue  # Explicit resolved payout is never a buy quote.
            t = x['timestamp']
            z = point(t, x['price'], t+res, res, f'/data/{i}/price', meta, 'polymarket_v2_completed_three_hour_price')
            if z and lo <= t and t+res < hi:
                points.append(z)
        page = body.get('pagination', {})
        cursor = page.get('next_cursor')
        if not cursor:
            assert not page.get('has_more', False)
            break
        assert cursor not in seen
        seen.add(cursor)
        params['cursor'] = cursor
    return points, requests


def kalshi(client, r, cutoff, market):
    settled = pd.Timestamp(market['settled'])
    assert pd.notna(settled)
    historic = settled < pd.Timestamp(cutoff['market_settled_ts'])
    base = 'https://external-api.kalshi.com/trade-api/v2/'
    endpoint = ('historical/markets/' if historic else 'series/'+market['series']+'/markets/') + r['entry_contract_id'] + '/candlesticks'
    lo = math.ceil(pd.Timestamp(r['information_time']).timestamp())
    hi = math.ceil(pd.Timestamp(r['start_time']).timestamp())-1
    url = base + endpoint + '?' + urllib.parse.urlencode(dict(start_ts=lo, end_ts=hi, period_interval=60))
    body, meta = client.get(url, 'NHL post-lineup hourly YES ask close ' + r['game_id'], kind='GET lineup historical candles' if historic else 'GET lineup recent candles')
    points = []
    if body is not None:
        assert isinstance(body.get('candlesticks'), list)
        assert body.get('ticker', r['entry_contract_id']) == r['entry_contract_id']
        for i, x in enumerate(body['candlesticks']):
            t = x['end_period_ts']
            obj = x.get('yes_ask') or {}
            key = 'close_dollars' if 'close_dollars' in obj else 'close'
            raw = obj.get(key)
            if raw is None:
                continue
            # Current docs use fixed-point dollar strings. Legacy integer cents
            # are a distinct source schema, not inferred from the value's size.
            price = float(raw) / 100 if key == 'close' and isinstance(raw, int) else float(raw)
            z = point(t, price, t, 3600, f'/candlesticks/{i}/yes_ask/{key}', meta, 'kalshi_recorded_yes_ask_close')
            if lo <= t-3600 and t <= hi:
                points.append(z)
    return points, [meta]


def collect(pilot=True):
    manifest = pd.read_parquet(RESULT / 'contract_manifest.parquet')
    if pilot:
        pick = manifest.assign(quarter=pd.to_datetime(manifest.date).dt.to_period('Q').astype(str))
        selected = pick.drop_duplicates(['provider', 'official_game_id']).groupby(['provider', 'quarter'], sort=True).head(1)
        manifest = manifest.merge(selected[['provider', 'official_game_id']], on=['provider', 'official_game_id'], validate='many_to_one')
    client = Client(per_second=4)
    cutoff, cutoff_meta = client.get('https://external-api.kalshi.com/trade-api/v2/historical/cutoff',
                                    'Current historical routing cutoff for NHL later-lineup price study', kind='GET historical cutoff', refresh=True)
    assert cutoff and cutoff.get('market_settled_ts')
    dump(RESULT / 'historical_cutoff.json', dict(value=cutoff, source=cutoff_meta))
    with read_db(PROJECT / 'collected data/result/sentinent_snake.sqlite') as db:
        markets = [json.loads(x[0]) for x in db.execute('SELECT body FROM _nhl_market_candidates')]
    km = {m['contract_id']: m for m in markets if m['provider'] == 'kalshi'}
    rows = []
    audit = []
    label = 'pilot' if pilot else 'development'
    checkpoint = 10
    def acquire(r):
        result = polymarket(client, r) if r['provider'] == 'polymarket' else kalshi(client, r, cutoff, km[r['entry_contract_id']])
        return r, result
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
      for n, (r, (points, requests)) in enumerate(pool.map(acquire, manifest.to_dict('records')), 1):
        for z in points:
            rows.append({k: r[k] for k in ['provider', 'game_id', 'official_game_id', 'class_index', 'entry_contract_id', 'information_time', 'start_time']} | z)
        audit.append({k: r[k] for k in ['provider', 'game_id', 'official_game_id', 'class_index', 'entry_contract_id']} |
                     dict(usable_window_points=len(points), requests_json=json.dumps(requests),
                          status='points_returned' if points else 'no_usable_post_information_point',
                          failure_not_unavailability=any(x['return_status'] != '200' for x in requests)))
        percent = 100*n/len(manifest)
        if percent >= checkpoint or n == len(manifest):
            pd.DataFrame(rows).to_parquet(RESULT / (label+'_points.parquet'), index=False)
            pd.DataFrame(audit).to_parquet(RESULT / (label+'_requests.parquet'), index=False)
            print(json.dumps(dict(stage=label, percent=round(percent, 1), contracts=n, total=len(manifest), points=len(rows))), flush=True)
            while checkpoint <= percent:
                checkpoint += 10
    validate(label)


def validate(label):
    points = pd.read_parquet(RESULT / (label+'_points.parquet'))
    audit = pd.read_parquet(RESULT / (label+'_requests.parquet'))
    cache = {}
    for r in points.to_dict('records'):
        meta = json.loads(r['source_json'])
        if meta['request_number'] not in cache:
            path = PROJECT / meta['raw_file']
            assert file_sha256(path) == meta['sha256']
            cache[meta['request_number']] = json.loads(path.read_bytes())
        body = cache[meta['request_number']]
        value = body
        for part in r['pointer'].strip('/').split('/'):
            value = value[int(part)] if isinstance(value, list) else value[part]
        v = float(value)/100 if r['provider']=='kalshi' and r['pointer'].endswith('/close') and isinstance(value, int) else float(value)
        assert v == r['price']
        parts = r['pointer'].strip('/').split('/')
        source_row = body[parts[0]][int(parts[1])]
        t = source_row.get('t', source_row.get('timestamp', source_row.get('end_period_ts')))
        assert pd.Timestamp(t, unit='s', tz='UTC') == r['source_utc']
        offset = source_row['resolution_seconds'] if parts[0] == 'data' else 0
        assert pd.Timestamp(t+offset, unit='s', tz='UTC') == r['available_utc']
        assert r['source_utc'] <= r['available_utc'] < pd.Timestamp(r['start_time'])
        earliest = r['source_utc'] - pd.Timedelta(hours=1) if r['provider']=='kalshi' else r['source_utc']
        assert earliest >= r['information_time']
    entries = []
    for (provider, game), g in points.groupby(['provider', 'official_game_id']):
        # The first observation on each side determines the decision. A first
        # terminal/nontradable value is not replaced with a later attractive one.
        first = g.sort_values(['available_utc', 'source_utc']).groupby('class_index').head(1)
        if set(first.class_index) != {0, 1}:
            continue
        at = first.available_utc.max()
        chosen = g[g.available_utc.le(at)].sort_values(['available_utc', 'source_utc']).groupby('class_index').tail(1)
        if not chosen.price.between(0, 1, inclusive='neither').all():
            continue
        assert len(chosen) == 2
        for r in chosen.to_dict('records'):
            entries.append(r | dict(decision_utc=at, quote_age_hours=(at-r['source_utc']).total_seconds()/3600))
    frame = pd.DataFrame(entries)
    frame.to_parquet(RESULT / (label+'_entries.parquet'), index=False)
    summary = dict(at_utc=stamp(), status='PASS', source_cells_replayed=len(points), raw_responses_replayed=len(cache),
                   contracts=len(audit), requested_games=audit.groupby('provider').official_game_id.nunique().to_dict(),
                   paired_entry_games=frame.groupby('provider').official_game_id.nunique().to_dict() if len(frame) else {},
                   requests_with_errors=int(audit.failure_not_unavailability.sum()),
                   information_and_price_clock_checks=True, outcomes_not_used=True, app_changed=False,
                   limitation='A point-in-time reconstructed historical article is not a stored contemporaneous archive; available time is latest published/modified timestamp. Historical prices are references, not proof of executable fills.')
    dump(RESULT / (label+'_validation.json'), summary)
    print(json.dumps(summary), flush=True)


def test_timing():
    """Fixed earlier-period comparison; probabilities are never refitted here."""
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    validation = json.loads((RESULT / 'development_validation.json').read_bytes())
    assert validation['status'] == 'PASS'
    assert (RESULT / 'experiment_plan.json').exists()
    original = ROOT_OUT / 'simulation_results/feature_revisions/nhl_player_strength/development_predictions.parquet'
    p = pd.read_parquet(original)
    p = p[p.variant.eq('candidate')].copy()
    assert not p.game_id.duplicated().any()
    for field in ['train_label_max', 'calibration_train_label_max', 'calibration_label_max']:
        assert p[field].lt(p.prediction_time).all()
    assert set(p.prediction_time.dt.year) == {2024, 2025}
    transfer.RESULT = RESULT
    quotes = quote_inputs(RESULT / 'quote_quality.json', revision='closest_v62')
    quotes = quotes[quotes.sport.eq('nhl') & quotes.year.isin([2024, 2025])].copy()

    def select_bets(f, forecasts):
        idx = forecasts.set_index('game_id').loc[f.game_id]
        f = f.copy()
        f['secondary_probability'] = np.where(f.side.eq(0), idx.second_p0, idx.second_p1)
        return f[np.minimum(f.probability, f.secondary_probability)/f.price >= 1.10].copy()

    baseline = select_bets(transfer.normalize('nhl', p, quotes, True), p)
    entries = pd.read_parquet(RESULT / 'development_entries.parquet')
    manifest = pd.read_parquet(RESULT / 'contract_manifest.parquet')
    native = manifest[['provider', 'official_game_id', 'native_team_ids_json']].drop_duplicates()
    e = entries.merge(native, on=['provider', 'official_game_id'], validate='many_to_one')
    e = e.merge(p[['official_game_id', 'target', 'sport', 'league']], on='official_game_id', validate='many_to_one')
    e = e.rename(columns={'price': 'entry_price', 'source_utc': 'entry_source_utc',
                         'available_utc': 'entry_available_utc', 'quote_age_hours': 'entry_age_hours',
                         'pointer': 'entry_pointer'})
    e['entry_request_id'] = 'nhl_soccer_iteration:' + e.request_number.astype(str)
    e['hours_before'] = (pd.to_datetime(e.start_time, utc=True)-e.decision_utc).dt.total_seconds()/3600
    late = []
    matched = []
    for provider, q in e.groupby('provider'):
        clocks = q[['official_game_id', 'decision_utc']].drop_duplicates()
        assert not clocks.official_game_id.duplicated().any()
        forecasts = p.merge(clocks, on='official_game_id', validate='one_to_one')
        issued = forecasts.prediction_time.copy()
        assert issued.le(forecasts.decision_utc).all()
        assert forecasts.decision_utc.lt(forecasts.start_time).all()
        forecasts['prediction_time'] = forecasts.decision_utc
        old = p.set_index('game_id').loc[forecasts.game_id]
        assert np.array_equal(forecasts[['p0','p1','second_p0','second_p1']].values, old[['p0','p1','second_p0','second_p1']].values)
        # Join a quote whitelist so the price manifest cannot inject forecast
        # fields or alter official settlement clocks.
        fields = ['provider', 'sport', 'league', 'official_game_id', 'game_id', 'native_team_ids_json',
                  'target', 'class_index', 'decision_utc', 'entry_price', 'entry_source_utc',
                  'entry_available_utc', 'entry_age_hours', 'entry_request_id', 'entry_pointer',
                  'entry_contract_id', 'price_basis']
        f = select_bets(transfer.normalize('nhl', forecasts, q[fields], True), forecasts)
        f['model_stage'] = 'frozen_pre12_forecast_later_quote'
        late.append(f)
        matched.append(baseline[baseline.provider.eq(provider) & baseline.game_id.isin(forecasts.game_id)])
    cases = dict(full_pre12=baseline, matched_pre12=pd.concat(matched, ignore_index=True),
                 post_publication=pd.concat(late, ignore_index=True))
    annual, bets, days, checks = [], [], [], []
    for variant, f in cases.items():
        for provider in ['polymarket', 'kalshi']:
            g = f[f.provider.eq(provider)]
            for year in [2024, 2025]:
                m, b, l, d = engine.simulate(g, year, 'all_selected_outcomes', 'flat20_cash_only', 5., 2000.)
                key = dict(sport='nhl', provider=provider, variant=variant, year=year)
                checks.append(key | engine.validate(b, l, d, 'flat20_cash_only', 5., 2000.))
                annual.append(key | m)
                if len(b):
                    bets.append(b.assign(**key))
                days.append(d.assign(**key))
    a = pd.DataFrame(annual)
    b = pd.concat(bets, ignore_index=True)
    a.to_csv(RESULT / 'annual.csv', index=False)
    b.to_parquet(RESULT / 'bets.parquet', index=False)
    pd.concat(days, ignore_index=True).to_parquet(RESULT / 'daily.parquet', index=False)
    # The full pre12 reference must reproduce the earlier published comparison.
    ref = pd.read_parquet(ROOT_OUT / 'simulation_results/feature_revisions/nhl_duration_chances/development_bets.parquet')
    ref = ref[ref.variant.eq('control')].sort_values(['provider','game_id'])
    actual = b[b.variant.eq('full_pre12')].sort_values(['provider','game_id'])
    assert ref[['provider','game_id']].values.tolist() == actual[['provider','game_id']].values.tolist()
    assert np.allclose(ref[['stake','price','probability','profit']], actual[['stake','price','probability','profit']], atol=1e-8, rtol=0)
    decisions = []
    for provider in ['polymarket', 'kalshi']:
        g = a[a.provider.eq(provider) & a.year.eq(2025)].set_index('variant')
        old, new = g.loc['matched_pre12'], g.loc['post_publication']
        passed = bool(new.return_pct > 0 and new.return_pct > old.return_pct and new.sharpe > old.sharpe)
        decisions.append(dict(provider=provider, passed=passed,
                              pre12_return_pct=old.return_pct, later_return_pct=new.return_pct,
                              pre12_sharpe=old.sharpe, later_sharpe=new.sharpe))
    # Inspect which losses were avoided, and which wins were lost, without
    # changing any strategy rule based on these identities.
    transitions = []
    keys = ['provider', 'year', 'game_id']
    old = b[b.variant.eq('matched_pre12')].set_index(keys)
    new = b[b.variant.eq('post_publication')].set_index(keys)
    for key in sorted(set(old.index) | set(new.index)):
        before = old.loc[key] if key in old.index else None
        after = new.loc[key] if key in new.index else None
        r = before if before is not None else after
        old_realized = float(before.profit) if before is not None and not before.unsettled_at_end else 0.
        new_realized = float(after.profit) if after is not None and not after.unsettled_at_end else 0.
        transitions.append(dict(provider=key[0], game_id=key[2], year=int(key[1]), teamA=r.teamA, teamB=r.teamB,
            transition='same_side' if before is not None and after is not None and before.side == after.side else
                       'side_changed' if before is not None and after is not None else 'removed' if before is not None else 'added',
            old_won=bool(before.won) if before is not None else None, new_won=bool(after.won) if after is not None else None,
            old_profit=float(before.profit) if before is not None else 0., new_profit=float(after.profit) if after is not None else 0.,
            profit_change=(float(after.profit) if after is not None else 0.)-(float(before.profit) if before is not None else 0.),
            old_unsettled=bool(before.unsettled_at_end) if before is not None else None,
            new_unsettled=bool(after.unsettled_at_end) if after is not None else None,
            old_realized_profit=old_realized, new_realized_profit=new_realized, realized_profit_change=new_realized-old_realized))
    transitions = pd.DataFrame(transitions)
    transitions.to_csv(RESULT / 'bet_transitions.csv', index=False)
    for (provider, year), part in transitions.groupby(['provider', 'year']):
        account = a[a.provider.eq(provider) & a.year.eq(year)].set_index('variant')
        change = (account.loc['post_publication', 'return_pct']-account.loc['matched_pre12', 'return_pct'])*20
        assert np.isclose(part.realized_profit_change.sum(), change, atol=1e-8, rtol=0)
    proof = dict(at_utc=stamp(), status='PASS', original_pre12_cash_replayed=True,
                 original_forecasts_unchanged=True, training_and_calibration_precede_forecast=True,
                 late_quotes_follow_information=True, cash_checks=checks, decisions=decisions,
                 prediction_source_sha256=file_sha256(original), model_refitted=False,
                 evaluation2026_run=False, app_changed=False, adopted=False)
    dump(RESULT / 'timing_validation.json', proof)
    print(a[['provider','year','variant','funded_games','win_rate_pct','return_pct','sharpe','max_drawdown_pct']].to_string(index=False), flush=True)
    print(json.dumps(dict(stage='timing_test', decisions=decisions)), flush=True)


def finish():
    from final_pipeline import cleanup, validate as validate_app
    proof = json.loads((RESULT / 'timing_validation.json').read_bytes())
    source = json.loads((RESULT / 'development_validation.json').read_bytes())
    assert proof['status'] == source['status'] == 'PASS'
    review_sources()
    annual = pd.read_csv(RESULT / 'annual.csv')
    transitions = pd.read_csv(RESULT / 'bet_transitions.csv')
    groups = transitions.groupby(['provider', 'year', 'transition'], dropna=False).agg(
        games=('game_id','size'), old_profit=('old_profit','sum'), new_profit=('new_profit','sum'),
        profit_change=('profit_change','sum'), old_realized_profit=('old_realized_profit','sum'),
        new_realized_profit=('new_realized_profit','sum'), realized_profit_change=('realized_profit_change','sum')).reset_index()
    groups.to_csv(RESULT / 'transition_summary.csv', index=False)
    readiness = pd.read_parquet(RESULT / 'lineup_readiness.parquet')
    r25 = readiness[readiness.date.str.startswith('2025')]
    report = REPORTS / 'nhl_lineup_entry.md'
    lines = ['# NHL lineup publication and entry timing', '',
        'Loss diagnosis identified high-confidence preseason errors and larger dollar losses under edge-based sizing. Adding more historical player-strength detail failed the earlier forecast-score test. This study isolates a different question: does entering after a dated official lineup report improve the existing betting rule?', '',
        'It keeps the primary regulation/OT model and secondary regularized logistic forecasts unchanged. Those forecasts were generated with monthly expanding 2021+ history, with all training and calibration labels before each forecast. This timing-only experiment does not feed the newly published player list into the model. A content-based forecast revision must be tested separately.', '',
        'The fixed rule chooses at most one outcome by its original expected-log-growth ranking, then requires both models to give probability/purchase price at least 1.10. Every funded bet uses $20 from a $2,000 annual starting account, limited by available cash, held to recorded official settlement. No costs or spread assumptions are added. Daily unsettled positions are valued at cost; Sharpe annualizes daily account returns by sqrt(365.25).', '',
        'The later decision is the first time both sides have post-information observations, after max(pre12, publication time, modification time). Projected lineups are not confirmed starters. CLOB hourly points use their observed timestamp; retained V2 prices require the complete three-hour bucket after the information time and exclude settlement points. Kalshi uses recorded YES ask close after a whole post-information hourly candle. Provider prices retain these distinct meanings.', '',
        f"All {source['source_cells_replayed']:,} price values and source timestamps were replayed against {source['raw_responses_replayed']:,} original responses. Usable paired later prices by provider: {source['paired_entry_games']}. The current Kalshi historical cutoff was called and saved, not assumed.", '',
        f"In 2025, {int(r25.published_lead_hours.gt(0).sum()):,} of {len(r25):,} stored reports precede game start; {int(r25.usable_projected_lineup.sum()):,} also pass complete projected identity/status checks. The remaining {len(r25)-int(r25.usable_projected_lineup.sum()):,} have explicit review reasons, not a claim that the source is unavailable. Static aliases, spelling errors and conflicting listed statuses require repair. This source collection currently covers regular-season/playoff reports, so it does not directly fix the preseason loss cases.", '',
        'Three comparisons separate timing from selection: the full pre12 reference; pre12 restricted to the exact games with usable later quotes; and later entry on that same game cohort. The full reference reproduces previously saved positions, probabilities, prices, stakes and profits.', '',
        '|Provider|Year|Entry comparison|Bets|Bet win rate|Account return|Sharpe|Max drawdown|',
        '|---|---:|---|---:|---:|---:|---:|---:|']
    for r in annual.itertuples():
        fmt = lambda v, suffix='': '—' if pd.isna(v) else f'{v:.2f}{suffix}'
        lines.append(f'|{r.provider}|{r.year}|{r.variant}|{r.funded_games}|{fmt(r.win_rate_pct,"%")}|{fmt(r.return_pct,"%")}|{fmt(r.sharpe)}|{fmt(r.max_drawdown_pct,"%")}|')
    lines += ['', 'The rule was frozen before reviewing this test: later entry must improve both 2025 return and Sharpe over the same-cohort pre12 reference, with positive return. Decisions:', '']
    for d in proof['decisions']:
        lines.append(f"- {d['provider']}: {'passed the earlier-period gate' if d['passed'] else 'failed the earlier-period gate'}; no production model or app change.")
    lines += ['', 'The reason for the timing failure is visible in the position-level accounting:', '']
    for provider in ['polymarket','kalshi']:
        removed = transitions[transitions.provider.eq(provider) & transitions.year.eq(2025) & transitions.transition.eq('removed')]
        added = transitions[transitions.provider.eq(provider) & transitions.year.eq(2025) & transitions.transition.eq('added')]
        same = transitions[transitions.provider.eq(provider) & transitions.year.eq(2025) & transitions.transition.eq('same_side')]
        lines.append(f"- {provider}: waiting removed {len(removed)} original bets, including {int(removed.old_won.eq(True).sum())} winners. That removed ${removed.old_realized_profit.sum():.2f} of realized net profit. The {len(added)} newly selected bets contributed ${added.new_realized_profit.sum():.2f}; the {len(same)} unchanged-side bets changed profit by ${same.realized_profit_change.sum():.2f}.")
    lines += ['', 'Thus avoiding individual losing bets was outweighed by discarding profitable earlier opportunities. This is consistent with useful early value being priced away, but does not establish a causal reason for each price move. Waiting with a stale forecast is rejected. The next model experiment must actually use dated participant/goalie information and demonstrate better earlier-period probability scores before another later-entry evaluation.']
    lines += ['', 'Bet transitions record every removed winner as well as every avoided loser. Realized-profit attribution reconciles exactly to each annual account change; eventual outcomes of positions still unsettled at year end are kept separate. The test does not ban teams, months or known losing matches. The 2024 price sample is partial. No new 2026 candidate evaluation was run in this stage. The acquired window includes early January 1 UTC observations for late December 31 games; entries outside the tested account year are not silently moved back. Repeatedly researched 2026 results elsewhere remain retrospective rolling evaluations, not a pristine OOS test. The overall Sharpe/return target remains unmet.', '',
        'Next: repair projected identities and isolate a small number of dated lineup-strength inputs. A timing-only result cannot establish whether player content improves forecasts. Preserve the separate soccer role/replacement-quality investigation.', '',
        'Reproduce with nhl_lineup_entry.py: prepare, pilot, collect, validate, test, finish. The source manifest is restricted to 2024/25 and selected without outcomes; original raw responses remain in the acquisition store. Per-request public logs contain request number, type, intent and status; detailed provenance is internal.', '',
        'Official documentation read for this acquisition:', '']
    lines += ['- '+u for u in DOCS]
    report.write_text('\n'.join(lines)+'\n', encoding='utf8')
    path = ROOT_OUT / 'simulation_results/experiment_results.csv'
    existing = pd.read_csv(path, low_memory=False)
    key = 'nhl_lineup_entry/annual.csv'
    pd.concat([existing[~existing.source_result_file.eq(key)], annual.assign(source_result_file=key)], ignore_index=True).to_csv(path, index=False)
    path = ROOT_OUT / 'simulation_results/experiment_decisions.json'
    decisions = json.loads(path.read_bytes())
    decisions['nhl_lineup_entry'] = dict(plan=json.loads((RESULT/'experiment_plan.json').read_bytes()),
                                        source=source, decision=proof)
    dump(path, decisions)
    # Completed pilot points are exact subsets of the final acquisition. Keep
    # the pilot validation/selection receipt, not duplicate research outputs.
    removed = []
    for kind in ['points', 'entries', 'requests']:
        pilot = RESULT / ('pilot_'+kind+'.parquet')
        if not pilot.exists():
            continue
        final = pd.read_parquet(RESULT / ('development_'+kind+'.parquet'))
        old = pd.read_parquet(pilot)
        keys = ['provider', 'official_game_id', 'class_index', 'entry_contract_id']
        if kind != 'requests':
            keys += ['source_utc','available_utc','price','request_number','pointer']
        available = set(map(tuple, final[keys].to_numpy()))
        assert all(tuple(row) in available for row in old[keys].to_numpy())
        resolved = pilot.resolve(strict=True)
        assert resolved.is_relative_to(RESULT.resolve(strict=True)) and not pilot.is_symlink() and not pilot.is_junction()
        removed.append(dict(path=str(pilot.relative_to(ROOT_OUT)),sha256=file_sha256(pilot)))
        pilot.unlink()
    cleanup()
    app = validate_app()
    path = ROOT_OUT / 'retention/retained_artifacts.json'
    retained = json.loads(path.read_bytes())
    retained['scripts'] = {p.name:file_sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}
    retained.update(updated_utc=stamp(), retained_scripts=len(retained['scripts']),
                    latest_simulation_update=dict(result=str(RESULT.relative_to(ROOT_OUT)),adopted=False,report=str(report)))
    dump(path, retained)
    receipt = dict(status='PASS',at_utc=stamp(),source=source,decisions=proof['decisions'],
                   removed_duplicate_pilot_files=removed,app_validation=app,goal_achieved=False,report=str(report))
    dump(ROOT_OUT/'retention/nhl_lineup_entry_completion.json',receipt)
    path = ROOT_OUT/'research_continuation.json'
    state = json.loads(path.read_bytes())
    state.update(at_utc=stamp(),current_job=None,live_sessions=[],running_jobs=[],
                 last_action='Completed source-validated NHL post-publication price acquisition and unchanged-forecast timing comparison on2024/25. Original baseline replayed; pilot duplicate files removed.',
                 next_action='Inspect timing results; repair static projected-player aliases/status conflicts, then test a limited dated lineup-strength revision on earlier forecasts. Do not use later report content with earlier quotes. Soccer role/replacement-quality work remains pending.',report=str(report))
    state.setdefault('research_state',{})['nhl_lineup_entry']=receipt
    dump(path,state)
    print(json.dumps(receipt),flush=True)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('action', choices=['prepare', 'pilot', 'collect', 'validate', 'test', 'finish'])
    args = ap.parse_args()
    if args.action == 'prepare':
        prepare()
    elif args.action == 'validate':
        validate('development')
    elif args.action == 'test':
        test_timing()
    elif args.action == 'finish':
        finish()
    else:
        collect(args.action == 'pilot')
