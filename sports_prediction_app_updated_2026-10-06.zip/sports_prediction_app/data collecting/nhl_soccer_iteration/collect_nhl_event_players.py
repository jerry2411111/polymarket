"""Recover exact event participants from official NHL play-by-play reports.

The API supplies dated native rosters, shooter, goalie and manpower, but not the
complete on-ice player sets. Official HTML is used only for that missing field.
Strict event joins and native roster identities replace ambiguous shift timing.
Every unmatched event is retained for repair, never silently called complete.
"""
import argparse,collections,concurrent.futures,datetime as dt,hashlib,json,re,sqlite3
from html.parser import HTMLParser
import pandas as pd
from common import ROOT_OUT,PREVIOUS,PROJECT,OfficialClient,read_db,dump,stamp
from validate_shifts import text,key,seconds

VERSION=4
EVENTS={'MISS':'missed-shot','SHOT':'shot-on-goal','GOAL':'goal'}


def surname_matches(name,player):
    if key(name).endswith(key(player['lastName']['default'])):return True
    # Some historical reports spell Janmark as Janmark-Nylen. This is an
    # exact compound-surname component, with an exact first name, dated team,
    # unique jersey and position also required; it is not a fuzzy name match.
    first,separator,last=name.partition(' ')
    return bool(separator and key(first)==key(player['firstName']['default']) and
                any(key(part)==key(player['lastName']['default']) for part in last.split('-')))


class EventRows(HTMLParser):
    def __init__(self):
        super().__init__();self.rows=[];self.current=None;self.depth=0;self.cell=-1;self.font=None
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='tr':
            if self.current is not None:self.depth+=1
            elif re.fullmatch(r'PL-\d+',a.get('id','')) or a.get('class','').strip() in ('oddColor','evenColor'):
                self.current=dict(report_event_id=a.get('id'),cells=[],players={'A':[],'B':[]})
                self.depth=1;self.cell=-1
        if self.current is None:return
        if tag=='td' and self.depth==1:
            self.cell+=1;self.current['cells'].append('')
        if tag=='br' and self.cell>=0:self.current['cells'][self.cell]+=' '
        if tag=='font' and self.cell in (6,7) and ' - ' in a.get('title',''):
            self.font=dict(title=a['title'],number='',side='A' if self.cell==6 else 'B')
    def handle_data(self,data):
        if self.current is not None and self.cell>=0:self.current['cells'][self.cell]+=data
        if self.font is not None:self.font['number']+=data
    def handle_endtag(self,tag):
        if self.current is None:return
        if tag=='font' and self.font is not None:
            self.current['players'][self.font['side']].append(self.font);self.font=None
        if tag=='tr':
            self.depth-=1
            if self.depth==0:
                self.current['cells']=[' '.join(c.split()) for c in self.current['cells']]
                if self.current['report_event_id'] is None:
                    self.current['report_event_id']='printed-event-'+self.current['cells'][0]
                self.rows.append(self.current);self.current=None;self.cell=-1


def normalize(game,shots,body,report_source,pbp,pbp_source):
    markup=body.decode('utf8',errors='replace');native=str(game['official_game_id'])
    assert str(pbp['id'])==native and pbp['gameDate']==game['date'],'API game identity mismatch'
    header=re.search(r'<table[^>]*id="GameInfo".*?</table>',markup,re.S)
    numbers=re.findall(r'\bGame\s+(\d+)\b',text(header.group(0))) if header else []
    assert len(numbers)==1 and int(numbers[0])==int(native[-4:]),'Report game number mismatch'
    day=dt.date.fromisoformat(game['date'])
    assert f'{day.strftime("%B")} {day.day}, {day.year}' in text(header.group(0)),'Report date mismatch'
    for side,table in [('A','Visitor'),('B','Home')]:
        match=re.search(r'<table[^>]*id="'+table+r'".*?<img[^>]*alt="([^"]+)"',markup,re.S)
        assert match and key(match.group(1))==key(game['team'+side]),'Report team identity mismatch: '+side
    teams={s:pbp[n] for s,n in [('A','awayTeam'),('B','homeTeam')]}
    assert [teams[s]['id'] for s in ['A','B']]==[int(v) for v in json.loads(game['native_team_ids_json'])],'Dated API team ID orientation mismatch'
    abbreviations=list(dict.fromkeys(re.findall(r'>([A-Z.]{2,4}) On Ice</td>',markup)))
    assert len(abbreviations)==2,'No unique away/home on-ice column headings'
    report_sides=dict(zip(abbreviations,['A','B']))
    roster={};by_id={}
    for p in pbp['rosterSpots']:
        jersey=(int(p['teamId']),int(p['sweaterNumber']))
        assert jersey not in roster,'Duplicate jersey in dated roster'
        roster[jersey]=p;by_id[str(p['playerId'])]=p
    parser=EventRows();parser.feed(markup)
    assert parser.rows,'No event rows parsed'
    assert len({r['report_event_id'] for r in parser.rows})==len(parser.rows),'Duplicate printed report event IDs'
    lookup=collections.defaultdict(list);report_issues=[];name_forms=[]
    for r in parser.rows:
        cells=r['cells']
        if len(cells)!=8 or cells[4] not in EVENTS:continue
        try:
            period=int(cells[1]);clock=seconds(cells[3].split()[0])
            shooter=re.search(r'^([A-Z.]{2,4})\s.*?#(\d+)\b',cells[5])
            assert shooter,'No explicit shooter jersey in report'
            side=report_sides[shooter[1]]
            shooter_id=str(roster[(teams[side]['id'],int(shooter[2]))]['playerId'])
            members={};positions={}
            for s in ['A','B']:
                ids=[]
                for font in r['players'][s]:
                    number=int(font['number'].strip());player=roster[(teams[s]['id'],number)]
                    role,name=font['title'].split(' - ',1)
                    assert surname_matches(name,player),'Report/API surname conflict: '+name
                    assert (role=='Goalie')==(player['positionCode']=='G'),'Goalie identity conflict'
                    pid=str(player['playerId']);ids.append(pid);positions[pid]=player['positionCode']
                    full=player['firstName']['default']+' '+player['lastName']['default']
                    if key(name)!=key(full):name_forms.append(dict(player_id=pid,report_name=name,api_name=full,jersey=number,side=s))
                assert ids and len(ids)==len(set(ids)),'Missing or duplicate event participants'
                members[s]=ids
            lookup[(period,clock,EVENTS[cells[4]],side,shooter_id)].append(dict(report_event_id=r['report_event_id'],participants=members,positions=positions,description=cells[5]))
        except (ValueError,KeyError,AssertionError,StopIteration) as exc:
            report_issues.append(dict(report_event_id=r['report_event_id'],source_cells=cells[:6],reason=type(exc).__name__+': '+str(exc)))
    eligible=shots[shots.period_type.ne('SO')];rows=[];unmatched=[]
    for s in eligible.itertuples():
        try:
            values=lookup[(int(s.period),int(s.seconds),s.result,s.side,str(int(s.shooter_id)))]
            assert values,'No exact report event'
            assert len({json.dumps({side:sorted(r['participants'][side]) for side in ['A','B']},sort_keys=True) for r in values})==1,'Same-second report events have different participants'
            r=values[0];members=r['participants'];positions=r['positions']
            for side in ['A','B']:
                observed=sum(positions[pid]!='G' for pid in members[side])
                expected=s.attackers if side==s.side else s.defenders
                assert pd.notna(expected) and observed==int(expected),'API/report skater count conflict: '+side
            assert str(int(s.shooter_id)) in members[s.side],'Shooter absent from on-ice team'
            opposing='B' if s.side=='A' else 'A'
            if pd.notna(s.goalie_id):
                goalies=[pid for pid in members[opposing] if positions[pid]=='G']
                assert goalies==[str(int(s.goalie_id))],'API/report opposing goalie conflict'
            rows.append(dict(event_id=int(s.event_id),report_event_id=r['report_event_id'] if len(values)==1 else None,
                             report_event_ids=[v['report_event_id'] for v in values],
                             identity_basis='unique_event' if len(values)==1 else 'identical_participants_in_all_exact_same_second_candidates',
                             period=int(s.period),seconds=int(s.seconds),result=s.result,
                             shooting_side=s.side,shooter_id=str(int(s.shooter_id)),participants=members,positions=positions))
        except (ValueError,KeyError,AssertionError) as exc:
            unmatched.append(dict(event_id=int(s.event_id),period=int(s.period),seconds=int(s.seconds),result=s.result,reason=str(exc)))
    return dict(game_id=game['game_id'],official_game_id=native,date=game['date'],phase=game['phase'],available_at_utc=game['available_time'],
                rows=rows,eligible_events=len(eligible),matched_events=len(rows),unmatched_events=unmatched,report_parse_issues=report_issues,
                validated_name_variants=list({json.dumps(v,sort_keys=True):v for v in name_forms}.values()),
                sources=[report_source,pbp_source],parser_version=VERSION,
                method='Exact period, elapsed second, shot kind, team and native shooter. On-ice roster verified by dated team/jersey/surname, official manpower and goalie.')


def main():
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int);p.add_argument('--native-id',nargs='*');p.add_argument('--workers',type=int,default=3);p.add_argument('--retry',action='store_true');p.add_argument('--progress-name',default='nhl_event_players_progress');p.add_argument('--include-preseason',action='store_true');a=p.parse_args()
    assert a.progress_name.replace('_','').isalnum()
    phases="('Regular Season','Playoffs','Preseason')" if a.include_preseason else "('Regular Season','Playoffs')"
    with read_db(PREVIOUS/'expanded.sqlite') as db:games={r['game_id']:dict(r) for r in db.execute("SELECT * FROM nhl_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30' AND phase IN "+phases)}
    shots=pd.read_parquet(ROOT_OUT/'nhl_shot_detail.parquet');groups={gid:f for gid,f in shots.groupby('game_id') if gid in games}
    db=sqlite3.connect(ROOT_OUT/'nhl_event_players.sqlite',timeout=60)
    db.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT); CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,body TEXT);')
    done={r[0] for r in db.execute("SELECT game_id FROM games WHERE json_extract(body,'$.parser_version')=?",(VERSION,))}
    tasks=[g for gid,g in games.items() if gid in groups and (a.retry or gid not in done)]
    if a.native_id:tasks=[g for g in tasks if str(g['official_game_id']) in a.native_id]
    tasks.sort(key=lambda g:(g['date'],g['game_id']))
    if a.limit:tasks=tasks[:a.limit]
    client=OfficialClient(per_second=2);counts=collections.Counter();milestone=10
    def collect(g):
        source=None
        try:
            s=groups[g['game_id']];first=s.iloc[0];path=PROJECT/first.source_raw_file;raw=path.read_bytes()
            assert hashlib.sha256(raw).hexdigest()==first.source_sha256,'Raw API provenance mismatch'
            pbp=json.loads(raw);native=str(g['official_game_id']);season=int(native[:4])
            pm=dict(raw_file=first.source_raw_file,sha256=first.source_sha256,url=f'https://api-web.nhle.com/v1/gamecenter/{native}/play-by-play')
            url=f'https://www.nhl.com/scores/htmlreports/{season}{season+1}/PL{native[4:]}.HTM'
            body,source=client.get(url,'Recover exact on-ice event participants unavailable from shift boundaries: '+native,kind='official_event_participants',document=True)
            assert body is not None,'HTTP '+source['return_status']
            return g['game_id'],normalize(g,s,body,source,pbp,pm),None
        except Exception as exc:return g['game_id'],None,dict(reason=type(exc).__name__+': '+str(exc),source=source)
    progress=dict(stage='nhl_event_players',at_utc=stamp(),processed=0,total=len(tasks),percent=0. if tasks else 100.,counts={})
    dump(ROOT_OUT/(a.progress_name+'.json'),progress);print(json.dumps(progress),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
        for n,(gid,row,error) in enumerate(pool.map(collect,tasks),1):
            with db:
                if row:
                    db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(gid,json.dumps(row)))
                    db.execute('DELETE FROM issues WHERE game_id=?',(gid,))
                    counts['games']+=1;counts['matched_events']+=row['matched_events'];counts['eligible_events']+=row['eligible_events']
                    counts['unmatched_events']+=len(row['unmatched_events']);counts['report_parse_issues']+=len(row['report_parse_issues'])
                else:
                    db.execute('INSERT OR REPLACE INTO issues VALUES (?,?)',(gid,json.dumps(error)));counts['game_issues']+=1
            if n*100>=milestone*len(tasks) or n==len(tasks):
                progress=dict(at_utc=stamp(),processed=n,total=len(tasks),percent=round(100*n/len(tasks),1),counts=dict(counts))
                dump(ROOT_OUT/(a.progress_name+'.json'),progress);print(json.dumps(progress),flush=True);milestone+=10
    db.close()


if __name__=='__main__':main()
