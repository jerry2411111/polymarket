"""Recover before-shot score state and five-on-five chance composition.

Every goal is applied after its own shot. Only official regulation events with
both goalies present can enter five-on-five state statistics. Event shares avoid
inventing continuous manpower exposure from intermittent event observations.
"""
import collections,hashlib,json,sqlite3
import numpy as np
import pandas as pd
from common import PROJECT,PREVIOUS,ROOT_OUT,read_db,dump,stamp


def parse(game,raw,shot_rows,source):
    assert str(raw['id'])==str(game['official_game_id'])
    ids=[str(raw['awayTeam']['id']),str(raw['homeTeam']['id'])]
    assert ids==list(map(str,json.loads(game['native_team_ids_json'])))
    assert [raw['awayTeam']['score'],raw['homeTeam']['score']]==[game['scoreA'],game['scoreB']]
    lookup={int(r['event_id']):r for r in shot_rows};assert len(lookup)==len(shot_rows)
    goals=[0,0];rows=[];issues=[];seen=set();goal_checks=0
    for e in sorted(raw['plays'],key=lambda e:e['sortOrder']):
        pid=e['periodDescriptor'];kind=e['typeDescKey'];details=e.get('details',{})
        if pid['periodType']=='SO':continue
        event=int(e['eventId']);assert event not in seen;seen.add(event)
        if event in lookup:
            shot=lookup[event];owner=str(details['eventOwnerTeamId']);side=ids.index(owner)
            assert shot['side']==['A','B'][side] and shot['result']==kind
            assert int(shot['period'])==pid['number']
            situation=str(e.get('situationCode',''));valid=len(situation)==4 and situation.isdigit()
            five=valid and situation=='1551' and pid['periodType']=='REG'
            rows.append(dict(game_id=game['game_id'],event_id=event,side=shot['side'],period=pid['number'],seconds=shot['seconds'],
                scoreA_before=goals[0],scoreB_before=goals[1],score_difference_before=goals[side]-goals[1-side],
                five_on_five=bool(five),situation_code=situation,period_type=pid['periodType'],
                model_xg=shot['model_xg'] if pd.notna(shot['model_xg']) else None,
                repeat_shot_3s=bool(shot['repeat_shot_3s']),source=source))
        if kind=='goal':
            owner=str(details['eventOwnerTeamId']);side=ids.index(owner);goals[side]+=1
            if 'awayScore' in details and 'homeScore' in details:
                assert goals==[details['awayScore'],details['homeScore']],(event,'Goal progression disagreement')
                goal_checks+=1
    assert len(rows)==len(shot_rows),'A retained shot has no exact source event'
    final=[game['scoreA'],game['scoreB']]
    delta=[final[i]-goals[i] for i in range(2)]
    assert delta==[0,0] or (raw['periodDescriptor']['periodType']=='SO' and goals[0]==goals[1] and delta in [[1,0],[0,1]])
    teams=[]
    for side in ['A','B']:
        own=[r for r in rows if r['side']==side and r['five_on_five']]
        opp=[r for r in rows if r['side']!=side and r['five_on_five']]
        row=dict(game_id=game['game_id'],side=side,date=game['date'],available_at_utc=game['available_time'],source=source)
        for state in ['all','tied','close','leading','trailing']:
            accept=lambda difference:state=='all' or (state=='tied' and difference==0) or (state=='close' and abs(difference)<=1) or (state=='leading' and difference>0) or (state=='trailing' and difference<0)
            attack=[r for r in own if accept(r['score_difference_before'])];defence=[r for r in opp if accept(-r['score_difference_before'])]
            for direction,part in [('for',attack),('against',defence)]:
                row[state+'_attempts_'+direction]=len(part)
                row[state+'_modelled_'+direction]=sum(r['model_xg'] is not None for r in part)
                row[state+'_xg_'+direction]=sum(r['model_xg'] for r in part) if all(r['model_xg'] is not None for r in part) else None
        teams.append(row)
    return dict(game_id=game['game_id'],date=game['date'],shots=rows,teams=teams,goal_progressions_checked=goal_checks,issues=issues,source=source)


def main():
    path=ROOT_OUT/'nhl_shot_detail.parquet';shots=pd.read_parquet(path);digest=hashlib.sha256(path.read_bytes()).hexdigest()
    with read_db(PREVIOUS/'expanded.sqlite') as c:games=[dict(r) for r in c.execute("SELECT * FROM nhl_games WHERE date>='2021-01-01' AND phase IN ('Regular Season','Playoffs') ORDER BY date,game_id")]
    groups={gid:g.to_dict('records') for gid,g in shots.groupby('game_id',sort=False)}
    db=sqlite3.connect(ROOT_OUT/'nhl_score_state.sqlite',timeout=60)
    db.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT); CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,reason TEXT);')
    done={r[0] for r in db.execute('SELECT game_id FROM games')};tasks=[g for g in games if g['game_id'] not in done]
    mark=10;count=0;errors=0
    for n,g in enumerate(tasks,1):
        try:
            rows=groups[g['game_id']];source_rows={(r['source_raw_file'],r['source_sha256']) for r in rows};assert len(source_rows)==1
            file,sha=next(iter(source_rows));blob=(PROJECT/file).read_bytes();assert hashlib.sha256(blob).hexdigest()==sha
            source=dict(raw_file=file,sha256=sha,event_model_sha256=digest,url='https://api-web.nhle.com/v1/gamecenter/'+str(g['official_game_id'])+'/play-by-play')
            result=parse(g,json.loads(blob),rows,source)
            with db:
                db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(g['game_id'],json.dumps(result)));db.execute('DELETE FROM issues WHERE game_id=?',(g['game_id'],))
            count+=1
        except (AssertionError,KeyError,ValueError,TypeError) as exc:
            with db:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?)',(g['game_id'],type(exc).__name__+': '+str(exc)))
            errors+=1
        if n*100>=mark*len(tasks) or n==len(tasks):
            report=dict(at_utc=stamp(),stage='nhl_score_state',processed=n,total=len(tasks),percent=round(100*n/len(tasks),1),games=count,issues=errors)
            dump(ROOT_OUT/'nhl_score_state_progress.json',report);print(json.dumps(report),flush=True);mark+=10
    db.close()


if __name__=='__main__':main()
