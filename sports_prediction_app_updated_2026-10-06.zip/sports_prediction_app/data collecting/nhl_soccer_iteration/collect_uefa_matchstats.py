"""Current official UEFA match statistics; pilot must pass before expansion.

Endpoints observed on UEFA's own current pages, definitions read before use.
Only explicit per-match fields enter normalized tables. Seasonal totals and
seasonal rankings are deliberately excluded from historical model inputs.
"""
import argparse,concurrent.futures,hashlib,json,math,re,sqlite3
from decimal import Decimal
import pandas as pd
from common import ROOT_OUT,PREVIOUS,PROJECT,OfficialClient,read_db,dump,stamp

RUN=ROOT_OUT/'uefa_matchstats_v33'
PARSER_VERSION=6
FIELDS=['goals','assists','attempts','attempts_on_target','attempts_off_target','attempts_blocked',
 'shot_in_penalty_area','shot_outside_penalty_area','big_chance','key_passes',
 'passes_attempted','passes_completed','passes_long_attempted','passes_long_completed',
 'passes_completed_forward','passes_into_opponent_area','passes_completed_into_opponent_area',
 'delivery_into_attacking_third','delivery_into_penalty_area','run_solo_into_penalty_area',
 'cross_attempted','cross_completed','dribbling','dribbling_successful',
 'recovered_ball','recovered_balls_opposite','lost_balls','tackles','tackles_won',
 'aerialduel','aerialduel_total','clearance_attempted','clearance_completed',
 'total_ball_touches_performed_in_penalty_area','fouls_committed','yellow_cards','red_cards',
 'saves','goals_conceded','minutes_played_official','played_time','matches_appearance',
 'distance_covered','top_speed','sprints','high_intensity_runs','ball_possession','corners']


def event_scores(match,events):
 assert events and len(events)<500 and any(e['type']=='FULL_TIME' for e in events),'Complete official event response required'
 native=[match[k]['id'] for k in ('awayTeam','homeTeam')];regular={'away':0,'home':0};total=regular.copy();evidence=[]
 goals=[e for e in events if e['type']=='GOAL'];assert len({e['id'] for e in goals})==len(goals)
 for e in goals:
  assert str(e['matchId'])==str(match['id'])
  phase=e['phase'];assert phase in ['FIRST_HALF','SECOND_HALF','EXTRA_TIME_FIRST_HALF','EXTRA_TIME_SECOND_HALF'],phase
  team=e['primaryActor']['team']['id'];assert team in native
  side=native.index(team)
  if e.get('subType')=='OWN':side=1-side
  key=['away','home'][side];total[key]+=1
  if phase in ['FIRST_HALF','SECOND_HALF']:regular[key]+=1
  evidence.append(dict(event_id=e['id'],phase=phase,time=e.get('time'),credited_side=key,own_goal=e.get('subType')=='OWN'))
 assert total==match['score']['total'],'Official goal events must reconcile to full-match total'
 return regular,evidence


def normalize(game,match,lineup,team,players,sources,events=None):
 assert match['id']==str(game['official_game_id']) and match['status']=='FINISHED'
 competition={'UEFA Champions League':'1','UEFA Nations League':'2014','UEFA Europa League':'14','UEFA Conference League':'2019'}[game['league']]
 assert str(match['competition']['id'])==competition
 assert pd.Timestamp(match['kickOffTime']['dateTime'])==pd.Timestamp(game['start_time'])
 native=list(map(str,json.loads(game['native_team_ids_json'])))
 assert [match[k]['id'] for k in ('awayTeam','homeTeam')]==native
 scores=match['score'].get('regular',match['score']['total']);score_evidence=None
 if [scores['away'],scores['home']]!=[game['scoreA'],game['scoreB']]:
  scores,score_evidence=event_scores(match,events)
 assert [scores['away'],scores['home']]==[game['scoreA'],game['scoreB']],'Retained regulation score disagrees with independent official score evidence'
 assert str(lineup['matchId'])==str(game['official_game_id'])
 identities={};teams={};discrepancies=[]
 if score_evidence:discrepancies.append(dict(actor='regulation_score',raw_match_score=match['score'],retained_regulation_score=scores,event_evidence=score_evidence,reason='Current regular field conflicts with completed official goal events; retain event-verified regulation score'))
 for side,key in [('A','awayTeam'),('B','homeTeam')]:
  t=lineup[key];tid=str(t['team']['id']);assert tid==native[0 if side=='A' else 1]
  name=match[key]['translations']['displayOfficialName']['EN'];teams[tid]=(side,name)
  for group in ('field','bench'):
   for r in t.get(group,[]):
    p=r['player'];pid=str(p['id']);assert pid not in identities
    identities[pid]=dict(side=side,team_id=tid,team_name=name,player_name=p.get('internationalName') or p['translations']['name']['EN'],position=p.get('fieldPosition'),lineup_group=group)
 matching=[r for r in team if str(r.get('teamId')) in native]
 assert len(matching)==2 and {r['teamId'] for r in matching}==set(native),'Need one statistic record for each official fixture team'
 out={'players':[],'teams':[],'unresolved_actor_rows':[]};seen=set();checks=0
 for actor,records in [('teams',team),('players',players)]:
  source=sources[actor]
  for i,r in enumerate(records):
   if str(r.get('teamId')) not in teams:
    # An extraneous statistics actor must not erase the valid dated participants.
    # Keep the exact raw pointer; never guess affiliation or invent a name.
    out['unresolved_actor_rows'].append(dict(actor=actor,player_id=r.get('playerId'),team_id=r.get('teamId'),source_request=source['request_number'],source_pointer='/'+str(i),
      reason='Statistics row has absent or nonparticipating team ID; reconciliation with dated fixture/lineup is required before use',source_raw_file=source['raw_file']))
    continue
   assert r.get('idProvider')=='FAME' and str(r['teamId']) in teams
   tid=str(r['teamId']);side,tname=teams[tid];pid=str(r['playerId']) if actor=='players' else None
   key=(actor,tid,pid);assert key not in seen;seen.add(key)
   verified=pid in identities and identities[pid]['team_id']==tid if pid else True
   row=dict(game_id=game['game_id'],official_game_id=str(game['official_game_id']),league=game['league'],date=game['date'],
    start_utc=match['kickOffTime']['dateTime'],available_at_utc=game['available_time'],side=side,team_id=tid,team_name=tname,
    source_request=source['request_number'],source_pointer='/'+str(i),source_raw_file=source['raw_file'],source_sha256=source['sha256'])
   if pid:
    row.update(official_player_id=pid,lineup_identity_verified=verified,player_name=None,position=None,lineup_group=None)
    if verified:row.update(**{k:v for k,v in identities[pid].items() if k not in ['side','team_id','team_name']})
    else:discrepancies.append(dict(actor='player_identity',team_id=tid,player_id=pid,reason='Statistics ID not present on the same dated team lineup. Raw values retained; ineligible for model use until independently reconciled.'))
   groups={}
   for j,s in enumerate(r['statistics']):groups.setdefault(s['name'],[]).append((j,s))
   stats={};ambiguous={}
   for name,values in groups.items():
    if len(values)==1 or all(s==values[0][1] for _,s in values):stats[name]=values[0]
    else:ambiguous[name]=values
    if len(values)>1:discrepancies.append(dict(actor=actor,team_id=tid,player_id=pid,field=name,reason='Conflicting duplicate field excluded' if name in ambiguous else 'Identical duplicate field retained once',source_pointers=[f'/{i}/statistics/{j}' for j,_ in values]))
   raw={};units={};evidence={}
   for field in FIELDS:
    row[field]=None
    if field in ambiguous:
     raw[field]=[s.get('value') for _,s in ambiguous[field]];units[field]=[s.get('unit') for _,s in ambiguous[field]]
     evidence[field]=dict(ambiguous=True,pointers=[f'/{i}/statistics/{j}/value' for j,_ in ambiguous[field]])
     continue
    if field not in stats:continue
    j,s=stats[field];value=s.get('value');raw[field]=value;units[field]=s.get('unit')
    evidence[field]=dict(pointer=f'/{i}/statistics/{j}/value',attributes=s.get('attributes'))
    if value is None or value=='':continue
    number=Decimal(str(value));assert number.is_finite() and number>=0
    row[field]=float(number);checks+=1
   # Official elapsed exposure is distinct from rounded regulation minutes.
   attrs=stats.get('played_time',(None,{}))[1].get('attributes',{});numeric_seconds=None;clock_seconds=None;time_issues=[]
   if attrs.get('TotalSeconds') is not None:
    value=Decimal(str(attrs['TotalSeconds']))
    if value.is_finite() and value>=0 and value==int(value):numeric_seconds=int(value)
    else:time_issues.append('Invalid numeric TotalSeconds')
   clock=attrs.get('TotalMinutesAndSeconds')
   if clock:
    parsed=re.fullmatch(r'''\s*(?:(\d+)['\u2019\u2032])?(\d{1,2})["\u201d\u2033]\s*''',str(clock))
    if parsed and int(parsed[2])<60:clock_seconds=60*int(parsed[1] or 0)+int(parsed[2])
    else:time_issues.append('Unrecognized TotalMinutesAndSeconds clock')
   if numeric_seconds is not None and clock_seconds is not None and numeric_seconds!=clock_seconds:time_issues.append('Numeric seconds and display clock differ; preserve numeric TotalSeconds and retain both raw values')
   row['played_seconds_including_stoppage']=numeric_seconds if numeric_seconds is not None else clock_seconds
   if time_issues:discrepancies.append(dict(actor=actor,team_id=tid,player_id=pid,field='played_seconds_including_stoppage',source_attributes=attrs,reasons=time_issues))
   row['raw_values_json']=json.dumps(raw,sort_keys=True);row['source_units_json']=json.dumps(units,sort_keys=True);row['field_evidence_json']=json.dumps(evidence,sort_keys=True)
   for a,b in [('passes_completed','passes_attempted'),('tackles_won','tackles'),('dribbling_successful','dribbling'),('attempts_on_target','attempts')]:
    if row[a] is not None and row[b] is not None and row[a]>row[b]:discrepancies.append(dict(actor=actor,team_id=tid,player_id=pid,field=a,value=row[a],comparison_field=b,comparison_value=row[b]))
   if actor=='teams':
    expected=match['score']['total']['away' if side=='A' else 'home']
    if row['goals'] is None:discrepancies.append(dict(actor=actor,team_id=tid,field='goals',reason='No unambiguous team-stat goals; official match result verified separately',official_match_goals=expected))
    else:assert row['goals']==expected,'Team match statistics disagree with final goals'
   out[actor].append(row)
 # Reconcile sums without silently forcing conflicting source definitions equal.
 for t in out['teams']:
  people=[r for r in out['players'] if r['team_id']==t['team_id']]
  for field in ['passes_completed','passes_attempted','attempts','assists','saves','recovered_ball']:
   observed=[r[field] for r in people]
   if t[field] is not None and all(v is not None for v in observed) and sum(observed)!=t[field]:
    discrepancies.append(dict(actor='player_team_sum',team_id=t['team_id'],field=field,player_sum=sum(observed),team_value=t[field]))
 return dict(**out,parser_version=PARSER_VERSION,discrepancies=discrepancies,source_links=sources,raw_normalized_cells_checked=checks,
  game_validation=dict(game_id=game['game_id'],official_game_id=game['official_game_id'],date=game['date'],start_utc=match['kickOffTime']['dateTime'],
    teamA=teams[native[0]][1],teamB=teams[native[1]][1],regulation_scores=scores,total_scores=match['score']['total'],regulation_event_evidence=score_evidence,
    public_url='https://www.uefa.com/'+{'1':'uefachampionsleague','2014':'uefanationsleague','14':'uefaeuropaleague','2019':'uefaconferenceleague'}[competition]+'/match/'+str(game['official_game_id'])+'/statistics/',native_id_match=True,start_match=True,score_match=True))


def fetch_verified(g,client):
 native=str(g['official_game_id']);sources={};data={}
 endpoints={'match':'https://match.uefa.com/v5/matches?matchId='+native,'lineup':'https://match.uefa.com/v5/matches/'+native+'/lineups',
  'teams':'https://matchstats.uefa.com/v2/team-statistics/'+native,'players':'https://matchstats.uefa.com/v2/player-statistics/'+native}
 try:
  for key,url in endpoints.items():
   d,s=client.get(url,'Dated UEFA '+key+' facts for '+g['date']+' match '+native,kind='official_match_statistics');sources[key]=s
   if d is None:raise ValueError(key+' request '+s['return_status'])
   data[key]=d
  matches=data['match'];assert len(matches)==1
  assert data['teams'] and data['players'],'Official match-statistics response contains no records'
  events=None;score=matches[0]['score'].get('regular',matches[0]['score']['total'])
  if [score['away'],score['home']]!=[g['scoreA'],g['scoreB']]:
   events,source=client.get('https://match.uefa.com/v5/matches/'+native+'/events?filter=ALL&limit=500&offset=0&order=ASC','Reconcile regulation and extra-time goals for '+native,kind='official_goal_event_validation');sources['events']=source
  return g['game_id'],normalize(g,matches[0],data['lineup'],data['teams'],data['players'],sources,events),None,sources
 except Exception as exc:return g['game_id'],None,type(exc).__name__+': '+str(exc),sources


def main():
 p=argparse.ArgumentParser();p.add_argument('--full',action='store_true');p.add_argument('--limit',type=int);p.add_argument('--workers',type=int,default=3);p.add_argument('--from-date',default='2021-01-01');p.add_argument('--through-date',default='2026-09-30');a=p.parse_args()
 assert '2021-01-01'<=a.from_date<=a.through_date<='2026-09-30'
 RUN.mkdir(exist_ok=True)
 if a.full:assert json.loads((RUN/'pilot_validation.json').read_bytes())['status']=='PASS','Pilot validation is required before expansion'
 client=OfficialClient(per_second=2)
 definitions,ds=client.get('https://compstats.uefa.com/v2/definitions','Current official UEFA per-statistic definitions',kind='official_api_definitions')
 assert isinstance(definitions,list);dump(RUN/'statistic_definitions_source.json',ds)
 pd.DataFrame([dict(name=r['name'],description=r.get('description'),aggregation=r.get('aggregationType'),actors=';'.join(r.get('actors',[]))) for r in definitions if r['name'] in FIELDS]).to_csv(RUN/'statistic_definitions.csv',index=False)
 with read_db(PREVIOUS/'expanded.sqlite') as db:
  games=[dict(r) for r in db.execute("SELECT * FROM soccer_games WHERE league='UEFA Champions League' AND date BETWEEN '2021-01-01' AND '2026-09-30' ORDER BY date,game_id")]
 if not a.full:games=[g for g in games if str(g['official_game_id']) in ['2032674','2042017','2047742']];assert len(games)==3
 else:games=[g for g in games if a.from_date<=g['date']<=a.through_date]
 db=sqlite3.connect(RUN/'match_statistics.sqlite');db.executescript('CREATE TABLE IF NOT EXISTS games(game_id TEXT PRIMARY KEY,body TEXT);CREATE TABLE IF NOT EXISTS issues(game_id TEXT PRIMARY KEY,checked_utc TEXT,reason TEXT,sources TEXT);')
 done={r[0] for r in db.execute("SELECT game_id FROM games WHERE json_extract(body,'$.parser_version')=?",(PARSER_VERSION,))};tasks=[g for g in games if g['game_id'] not in done]
 if a.limit:tasks=tasks[:a.limit]
 def fetch(g):return fetch_verified(g,client)
 initial=dict(stage='uefa_matchstats_collection',pilot=not a.full,total=len(tasks),retained=len(done),from_date=a.from_date,through_date=a.through_date)
 dump(RUN/'collection_progress.json',initial|dict(at_utc=stamp(),processed=0,percent=0 if tasks else 100));print(json.dumps(initial),flush=True)
 milestone=10;counts={'games':0,'players':0,'issues':0}
 with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
  for n,(gid,record,error,sources) in enumerate(pool.map(fetch,tasks),1):
   with db:
    if record:
     db.execute('INSERT OR REPLACE INTO games VALUES (?,?)',(gid,json.dumps(record,allow_nan=False)));db.execute('DELETE FROM issues WHERE game_id=?',(gid,));counts['games']+=1;counts['players']+=len(record['players'])
    else:db.execute('INSERT OR REPLACE INTO issues VALUES (?,?,?,?)',(gid,stamp(),error,json.dumps(sources)));counts['issues']+=1
   if n*100>=milestone*len(tasks) or n==len(tasks):
    progress=initial|dict(at_utc=stamp(),processed=n,percent=round(n*100/len(tasks),1),counts=counts)
    dump(RUN/'collection_progress.json',progress)
    if a.full:dump(RUN/('collection_'+a.from_date+'_'+a.through_date+'_progress.json'),progress)
    print(json.dumps(progress),flush=True);milestone+=10
 records=[json.loads(b) for b, in db.execute('SELECT body FROM games')]
 for actor in ['players','teams']:
  f=pd.DataFrame([r for g in records for r in g[actor]])
  if not f.empty:f.to_parquet(RUN/('uefa_match_'+actor+'.parquet'),index=False);f.to_csv(RUN/('uefa_match_'+actor+'.csv'),index=False)
 dump(RUN/'source_discrepancies.json',[g['game_validation']|dict(discrepancies=g['discrepancies']) for g in records if g['discrepancies']])
 db.close()


if __name__=='__main__':main()
