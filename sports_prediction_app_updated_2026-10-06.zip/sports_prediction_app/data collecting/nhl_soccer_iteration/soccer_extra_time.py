"""Past-only extra-time forecasts for UEFA ties where extra time is permitted.

Separate from a 90-minute draw and from the existing winner model. Source
outcomes are retained official phase observations; this module never invents
an extra-time contract price from a draw contract.
"""
import argparse
import collections
import json
import sqlite3
import numpy as np
import pandas as pd
from scipy.special import logit
from scipy.stats import poisson, skellam
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, brier_score_loss, roc_auc_score, average_precision_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from common import ROOT_OUT, PREVIOUS, PROJECT, read_db, dump, stamp, file_sha256

TABLE='soccer_extra_time_features'
OUT=ROOT_OUT/'simulation_results/soccer_extra_time'
RULES={
 'ucl_current':'https://documents.uefa.com/r/Regulations-of-the-UEFA-Champions-League-2026/27/Article-21-Knockout-system-extra-time-and-penalty-shoot-outs-Online',
 'ucl_change':'https://www.uefa.com/uefachampionsleague/news/026a-1298aeb73a7a-5b64cb68d920-1000--abolition-of-away-goals-rule-in-all-uefa-club-competitions/',
 'nations_current':'https://documents.uefa.com/r/Regulations-of-the-UEFA-Nations-League-2024/25/Article-18-Extra-time-and-penalty-shoot-outs-Online',
 'nations_2021':'https://editorial.uefa.com/resources/0256-0f842fa4944a-f636da185247-1000/regulations_of_the_uefa_nations_league_2020_21.pdf'}
FEATURES=['logit_score_probability','aggregate_gap_squared','log_expected_total']


def sources(additional=False):
    from features import LEAGUE_CODE
    phases=pd.read_parquet(ROOT_OUT/'soccer_match_phase_observations.parquet')
    legs=pd.read_parquet(ROOT_OUT/'soccer_second_leg_context.parquet').set_index('game_id')
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        g=pd.read_sql_query("SELECT game_id,league,start_time,available_time,native_team_ids_json,scoreA,scoreB FROM soccer_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30'",db)
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
        registry={(code,str(native)):json.loads(body)['team_id'] for code,native,body in db.execute('SELECT * FROM _eu_team_identity')}
    ids=g.native_team_ids_json.map(json.loads)
    for side,n in [('A',0),('B',1)]:
        g['key'+side]=[registry.get((LEAGUE_CODE.get(league),str(pair[n])),league+':'+str(pair[n])) for league,pair in zip(g.league,ids)]
    # Nations histories are kept distinct from clubs. The same native team ID
    # carries across its Nations seasons, without future player affiliations.
    nations=phases[phases.league.eq('UEFA Nations League')]
    n=nations[['game_id','league','start_time','available_time','regulation_scoreA','regulation_scoreB']].rename(columns={'regulation_scoreA':'scoreA','regulation_scoreB':'scoreB'}).copy()
    for side in ['A','B']:n['key'+side]='NATION:'+nations['team'+side+'_id'].astype(str)
    assert not set(g.game_id)&set(n.game_id)
    g=pd.concat([g.drop(columns='native_team_ids_json'),n],ignore_index=True)
    native=phases.set_index('game_id');g=g.set_index('game_id')
    assert set(phases.game_id).issubset(g.index)
    # Regulation goals, not an extra-time or shoot-out final score.
    for side in ['A','B']:g.loc[native.index,'score'+side]=native['regulation_score'+side]
    g.loc[native.index,'available_time']=native.available_time
    g=g.reset_index()
    if additional:
        validation=json.loads((ROOT_OUT/'retention/uefa_additional_club_history_validation.json').read_bytes())
        assert validation['status']=='PASS'
        path=ROOT_OUT/'soccer_additional_club_results.parquet';assert file_sha256(path)==validation['output_sha256']
        extra=pd.read_parquet(path)
        extra=extra.rename(columns={'regulation_scoreA':'scoreA','regulation_scoreB':'scoreB'})
        for side in ['A','B']:
            extra['key'+side]=[registry.get(('UCL',str(native)),'UEFA Champions League:'+str(native)) for native in extra['team'+side+'_id']]
        assert not set(extra.game_id)&set(g.game_id)
        g=pd.concat([g,extra[g.columns]],ignore_index=True)
    for c in ['start_time','available_time']:g[c]=pd.to_datetime(g[c],utc=True,format='mixed')
    assert g.game_id.is_unique and g[['scoreA','scoreB']].notna().all().all()
    assert g.available_time.gt(g.start_time).all()
    phases=phases.copy();phases['start_time']=pd.to_datetime(phases.start_time,utc=True)
    phases['prediction_time']=phases.start_time-pd.Timedelta(hours=12)
    phases['available_time']=pd.to_datetime(phases.available_time,utc=True,format='mixed')
    third=phases.league.eq('UEFA Nations League')&phases.round_name.str.lower().str.contains('third|3rd')
    eligible=phases.match_type.isin(['SECOND_LEG','SINGLE'])&~third
    assert not phases.loc[~eligible,'went_to_extra_time'].any()
    return g,phases,legs,eligible


def build(g,phases,legs,eligible,history_end=None):
    histories=collections.defaultdict(lambda:collections.deque(maxlen=60))
    league_goals=collections.defaultdict(lambda:[0.,0.,0])
    historical=g if history_end is None else g[g.available_time.lt(history_end)]
    events=historical.sort_values(['available_time','game_id']).to_dict('records');pos=0;rows=[];league_latest={}
    indexed=g.set_index('game_id')
    for r in phases[eligible].sort_values(['prediction_time','game_id']).itertuples():
        cut=r.prediction_time
        while pos<len(events) and events[pos]['available_time']<cut:
            old=events[pos];pos+=1
            for side,opp in [('A','B'),('B','A')]:
                histories[old['key'+side]].append(dict(game_id=old['game_id'],available_time=old['available_time'],
                    scored=float(old['score'+side]),conceded=float(old['score'+opp])))
            totals=league_goals[old['league']];totals[0]+=old['scoreA'];totals[1]+=old['scoreB'];totals[2]+=1
            league_latest[old['league']]=old['available_time']
            totals=league_goals['_ALL_'];totals[0]+=old['scoreA'];totals[1]+=old['scoreB'];totals[2]+=1
            league_latest['_ALL_']=old['available_time']
        match=indexed.loc[r.game_id];lg=league_goals[r.league]
        baseline_key=r.league if lg[2]>0 else '_ALL_'
        lg=league_goals[baseline_key]
        assert lg[2]>0, 'Observed scoring history required; do not substitute guessed rates'
        away_mean,home_mean=lg[0]/lg[2],lg[1]/lg[2];base=(away_mean+home_mean)/2
        means={};sources=[];counts=[]
        for side in ['A','B']:
            h=list(histories[match['key'+side]]);counts.append(len(h));sources.extend(h)
            weights=np.power(.94,np.arange(len(h))[::-1])
            means[side]={field:(sum(w*x[field] for w,x in zip(weights,h))+5*base)/(sum(weights)+5) for field in ['scored','conceded']}
        muA=away_mean*(means['A']['scored']/base)*(means['B']['conceded']/base)
        muB=home_mean*(means['B']['scored']/base)*(means['A']['conceded']/base)
        assert min(muA,muB)>0
        second=r.match_type=='SECOND_LEG';lead=0;priorA=priorB=0
        if second:
            previous=legs.loc[r.game_id]
            assert pd.Timestamp(previous.first_leg_end_time)<cut
            priorA=int(previous.teamA_first_leg_goals);priorB=int(previous.teamB_first_leg_goals);lead=priorB-priorA
        old_rule=r.league=='UEFA Champions League' and r.start_time<pd.Timestamp('2021-06-22',tz='UTC') and second
        # Before abolition, both aggregate and away goals had to be level.
        mechanical=float(poisson.pmf(priorB,muA)*poisson.pmf(priorA,muB)) if old_rule else float(skellam.pmf(-lead,muB,muA))
        observed=(r.regulation_scoreA==priorB and r.regulation_scoreB==priorA) if old_rule else (r.regulation_scoreB-r.regulation_scoreA+lead==0)
        assert observed==bool(r.went_to_extra_time),(r.game_id,'rule and official phase disagree')
        latest=max([league_latest[baseline_key]]+[x['available_time'] for x in sources])
        assert latest<cut
        rows.append(dict(game_id=r.game_id,official_game_id=r.official_game_id,league=r.league,
            start_time=r.start_time,prediction_time=cut,available_time=r.available_time,
            match_type=r.match_type,away_goals_rule=old_rule,prior_home_aggregate_lead=lead,
            scoring_baseline='competition_history' if baseline_key!='_ALL_' else 'pooled_observed_history',
            teamA_prior_games=counts[0],teamB_prior_games=counts[1],
            expected_goalsA=muA,expected_goalsB=muB,score_probability=mechanical,
            logit_score_probability=float(logit(np.clip(mechanical,1e-8,1-1e-8))),
            aggregate_gap_squared=float((muB-muA+lead)**2),log_expected_total=float(np.log(muA+muB)),
            target_extra_time=int(r.went_to_extra_time),source_max_available_utc=latest,
            source_game_ids_json=json.dumps(sorted({x['game_id'] for x in sources})),
            source_json=json.dumps(dict(phase_table='soccer_match_phase_observations',first_leg_table='soccer_second_leg_context',
                score_history='soccer_games in soccer_nhl_granular/expanded.sqlite plus official UEFA regulation scores',
                additional_club_table='soccer_additional_club_results' if g.game_id.str.startswith(('HIST_UEL_','HIST_UECL_')).any() else None,
                rules=RULES),sort_keys=True)))
    return pd.DataFrame(rows)


def publish(f):
    meaning={
        'game_id':('Canonical match identifier','identifier'),
        'official_game_id':('UEFA native match identifier','identifier'),
        'league':('Actual UEFA competition','category'),
        'start_time':('Official kickoff','UTC timestamp'),
        'prediction_time':('Twelve hours before kickoff','UTC timestamp'),
        'available_time':('Official result availability; label only','UTC timestamp'),
        'match_type':('Second leg or single knockout match; structurally ineligible matches excluded','category'),
        'away_goals_rule':('Whether pre-2021/22 UEFA club away-goals rule applies','boolean'),
        'prior_home_aggregate_lead':('Home minus away aggregate goals before this match; zero in a single tie','goals'),
        'scoring_baseline':('Past competition mean; pooled observed prior games only when that competition has no earlier records','category'),
        'teamA_prior_games':('Away team prior games in capped 60-game history','games'),
        'teamB_prior_games':('Home team prior games in capped 60-game history','games'),
        'expected_goalsA':('Derived away regulation goal rate from past attack/defence and competition scoring','expected goals'),
        'expected_goalsB':('Derived home regulation goal rate from past attack/defence and competition scoring','expected goals'),
        'score_probability':('Poisson/Skellam probability of the score condition requiring extra time; estimate, not observed truth','probability 0-1'),
        'logit_score_probability':('Log odds of score_probability, with numerical clipping at 1e-8','log odds'),
        'aggregate_gap_squared':('Squared expected aggregate margin after regulation','goals squared'),
        'log_expected_total':('Natural log of expected combined regulation goals','log goals'),
        'target_extra_time':('Official extra-time occurrence; outcome label excluded from predictors','0/1'),
        'source_max_available_utc':('Latest team/competition-history source clock; strictly earlier than prediction_time','UTC timestamp'),
        'source_game_ids_json':('Prior games contributing team attack/defence; competition baseline also uses strictly prior games','JSON identifiers'),
        'source_json':('Traceable source tables and official rules','JSON')}
    assert set(f)==set(meaning) and not f.isna().any().any()
    f.to_parquet(ROOT_OUT/(TABLE+'.parquet'),index=False);f.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    sql=f.copy()
    for c in ['start_time','prediction_time','available_time','source_max_available_utc']:sql[c]=sql[c].astype(str)
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        sql.to_sql(TABLE,db,if_exists='replace',index=False)
        for name in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+name+' WHERE [table]=?',(TABLE,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(TABLE,len(f),len(f.columns)))
        for c in f:
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(TABLE,c,*meaning[c],
                'Official UEFA phase/first-leg responses and official league game results. Derived histories use only available past games; five league-average pseudo-games, 0.94 per-game decay, maximum 60 games.'))
            db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(TABLE,c,len(f),0,0.))
    from publish import main
    main()


def metric(f):
    rows=[]
    for (variant,year),g in f.groupby(['variant','year']):
        y=g.target_extra_time.to_numpy();p=g.probability.to_numpy();pred=p>=.5
        tp=int((pred&(y==1)).sum());fp=int((pred&(y==0)).sum());fn=int((~pred&(y==1)).sum())
        rows.append(dict(variant=variant,year=int(year),games=len(g),extra_time_games=int(y.sum()),
            log_loss=log_loss(y,p,labels=[0,1]),brier=brier_score_loss(y,p),
            roc_auc=roc_auc_score(y,p) if len(set(y))==2 else None,
            average_precision=average_precision_score(y,p),prevalence=float(y.mean()),
            mean_probability=float(p.mean()),accuracy=float((pred==y).mean()),
            extra_time_recall=tp/(tp+fn) if tp+fn else None,extra_time_precision=tp/(tp+fp) if tp+fp else None,
            positive_predictions=int(pred.sum())))
    return pd.DataFrame(rows)


def forecast(f,years,variants):
    predictions=[];replays=0
    target=f[f.prediction_time.dt.year.isin(years)]
    for fold,observed in target.groupby(target.prediction_time.dt.strftime('%Y-%m')):
        boundary=pd.Timestamp(fold+'-01',tz='UTC');training=f[f.available_time.lt(boundary)]
        assert len(training)>=100 and training.target_extra_time.sum()>=10
        assert training.available_time.max()<observed.prediction_time.min()
        y=training.target_extra_time.to_numpy();rate=(y.sum()+1)/(len(y)+2)
        for variant in variants:
            if variant=='historical_rate':p=np.full(len(observed),rate)
            elif variant=='score_condition':p=observed.score_probability.to_numpy()
            else:
                # Few labels: a fixed, strongly regularized 3-input model.
                model=make_pipeline(StandardScaler(),LogisticRegression(C=.1,max_iter=2000))
                model.fit(training[FEATURES],y);p=model.predict_proba(observed[FEATURES])[:,1]
                replay=model.predict_proba(observed[FEATURES].head(3))[:,1]
                assert np.array_equal(replay,p[:3]);replays+=len(replay)
            row=observed[['game_id','league','prediction_time','available_time','target_extra_time']].copy()
            row['variant']=variant;row['fold']=fold;row['year']=row.prediction_time.dt.year
            row['probability']=p;row['training_games']=len(training);row['training_positives']=int(y.sum())
            row['train_label_max']=training.available_time.max();predictions.append(row)
    return pd.concat(predictions,ignore_index=True),replays


def main(additional=False):
    global OUT,TABLE
    original=OUT
    if additional:
        OUT=original/'club_history';TABLE='soccer_extra_time_club_features'
    assert not (OUT/'validation.json').exists();OUT.mkdir(exist_ok=True)
    dump(OUT/'experiment_plan.json',dict(at_utc=stamp(),hypothesis='Forecast an aggregate tie requiring extra time, not a 90-minute draw. Existing winner model is near50.7% in2026; test a different, rule-defined target.',
        source_rules=RULES,history_from='2021-01-01',rolling_forecasts_from='2024-01-01',
        scope='Only extra-time-eligible UEFA knockout matches. Nations third place, group games and first legs cannot pad accuracy.',
        candidates=['score_condition','logistic_shape'],features=FEATURES,model='Monthly expanding logistic C0.1; training-only standardization; no market input, weight search or class rebalancing.',
        rates='Past-only 0.94-per-game EW attack/defence, last60 matches, five competition-average pseudo-games; home/away league mean from all previously available matches. A competition with zero prior records uses the observed pooled mean and is explicitly labelled; no guessed goal rate.',
        gate='Lower pooled2024/25 logloss AND Brier than expanding historical occurrence rate. Best logloss among passing candidates. Inspect positive-class recall/AP, not raw accuracy alone.',
        evaluation='Only development winner evaluated2026, if any;2026is retrospectively researched, not an untouched strategy holdout.',
        betting='No simulation unless a real, correctly resolved extra-time contract and dated price are acquired. Never reuse a draw price.',app_changed=False))
    if additional:
        plan=json.loads((OUT/'experiment_plan.json').read_bytes())
        plan.update(hypothesis='Replace sparse club histories with additional official Europa/Conference prior results; same model formulas, decay, shrinkage and target fixtures.',
            additional_source_sha256=file_sha256(ROOT_OUT/'soccer_additional_club_results.parquet'),
            gate='Candidate must beat BOTH historical-rate baseline and previously selected score_condition on pooled2024/25 logloss AND Brier before2026evaluation.',
            underlying_problem='Several clubs have1-7 prior matches in the original six-competition history. This changes observations, not an outcome-dependent exclusion.')
        dump(OUT/'experiment_plan.json',plan)
    g,phases,legs,eligible=sources(additional);f=build(g,phases,legs,eligible)
    cutoff=pd.Timestamp('2025-01-01',tz='UTC');prior=phases.prediction_time.lt(cutoff)
    prefix=build(g,phases[prior],legs,eligible[prior],history_end=cutoff)
    expected=f[f.prediction_time.lt(cutoff)].reset_index(drop=True)
    pd.testing.assert_frame_equal(prefix.reset_index(drop=True),expected,check_exact=True)
    publish(f)
    dev,replays=forecast(f,[2024,2025],['historical_rate','score_condition','logistic_shape'])
    dev.to_parquet(OUT/'development_predictions.parquet',index=False);metric(dev).to_csv(OUT/'development_metrics.csv',index=False)
    score=[]
    for variant,h in dev.groupby('variant'):
        score.append(dict(variant=variant,log_loss=log_loss(h.target_extra_time,h.probability,labels=[0,1]),brier=brier_score_loss(h.target_extra_time,h.probability)))
    score=pd.DataFrame(score).set_index('variant');baseline=score.loc['historical_rate']
    good=score[(score.log_loss<baseline.log_loss)&(score.brier<baseline.brier)].sort_values('log_loss')
    if additional:
        old=pd.read_parquet(original/'development_predictions.parquet')
        chosen_before=json.loads((original/'selection.json').read_bytes())['chosen']
        reference=old[old.variant.eq(chosen_before)]
        assert set(reference.game_id)==set(dev.game_id)
        loss=log_loss(reference.target_extra_time,reference.probability,labels=[0,1]);bs=brier_score_loss(reference.target_extra_time,reference.probability)
        good=good[(good.log_loss<loss)&(good.brier<bs)]
        oldf=pd.read_parquet(ROOT_OUT/'soccer_extra_time_features.parquet').set_index('game_id')
        assert set(oldf.index)==set(f.game_id)
        counts=f.set_index('game_id')[['teamA_prior_games','teamB_prior_games']]-oldf[['teamA_prior_games','teamB_prior_games']]
        counts.reset_index().to_csv(OUT/'prior_history_increase.csv',index=False)
    chosen=str(good.index[0]) if len(good) else None
    selection=dict(at_utc=stamp(),chosen=chosen,pooled_scores=score.reset_index().to_dict('records'),
        adopted=False,rare_outcome_accuracy_not_sufficient=True)
    dump(OUT/'selection.json',selection)
    evaluation=None
    if chosen:
        evaluation,checks=forecast(f,[2026],['historical_rate',chosen]);replays+=checks
        evaluation.to_parquet(OUT/'evaluation_predictions.parquet',index=False);metric(evaluation).to_csv(OUT/'evaluation_metrics.csv',index=False)
    validation=dict(status='PASS',at_utc=stamp(),input_rows=len(f),eligible_extra_time_games=int(f.target_extra_time.sum()),
        structural_noneligible_excluded=int((~eligible).sum()),zero_missing_fields=True,
        prefix_invariant_rows=len(prefix),forecast_replays=replays,rule_outcome_reconciliations=len(f),
        phase_source_sha256=file_sha256(ROOT_OUT/'soccer_match_phase_observations.parquet'),
        input_sha256=file_sha256(ROOT_OUT/(TABLE+'.parquet')),evaluated2026=chosen is not None,
        no_prices_substituted=True,no_trading_result_claimed=True,app_changed=False,adopted=False)
    dump(OUT/'validation.json',validation)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';decisions=json.loads(path.read_bytes())
    decisions[OUT.relative_to(ROOT_OUT/'simulation_results').as_posix()]=dict(plan=json.loads((OUT/'experiment_plan.json').read_bytes()),selection=selection,validation=validation)
    dump(path,decisions)
    from final_pipeline import cleanup
    cleanup();print(metric(pd.concat([dev,evaluation],ignore_index=True) if evaluation is not None else dev).round(5).to_string(index=False),flush=True)
    print(json.dumps(selection),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--additional-history',action='store_true');args=parser.parse_args()
    main(args.additional_history)
