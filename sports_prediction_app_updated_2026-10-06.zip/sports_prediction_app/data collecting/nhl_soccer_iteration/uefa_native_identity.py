"""Verify old UEFA statistics IDs against dated lineup identities.

Official route observed in UEFA's current jr.b175cc2d.js client:
comp.uefa.com/v2/players?playerIds=ID. This is an identity-only lookup.
Current clubs, ages, shirts, positions and statistics are never backfilled.
Aliases require exact registered name, birth date, gender and nationality AND a
unique player on the same dated team. Both provider IDs remain in the output.
"""
import hashlib,json
from collections import defaultdict
import pandas as pd
from common import ROOT_OUT,PROJECT,OfficialClient,read_db,dump,stamp

RUN=ROOT_OUT/'uefa_identity_v42'
INPUTS={'nations':('nations_actions_v41','nations_match_players.parquet'),
        'ucl':('uefa_matchstats_v33','uefa_match_players.parquet')}


def original(source):
    b=(PROJECT/source['raw_file']).read_bytes()
    assert hashlib.sha256(b).hexdigest()==source['sha256']
    return json.loads(b)


def names(p):
    # No transliteration, edit distance, abbreviation or fuzzy matching.
    return {' '.join(v.split()).casefold() for v in
            [p.get('internationalName'),p.get('translations',{}).get('name',{}).get('EN')]
            if isinstance(v,str) and v.strip()}


def identity_matches(p,q):
    if not bool(names(p)&names(q)) or not all(p.get(k) and p[k]==q.get(k) for k in ['birthDate','gender']):return False
    if p.get('countryCode') and q.get('countryCode') and p['countryCode']!=q['countryCode']:return False
    nationality=(p.get('countryCode') and p['countryCode']==q.get('countryCode')) or (p.get('nationalTeamId') and p['nationalTeamId']==q.get('nationalTeamId'))
    return bool(nationality)


def load_records():
    frames={};records={}
    for label,(folder,file) in INPUTS.items():
        frames[label]=pd.read_parquet(ROOT_OUT/folder/file)
        with read_db(ROOT_OUT/folder/'match_statistics.sqlite') as c:
            records[label]={gid:json.loads(b) for gid,b in c.execute('SELECT game_id,body FROM games')}
    return frames,records


def main():
    RUN.mkdir(exist_ok=True);frames,records=load_records()
    ids=sorted({pid for f in frames.values() for pid in f.loc[~f.lineup_identity_verified,'official_player_id']})
    OfficialClient.HOSTS.add('comp.uefa.com');client=OfficialClient(per_second=2)
    profiles={};sources={};milestone=10
    for n,pid in enumerate(ids,1):
        body,s=client.get('https://comp.uefa.com/v2/players?playerIds='+pid,
                         'Verify historical statistics identity for UEFA player '+pid,'official_player_identity')
        sources[pid]=s
        if body and len(body)==1 and str(body[0]['id'])==pid:profiles[pid]=body[0]
        if n*100>=milestone*len(ids) or n==len(ids):
            progress=dict(at_utc=stamp(),stage='official_identity_profiles',processed=n,total=len(ids),percent=round(100*n/len(ids),1))
            dump(RUN/'progress.json',progress);print(json.dumps(progress),flush=True);milestone+=10
    proofs=[];pending=[]
    for label,f in frames.items():
        for r in f.loc[~f.lineup_identity_verified].itertuples():
            g=records[label][r.game_id];s=g['source_links']['lineup'];lineup=original(s)
            side='awayTeam' if r.side=='A' else 'homeTeam';team=lineup[side]
            assert str(team['team']['id'])==str(r.team_id)
            all_players=[(group,i,v['player']) for group in ['field','bench'] for i,v in enumerate(team.get(group,[]))]
            p=profiles.get(r.official_player_id)
            matched=[(group,i,q) for group,i,q in all_players if p and identity_matches(p,q)]
            info=dict(dataset=label,game_id=r.game_id,side=r.side,team_id=r.team_id,
                      statistics_player_id=r.official_player_id,profile_source=sources[r.official_player_id],lineup_source=s)
            if len(matched)==1:
                group,i,q=matched[0];assert q['id']!=r.official_player_id
                # Already present source statistics for the proposed destination
                # would be a conflict, not permission to sum or silently dedup.
                duplicate=f[(f.game_id==r.game_id)&(f.official_player_id==str(q['id']))]
                if not duplicate.empty:
                    pending.append(info|dict(reason='Both old and proposed canonical statistics IDs exist',proposed_id=q['id']));continue
                proofs.append(info|dict(lineup_player_id=str(q['id']),player_name=q.get('internationalName') or q['translations']['name']['EN'],
                    birth_date=q['birthDate'],country_code=q['countryCode'],gender=q['gender'],lineup_group=group,position=q.get('fieldPosition'),
                    profile_pointer='/0',lineup_pointer=f'/{side}/{group}/{i}/player',
                    method='Exact registered-name intersection + birth date + gender + nationality (country code or national-team ID, no conflicting country); unique same dated team lineup; inference from official identity records, not a provider-issued alias'))
            else:
                same_dob=[dict(player_id=q['id'],name=q.get('internationalName'),birth=q.get('birthDate'),country=q.get('countryCode'))
                          for _,_,q in all_players if p and q.get('birthDate')==p.get('birthDate')]
                pending.append(info|dict(reason='No unique strict identity match',profile={k:p.get(k) for k in ['id','internationalName','birthDate','countryCode','gender']} if p else None,candidates=same_dob))
    mapping=defaultdict(set)
    for p in proofs:mapping[p['statistics_player_id']].add(p['lineup_player_id'])
    assert all(len(v)==1 for v in mapping.values()),'Alias differs across games: manual reconciliation required'
    dump(RUN/'identity_proofs.json',dict(at_utc=stamp(),proofs=proofs,pending=pending,profiles=sources,
         route_documentation=['https://www.uefa.com/CompiledAssets/UefaCom/js/jr.b175cc2d.js',
           'https://www.uefa.com/european-qualifiers/teams/players/50327420--virgil-van-dijk/']))
    report=dict(at_utc=stamp(),unique_ids_requested=len(ids),profiles_returned=len(profiles),resolved_rows=len(proofs),pending_rows=len(pending),
                resolved_by_dataset={k:sum(p['dataset']==k for p in proofs) for k in frames},identity_pairs={k:next(iter(v)) for k,v in mapping.items()})
    dump(RUN/'identity_summary.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
