"""Recover keeper dependencies using independently verified official calendars."""
import argparse,io,json,sqlite3
import pandas as pd
from pypdf import PdfReader
from urllib.parse import quote
from common import OfficialClient,read_db,dump,stamp
from collect_seriea_keeper_statistics import FOLDER,sources,endpoint,normalize
from collect_seriea_players import parse

def repair_keeper_starter(game,players,lineup,ranking,client):
    if game['game_id']!='SEA_20250512_ROM_ATA':return
    # This correction is supported by the club's dated historical lineup table.
    # Its later publication delays feature availability; no future roster leaks.
    url='https://images.atalanta.it/image/private/t_q-good/prd/bph1rxkuquvpjn72jebh.pdf'
    OfficialClient.HOSTS.add('images.atalanta.it')
    body,source=client.get(url,'Verify official final-report evidence for Atalanta-Roma 2025-05-12','official_keeper_final_report',document=True)
    assert body is not None and body.startswith(b'%PDF'),source['return_status']
    report=PdfReader(io.BytesIO(body));text=' '.join(report.pages[20].extract_text().split())
    assert 'Serie A' in text and '25/05/2025' in text
    assert '12/05/2025 Roma (C) 2-1 3-4-2-1 Carnesecchi' in text
    pid='serie-a::Football_Player::adfb707431614df5aeec9b486a888815'
    person=next(p for p in lineup['home']['benched'] if p['playerId']==pid)
    assert person['shortName']=='Marco Carnesecchi' and person['roleLabel']=='Goalkeeper'
    assert '29 Marco Carnesecchi' in ' '.join(report.pages[53].extract_text().split())
    stat=next(p for p in ranking['home']['players'] if p['player']['playerId']==pid)
    for field in ['minutes','minsPlayed']:
        values=[s['statsValue'] for s in stat['stats'] if s['statsId']==field];assert values and set(values)=={90}
    p=next(p for p in players if p['official_player_id']==pid)
    proof=dict(source=source,page=21,identity_page=54,report_date='2025-05-25',native_player_id=pid,
        exact_fixture_text='12/05/2025 Roma (C) 2-1 3-4-2-1 Carnesecchi',
        raw_lineup_group='benched',raw_started=p['started'],raw_minutes=p['minutes'],
        correction='Club historical starting lineup plus both native ranking minute fields verify full regulation appearance',
        conservative_available_at_utc='2025-05-26T00:00:00+00:00')
    assert not p['lineup_events']
    p.update(started=1,did_play=True,minutes=90,keeper_report_repair=proof)
    p['available_at_utc']=max(pd.Timestamp(p['available_at_utc']),pd.Timestamp(proof['conservative_available_at_utc'])).isoformat()


def main(game_ids=None):
    games,people=sources();routes={}
    for gid,players in people.items():
        if gid in games:routes[games[gid]['season']]=endpoint(players).split('/match/')[0]
    with read_db(FOLDER/'statistics.sqlite') as db:issues=[json.loads(b) for b, in db.execute('SELECT body FROM issues')]
    if game_ids:issues=[dict(game_id=gid) for gid in game_ids]
    client=OfficialClient(2);db=sqlite3.connect(FOLDER/'source_repairs.sqlite');db.execute('CREATE TABLE IF NOT EXISTS players(game_id TEXT PRIMARY KEY,body TEXT NOT NULL)')
    records=[]
    for issue in issues:
        gid=issue['game_id'];game=games[gid];base=routes[game['season']]+'/matches/'+quote(game['official_game_id'],safe='');parts={};refs={}
        try:
            for kind in ['lineups','feed']:
                data,source=client.get(base+'/'+kind,'Repair dated official goalkeeper source dependency: '+gid,'seriea_keeper_dependency_repair')
                refs['lineup' if kind=='lineups' else kind]=source;assert data is not None,source['return_status'];parts[kind]=data
            calendar,calendar_source=client.get(routes[game['season']]+'/matches','Verify official final calendar result for goalkeeper recovery, season '+game['season'],'seriea_keeper_result_recovery')
            matched=[i for i,m in enumerate(calendar['matches']) if m['matchId']==game['official_game_id']];assert len(matched)==1
            refs['calendar']=calendar_source|dict(source_pointer='/matches/'+str(matched[0]))
            players=parse(game,parts['lineups'],parts['feed'],refs,require_full_lineup=False)
            rank,source=client.get(endpoint(players),'Recover keeper ranking after verified dated source repair: '+gid,'seriea_keeper_repaired_ranking')
            repair_keeper_starter(game,players,parts['lineups'],rank,client)
            with db:db.execute('INSERT OR REPLACE INTO players VALUES (?,?)',[gid,json.dumps(players)])
            result=normalize(game,players,rank,source,refs['calendar'])
            with sqlite3.connect(FOLDER/'statistics.sqlite') as target:
                target.execute('INSERT OR REPLACE INTO games VALUES (?,?)',[gid,json.dumps(result)]);target.execute('DELETE FROM issues WHERE game_id=?',[gid])
            record=dict(game_id=gid,date=game['date'],recovered=True,keeper_rows=len(result['players']),sources=refs)
        except Exception as exc:
            record=dict(game_id=gid,date=game['date'],recovered=False,reason=type(exc).__name__+': '+str(exc),sources=refs)
        records.append(record);print(json.dumps({k:v for k,v in record.items() if k!='sources'}),flush=True)
    db.close();path=FOLDER/'dependency_repair.json'
    previous=json.loads(path.read_text()).get('records',[]) if path.exists() else []
    updated={r['game_id']:r for r in previous};updated.update({r['game_id']:r for r in records})
    dump(path,dict(at_utc=stamp(),records=list(updated.values()),original_source_tables_unchanged=True))
    with read_db(FOLDER/'statistics.sqlite') as target:
        bodies=[json.loads(b) for b, in target.execute('SELECT body FROM games')]
        pending=target.execute('SELECT count(*) FROM issues').fetchone()[0]
    dump(FOLDER/'coverage.json',dict(at_utc=stamp(),retained_games=len(bodies),keeper_rows=sum(len(r['players']) for r in bodies),
        pending_requests=pending,earliest=min(r['date'] for r in bodies),latest=max(r['date'] for r in bodies)))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--game-id',action='append');a=p.parse_args();main(a.game_id)
