"""Official per-game NHL player/team discipline statistics, 2021 onward.

Use bounded monthly requests. A supported limit=-1 retrieves a month; retain
pagination handling if the service returns fewer rows than its reported total.
Every raw response is preserved by OfficialClient before normalization.
"""
import argparse,calendar,collections,json,sqlite3
from urllib.parse import urlencode
import pandas as pd
from common import ROOT_OUT,PREVIOUS,OfficialClient,read_db,dump,stamp

PLAYER={'penaltiesDrawn':'penalties_drawn','penalties':'penalties_taken','netPenalties':'net_penalties',
 'minorPenalties':'minor_penalties','majorPenalties':'major_penalties','matchPenalties':'match_penalties',
 'misconductPenalties':'misconduct_penalties','gameMisconductPenalties':'game_misconduct_penalties',
 'penaltyMinutes':'penalty_minutes','timeOnIcePerGame':'playing_seconds',
 'penaltiesDrawnPer60':'raw_drawn_per60','penaltiesTakenPer60':'raw_taken_per60','netPenaltiesPer60':'raw_net_per60'}
TEAM={'totalPenaltiesDrawn':'penalties_drawn','penalties':'penalties_taken','netPenalties':'net_penalties',
 'minors':'minor_penalties','majors':'major_penalties','matchPenalties':'match_penalties',
 'misconducts':'misconduct_penalties','gameMisconducts':'game_misconduct_penalties','benchMinorPenalties':'bench_minor_penalties',
 'penaltyMinutes':'penalty_minutes','penaltiesDrawnPer60':'raw_drawn_per60','penaltiesTakenPer60':'raw_taken_per60','netPenaltiesPer60':'raw_net_per60'}
SOURCES='nhl_penalty_sources'
TABLES={'skater':'nhl_player_penalty_statistics','team':'nhl_team_penalty_statistics'}


def main(year=None):
    with read_db(PREVIOUS/'expanded.sqlite') as db:
        games={str(r['official_game_id']):dict(r) for r in db.execute("SELECT * FROM nhl_games WHERE date BETWEEN '2021-01-01' AND '2026-09-30' AND phase IN ('Regular Season','Playoffs')")}
        old={(r['game_id'],str(r['official_player_id'])):dict(r) for r in db.execute('SELECT game_id,official_player_id,side,minutes,penalty_minutes FROM nhl_player_games')}
    assert json.loads((ROOT_OUT/'retention/nhl_penalties_pilot.json').read_text())['status']=='PASS'
    client=OfficialClient(3);config,documentation=client.get('https://api.nhle.com/stats/rest/en/config','Read current official NHL discipline field configuration','official_api_documentation')
    assert 'penalties' in config['playerReportData'] and 'penalties' in config['teamReportData']
    db=sqlite3.connect(ROOT_OUT/'granular.sqlite',timeout=60)
    db.execute('CREATE TABLE IF NOT EXISTS nhl_penalty_sources(request_number INTEGER PRIMARY KEY,kind TEXT,month TEXT,returned_rows INTEGER,source_json TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS nhl_penalty_acquisition_state(kind TEXT,month TEXT,total_rows INTEGER,completed_at_utc TEXT,PRIMARY KEY(kind,month))')
    db.execute('CREATE TABLE IF NOT EXISTS nhl_penalty_validation_issues(game_id TEXT,official_player_id TEXT,field TEXT,comparison_value REAL,official_value REAL,request_number INTEGER,source_pointer TEXT)')
    if 'older_value' in [r[1] for r in db.execute('PRAGMA table_info(nhl_penalty_validation_issues)')]:
        db.execute('ALTER TABLE nhl_penalty_validation_issues RENAME COLUMN older_value TO comparison_value')
    existing=[r[1] for r in db.execute('PRAGMA table_info(nhl_player_penalty_statistics)')]
    if existing:
        for col,count in [('calculated_drawn_per60','penalties_drawn'),('calculated_taken_per60','penalties_taken'),('calculated_net_per60','net_penalties')]:
            if col not in existing:
                db.execute('ALTER TABLE nhl_player_penalty_statistics ADD COLUMN '+col+' REAL')
                db.execute('UPDATE nhl_player_penalty_statistics SET '+col+'='+count+'*3600.0/playing_seconds WHERE playing_seconds>0')
    db.commit()
    months=sorted({g['date'][:7] for g in games.values() if year is None or g['date'].startswith(str(year))})
    done=set(db.execute('SELECT kind,month FROM nhl_penalty_acquisition_state'))
    tasks=[(kind,month) for month in months for kind in ['skater','team'] if (kind,month) not in done]
    counts=collections.Counter();mark=10
    for n,(kind,month) in enumerate(tasks,1):
        y,m=map(int,month.split('-'));last=calendar.monthrange(y,m)[1];start=0;rows=[];refs=[];issues=[];seen=set();total=None
        fields=PLAYER if kind=='skater' else TEAM
        while total is None or start<total:
            query=dict(isAggregate='false',isGame='true',start=start,limit=-1,
                sort=json.dumps([dict(property='gameId',direction='ASC'),dict(property='playerId' if kind=='skater' else 'teamId',direction='ASC')]),
                cayenneExp=f'gameDate>="{month}-01" and gameDate<="{month}-{last:02d}" and (gameTypeId=2 or gameTypeId=3)')
            data,source=client.get('https://api.nhle.com/stats/rest/en/'+kind+'/penalties?'+urlencode(query),f'{month} official NHL {kind} penalties drawn/taken and discipline, page offset {start}','official_penalty_statistics')
            assert data is not None,source['return_status']
            if total is None:total=data['total']
            assert data['total']==total and (data['data'] or total==0)
            refs.append((source['request_number'],kind,month,len(data['data']),json.dumps(source)))
            for i,raw in enumerate(data['data']):
                native=str(raw['gameId']);g=games[native];assert raw['gameDate']==g['date'] and raw['gamesPlayed']==1
                side='B' if raw['homeRoad']=='H' else 'A';assert raw['homeRoad'] in ['H','R']
                pid=str(raw['playerId']) if kind=='skater' else None
                identity=(native,pid if kind=='skater' else str(raw['teamId']));assert identity not in seen;seen.add(identity)
                row=dict(game_id=g['game_id'],official_game_id=native,date=g['date'],available_at_utc=g['available_time'],side=side,
                    team_id=str(json.loads(g['native_team_ids_json'])[0 if side=='A' else 1]),
                    request_number=source['request_number'],source_pointer='/data/'+str(i))
                if kind=='skater':row.update(official_player_id=pid,player_name=raw['skaterFullName'],position=raw['positionCode'],source_team_abbrev=raw['teamAbbrev'])
                else:
                    row.update(source_team_id=str(raw['teamId']),team_name=raw['teamFullName'])
                    assert row['source_team_id']==row['team_id'],(g['game_id'],row['source_team_id'],row['team_id'])
                row.update({normal:raw.get(native_field) for native_field,normal in fields.items()})
                assert row['net_penalties']==row['penalties_drawn']-row['penalties_taken']
                for field,value in row.items():
                    if field in fields.values() and value is not None and 'net' not in field:assert value>=0
                if kind=='skater':
                    prior=old.get((g['game_id'],pid))
                    if prior:
                        assert prior['side']==side
                        for field,a,b in [('playing_seconds',round(prior['minutes']*60) if prior['minutes'] is not None else None,row['playing_seconds']),('penalty_minutes',prior['penalty_minutes'],row['penalty_minutes'])]:
                            if a is not None and b is not None and abs(a-b)>(1 if field=='playing_seconds' else 0):issues.append((g['game_id'],pid,field,a,b,source['request_number'],row['source_pointer']))
                    seconds=row['playing_seconds']
                    for count,rate in [('penalties_drawn','raw_drawn_per60'),('penalties_taken','raw_taken_per60'),('net_penalties','raw_net_per60')]:
                        exact=row[count]*3600/seconds if seconds and seconds>0 and row[count] is not None else None
                        row[rate.replace('raw_','calculated_')]=exact
                        # Preserve both values. Very short appearances reveal
                        # likely rounding in the provider's rate denominator; that is
                        # not a reason to discard otherwise verified counts.
                        if exact is not None and row[rate] is not None and abs(exact-row[rate])>.0011:
                            issues.append((g['game_id'],pid,rate+'_versus_exact_count_rate',exact,row[rate],source['request_number'],row['source_pointer']))
                rows.append(row)
            start+=len(data['data'])
        assert start==total==len(rows)
        frame=pd.DataFrame(rows)
        with db:
            if len(frame):frame.to_sql(TABLES[kind],db,if_exists='append',index=False,chunksize=1000)
            db.executemany('INSERT OR REPLACE INTO nhl_penalty_sources VALUES(?,?,?,?,?)',refs)
            db.executemany('INSERT INTO nhl_penalty_validation_issues VALUES(?,?,?,?,?,?,?)',issues)
            db.execute('INSERT INTO nhl_penalty_acquisition_state VALUES(?,?,?,?)',(kind,month,len(frame),stamp()))
        counts[kind+'_rows']+=len(rows);counts['source_disagreements']+=len(issues)
        if n*100>=mark*len(tasks) or n==len(tasks):
            result=dict(at_utc=stamp(),processed=n,total=len(tasks),percent=round(100*n/len(tasks),1),counts=dict(counts));dump(ROOT_OUT/'nhl_penalty_collection_progress.json',result);print(json.dumps(result),flush=True);mark+=10
    db.close();publish()


def publish():
    maps={TABLES['skater']:PLAYER,TABLES['team']:TEAM,SOURCES:{}}
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        for table,fields in maps.items():
            f=pd.read_sql_query('SELECT * FROM '+table,db)
            keys=['game_id','official_player_id'] if table==TABLES['skater'] else (['game_id','side'] if table==TABLES['team'] else ['request_number'])
            assert not f.duplicated(keys).any()
            f.to_parquet(ROOT_OUT/(table+'.parquet'),index=False);f.to_csv(ROOT_OUT/(table+'.csv'),index=False)
            for cat in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+cat+' WHERE "table"=?',(table,))
            db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(table,len(f),len(f.columns)))
            for col in f:
                unit='count' if col in fields.values() else 'identifier/text'
                if col=='playing_seconds':unit='seconds'
                elif col=='penalty_minutes':unit='minutes'
                elif col.endswith('per60'):unit='per60minutes'
                elif col=='available_at_utc':unit='UTC timestamp'
                elif col=='date':unit='YYYY-MM-DD'
                elif col=='source_json':unit='JSON'
                meaning={'penalties_drawn':'Official penalties drawn; not asserted equal to power-play opportunities',
                  'penalties_taken':'Official penalties assessed to this skater/team', 'net_penalties':'Official penalties drawn minus penalties taken',
                  'playing_seconds':'Official single-game timeOnIcePerGame; positive seconds, not minutes',
                  'available_at_utc':'Conservative completed-game statistics availability inherited from the verified game',
                  'request_number':'Foreign key to nhl_penalty_sources and the original request audit',
                  'source_pointer':'Exact JSON row pointer in the linked original response',
                  'source_json':'Official endpoint, request number, retrieval UTC, original response path and SHA256',
                  'side':'A away / B home, verified against official homeRoad and team/player identity'}.get(col,col.replace('_',' '))
                if col.startswith('calculated_'):meaning='Derived exact '+col.replace('calculated_','').replace('_',' ')+' = official count*3600/official playing seconds; no unknown input filled with zero'
                source='Official NHL statistics API '+('player/team penalty reports' if fields else 'request provenance')+'; field definitions from https://api.nhle.com/stats/rest/en/config; exact native names and parameters retained in collector and original response.'
                db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(table,col,meaning,unit,source))
                missing=int(f[col].isna().sum());db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(table,col,len(f),missing,100*missing/len(f) if len(f) else None))
    print(json.dumps(dict(stage='published_official_discipline',tables=list(maps))),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--year',type=int);a=p.parse_args();main(a.year)
