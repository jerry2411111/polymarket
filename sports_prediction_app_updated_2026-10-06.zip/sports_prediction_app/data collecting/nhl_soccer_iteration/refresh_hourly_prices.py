"""Recover closer official hourly observations for a fixed chronological cohort."""
import argparse,concurrent.futures,hashlib,json,urllib.parse
import numpy as np
import pandas as pd
from common import ROOT_OUT,OfficialClient,dump,stamp
from backtest import quote_inputs

RUN=ROOT_OUT/'hourly_prices_v61'
class Client(OfficialClient):
    HOSTS=OfficialClient.HOSTS|{'clob.polymarket.com'}


def acquire(client,r):
    cut=int(r['decision_utc'].timestamp());params=dict(market=r['entry_contract_id'],startTs=cut-86400,endTs=cut,fidelity=60)
    url='https://clob.polymarket.com/prices-history?'+urllib.parse.urlencode(params)
    body,meta=client.get(url,'Hourly history beforepre12; '+r['sport']+' '+r['game_id']+' outcome'+str(r['class_index']),kind='GET pre-match hourly prices')
    result={k:r[k] for k in ['sport','league','provider','game_id','class_index','decision_utc','entry_contract_id','entry_price','entry_source_utc','entry_available_utc','entry_age_hours','entry_request_id','entry_pointer']}
    result.update(source_json=json.dumps(meta),status='request_failed',retrieved_at_utc=meta['retrieved_at_utc'],history_rows=0,new_price=None,new_source_utc=None,new_available_utc=None,new_age_hours=None,new_pointer=None,replace_old=False)
    if body is None:return result
    if not isinstance(body,dict) or not isinstance(body.get('history'),list):result['status']='schema_problem';return result
    points=body['history'];result['history_rows']=len(points)
    usable=[]
    for i,x in enumerate(points):
        if not isinstance(x.get('t'),(int,float)) or not isinstance(x.get('p'),(int,float)) or not np.isfinite(x['p']) or not 0<=x['p']<=1:continue
        if cut-86400<=x['t']<=cut:usable.append((x['t'],i,x))
    if not usable:result['status']='empty_before_cutoff';return result
    t,i,p=max(usable);at=pd.Timestamp(t,unit='s',tz='UTC')
    result.update(new_price=float(p['p']),new_source_utc=at,new_available_utc=at,new_age_hours=(cut-t)/3600,new_pointer='/history/'+str(i)+'/p',replace_old=bool(at>r['entry_available_utc']),status='recovered')
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--year',type=int,required=True,choices=[2024,2025,2026]);parser.add_argument('--month',type=int);parser.add_argument('--rate',type=float,default=4);parser.add_argument('--workers',type=int,default=3);args=parser.parse_args()
    assert 0<args.rate<=20 and 1<=args.workers<=8
    label=str(args.year)+(f'-{args.month:02}' if args.month else '');folder=RUN/label;folder.mkdir(parents=True,exist_ok=True)
    q=quote_inputs(folder/'old_quote_quality.json');q=q[q.provider.eq('polymarket')&q.year.eq(args.year)]
    if args.month:q=q[q.decision_utc.dt.month.eq(args.month)]
    q=q.sort_values(['decision_utc','sport','game_id','class_index']).reset_index(drop=True)
    assert not q.duplicated(['game_id','class_index']).any()
    plan=dict(year=args.year,month=args.month,rows=len(q),games=q.game_id.nunique(),decision='pre12 unchanged',endpoint='https://clob.polymarket.com/prices-history',fidelity_minutes=60,window='24hours ending at original decision timestamp',
        selection='Latest returned historical point t<=decision,age<=24h. Prefer over old observation only when its availability is later. Retain0/1 as returned; never resurrect an older tradable value when the latest is0/1.',
        timestamp_basis='CLOB history t,p samples use point timestamp t; fidelity controls sample spacing. V2 aggregate availability remains timestamp+resolution_seconds. No v2 terminal settlement point used.',
        docs=['https://docs.polymarket.com/api-reference/markets/get-prices-history','https://docs.polymarket.com/api-reference/markets/get-a-tokens-price-history'],
        unchanged='No predictions,features,selection thresholds,stakes,app,or previous raw/normalized records modified. Raw-first traceable research overlay only. Empty responses retain fallback with explicit coverage status.',
        limitation='Hourly historical references remain distinct from executable offers; no spread or cost adjustment.',source_sha256=hashlib.sha256(pd.util.hash_pandas_object(q,index=False).values.tobytes()).hexdigest())
    if (folder/'plan.json').exists():assert json.loads((folder/'plan.json').read_bytes())==plan
    else:dump(folder/'plan.json',plan)
    dump(folder/'execution.json',dict(at_utc=stamp(),requests_per_second=args.rate,workers=args.workers,documented_limit='1000requests per10seconds forCLOB prices-history',rate_limit_source='https://docs.polymarket.com/api-reference/rate-limits'))
    client=Client(per_second=args.rate);rows=[];milestone=10
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for r in pool.map(lambda x:acquire(client,x),q.to_dict('records')):
            rows.append(r);pct=100*len(rows)/len(q)
            if pct>=milestone or len(rows)==len(q):
                f=pd.DataFrame(rows);f.to_parquet(folder/'quotes.parquet',index=False)
                info=dict(at_utc=stamp(),period=label,completed=len(rows),total=len(q),percent=milestone,closer_observations=int(f.replace_old.sum()),statuses=f.status.value_counts().to_dict())
                dump(folder/'progress.json',info);print(json.dumps(info),flush=True);milestone+=10
    f=pd.DataFrame(rows);f.to_parquet(folder/'quotes.parquet',index=False)
    dump(folder/'complete.json',dict(at_utc=stamp(),state='acquisition complete; independent validation pending',rows=len(f),changed_prices=int((f.replace_old&f.new_price.ne(f.entry_price)).sum()),closer_observations=int(f.replace_old.sum()),status_counts=f.status.value_counts().to_dict()))


if __name__=='__main__':main()
