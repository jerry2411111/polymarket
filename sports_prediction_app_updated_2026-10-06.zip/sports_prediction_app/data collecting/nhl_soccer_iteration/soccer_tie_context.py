"""Official earlier-leg context; no eventual aggregate winner as a predictor."""
import argparse
import copy
import json
import pickle
import sqlite3
import numpy as np
import pandas as pd
from sklearn.metrics import log_loss
from common import ROOT_OUT,dump,stamp,file_sha256
from soccer_match_phases import raw
from final_pipeline import cleanup,discard_work
import models

TABLE='soccer_second_leg_context'
LABEL='soccer_earlier_leg_context'
RESULT=ROOT_OUT/'simulation_results/feature_revisions'/LABEL
FIELDS=['f_ctx_first_leg','f_ctx_second_leg','f_ctx_single_knockout',
        'f_ctx_prior_aggregate_lead','f_ctx_prior_aggregate_abs_lead']


def earlier_context(current,match,phases):
    assert current.match_type=='SECOND_LEG'
    earlier=[str(r['id']) for r in match.get('relatedMatches',[]) if r.get('type')=='FIRST_LEG']
    assert len(earlier)==1 and earlier[0] in phases.index,'Recover missing official first leg before modeling'
    first=phases.loc[earlier[0]]
    assert first.match_type=='FIRST_LEG' and first.league==current.league
    scores={first.teamA_id:int(first.regulation_scoreA),first.teamB_id:int(first.regulation_scoreB)}
    assert set(scores)=={current.teamA_id,current.teamB_id}
    start=pd.Timestamp(current.start_time);cut=start-pd.Timedelta(hours=12)
    previous=pd.Timestamp(first.available_time)
    assert pd.Timestamp(first.start_time)<previous<cut
    a,b=scores[current.teamA_id],scores[current.teamB_id]
    first_evidence=json.loads(first.source_json)
    # Do not read score.aggregate, winner, later events or the present score.
    return dict(game_id=current.game_id,official_game_id=current.official_game_id,league=current.league,
        date=current.date,start_time=current.start_time,prediction_time=cut.isoformat(),
        first_leg_game_id=first.game_id,first_leg_official_game_id=first.official_game_id,
        first_leg_start_time=first.start_time,first_leg_end_time=first.available_time,
        teamA_first_leg_goals=a,teamB_first_leg_goals=b,prior_home_aggregate_lead=b-a,
        prior_aggregate_abs_lead=abs(b-a),
        source_json=json.dumps(dict(current_match=json.loads(current.source_json)['match'],
            first_match=first_evidence['match'],first_score_proof=first_evidence['regulation_score_proof'],
            first_clock_correction=first_evidence.get('clock_correction'),
            excluded_fields=['/score/aggregate','/winner','current-game scores, players and match events'],
            first_score_availability='Native event/end clock is the historical availability proxy; later database revisions are not treated as historical publications.'),sort_keys=True))


def collect():
    path=ROOT_OUT/'soccer_match_phase_observations.parquet'
    validation=json.loads((ROOT_OUT/'retention/soccer_match_phases_validation.json').read_bytes())
    assert validation['status']=='PASS' and validation['output_sha256']==file_sha256(path)
    phases=pd.read_parquet(path).set_index('official_game_id',drop=False)
    rows=[];replays=0
    second=phases[phases.match_type.eq('SECOND_LEG')];milestone=10
    for i,current in enumerate(second.itertuples(index=False),1):
        match=raw(json.loads(current.source_json)['match']);match=match[0] if isinstance(match,list) else match
        row=earlier_context(current,match,phases)
        poisoned=copy.deepcopy(match)
        poisoned['score']={'regular':{'away':999,'home':888},'aggregate':{'away':777,'home':666}}
        poisoned['winner']={'aggregate':{'team':{'id':'FUTURE_FORBIDDEN'}}}
        for related in poisoned.get('relatedMatches',[]):
            related['score']={'aggregate':{'away':555,'home':444}}
            related['winner']={'aggregate':{'team':{'id':'FUTURE_FORBIDDEN'}}}
        assert row==earlier_context(current,poisoned,phases)
        rows.append(row);replays+=1
        if i*100>=milestone*len(second) or i==len(second):
            print(json.dumps(dict(stage='earlier_leg_context',complete=i,total=len(second),percent=round(100*i/len(second),1))),flush=True)
            milestone+=10
    f=pd.DataFrame(rows);assert f.game_id.is_unique and not f.isna().any().any()
    f.to_parquet(ROOT_OUT/(TABLE+'.parquet'),index=False);f.to_csv(ROOT_OUT/(TABLE+'.csv'),index=False)
    meanings={
        'game_id':('Canonical second-leg game identifier','identifier'),
        'official_game_id':('UEFA native second-leg game identifier','identifier'),
        'league':('Actual Champions League or Nations League competition','text'),
        'date':('Second-leg date','YYYY-MM-DD'),
        'start_time':('Official second-leg kickoff','UTC timestamp'),
        'prediction_time':('Pre12 forecast boundary','UTC timestamp'),
        'first_leg_game_id':('Linked canonical first-leg identifier','identifier'),
        'first_leg_official_game_id':('Linked native first-leg identifier','identifier'),
        'first_leg_start_time':('Official first-leg kickoff','UTC timestamp'),
        'first_leg_end_time':('First-leg final clock, including documented native-event correction where needed','UTC timestamp'),
        'teamA_first_leg_goals':('Second-leg away team goals in the earlier first leg','goals'),
        'teamB_first_leg_goals':('Second-leg home team goals in the earlier first leg','goals'),
        'prior_home_aggregate_lead':('Home minus away goals before this leg begins','goals'),
        'prior_aggregate_abs_lead':('Absolute gap before this leg begins','goals'),
        'source_json':('Raw official source hashes, earlier score proof, clock correction and explicit excluded future fields','JSON')}
    origin='Official UEFA match metadata and independently validated first-leg regulation scores. Native team IDs map both legs. Raw first-leg eventual aggregate scores/winners and all second-leg results are excluded.'
    assert set(f)==set(meanings)
    with sqlite3.connect(ROOT_OUT/'granular.sqlite') as db:
        f.to_sql(TABLE,db,if_exists='replace',index=False)
        db.execute('CREATE UNIQUE INDEX '+TABLE+'_game ON '+TABLE+'(game_id)')
        for name in ['table_catalog','column_catalog','missing_report']:db.execute('DELETE FROM '+name+' WHERE "table"=?',(TABLE,))
        db.execute('INSERT INTO table_catalog VALUES(?,?,?)',(TABLE,len(f),len(f.columns)))
        for c in f:
            db.execute('INSERT INTO column_catalog VALUES(?,?,?,?,?)',(TABLE,c,*meanings[c],origin))
            db.execute('INSERT INTO missing_report VALUES(?,?,?,?,?)',(TABLE,c,len(f),int(f[c].isna().sum()),100*f[c].isna().mean()))
        replay=pd.read_sql_query('SELECT * FROM '+TABLE,db)
        pd.testing.assert_frame_equal(f,replay,check_dtype=False)
    proof=dict(status='PASS',at_utc=stamp(),rows=len(f),source_phase_sha256=file_sha256(path),
        output_sha256=file_sha256(ROOT_OUT/(TABLE+'.parquet')),future_field_poison_replays=replays,
        all_first_legs_known_before_pre12=True,missing_fields=0,
        clocks_recovered=validation['clock_corrections'],used_current_game_results=False,
        public_validation_urls=['https://www.uefa.com/uefachampionsleague/match/2032548--fola-vs-l-red-imps/',
            'https://editorial.uefa.com/resources/027d-173372178cbf-c5a282fad549-1000/uefa_competition_results_2021-22.pdf',
            'https://www.uefa.com/uefachampionsleague/match/2038614--maccabi-haifa-vs-sheriff/'])
    dump(ROOT_OUT/'retention/soccer_tie_context_validation.json',proof)
    from publish import main
    main();cleanup();print(json.dumps({k:v for k,v in proof.items() if k!='clocks_recovered'}),flush=True)
    return f,phases,proof


def build(work):
    f=pd.read_parquet(ROOT_OUT/(TABLE+'.parquet'));phases=pd.read_parquet(ROOT_OUT/'soccer_match_phase_observations.parquet').set_index('game_id')
    proof=json.loads((ROOT_OUT/'retention/soccer_tie_context_validation.json').read_bytes())
    assert proof['status']=='PASS' and proof['output_sha256']==file_sha256(ROOT_OUT/(TABLE+'.parquet'))
    base=pd.read_parquet(ROOT_OUT/'retained_models/soccer/soccer_features.parquet')
    result=base.copy();kind=result.game_id.map(phases.match_type)
    assert kind[result.league.eq('UEFA Champions League')].notna().all()
    for field,type_ in zip(FIELDS[:3],['FIRST_LEG','SECOND_LEG','SINGLE']):result[field]=kind.eq(type_).astype(float)
    mapping=f.set_index('game_id')
    for field,source in zip(FIELDS[3:],['prior_home_aggregate_lead','prior_aggregate_abs_lead']):
        result[field]=result.game_id.map(mapping[source])
        assert result.loc[kind.eq('SECOND_LEG'),field].notna().all()
        result.loc[~kind.eq('SECOND_LEG'),field]=0.
    eligible=result[kind.eq('SECOND_LEG')]
    assert pd.to_datetime(eligible.game_id.map(mapping.prediction_time),utc=True).to_numpy().tolist()==eligible.prediction_time.to_numpy().tolist()
    pd.testing.assert_frame_equal(base,result[base.columns],check_exact=True)
    result.to_parquet(work/'soccer_features.parquet',index=False)
    # All future-derived fields are outside the feature allowlist. Removing
    # later matches from the lookup cannot affect any earlier first-leg context.
    cutoff=pd.Timestamp('2025-01-01',tz='UTC');prior=result[result.prediction_time.lt(cutoff)]
    used=f[pd.to_datetime(f.prediction_time,utc=True).lt(cutoff)].set_index('game_id')
    ids=prior[prior.f_ctx_second_leg.eq(1)].game_id
    assert set(ids).issubset(used.index)
    assert np.array_equal(prior.loc[prior.f_ctx_second_leg.eq(1),FIELDS[3]],ids.map(used.prior_home_aggregate_lead))
    info=dict(status='PASS',at_utc=stamp(),source_validation=proof['output_sha256'],rows=len(result),new_features=FIELDS,
        baseline_columns_unchanged=True,future_field_poison_replays=proof['future_field_poison_replays'],
        before2025_prefix_rows=len(prior),known_first_leg_context_rows=len(eligible),
        feature_sha256=file_sha256(work/'soccer_features.parquet'))
    dump(work/'feature_validation.json',info)
    return result,info


def run():
    assert not (RESULT/'validation.json').exists()
    work=ROOT_OUT/'_work'/LABEL;assert not work.exists();work.mkdir(parents=True)
    RESULT.mkdir(exist_ok=True)
    try:
        frame,feature_proof=build(work)
        prior=ROOT_OUT/'simulation_results/feature_revisions/soccer_pooled_scale'
        reference=json.loads((prior/'experiment_plan.json').read_bytes())
        recipe=copy.deepcopy(reference['recipe']);recipe['preserve_unit_columns']+=FIELDS
        name='soccer_tie_context';models.CANDIDATES[name]=recipe;models.OUT=work
        plan=dict(at_utc=stamp(),hypothesis='Known first-leg aggregate lead changes return-leg incentives beyond generic strength. Add only first/second/single-leg indicators and signed/absolute prior lead.',
            reference='soccer_pooled_scale primary, best saved development probability loss',new_features=FIELDS,
            history_from='2021-01-01',forecasts_from='2024-01-01',recipe=recipe,
            gate='Lower pooled2024/25 multiclass logloss AND lower second-leg logloss versus the reference on identical games. Probability-only model selection; no betting return can promote a model.',
            betting='Same$2000account;$5per percentage point of positive price advantage; one original outcome chosen by quarter-Kelly expected-log criterion; pre12 prior quotes; providers separate.',
            target='Soccer regulation home/away/draw, not aggregate qualification or extra time.',
            evaluation='2026only after development gate, retrospective repeated research, not untouched.',feature_sha256=feature_proof['feature_sha256'],app_changed=False)
        dump(RESULT/'experiment_plan.json',plan);dump(RESULT/'feature_validation.json',feature_proof)
        candidate=models.run('soccer','development',[name]);candidate['variant']='candidate'
        control=pd.read_parquet(prior/'development_predictions.parquet');control=control[control.variant.eq('candidate')].copy();control['variant']='reference'
        assert set(candidate.game_id)==set(control.game_id)
        joined=pd.concat([control,candidate],ignore_index=True)
        joined.to_parquet(RESULT/'development_predictions.parquet',index=False)
        models.metrics(joined).to_csv(RESULT/'development_metrics.csv',index=False)
        second=set(frame[frame.f_ctx_second_leg.eq(1)].game_id)
        rows=[]
        for variant,g in joined.groupby('variant'):
            for scope in ['all','second_leg','other']:
                h=g if scope=='all' else (g[g.game_id.isin(second)] if scope=='second_leg' else g[~g.game_id.isin(second)])
                rows.append(dict(variant=variant,scope=scope,games=len(h),logloss=log_loss(h.target,h[['p0','p1','p2']],labels=[0,1,2])))
        scores=pd.DataFrame(rows);scores.to_csv(RESULT/'scope_metrics.csv',index=False)
        score=scores.set_index(['variant','scope']).logloss
        passed=all(score['candidate',scope]<score['reference',scope] for scope in ['all','second_leg'])
        a=candidate.set_index('game_id');b=control.set_index('game_id').loc[a.index];target=a.target.to_numpy(int)
        assert a.target.eq(b.target).all()
        delta=-np.log(a[['p0','p1','p2']].to_numpy()[np.arange(len(a)),target])+np.log(b[['p0','p1','p2']].to_numpy()[np.arange(len(a)),target])
        blocks=pd.DataFrame(dict(fold=a.fold,delta=delta)).groupby('fold').delta.agg(['sum','count'])
        draws=np.random.default_rng(904).integers(0,len(blocks),size=(3000,len(blocks)))
        bootstrap=blocks['sum'].to_numpy()[draws].sum(axis=1)/blocks['count'].to_numpy()[draws].sum(axis=1)
        decision=dict(at_utc=stamp(),passed=bool(passed),comparison=rows,paired_loss_change=float(delta.mean()),
            monthly_block95_interval=np.quantile(bootstrap,[.025,.975]).tolist(),multiple_testing_adjusted=False)
        dump(RESULT/'selection.json',decision)
        package=pickle.loads((work/'model_runs/soccer/development'/(name+'.pkl')).read_bytes())
        data=pd.concat([frame,pd.get_dummies(frame.league,prefix='league',dtype=float)],axis=1).set_index('game_id')
        sample=candidate[candidate.fold.eq(package['boundary'].strftime('%Y-%m'))].head(25)
        x=data.loc[sample.game_id,package['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
        replay=models.apply_calibration(package['model'].predict_proba(x),package['calibrator'])
        assert np.allclose(replay,sample[['p0','p1','p2']],rtol=0,atol=1e-12)
        assert candidate.train_label_max.lt(candidate.prediction_time).all() and candidate.calibration_label_max.lt(candidate.prediction_time).all()
        if passed:
            dump(work/'soccer_selection.json',dict(selected_candidates=[name]))
            test=models.run('soccer','evaluation',[name]);test['variant']='candidate'
            ref=pd.read_parquet(ROOT_OUT/'simulation_results/transferred_account_staking/soccer_evaluation_predictions.parquet');ref['variant']='reference'
            test=pd.concat([test,ref],ignore_index=True);test.to_parquet(RESULT/'evaluation_predictions.parquet',index=False)
            models.metrics(test).to_csv(RESULT/'evaluation_metrics.csv',index=False)
        simulate(joined,pd.read_parquet(RESULT/'evaluation_predictions.parquet') if passed else None)
        dump(RESULT/'validation.json',dict(status='PASS',at_utc=stamp(),feature_validation=feature_proof,
            forecasts=len(candidate),forecast_replays=len(sample),development_gate_passed=bool(passed),
            evaluated2026=bool(passed),new_input_count=len(package['columns']),adopted=False,app_changed=False))
        print(json.dumps(decision),flush=True)
    finally:
        if work.exists():discard_work(work)
        cleanup()


def simulate(development,evaluation):
    import transfer_stake_sizing as transfer
    import test_confidence_dollars as engine
    from backtest import quote_inputs
    quotes=quote_inputs(RESULT/'quote_quality.json',revision='closest_v62');transfer.RESULT=RESULT
    p=pd.concat([development,evaluation],ignore_index=True) if evaluation is not None else development
    records=[];bets=[];days=[];checks=[]
    for variant,g in p.groupby('variant'):
        normalized=transfer.normalize('soccer',g,quotes,pick_growth=True)
        for provider,h in normalized.groupby('provider'):
            for year in sorted(h.year.unique()):
                m,b,l,d=engine.simulate(h,int(year),'all_selected_outcomes','edge_dollars_cash_only',5.,2000.)
                key=dict(sport='soccer',provider=provider,variant=variant,year=int(year))
                records.append(key|m);checks.append(key|engine.validate(b,l,d,'edge_dollars_cash_only',5.,2000.))
                if len(b):bets.append(b.assign(**key))
                days.append(d.assign(**key))
    a=pd.DataFrame(records);a.to_csv(RESULT/'annual.csv',index=False)
    pd.concat(bets,ignore_index=True).to_parquet(RESULT/'bets.parquet',index=False)
    pd.concat(days,ignore_index=True).to_parquet(RESULT/'daily.parquet',index=False)
    dump(RESULT/'cash_validation.json',dict(status='PASS',checks=checks))
    path=ROOT_OUT/'simulation_results/experiment_results.csv';old=pd.read_csv(path,low_memory=False);key=RESULT.relative_to(ROOT_OUT/'simulation_results').as_posix()+'/annual.csv'
    pd.concat([old[~old.source_result_file.eq(key)],a.assign(source_result_file=key)],ignore_index=True).to_csv(path,index=False)
    path=ROOT_OUT/'simulation_results/experiment_decisions.json';old=json.loads(path.read_bytes());old[RESULT.relative_to(ROOT_OUT/'simulation_results').as_posix()]=dict(plan=json.loads((RESULT/'experiment_plan.json').read_bytes()),selection=json.loads((RESULT/'selection.json').read_bytes()),adopted=False);dump(path,old)
    print(a[['provider','variant','year','funded_games','return_pct','sharpe','max_drawdown_pct']].round(4).to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--train',action='store_true');args=parser.parse_args()
    run() if args.train else collect()
