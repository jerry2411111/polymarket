"""Add official LaLiga asset-verified and PL native-ID identity evidence."""
import hashlib,json,re
import pandas as pd
from common import ROOT_OUT,PROJECT,read_db,dump,stamp
import soccer_identity_repair as identity

RUN=ROOT_OUT/'soccer_identity_sources_v58'
PREVIOUS=ROOT_OUT/'soccer_identity_v55'


def main(source_players=None):
    RUN.mkdir(exist_ok=True);old=pd.read_parquet(PREVIOUS/'identity_evidence.parquet')
    pending=pd.read_csv(PREVIOUS/'identity_evidence_pending.csv',dtype=str)
    desired=pending.set_index(['league','official_player_id']).player_id.to_dict();fresh=[]
    with read_db(PROJECT/'collected data/result/sentinent_snake.sqlite') as db:
        def source(rid):
            m=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);assert m['status']==200;return m
        for body, in db.execute('SELECT body FROM _official_laliga_people_sources'):
            r=json.loads(body)
            if r.get('status')!='ok':continue
            assets=set(re.findall(r'/(p\d+)/',json.dumps(r.get('data',{}).get('squads',[]))))
            wanted=[x for x in assets if ('La Liga',x) in desired]
            if not wanted:continue
            docs,meta=identity.read(source(r['request_id']));matches=[]
            for i,doc in enumerate(docs):
                try:node=identity.pointer(doc,r['json_pointer'])
                except (KeyError,TypeError,IndexError):continue
                if str(node['id'])==str(r['person_id']):matches.append((node,'/'+str(i)+r['json_pointer']))
            assert len(matches)==1;node,path=matches[0]
            actual,names,dob=identity.identity('lal',node)
            rawassets=set(re.findall(r'/(p\d+)/',json.dumps(node.get('squads',[]))))
            names=sorted({n for n in names if n and identity.full(n)})
            if not dob or not names:continue
            for native in wanted:
                assert native in rawassets
                fresh.append(dict(player_id=desired['La Liga',native],league='La Liga',official_player_id=native,
                    identity_kind='lal',full_names_json=json.dumps(names,ensure_ascii=True),birth_date=str(dob)[:10],profile_pointer=path,source_json=json.dumps(meta,sort_keys=True)))
        # Reuse a directly returned PL native profile even if it was originally
        # requested for an Opta-linked person in a different competition.
        for native,body in db.execute('SELECT * FROM _eu_opta_biographies'):
            key=('Premier League',str(native))
            if key not in desired:continue
            r=json.loads(body)
            if not r.get('birth_date'):continue
            doc,meta=identity.read(source(r['biography_request_id']));path=r['sources']['birth_date'].rsplit('/dates/birth',1)[0]
            node=identity.pointer(doc,path);actual,names,dob=identity.identity('pl',node);assert actual==str(native)
            names=sorted({n for n in names if n and identity.full(n)})
            if not dob or not names:continue
            fresh.append(dict(player_id=desired[key],league=key[0],official_player_id=key[1],identity_kind='pl',full_names_json=json.dumps(names,ensure_ascii=True),birth_date=str(dob)[:10],profile_pointer=path,source_json=json.dumps(meta,sort_keys=True)))
    new=pd.DataFrame(fresh).drop_duplicates(['player_id','league','official_player_id','source_json']);combined=pd.concat([old,new],ignore_index=True)
    assert not combined.duplicated(['player_id','league','official_player_id','source_json']).any()
    combined.to_parquet(RUN/'identity_evidence.parquet',index=False)
    remaining=pending.merge(new[['league','official_player_id']].drop_duplicates().assign(found=True),on=['league','official_player_id'],how='left')
    remaining=remaining[remaining.found.isna()].drop(columns='found');remaining.to_csv(RUN/'identity_evidence_pending.csv',index=False)
    dump(RUN/'source_extension.json',dict(at_utc=stamp(),source_snapshot_sha256=hashlib.sha256((PREVIOUS/'identity_evidence.parquet').read_bytes()).hexdigest(),
        earlier_evidence_rows=len(old),new_evidence_rows=len(new),new_native_ids=len(new[['league','official_player_id']].drop_duplicates()),
        still_needing_evidence=len(remaining),new_requests=0,counts_by_league=new.groupby('league').size().to_dict(),
        source_rules='LaLiga exact player asset ID in official profile photos, full names/DOB; PL exact returned nativeplayerID,fullnames/DOB. No current team or career values imported.'))
    identity.RUN=RUN
    if source_players is not None:identity.SOURCE=source_players.parent
    identity.links()
    # Independently reuse the complete raw identity verifier on the expanded
    # files. No new performance model is run before this source repair passes.
    import validate_soccer_identity as validate
    validate.RUN=RUN;result=validate.check_identities(source_players);print(json.dumps(result),flush=True)
    print((RUN/'source_extension.json').read_text(),flush=True)


if __name__=='__main__':main()
