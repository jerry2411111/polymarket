"""Evaluate one declared feature revision against retained rolling forecasts.

No parameter search or 2026-based promotion. Final metrics/ledgers survive;
rejected fit artifacts and temporary inputs are deleted after validation.
"""
import argparse,hashlib,json,pickle,shutil
from pathlib import Path
import numpy as np
import pandas as pd
from common import ROOT_OUT,dump,stamp
import models
from backtest import quote_inputs,attach,select,simulate
from cash_validation import validate_cash
from final_pipeline import discard_work


def diagnose(result):
    """Attribute changed bets separately from all-game probability quality."""
    p=pd.read_parquet(result/'development_predictions.parquet')
    a=p[p.variant.eq('candidate')].set_index('game_id').sort_index()
    b=p[p.variant.eq('retained')].set_index('game_id').loc[a.index]
    assert a.target.eq(b.target).all()
    y=a.target.to_numpy(int);delta=(-np.log(a[['p0','p1','p2']].to_numpy()[np.arange(len(y)),y])
        +np.log(b[['p0','p1','p2']].to_numpy()[np.arange(len(y)),y]))
    blocks=pd.DataFrame(dict(fold=a.fold,delta=delta)).groupby('fold').delta.agg(['sum','count'])
    draw=np.random.default_rng(731).integers(0,len(blocks),size=(3000,len(blocks)))
    samples=blocks['sum'].to_numpy()[draw].sum(axis=1)/blocks['count'].to_numpy()[draw].sum(axis=1)
    loss=dict(paired_logloss_change=float(delta.mean()),monthly_block95_interval=np.quantile(samples,[.025,.975]).tolist(),
        multiple_testing_adjusted=False,forecasts=len(p),paired_games=len(a))
    bets=pd.read_parquet(result/'development_bets.parquet');rows=[]
    for (provider,year),g in bets.groupby(['provider','year']):
        groups={variant:v.set_index(['game_id','class_index']) for variant,v in g.groupby('variant')}
        common=groups['candidate'].index.intersection(groups['retained'].index)
        for variant,v in groups.items():
            for name,sub in [('all',v),('shared',v.loc[common]),('candidate_added' if variant=='candidate' else 'candidate_removed',v.loc[~v.index.isin(common)])]:
                if sub.empty:continue
                rows.append(dict(provider=provider,year=int(year),variant=variant,cohort=name,bets=len(sub),
                    mean_probability=float(sub.probability.mean()),win_rate=float(sub.won.mean()),
                    mean_price=float(sub.price.mean()),mean_unit_return=float(sub.unit_return.mean()),
                    net_cash_profit=float((sub.payout-sub.stake).sum())))
    pd.DataFrame(rows).to_csv(result/'selection_metrics.csv',index=False)
    dump(result/'probability_comparison.json',loss)
    return loss


def consolidate(result):
    root=ROOT_OUT/'simulation_results';path=root/'experiment_results.csv'
    ledger=pd.read_csv(path,low_memory=False)
    for file in sorted(result.glob('*.csv')):
        if not file.name.endswith(('_annual.csv','_metrics.csv')):continue
        key=result.relative_to(root).as_posix()+'/'+file.name
        ledger=ledger[~ledger.source_result_file.eq(key)]
        ledger=pd.concat([ledger,pd.read_csv(file).assign(source_result_file=key)],ignore_index=True)
    ledger.to_csv(path,index=False)
    record=root/'experiment_decisions.json';decisions=json.loads(record.read_bytes())
    decisions[result.relative_to(root).as_posix()]=dict(plan=json.loads((result/'experiment_plan.json').read_bytes()),
        decision=json.loads((result/'validation.json').read_bytes()),diagnosis=json.loads((result/'probability_comparison.json').read_bytes()))
    dump(record,decisions)


def simulate_predictions(predictions,quotes,years,work,stage):
    joined,audit=attach(predictions,quotes);dump(work/(stage+'_matching.json'),audit)
    summaries=[];bets=[];daily=[]
    for (provider,variant),group in joined.groupby(['provider','variant']):
        chosen=select(group,'edge_any')
        for year in years:
            summary,t,c=simulate(chosen,year)
            meta=dict(sport='soccer',provider=provider,variant=variant,recipe='fixed',year=year)
            summaries.append(meta|summary)
            if len(t):bets.append(t.assign(**meta))
            daily.append(c.assign(**meta))
    a=pd.DataFrame(summaries);t=pd.concat(bets,ignore_index=True);c=pd.concat(daily,ignore_index=True)
    checks=validate_cash(t,c)
    a.to_csv(work/(stage+'_annual.csv'),index=False)
    t.to_parquet(work/(stage+'_bets.parquet'),index=False);c.to_parquet(work/(stage+'_daily.parquet'),index=False)
    return a,checks


def _run(label,hypothesis,reference_label=None):
    assert label.replace('_','').isalnum()
    work=ROOT_OUT/'_work'/label;feature=work/'soccer_features.parquet'
    validation=json.loads((work/'feature_validation.json').read_bytes());assert validation['status']=='PASS'
    assert hashlib.sha256(feature.read_bytes()).hexdigest()==validation['feature_sha256']
    final=ROOT_OUT/'simulation_results/feature_revisions';final.mkdir(exist_ok=True)
    plan=dict(at_utc=stamp(),label=label,hypothesis=hypothesis,
        history_from='2021-01-01',forecast_from='2024-01-01',development_years=[2024,2025],evaluation_years=[2026],
        recipe=models.CANDIDATES['context_league'],feature_sha256=validation['feature_sha256'],
        unchanged='Retained monthly expanding logistic C=.02; preprocessing details are in recipe and feature_validation; purged earlier180-day calibration; pre12 closest prior observations age<=24h; p-price>=.05;1%NAV/20%open-cost cap; officialsettlement; providers separate; no costs.',
        gate='Lower pooled2024/25 logloss AND higher weaker-year Polymarket Sharpe AND >=30bets eachyear. Fixed before fitting. Only a passing candidate receives2026evaluation.',
        limitation='2026 repeatedly researched is retrospective, not independent holdout.',additional_development_reference=reference_label)
    existing=work/'experiment_plan.json'
    if existing.exists():
        old=json.loads(existing.read_bytes());assert all(old[k]==v for k,v in plan.items() if k!='at_utc');plan=old
    else:dump(existing,plan)
    models.OUT=work
    candidate=models.run('soccer','development',['context_league']);candidate['variant']='candidate'
    control=pd.read_parquet(ROOT_OUT/'retained_models/soccer/development_predictions.parquet');control['variant']='retained'
    p=pd.concat([control,candidate],ignore_index=True)
    assert not p.duplicated(['game_id','variant']).any()
    metric=models.metrics(p);metric.to_csv(work/'development_metrics.csv',index=False)
    by_league=[]
    for league,g in p.groupby('league'):
        by_league.append(models.metrics(g).assign(league=league))
    pd.concat(by_league).to_csv(work/'development_league_metrics.csv',index=False)
    assert p.train_label_max.lt(p.prediction_time).all()
    quotes=quote_inputs(work/'quote_quality.json',revision='closest_v62')
    annual,cash=simulate_predictions(p,quotes,[2024,2025],work,'development')
    scored={}
    for variant,m in metric.groupby('variant'):
        a=annual[annual.variant.eq(variant)&annual.provider.eq('polymarket')]
        scored[variant]=dict(pooled_logloss=float(np.average(m.log_loss,weights=m.games)),
            minimum_sharpe=float(a.sharpe.min()),minimum_bets=int(a.bets.min()),mean_annual_return=float(a.return_pct.mean()))
    c,b=scored['candidate'],scored['retained']
    passed=c['pooled_logloss']<b['pooled_logloss'] and c['minimum_sharpe']>b['minimum_sharpe'] and c['minimum_bets']>=30
    decision=dict(at_utc=stamp(),passed=bool(passed),comparison=scored,development_cash_days=cash)
    if reference_label:
        assert reference_label.replace('_','').isalnum()
        reference=final/reference_label
        ref=json.loads((reference/'validation.json').read_bytes())['comparison']['candidate']
        ref_predictions=pd.read_parquet(reference/'development_predictions.parquet')
        ref_predictions=ref_predictions[ref_predictions.variant.eq('candidate')].set_index('game_id')
        assert set(ref_predictions.index)==set(candidate.game_id)
        assert candidate.set_index('game_id').target.eq(ref_predictions.target).all()
        additional=c['pooled_logloss']<ref['pooled_logloss'] and c['minimum_sharpe']>ref['minimum_sharpe']
        passed=passed and additional
        decision.update(passed=bool(passed),additional_reference=dict(label=reference_label,metrics=ref,passed=bool(additional)))
    dump(work/'selection.json',decision)
    # Reproduce saved probabilities using the retained last fit before discarding it.
    fitted=pickle.loads((work/'model_runs/soccer/development/context_league.pkl').read_bytes())
    data=pd.read_parquet(feature);data=pd.concat([data,pd.get_dummies(data.league,prefix='league',dtype=float)],axis=1)
    last=candidate[candidate.fold.eq(fitted['boundary'].strftime('%Y-%m'))].head(20)
    X=data.set_index('game_id').loc[last.game_id,fitted['columns']].replace([np.inf,-np.inf],np.nan).astype(float)
    raw=fitted['model'].predict_proba(X);actual=models.apply_calibration(raw,fitted['calibrator'])
    assert np.allclose(actual,last[['p0','p1','p2']],rtol=0,atol=1e-12)
    p.to_parquet(work/'development_predictions.parquet',index=False)
    if passed:
        dump(work/'soccer_selection.json',dict(selected_candidates=['context_league']))
        test=models.run('soccer','evaluation',['context_league']);test['variant']='candidate'
        prior=pd.read_parquet(ROOT_OUT/'retained_models/soccer/evaluation_predictions.parquet');prior['variant']='retained'
        test=pd.concat([prior,test],ignore_index=True)
        test.to_parquet(work/'evaluation_predictions.parquet',index=False)
        models.metrics(test).to_csv(work/'evaluation_metrics.csv',index=False)
        _,cash=simulate_predictions(test,quotes,[2026],work,'evaluation');decision['evaluation_cash_days']=cash
        # A passing development gate permits evaluation, not final adoption.
        # Retain the result below; discard candidate fits with the work folder.
    result=final/label;result.mkdir(exist_ok=True)
    for path in work.iterdir():
        if path.is_file() and (path.name.endswith(('_annual.csv','_metrics.csv','_bets.parquet','_daily.parquet','_coverage.csv'))
                             or path.name in ['development_predictions.parquet','evaluation_predictions.parquet','feature_validation.json','experiment_plan.json','selection.json']):
            shutil.copy2(path,result/path.name)
    decision.update(status='PASS',forecast_replays=len(last),feature_validation=validation,goal_achieved=False)
    dump(result/'validation.json',decision)
    decision['probability_comparison']=diagnose(result)
    dump(result/'validation.json',decision)
    consolidate(result)
    print(json.dumps(decision),flush=True);print(annual.to_string(index=False),flush=True)
    discard_work(work)


def main(label,hypothesis,reference_label=None):
    assert label.replace('_','').isalnum()
    work=ROOT_OUT/'_work'/label
    try:
        _run(label,hypothesis,reference_label)
    except Exception as exc:
        record=ROOT_OUT/'simulation_results/failed_runs.json'
        failures=json.loads(record.read_text()) if record.exists() else []
        failures.append(dict(at_utc=stamp(),run=label,hypothesis=hypothesis,
            error=type(exc).__name__+': '+str(exc),temporary_artifacts_retained=False))
        dump(record,failures)
        raise
    finally:
        if work.exists():discard_work(work)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--hypothesis',required=True);a=p.parse_args();main(a.label,a.hypothesis)
