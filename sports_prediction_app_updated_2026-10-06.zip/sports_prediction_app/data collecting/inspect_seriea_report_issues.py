"""Show only identity, score and phase evidence for incomplete Serie A reports."""
import json,sqlite3
from build_history_catalog import DB

def main():
 db=sqlite3.connect(DB)
 for mid,b in db.execute('SELECT * FROM _official_seriea_game_reports'):
  r=json.loads(b)
  if r['status']=='ok':continue
  g=json.loads(db.execute('SELECT body FROM _official_seriea_calendar WHERE match_id=?',(mid,)).fetchone()[0]);print('GAME',g['date'],g['away']['name'],g['home']['name'],g['scores'],mid,r.get('error'));h=r['sources'].get('header',{}).get('data',{});print('HEADER',{k:v for k,v in h.items() if 'score' in k.lower() or k in ['phase','status']})
  for kind,s in r['sources'].items():print('SOURCE',kind,s['request_id'])
  for e in r['sources'].get('feed',{}).get('data',{}).get('events',[]):
   if e['type'] not in ['first-half','half-time-break','second-half','end-second-half','full-time','goal','penalty-goal','own-goal']:continue
   x={k:v for k,v in e.items() if not isinstance(v,(dict,list))};print('EVENT',json.dumps(x,ensure_ascii=False))
 db.close()

if __name__=='__main__':main()
