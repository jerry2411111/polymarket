"""Publish validated non-EPL competitions into the separate provider SQL tables."""
import argparse,collections,datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from build_history_odds import export
from epl_price_points import Sources,pointer,load
from eu_official_games import CONFIG,games
from eu_verified_details import details
from eu_schema import EU_PRE_COLUMNS,EU_INGAME_COLUMNS,refresh_main_views
from schema import HOURS,aligned
from core import utc,odd
from quote_selection import nearest_pregame,inside_window,available_at

def unaffected_us(db):
 out={}
 for provider in ['polymarket','kalshi']:
  for kind in ['pre_match','in_game']:
   name='_source_'+provider+'_us_'+kind;h=hashlib.sha256();n=0
   for row in db.execute('SELECT * FROM '+name+' ORDER BY game_id'):h.update((json.dumps(row,separators=(',',':'),ensure_ascii=False)+'\n').encode());n+=1
   out[name]=dict(rows=n,sha256=h.hexdigest())
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--publish',action='store_true');a=ap.parse_args();db=sqlite3.connect(DB,timeout=60);db.execute('BEGIN');ds=details(db);official={code:games(db,code) for code in CONFIG};src=Sources(db);cs={(p,cid):json.loads(b) for p,cid,b in db.execute('SELECT provider,contract_id,body FROM _eu_validated_contracts')};tables=['_eu_price_acquisition']
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_polymarket_asof'").fetchone():tables.append('_eu_polymarket_asof')
 points,conflicts,excluded=load(db,cs,src,tables);assert not conflicts,'Resolve source price conflicts before publication';families=collections.defaultdict(list);audits=[];eligibility=[];canonical={};outputs={p:{'pre_match':[],'in_game':[]} for p in ['polymarket','kalshi']};venues={(code,mid):json.loads(b) for code,mid,b in db.execute('SELECT * FROM _eu_venue_reviews')}
 for key,c in cs.items():
  raw,_=src.get(c['request_id']);m=pointer(raw,c['pointer'])
  if c['provider']=='polymarket':
   arr=lambda v:json.loads(v) if isinstance(v,str) else v;assert arr(m['clobTokenIds'])[c['outcome_index']]==c['contract_id'] and arr(m['outcomes'])[c['outcome_index']].lower()=='yes'
  else:assert m['ticker']==c['contract_id'] and m['yes_sub_title']==c['team_question']
  opened=utc(c['open']);points[key]=[p for p in points[key] if not opened or p['timestamp']>=opened.timestamp()];families[c['provider'],c['game_id'],c['family_id']].append(c)
 choices=collections.defaultdict(list)
 for (p,gid,fid),members in families.items():
  assert len(members)==3 and sorted(c['side'] for c in members)==[0,1,2];choices[p,gid].append((max(c['open'] for c in members),fid,members))
 def select(c,field,lo,start,hi=None,basis=None):
  xs=points[c['provider'],c['contract_id']];x=nearest_pregame(xs,lo,start) if hi is None else min((x for x in xs if inside_window(x,lo,hi)),key=lambda x:(available_at(x),x['timestamp'],x['resolution_seconds']),default=None);r=None
  if x:raw,r=src.get(x['request_id']);assert float(pointer(raw,x['pointer']))==x['price']
  audits.append(dict(competition=c['competition'],provider=c['provider'],game_id=c['game_id'],family_id=c['family_id'],side=c['side'],contract_id=c['contract_id'],market_id=c['market_id'],target=field,target_timestamp_utc=utc(lo).isoformat(),window_end_utc=utc(hi).isoformat() if hi is not None else None,anchor_basis=basis,price=x['price'] if x else None,source=x,source_age_seconds=lo-x['timestamp'] if x else None,request_endpoint=r['endpoint'] if r else None,request_parameters=r['parameters'] if r else None,reason=None if x else 'No eligible observation acquired'))
  return x['price'] if x else None
 for (provider,gid),variants in sorted(choices.items()):
  best=None
  for _,fid,members in sorted(variants):
   code=members[0]['competition'];mid=members[0]['official_match_id'];g=official[code][mid];d=ds.get((code,mid))
   if d is None:eligibility.append(dict(provider=provider,competition=code,game_id=gid,family_id=fid,included=False,reason='Official detailed report has not passed validation'));continue
   assert d['scores']==g['scores'];clock=d['clock'];s=clock.get('actual_start_utc') or g['scheduled_start_utc'];basis='official_actual_kickoff' if clock.get('actual_start_utc') else 'official_scheduled_kickoff_actual_unavailable';start=utc(s).timestamp();names=[g[side]['name'] for side in ['away','home']];winner='Draw' if g['scores'][0]==g['scores'][1] else names[int(g['scores'][1]>g['scores'][0])];row=dict.fromkeys(EU_PRE_COLUMNS);row.update(match='/'.join(names),date=g['date'],timestamp=s,game_type='Soccer',league='EU soccer',competition=CONFIG[code][0],season=g['season'],location=d.get('location') or g.get('location'),home_away='Away;Home',final=winner,teamA_final_score=g['scores'][0],teamB_final_score=g['scores'][1],game_id=gid)
   if (code,mid) in venues:row['home_away']=venues[code,mid]['home_away']
   for c in members:
    side=['teamA','teamB','draw'][c['side']]
    for h in HOURS:p=select(c,'pre_'+str(h),start-h*3600,start,basis=basis);row[f'{side}_pre_{h}_p']=p;row[f'{side}_pre_{h}_odd']=odd(p)
   actual=utc(clock.get('actual_start_utc'));hs=utc(clock.get('halftime_start_utc'));rs=utc(clock.get('second_half_start_utc'));windows=[(actual.timestamp(),actual.timestamp()+120) if actual else (None,None),(hs.timestamp(),rs.timestamp()) if hs and rs else (None,None),(rs.timestamp(),rs.timestamp()+120) if rs else (None,None)];half=d.get('halftime_scores') or [None,None];ing=dict(match=row['match'],game_type='Soccer',league='EU soccer',competition=row['competition'],season=g['season'],timestamp=aligned([utc(lo).isoformat() if lo is not None else None for lo,hi in windows]),checkpoint='START;HALFTIME;SECOND_HALF_START',teamA_score=aligned([0,half[0],half[0]]),teamB_score=aligned([0,half[1],half[1]]),game_id=gid);ing_count=0
   for c in members:
    vals=[select(c,'ingame_'+str(n),lo,start,hi,basis='official_phase_boundary') if lo is not None and hi is not None else None for n,(lo,hi) in enumerate(windows)];side=['teamA','teamB','draw'][c['side']];ing[side+'_ingame_p']=aligned(vals);ing[side+'_ingame_odd']=aligned([odd(v) for v in vals]);ing_count+=sum(v is not None for v in vals)
   if any(row[k] is not None for k in EU_PRE_COLUMNS if k.endswith('_p')) or ing_count:best=(row,ing,ing_count,members,g,d);break
   eligibility.append(dict(provider=provider,competition=code,game_id=gid,family_id=fid,included=False,reason='No usable pregame or break observations acquired'))
  if best:
   row,ing,ing_count,members,g,d=best;outputs[provider]['pre_match'].append(row)
   if ing_count:outputs[provider]['in_game'].append(ing)
   eligibility.append(dict(provider=provider,competition=code,game_id=gid,family_id=members[0]['family_id'],included=True,reason=None));canonical[gid]=dict(game_id=gid,league='EU soccer',competition=row['competition'],game_type='Soccer',date=g['date'],season=g['season'],official_match_id=mid,teams=names,team_ids=[g[x]['id'] for x in ['away','home']],scores=g['scores'],winner=winner,start=s,location=row['location'],home_away=row['home_away'],official_request_id=g['request_id'],completion_utc=d['clock'].get('regulation_end_utc'),clock_basis=basis)
 selected={(x['provider'],x['game_id'],x['family_id']) for x in eligibility if x['included']};us_before=unaffected_us(db)
 for x in audits:x['selected_family']=(x['provider'],x['game_id'],x['family_id']) in selected
 summary=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',published=a.publish,scope='Five additional EU competitions. Supporting tables and missing historical fields remain in progress.',providers={p:{k:len(v) for k,v in ts.items()} for p,ts in outputs.items()},competitions={p:dict(collections.Counter(r['competition'] for r in ts['pre_match'])) for p,ts in outputs.items()},distinct_games=len(canonical),source_hashes=len(src.cache),source_price_conflicts=conflicts,excluded_source_points=excluded,excluded_families=dict(collections.Counter(x['reason'] for x in eligibility if not x['included'])),scheduled_start_fallback_games=sum(g['clock_basis']!='official_actual_kickoff' for g in canonical.values()),missing_percent={p:{c:round(sum(r[c] is None for r in ts['pre_match'])*100/len(ts['pre_match']),4) if ts['pre_match'] else None for c in EU_PRE_COLUMNS} for p,ts in outputs.items()})
 db.commit()
 if a.publish:
  with db:
   for p,ts in outputs.items():
    for kind,rows in ts.items():
     table='_source_'+p+'_soccer_'+kind;columns=EU_PRE_COLUMNS if kind=='pre_match' else EU_INGAME_COLUMNS;db.execute('DELETE FROM '+table+" WHERE competition<>'Premier League'");db.executemany('INSERT INTO '+table+' VALUES ('+','.join('?' for _ in columns)+')',[tuple(r[c] for c in columns) for r in rows])
   for name,rows in [('_eu_odds_selections',audits),('_eu_odds_eligibility',eligibility)]:db.execute('CREATE TABLE IF NOT EXISTS '+name+' (body TEXT NOT NULL) STRICT');db.execute('DELETE FROM '+name);db.executemany('INSERT INTO '+name+' VALUES (?)',[(json.dumps(r),) for r in rows])
   db.execute("DELETE FROM _eu_game_facts WHERE json_extract(body,'$.competition')<>'Premier League'");db.executemany('INSERT INTO _eu_game_facts VALUES (?,?)',[(gid,json.dumps(g)) for gid,g in canonical.items()]);refresh_main_views(db)
  assert unaffected_us(db)==us_before,'Existing US provider outputs changed unexpectedly';summary['unaffected_US_provider_tables']=us_before
  for p in outputs:
   for kind,columns in [('pre_match',EU_PRE_COLUMNS),('in_game',EU_INGAME_COLUMNS)]:
    cur=db.execute('SELECT * FROM '+'_source_'+p+'_soccer_'+kind+' ORDER BY game_id');names=[v[0] for v in cur.description];rows=[dict(zip(names,r)) for r in cur];export('eu_soccer/'+p+'/'+kind,rows,columns,db=db)
 (ROOT/'reports'/('eu_odds_publication.json' if a.publish else 'eu_odds_preview.json')).write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in summary.items() if k!='missing_percent'}),flush=True);db.close()

if __name__=='__main__':main()
