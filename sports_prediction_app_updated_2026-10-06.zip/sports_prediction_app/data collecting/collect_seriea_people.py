"""Date-batched official individual biographies using verified native player IDs."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from urllib.parse import quote
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from probe_seriea_api import BASE
from collect_laliga_people import namekey

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--through-percent',type=int,default=100);a=ap.parse_args();db=sqlite3.connect(DB,timeout=60);c=HistoryClient();HOSTS.add('seriea-api.prd.sdp.deltatre.digital');people={};by_month=collections.defaultdict(list)
 for b, in db.execute('SELECT body FROM _official_seriea_game_reports ORDER BY json_extract(body,\'$.date\')'):
  r=json.loads(b)
  for side in ['away','home']:
   for p in r['sources']['lineups']['data'][side]['fielded']+r['sources']['lineups']['data'][side]['benched']:
    pid=p['playerId'];v=people.setdefault(pid,dict(person_id=pid,first_date=r['date'],source_names=[],lineup_request_id=r['sources']['lineups']['request_id']))
    for n in [' '.join(filter(None,[p.get('mediaFirstName'),p.get('mediaLastName')])),p.get('shortName')]:
     if n and n not in v['source_names']:v['source_names'].append(n)
 with db:db.execute('CREATE TABLE IF NOT EXISTS _official_seriea_people_sources (person_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
 done={pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _official_seriea_people_sources')}
 for p in list(people.values())[:3 if a.pilot else None]:by_month[p['first_date'][:7]].append(p)
 def fetch(p):
  pid=p['person_id']
  if pid in done:return pid,done[pid]
  row=dict(p);url=BASE+'/players/'+quote(pid,safe='')+'/profile'
  try:
   d,r=c.get(url);assert d['playerId']==pid;name=' '.join(filter(None,[d.get('mediaFirstName'),d.get('mediaLastName')]));assert {namekey(name),namekey(d.get('shortName') or '')}&{namekey(n) for n in p['source_names']};row.update(status='ok',request_id=r['request_id'],endpoint=url,data=d)
  except Exception as e:row.update(status='unavailable',error=str(e))
  return pid,row
 day=dt.date(2024,1,1);parts=[];milestone=10
 while day<=dt.date(2026,9,14) and (a.pilot or len(parts)<math.ceil(33*a.through_percent/100)):
  month=day.strftime('%Y-%m');counts=collections.Counter()
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
   for pid,row in pool.map(fetch,by_month[month]):
    if pid not in done:
     with db:db.execute('INSERT OR REPLACE INTO _official_seriea_people_sources VALUES (?,?)',(pid,json.dumps(row)))
    counts[row['status']]+=1
  parts.append(dict(month=month,people=len(by_month[month]),counts=dict(counts)));out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Official Serie A biographies by first collected game date',pilot=a.pilot,processed_months=len(parts),total_months=33,total_people=3 if a.pilot else len(people),new_requests=c.requests,months=parts);(ROOT/'reports'/('seriea_people_'+('pilot' if a.pilot else 'months')+'.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
  if counts:print('SERIE A PEOPLE',month,dict(counts),flush=True)
  while not a.pilot and milestone<=100 and len(parts)>=math.ceil(33*milestone/100):print('SERIE A PEOPLE DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print('SERIE A BIOGRAPHY NEW REQUESTS',c.requests,flush=True);db.close()

if __name__=='__main__':main()
