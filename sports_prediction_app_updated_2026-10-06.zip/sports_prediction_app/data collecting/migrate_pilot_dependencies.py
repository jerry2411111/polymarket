"""Preserve still-used raw evidence and helpers before removing the superseded pilot."""
import ast
import datetime as dt
import hashlib
import json
import shutil
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OLD = Path(r'C:\Users\Jerry\Desktop\sentinent snake')


def main():
    if OLD.resolve() == ROOT.resolve():
        print('Migration already complete: Desktop path points to this project.', flush=True)
        return
    db = sqlite3.connect(ROOT / 'data/result/sentinent_snake.sqlite', timeout=60)
    from request_audit import describe, export_log
    evidence = []
    records = [json.loads(line) for line in (OLD / 'data/raw/requests.jsonl').read_text(encoding='utf-8').splitlines() if line]
    with db:
        for r in records:
            source = (OLD / r['raw_file']).resolve()
            assert source.is_relative_to(OLD.resolve() / 'data/raw')
            raw = source.read_bytes()
            assert hashlib.sha256(raw).hexdigest() == r['sha256'], r['request_id']
            destination = (ROOT / r['raw_file']).resolve()
            assert destination.is_relative_to(ROOT.resolve() / 'data/raw')
            destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.exists():
                assert destination.read_bytes() == raw
            else:
                destination.write_bytes(raw)
            assert hashlib.sha256(destination.read_bytes()).hexdigest() == r['sha256']
            old = db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?', (r['request_id'],)).fetchone()
            if old:
                assert json.loads(old[0]) == r
            else:
                kind, intent, status = describe(r)
                db.execute('INSERT INTO _request_audit(request_id,request_type,requested_data,return_status,metadata_json) VALUES (?,?,?,?,?)',
                           (r['request_id'], kind, intent, status, json.dumps(r)))
            evidence.append(dict(request_id=r['request_id'], raw_file=r['raw_file'], sha256=r['sha256'], bytes=len(raw)))
        old_report = (OLD / 'reports/validation.json').read_bytes()
        anchors = json.loads(old_report)['games']
        db.execute('CREATE TABLE IF NOT EXISTS _verified_pilot_anchors (game_id TEXT PRIMARY KEY,body TEXT NOT NULL,original_report_sha256 TEXT NOT NULL) STRICT')
        for row in anchors:
            db.execute('INSERT OR IGNORE INTO _verified_pilot_anchors VALUES (?,?,?)',
                       (row['game_id'], json.dumps(row), hashlib.sha256(old_report).hexdigest()))
    exported = []
    helper_specs = [
        ('core', ['utc', 'iso', 'num', 'odd', 'array', 'pointer', 'boundary', 'checkpoint_rows'],
         'import datetime as dt\nimport json,math\nfrom decimal import Decimal\n'),
        ('people', ['namekey', 'minutes'], 'import unicodedata\n'),
        ('temporal_sql', ['export'], 'import csv,hashlib\nimport pyarrow as pa\nimport pyarrow.parquet as pq\n')]
    for original, names, imports in helper_specs:
        path = OLD / 'data collecting' / (original + '.py')
        source = path.read_text(encoding='utf-8')
        nodes = {node.name: node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef)}
        parts = [ast.get_source_segment(source, nodes[name]) for name in names]
        name = 'dataset_export' if original == 'temporal_sql' else original
        destination = ROOT / 'data collecting' / (name + '.py')
        text = '"""Helpers retained from verified acquisition; obsolete pilot builders removed."""\n' + imports + '\n\n' + '\n\n'.join(parts) + '\n'
        compile(text, str(destination), 'exec')
        destination.write_text(text, encoding='utf-8')
        exported.append(dict(module=name, functions=names, original_module_sha256=hashlib.sha256(source.encode()).hexdigest(),
                             retained_module_sha256=hashlib.sha256(text.encode()).hexdigest()))
    instructions = []
    for path in (OLD / 'instruction').glob('*'):
        if not path.is_file():
            continue
        target = ROOT / 'instruction' / path.name
        if target.exists():
            if target.read_bytes() == path.read_bytes():
                continue
            target = target.with_name('original_' + target.name)
        if not target.exists():
            shutil.copy2(path, target)
        assert target.read_bytes() == path.read_bytes()
        instructions.append(target.relative_to(ROOT).as_posix())
    web_captures = []
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _retained_web_source_captures (relative_path TEXT PRIMARY KEY,sha256 TEXT NOT NULL,bytes INTEGER NOT NULL,migrated_at_utc TEXT NOT NULL) STRICT')
        for path in sorted((OLD/'data/raw/web_research').glob('*.json')):
            relative = path.relative_to(OLD).as_posix()
            raw = path.read_bytes()
            destination = ROOT/relative
            destination.parent.mkdir(exist_ok=True)
            if destination.exists():
                assert destination.read_bytes() == raw
            else:
                destination.write_bytes(raw)
            digest = hashlib.sha256(raw).hexdigest()
            assert hashlib.sha256(destination.read_bytes()).hexdigest() == digest
            db.execute('INSERT OR IGNORE INTO _retained_web_source_captures VALUES (?,?,?,?)',
                       (relative,digest,len(raw),dt.datetime.now(dt.UTC).isoformat()))
            web_captures.append(dict(relative_path=relative,sha256=digest,bytes=len(raw)))
    export_log(ROOT, db)
    report = dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(), status='MIGRATED_REQUIRES_RUNTIME_VALIDATION',
                  original_requests=len(records), raw_bytes=sum(r['bytes'] for r in evidence),
                  retained_source_evidence=evidence, retained_helpers=exported, instructions_preserved=instructions,
                  anchors=len(anchors), logged_requests=db.execute('SELECT count(*) FROM _request_audit').fetchone()[0],
                  retained_web_source_captures=web_captures,original_pilot_deleted=False)
    (ROOT / 'reports/pilot_dependency_migration.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in {'retained_source_evidence','retained_helpers'}}), flush=True)
    db.close()


if __name__ == '__main__':
    main()
