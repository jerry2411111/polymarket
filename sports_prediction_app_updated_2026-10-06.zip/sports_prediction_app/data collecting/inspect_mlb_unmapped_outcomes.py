import json,sqlite3
from build_history_catalog import DB
from history_index import index
db=sqlite3.connect(DB);ids={json.loads(b)['market_id'] for b, in db.execute('SELECT body FROM _mlb_market_matching_audit') if 'labels' in json.loads(b)['reason']};data=index();n=0
for eid,(e,_,_) in data['polymarket_events'].items():
    for m in e.get('markets',[]):
        if m['id'] in ids and json.loads(m.get('outcomes','[]'))!=['Yes','No']:
            print(json.dumps({k:m.get(k) for k in ['id','question','slug','description','gameStartTime','outcomes','closed','umaResolutionStatus']}));n+=1
print('COUNT',n)
