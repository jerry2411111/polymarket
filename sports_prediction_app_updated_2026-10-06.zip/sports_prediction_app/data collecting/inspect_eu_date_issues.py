"""List unresolved metadata dates alongside official opponent/date candidates."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources,pointer
from eu_official_games import CONFIG,games
from probe_history import ROOT
db=sqlite3.connect(DB);src=Sources(db);official={code:games(db,code) for code in CONFIG};issues=[]
for code,b in db.execute('SELECT competition,body FROM _eu_matching_issues'):
 i=json.loads(b)
 if not any(t in i['reason'] for t in ['date','start times','six hours']):continue
 candidates=[]
 if i.get('official_match_id'):candidates=[official[code][i['official_match_id']]]
 elif i.get('team_ids'):
  candidates=[g for g in official[code].values() if {g['away']['id'],g['home']['id']}==set(i['team_ids']) and (not i.get('date') or abs((dt.date.fromisoformat(g['date'])-dt.date.fromisoformat(i['date'])).days)<=10)]
 if i['provider']=='polymarket':
  row=db.execute('SELECT body FROM _eu_pm_events WHERE event_id=?',(i['family_id'],)).fetchone();e=json.loads(row[0]);detail=dict(title=e['title'],start=e.get('startTime'),end=e.get('endDate'),markets=[dict(id=m['id'],q=m['question'],start=m.get('gameStartTime'),desc=m.get('description','')[:160]) for m in e.get('markets',[]) if m.get('sportsMarketType') in [None,'moneyline']][:3])
 else:
  row=db.execute("SELECT body FROM _eu_kalshi_markets WHERE competition=? AND json_extract(body,'$.event_ticker')=? LIMIT 1",(code,i['family_id'])).fetchone();m=json.loads(row[0]);detail=dict(title=m['title'],rules=m['rules_primary'])
 out=dict(**i,source=detail,official_nearby=[dict(id=g['official_match_id'],date=g['date'],start=g['scheduled_start_utc'],match=g['away']['name']+' / '+g['home']['name'],status=g['status']) for g in candidates]);issues.append(out);print(code,i['provider'],i['family_id'],i['reason'],[(g['date'],g['official_match_id']) for g in candidates])
(ROOT/'reports/eu_date_issues.json').write_text(json.dumps(issues,indent=2),encoding='utf-8')
db.close()
