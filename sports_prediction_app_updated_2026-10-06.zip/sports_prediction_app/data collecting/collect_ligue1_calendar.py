"""Date-batched official Ligue 1 rounds, filtered by actual local game date."""
import argparse,calendar,collections,datetime as dt,json,math,sqlite3
from zoneinfo import ZoneInfo
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from probe_ligue1_history import BASE

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100;assert json.loads((ROOT/'reports/ligue1_pilot_validation.json').read_text())['status']=='WORKING';HOSTS.add('ma-api.ligue1.fr');client=HistoryClient();db=sqlite3.connect(DB,timeout=60);rounds=collections.defaultdict(list)
    for table,key in [('_official_ligue1_calendar','match_id'),('_official_ligue1_rounds','round_key')]:db.execute('CREATE TABLE IF NOT EXISTS '+table+' ('+key+' TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
    db.commit()
    for year in [2023,2024,2025,2026]:
        data,r=client.get(BASE+'/championship-calendar/1',dict(season=year));assert len(data['gameWeeks'])==34
        for w in data['gameWeeks'].values():
            if w['startDate'][:10]>'2026-09-14':continue
            rounds[max(w['startDate'][:7],'2024-01')].append((year,w,r['request_id']))
    day=dt.date(2024,1,1);parts=[]
    while day<=dt.date(2026,9,14) and len(parts)<math.ceil(33*a.through_percent/100):
        month=day.strftime('%Y-%m');errors=[];before=client.requests
        for year,w,calendar_rid in rounds[month]:
            week=w['gameWeekNumber'];key=str(year)+':'+str(week)
            if db.execute('SELECT 1 FROM _official_ligue1_rounds WHERE round_key=?',(key,)).fetchone():continue
            try:
                data,r=client.get(BASE+f'/championship-matches/championship/1/game-week/{week}',dict(season=year));ms=data['matches'];assert len(ms)==len(set(w['matchesIds'])) and {m['matchId'] for m in ms}==set(w['matchesIds']),'Round response differs from official native-ID calendar';rows=[]
                for i,m in enumerate(ms):
                    assert m['championshipId']==1 and m['gameWeekNumber']==week and not m['unknownMatch'];when=dt.datetime.fromisoformat(m['date']);assert when.tzinfo;date=when.astimezone(ZoneInfo('Europe/Paris')).date().isoformat()
                    if not '2024-01-01'<=date<='2026-09-14' or m['period']!='fullTime':continue
                    assert not m['isLive'];teams=[m[s]['clubIdentity'] for s in ['away','home']];scores=[m[s]['score'] for s in ['away','home']];assert all(type(v)is int and v>=0 for v in scores);assert teams[0]['id']!=teams[1]['id']
                    for side,t in zip(['away','home'],teams):assert t['id']==m[side]['clubId'] and t['id'].startswith('l1_championship_club_'+str(year)+'_')
                    g=dict(official_match_id=m['matchId'],competition='Ligue 1',competition_id=1,season=str(year)+'-'+str(year+1)[2:],date=date,scheduled_start_utc=when.astimezone(dt.UTC).isoformat(),home=m['home']['clubIdentity'],away=m['away']['clubIdentity'],scores=scores,winner='Draw' if scores[0]==scores[1] else teams[int(scores[1]>scores[0])]['name'],status=m['period'],request_id=r['request_id'],calendar_request_id=calendar_rid,pointer='/matches/'+str(i),raw=m);old=db.execute('SELECT body FROM _official_ligue1_calendar WHERE match_id=?',(g['official_match_id'],)).fetchone();assert not old or json.loads(old[0])['raw']==m;rows.append((g['official_match_id'],json.dumps(g)))
                with db:db.executemany('INSERT OR REPLACE INTO _official_ligue1_calendar VALUES (?,?)',rows);db.execute('INSERT INTO _official_ligue1_rounds VALUES (?,?)',(key,json.dumps(dict(season=year,week=week,request_id=r['request_id'],calendar_request_id=calendar_rid,source_games=len(ms),in_scope_completed=len(rows)))))
            except Exception as e:errors.append(dict(season=year,week=week,error=type(e).__name__+': '+str(e)));break
        parts.append(dict(month=month,rounds=len(rounds[month]),errors=errors));total=db.execute('SELECT count(*) FROM _official_ligue1_calendar').fetchone()[0];out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='ACQUIRED_REQUIRES_FULL_RAW_VALIDATION',total_months=33,months_processed=len(parts),completed_games=total,new_requests=client.requests,months=parts,scope='Only the official league calendar; prices and supporting tables require independent acquisition and validation');(ROOT/'reports/ligue1_calendar_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        if client.requests>before or errors:print('LIGUE1 CALENDAR',month,'games',total,'months',len(parts),'/33','errors',errors,flush=True)
        if errors:break
        day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
    db.close()

if __name__=='__main__':main()
