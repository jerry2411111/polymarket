"""Count field-level weather gaps for MLB-linked city/dates."""
import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB);db.row_factory=sqlite3.Row
rows=[dict(r) for r in db.execute("""SELECT w.city,count(*) AS city_dates,sum(w.temperature_c IS NULL) AS missing_temperature,sum(w.humidity_pct IS NULL) AS missing_humidity,sum(w.weather_type IS NULL) AS missing_weather_type,sum(w.wind_direction IS NULL) AS missing_wind FROM weather w WHERE EXISTS(SELECT 1 FROM _game_weather_links l WHERE l.city=w.city AND l.date=w.date AND l.game_id LIKE 'MLB_%') GROUP BY w.city HAVING sum(w.temperature_c IS NULL)>0 ORDER BY missing_temperature DESC""")]
print(json.dumps(rows,ensure_ascii=False,indent=2));db.close()
