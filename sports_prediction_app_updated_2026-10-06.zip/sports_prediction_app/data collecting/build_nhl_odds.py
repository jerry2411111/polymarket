"""Publish verified NHL rows while preserving all other leagues byte for byte.

Each provider/game uses one coherent two-team contract family. Raw Polymarket
bucket starts are never treated as completed observations. The official feed
supplies reported puck drop, intermission windows, scores, venue and participant identities.
"""
import argparse,collections,datetime as dt,hashlib,json,math,sqlite3
from zoneinfo import ZoneInfo
from build_history_catalog import DB,ORIGINAL
from build_history_odds import export
from history_index import records,payload
from core import utc,odd
from schema import PRE_COLUMNS,INGAME_COLUMNS,HOURS,CHECKPOINTS,aligned
from quote_selection import available_at,nearest_pregame,inside_window
from probe_history import ROOT

def digest_other_leagues(db):
    return {name:hashlib.sha256(json.dumps(db.execute('SELECT * FROM '+name+" WHERE league!='NHL' ORDER BY game_id").fetchall(),separators=(',',':')).encode()).hexdigest() for name in ['polymarket_pre_match','kalshi_pre_match','polymarket_in_game','kalshi_in_game']}

def load_points(db,contracts):
    points={};seen=set();conflicts=[];parsed=[]
    for b, in db.execute('SELECT body FROM _history_price_points'):
        x=json.loads(b)
        if (x['provider'],x['contract_id']) not in contracts:continue
        points[x['provider'],x['contract_id'],x['timestamp'],x['kind'],x['resolution_seconds']]=x
    # Consumed raw responses can contain null-only history and no stored points.
    for name in ['_history_price_requests','_nhl_price_requests']:
        if db.execute('SELECT 1 FROM sqlite_master WHERE name=?',(name,)).fetchone():seen.update(r[0] for r in db.execute('SELECT request_id FROM '+name))
    reused=len(points)
    for root in dict.fromkeys([ORIGINAL,ROOT]):
        for r in records(root):
            if r.get('status')!=200 or r['request_id'] in seen:continue
            u=r['endpoint'];p=r.get('parameters',{})
            if not u.endswith(('/candlesticks','/prices-history')) or '/markets/candlesticks' in u:continue
            provider='kalshi' if 'kalshi.com/' in u else 'polymarket'
            cid=u.split('/markets/')[-1].split('/')[0] if provider=='kalshi' else p.get('token_id') or p.get('market')
            if (provider,cid) not in contracts:continue
            d=payload(r,root);parsed.append(r['request_id']);seen.add(r['request_id'])
            if provider=='kalshi':
                assert d.get('ticker')==cid;kind='candle';items=d.get('candlesticks',[]);suffix='close' if '/historical/' in u else 'close_dollars'
            else:kind='v2' if '/v2/' in u else 'clob';items=d.get('data' if kind=='v2' else 'history',[])
            for n,v in enumerate(items):
                if kind=='candle':
                    price=v.get('yes_bid',{}).get(suffix);ask=v.get('yes_ask',{}).get(suffix);ts=v['end_period_ts'];resolution=int(p['period_interval'])*60;pointer=f'/candlesticks/{n}/yes_bid/{suffix}'
                    if price is not None and ask is not None and float(price)>float(ask):
                        conflicts.append(dict(request_id=r['request_id'],pointer=pointer,reason='Crossed source bid/ask excluded'));continue
                else:
                    tk,pk=('timestamp','price') if kind=='v2' else ('t','p');price=v.get(pk);ts=v[tk];resolution=v.get('resolution_seconds',int(p.get('fidelity',1))*60);pointer=f'/{"data" if kind=="v2" else "history"}/{n}/{pk}'
                if price is None:continue
                price=float(price);assert math.isfinite(price) and 0<=price<=1;assert isinstance(ts,int) and resolution>=0
                x=dict(provider=provider,contract_id=cid,timestamp=ts,price=price,implied_probability=price,resolution_seconds=resolution,request_id=r['request_id'],pointer=pointer,kind=kind,retrieved_at_utc=r['retrieved_at_utc'])
                key=provider,cid,ts,kind,resolution;old=points.get(key)
                if old and old['price']!=price:conflicts.append(dict(reason='Changed source observation; latest retrieved version selected',previous=old,replacement=x))
                if old and utc(old['retrieved_at_utc'])>=utc(x['retrieved_at_utc']):continue
                points[key]=x
    return list(points.values()),parsed,conflicts,reused

def enrich(g,f,s,sources):
    g=dict(g);assert g['official_game_id']==f['official_game_id'];assert g['team_ids']==f['official_team_ids'] and g['scores']==f['scores']
    # Official English player/team records use Montreal; some date cards use
    # the accented place label. Keep native IDs and original spelling in raw.
    g['teams']=[name.replace('Montréal Canadiens','Montreal Canadiens') for name in g['teams']]
    g['winner']=g['winner'].replace('Montréal Canadiens','Montreal Canadiens')
    r=sources[f['request_ids']['boxscore']];raw=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];box=json.loads(raw)
    end=[x['timestamp_utc'] for x in f['period_clock_events'] if x['event']=='GEND' and x['timestamp_utc']]
    completion=(utc(end[-1])+dt.timedelta(minutes=1)).astimezone(ZoneInfo(g['venue_timezone'])).date().isoformat() if end and g['venue_timezone'] else (dt.date.fromisoformat(g['date'])+dt.timedelta(days=1)).isoformat()
    g.update(start=f['actual_start_utc'] or s['scheduled_start_utc'],start_basis='Official NHL scorer-report opening minute' if f['actual_start_utc'] else 'Official NHL scheduled start; actual start unavailable',start_precision_seconds=60 if f['actual_start_utc'] else None,location=box.get('venue',{}).get('default'),city=box.get('venueLocation',{}).get('default'),city_request_id=r['request_id'],city_pointer='/venueLocation/default',break_scores=f['break_scores'],result_request_id=r['request_id'],result_pointer='/',classification_request_id=s['request_id'],classification_source_url=sources[s['request_id']]['endpoint'],last_play_utc=end[-1] if end else None,completion_local_date=completion,completion_date_basis='Official reported game-end minute plus its one-minute precision' if end else 'Conservative next local date; official wall-clock end unavailable',spans_multiple_local_dates=completion!=g['date'],validation_status='OFFICIAL_NHL_SCHEDULE_AND_REPORTS_MATCH')
    g['home_away_basis']='Official NHL schedule home/away designations; neutral-site flag means both Away'
    if s['game_type_code'] in [19,20]:
        # Official NHL native city and the national participant IDs establish
        # the host nation. National teams are not treated as local NHL clubs.
        country={'Boston':'67','Montreal':'60','Montréal':'60'}.get(g['city'])
        if country:g['home_away']=';'.join('Home' if tid==country else 'Away' for tid in g['team_ids']);g['home_away_basis']='National-team venue country from the official NHL game city'
    return g

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inspect-only',action='store_true');args=ap.parse_args();db=sqlite3.connect(DB,timeout=60)
    games={i:json.loads(b) for i,b in db.execute('SELECT * FROM _nhl_canonical_games')};cs=[json.loads(b) for b, in db.execute('SELECT body FROM _nhl_market_candidates')];contracts={(c['provider'],c['contract_id']):c for c in cs}
    feeds={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_nhl_game_reports')};schedules={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_nhl_schedule')}
    missing=[g['game_id'] for g in games.values() if g['official_game_id'] not in feeds]
    if missing:raise ValueError('Official feed acquisition incomplete for '+str(len(missing))+' matched games')
    official_sources={r['request_id']:r for r in records()}
    games={i:enrich(g,feeds[g['official_game_id']],schedules[g['official_game_id']],official_sources) for i,g in games.items()}
    print('NHL ODDS: reading retained price responses',flush=True)
    points,parsed,conflicts,reused=load_points(db,contracts);grouped=collections.defaultdict(list);terminal_exclusions=0
    print('NHL ODDS: selecting from',len(points),'points;',len(parsed),'new responses',flush=True)
    for x in points:
        c=contracts[x['provider'],x['contract_id']];opened=utc(c['open'])
        if opened and x['timestamp']<opened.timestamp():continue
        # The official API may append a settlement payout at a synthetic,
        # window-clamped timestamp. The payload does not identify whether a
        # zero-width terminal point is a trade or payout. Do not use these
        # ambiguous exact points as historical features of completed markets.
        if x['kind']=='v2' and x['resolution_seconds']==0:
            terminal_exclusions+=1;continue
        grouped[x['provider'],x['contract_id']].append(x)
    families=collections.defaultdict(list)
    for c in cs:families[c['game_id'],c['provider'],c['market_id'] if c['provider']=='polymarket' else c['event_id']].append(c)
    bygame=collections.defaultdict(list);family_audit=[]
    for (gid,provider,fid),members in families.items():
        sides=collections.Counter(c['side'] for c in members);g=games[gid];start=utc(g['start']).timestamp()
        valid=sides=={0:1,1:1};precount=sum(nearest_pregame(grouped[c['provider'],c['contract_id']],start-h*3600,start) is not None for c in members for h in HOURS) if valid else 0
        intervals=([(start+60,start+120)] if feeds[g['official_game_id']]['actual_start_utc'] else [])+[(utc(b['start_utc']).timestamp(),utc(b['end_utc']).timestamp()) for b in feeds[g['official_game_id']]['breaks'] if b['start_utc'] and b['end_utc']]
        ingcount=sum(any(inside_window(x,lo,hi) for x in grouped[c['provider'],c['contract_id']]) for c in members for lo,hi in intervals) if valid else 0
        opened=max((utc(c['open']).timestamp() for c in members if utc(c['open'])),default=float('inf'))
        rec=dict(game_id=gid,provider=provider,family_id=fid,valid_two_team_family=valid,pre_slots=precount,in_game_slots=ingcount,open_timestamp=opened if math.isfinite(opened) else None,selected=False)
        family_audit.append(rec)
        if valid and precount+ingcount:bygame[gid,provider].append((opened,fid,members,rec))
    outputs={p:{'pre_match':[],'in_game':[]} for p in ['polymarket','kalshi']};audits=[];eligibility=[]
    def select(c,g,label,lo,hi=None):
        xs=grouped[c['provider'],c['contract_id']];start=utc(g['start']).timestamp();ispre=label.startswith('pre_')
        x=nearest_pregame(xs,lo,start) if ispre else min((x for x in xs if inside_window(x,lo,hi)),key=lambda x:(available_at(x),x['timestamp'],x['resolution_seconds'],x['contract_id']),default=None)
        reason=None if x else 'No previous completed observation available' if ispre else 'No quote inside verified opening/break interval' if lo is not None and hi is not None else 'Official break interval unavailable'
        audits.append(dict(provider=c['provider'],game_id=g['game_id'],side=c['side'],market_id=c['market_id'],contract_id=c['contract_id'],target=label,target_timestamp_utc=utc(lo).isoformat() if lo is not None else None,window_end_utc=utc(hi).isoformat() if hi is not None else None,source_timestamp_utc=utc(x['timestamp']).isoformat() if x else None,source_available_at_utc=utc(available_at(x)).isoformat() if x else None,source_age_seconds=lo-x['timestamp'] if x else None,source_resolution_seconds=x['resolution_seconds'] if x else None,source_price=x['price'] if x else None,normalized_price=x['price'] if x else None,request_id=x['request_id'] if x else None,pointer=x['pointer'] if x else None,source_kind=x['kind'] if x else None,selection_method='Latest completed previous observation, with raw timestamp strictly before reported puck drop' if ispre else 'First completed observation fully inside the official opening/break interval',reason=reason))
        return x['price'] if x else None
    for gid,provider in sorted({(c['game_id'],c['provider']) for c in cs}):
        g=games[gid];choices=bygame[gid,provider]
        if not choices:
            eligibility.append(dict(game_id=gid,provider=provider,league='NHL',included=False,usable_odds=False,reason='No coherent two-team contract family has usable odds'));continue
        _,_,members,rec=min(choices,key=lambda x:(x[0],x[1]));rec['selected']=True;start=utc(g['start']).timestamp();f=feeds[g['official_game_id']]
        row=dict.fromkeys(PRE_COLUMNS);row.update(match='/'.join(g['teams']),date=g['date'],timestamp=g['start'],game_type='Hockey',league='NHL',season=g['season'],location=g['location'],home_away=g['home_away'],final=g['winner'],teamA_final_score=g['scores'][0],teamB_final_score=g['scores'][1],game_id=gid)
        for c in members:
            side='AB'[c['side']]
            for h in HOURS:
                p=select(c,g,'pre_'+str(h),start-h*3600);row[f'team{side}_pre_{h}_p']=p;row[f'team{side}_pre_{h}_odd']=odd(p)
        windows=[(start+60,start+120)] if f['actual_start_utc'] else [(None,None)]
        windows += [(utc(b['start_utc']).timestamp() if b['start_utc'] else None,utc(b['end_utc']).timestamp() if b['end_utc'] else None) for b in f['breaks']]
        assert len(windows)==3 and len(g['break_scores'])==3
        ing=dict(match=row['match'],game_type='Hockey',league='NHL',season=g['season'],timestamp=aligned([utc(lo).isoformat() if lo is not None else None for lo,hi in windows]),checkpoint=';'.join(CHECKPOINTS['Hockey']),teamA_score=aligned([s[0] for s in g['break_scores']]),teamB_score=aligned([s[1] for s in g['break_scores']]),game_id=gid)
        for c in members:
            vals=[select(c,g,'ingame_'+str(n),lo,hi) for n,(lo,hi) in enumerate(windows)];side='AB'[c['side']];ing[f'team{side}_ingame_p']=aligned(vals);ing[f'team{side}_ingame_odd']=aligned([odd(p) for p in vals])
        outputs[provider]['pre_match'].append(row);outputs[provider]['in_game'].append(ing);eligibility.append(dict(game_id=gid,provider=provider,league='NHL',date=g['date'],is_training=g['is_training'],included=True,usable_odds=True,reason=None))
    # Check every chosen number directly against the preserved original response.
    source_records={r['request_id']:(r,root) for root in dict.fromkeys([ORIGINAL,ROOT]) for r in records(root)};values=collections.defaultdict(list)
    for a in audits:
        if a['request_id']:values[a['request_id']].append(a)
    checks=0
    print('NHL ODDS: checking raw values and hashes for',len(values),'responses',flush=True)
    for rid,items in values.items():
        r,root=source_records[rid];raw=(root/r['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];d=json.loads(raw)
        for a in items:
            requested_contract=r['endpoint'].split('/markets/')[-1].split('/')[0] if a['provider']=='kalshi' else r['parameters'].get('token_id') or r['parameters'].get('market')
            assert requested_contract==a['contract_id'],'Price request belongs to another outcome token/contract'
            v=d
            for key in a['pointer'].strip('/').split('/'):v=v[int(key)] if isinstance(v,list) else v[key]
            assert float(v)==a['normalized_price'];checks+=1
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='NHL main and in-game tables; supporting tables have separate coverage',canonical_candidate_games=len(games),reused_points=reused,price_points=len(points),new_price_responses=len(parsed),source_observation_conflicts=len(conflicts),ambiguous_zero_duration_terminal_points_excluded=terminal_exclusions,raw_value_checks=checks,source_hash_checks=len(values),providers={p:len(v['pre_match']) for p,v in outputs.items()},earliest=min((r['date'] for v in outputs.values() for r in v['pre_match']),default=None),latest=max((r['date'] for v in outputs.values() for r in v['pre_match']),default=None),missing_reasons=dict(collections.Counter(a['reason'] for a in audits if a['reason'])),excluded_provider_game_pairs=sum(not e['included'] for e in eligibility),inspection_only=args.inspect_only)
    if not args.inspect_only:
        print('NHL ODDS: publishing scoped SQL replacement',flush=True)
        before=digest_other_leagues(db)
        with db:
            for provider,tables in outputs.items():
                for kind,rows in tables.items():
                    name='_source_'+provider+'_us_'+kind;columns=PRE_COLUMNS if kind=='pre_match' else INGAME_COLUMNS
                    db.execute('DELETE FROM '+name+" WHERE league='NHL'");db.executemany('INSERT INTO '+name+' VALUES ('+','.join('?' for _ in columns)+')',[tuple(r[k] for k in columns) for r in rows])
            db.execute("DELETE FROM _official_game_facts WHERE json_extract(body,'$.league')='NHL'")
            db.executemany('INSERT INTO _official_game_facts VALUES (?,?)',[(gid,json.dumps(g)) for gid,g in games.items()])
            db.executemany('UPDATE _nhl_canonical_games SET body=? WHERE id=?',[(json.dumps(g),gid) for gid,g in games.items()])
            db.execute('CREATE TEMP TABLE _nhl_contract_ids (provider TEXT,contract_id TEXT,PRIMARY KEY(provider,contract_id))')
            db.executemany('INSERT INTO _nhl_contract_ids VALUES (?,?)',list(contracts))
            db.execute("DELETE FROM _history_price_points WHERE EXISTS (SELECT 1 FROM _nhl_contract_ids c WHERE c.provider=json_extract(body,'$.provider') AND c.contract_id=json_extract(body,'$.contract_id'))")
            db.executemany('INSERT INTO _history_price_points VALUES (?)',[(json.dumps(x),) for x in points])
            for name,rows in [('_nhl_price_conflicts',conflicts),('_nhl_family_selection',family_audit)]:
                db.execute('CREATE TABLE IF NOT EXISTS '+name+' (body TEXT NOT NULL)');db.execute('DELETE FROM '+name);db.executemany('INSERT INTO '+name+' VALUES (?)',[(json.dumps(r),) for r in rows])
            for name,rows in [('_history_selections',audits),('_game_odds_eligibility',eligibility)]:
                db.execute("DELETE FROM "+name+" WHERE json_extract(body,'$.game_id') LIKE 'NHL_%'");db.executemany('INSERT INTO '+name+' VALUES (?)',[(json.dumps(r),) for r in rows])
            db.execute('CREATE TABLE IF NOT EXISTS _nhl_price_requests (request_id TEXT PRIMARY KEY) STRICT');db.executemany('INSERT OR IGNORE INTO _nhl_price_requests VALUES (?)',[(r,) for r in parsed])
            after=digest_other_leagues(db);assert before==after,'Another league changed during scoped NHL installation'
        report['unchanged_other_league_sha256']=after
        for p,tables in outputs.items():
            for kind in tables:
                name='_source_'+p+'_us_'+kind;cols=PRE_COLUMNS if kind=='pre_match' else INGAME_COLUMNS;rows=[dict(zip(cols,r)) for r in db.execute('SELECT * FROM '+name+' ORDER BY date,game_id' if kind=='pre_match' else 'SELECT * FROM '+name+' ORDER BY game_id')];export(p+'/'+kind,rows,cols,db=db)
    db.close();(ROOT/'reports/nhl_odds_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
