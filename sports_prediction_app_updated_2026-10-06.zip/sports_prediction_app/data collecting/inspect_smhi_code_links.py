import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT

db=sqlite3.connect(DB);report=json.loads((ROOT/'reports/smhi_quality_and_codes.json').read_text());rid=report['code_documentation']['request_id'];r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);text=(ROOT/r['raw_file']).read_text(encoding='utf-8');s=BeautifulSoup(text,'html.parser');print('SCRIPTS',[a['src'] for a in s.find_all('script',src=True)]);print('APP LINKS',list(dict.fromkeys(re.findall(r'https?[^\s<>"\\]+',text)))[:80]);print('CODE MATCHES',[text[max(0,m.start()-120):m.end()+250] for m in list(re.finditer(r'parameterCode|metobs/codes|signifikant|parameter.?13',text))[:8]])
for rid,b in db.execute("SELECT request_id,metadata_json FROM _request_audit WHERE json_extract(metadata_json,'$.endpoint') LIKE '%/parameter/13.json' AND return_status='200'"):
    r=json.loads(b);d=json.loads((ROOT/r['raw_file']).read_bytes());print('PARAMETER KEYS',list(d));print('PARAM LINKS',d.get('link'))
db.close()
