"""Capture current official documentation and public league clients before implementation."""
import argparse,datetime as dt,json
from urllib.parse import urljoin,urlsplit
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

DOCS=['https://docs.polymarket.com/llms.txt','https://docs.polymarket.com/_llms/en/api-reference/predictions.md','https://docs.polymarket.com/api-spec/gamma-openapi.yaml','https://docs.kalshi.com/api-reference/market/get-series-list.md','https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps.md']
PAGES=['https://www.premierleague.com/en/matches/premier-league/2026-27','https://www.laliga.com/en-GB/laliga-easports/results','https://www.bundesliga.com/en/bundesliga/matchday','https://www.legaseriea.it/serie-a/calendario-risultati','https://ligue1.com/en/calendar/ligue1','https://www.uefa.com/uefachampionsleague/fixtures-results/']

def main():
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['docs','pages']);args=ap.parse_args();urls=DOCS if args.stage=='docs' else PAGES;HOSTS.update(urlsplit(u).hostname for u in urls);client=HistoryClient();out=[]
    for url in urls:
        try:
            b,r=client.get(url,document=True);s=b.decode('utf-8',errors='replace');item=dict(url=url,request_id=r['request_id'],status=r['status'])
            if args.stage=='docs':
                item['lines']=len(s.splitlines());print(url,'\n'+ ('\n'.join(x for x in s.splitlines() if any(t in x.lower() for t in ['sport','series','historical','/tags','/teams'])) if len(s)>50000 else s[:26000]),flush=True)
            else:
                soup=BeautifulSoup(s,'html.parser');base=soup.find('base',href=True);base_url=urljoin(url,base['href']) if base else url;item['scripts']=[urljoin(base_url,x['src']) for x in soup.find_all('script',src=True)];item['title']=soup.title.get_text() if soup.title else None;item['embedded_data']=[dict(id=x.get('id'),type=x.get('type'),length=len(x.get_text())) for x in soup.find_all('script') if not x.get('src') and len(x.get_text())>100];print(json.dumps(dict(url=url,request_id=r['request_id'],title=item['title'],script_count=len(item['scripts']))),flush=True)
            out.append(item)
        except Exception as e:out.append(dict(url=url,error=str(e)));print(url,str(e),flush=True)
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),stage=args.stage,sources=out,requests=client.requests)
    (ROOT/'reports'/('eu_soccer_'+args.stage+'_sources.json')).write_text(json.dumps(report,indent=2),encoding='utf-8')

if __name__=='__main__':main()
