import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
for b, in db.execute("SELECT metadata_json FROM _request_audit WHERE json_extract(metadata_json,'$.endpoint')='https://statsapi.mlb.com/api/v1/transactions' ORDER BY request_number DESC LIMIT 35"):
    r=json.loads(b)
    if r['status']!=200:print(r['parameters'],r['status']);continue
    d=json.loads((ROOT/r['raw_file']).read_bytes());xs=d['transactions'];ids=collections.Counter(x['id'] for x in xs)
    print(r['parameters'],len(xs),'dates',collections.Counter(x.get('date') for x in xs),'duplicate_ids',[i for i,n in ids.items() if n>1])
