"""Retain dated official head-coach appointments beyond per-game identities."""
import concurrent.futures,datetime as dt,json,re,sqlite3
from urllib.parse import urljoin,urlsplit
from bs4 import BeautifulSoup
from build_history_catalog import DB
from collect_nba_ranking_pages import metadata
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT

URLS=['https://www.nhl.com/news/topic/offseason/nhl-coaches-2023-24-season-290549742','https://www.nhl.com/news/dan-bylsma-named-seattle-coach','https://www.nhl.com/news/sheldon-keefe-fired-by-toronto','https://www.nhl.com/news/todd-mclellan-fired-by-los-angeles','https://www.nhl.com/goldenknights/news/vegas-golden-knights-announce-changes-to-team-s-coaching-staff']

def main():
    c=HistoryClient();db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _nhl_coach_sources (url TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();queue=list(URLS);seen=set();rows=[]
    while queue:
        url=queue.pop(0)
        if url in seen:continue
        seen.add(url)
        try:
            b,r,redirects=get(c,url);s=BeautifulSoup(b,'html.parser');body=s.find('article') or s
            row=dict(url=url,status='ACQUIRED_NOT_VERIFIED',request_id=r['request_id'],metadata=metadata(s),title=s.title.get_text(' ',strip=True) if s.title else None,paragraphs=[dict(selector='p',index=i,text=p.get_text(' ',strip=True)) for i,p in enumerate(s.select('p'))],redirects=redirects)
            for a in body.find_all('a',href=True):
                link=urljoin(r['endpoint'],a['href']).split('#')[0]
                if urlsplit(link).hostname=='www.nhl.com' and '/news/' in link and ('coach' in link or 'coaching' in link) and any(t in link for t in ['hired','named','fired','announc','contract','retires']):
                    if link not in seen:queue.append(link)
        except Exception as e:row=dict(url=url,status='ERROR',error=str(e))
        db.execute('INSERT OR REPLACE INTO _nhl_coach_sources VALUES (?,?)',(url,json.dumps(row)));db.commit();rows.append(row)
        if len(rows)%10==0:print('NHL COACH SOURCES',len(rows),'saved;',len(queue),'linked pending',flush=True)
        assert len(seen)<150,'Unexpected head-coach link expansion'
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),new_requests=c.requests,acquired=sum(r['status']=='ACQUIRED_NOT_VERIFIED' for r in rows),errors=[r for r in rows if r['status']=='ERROR'],scope='Dated appointment and departure evidence; career totals on current pages never enter historical performance.')
    (ROOT/'reports/nhl_coach_source_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
