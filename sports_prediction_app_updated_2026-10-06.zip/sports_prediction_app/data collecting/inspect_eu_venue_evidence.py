"""Bounded inspection of official match venue fields and unusual host locations."""
import collections,json,sqlite3
from build_history_catalog import DB
from eu_official_games import games,CONFIG

db=sqlite3.connect(DB)
for code in CONFIG:
 gs=games(db,code); wanted={json.loads(b)['official_match_id'] for b, in db.execute('SELECT body FROM _eu_validated_contracts WHERE competition=?',(code,))}; rows=[]
 for mid,g in gs.items():
  if mid not in wanted:continue
  raw=g['raw']; stadium=raw.get('stadium') or raw.get('venue') or raw.get('ground')
  if code=='UCL':
   if not rows:print('UEFA FIELD KEYS',json.dumps(list(raw)))
   round_text=' '.join(str(g.get(k,'')) for k in ['round_type','match_type','round_name'])
   if g.get('round_type')=='FINAL' or stadium.get('countryCode')!=raw['homeTeam'].get('countryCode'):
    rows.append(dict(id=mid,date=g['date'],teams=[g[s]['name'] for s in ['away','home']],round=round_text,location=g.get('location'),stadium_id=stadium['id'],venue_country=stadium.get('countryCode'),home_country=raw['homeTeam'].get('countryCode'),away_country=raw['awayTeam'].get('countryCode')))
  elif len(rows)<2:rows.append(dict(id=mid,date=g['date'],teams=[g[s]['name'] for s in ['away','home']],location=g.get('location'),raw_keys=list(raw),venue=stadium))
 print(code,json.dumps(rows[:30],ensure_ascii=False))
db.close()
