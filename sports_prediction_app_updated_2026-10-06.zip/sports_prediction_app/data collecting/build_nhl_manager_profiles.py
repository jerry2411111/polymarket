"""Date-queryable head-coach profiles and t-1 joins for the collected NHL sample."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from build_nba_dated_profiles import months
from build_nhl_temporal_events import franchise
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone();events=collections.defaultdict(list);performance=collections.defaultdict(list);game_days=collections.defaultdict(list);rosters=collections.defaultdict(list)
    for b, in db.execute('SELECT body FROM _nhl_coach_affiliation_events ORDER BY known_date,event_id'):
        e=json.loads(b);events[e['known_date']].append(e)
    wanted={r[0] for r in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='NHL' UNION SELECT game_id FROM kalshi_pre_match WHERE league='NHL'")};games={g:json.loads(b) for g,b in db.execute('SELECT * FROM _nhl_canonical_games') if g in wanted};assert len(games)>100,'Expanded NHL main/performance tables required'
    for r in db.execute("SELECT * FROM _manager_game_results WHERE league='NHL'"):performance[r['game_date']].append(dict(r))
    for b, in db.execute('SELECT body FROM _nhl_manager_game_facts'):
        f=json.loads(b);rosters[f['game_date']].append(f)
    for g in games.values():game_days[(dt.date.fromisoformat(g['date'])-dt.timedelta(days=1)).isoformat()].append(g)
    state={};current={};temporary={};rows=[];links=[];audit=[];missing=collections.Counter();issues=[]
    def person(mid,name):return state.setdefault(mid,dict(name=name,team=None,fid=None,history=[],history_ids=[],tenure=None,games=0,wins=0))
    def set_team(mid,name,team,day,exact=False):
        fid=franchise(team);p=person(mid,name);old=current.get(fid)
        if old and old!=mid:state[old]['team']=None;state[old]['fid']=None;state[old]['tenure']=None
        if p['fid'] and p['fid']!=fid and current.get(p['fid'])==mid:current.pop(p['fid'])
        if p['fid']!=fid:p.update(team=team,fid=fid,tenure=day if exact else None)
        elif exact and p['tenure'] is None:p['tenure']=day
        p['team']=team
        if not p['history_ids'] or p['history_ids'][-1]!=fid:p['history_ids'].append(fid);p['history'].append(team)
        elif fid=='utah_nhl':p['history'][-1]=team
        current[fid]=mid
    def apply(day):
        priority={'documented_departure':0,'observed_first_game':1,'documented_appointment':2,'dated_roster':3}
        for e in sorted(events[day],key=lambda e:(priority[e['kind']],e['event_id'])):
            if e['kind']=='documented_departure':
                p=person(e['manager_id'],e['manager_name']);fid=franchise(e['team_name'])
                if p['fid']==fid:
                    p.update(team=None,fid=None,tenure=None)
                    if current.get(fid)==e['manager_id']:current.pop(fid)
            else:set_team(e['manager_id'],e['manager_name'],e['team_name'],day,e['exact_appointment'])
        for f in rosters[day]:
            if f['temporary_team']:
                person(f['manager_id'],f['manager_name']);temporary[franchise(f['team_name'])]=dict(manager_id=f['manager_id'],observed_date=day,game_id=f['game_id'])
            else:set_team(f['manager_id'],f['manager_name'],f['team_name'],day)
        if day=='2025-05-07':
            for mid,p in state.items():
                if p['fid']=='utah_nhl':p['team']='Utah Mammoth';p['history'][-1]='Utah Mammoth'
        for f in performance[day]:p=person(f['manager_id'],f['manager_name']);p['games']+=1;p['wins']+=f['win']
    for day in sorted(d for d in events if d<start):apply(day)
    first=dt.date.fromisoformat(start);total=(dt.date.fromisoformat(end)-first).days+1;cols=[r[1] for r in db.execute('PRAGMA table_info(manager_profiles)')]
    for i in range(total):
        day=(first+dt.timedelta(days=i)).isoformat();apply(day)
        for mid,p in state.items():
            if not p['team']:continue
            row=dict(manager_id=mid,manager_name=p['name'],game_type='Hockey',league='NHL',team=p['team'],number_of_teams_served=len(set(p['history_ids'])) if p['history_ids'] else None,served_team_history=','.join(p['history']) or None,months_serving_current_team=months(p['tenure'],day) if p['tenure'] else None,overall_winrate=p['wins']/p['games'] if p['games'] else None,as_of_date=day);rows.append(tuple(row[c] for c in cols));missing.update(k for k,v in row.items() if v is None)
        for g in game_days[day]:
            national=any(k in g['season'] for k in ['All-Star','4 Nations']);n=0
            for team in g['teams']:
                mid=temporary.get(franchise(team),{}).get('manager_id') if national else current.get(franchise(team))
                if mid and state[mid]['team']:links.append((g['game_id'],mid,day));n+=1
            audit.append(dict(game_id=g['game_id'],as_of_date=day,linked_managers=n,meaning='Only observed or documented affiliations through t-1; never tomorrow\'s actual coach'))
    for table,where in [('game_manager_profiles',"game_id LIKE 'NHL_%'"),('manager_profiles',"league='NHL'")]:
        while True:
            cur=db.execute('DELETE FROM '+table+' WHERE rowid IN (SELECT rowid FROM '+table+' WHERE '+where+' LIMIT 5000)');db.commit()
            if not cur.rowcount:break
    for offset in range(0,len(rows),5000):db.executemany('INSERT INTO manager_profiles VALUES ('+','.join('?' for _ in cols)+')',rows[offset:offset+5000]);db.commit()
    with db:
        db.executemany('INSERT INTO game_manager_profiles VALUES (?,?,?)',links);db.execute('CREATE TABLE IF NOT EXISTS _nhl_game_manager_link_audit (game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nhl_game_manager_link_audit');db.executemany('INSERT INTO _nhl_game_manager_link_audit VALUES (?,?)',[(a['game_id'],json.dumps(a)) for a in audit])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',native_coaches=len(state),dated_profiles=len(rows),t_minus_one_links=len(links),games_missing_one_or_both_prior_coaches=sum(a['linked_managers']<2 for a in audit),missing={k:dict(count=v,total=len(rows),percentage=round(v*100/len(rows),4)) for k,v in missing.items()},meaning='Performance includes only collected completed games through date. Team is latest dated official affiliation; complete appointment/departure histories remain partial. First coached dates do not become hire dates. National-team observations remain separate from permanent club history.')
    (ROOT/'reports/nhl_manager_profiles.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='missing'}));db.close()

if __name__=='__main__':main()
