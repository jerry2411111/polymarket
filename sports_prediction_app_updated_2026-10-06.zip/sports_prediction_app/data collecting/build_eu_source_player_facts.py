"""Validate retained reports and prepare date-batched, source-native player facts."""
import argparse,calendar,collections,datetime as dt,hashlib,json,math,re,sqlite3
from zoneinfo import ZoneInfo
from build_history_catalog import DB
from epl_price_points import Sources,pointer
from eu_official_games import CONFIG,games
from eu_verified_details import details
from eu_player_fact_parsers import derive
from core import utc
from probe_history import ROOT

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--through-percent',type=int,default=100);ap.add_argument('--repair-event-errors',action='store_true');a=ap.parse_args();db=sqlite3.connect(DB,timeout=60);src=Sources(db);ds=details(db);hashes=set();by_month=collections.defaultdict(list);issues=[];counts=collections.defaultdict(collections.Counter);missing=collections.defaultdict(collections.Counter);parts=[];milestone=10;repair={gid for gid,b in db.execute('SELECT * FROM _eu_player_event_audit') if any(e['field']=='event_derivation' for e in json.loads(b)['issues'])} if a.repair_event_errors else None
 for code in CONFIG:
  gs=games(db,code);wanted={json.loads(b)['official_match_id'] for b, in db.execute('SELECT body FROM _eu_validated_contracts WHERE competition=?',(code,))};chosen=sorted([gs[mid] for mid in wanted if (code,mid) in ds],key=lambda g:(g['date'],g['game_id']))
  for g in chosen[:3 if a.pilot else None]:
   if repair is None or g['game_id'] in repair:by_month[g['date'][:7]].append((code,g))
 for table,cols in [('_eu_source_player_game_facts','player_id TEXT,game_id TEXT,body TEXT NOT NULL,PRIMARY KEY(player_id,game_id)'),('_eu_source_manager_game_facts','manager_id TEXT,game_id TEXT,body TEXT NOT NULL,PRIMARY KEY(manager_id,game_id)'),('_eu_player_event_audit','game_id TEXT PRIMARY KEY,body TEXT NOT NULL')]:db.execute('CREATE TABLE IF NOT EXISTS '+table+' ('+cols+') STRICT')
 db.commit();day=dt.date(2024,1,1)
 while day<=dt.date(2026,9,14) and (a.pilot or len(parts)<math.ceil(33*a.through_percent/100)):
  month=day.strftime('%Y-%m');n=0
  for code,g in by_month[month]:
   mid=g['official_match_id'];r=json.loads(db.execute('SELECT body FROM _official_'+CONFIG[code][1]+'_game_reports WHERE match_id=?',(mid,)).fetchone()[0]);assert r['status']=='ok';s=r['sources']
   if code=='LAL':
    q=s['match_page'];meta=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(q['request_id'],)).fetchone()[0]);raw=(ROOT/meta['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==meta['sha256'];hit=re.search(rb'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',raw,re.S);assert hit and json.loads(hit[1])['props']['pageProps']==q['data'];hashes.add(q['request_id'])
   elif code=='UCL':
    for kind in ['match','lineups']:
     raw,_=src.get(s[kind]['request_ids'][0]);assert raw==s[kind]['data']
    all_events=[]
    for page in s['events']['page_ranges']:
     raw,meta=src.get(page['request_id']);assert page['start_index']==len(all_events) and meta['parameters']['offset']==len(all_events);all_events+=raw
    assert all_events==s['events']['data']
   else:
    for kind,q in s.items():
     raw,_=src.get(q['request_id']);assert (pointer(raw,q['pointer']) if q.get('pointer') else raw)==q['data']
   hashes.update(src.cache);src.cache.clear();d=ds[code,mid];corrections={eid:json.loads(b) for eid,b in db.execute('SELECT event_id,body FROM _eu_source_event_corrections WHERE game_id=?',(g['game_id'],))} if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_source_event_corrections'").fetchone() else {};rows,coaches,errs,audit=derive(code,g,r,d,corrections);issues.extend(dict(competition=code,game_id=g['game_id'],**e) for e in errs)
   zone=g.get('timezone') or {'LAL':'Europe/Madrid','BUN':'Europe/Berlin','SEA':'Europe/Rome','FL1':'Europe/Paris'}.get(code);finish=utc(d['clock'].get('regulation_end_utc'))
   if finish and zone:available=finish.astimezone(ZoneInfo(zone)).date().isoformat()
   elif finish:available=max(g['date'],finish.date().isoformat())
   else:available=(dt.date.fromisoformat(g['date'])+dt.timedelta(days=1)).isoformat()
   assert available>=g['date'];names=[g[x]['name'] for x in ['away','home']];base=dict(game_id=g['game_id'],official_match_id=mid,game_type='Soccer',league='EU soccer',competition=CONFIG[code][0],competition_code=code,game_date=available,original_game_date=g['date'],temporary_team=False,affiliation_observation_safe=available==g['date']);ha=db.execute('SELECT body FROM _eu_venue_reviews WHERE competition=? AND match_id=?',(code,mid)).fetchone();sides=json.loads(ha[0])['home_away'].split(';') if ha else ['Away','Home']
   for p in rows:
    side=p['side'];p.update(base,team_name=names[side],official_team_id=g[['away','home'][side]]['id'],win=int(g['scores'][side]>g['scores'][1-side]));counts[code]['roster_rows']+=1;counts[code]['played_rows']+=p['did_play'] is True;counts[code]['unknown_appearance_rows']+=p['did_play'] is None;counts[code]['unstable_source_identity']+=not p['source_identity_stable'];counts[code]['injured_departures']+=p['injured_departure']
    if p['did_play'] is True:missing[code].update(k for k in ['score','assists','minutes','starter'] if p[k] is None)
   for p in coaches:
    side=p['side'];p.update(base,team_name=names[side],official_team_id=g[['away','home'][side]]['id'],home_away=sides[side],score_for=g['scores'][side],score_against=g['scores'][1-side],win=int(g['scores'][side]>g['scores'][1-side]))
   audit.update(game_id=g['game_id'],competition=code,issues=errs)
   with db:
    for table in ['_eu_source_player_game_facts','_eu_source_manager_game_facts']:db.execute('DELETE FROM '+table+' WHERE game_id=?',(g['game_id'],))
    db.executemany('INSERT INTO _eu_source_player_game_facts VALUES (?,?,?)',[(p['player_id'],p['game_id'],json.dumps(p)) for p in rows]);db.executemany('INSERT INTO _eu_source_manager_game_facts VALUES (?,?,?)',[(p['manager_id'],p['game_id'],json.dumps(p)) for p in coaches]);db.execute('INSERT OR REPLACE INTO _eu_player_event_audit VALUES (?,?)',(g['game_id'],json.dumps(audit)))
   counts[code]['games']+=1;counts[code]['coach_game_rows']+=len(coaches);n+=1
  parts.append(dict(month=month,games=n));out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING' if issues else 'WORKING',pilot=a.pilot,repair_only=a.repair_event_errors,scope='Source-native facts only. Cross-competition people matching, public odds-game filtering and temporal installation remain separate.',processed_months=len(parts),total_months=33,counts={k:dict(v) for k,v in counts.items()},missing={code:{k:dict(count=v,total=counts[code]['played_rows'],percentage=round(v*100/counts[code]['played_rows'],4)) for k,v in fields.items()} for code,fields in missing.items()},source_hashes=len(hashes),issues=issues,months=parts);(ROOT/'reports'/('eu_source_player_facts_'+('repair' if a.repair_event_errors else 'pilot' if a.pilot else 'months')+'.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
  if n:print('EU PLAYER FACTS MONTH',month,n,'games',flush=True)
  while not a.pilot and not a.repair_event_errors and milestone<=100 and len(parts)>=math.ceil(33*milestone/100):print('EU PLAYER FACTS DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print(json.dumps({k:v for k,v in out.items() if k not in ['issues','months','missing']}));print('ISSUES',len(issues),'EXAMPLES',json.dumps(issues[:15]));db.close()

if __name__=='__main__':main()
