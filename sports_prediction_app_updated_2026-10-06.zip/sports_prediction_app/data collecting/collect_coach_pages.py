"""Collect source-linked NBA coaching contract and appointment history pages."""
import json,concurrent.futures
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT
def main():
 c=HistoryClient();b,r=c.get('https://www.salaryswish.com/coaches/history',document=True);s=BeautifulSoup(b,'html.parser');links=sorted({a['href'] for a in s.select('a[href*="/staff/"]')})
 def task(path):
  try:
   b,r=c.get('https://www.salaryswish.com'+path,document=True);s=BeautifulSoup(b,'html.parser')
   if path.endswith('/mike-brown'):
    print('STAFF TABLES',json.dumps([t.get_text(' ',strip=True)[:3500] for t in s.find_all('table')]),flush=True)
    print('STAFF META',s.get_text(' ',strip=True)[-8500:].encode('ascii','backslashreplace').decode(),flush=True)
   return dict(url='https://www.salaryswish.com'+path,status='ok',request_id=r['request_id'])
  except Exception as e:return dict(url=path,status='error',error=str(e))
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  out=list(pool.map(task,links))
 (ROOT/'reports/coach_page_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('COACH PAGES',len(out),sum(x['status']=='ok' for x in out))
if __name__=='__main__':main()
