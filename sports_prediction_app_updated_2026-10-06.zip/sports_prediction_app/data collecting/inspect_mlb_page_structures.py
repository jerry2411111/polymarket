﻿import json,sqlite3,re
from bs4 import BeautifulSoup
from probe_history import ROOT
from build_history_catalog import DB
db=sqlite3.connect(DB)
for rid in ['f3bfc20f580143ba8f82e4cdff01db26','cd1eeca1735e4687992ee023662a2b58','ad6da835bc514244aaa5f3047da8aa52']:
 r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);print('URL',r['endpoint'],'redirect',r.get('location'));raw=(ROOT/r['raw_file']).read_text(encoding='utf-8',errors='replace');s=BeautifulSoup(raw,'html.parser')
 if len(raw)<2000:print(s.get_text(' ',strip=True),[(x.get('src'),(x.string or '')[:100]) for x in s.find_all('script')]);continue
 for word in ['778297','gameType','gameDate','__data','application/json','__NEXT_DATA__','startTime','gameNumber']:
  i=raw.find(word);print('MATCH',word,i,raw[max(0,i-80):i+160] if i>=0 else '')
 print('SCRIPTS',[(x.get('id'),x.get('type'),len(x.string or x.get_text()),(x.string or x.get_text())[:100]) for x in s.find_all('script') if len(x.string or x.get_text())>100])
