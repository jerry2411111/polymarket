"""Inspect source dates and rank-bearing HTML before implementing extraction."""
import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_nba_ranking_facts import source_dates
from probe_history import ROOT

db=sqlite3.connect(DB)
for b, in db.execute('SELECT body FROM _nhl_ranking_sources'):
    x=json.loads(b)
    if x['status']!='ACQUIRED_NOT_VALIDATED':continue
    r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(x['request_id'],)).fetchone()[0]);s=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
    try:
        published,version,article=source_dates(x);dates=dict(published=published,version=version,free=article.get('isAccessibleForFree'))
    except Exception as e:dates=dict(error=str(e),metadata=x['metadata'])
    entries=[(i,t.name,t.get_text(' ',strip=True)[:250]) for i,t in enumerate(s.select('h2,h3,h4,p')) if re.match(r'^(?:No\.?\s*)?\d+[.\s:—-]+',t.get_text(' ',strip=True))]
    print(json.dumps(dict(publisher=x['publisher'],url=x['url'],dates=dates,entries=entries[:60],links=[(a.get_text(' ',strip=True)[:60],a['href']) for a in s.find_all('a',href=True) if re.search('top.50|top.players|top.100',a.get('href',''))][:12])))
db.close()
