"""Retain three official public match pages for API-to-public-page validation."""
import datetime as dt,json
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def main():
    HOSTS.add('ligue1.com');client=HistoryClient();rows=[]
    for mid in ['l1_championship_match_71794','l1_championship_match_72418','l1_championship_match_73125']:
        url='https://ligue1.com/en/match-sheet/'+mid
        try:
            b,r=client.get(url,document=True);soup=BeautifulSoup(b,'html.parser');text=soup.get_text(' ',strip=True);row=dict(match_id=mid,url=url,request_id=r['request_id'],title=soup.title.get_text() if soup.title else None,public_text_preview=text[:2100],json_ld=[json.loads(s.get_text()) for s in soup.find_all('script',type='application/ld+json')]);print(json.dumps(row),flush=True)
        except Exception as e:row=dict(match_id=mid,url=url,error=str(e));print(json.dumps(row),flush=True)
        rows.append(row)
    (ROOT/'reports/ligue1_public_validation_sources.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=rows,new_requests=client.requests),indent=2),encoding='utf-8')

if __name__=='__main__':main()
