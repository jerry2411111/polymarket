import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB);rows=[json.loads(b) for b, in db.execute("SELECT body FROM _mlb_price_acquisition WHERE json_extract(body,'$.status')='error'")];print('ERRORS',len(rows),collections.Counter((x['mode'],x.get('error')) for x in rows))
for x in rows[:10]:
    print(json.dumps(x))
    for rid in x['request_ids'][-1:]:
        r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);d=json.loads((ROOT/r['raw_file']).read_bytes());print('REQUEST',r['endpoint'],r['parameters'],r['status'])
        if 'candlesticks' in d:
            suff='close' if '/historical/' in r['endpoint'] else 'close_dollars'
            for item in d['candlesticks']:
                bid=item.get('yes_bid',{}).get(suff);ask=item.get('yes_ask',{}).get(suff)
                if bid is not None and ask is not None and float(bid)>float(ask):print('CROSSED',item)
        else:print(str(d)[:700])
