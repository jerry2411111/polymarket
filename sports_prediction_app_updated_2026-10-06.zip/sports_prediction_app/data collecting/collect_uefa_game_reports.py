"""Retain official details, lineups and paginated timelines for matched UEFA games."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from core import utc

def derive(match,events):
 issues=[];clock={};proofs={}
 for name,kind,phase in [('actual_start_utc','START_PHASE','FIRST_HALF'),('halftime_start_utc','END_PHASE','FIRST_HALF'),('second_half_start_utc','START_PHASE','SECOND_HALF'),('regulation_end_utc','END_PHASE','SECOND_HALF')]:
  xs=[(i,e) for i,e in enumerate(events) if e['type']==kind and e.get('phase')==phase];times={e['timestamp'] for _,e in xs if e.get('timestamp')};clock[name]=next(iter(times)) if len(times)==1 and all(e.get('timestamp') for _,e in xs) else None;proofs[name]=[dict(event_id=e['id'],pointer='/'+str(i)+'/timestamp',value=e['timestamp']) for i,e in xs if e.get('timestamp')]
  if clock[name] is None:issues.append(dict(field=name,reason='Missing or ambiguous official phase boundary',values=sorted(times)))
 vals=[clock[k] for k in ['actual_start_utc','halftime_start_utc','second_half_start_utc','regulation_end_utc']]
 if all(vals):
  ts=list(map(utc,vals));first=(ts[1]-ts[0]).total_seconds();pause=(ts[2]-ts[1]).total_seconds();second=(ts[3]-ts[2]).total_seconds()
  if not(40*60<=first<=100*60 and 3*60<=pause<=60*60 and 40*60<=second<=100*60):issues.append(dict(reason='Official phase chronology outside plausible range',durations_seconds=[first,pause,second]));clock={k:None for k in clock}
  elif abs((ts[0]-utc(match['kickOffTime']['dateTime'])).total_seconds())>6*3600:issues.append(dict(reason='Actual kickoff differs from official scheduled start by over six hours'));clock={k:None for k in clock}
 return dict(**clock,clock_proofs=proofs,issues=issues)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--through-percent',type=int,default=10);ap.add_argument('--pilot',action='store_true');a=ap.parse_args();assert 0<a.through_percent<=100;HOSTS.add('match.uefa.com');db=sqlite3.connect(DB,timeout=60);c=HistoryClient()
 db.execute('CREATE TABLE IF NOT EXISTS _official_uefa_game_reports (match_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();done={m:json.loads(b) for m,b in db.execute('SELECT * FROM _official_uefa_game_reports') if json.loads(b).get('status')=='ok'}
 ids={json.loads(b)['official_match_id'] for b, in db.execute("SELECT body FROM _eu_validated_contracts WHERE competition='UCL'")};ids|={'2039914','2039915','2039916'};games={m:json.loads(b) for m,b in db.execute('SELECT * FROM _official_uefa_calendar') if m in ids};months=collections.defaultdict(list)
 for mid,g in games.items():
  if not a.pilot or mid in ['2039914','2039915','2039916']:months[g['date'][:7]].append(mid)
 def fetch(mid):
  if mid in done:return mid,done[mid]
  sources={};row=dict(match_id=mid,date=games[mid]['date'],sources=sources)
  try:
   for kind,suffix in [('match',''),('lineups','/lineups')]:
    d,r=c.get('https://match.uefa.com/v5/matches/'+mid+suffix);assert str(d['id'] if kind=='match' else d['matchId'])==mid;sources[kind]=dict(request_ids=[r['request_id']],data=d)
   m=sources['match']['data'];lineups=sources['lineups']['data'];assert m['status']=='FINISHED';assert m['awayTeam']['id']==games[mid]['raw']['awayTeam']['id'] and m['homeTeam']['id']==games[mid]['raw']['homeTeam']['id']
   for side in ['awayTeam','homeTeam']:assert not lineups.get(side) or lineups[side]['team']['id']==m[side]['id']
   events=[];rids=[];page_ranges=[];seen=set()
   for offset in range(0,10000,500):
    data,r=c.get('https://match.uefa.com/v5/matches/'+mid+'/events',dict(filter='ALL',limit=500,offset=offset,order='ASC'));rids.append(r['request_id']);page_ranges.append(dict(request_id=r['request_id'],start_index=len(events),length=len(data)))
    for e in data:
     assert e['matchId']==mid and e['id'] not in seen;seen.add(e['id'])
     if e.get('timestamp'):utc(e['timestamp'])
    events+=data
    if len(data)<500:break
   else:raise ValueError('Unexhausted official event pagination')
   sources['events']=dict(request_ids=rids,page_ranges=page_ranges,data=events);row.update(status='ok',derived=derive(m,events))
  except Exception as e:row.update(status='error',error=type(e).__name__+': '+str(e))
  return mid,row
 day=dt.date(2024,1,1);parts=[];milestone=10
 while day<=dt.date(2026,9,14) and len(parts)<math.ceil(33*a.through_percent/100):
  month=day.strftime('%Y-%m');counts=collections.Counter();errors=[];issues=[]
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
   for mid,row in pool.map(fetch,months[month]):
    if mid not in done:
     with db:db.execute('INSERT OR REPLACE INTO _official_uefa_game_reports VALUES (?,?)',(mid,json.dumps(row)))
    counts[row['status']]+=1
    if row['status']=='error':errors.append(row)
    else:
     counts['events']+=len(row['sources']['events']['data']);counts['roster_players']+=sum(len(row['sources']['lineups']['data'].get(side,{}).get(kind,[])) for side in ['awayTeam','homeTeam'] for kind in ['field','bench']);issues.extend(dict(match_id=mid,**i) for i in row['derived']['issues'])
  parts.append(dict(month=month,games=len(months[month]),counts=dict(counts),errors=[dict(match_id=e['match_id'],error=e['error']) for e in errors],clock_issues=issues));report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='UEFA official game reports',pilot=a.pilot,total_months=33,processed_months=len(parts),months=parts,new_requests=c.requests)
  (ROOT/'reports/uefa_game_reports_months.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print('UEFA REPORT MONTH',month,dict(counts),'clock issues',len(issues),'months',len(parts),'/33',flush=True)
  while len(parts)>=math.ceil(33*milestone/100) and milestone<=100:print('UEFA REPORT DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  if errors:break
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print('UEFA REPORT NEW REQUESTS',c.requests,flush=True);db.close()

if __name__=='__main__':main()
