import json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB);report=json.loads((ROOT/'reports/eu_source_player_facts_months.json').read_text())
for issue in [i for i in report['issues'] if i['competition']=='UCL' and i['field']=='manager']:
 p=json.loads(db.execute('SELECT body FROM _eu_source_player_game_facts WHERE game_id=? LIMIT 1',(issue['game_id'],)).fetchone()[0]);r=json.loads(db.execute('SELECT body FROM _official_uefa_game_reports WHERE match_id=?',(p['official_match_id'],)).fetchone()[0]);cs=r['sources']['lineups']['data'][['awayTeam','homeTeam'][issue['side']]]['coaches'];print('COACH',issue['game_id'],[{k:c.get(k) for k in ['role']}|dict(name=c['person']['translations']['name'].get('EN'),id=c['person']['id']) for c in cs])
for issue in [i for i in report['issues'] if i['competition']=='SEA' and i['field']=='event_derivation']:
 rows=[json.loads(r[0]) for r in db.execute('SELECT body FROM _eu_source_player_game_facts WHERE game_id=?',(issue['game_id'],))];ids={p['official_player_id']:p['side'] for p in rows};r=json.loads(db.execute('SELECT body FROM _official_seriea_game_reports WHERE match_id=?',(rows[0]['official_match_id'],)).fetchone()[0]);bad=[]
 for e in r['sources']['feed']['data']['events']:
  for side,s in enumerate(['away','home']):
   v=e.get(s)
   if v and e['type'] in ['goal','penalty-goal','own-goal','substitution']:
    p=v.get('player',{});pid=p.get('playerId');related=p.get('relatedPlayerId');expected=side if e['type']!='own-goal' or (r['derived']['goal_reconciliation'] or {}).get('own_goal_side_inverted',False) else 1-side
    if pid in ids and ids[pid]!=expected or related in ids and ids[related]!=ids.get(pid):bad.append(dict(type=e['type'],id=e['eventId'],description=e.get('description'),event_side=side,player_side=ids.get(pid),related_side=ids.get(related),phase=v.get('phase')))
 print('SIDE ISSUE',issue['game_id'],json.dumps(bad))
db.close()
