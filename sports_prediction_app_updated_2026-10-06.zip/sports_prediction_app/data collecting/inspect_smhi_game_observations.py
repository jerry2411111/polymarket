import csv,io,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

db=sqlite3.connect(DB);games=[json.loads(b) for b, in db.execute("SELECT body FROM _nhl_canonical_games WHERE json_extract(body,'$.city')='Stockholm'")];days={g['date'] for g in games}
print('GAMES',json.dumps([{k:g[k] for k in ['game_id','date','start','city']} for g in games]))
for source in json.loads((ROOT/'reports/smhi_stockholm_archives.json').read_text())['sources']:
    r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(source['request_id'],)).fetchone()[0]);lines=(ROOT/r['raw_file']).read_text(encoding='utf-8-sig').splitlines();print('QUALITY',source['parameter'],lines[12:22]);matches=[(i,x) for i,x in enumerate(csv.reader(lines,delimiter=';')) if x and x[0] in days];print('OBS',source['parameter'],json.dumps(matches))
db.close()
