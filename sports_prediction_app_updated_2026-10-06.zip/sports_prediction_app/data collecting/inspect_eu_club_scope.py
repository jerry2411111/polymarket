import sqlite3,json
from build_history_catalog import DB
db=sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True)
for name,sql in db.execute("SELECT name,sql FROM sqlite_master WHERE type IN ('table','view') AND (name LIKE '%eu%game%' OR name LIKE '%eu%club%' OR name LIKE '%eu%team%')"):
 print(name,sql[:200]);print(db.execute('SELECT * FROM "'+name+'" LIMIT 1').fetchone())
print('MAIN COLS',db.execute('PRAGMA table_info(_source_polymarket_soccer_pre_match)').fetchall())
db.close()
