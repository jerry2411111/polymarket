"""Small native-person transaction histories for players in matched game rosters."""
import argparse,collections,concurrent.futures,datetime as dt,json,sqlite3
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--max-new-players',type=int);a=ap.parse_args();db=sqlite3.connect(DB,timeout=60);wanted={json.loads(b)['official_game_id'] for b, in db.execute('SELECT body FROM _mlb_canonical_games')};people={}
    for gid,b in db.execute('SELECT * FROM _official_mlb_feeds'):
        if gid not in wanted:continue
        for p in json.loads(b)['players']:people[p['official_player_id']]=p['player_name']
    db.execute('CREATE TABLE IF NOT EXISTS _mlb_player_transaction_history (player_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();done={pid for pid,b in db.execute('SELECT * FROM _mlb_player_transaction_history') if json.loads(b)['status']=='ok'};jobs=sorted(set(people)-done,key=int)
    if a.max_new_players:jobs=jobs[:a.max_new_players]
    c=HistoryClient();errors=[];total=0;completed=len(done & set(people));milestone=((completed*100//len(people))//10+1)*10
    def fetch(pid):
        ids=[]
        try:
            d,r=c.get('https://statsapi.mlb.com/api/v1/transactions',dict(playerId=int(pid),startDate='1900-01-01',endDate='2026-09-14'));ids.append(r['request_id']);xs=d['transactions']
            assert all(str(x.get('person',{}).get('id'))==pid for x in xs),'Person filter returned a different player'
            assert all('1900-01-01'<=x['date'][:10]<='2026-09-14' for x in xs),'Date filter returned future records'
            assert not d.get('nextPage') and not d.get('next_cursor'),'Unhandled person-history pagination'
            return dict(player_id=pid,player_name=people[pid],status='ok',request_id=r['request_id'],records=xs,earliest=min((x['date'] for x in xs),default=None),latest=max((x['date'] for x in xs),default=None),source_url=r['endpoint'])
        except Exception as e:return dict(player_id=pid,player_name=people[pid],status='error',request_ids=ids,error=type(e).__name__+': '+str(e))
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        for n,row in enumerate(pool.map(fetch,jobs),1):
            db.execute('INSERT OR REPLACE INTO _mlb_player_transaction_history VALUES (?,?)',(row['player_id'],json.dumps(row)));db.commit()
            if row['status']=='ok':completed+=1;total+=len(row['records'])
            else:errors.append(row)
            if completed*100//len(people)>=milestone:
                print('MLB PLAYER HISTORY',milestone,'percent;',completed,'/',len(people),'people; errors',len(errors),flush=True);milestone+=10
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING' if completed==len(people) else 'PARTIALLY WORKING',candidate_roster_players=len(people),completed_players=completed,completion_percentage=100*completed/len(people),new_records_in_run=total,new_requests=c.requests,errors=errors,note='Official returned transaction history, including affiliates and initial signings where available; historical team display names can differ from currently hydrated team objects. Performance still uses only collected game statistics.')
    (ROOT/'reports/mlb_player_history_acquisition.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='errors'}));db.close()

if __name__=='__main__':main()
