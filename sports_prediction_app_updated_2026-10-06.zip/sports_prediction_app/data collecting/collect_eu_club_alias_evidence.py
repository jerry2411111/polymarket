"""Retain official published evidence for translated club labels missing from APIs."""
import datetime as dt,hashlib,html,json,re,sqlite3
from urllib.parse import urlsplit
from history_client import HistoryClient
from official_redirects import get
from build_history_catalog import DB
from probe_history import ROOT,HOSTS
from eu_official_games import games,club_key

ITEMS=[
 ('BUN','1. FC Köln',['1. FC Cologne','Cologne'],'https://www.bundesliga.com/en/bundesliga/clubs/1-fc-koeln/profile',['1. FC Köln','Cologne']),
 ('LAL','Athletic Club',['Bilbao','Athletic Bilbao'],'https://www.laliga.com/noticias/historia-san-mames-estadio-athletic-club-de-bilbao',['Athletic Club','Bilbao']),
 ('LAL','Real Racing Club SAD',['Santander','Racing Santander'],'https://www.laliga.com/en-GB/news/real-racing-club-santander-return-to-laliga-1l2l3',['Real Racing Club','Santander'])]

def main():
 db=sqlite3.connect(DB,timeout=60);c=HistoryClient();rows=[]
 db.execute('CREATE TABLE IF NOT EXISTS _eu_club_alias_evidence (competition TEXT NOT NULL,team_id TEXT NOT NULL,alias TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(competition,team_id,alias)) STRICT');db.commit()
 for code,name,labels,url,terms in ITEMS:
  clubs={g[s]['id']:g[s] for g in games(db,code).values() for s in ['away','home']};found=[t for t in clubs.values() if club_key(t['name'])==club_key(name)];assert len(found)==1,(code,name);team=found[0]
  HOSTS.add(urlsplit(url).hostname);b,r,redirects=get(c,url);text=html.unescape(b.decode('utf-8'));assert all(term.lower() in text.lower() for term in terms),(url,terms)
  evidence=dict(team_id=team['id'],official_name=team['name'],url=url,request_id=r['request_id'],sha256=hashlib.sha256(b).hexdigest(),checked_terms=terms,redirects=redirects,basis='Official league club profile or club-specific article links the translated city/name to this club. Both opponents and official fixture date remain required.')
  with db:db.executemany('INSERT OR REPLACE INTO _eu_club_alias_evidence VALUES (?,?,?,?)',[(code,team['id'],label,json.dumps(evidence)) for label in labels])
  rows.append(dict(competition=code,aliases=labels,**evidence));print(code,name,labels,r['status'],flush=True)
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',evidence=rows,new_requests=c.requests);(ROOT/'reports/eu_club_alias_evidence.json').write_text(json.dumps(report,indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
