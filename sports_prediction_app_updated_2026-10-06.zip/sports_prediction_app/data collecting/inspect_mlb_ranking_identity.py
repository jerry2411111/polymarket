import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB,timeout=60)
for b, in db.execute("SELECT body FROM _mlb_ranking_sources WHERE json_extract(body,'$.publisher')='mlb_network'"):
 x=json.loads(b);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(x['request_id'],)).fetchone()[0]);s=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
 print(x['url'])
 for p in s.select('p'):
  t=p.get_text(' ',strip=True)
  if re.match(r'^(81|91)',t):print(str(p)[:4000])
for pid in ['MLB:622491','MLB:699127','MLB:621242','MLB:641521']:
 row=db.execute('SELECT body FROM _mlb_player_bio_constants WHERE player_id=?',(pid,)).fetchone();print(pid,json.loads(row[0]))
print('Pending', (ROOT/'reports/raw_provenance_audit.json').read_text()[-1300:]);db.close()
