"""Print exact official club-page stadium/location answers for review."""
import json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
db=sqlite3.connect(DB)
for tid,b in db.execute('SELECT * FROM _official_laliga_club_location_sources'):
 r=json.loads(b)
 if r['status']!='ok':continue
 club=r['club'];venue=club.get('venue') or {};answers=[]
 for q in r['faqs']:
  question=q.get('name','');answer=BeautifulSoup(q.get('acceptedAnswer',{}).get('text',''),'html.parser').get_text(' ',strip=True)
  if 'stadium' in question.lower() or 'where' in question.lower() or 'home games' in question.lower():answers.append(dict(question=question,answer=answer))
 print(json.dumps(dict(team_id=tid,name=r['name'],venue=venue.get('name'),address=club.get('address'),answers=answers),ensure_ascii=False))
db.close()
