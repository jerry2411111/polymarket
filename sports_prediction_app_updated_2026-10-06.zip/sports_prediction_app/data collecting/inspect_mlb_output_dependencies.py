import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for name in ['_player_game_results','_team_game_results','_manager_game_results','_game_weather_links']:
 print(name,db.execute('SELECT sql FROM sqlite_master WHERE name=?',(name,)).fetchone()[0][:2500])
