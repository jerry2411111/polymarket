"""Discover the exact public biography request retained by the official page."""
import hashlib,json,sqlite3
from urllib.parse import urlsplit
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def main():
 db=sqlite3.connect(DB);rid='30e7c12fd630486a9d3f0465ab34049b';r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);raw=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];c=HistoryClient();out=[]
 for script in BeautifulSoup(raw,'html.parser').find_all('script',type='application/json'):
  for k,v in json.loads(script.get_text()).items():
   if not isinstance(v,dict) or not isinstance(v.get('b'),dict) or v['b'].get('id')!='DFL-OBJ-00001E':continue
   print('TRANSFER KEY',k,'FIELDS',list(v),'URL',v.get('u'));url=v.get('u');assert url and urlsplit(url).scheme=='https';HOSTS.add(urlsplit(url).hostname)
   try:
    d,sr=c.get(url);assert d==v['b'];print('EXACT PAGE API',sr['request_id'],list(d));out.append(dict(status='WORKING',official_page_request_id=rid,api_request_id=sr['request_id'],endpoint=url,person_id=d['id'],page_pointer='/'+k+'/b'))
   except Exception as e:out.append(dict(status='API_UNAVAILABLE_USE_OFFICIAL_PUBLIC_PAGE',official_page_request_id=rid,endpoint=url,person_id=v['b']['id'],page_pointer='/'+k+'/b',error=str(e)));print('API BLOCK',str(e))
 (ROOT/'reports/bundesliga_person_api_pilot.json').write_text(json.dumps(out,indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
