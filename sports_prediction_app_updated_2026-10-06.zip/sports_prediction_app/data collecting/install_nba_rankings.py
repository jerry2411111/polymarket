"""Validate retained ranking facts and install publisher-separated dated flags.

Publisher editions remain distinct from quarterly research snapshots. Unlisted
players remain unknown because lists can exclude injured/ineligible players.
"""
import collections,datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
from temporal_queries import PUBLISHERS,FLAGS

NAMES=dict(zip(PUBLISHERS,['ESPN','CBS Sports','Sports Illustrated','Bleacher Report','The Sporting News','The Ringer','The Athletic','NBC Sports/Rotoworld','Yahoo Sports','FOX Sports','MLB Network','NHL Network','Sportsnet','TSN','The Hockey News','HoopsHype','Action Network','USA Today','GOAL','France Football / Groupe Amaury']))

def verify_raw(f,soup):
    pointer=f['raw_pointer'];rank=f['rank'];name=f['source_player_name']
    if pointer.startswith('__NEXT_DATA__'):
        value=json.loads(soup.find('script',id='__NEXT_DATA__').string)
        for key in pointer.split('/')[1:-1]:value=value[key]
        assert value['order']==rank==value['weekly_rankings']['weekly_rankings_4']
        assert (value['first_name']+' '+value['last_name']).strip()==name
    elif pointer.startswith('table.ranked-players'):
        i=int(re.search(r'\[(\d+)\]',pointer)[1]);tr=soup.select('table.ranked-players tr')[i]
        assert tr.get_text(' ',strip=True)==f['raw_value']
        assert int(tr.find_all('td',recursive=False)[0].get_text(strip=True))==rank
        assert tr.select_one('.player-name').get_text(' ',strip=True)==name
    elif pointer.startswith('table['):
        ti,ri=map(int,re.findall(r'\[(\d+)\]',pointer));tr=soup.find_all('table')[ti].select('tr')[ri];cs=tr.find_all(['td','th'],recursive=False)
        assert tr.get_text(' ',strip=True)==f['raw_value'] and int(cs[0].get_text(strip=True).strip('.'))==rank and cs[1].get_text(' ',strip=True)==name
    elif pointer.startswith('.content-body heading'):
        hi=int(re.search(r'\[(\d+)\]',pointer)[1]);label=pointer.split('] ',1)[1].removesuffix(' rank');h=soup.select_one('.content-body').select('h2,h3')[hi];parts=[]
        assert re.match(r'^\d+\. (.*?)\s*\([^)]*\)$',h.get_text(' ',strip=True))[1]==name
        for n in h.next_siblings:
            if getattr(n,'name',None) in ['h2','h3']:break
            if getattr(n,'get_text',None):parts.append(n.get_text(' ',strip=True))
        assert int(re.search(re.escape(label)+r' rank:\s*No\.\s*(\d+)',' '.join(parts))[1])==rank
    else:
        hi=int(re.search(r'\[(\d+)\]',pointer)[1]);body=soup.select_one('.content-body') if f['publisher_key']=='usa_today' else soup;text=body.select('h2,h3,h4')[hi].get_text(' ',strip=True)
        assert text==f['raw_value'];m=re.match(r'^(?:Tie-)?(\d+)\.\s*(.+)',text);assert int(m[1])==rank
        assert re.sub(r'\s*\(tie\)\s*','',m[2].split(',')[0].strip(),flags=re.I)==name

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    fs=[json.loads(b) for (b,) in db.execute('SELECT body FROM _nba_ranking_candidate_facts')];es={k:json.loads(b) for k,b in db.execute('SELECT * FROM _nba_ranking_candidate_editions')}
    assert fs and all(f['player_id'] is not None for f in fs),'Resolve or explicitly quarantine unmatched player identities before publishing'
    assert len({(f['list_id'],f['player_id']) for f in fs})==len(fs),'Duplicate person in one edition'
    raw={};now=dt.datetime.now(dt.UTC).isoformat()
    for f in fs:
        rid=f['request_id']
        if rid not in raw:
            a=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/a['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==a['sha256'];raw[rid]=(a,BeautifulSoup(b,'html.parser'))
        verify_raw(f,raw[rid][1]);assert 1<=f['rank']<=100
        assert es[f['list_id']]['version_verified_date']>=f['source_version_date']
    # Later syndication confirms, but does not replace, the fuller same-year
    # original edition. All corroborating observations remain in the fact table.
    suppressed=[]
    for pub in ['espn','cbs_sports','action_network']:
        direct=[e for e in es.values() if e['publisher_key']==pub and e['publication_date'].startswith('2024') and e['acquisition_method']=='PUBLIC_ORIGINAL_PUBLISHER_HTML']
        synd=[e for e in es.values() if e['publisher_key']==pub and e['acquisition_method']=='PUBLIC_AUTHORIZED_SYNDICATION']
        assert len(direct)==len(synd)==1
        ranks={f['player_id']:f['rank'] for f in fs if f['list_id']==direct[0]['list_id']};subset=[f for f in fs if f['list_id']==synd[0]['list_id']]
        assert all(ranks.get(f['player_id'])==f['rank'] for f in subset),'Syndication conflicts with original publisher'
        suppressed.append(synd[0]['list_id'])
    db.execute('CREATE TABLE IF NOT EXISTS _ranking_fact_audit (list_id TEXT NOT NULL,player_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(list_id,player_id)) STRICT')
    db.execute('CREATE TABLE IF NOT EXISTS _ranking_edition_audit (list_id TEXT PRIMARY KEY,body TEXT NOT NULL,use_for_flags INTEGER NOT NULL) STRICT')
    for eid,e in es.items():
        row=(eid,'NBA_'+e['publisher_key'].upper(),NAMES[e['publisher_key']],'NBA','overall',e['publication_date'],e['version_verified_date'],int(e['complete_list']),e['acquisition_method'],e['note'],now)
        old=db.execute('SELECT * FROM ranking_list_versions WHERE list_id=?',(eid,)).fetchone()
        if old:assert tuple(old)[:-1]==row[:-1],('Existing ranking edition changed',eid)
        else:db.execute('INSERT INTO ranking_list_versions VALUES (?,?,?,?,?,?,?,?,?,?,?)',row)
        db.execute('INSERT OR IGNORE INTO _ranking_edition_audit VALUES (?,?,?)',(eid,json.dumps(e),int(eid not in suppressed)))
    for f in fs:
        row=(f['list_id'],f['player_id'],f['player_name'],'NBA',f['rank'],None,f['source_url'],raw[f['request_id']][0]['raw_file'])
        old=db.execute('SELECT * FROM player_media_rankings WHERE list_id=? AND player_id=?',row[:2]).fetchone()
        if old:assert tuple(old)==row,('Existing rank changed',row[:2])
        else:db.execute('INSERT INTO player_media_rankings VALUES (?,?,?,?,?,?,?,?)',row)
        db.execute('INSERT OR IGNORE INTO _ranking_fact_audit VALUES (?,?,?)',(f['list_id'],f['player_id'],json.dumps(f)))
    start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    dates=[d for (d,) in db.execute("SELECT as_of_date FROM _query_dates WHERE substr(as_of_date,6) IN ('01-01','04-01','07-01','10-01')")]
    dates=sorted(set(dates+[end]))
    db.execute('CREATE TABLE IF NOT EXISTS _ranking_snapshot_dates (as_of_date TEXT PRIMARY KEY) STRICT');db.executemany('INSERT OR IGNORE INTO _ranking_snapshot_dates VALUES (?)',[(d,) for d in dates])
    aliases={(r['source_player_id'],r['league']):r['player_id'] for r in db.execute('SELECT * FROM _player_identity_aliases')}
    editions=[dict(r) for r in db.execute('SELECT * FROM ranking_list_versions') if r['list_id'] not in suppressed]
    observations={(r['list_id'],aliases.get((r['player_id'],r['league']),r['player_id'])):dict(r) for r in db.execute('SELECT * FROM player_media_rankings')}
    players=[dict(r) for r in db.execute('SELECT player_id,player_name,league,min(as_of_date) AS first_seen FROM player_profiles GROUP BY player_id,league')]
    groups=collections.defaultdict(list)
    for e in editions:groups[e['league'],e['publisher']].append(e)
    snap=[];flags={}
    for day in dates:
        for (league,publisher),eds in groups.items():
            eligible=[e for e in eds if e['publication_date']<=day and e['version_verified_date']<=day]
            e=max(eligible,key=lambda e:(e['version_verified_date'],e['publication_date'],e['list_id'])) if eligible else None
            for p in players:
                if p['league']!=league or p['first_seen']>day:continue
                pid=aliases.get((p['player_id'],league),p['player_id']);o=observations.get((e['list_id'],pid)) if e else None;rank=o['rank'] if o else None
                age=(dt.date.fromisoformat(day)-dt.date.fromisoformat(e['version_verified_date'])).days if e else None
                snap.append((day,pid,p['player_name'],league,publisher,e['publication_date'] if e else None,rank,o['rating'] if o else None,'overall',age,int(age>=90) if age is not None else None,'OBSERVED' if o else 'NOT_LISTED_ELIGIBILITY_UNKNOWN' if e and e['complete_list'] else 'PARTIAL_LIST_NOT_OBSERVED' if e else 'NO_DATED_LIST_ACQUIRED',o['source_url'] if o else None))
                key=day,pid,league;f=flags.setdefault(key,{c:None for c in FLAGS});pubkey=next(k for k,v in NAMES.items() if v==publisher)
                for n in [5,10,20,50]:f[pubkey+'_top_'+str(n)]=int(rank<=n) if rank is not None else None
    # Snapshot tables are derived results and can be rebuilt; source facts are
    # append-only. These dates are research cutoffs, not fabricated media editions.
    db.execute('DROP VIEW IF EXISTS player_performance');db.execute('DROP VIEW IF EXISTS _player_ranking_flags_canonical');db.execute('DROP VIEW IF EXISTS _player_ranking_flags_quarterly');db.execute('DROP VIEW IF EXISTS player_rankings_quarterly')
    db.execute('DROP TABLE IF EXISTS _ranking_quarterly_results');db.execute('''CREATE TABLE _ranking_quarterly_results (as_of_date TEXT NOT NULL,player_id TEXT NOT NULL,player_name TEXT NOT NULL,league TEXT NOT NULL,publisher TEXT NOT NULL,ranking_date TEXT,rank INTEGER,rating REAL,ranking_type TEXT,age_days INTEGER,is_carried_forward INTEGER,coverage_status TEXT,source_url TEXT,PRIMARY KEY(as_of_date,player_id,league,publisher)) STRICT''')
    db.executemany('INSERT INTO _ranking_quarterly_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',snap)
    db.execute('CREATE VIEW player_rankings_quarterly AS SELECT * FROM _ranking_quarterly_results')
    db.execute('DROP TABLE IF EXISTS _ranking_flag_results');db.execute('CREATE TABLE _ranking_flag_results (as_of_date TEXT NOT NULL,player_id TEXT NOT NULL,league TEXT NOT NULL,'+','.join(c+' INTEGER CHECK ('+c+' IN (0,1) OR '+c+' IS NULL)' for c in FLAGS)+',PRIMARY KEY(as_of_date,player_id,league)) STRICT')
    db.executemany('INSERT INTO _ranking_flag_results VALUES ('+','.join('?' for _ in range(3+len(FLAGS)))+')',[key+tuple(values[c] for c in FLAGS) for key,values in flags.items()])
    db.execute('CREATE VIEW _player_ranking_flags_quarterly AS SELECT * FROM _ranking_flag_results')
    from index_ranking_flags import refresh
    refresh(db)
    db.commit();db.close()
    report=dict(generated_at_utc=now,status='WORKING',coverage_status='PARTIALLY WORKING',raw_rank_checks=len(fs),raw_response_hash_checks=len(raw),native_identity_mapped=len(fs),new_editions=len(es),new_publishers=sorted({f['publisher_key'] for f in fs}),corroborating_editions_not_double_counted=suppressed,quarterly_cutoffs=dates,quarterly_rows=len(snap),flag_rows=len(flags),nba_publisher_series_with_any_facts=9,target_independent_lists=10,target_achieved=False,limitations=['Sports Illustrated has only two previously reviewed NBA facts; its full-list articles identify subscription access.','HoopsHype and older Ringer lists are partial authorized syndicated facts.','Publication/revision dates are retrospective documentary evidence, not independently archived point-in-time captures.','Ringer current list uses capture date as known version; old duplicate weekly fields excluded.','Quarterly cutoffs carry the latest acquired eligible edition, with an additional collection-end snapshot; they do not create fresh quarterly media rankings.','Unlisted players remain null because publisher eligibility and complete league populations are not established.','Action Network is a specialist sports publication; publisher series count is not a certification that every source meets a particular major-media definition.'])
    (ROOT/'reports/nba_rankings_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))

if __name__=='__main__':main()
