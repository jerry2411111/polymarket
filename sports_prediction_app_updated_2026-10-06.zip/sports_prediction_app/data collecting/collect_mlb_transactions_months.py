"""Date-partitioned official transactions, with publication/effective dates intact."""
import argparse,calendar,concurrent.futures,datetime as dt,json,sqlite3
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--max-new-months',type=int);a=ap.parse_args();db=sqlite3.connect(DB,timeout=60)
    assert json.loads((ROOT/'reports/mlb_transactions_api_validation.json').read_text())['status']=='WORKING'
    # A trade shares one transaction ID across several people and directions.
    # Rebuild the initial derived pilot schema; original responses remain intact.
    cols=[r[1] for r in db.execute('PRAGMA table_info(_official_mlb_transactions)')]
    if cols==['transaction_id','body']:db.execute('DROP TABLE _official_mlb_transactions')
    db.execute('CREATE TABLE IF NOT EXISTS _official_mlb_transactions (record_id TEXT PRIMARY KEY,transaction_id TEXT NOT NULL,person_id TEXT,body TEXT NOT NULL) STRICT');db.execute('CREATE TABLE IF NOT EXISTS _mlb_transaction_dates (date TEXT PRIMARY KEY,request_id TEXT NOT NULL,transaction_rows INTEGER NOT NULL) STRICT');db.commit()
    c=HistoryClient();path=ROOT/'reports/mlb_transaction_months.json';old=json.loads(path.read_text()) if path.exists() else {};done={x['month']:x for x in old.get('months',[]) if x['status']=='WORKING'};parts=[];processed=0;day=dt.date(2024,1,1);end=dt.date(2026,9,14)
    def fetch(date):
        try:
            d,r=c.get('https://statsapi.mlb.com/api/v1/transactions',dict(date=date,sportId=1));xs=d['transactions']
            assert all(x['date'][:10]==date for x in xs),'Transaction date filter not respected'
            assert not d.get('nextPage') and not d.get('next_cursor'),'Unprocessed transaction pagination'
            seen={}
            for x in xs:
                key=tuple(x.get(k,{}).get('id') for k in ['person','fromTeam','toTeam'])+(x['id'],)
                assert key not in seen or seen[key]==x,'Conflicting duplicate transaction/person/direction in one response'
                seen[key]=x
            return date,xs,r,None
        except Exception as e:return date,[],None,type(e).__name__+': '+str(e)
    while day<=end:
        month=day.strftime('%Y-%m');last=min(day.replace(day=calendar.monthrange(day.year,day.month)[1]),end)
        if month in done:parts.append(done[month]);day=last+dt.timedelta(days=1);continue
        if a.max_new_months and processed>=a.max_new_months:break
        days=[(day+dt.timedelta(days=n)).isoformat() for n in range((last-day).days+1)];errors=[];rows=0;success=0
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            for date,xs,r,error in pool.map(fetch,days):
                if error:errors.append(dict(date=date,error=error));continue
                with db:
                    for n,x in enumerate(xs):
                        fact=dict(raw=x,request_id=r['request_id'],pointer='/transactions/'+str(n),requested_date=date,publication_date=x['date'][:10],effective_date=x.get('effectiveDate'),source_url=r['endpoint'])
                        pid=x.get('person',{}).get('id');key=':'.join(str(i) if i is not None else '' for i in [x['id'],pid,x.get('fromTeam',{}).get('id'),x.get('toTeam',{}).get('id')])
                        db.execute('INSERT OR REPLACE INTO _official_mlb_transactions VALUES (?,?,?,?)',(key,str(x['id']),str(pid) if pid is not None else None,json.dumps(fact)))
                    db.execute('INSERT OR REPLACE INTO _mlb_transaction_dates VALUES (?,?,?)',(date,r['request_id'],len(xs)))
                rows+=len(xs);success+=1
        parts.append(dict(month=month,status='WORKING' if not errors else 'PARTIALLY WORKING',dates=len(days),successful_dates=success,transaction_rows=rows,errors=errors));processed+=1
        out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Official MLB dated transaction acquisition; includes affiliates before selected-player filtering',total_months=33,completed_months=sum(x['status']=='WORKING' for x in parts),months=parts,new_requests=c.requests)
        path.write_text(json.dumps(out,indent=2),encoding='utf-8');print('MLB TRANSACTIONS',month,'dates',success,'/',len(days),'records',rows,'errors',len(errors),'months',out['completed_months'],'/33',flush=True)
        if errors:break
        day=last+dt.timedelta(days=1)
    db.close()

if __name__=='__main__':main()
