"""Zero denotes no collected performance observations, not a missing source value."""

def include_unobserved_player(base,parameterized=False):
    from temporal_queries import PUBLIC_PLAYER
    values=['p.'+c if c in PUBLIC_PLAYER[:6] else '0 AS '+c for c in PUBLIC_PLAYER]
    cutoff='p.as_of_date=:query_date AND ' if parameterized else ''
    if parameterized:
        absent='NOT EXISTS(SELECT 1 FROM _player_game_results g WHERE g.player_id=p.player_id AND g.league=p.league AND g.game_date BETWEEN :collection_start AND :query_date)'
    else:
        absent='NOT EXISTS(SELECT 1 FROM _player_performance_periods m WHERE m.player_id=p.player_id AND m.league=p.league AND m.effective_from<=p.as_of_date)'
    return 'SELECT * FROM ('+base+') UNION ALL SELECT '+','.join(values)+' FROM player_profiles p WHERE '+cutoff+absent

def install(db):
    from temporal_queries import ranked,FLAGS,PUBLIC_PLAYER
    from ranking_policy import active_flags
    observed=db.execute("SELECT sql FROM sqlite_master WHERE name='player_performance'").fetchone()[0]
    if '_observed_player_performance' in observed or 'UNION ALL SELECT p.player_id' in observed:return
    # The current view already contains publisher joins; keep it as the observed branch.
    db.execute('DROP VIEW IF EXISTS _observed_player_performance')
    db.execute(observed.replace('CREATE VIEW player_performance','CREATE VIEW _observed_player_performance',1))
    base=include_unobserved_player('SELECT '+','.join(PUBLIC_PLAYER)+' FROM _observed_player_performance')
    db.execute('DROP VIEW player_performance')
    db.execute('CREATE VIEW player_performance AS '+ranked(base,flags=active_flags(db,fallback=FLAGS),use_policy=True))
