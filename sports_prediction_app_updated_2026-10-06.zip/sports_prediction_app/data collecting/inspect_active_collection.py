"""Small read-only collector health summary without verbose request records."""
import datetime as dt,json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
print('HOST LIMITS',[dict(host=h,minimum_interval_seconds=w) for h,w in db.execute('SELECT host,min_interval FROM _http_rate_limits') if 'polymarket' in h or 'kalshi' in h])
for minutes in [5,15]:
 cutoff=(dt.datetime.now(dt.UTC)-dt.timedelta(minutes=minutes)).isoformat();rows=db.execute("SELECT json_extract(metadata_json,'$.status'),count(*) FROM _request_audit WHERE json_extract(metadata_json,'$.requested_at_utc')>=? GROUP BY 1",(cutoff,)).fetchall();print('REQUEST STATUS LAST',minutes,'MINUTES',rows)
db.close()
