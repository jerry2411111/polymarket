import collections,json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB);db.row_factory=sqlite3.Row
for t in ['game_player_profiles','player_profiles','player_current_team','_player_performance_periods']:
    print(t,[r[1] for r in db.execute('PRAGMA table_info('+t+')')]);print('Example',dict(db.execute('SELECT * FROM '+t+' LIMIT 1').fetchone()))
comments=collections.Counter();raw={}
for (b,) in db.execute('SELECT body FROM _nba_player_game_facts'):
    p=json.loads(b)
    if p.get('comment'):comments[p['comment']]+=1;raw.setdefault(p['comment'],p)
print('Top comments',comments.most_common(35))
for text,n in comments.most_common(8):print(json.dumps(raw[text]))
print('Seasons',db.execute("SELECT DISTINCT season FROM polymarket_pre_match WHERE league='NBA'").fetchall())
print('Known how-acquired examples')
for (b,) in db.execute("SELECT body FROM _official_player_biographies WHERE json_extract(body,'$.how_acquired') IS NOT NULL LIMIT 5"):print(b)
