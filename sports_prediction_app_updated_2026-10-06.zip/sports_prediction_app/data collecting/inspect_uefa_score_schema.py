"""Inspect real retained goal types and score meanings before normalization."""
import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB);games={}
for rid,body in db.execute("SELECT request_id,metadata_json FROM _request_audit WHERE json_extract(metadata_json,'$.endpoint')='https://match.uefa.com/v5/matches' AND json_extract(metadata_json,'$.status')=200"):
 r=json.loads(body)
 for m in json.loads((ROOT/r['raw_file']).read_bytes()):games[m['id']]=(m,rid)
types=collections.Counter();phases=collections.Counter();special=[]
for mid,(m,rid) in games.items():
 goals=m.get('playerEvents',{}).get('scorers',[])
 for g in goals:
  types[g.get('goalType')]+=1;phases[g.get('phase')]+=1
  if g.get('goalType') not in ['SCORED','PENALTY']:special.append(dict(match_id=mid,away_id=m['awayTeam']['id'],home_id=m['homeTeam']['id'],scores=m['score'],goal=g,request_id=rid))
print(json.dumps(dict(games=len(games),types=dict(types),phases=dict(phases),examples=[dict(match_id=s['match_id'],away_id=s['away_id'],home_id=s['home_id'],score=s['scores'],goal={k:s['goal'].get(k) for k in ['teamId','goalType','time','phase']},player_club=s['goal'].get('player',{}).get('clubId'),request_id=s['request_id']) for s in special[:10]]),ensure_ascii=False));db.close()
