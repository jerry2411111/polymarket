﻿import json,sqlite3,collections
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
for u,b in db.execute('SELECT * FROM _nba_ranking_sources'):
 s=json.loads(b)
 if s['publisher']=='espn' and '46306892' in u:print('ESPN LINKS',s['ranking_links'])
 if s['publisher']!='the_ringer':continue
 r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(s['request_id'],)).fetchone()[0]);soup=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser');p=json.loads(soup.find('script',id='__NEXT_DATA__').string)['props']['pageProps'];x=p['content']['processedPlayers'];ps=[x['playerData'][i] for i in x['rankings'] if (x['playerData'][i].get('weekly_rankings') or {}).get('weekly_rankings_4') is not None]
 print('RINGER CURRENT',len(ps),'orderdup',[(k,v) for k,v in collections.Counter(a['order'] for a in ps).items() if v>1]);print('ORDERMIS',[(a['title'],a['order'],a['weekly_rankings']['weekly_rankings_4']) for a in ps if a['order']!=a['weekly_rankings']['weekly_rankings_4']]);print('UPDATED',min(a['updated'] for a in ps),max(a['updated'] for a in ps));print('INTRO',p['settings']['pages']['rankings'].get('intro'))
 for i in range(5):
  ct=collections.Counter(a['weekly_rankings'].get('weekly_rankings_'+str(i)) for a in ps);print('week',i,'count',sum(ct.values()),'duplicates',[(k,v) for k,v in ct.items() if v>1])
for n in ['ranking_source_audit','ranking_list_versions','player_media_rankings','player_rankings_quarterly','_player_ranking_flags_quarterly']:
 print('SCHEMA',n,db.execute('SELECT sql FROM sqlite_master WHERE name=?',(n,)).fetchone()[0]);print('ROW',db.execute('SELECT * FROM '+n+' LIMIT 1').fetchone())
