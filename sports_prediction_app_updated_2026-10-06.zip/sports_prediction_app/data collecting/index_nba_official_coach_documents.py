"""Index acquired official coach documents internally, preserving raw PDFs."""
import datetime as dt,hashlib,io,json,sqlite3
from bs4 import BeautifulSoup
from pypdf import PdfReader
from build_history_catalog import DB
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _nba_coach_document_pages (request_id TEXT NOT NULL,page_number INTEGER NOT NULL,source_url TEXT NOT NULL,text TEXT NOT NULL,PRIMARY KEY(request_id,page_number)) STRICT')
    for url,body in db.execute('SELECT * FROM _nba_coach_official_sources').fetchall():
        s=json.loads(body)
        if s['status']!='ok':continue
        rid=s['request_id']
        if db.execute('SELECT 1 FROM _nba_coach_document_pages WHERE request_id=?',(rid,)).fetchone():continue
        r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256']
        if b.startswith(b'%PDF'):pages=[p.extract_text() for p in PdfReader(io.BytesIO(b)).pages]
        else:
            soup=BeautifulSoup(b,'html.parser');article=soup.find('article') or soup.find('main') or soup
            for node in article.select('script,style,nav'):node.decompose()
            pages=[article.get_text(' ',strip=True)]
        db.executemany('INSERT INTO _nba_coach_document_pages VALUES (?,?,?,?)',[(rid,i+1,url,text) for i,text in enumerate(pages)]);db.commit();print('INDEXED OFFICIAL COACH DOCUMENT',url,len(pages),flush=True)
    # Bounded human-review excerpts and source inventory; no public extra fields.
    print('OFFICIAL DOCUMENT PAGE COUNT',db.execute('SELECT count(*) FROM _nba_coach_document_pages').fetchone()[0]);db.close();return
    for url,page,text in db.execute("SELECT source_url,page_number,text FROM _nba_coach_document_pages WHERE source_url LIKE '%Pacers-Media-Guide%' AND text LIKE '%HEAD COACH:%' LIMIT 4"):
        at=text.find('HEAD COACH:');print('EXAMPLE',page,text[max(0,at-300):at+800])
    print('DATE-RANGE CANDIDATES')
    for (b,) in db.execute('SELECT body FROM _nba_coach_tenure_sources'):
        s=json.loads(b)
        if not s['effective_to'] or s['effective_to']>='2024-01-01':print(s['coach_id'],s['team_name'],s['effective_from'],s['effective_to'])
    db.close()

if __name__=='__main__':main()
