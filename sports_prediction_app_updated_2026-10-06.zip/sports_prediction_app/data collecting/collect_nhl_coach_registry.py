"""Use endpoints read from the current official NHL Records client."""
import collections,datetime as dt,json,re,sqlite3
from build_history_catalog import DB
from build_nhl_market_candidates import clean
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def main():
    HOSTS.add('records.nhl.com');c=HistoryClient();db=sqlite3.connect(DB,timeout=60)
    documentation=json.loads((ROOT/'reports/nhl_coach_api_documentation.json').read_text());assert any('/site/api/coach?' in t for s in documentation['public_client_scripts'] for t in s['snippets'])
    d,r=c.get('https://records.nhl.com/site/api/coach',dict(cayenneExp='coachCareerRecords.games>0',include=['id','fullName'],sort='fullName'));print('REGISTRY',r['request_id'],'keys',list(d),'rows',len(d.get('data',[])),flush=True)
    assert isinstance(d.get('data'),list) and (d.get('total') is None or d['total']==len(d['data'])),'Coach registry pagination or schema needs review'
    byname=collections.defaultdict(list)
    for x in d['data']:byname[clean(x['fullName'])].append(x)
    names=set()
    for b, in db.execute('SELECT body FROM _official_nhl_game_reports'):names.update(n for n in json.loads(b)['coaches'] if n)
    for b, in db.execute("SELECT body FROM _nhl_coach_sources WHERE url LIKE '%nhl-coaches-2023-24-season%'"):
        source=json.loads(b)
        for article in source['metadata'].get('structured',[]):
            if article.get('@type')!='NewsArticle':continue
            for line in article.get('articleBody','').splitlines():
                plain=re.sub(r'\[([^]]+)\]\([^)]*\)',r'\1',line.replace('**','')).strip();match=re.search(r'([A-Z][^:]+):\s*([^:]+)$',plain)
                if match:names.add(match[2].strip())
    db.execute('CREATE TABLE IF NOT EXISTS _official_nhl_coach_registry (official_coach_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();issues=[]
    for name in sorted(names):
        matches=byname[clean(name)];identity_registry_request=r
        if not matches:
            # The public list filters out coaches with zero NHL games. Query
            # that same documented resource by exact fullName for new hires.
            nd,nr=c.get('https://records.nhl.com/site/api/coach',dict(cayenneExp='fullName="'+name+'"',include=['id','fullName'],sort='fullName'))
            matches=[x for x in nd.get('data',[]) if clean(x['fullName'])==clean(name)];identity_registry_request=nr
        if len(matches)!=1:issues.append(dict(game_report_name=name,reason='No unique full-name match in official coach registry',candidates=matches));continue
        native=matches[0]
        includes=['player.inTop100Alltime','coachCareerRecords','coachFranchiseRecords','coachFranchiseSeasonRecords']
        for field in ['coachFranchiseRecords','coachFranchiseSeasonRecords']:includes.extend(field+'.team.'+k for k in ['id','commonName','placeName','logos'])
        v,vr=c.get('https://records.nhl.com/site/api/coach/'+str(native['id']),dict(include=includes));assert len(v['data'])==1 and v['data'][0]['id']==native['id'];body=dict(official_coach_id=str(native['id']),full_name=native['fullName'],game_report_name=name,registry_request_id=identity_registry_request['request_id'],request_id=vr['request_id'],raw=v['data'][0]);db.execute('INSERT OR REPLACE INTO _official_nhl_coach_registry VALUES (?,?)',(str(native['id']),json.dumps(body)));db.commit()
        print('NHL COACH HISTORY',name,native['id'],flush=True)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),official_registry_count=len(d['data']),game_report_coach_names=len(names),acquired=db.execute('SELECT count(*) FROM _official_nhl_coach_registry').fetchone()[0],registry_request_id=r['request_id'],issues=issues,new_requests=c.requests,meaning='Native identity and career evidence only; cumulative current career totals never enter past collected-game performance')
    (ROOT/'reports/nhl_coach_registry_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
