"""Dated EPL profiles, source-bounded club histories and strictly prior game links."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from build_nba_dated_profiles import months
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone();bios={r[0]:json.loads(r[1]) for r in db.execute('SELECT * FROM _epl_people_biographies')};rosters=collections.defaultdict(list);memberships=collections.defaultdict(list);histories=collections.defaultdict(list);changes=collections.defaultdict(list);coach_games=collections.defaultdict(list);game_days=collections.defaultdict(list);injuries=collections.defaultdict(list);issues=[]
    facts=[json.loads(r[0]) for r in db.execute('SELECT body FROM _epl_player_game_facts')];wanted={p['player_id'] for p in facts};games={r[0]:json.loads(r[1]) for r in db.execute("SELECT * FROM _eu_game_facts WHERE json_extract(body,'$.competition')='Premier League'")}
    assert json.loads((ROOT/'reports/epl_performance_validation.json').read_text())['status']=='WORKING'
    for p in facts:rosters[p['game_date']].append(p)
    for row in db.execute('SELECT body FROM _epl_player_memberships'):
        m=json.loads(row[0])
        if m['player_id'] not in wanted or not m['start_date']:continue
        memberships[m['player_id']].append(m);histories[m['start_date']].append(m)
    for r in db.execute("SELECT * FROM _player_performance_periods WHERE league='EU soccer'"):changes[r['effective_from']].append(dict(r))
    cohorts={r['as_of_date']:dict(r) for r in db.execute("SELECT * FROM _player_score_cohorts WHERE league='EU soccer'")}
    for r in db.execute('SELECT body FROM _epl_manager_game_facts'):
        m=json.loads(r[0]);coach_games[m['game_date']].append(m)
    for gid,g in games.items():
        game_days[(dt.date.fromisoformat(g['date'])-dt.timedelta(days=1)).isoformat()].append(g);report=json.loads(db.execute('SELECT body FROM _official_epl_game_reports WHERE match_id=?',(g['official_match_id'],)).fetchone()[0]);native={p['official_player_id']:p for p in facts if p['game_id']==gid};events=report['sources']['events']['data']
        for c in report['commentary_complete']['rows']:
            v=c['raw'];kind=v.get('type');text=v.get('comment','');pid=v.get('player2') if kind=='substitution' and 'because of an injury' in text else v.get('player1') if kind=='player retired' and 'went off injured' in text else None
            if not pid:continue
            assert pid in native and native[pid]['did_play'];p=native[pid];side=['awayTeam','homeTeam'][p['side']];matching=[s for s in events[side]['subs'] if s['playerOffId']==pid and (kind!='substitution' or s['playerOnId']==v.get('player1'))];assert len(matching)==1,'Reported injured departure does not match official substitution';injuries[p['game_date']].append(dict(player_id=p['player_id'],game_id=gid,source=c,events_request_id=p['events_request_id'],official_substitution=matching[0]))
    states={};perf={};managers={};latest_rosters={};current_coach={};aff=[];links=[];manager_links=[];audits=[];manager_audits=[];rows=[];manager_rows=[];missing=collections.Counter();coach_missing=collections.Counter();count=0
    def person(pid,name=None):
        bio=bios.get('player:'+pid.split(':')[1],{})
        return states.setdefault(pid,dict(name=name or bio.get('person_name'),team=None,observed_date=None,history=[],history_ids=[],n=0,played=0,current_n=0,current_played=0,current_starts=0,injured=False,ever_injured=False,tenure=None))
    def set_team(p,team,day):
        if p['team']!=team:p.update(team=team,current_n=0,current_played=0,current_starts=0,tenure=None)
        if team and (not p['history'] or p['history'][-1]!=team):p['history'].append(team)
    def apply(day,with_roster=True):
        for m in sorted(histories[day],key=lambda m:(m['player_id'],m['native_membership_id'])):
            p=person(m['player_id'])
            if not p['history'] or p['history'][-1]!=m['team_name']:p['history'].append(m['team_name'])
        # Latest dated actual roster takes precedence over an earlier career
        # start. A later documented move can update affiliation between games.
        for pid,p in states.items():
            eligible=[m for m in memberships[pid] if m['start_date']<=day and (m['end_date'] is None or m['end_date']>day)];latest=max((m['start_date'] for m in eligible),default=None);newest=[m for m in eligible if m['start_date']==latest];names={m['team_name'] for m in newest}
            if latest and (p['observed_date'] is None or latest>p['observed_date']):
                if len(names)==1:set_team(p,next(iter(names)),day)
                else:set_team(p,None,day)
            elif not eligible and p['observed_date'] is None:set_team(p,None,day)
            elif p['team'] and p['observed_date']:
                ends=[m['end_date'] for m in memberships[pid] if m['team_name']==p['team'] and m['end_date'] and m['start_date']<=p['observed_date']<m['end_date']<=day]
                if ends and not any(m['team_name']==p['team'] for m in eligible):set_team(p,None,day)
        if with_roster:
            grouped=collections.defaultdict(set)
            for p in sorted(rosters[day],key=lambda p:p['game_id']):
                s=person(p['player_id'],p['player_name']);s['name']=p['player_name'];set_team(s,p['team_name'],day);s['observed_date']=day;s['n']+=1;s['played']+=p['did_play'];s['current_n']+=1;s['current_played']+=p['did_play'];s['current_starts']+=p['did_play'] and p['starter'];s['injured']=False;grouped[p['game_id'],p['team_name']].add(p['player_id'])
            for (gid,team),ids in grouped.items():latest_rosters[team]=dict(game_id=gid,observed_date=day,players=ids)
            for injury in injuries[day]:p=person(injury['player_id']);p['injured']=True;p['ever_injured']=True
        for pid,p in states.items():
            active=[m for m in memberships[pid] if m['team_name']==p['team'] and m['start_date']<=day and (m['end_date'] is None or m['end_date']>day)];tenure=min((m['start_date'] for m in active),default=None)
            if tenure:
                while True:
                    earlier=[m['start_date'] for m in memberships[pid] if m['team_name']==p['team'] and m['start_date']<tenure and m['end_date'] and (dt.date.fromisoformat(m['end_date'])+dt.timedelta(days=1)).isoformat()>=tenure];new=min(earlier,default=tenure)
                    if new==tenure:break
                    tenure=new
            p['tenure']=tenure
        for p in changes[day]:perf[p['player_id']]=p
        for m in coach_games[day]:
            mid=m['manager_id'];p=managers.setdefault(mid,dict(name=m['manager_name'],team=None,history=[],tenure=None,games=0,wins=0,first_current=None));old=current_coach.get(m['team_name'])
            if old and old!=mid:managers[old]['team']=None;managers[old]['tenure']=None
            if p['team']!=m['team_name']:
                if p['team'] and current_coach.get(p['team'])==mid:current_coach.pop(p['team'])
                p.update(team=m['team_name'],tenure=None,first_current=day)
                if not p['history'] or p['history'][-1]!=p['team']:p['history'].append(p['team'])
            p['games']+=1;p['wins']+=m['win'];current_coach[p['team']]=mid
            bio=bios.get('manager:'+mid.split(':')[1],{});appointment=bio.get('raw_joined_club');native_team=bio.get('raw_current_team') or {};g=games[m['game_id']];tid=g['team_ids'][g['teams'].index(p['team'])]
            if appointment and native_team.get('id')==tid and appointment<=p['first_current']:p['tenure']=appointment
    for day in sorted(d for d in histories if d<start):apply(day,False)
    cols=[r[1] for r in db.execute('PRAGMA table_info(player_profiles)')];mcols=[r[1] for r in db.execute('PRAGMA table_info(manager_profiles)')]
    for table,where in [('game_player_profiles',"game_id LIKE 'EPL_%'"),('game_manager_profiles',"game_id LIKE 'EPL_%'"),('player_profiles',"player_id LIKE 'EU_PL:%'"),('manager_profiles',"manager_id LIKE 'EU_PL_COACH:%'")]:
        while True:
            cur=db.execute('DELETE FROM '+table+' WHERE rowid IN (SELECT rowid FROM '+table+' WHERE '+where+' LIMIT 5000)');db.commit()
            if not cur.rowcount:break
    first=dt.date.fromisoformat(start);total=(dt.date.fromisoformat(end)-first).days+1;milestone=10;previous_aff={}
    for i in range(total):
        d=first+dt.timedelta(days=i);day=d.isoformat();apply(day);cohort=cohorts.get(day,{})
        for pid,p in states.items():
            bio=bios.get('player:'+pid.split(':')[1],{});m=perf.get(pid,{});dob=dt.date.fromisoformat(bio['birth_date']) if bio.get('birth_date') else None;avg=m.get('average_score_per_game');mu=cohort.get('mu');sigma=cohort.get('sigma');experience=bio.get('completed_season_evidence');row=dict(player_id=pid,player_name=p['name'],game_type='Soccer',league='EU soccer',team=p['team'],overall_winrate=m.get('overall_winrate'),average_score_per_game=avg,average_assists_per_game=m.get('average_assists_per_game'),std_score_per_game=m.get('std_score_per_game'),std_assists_per_game=m.get('std_assists_per_game'),age=d.year-dob.year-((d.month,d.day)<(dob.month,dob.day)) if dob else None,weight_kg=bio.get('weight_kg'),height_cm=bio.get('height_cm'),years_played=sum(v['available_date']<=day for v in experience.values()) if experience is not None else None,score_z_score=(avg-mu)/sigma if avg is not None and mu is not None and sigma else None,injured_times_till_as_of_date=None if p['ever_injured'] else 0,currently_injured_till_as_of_date=int(p['injured']),number_of_teams_served=None,participation_rate_current_team=p['current_played']/p['current_n'] if p['current_n'] else None,participation_rate_overall=p['played']/p['n'] if p['n'] else None,starter_percentage_current_team=p['current_starts']/p['current_played'] if p['current_played'] else None,starter_percentage_overall=m.get('starter_percentage_overall'),average_minutes_per_game=m.get('average_minutes_per_game'),std_minutes_per_game=m.get('std_minutes_per_game'),served_team_history=','.join(p['history']) or None,months_serving_current_team=months(p['tenure'],day) if p['team'] and p['tenure'] else None,as_of_date=day);assert row['player_name'];rows.append(tuple(row[c] for c in cols));count+=1;missing.update(k for k,v in row.items() if v is None)
            if pid not in previous_aff or previous_aff[pid]!=p['team']:aff.append((pid,day,p['team'],'EPL_DATED:'+day));previous_aff[pid]=p['team']
        for mid,p in managers.items():
            row=dict(manager_id=mid,manager_name=p['name'],game_type='Soccer',league='EU soccer',team=p['team'],number_of_teams_served=None,served_team_history=','.join(p['history']) or None,months_serving_current_team=months(p['tenure'],day) if p['team'] and p['tenure'] else None,overall_winrate=p['wins']/p['games'] if p['games'] else None,as_of_date=day);manager_rows.append(tuple(row[c] for c in mcols));coach_missing.update(k for k,v in row.items() if v is None)
        for g in game_days[day]:
            eligible=set();proof=[];coach_n=0
            for team in g['teams']:
                roster=latest_rosters.get(team)
                if roster:eligible.update(pid for pid in roster['players'] if pid in states and states[pid]['team']==team);proof.append(dict(team=team,game_id=roster['game_id'],observed_date=roster['observed_date']))
                # Only a documented move after a prior roster can supplement it.
                eligible.update(pid for pid,p in states.items() if p['team']==team and p['tenure'] and p['tenure']<=day and (roster is None or p['tenure']>roster['observed_date']))
                if team in current_coach:manager_links.append((g['game_id'],current_coach[team],day));coach_n+=1
            links.extend((g['game_id'],pid,day) for pid in sorted(eligible));audits.append(dict(game_id=g['game_id'],as_of_date=day,players=len(eligible),prior_roster_sources=proof));manager_audits.append(dict(game_id=g['game_id'],as_of_date=day,managers=coach_n))
        if len(rows)>=5000:db.executemany('INSERT INTO player_profiles VALUES ('+','.join('?' for _ in cols)+')',rows);db.commit();rows=[]
        if (i+1)*100//total>=milestone:print('EPL DATED PROFILES',milestone,'percent;',day,'player rows',count,flush=True);milestone+=10
    with db:
        if rows:db.executemany('INSERT INTO player_profiles VALUES ('+','.join('?' for _ in cols)+')',rows)
        db.executemany('INSERT INTO manager_profiles VALUES ('+','.join('?' for _ in mcols)+')',manager_rows);db.executemany('INSERT INTO game_player_profiles VALUES (?,?,?)',links);db.executemany('INSERT INTO game_manager_profiles VALUES (?,?,?)',manager_links);db.execute('CREATE TABLE IF NOT EXISTS _epl_affiliation_daily (player_id TEXT,observed_date TEXT,team_name TEXT,observation_id TEXT,PRIMARY KEY(player_id,observed_date)) STRICT');db.execute('DELETE FROM _epl_affiliation_daily');db.executemany('INSERT INTO _epl_affiliation_daily VALUES (?,?,?,?)',aff)
        for table,data in [('_epl_game_profile_link_audit',audits),('_epl_game_manager_link_audit',manager_audits),('_epl_injury_observations',[x for vs in injuries.values() for x in vs])]:db.execute('CREATE TABLE IF NOT EXISTS '+table+' (body TEXT NOT NULL) STRICT');db.execute('DELETE FROM '+table);db.executemany('INSERT INTO '+table+' VALUES (?)',[(json.dumps(x),) for x in data])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',players=len(states),coaches=len(managers),player_profile_rows=count,manager_profile_rows=len(manager_rows),t_minus_one_player_links=len(links),t_minus_one_coach_links=len(manager_links),reported_injured_departures=sum(map(len,injuries.values())),missing_player={k:dict(count=v,total=count,percentage=round(v*100/count,4)) for k,v in missing.items()},missing_coach={k:dict(count=v,total=len(manager_rows),percentage=round(v*100/len(manager_rows),4)) for k,v in coach_missing.items()},meaning=dict(performance='Only published collected game facts through each query date; sample SD and date-specific cohort',physical='Latest official constants; DOB-derived age',history='Dated club memberships plus collected rosters through date; complete career counts remain unknown',tenure='Completed months in a documented dated club stint; contiguous loan/permanent service to the same club is merged',participation='Collected roster opportunities only, with counters reset on dated club change',injury='Explicit injured substitutions/retirements set true; next roster observation without an injury report resets false by user convention. No report defaults false. Lifetime distinct episode count unknown after any positive report',coaches='Dated actual head-coach game observations; tenure only where official biography appointment matches the observed club and stint',links='Prior observed roster plus documented acquisitions through t-1, never the upcoming actual lineup'));(ROOT/'reports/epl_dated_profiles.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['missing_player','missing_coach','meaning']}));db.close()

if __name__=='__main__':main()
