import collections,json,sqlite3
from history_index import index
from build_history_catalog import DB
d=index();db=sqlite3.connect(DB)
for k,(x,r,p) in d['teams'].items():
 if x.get('details',{}).get('league')=='NHL' and any(s in json.dumps(x) for s in ['Washington','Montreal','Vegas','Utah']):print('TEAM',k,json.dumps(x))
bad={json.loads(b)['market_id'] for b, in db.execute('SELECT body FROM _nhl_market_matching_audit')}
for eid,(e,r,p) in d['polymarket_events'].items():
 for m in e.get('markets',[]):
  if m['id'] in ['502051','502106','517391','605042','1066639']:print('MARKET',json.dumps({k:e.get(k) for k in ['id','title','slug','startTime','startDate','endDate']}),json.dumps({k:m.get(k) for k in ['id','question','description','outcomes','gameStartTime','eventStartTime','endDate','slug','closed','umaResolutionStatus','outcomePrices']}))
for mid,(m,r,p) in d['milestones'].items():
 if any('26JAN26LACBJ' in t for t in m.get('primary_event_tickers',[])):print('MILESTONE',json.dumps(m))
for b, in db.execute('SELECT body FROM _official_nhl_schedule'):
 g=json.loads(b)
 if (g['game_type_code'] not in [1,2,3] and g['game_type_code'] not in [4,12,19,9]) or ('LAK' in g['team_codes'] and 'CBJ' in g['team_codes']) or ('EDM' in g['team_codes'] and 'CGY' in g['team_codes'] and g['local_date']=='2025-09-21'):print('SCHEDULE',json.dumps({k:g[k] for k in ['official_game_id','local_date','scheduled_start_utc','teams','scores','game_type_code','official_team_ids']}),json.dumps({k:g['raw'].get(k) for k in ['specialEvent','rescheduledFrom','rescheduledTo','gameCenterLink']}))
db.close()
