"""Acquire public publisher ranking pages; store originals before parsing facts."""
import concurrent.futures,datetime as dt,json,sqlite3
from urllib.parse import urlsplit,urljoin
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
PAGES=[
('espn','https://www.espn.com/nba/story/_/id/46304114/nba-rank-2025-2026-flagg-beal-reaves-best-players-100-51'),
('tnt_inside_nba','https://bleacherreport.com/articles/10139605-charles-barkleys-top-50-players-heading-into-2024-25-nba-season'),
('action_network','https://www.actionnetwork.com/nba/nba-elite-100-ranking-the-100-best-players-in-the-nba-for-the-2024-25-season'),
('the_ringer','https://nbarankings.theringer.com/'),
('espn','https://www.espn.com/nba/story/_/id/46306892/nba-rank-2025-rankings-top-10-players-jokic-durant-lebron'),
('espn','https://www.espn.com/nba/story/_/id/46306594/nba-rank-2025-2026-williams-harden-morant-best-players-50-11'),
('sporting_news','https://www.sportingnews.com/uk/nba/news/nba-top-30-player-ranking-victor-wembanyama-lebron-james/b242fa702bbcffc602045835'),
('espn','https://www.espn.com/nba/story/_/id/41555759/nba-rank-2024-2025-best-players-100-51'),
('espn','https://www.espn.com/nba/story/_/id/41686157/nba-rank-2024-2025-best-players-50-11'),
('hoopshype_syndicated','https://ca.sports.yahoo.com/news/ranking-consensus-top-100-players-124509204.html'),
('usa_today_syndicated','https://sports.yahoo.com/article/nba-experts-ranked-top-25-100536978.html'),
('usa_today_syndicated','https://sports.yahoo.com/articles/ranking-nbas-best-players-top-120305258.html'),
('espn','https://www.espn.com/nba/story/_/id/41796364/nba-rank-2024-rankings-top-10-players-league'),
('cbs_sports','https://www.cbssports.com/nba/news/nba-top-100-players-ranked-how-lebron-james-jayson-tatum-anthony-edwards-stack-up-ahead-of-2024-25-season/'),
('cbs_sports','https://www.cbssports.com/nba/news/nba-top-100-players-2025-26-season/'),
('sports_illustrated','https://www.si.com/nba/2025-si-nba-100-rankings-nos-10-to-1-digital-cover'),
('sports_illustrated','https://www.si.com/nba/2025-si-nba-100-rankings-nos-50-to-11'),
('sporting_news','https://www.sportingnews.com/ca/nba/news/nba-player-rankings-2024-25-jokic-lebron-james-curry/12382ddabf8a0688c2165e0e'),
('washington_post','https://www.washingtonpost.com/sports/interactive/2024/nba-top-100-players-ranking/'),
('bleacher_report','https://bleacherreport.com/articles/25259327-top-100-players-2025-26-nba-season-ranked'),
]
def metadata(s):
    result=[]
    for tag in s.select('script[type="application/ld+json"]'):
        try:result.append(json.loads(tag.string or tag.get_text()))
        except (ValueError,TypeError):pass
    return dict(structured=result,meta=[dict(t.attrs) for t in s.select('meta[property*=time],meta[name*=date]')],times=[dict(attrs=t.attrs,text=t.get_text(' ',strip=True)) for t in s.select('time')][:3])
def main():
    HOSTS.update(urlsplit(u).hostname for p,u in PAGES);c=HistoryClient();out=[]
    db=sqlite3.connect(DB);prior={u:json.loads(b) for u,b in db.execute('SELECT * FROM _nba_ranking_sources')} if db.execute("SELECT 1 FROM sqlite_master WHERE name='_nba_ranking_sources'").fetchone() else {};db.close()
    def get(item):
        publisher,url=item
        if url in prior:return prior[url]
        try:
            b,r=c.get(url,document=True);s=BeautifulSoup(b,'html.parser')
            return dict(publisher=publisher,url=url,status='ACQUIRED_NOT_VALIDATED',request_id=r['request_id'],retrieved_at_utc=r['retrieved_at_utc'],title=s.title.get_text(' ',strip=True) if s.title else None,metadata=metadata(s),ranking_links=sorted({urljoin(url,a['href']) for a in s.find_all('a',href=True) if any(w in a['href'] for w in ['nba-rank-2024-rankings','2025-si-nba-100-rankings','nba-rank-2025','nba-top-100','top-100-players'])}))
        except Exception as e:return dict(publisher=publisher,url=url,status='UNAVAILABLE',error=str(e))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for x in pool.map(get,PAGES):out.append(x);print('RANKING SOURCE',x['publisher'],x['status'],x['url'],flush=True)
    db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _nba_ranking_sources (url TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _nba_ranking_sources VALUES (?,?)',[(x['url'],json.dumps(x)) for x in out]);db.commit();db.close()
    (ROOT/'reports/nba_ranking_acquisition.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=out),indent=2),encoding='utf-8')

if __name__=='__main__':main()
