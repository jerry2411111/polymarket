"""Inspect bounded real official timeline and lineup examples for schema review."""
import collections,json,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources
db=sqlite3.connect(DB);src=Sources(db)
for rid in ['29a4ac449bf34045a821847e86bcd959','28c7cdb6bdf84eea896f9e4c54331ff4','c7156e2ad06342f6a1d74430e058e665']:
 rows,_=src.get(rid);print('EVENT_TYPES',rid,dict(collections.Counter(r['type'] for r in rows)))
 for i,r in enumerate(rows):
  if r['type'] in ['START_PHASE','END_PHASE','GOAL','SUBSTITUTION']:print('EVENT',i,json.dumps({k:v for k,v in r.items() if k not in ['primaryActor','secondaryActor','fieldPosition','fspFieldPosition']}|{k:dict(person_id=v.get('person',{}).get('id'),name=v.get('person',{}).get('internationalName'),team_id=v.get('team',{}).get('id')) for k,v in r.items() if k in ['primaryActor','secondaryActor']},ensure_ascii=False))
rows,_=src.get('a7453d9dc0d647e2afce3303992a2c7c')
for side in ['awayTeam','homeTeam']:
 for kind in ['field','bench','coaches']:
  v=rows[side][kind][0];p=v.get('player') or v.get('person');print('LINEUP',side,kind,json.dumps({k:x for k,x in v.items() if k not in ['player','person','translations']}|{'person':{k:p.get(k) for k in ['id','internationalName','birthDate','age','height','weight','clubId']}},ensure_ascii=False))
db.close()
