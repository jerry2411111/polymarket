"""Compare explicit official halftime commentary names with structured team aliases."""
import collections,json,re,sqlite3
from build_history_catalog import DB
from eu_official_games import club_key
db=sqlite3.connect(DB);counts=collections.Counter();examples={}
for mid,b in db.execute("SELECT * FROM _official_laliga_game_reports WHERE json_extract(body,'$.status')='ok'"):
 p=json.loads(b)['sources']['match_page']['data'];m=p['match']
 for comment in p['data'].get('comments',[]):
  v=re.fullmatch(r'First Half ends, (.+) (\d+), (.+) (\d+)\.',comment['content'])
  if not v:continue
  for side,label in [('home',v[1]),('away',v[3])]:
   t=m[side+'_team'];names=[t[k] for k in ['nickname','boundname','name']]
   if club_key(label) not in {club_key(n) for n in names}:key=label,tuple(names);counts[key]+=1;examples[key]=mid
for key,n in counts.items():print(n,examples[key],key)
db.close()
