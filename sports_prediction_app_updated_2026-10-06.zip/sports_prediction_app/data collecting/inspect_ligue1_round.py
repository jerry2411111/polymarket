import argparse,json
from history_client import HistoryClient
from probe_history import HOSTS
from probe_ligue1_history import BASE
ap=argparse.ArgumentParser();ap.add_argument('season',type=int);ap.add_argument('week',type=int);a=ap.parse_args();HOSTS.add('ma-api.ligue1.fr');client=HistoryClient();calendar,cr=client.get(BASE+'/championship-calendar/1',dict(season=a.season));data,r=client.get(BASE+f'/championship-matches/championship/1/game-week/{a.week}',dict(season=a.season));print(json.dumps(dict(expected=calendar['gameWeeks'][str(a.week)],request_id=r['request_id'],matches=[{k:m.get(k) for k in ['matchId','championshipId','gameWeekNumber','date','period','unknownMatch','isLive']} for m in data['matches']]),indent=2))
