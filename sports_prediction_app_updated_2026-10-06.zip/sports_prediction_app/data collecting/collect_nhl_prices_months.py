"""Acquire modest pre-game windows and small verified intermission windows."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,hashlib,json,re,sqlite3
from build_history_catalog import DB
from core import utc
from history_client import HistoryClient
from probe_history import ROOT
from schema import HOURS
K='https://external-api.kalshi.com/trade-api/v2'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--max-new-months',type=int);ap.add_argument('--mode',choices=['pre','break'],default='pre');ap.add_argument('--through-month',default='2026-09');a=ap.parse_args();db=sqlite3.connect(DB,timeout=60)
    games={gid:json.loads(b) for gid,b in db.execute('SELECT * FROM _nhl_canonical_games')};contracts=[json.loads(b) for (b,) in db.execute('SELECT body FROM _nhl_market_candidates')];feeds={n:json.loads(b) for n,b in db.execute('SELECT * FROM _official_nhl_game_reports')};by_month=collections.defaultdict(list)
    for m in contracts:
        g=games[m['game_id']]
        if g['official_game_id'] not in feeds:continue
        if a.mode=='break' and m['provider']!='kalshi':continue
        by_month[g['date'][:7]].append(m)
    db.execute('CREATE TABLE IF NOT EXISTS _nhl_price_acquisition (job_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();c=HistoryClient();cutoff,cr=c.get(K+'/historical/cutoff',refresh=True);cut=utc(cutoff['market_settled_ts'])
    path=ROOT/'reports'/('nhl_'+a.mode+'_price_months.json');old=json.loads(path.read_text()) if path.exists() else {};done={x['month']:x for x in old.get('months',[]) if x['status']=='WORKING'};parts=[];processed=0;day=dt.date(2024,1,1);end=dt.date(2026,9,14)
    cached=collections.defaultdict(list)
    if a.mode=='pre':
        for r in c.cache.values():
            u=r['endpoint'];p=r['parameters']
            if u.endswith('/candlesticks') and '/markets/candlesticks' not in u and p.get('period_interval')==60:
                cid=u.split('/markets/')[-1].split('/')[0];cached['kalshi',cid].append(r)
            elif u.endswith('/v2/prices-history') and 'start' in p and 'end' in p and not p.get('cursor'):
                cached['polymarket',p.get('token_id')].append(r)
    def fetch(job):
        m,ordinal,lo,hi=job;requests=[];cid=m['contract_id'];gid=m['game_id'];key=f'{a.mode}:{m["provider"]}:{cid}:{ordinal}:{lo}:{hi}'
        try:
            if a.mode=='pre':
                # The previous 84-hour window usually already encloses all
                # seven new official-start-based targets. Reuse it with its exact
                # native observation times instead of downloading it again.
                anchor=lo+84*3600
                for prior in reversed(cached[m['provider'],cid]):
                    p=prior['parameters'];left=p.get('start_ts',p.get('start'));right=p.get('end_ts',p.get('end'))
                    if left is None or right is None or left>anchor-75*3600 or right<anchor:continue
                    raw=(ROOT/prior['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==prior['sha256'];d=json.loads(raw)
                    items=d.get('candlesticks',d.get('data',[]))
                    if not items or d.get('pagination',{}).get('next_cursor') or d.get('pagination',{}).get('has_more'):continue
                    resolutions=[3600] if m['provider']=='kalshi' else sorted({x['resolution_seconds'] for x in items})
                    # A retained three-hour series suffices for old games; a
                    # recent coarse-only response still gets the finer probe.
                    if m['provider']=='polymarket' and max(resolutions)>3600 and anchor>dt.datetime.now(dt.UTC).timestamp()-90*86400:continue
                    return key,dict(game_id=gid,provider=m['provider'],contract_id=cid,mode=a.mode,checkpoint=ordinal,status='ok',start_ts=lo,end_ts=hi,request_ids=[prior['request_id']],rows=len(items),resolutions=resolutions,reused_covering_raw=True,reused_request_start=left,reused_request_end=right)
            if m['provider']=='kalshi':
                settled=utc(m.get('settled'));archive=bool(settled and settled<cut);route='/historical/markets/'+cid+'/candlesticks' if archive else '/series/'+m['series']+'/markets/'+cid+'/candlesticks'
                d,r=c.get(K+route,dict(start_ts=lo,end_ts=hi,period_interval=60 if a.mode=='pre' else 1));requests.append(r['request_id']);assert d.get('ticker')==cid;suffix='close' if archive else 'close_dollars'
                for x in d['candlesticks']:
                    p=x.get('yes_bid',{}).get(suffix);ask=x.get('yes_ask',{}).get(suffix)
                    assert p is None or 0<=float(p)<=1
                    assert p is None or ask is None or float(p)<=float(ask)
                rows=len(d['candlesticks']);resolutions=[60*60 if a.mode=='pre' else 60]
            else:
                params=dict(token_id=cid,start=lo,end=hi,bucket_seconds=3600,limit=10000);rows=0;seen=set();resolutions=set()
                for page in range(20):
                    d,r=c.get('https://data-api.polymarket.com/v2/prices-history',params);requests.append(r['request_id']);items=d.get('data',[])
                    if page==0 and not items:
                        params.pop('bucket_seconds',None);d,r=c.get('https://data-api.polymarket.com/v2/prices-history',params);requests.append(r['request_id']);items=d.get('data',[])
                    for x in items:assert 0<=x['price']<=1 and isinstance(x['timestamp'],int);resolutions.add(x['resolution_seconds'])
                    rows+=len(items);cursor=d.get('pagination',{}).get('next_cursor')
                    if not cursor:
                        assert not d.get('pagination',{}).get('has_more');break
                    assert cursor not in seen;seen.add(cursor);params['cursor']=cursor
                else:raise ValueError('Historical price pagination bound exceeded')
                resolutions=sorted(resolutions)
            return key,dict(game_id=gid,provider=m['provider'],contract_id=cid,mode=a.mode,checkpoint=ordinal,status='ok',start_ts=lo,end_ts=hi,request_ids=requests,rows=rows,resolutions=resolutions)
        except Exception as e:
            requests.extend(rid for rid in re.findall(r'request ([a-f0-9]{32})',str(e)) if rid not in requests)
            return key,dict(game_id=gid,provider=m['provider'],contract_id=cid,mode=a.mode,checkpoint=ordinal,status='error',request_ids=requests,error=type(e).__name__+': '+str(e))
    while day<=end:
        month=day.strftime('%Y-%m')
        if month>a.through_month:break
        last=min(day.replace(day=calendar.monthrange(day.year,day.month)[1]),end);ms=by_month[month];jobs=[]
        missing_reports=sum(g['official_game_id'] not in feeds for g in games.values() if g['date'].startswith(month))
        for m in ms:
            g=games[m['game_id']];f=feeds[g['official_game_id']];start=int(utc(f['actual_start_utc'] or g['start']).timestamp())
            if a.mode=='pre':jobs.append((m,'pre',start-84*3600,start+6*3600))
            elif f['actual_start_utc']:
                windows=[(0,start+60,start+120)]+[(n,int(utc(b['start_utc']).timestamp()),int(utc(b['end_utc']).timestamp())) for n,b in enumerate(f['breaks'],1) if b['start_utc'] and b['end_utc']]
                for n,lo,hi in windows:
                    # Long suspensions are not a bounded intermission download.
                    # Keep a documented missing interval instead of many days.
                    if hi-lo<=2*3600:jobs.append((m,n,lo-60,hi))
        signature=sorted(f'{m["provider"]}:{m["contract_id"]}:{n}:{lo}:{hi}' for m,n,lo,hi in jobs)
        if month in done and done[month]['job_signature']==signature:parts.append(done[month]);day=last+dt.timedelta(days=1);continue
        if a.max_new_months and processed>=a.max_new_months:break
        counts=collections.Counter();rows=0;errors=[]
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            for num,(key,r) in enumerate(pool.map(fetch,jobs),1):
                db.execute('INSERT OR REPLACE INTO _nhl_price_acquisition VALUES (?,?)',(key,json.dumps(r)));db.commit();counts[r['status']]+=1;rows+=r.get('rows',0)
                if r['status']=='error':errors.append(r)
                elif r['rows']==0:counts['empty']+=1
                if num%200==0:print('NHL PRICE JOBS',a.mode,month,num,'/',len(jobs),'errors',len(errors),flush=True)
        parts.append(dict(month=month,status='WORKING' if not errors and not missing_reports else 'PARTIALLY WORKING',games_still_waiting_for_official_reports=missing_reports,requests_accounted_for=counts['ok'],job_signature=signature,jobs=len(jobs),returned_rows=rows,empty_histories=counts['empty'],errors=errors));processed+=1
        out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='NHL '+a.mode+' price request acquisition; normalized usability checked separately',total_months=33,completed_months=sum(x['status']=='WORKING' for x in parts),months=parts,cutoff=cutoff,cutoff_request_id=cr['request_id'],new_requests_in_this_run=c.requests);path.write_text(json.dumps(out,indent=2),encoding='utf-8');print('NHL PRICE MONTH',a.mode,month,'jobs',len(jobs),'rows',rows,'empty',counts['empty'],'errors',len(errors),'months',out['completed_months'],'/33',flush=True)
        if errors:break
        day=last+dt.timedelta(days=1)
    db.close()

if __name__=='__main__':main()
