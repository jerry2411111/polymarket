"""Official personal profiles linked by complete source names, retaining transient lineup IDs."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,re,sqlite3,unicodedata
from urllib.parse import quote
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS

def namekey(s):return re.sub(r'[^a-z0-9]','',unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower())
def slug(s):return re.sub(r'[^a-z0-9]+','-',unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower()).strip('-')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100;db=sqlite3.connect(DB,timeout=60);c=HistoryClient();HOSTS.add('www.laliga.com');people={}
 for mid,b in db.execute('SELECT * FROM _official_laliga_game_reports ORDER BY json_extract(body,\'$.date\')'):
  row=json.loads(b);source=row['sources']['match_page']
  for side in ['away','home']:
   for kind in ['starts','subs']:
    for p in source['data']['data']['lineups'][side][kind]:
     n=p['person'];key=namekey(n['name']);v=people.setdefault(key,dict(source_name=n['name'],first_date=row['date'],source_names=[],source_lineup_ids=[],official_team_ids=[],profile_slugs=[],first_lineup_request_id=source['request_id']))
     for name in [n['name'],' '.join(filter(None,[n.get('firstname'),n.get('lastname')]))]:
      if name and name not in v['source_names']:v['source_names'].append(name)
      if name and slug(name) not in v['profile_slugs']:v['profile_slugs'].append(slug(name))
     if n.get('nickname') and slug(n['nickname']) not in v['profile_slugs']:v['profile_slugs'].append(slug(n['nickname']))
     v['source_lineup_ids'].append(str(p['id']));v['official_team_ids'].append(str(source['data']['match'][side+'_team']['id']))
 with db:db.execute('CREATE TABLE IF NOT EXISTS _official_laliga_people_sources (source_person_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
 done={k:json.loads(b) for k,b in db.execute('SELECT * FROM _official_laliga_people_sources')};by_month=collections.defaultdict(list)
 for key,p in list(people.items())[:3 if a.pilot else None]:
  p['source_lineup_ids']=sorted(set(p['source_lineup_ids']));p['official_team_ids']=sorted(set(p['official_team_ids']));by_month[p['first_date'][:7]].append((key,p))
 def fetch(job):
  key,p=job
  if key in done:return key,done[key]
  row=dict(**p,attempts=[],api_fallback='Official public API requires unavailable subscription key; official public player page provides personal attributes')
  for candidate in p['profile_slugs'][:3]:
   url='https://www.laliga.com/en-GB/player/'+quote(candidate,safe='-');attempt=dict(url=url);row['attempts'].append(attempt)
   try:
    b,r,redirects=get(c,url);attempt.update(request_id=r['request_id'],status=r['status'],redirects=redirects);m=re.search(rb'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',b,re.S);assert m,'No official structured page payload';props=json.loads(m[1])['props']['pageProps'];d=props.get('player');assert d and d.get('id') and d.get('name'),'No official player profile';aliases={namekey(d['name']),namekey(' '.join(filter(None,[d.get('firstname'),d.get('lastname')])))};assert aliases&{namekey(n) for n in p['source_names']},'Official full profile name does not match the source lineup';row.update(status='ok',person_id=str(d['id']),request_id=r['request_id'],url=url,json_pointer='/props/pageProps/player',data=d);return key,row
   except Exception as e:attempt['error']=type(e).__name__+': '+str(e)
  row['status']='unavailable';return key,row
 day=dt.date(2024,1,1);parts=[];milestone=10
 while day<=dt.date(2026,9,14) and (a.pilot or len(parts)<math.ceil(33*a.through_percent/100)):
  month=day.strftime('%Y-%m');counts=collections.Counter()
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
   for key,row in pool.map(fetch,by_month[month]):
    if key not in done:
     with db:db.execute('INSERT OR REPLACE INTO _official_laliga_people_sources VALUES (?,?)',(key,json.dumps(row)))
    counts[row['status']]+=1
  parts.append(dict(month=month,people=len(by_month[month]),counts=dict(counts)));out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='LaLiga official player biographies by first collected game date',pilot=a.pilot,processed_months=len(parts),total_months=33,total_requested_people=3 if a.pilot else len(people),new_requests=c.requests,months=parts);(ROOT/'reports'/('laliga_people_pilot.json' if a.pilot else 'laliga_people_months.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
  if counts:print('LALIGA PEOPLE',month,dict(counts),'months',len(parts),'/33',flush=True)
  while not a.pilot and milestone<=100 and len(parts)>=math.ceil(33*milestone/100):print('LALIGA PEOPLE DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print('LALIGA BIOGRAPHY NEW REQUESTS',c.requests,flush=True);db.close()

if __name__=='__main__':main()
