"""Helpers retained from verified acquisition; obsolete pilot builders removed."""
import csv,hashlib
import pyarrow as pa
import pyarrow.parquet as pq


def export(root,name,records,columns,types):
    path=root/'data/result'/name
    table=pa.Table.from_pylist(records,schema=pa.schema([pa.field(c,types.get(c,pa.string())) for c in columns]))
    pq.write_table(table,path.with_suffix('.parquet'),compression='zstd')
    with path.with_suffix('.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader();writer.writerows(records)
    return dict(rows=len(records),columns=columns,sha256={suffix:hashlib.sha256(path.with_suffix(suffix).read_bytes()).hexdigest() for suffix in ['.parquet','.csv']})
