import json
from history_client import HistoryClient
c=HistoryClient()
for n in ['2023020573','2024020620','2025030416']:
 for kind in ['boxscore','landing','right-rail']:
  d,r=c.get('https://api-web.nhle.com/v1/gamecenter/'+n+'/'+kind);print(n,kind,{k:v for k,v in d.items() if 'venue' in k.lower() or 'city' in k.lower() or 'location' in k.lower()},'KEYS',list(d))
