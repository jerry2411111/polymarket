"""Publish a field-by-field catalog from current export schemas and retained lineage.

This changes catalog metadata only. It does not collect, rewrite or impute research
observations. Reuses the last independently verified missing-count inventory after
checking file sizes, headers, Parquet row counts and SQL projections.
"""
import collections
import csv
import datetime as dt
import json
import pathlib
import re
import sqlite3

import pyarrow.parquet as pq

from probe_history import ROOT
from build_history_catalog import DB
from report_all_outputs import meaning
from verify_missing_data import public_query
from verify_missing_data import reason_basis

REPORTS = ROOT / 'reports'
LEAGUES = {'nba': 'NBA', 'mlb': 'MLB', 'nhl': 'NHL', 'eu_soccer': 'EU soccer'}
EU_SOURCES = ['pl', 'laliga', 'bundesliga', 'serie_a', 'ligue1', 'uefa']
SOURCES = {}
PUBLISHERS = {
    'espn': 'ESPN', 'cbs_sports': 'CBS Sports', 'sports_illustrated': 'Sports Illustrated',
    'bleacher_report': 'Bleacher Report', 'sporting_news': 'The Sporting News',
    'the_ringer': 'The Ringer', 'the_athletic': 'The Athletic', 'nbc_sports': 'NBC Sports',
    'yahoo_sports': 'Yahoo Sports', 'fox_sports': 'FOX Sports', 'mlb_network': 'MLB Network',
    'nhl_network': 'NHL Network', 'sportsnet': 'Sportsnet', 'tsn': 'TSN',
    'the_hockey_news': 'The Hockey News', 'hoopshype': 'HoopsHype',
    'action_network': 'Action Network', 'usa_today': 'USA Today', 'goal': 'GOAL',
    'france_football': 'France Football / Groupe Amaury',
}
PERFORMANCE = {'games_played', 'performance_status', 'overall_winrate', 'winrate', 'average_score_per_game',
    'std_score_per_game', 'average_assists_per_game', 'std_assists_per_game',
    'average_minutes_per_game', 'std_minutes_per_game', 'score_z_score',
    'starter_percentage_overall', 'home_times', 'away_times', 'average_score_margin'}
AFFILIATION = {'team', 'current_team', 'team_name', 'served_team_history',
    'months_serving_current_team', 'number_of_teams_served',
    'participation_rate_current_team', 'participation_rate_overall',
    'starter_percentage_current_team'}
RANKING = {'publisher', 'ranking_date', 'rank', 'rating', 'ranking_type', 'age_days',
    'is_carried_forward', 'coverage_status', 'source_url'}
RAW_CHAIN = 'request_id -> _request_audit.metadata_json -> endpoint, parameters, retrieval UTC, raw file and hash. Web-only evidence may instead use evidence_file / retained web captures.'
TEMPORAL = 'Daily cumulative history: all collected completed games from the fixed collection start (2024-01-01) through as_of_date, inclusively. No calendar-year or season reset. A 2025-07-01 query includes 2024-01-01 through 2025-07-01. Game features use t-1; future game statistics are excluded.'
PRE_TIME = 'Target = official start minus the named number of hours. Select the latest eligible previous observation, with raw timestamp strictly before game start. A bucket/candle must be fully available by the target. Actual quote time, availability and age are in the selection audit; the column label is not an exact quote timestamp.'
ING_TIME = 'Select the first eligible quote timestamp inside the official opening/break interval. Polymarket aggregate buckets must finish within the interval; Kalshi uses the candle close time. Stored timestamp is the checkpoint reference, not necessarily the quote timestamp. Exact quote time/availability remain in the selection audit. Missing slots are literal null inside semicolon sequences.'


def source(key, name, urls, source_class, note=''):
    if key == 'smhi':
        acquisition = 'OFFICIAL_BACKUP_DIRECT'
    elif key.startswith('rank:') and not urls:
        acquisition = 'NO_ELIGIBLE_LIST_ACQUIRED'
    elif key.startswith('rank:'):
        acquisition = 'DIRECT_OR_REPUBLISHED_MEDIA; inspect each URL and attributed publisher'
    elif key == 'nba_staff_history':
        acquisition = 'CREDITED_SECONDARY_STAFF_HISTORY; official identity/appointment corroboration retained'
    elif source_class.startswith('official'):
        acquisition = 'PREFERRED_OFFICIAL_DIRECT'
    else:
        acquisition = 'LOCAL_RULE_OR_UNAVAILABLE'
    SOURCES[key] = dict(source_id=key, source_name=name, source_class=source_class,
        acquisition_path=acquisition, urls=sorted(set(urls)), note=note)
    return key


def extract_urls(obj):
    if isinstance(obj, dict):
        return set().union(*(extract_urls(v) for v in obj.values())) if obj else set()
    if isinstance(obj, list):
        return set().union(*(extract_urls(v) for v in obj)) if obj else set()
    if isinstance(obj, str) and obj.startswith(('https://', 'http://')) and not any(c.isspace() for c in obj):
        return {obj}
    return set()


def setup_sources(db):
    source('polymarket', 'Polymarket official historical token prices and outcome-token mapping', [
        'https://data-api.polymarket.com/v2/openapi.json',
        'https://docs.polymarket.com/api-reference/markets/get-a-tokens-price-history',
        'https://docs.polymarket.com/api-reference/events/list-events'], 'official API',
        'Data API /v2/prices-history plus retained CLOB /prices-history. Historical token prices are not verified historical bid prices; Gamma maps tokens to outcomes.')
    source('kalshi', 'Kalshi official recent/historical candlesticks and market mapping', [
        'https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps',
        'https://docs.kalshi.com/api-reference/historical/get-historical-market-candlesticks',
        'https://docs.kalshi.com/api-reference/market/get-market-candlesticks'], 'official API',
        'Team YES bid close, normalized to 0-1. Actual acquired cutoff determines recent/historical routing. Market settlement is not the source for published game results.')
    for key, name, urls, note in [
        ('nba', 'NBA official game pages, final scorer reports, biographies and dated club announcements',
         ['https://www.nba.com/games', 'https://www.nba.com/players'], 'Native game/player/team IDs; exact gamebook/page URL and page/JSON field retained per record.'),
        ('mlb', 'MLB official Stats API schedule, game feeds, people, transactions and coaching rosters',
         ['https://statsapi.mlb.com/api/v1/schedule?sportId=1&date=2025-07-04', 'https://docs.statsapi.mlb.com/'],
         'Public routes came from official clients/returned links; restricted partner documentation was not bypassed. Batting runs and fielding assists; individual playing minutes unavailable.'),
        ('nhl', 'NHL official schedule, game-center/scorer reports, player APIs and Records coach registry',
         ['https://api-web.nhle.com/v1/schedule/2025-01-01', 'https://records.nhl.com/'],
         'Scorer/game reports supply results and minutes. Career logs support affiliation/experience, not performance from uncollected games.'),
        ('pl', 'Premier League official calendar, match, lineup, event, commentary and biography APIs',
         ['https://www.premierleague.com/en/matches'], 'Official-client routes retained. Its global Opta biography service also provides native-linked constants for other EU competitions.'),
        ('laliga', 'LaLiga official archived match, lineup and player pages',
         ['https://www.laliga.com/en-GB/laliga-easports/results'], 'Official website fallback: API subscription key unavailable. Insufficient identity links quarantined.'),
        ('bundesliga', 'Bundesliga official public client data and DFB decisions',
         ['https://www.bundesliga.com/en/bundesliga'], 'Native public-client match data checked against official matchday pages. Awarded results respect the dated decision.'),
        ('serie_a', 'Lega Serie A official SDP match/lineup/feed APIs and club reports',
         ['https://www.legaseriea.it/'], 'Official widget routes retained. Conflicting edited feed clocks/scores can be withheld.'),
        ('ligue1', 'Ligue 1 official match APIs, native biographies and club reports',
         ['https://ligue1.com/'], 'Native match/person IDs and independent official club validation retained.'),
        ('uefa', 'UEFA official match/event APIs, profiles and match reports',
         ['https://www.uefa.com/uefachampionsleague/'], 'Regulation-time market results are distinguished from extra time and shootouts.'),
        ('noaa', 'NOAA/NCEI GHCNh quality-screened station observations',
         ['https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/doc/ghcnh_DOCUMENTATION.pdf'],
         'Nearest eligible previous station observation within 90 minutes of the representative game start. One city/date row can serve several games; this is not a daily mean. Retained documentation used; live document access failed during catalog review.'),
        ('smhi', 'SMHI official meteorological station archives',
         ['https://opendata.smhi.se/apidocs/metobs/'],
         'Two Stockholm city/date fallbacks. Bromma temperature/wind/weather and Observatoriekullen humidity use separately audited observations. Retained documentation used; live document access failed during catalog review.'),
    ]:
        source(key, name, urls, 'official league/agency source', note)
    source('rules', 'Project normalization and date/query rules', [], 'local derivation/configuration',
           'No external statistic is claimed for canonical IDs, checkpoint labels, formulae or query dates.')
    source('injury_default', 'User-requested no-report injury convention', [], 'user-specified default',
           'False/zero means no qualifying collected report, not verified absence of injury. NHL injury fields currently use this default throughout.')
    source('unavailable', 'No sufficiently documented value acquired', [], 'unavailable',
           'NULL is retained. No complete career count or missing statistic is fabricated.')
    # Separate the publisher credited with a list from the site where its evidence was acquired.
    reverse = {v: k for k, v in PUBLISHERS.items()}
    rows = db.execute('SELECT DISTINCT v.league,v.publisher,r.source_url FROM ranking_list_versions v '
                      'JOIN player_media_rankings r USING(list_id) WHERE r.source_url IS NOT NULL').fetchall()
    grouped = collections.defaultdict(set)
    for league, publisher, url in rows:
        grouped[league, reverse[publisher]].add(url)
    for scope, league in LEAGUES.items():
        for code, publisher in PUBLISHERS.items():
            urls = grouped[league, code]
            source('rank:' + scope + ':' + code, publisher + ' / ' + league, urls,
                   'acquired ranking evidence' if urls else 'no acquired eligible publisher list',
                   'URLs are actual retained evidence pages, including syndicated copies. Publisher attribution does not establish a direct original-host acquisition. '
                   + ('League-operated network; not an independent external publisher.' if code in ('mlb_network', 'nhl_network') else ''))
    source('nba_staff_history', 'SalarySwish dated NBA staff history, with official appointment/identity corroboration',
           [json.loads(r[0])['source_url'] for r in db.execute('SELECT body FROM _nba_coach_tenure_sources')],
           'credited secondary staff history', 'Used only for documented coach affiliations; coach contract amounts are excluded from public outputs.')


def sport_sources(scope):
    if scope == 'eu_soccer':
        return EU_SOURCES
    if scope == 'us':
        return ['nba', 'mlb', 'nhl']
    if scope == 'all':
        return ['nba', 'mlb', 'nhl'] + EU_SOURCES
    return [scope]


def all_scopes(scope):
    return list(LEAGUES) if scope == 'all' else ['nba', 'mlb', 'nhl'] if scope == 'us' else [scope]


def evidence_tables(scope, purpose):
    mapping = {
        'nba': {'game': ['_nba_canonical_games', '_official_game_facts'],
                'bio': ['_nba_player_bio_constants'],
                'affiliation': ['_nba_roster_game_observations', '_nba_affiliation_events', '_nba_coach_tenure_sources'],
                'injury': ['_nba_injury_observations']},
        'mlb': {'game': ['_mlb_canonical_games', '_official_mlb_schedule', '_official_mlb_feeds'],
                'bio': ['_mlb_player_bio_constants'],
                'affiliation': ['_mlb_affiliation_daily', '_mlb_temporal_events', '_official_mlb_coach_observations'],
                'injury': ['_mlb_temporal_events']},
        'nhl': {'game': ['_nhl_canonical_games', '_official_nhl_schedule', '_official_nhl_game_reports'],
                'bio': ['_official_nhl_player_bios', '_official_nhl_career_sources'],
                'affiliation': ['_nhl_affiliation_daily', '_nhl_temporal_events', '_official_nhl_coach_registry', '_nhl_coach_affiliation_events'],
                'injury': []},
        'eu_soccer': {'game': ['_eu_game_facts'],
                'bio': ['_eu_profile_biographies', '_eu_person_alternative_biographies', '_eu_opta_biographies'],
                'affiliation': ['_eu_affiliation_daily', '_eu_people_registry'],
                'injury': ['_eu_injury_observations']},
    }
    return [t for s in all_scopes(scope) for t in mapping[s][purpose]]


def describe(column, kind, scope, provider=None):
    """Exhaustive semantic mapping; an unknown column fails publication."""
    c = column
    ids = sport_sources(scope)
    is_game = kind in ('pre_match', 'in_game', 'checkpoints')
    text = meaning(c) if c not in {'provider', 'person_id', 'effective_from', 'effective_to', 'checkpoint_index',
        'teamA_odd', 'teamB_odd', 'teamA_p', 'teamB_p'} else ''
    out = dict(meaning=text, value_origin='', source_ids=[], source_fields='', derivation='',
               temporal_rule='', lineage_tables=[], lineage_lookup='', limitations='')

    def put(origin, sources, fields, derivation, tables, time='', note=''):
        out.update(value_origin=origin, source_ids=list(dict.fromkeys(sources)), source_fields=fields,
            derivation=derivation, lineage_tables=list(dict.fromkeys(tables)), temporal_rule=time,
                   lineage_lookup='; '.join(tables) + '. ' + RAW_CHAIN if tables else 'Project rule; no external raw statistic.', limitations=note)

    pre = re.fullmatch(r'(teamA|teamB|draw)_pre_(0|12|24|36|48)_(odd|p)', c)
    ing = re.fullmatch(r'(teamA|teamB|draw)_ingame_(odd|p)', c)
    scalar = re.fullmatch(r'(teamA|teamB)_(odd|p)', c) if kind == 'checkpoints' else None
    rank_flag = re.fullmatch(r'(.+)_top_(5|10|20|50)', c)
    if pre or ing or scalar:
        measure = (pre or ing or scalar).groups()[-1]
        providers = [provider] if provider else ['polymarket', 'kalshi']
        tables = (['_history_selections'] if scope in ('us', 'all') else [])
        if scope in ('eu_soccer', 'all'):
            tables += ['_epl_odds_selections', '_eu_odds_selections', '_eu_validated_contracts']
        fields = []
        if 'polymarket' in providers:
            fields.append('Polymarket /data/{i}/price with timestamp and resolution_seconds; retained CLOB /history/{i}/p with t; Gamma outcome/token IDs establish side.')
        if 'kalshi' in providers:
            fields.append('Kalshi /candlesticks/{i}/yes_bid/close (historical decimal dollars) or close_dollars (recent decimal dollars); end_period_ts. Market ticker maps YES to the relevant team/draw.')
        put('derived' if measure == 'odd' else 'source value normalized', providers + ['rules'], ' '.join(fields),
            'decimal odds = 1 / normalized probability when probability > 0; otherwise NULL.' if measure == 'odd'
            else 'Polymarket p = token price; Kalshi p = decimal dollar value parsed from the retained response. Current acquired historical close and recent close_dollars are already on 0-1 scale; do not divide them by 100. Missing stays NULL; no opposite-side complement.',
            tables, PRE_TIME if pre else ING_TIME,
            'Two provider price definitions must remain distinguishable. Draw columns apply only to EU soccer; combined SQL US draw cells are structurally not applicable.')
        if scalar:
            out['meaning'] = scalar[1] + (' decimal odds' if measure == 'odd' else ' implied probability 0-1') + ' at this checkpoint, split from the US sequence table.'
    elif rank_flag or c in RANKING:
        codes = [rank_flag[1]] if rank_flag else list(PUBLISHERS)
        selected = ['rank:' + s + ':' + code for s in all_scopes(scope) for code in codes]
        # For general ranking metadata list only publishers with actual retained evidence.
        if not rank_flag:
            selected = [key for key in selected if SOURCES[key]['urls']]
        put('derived' if rank_flag or c in {'age_days', 'is_carried_forward', 'coverage_status'} else 'source value normalized',
            selected + ['rules'], 'player_media_rankings.rank/rating/source_url; ranking_list_versions.publisher, publication_date, version_verified_date, ranking_type.',
            'Latest eligible dated edition per publisher and league: recorded rank <= N gives 1; other players give 0 once that dated publisher evidence exists. No eligible dated publisher evidence remains NULL. Entirely unobserved publisher flags are excluded. False is an acquired-list membership convention, not proof of exhaustive publication.' if rank_flag else
            'Quarterly snapshots join canonical player IDs to eligible list versions. age_days = snapshot minus publication date; is_carried_forward = (age_days >= 90).',
            ['player_media_rankings', 'ranking_list_versions', '_ranking_asof_selection', '_ranking_canonical_cache'],
            'Publication AND verified version availability must be on or before the query date. Select the latest eligible publisher edition and carry it forward until a newer eligible edition exists, without waiting for a quarter boundary.',
            'No new ranking publication is invented. The acquired evidence can be a syndication host. Network ownership and missing publishers are recorded in the source registry.')
        if c == 'source_url':
            out['meaning'] = 'Actual public evidence URL retained for this ranking fact; may be a syndicated copy. publisher identifies the attributed list origin.'
    elif c in PERFORMANCE:
        role_table = '_manager_game_results' if kind in ('manager_performance', 'manager_profiles') else '_team_game_results' if kind == 'team_history' else '_player_game_results'
        formulas = {
            'games_played': 'Count completed collected games; player rows count played appearances, not DNP roster entries.',
            'performance_status': 'CASE WHEN games_played=0 THEN insufficient matches ELSE observed matches. Use available statistics immediately from the first played appearance, including the first collection year. The label describes appearance history, not completeness of each statistic.',
            'overall_winrate': 'SUM(win) / COUNT(qualifying appearances or managed games); draws count in the denominator, not as wins.',
            'winrate': 'SUM(win) / COUNT(collected team games).',
            'average_score_per_game': 'Arithmetic mean of available earlier score observations. Zero with no played history; NULL when games exist but no scores are observed.',
            'average_assists_per_game': 'Arithmetic mean of available earlier assist observations. Zero with no played history; NULL when games exist but no assists are observed.',
            'average_minutes_per_game': 'Arithmetic mean of available earlier minutes observations. Zero with no played history; NULL when games exist but no minutes are observed.',
            'std_score_per_game': 'Sample score SD using valid-observation count n, denominator n-1. Zero with no played history; otherwise NULL when fewer than two scores exist.',
            'std_assists_per_game': 'Sample assists SD using valid-observation count n, denominator n-1. Zero with no played history; otherwise NULL when fewer than two assists exist.',
            'std_minutes_per_game': 'Sample minutes SD using valid-observation count n, denominator n-1. Zero with no played history; otherwise NULL when fewer than two minutes values exist.',
            'score_z_score': '(player mean score - same-league cohort mean of observed player means) / population SD at the cutoff. Zero with no played history; otherwise an undefined denominator gives NULL.',
            'starter_percentage_overall': 'Known starts / appearances with known starter status. Zero with no played history; NULL when games exist but all starter indicators are unknown.',
            'home_times': 'Count collected games designated Home for this team/manager.',
            'away_times': 'Count collected games designated Away; verified neutral-site Away;Away follows user convention.',
            'average_score_margin': 'AVG(team score - opponent score), preserving the sign of each margin. Lose 2, win 3, win 5 gives (-2+3+5)/3 = 2. Uses collected completed games through as_of_date.',
        }
        tables = [role_table] + evidence_tables(scope, 'game')
        if c == 'score_z_score':
            tables += ['_player_score_cohorts', '_player_performance_periods']
        put('derived', ids + ['rules'], 'Official collected game facts: win, score, assists, minutes, starter; or score_for/score_against and home_away for teams/managers.',
            formulas[c], tables, TEMPORAL,
            'Player score: NBA points, MLB batting runs, NHL/soccer goals. MLB assists are fielding assists, and individual minutes are unavailable. Not complete league/career performance.')
    elif c in AFFILIATION:
        put('dated source value / derived history', ids + ['rules'],
            'Native rosters, dated acquisition/departure or head-coach appointment, affiliation observations, native career team/season evidence.',
            {'team': 'Latest eligible observed affiliation.', 'current_team': 'Alias of player_profiles.team at the selected date.',
             'team_name': 'Official full team name for the dated team affiliation.',
             'served_team_history': 'Ordered observed club sequence through date; comma separated (CSV escaping for EU names with commas).',
             'months_serving_current_team': 'Completed calendar months since documented start of current continuous stint; first observed appearance alone does not establish start.',
             'number_of_teams_served': 'Distinct career clubs/franchises only if source completeness established; otherwise NULL.',
             'participation_rate_current_team': 'Played appearances / eligible collected roster opportunities in current recorded stint.',
             'participation_rate_overall': 'Played appearances / eligible collected roster opportunities through cutoff.',
             'starter_percentage_current_team': 'Starts / played appearances in current stint; all required starter facts must be known.'}[c],
            evidence_tables(scope, 'affiliation') + ['_player_game_results', '_manager_game_results'],
            'Only observations/announcements available by the date. Current-stint counters reset on verified/observed club change; NHL same-franchise rename is not a transfer.',
            'Observed history can be incomplete or stale. NBA/MLB/EU complete career counts remain NULL; NHL uses validated career/franchise evidence where complete. Rates are fractions 0-1.')
        if scope in ('nba', 'all') and kind == 'manager_profiles':
            out['source_ids'].append('nba_staff_history')
            out['limitations'] += ' NBA coach stint dates also use SalarySwish dated staff history with official identity/appointment corroboration; not every boundary is independently official.'
    elif c in {'age', 'weight_kg', 'height_cm', 'years_played'}:
        put('source constant / date-derived', ids + ['rules'],
            {'age': 'Official biography birth date.', 'weight_kg': 'Official biography weight (kg or pounds).',
             'height_cm': 'Official biography height (cm, metres or feet/inches).',
             'years_played': 'Documented completed regular-season/career season evidence, with availability date.'}[c],
            {'age': 'Completed years between documented DOB and as_of_date.',
             'weight_kg': 'Source kg, or source pounds x 0.45359237.',
             'height_cm': 'Source cm, metres x 100, or total inches x 2.54.',
             'years_played': 'Count documented completed seasons by cutoff; NBA/NHL July 1 ending-season boundary; EU explicit season availability; MLB unavailable.'}[c],
            evidence_tables(scope, 'bio'),
            'Age and experience depend on selected date. Height and weight are permitted sourced constants, not a dated measurement series.',
            'EU constants may use Premier League-hosted global Opta biography evidence; actual native source/field IDs remain in biography audit.')
    elif c in {'injured_times_till_as_of_date', 'currently_injured_till_as_of_date'}:
        put('dated evidence plus requested default', (ids if scope != 'nhl' else []) + ['injury_default'],
            'NBA dated injury/illness/concussion roster notes; MLB injured-list/activation transactions; EU explicit official injury-linked observations; no collected NHL injury history.',
            'Current flag follows dated collected evidence, default 0 without a report. Distinct lifetime episode count is NULL after a positive report, otherwise 0. NHL currently stores 0 for both fields.',
            evidence_tables(scope, 'injury'), 'No future injury report is used. NBA/EU later eligible roster observation can clear the flag; MLB activation/appearance ends listed absence.',
            'These defaults must not be treated as verified medical negatives or a complete injury archive.')
    elif kind == 'weather':
        if c in {'city', 'date'}:
            put('official location/date normalized', ids, 'Official game city and local game calendar date.',
                'Deduplicate city/date; league weather files are filtered copies of global weather.',
                ['_game_weather_links'] + evidence_tables(scope, 'game'), 'Local game day, not UTC date and not retrieval date.')
        elif c in {'humidity_pct', 'temperature_c', 'wind_direction', 'weather_type'}:
            put('official observation normalized', ['noaa', 'smhi'],
                'NOAA raw station field: ' + {'humidity_pct': 'relative humidity', 'temperature_c': 'air temperature',
                'wind_direction': 'wind direction', 'weather_type': 'present-weather/sky-cover codes'}[c] + '; SMHI parameter CSV value/quality where fallback applies.',
                'Select quality-approved previous observation and normalize documented units/codes; preserve other observed weather categories.',
                ['_weather_observation_audit', '_weather_field_provenance', '_game_weather_links'],
                'One representative observation per city/date; normally <=90 minutes before game start. SMHI per-variable station/time is separately audited.',
                'Not a daily average, forecast, exact stadium measurement or indoor playing condition. NOAA humidity measurement code D means agency-derived, not a direct humidity sensor reading. Missing station/observation/variable remains NULL. _weather_field_provenance explicitly distinguishes primary NOAA and official-backup SMHI with the actual URL for each field.')
        else:
            raise ValueError(('Unmapped weather field', c))
    elif c in {'player_id', 'manager_id', 'person_id', 'player_name', 'manager_name', 'coach_or_manager_name'}:
        if c == 'person_id':
            out['meaning'] = 'Internal canonical person key for native player/coach identity.'
        put('canonical identifier' if c.endswith('_id') else 'official name normalized', ids + ['rules'],
            'Official native player/coach ID, roster/biography full name, canonical identity registry.',
            'Preserve native ID mapping and full documented name; names alone are not join keys.',
            evidence_tables(scope, 'bio') + evidence_tables(scope, 'affiliation'),
            'Stable identity; membership is independently date-qualified.',
            'Some coach canonical IDs encode an officially verified name rather than an available native numeric ID.')
    elif c == 'as_of_date':
        put('query/snapshot configuration', ['rules'], '_query_dates / _ranking_snapshot_dates or supplied :query_date.',
            'ISO local calendar cutoff; profiles use daily dates and rankings change when a newly eligible publisher edition becomes available.',
            ['_query_dates', '_ranking_snapshot_dates'], 'Inclusive date; game_player_profiles/game_manager_profiles link to the prior date.')
    elif c == 'provider':
        out['meaning'] = 'Odds provider discriminator: polymarket or kalshi; added by UNION ALL SQL views.'
        put('table discriminator', ['rules'], 'Name of underlying provider-specific table.',
            'Literal provider assigned to each union branch; prevents treating two provider rows as one observation.', [])
    elif c == 'checkpoint_index':
        out['meaning'] = 'Zero-based position of the checkpoint in the ordered US in-game sequence.'
        put('derived', ['rules'], 'Underlying semicolon sequence position.', 'Split sequences at identical 0-based index.', [], ING_TIME)
    elif c in {'game_type', 'league', 'competition'}:
        put('source classification / configured group', ids + ['rules'], 'Official competition identity mapped to canonical sport/league labels.',
            'Game tables: Basketball/NBA, Baseball/MLB, Hockey/NHL; Soccer with Premier League, La Liga, Bundesliga, Serie A, Ligue 1 or UEFA Champions League in league. Dated soccer performance/profile tables retain the combined EU soccer scope.',
            evidence_tables(scope, 'game'), 'Classification of the collected game/person, not a prediction.',
            'Soccer performance remains combined across all six competitions, as requested; game rows identify the individual competition.')
    elif is_game and c in {'match', 'date', 'timestamp', 'season', 'location', 'home_away', 'final',
                           'teamA_final_score', 'teamB_final_score', 'game_id', 'checkpoint', 'teamA_score', 'teamB_score'}:
        fields = {'match': 'Canonical official teams[0] and teams[1].', 'date': 'Official local game calendar date.',
            'timestamp': 'Official actual start/first pitch/scorer clock, or documented scheduled fallback; for in-game, official break/opening reference times.',
            'season': 'Official season year and competition/game phase where provided.', 'location': 'Official venue and location fields.',
            'home_away': 'Official away/home designation plus verified neutral venue evidence.',
            'final': 'Official scores/result, not Polymarket/Kalshi settlement.',
            'teamA_final_score': 'Official scores[0], regulation basis for soccer.',
            'teamB_final_score': 'Official scores[1], regulation basis for soccer.',
            'game_id': 'Native game ID, local date, canonical team IDs/codes and doubleheader game number.',
            'checkpoint': 'Requested checkpoint definitions and official period/inning boundaries.',
            'teamA_score': 'Official break_scores[j][0] or regulation halftime score.',
            'teamB_score': 'Official break_scores[j][1] or regulation halftime score.'}
        put('derived' if c in {'match', 'game_id', 'checkpoint', 'final', 'home_away'} else 'official source value normalized',
            ids + (['rules'] if c in {'match', 'game_id', 'checkpoint', 'home_away'} else []), fields[c],
            'Full Team A/Team B order is consistent across names, probabilities and scores. Verified neutral-site designation is Away;Away. Canonical IDs preserve separate doubleheader games.',
            evidence_tables(scope, 'game'), ING_TIME if kind in ('in_game', 'checkpoints') else
            'Event date is local; start is UTC. Use official actual timing when established, otherwise the documented scheduled fallback. NHL start can have minute precision.',
            'Soccer final = regulation result (Draw possible), excluding extra-time/shootout. Start/break timestamp precision and source basis are per-game audit facts.')
        if c == 'checkpoint':
            out['derivation'] = 'NBA Start;Q1;Halftime;Q4 (entry into Q4). MLB Start;Inning3;Inning5;Inning7. NHL Start;P1;P2. Soccer START;HALFTIME;SECOND_HALF_START.'
        if kind == 'checkpoints' and c in {'timestamp', 'checkpoint', 'teamA_score', 'teamB_score'}:
            out['meaning'] = {'timestamp': 'Single UTC checkpoint reference timestamp, not necessarily selected quote time.',
                'checkpoint': 'One checkpoint label after splitting the US in-game sequence.',
                'teamA_score': 'Single official cumulative Team A score at this checkpoint.',
                'teamB_score': 'Single official cumulative Team B score at this checkpoint.'}[c]
    else:
        raise ValueError(('Unmapped column', c, kind, scope, provider))
    assert out['meaning'] and out['source_ids'] and out['value_origin'], (c, kind)
    return out


def context(dataset):
    parts = pathlib.PurePosixPath(dataset).parts[2:]
    if parts[0] in ('polymarket', 'kalshi'):
        return parts[-1], 'all', parts[0]
    if parts[0] == 'eu_soccer' and parts[1] in ('polymarket', 'kalshi'):
        return parts[-1], 'eu_soccer', parts[1]
    if parts == ('weather',):
        return 'weather', 'all', None
    return parts[-1], parts[0], None


def grain(kind):
    return {'pre_match': 'One provider/game, one winner-of-game market family; many lookback columns.',
        'in_game': 'One provider/game with at least one qualifying quote; aligned checkpoint sequences.',
        'checkpoints': 'One provider/game/checkpoint, US leagues only; scalar expansion of in-game sequences.',
        'weather': 'One city/local date; per-league files overlap the global weather table.',
        'player_profiles': 'One canonical player/as_of_date; not one distinct player per row.',
        'player_current_team': 'One canonical player/as_of_date recorded affiliation.',
        'player_performance': 'One player/as_of_date with collected played history; publisher-specific flags.',
        'manager_profiles': 'One canonical head coach/manager/as_of_date.',
        'manager_performance': 'One manager/as_of_date with attributed collected game history.',
        'team_history': 'Dated cumulative collected-game team win rate, game counts and average signed scoring margin.',
        'player_rankings_quarterly': 'One canonical player/publisher/quarterly snapshot, including explicit coverage states.',
        'game_player_profiles': 'One game/player link to the prior-date profile; eligibility from then-known rosters.',
        'game_manager_profiles': 'One game/manager link to the prior-date profile.',
        'game_weather_links': 'One canonical game linked to its official city/local-date weather key.'}[kind]


def enrich(row):
    row['unit'] = unit(row['column_name'], row['scope'], row['row_grain'])
    row['source_names'] = '; '.join(SOURCES[k]['source_name'] for k in row['source_ids'])
    row['source_urls'] = sorted({u for k in row['source_ids'] for u in SOURCES[k]['urls']})
    row['source_status'] = 'NO_ACQUIRED_EXTERNAL_VALUE' if all(not SOURCES[k]['urls'] for k in row['source_ids']) else 'SEE_FIELD_AND_SOURCE_LIMITATIONS'
    if row.get('missing_pct') == 100:
        row['source_status'] = 'ALL_VALUES_MISSING_IN_THIS_EXPORT; ' + row['source_status']
    return row


def unit(c, scope, row_grain):
    sequence = 'semicolon-separated values, one per checkpoint; ' if 'aligned checkpoint sequences' in row_grain and c in {'timestamp', 'teamA_score', 'teamB_score', 'checkpoint'} or '_ingame_' in c else ''
    score = {'nba': 'points', 'mlb': 'runs', 'nhl': 'goals', 'eu_soccer': 'goals'}.get(scope, 'NBA points / MLB runs / NHL or soccer goals')
    if re.search(r'_(pre_\d+|ingame)_(odd|p)$', c) or c in {'teamA_odd','teamB_odd','teamA_p','teamB_p'}:
        return sequence + ('decimal payout multiple (1/p)' if c.endswith('odd') else 'probability fraction, 0-1')
    if re.fullmatch(r'.+_top_(5|10|20|50)', c) or c in {'currently_injured_till_as_of_date', 'is_carried_forward'}:
        return 'Boolean: 1=true, 0=false; NULL=unknown (injury default is separately documented)'
    if c in {'overall_winrate','winrate'} or c.startswith(('participation_rate_', 'starter_percentage_')):
        return 'fraction, 0-1; not percentage points'
    if c in {'teamA_final_score','teamB_final_score','teamA_score','teamB_score','average_score_margin','average_score_per_game','std_score_per_game'}:
        return sequence + score + (' per played game' if '_per_game' in c else ' per team game' if c == 'average_score_margin' else '')
    if c in {'average_assists_per_game','std_assists_per_game'}:
        return 'assists per played game (MLB: fielding assists; other sports: scoring assists)'
    if c in {'average_minutes_per_game','std_minutes_per_game'}:
        return 'minutes per played game; SD uses n-1'
    if c in {'date','as_of_date','ranking_date','effective_from','effective_to'}:
        return 'calendar date, YYYY-MM-DD; local game/as-of date (not a UTC instant)'
    if c == 'timestamp':
        return sequence + 'UTC ISO-8601 timestamp; checkpoint reference for in-game tables'
    direct = {'age':'completed years', 'weight_kg':'kilograms', 'height_cm':'centimetres',
        'years_played':'completed evidenced seasons', 'months_serving_current_team':'completed calendar months',
        'injured_times_till_as_of_date':'reported episode count convention; not verified lifetime injuries',
        'number_of_teams_served':'distinct career clubs/franchises, only if complete',
        'games_played':'games / played appearances', 'home_times':'games', 'away_times':'games',
        'score_z_score':'dimensionless z-score',
        'temperature_c':'degrees Celsius', 'humidity_pct':'percent relative humidity, 0-100',
        'wind_direction':'compass degrees from true north; or Calm/Variable where officially coded',
        'weather_type':'source-derived categorical text; multiple descriptions may be semicolon-separated',
        'rank':'ordinal league/list position, 1 is highest', 'rating':'publisher-specific score; no common scale is imposed',
        'age_days':'calendar days', 'checkpoint_index':'zero-based integer sequence position',
        'source_url':'HTTP(S) URL', 'served_team_history':'ordered comma-separated names; EU CSV escaping where needed',
        'home_away':'Team A;Team B categorical pair: Home/Away', 'checkpoint':sequence+'checkpoint label'}
    if c in direct:
        return direct[c]
    if c.endswith('_id'):
        return 'identifier string; not a numeric measurement'
    if c in {'match','player_name','manager_name','coach_or_manager_name','team','current_team','team_name','city','location','final','game_type','league','competition','season','publisher','ranking_type','coverage_status','performance_status','provider'}:
        return 'text / categorical label; no physical unit'
    raise ValueError(('Unmapped unit', c))


def sql_interfaces(db):
    contexts = {'main': ('pre_match', 'all', None), 'in_game': ('in_game', 'all', None),
        'weather': ('weather', 'all', None)}
    for n in ['player_profiles', 'player_current_team', 'player_performance', 'manager_profiles',
              'manager_performance', 'team_history']:
        contexts[n] = (n, 'all', None)
    for p in ['polymarket', 'kalshi']:
        for k in ['pre_match', 'in_game']:
            contexts[p + '_' + k] = (k, 'all', p)
        contexts[p + '_in_game_checkpoints'] = ('checkpoints', 'us', p)
    for n in ['game_player_profiles', 'game_manager_profiles']:
        contexts[n] = (n, 'all', None)
    contexts['_game_weather_links'] = ('game_weather_links', 'all', None)
    outputs, objects = [], []
    for name, (kind, scope, provider) in contexts.items():
        definition = db.execute('SELECT type,sql FROM sqlite_master WHERE name=?', (name,)).fetchone()
        assert definition, name
        cols = db.execute('PRAGMA table_info("' + name + '")').fetchall()
        note = ''
        if name in ('player_performance', 'manager_performance', 'team_history'):
            note = 'Stored/default collection-start snapshots. For a custom start date use the parameterized SQL in temporal_queries.py.'
        elif name == 'main':
            note = 'Combined provider interface; provider + game_id identifies a row. league contains NBA, MLB, NHL or the actual soccer competition. Draw values apply only to explicit draw-option markets.'
        elif name == 'in_game':
            note = 'Combined provider in-game interface, with game date joined from main. Sequences require checkpoint-wise parsing.'
        objects.append(dict(dataset=name, object_type='SQL ' + definition['type'], kind=kind, scope=scope,
            row_grain=grain(kind), columns=len(cols), note=note, query='SELECT * FROM "' + name + '";', parameters='[]'))
        for col in cols:
            mapping_kind = 'pre_match' if kind in ('game_player_profiles', 'game_manager_profiles') else 'pre_match' if kind == 'game_weather_links' and col['name'] == 'game_id' else 'weather' if kind == 'game_weather_links' else kind
            row = dict(object_type='sql', dataset=name, position=col['cid'], column_name=col['name'],
                       physical_type=col['type'] or 'SQLite expression (dynamic)', rows=None, missing_count=None, missing_pct=None,
                       scope=scope, row_grain=grain(kind), sql_query='SELECT * FROM "' + name + '"', sql_parameters='[]')
            row.update(describe(col['name'], mapping_kind, scope, provider))
            if kind in ('game_player_profiles', 'game_manager_profiles'):
                row['temporal_rule'] = 'as_of_date is the prior local date t-1, derived from the official game date. Joining uses both person ID and as_of_date.'
            row['interface_note'] = note
            outputs.append(enrich(row))
    return outputs, objects


def add_missing_details(db, export_rows, sql_rows, objects):
    """Use verified disjoint export rollups, and directly count SQL-only projections."""
    exports = collections.defaultdict(dict)
    for r in export_rows:
        exports[r['dataset']][r['column_name']] = r
    sql_groups = collections.defaultdict(list)
    for r in sql_rows:
        sql_groups[r['dataset']].append(r)
    for table, rows in sql_groups.items():
        components = []
        if table in ('main', 'in_game'):
            target = 'pre_match' if table == 'main' else 'in_game'
            components = [v for k, v in exports.items() if context(k)[0] == target]
        elif table == 'weather':
            components = [exports['data/result/weather']]
        elif table in ('player_profiles','player_current_team','player_performance','manager_profiles','manager_performance','team_history','player_rankings_quarterly'):
            components = [v for k, v in exports.items() if context(k)[0] == table]
        else:
            components = [v for k, v in exports.items() if context(k)[0] in ('pre_match','in_game')
                          and re.search(r'FROM\s+' + re.escape(table) + r'\s*$', next(iter(v.values()))['sql_query'])]
        if components:
            # The full SQL performance projection includes publisher columns omitted
            # from league files. Verify those omitted source flags are all NULL.
            if table == 'player_performance':
                for component in components:
                    absent = [r['column_name'] for r in rows if r['column_name'] not in component]
                    if absent:
                        league = LEAGUES[next(iter(component.values()))['scope']]
                        condition = ' OR '.join('"' + name + '" IS NOT NULL' for name in absent)
                        assert not db.execute('SELECT 1 FROM _ranking_canonical_cache WHERE league=? AND (' + condition + ') LIMIT 1', (league,)).fetchone(), ('Export omitted populated ranking field', league)
            for r in rows:
                name = r['column_name']; total = missing = structural = 0
                for component in components:
                    base = next(iter(component.values())); total += base['rows']
                    if name in component:
                        missing += component[name]['missing_count']
                    elif name == 'provider' or name == 'competition' or (name == 'date' and table == 'in_game'):
                        pass  # literal provider, league classification or verified joined date
                    elif name.startswith('draw_') and base['scope'] == 'us':
                        missing += base['rows']; structural += base['rows']
                    elif table == 'player_performance' and '_top_' in name:
                        missing += base['rows']
                    else:
                        raise ValueError(('Unexplained SQL-only projection', table, name, base['dataset']))
                r.update(rows=total, missing_count=missing, missing_pct=round(missing*100/total,6) if total else None,
                         structural_not_applicable_count=structural, missing_basis='Rollup of verified disjoint export groups; SQL-only constant/omitted ranking projections checked.')
            if table == 'in_game':
                assert db.execute('SELECT COUNT(*) FROM in_game WHERE date IS NULL').fetchone()[0] == 0
        else:
            columns = [r['column_name'] for r in rows]
            query = 'SELECT COUNT(*),' + ','.join('COALESCE(SUM("' + n + '" IS NULL OR "' + n + '"=\'\'),0)' for n in columns) + ' FROM "' + table + '"'
            values = db.execute(query).fetchone()
            for r, missing in zip(rows, values[1:]):
                r.update(rows=values[0], missing_count=missing, missing_pct=round(missing*100/values[0],6) if values[0] else None,
                         structural_not_applicable_count=0, missing_basis='Direct current SQL COUNT and NULL/empty-string check.')
    for r in export_rows:
        r.update(structural_not_applicable_count=0, missing_basis='Previously independently verified SQL/CSV/Parquet counts; current schema, row counts and file sizes reconfirmed.')
    # Draws are optional outcomes. A NULL for an NBA/MLB/NHL game is not missing
    # data; keep that structural count separate from the applicable denominator.
    applicability={}
    for r in export_rows + sql_rows:
        r['applicable_rows']=r['rows']
        if not r['column_name'].startswith('draw_'):
            continue
        key=(r['object_type'],r['dataset'])
        if key not in applicability:
            if r['object_type']=='sql':
                sql='SELECT * FROM "'+r['dataset']+'"';params=[]
            else:
                sql,params=public_query(r['dataset'],['game_type'])
            applicability[key]=db.execute("SELECT count(*) FROM ("+sql+") WHERE game_type<>'Soccer'",params).fetchone()[0]
        structural=applicability[key]
        r['structural_not_applicable_count']=structural
        r['missing_count']-=structural
        r['applicable_rows']=r['rows']-structural
        assert r['missing_count']>=0
        r['missing_pct']=round(100*r['missing_count']/r['applicable_rows'],6) if r['applicable_rows'] else None
        r['missing_basis']+=' Draw missing percentage uses only explicit draw-option soccer rows; other sport rows are structurally not applicable.'
    totals = {table: rows[0]['rows'] for table, rows in sql_groups.items()}
    for o in objects:
        if o['dataset'] in totals:
            o['rows'] = totals[o['dataset']]
    for r in export_rows + sql_rows:
        r['missing_reason'] = reason_basis(r['dataset'], r['column_name'])
        if r['structural_not_applicable_count']:
            r['missing_reason'] = 'Draw missing count and percentage apply only to soccer markets with explicit draw options. Non-applicable sport rows are counted separately; missing soccer values follow the provider selection audit.'
        if r['column_name'] == 'effective_to':
            r['missing_reason'] = 'NULL end is an intentionally open-ended temporal interval; not an unknown amount or failed observation.'
        if r['column_name'] == 'rating':
            r['missing_reason'] = 'Publisher list supplies an ordinal rank but may not publish a separate numeric rating; no rating is invented.'
        if r['missing_pct'] == 100:
            r['source_status'] = 'ALL_VALUES_MISSING_IN_THIS_PROJECTION; see field/source limitations'


def write_csv(path, rows):
    assert rows, path
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        for r in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k, v in r.items()})


GUIDE = '''# Current data catalog

This catalog documents the actual current publication, not a proposed schema.
Every file column is listed separately, with its type, meaning, upstream source,
calculation, temporal rule, internal evidence path and latest verified missing count.
The source registry contains both official endpoint/documentation references and
actual selected ranking evidence URLs. A family reference is not a claim
that one page supplied every record; follow the per-record audit for the exact raw field.

- Open [the searchable HTML catalog](data_catalog.html) to filter by dataset, field or source.
- [Every export field, CSV](data_catalog_columns.csv); [SQL interface fields, CSV](data_catalog_sql_columns.csv).
- [Source registry, CSV](data_catalog_sources.csv).
- [Catalog validation](data_catalog_validation.json).

## Structure and time rules

`collected data/result` is the physical output folder. `data/result` is its existing
compatibility path, not another copy. CSV and Parquet versions of one dataset have
the same logical schema. League weather files are subsets of global weather, and
SQL union views expose existing rows rather than new observations.

Pregame hours are **0, 12, 24, 36 and 48**. Each hour has separate Team A and Team B
probability and decimal-odds columns; draw fields apply only to markets that offer a draw. `pre_0` is
strictly before start. A column label is the requested lookback, not proof of an
exactly timed quote. Prices use the closest eligible previous observation and
respect bucket/candle completion. Actual times and raw pointers remain in SQL audit.

Polymarket probabilities are historical token prices. Kalshi probabilities use the
corresponding team's YES bid close on a 0-1 scale. Decimal odds are `1/p` for `p>0`.
They are different price definitions. Scores and winners come from official sports
reports, and soccer final results follow the regulation-time market definition.

In-game fields are semicolon-separated sequences: each position aligns with one
checkpoint. Missing positions contain `null`; cell-level non-null counts do not
measure checkpoint completeness. See [checkpoint missing slots](in_game_missing_slots.csv).
NBA has Start/Q1/Halftime/Q4; MLB Start/Inning3/Inning5/Inning7; NHL Start/P1/P2;
soccer START/HALFTIME/SECOND_HALF_START. Scalar checkpoint SQL views currently cover US leagues only.

Daily performance/profile rows are person-date observations, not distinct people.
Performance is cumulative day by day from **2024-01-01 through the queried date**, with no calendar-year or season reset. For example, **2025-07-01 includes 2024-01-01 through 2025-07-01**. Results begin with the first available game, including the first year. Only zero played appearances receive performance_status='insufficient matches' and zero performance values; one or more appearances receive 'observed matches'. Each statistic uses its available source values. Missing source statistics after appearances remain null; sample standard deviations require two valid observations. Valid observation counts are retained in _player_performance_sample_counts. Profile exports start at the stored
collection start; parameterized performance SQL can restrict both start and cutoff.
Join `game_player_profiles` / `game_manager_profiles` to profiles on person ID AND
`as_of_date` for t-1 features. Complete career statistics are not implied.

The [2025-08-01 player-performance check](player_performance_asof_20250801.md)
independently recomputes that date's performance from collected game observations
through the date. Date queries are inclusive end-of-day snapshots; use the preceding
date for pre-game prediction features.

Injury false/zero follows the documented no-report convention. Physical attributes
are sourced constants while age is date-derived. Ranking flags remain publisher-specific.
Some ranking evidence is syndicated. The latest eligible publisher edition is carried forward on each query date; quarterly ranking output tables have been removed.

Game tables share one schema per provider. league identifies NBA, MLB, NHL, Premier League, La Liga, Bundesliga, Serie A, Ligue 1 or UEFA Champions League. The separate competition column and separate EU game exports have been removed. Soccer player, team and coach performance remains pooled across all six competitions, with the combined EU soccer scope in supporting tables.

## SQL examples

```sql
-- Discover every published export column and its source.
SELECT dataset, position, column_name, physical_type, unit, meaning,
       source_names, source_urls, derivation, temporal_rule
FROM data_catalog
WHERE object_type = 'export'
ORDER BY dataset, position;

-- Look up one provider's pregame fields.
SELECT column_name, meaning, source_names, source_fields, lineage_lookup
FROM data_catalog
WHERE dataset = 'data/result/polymarket/pre_match';

-- Separate odds tables remain available; combined main requires provider filtering.
SELECT * FROM main
WHERE date = :query_date AND provider = 'kalshi';

-- Team performance accumulated through the selected date.
SELECT * FROM team_history WHERE as_of_date = :query_date;

-- Recorded player-to-team affiliations on the selected date.
SELECT * FROM player_current_team WHERE as_of_date = :query_date;

-- Dated weather: local day, one row per city, representative station observation.
SELECT * FROM weather WHERE date = :query_date;
```

For custom performance bounds, use the checked-in `data collecting/temporal_queries.py`
templates, or:

```powershell
& '.venv/Scripts/python.exe' 'data collecting/query_sql.py' --table player_performance --start-date 2024-01-01 --date 2025-06-01
```

SQL metadata tables added by this catalog are `_data_catalog_columns`,
`_data_catalog_sources` and `_data_catalog_datasets`;
`data_catalog` is their public field-catalog view. These are documentation metadata,
not additional research datasets. Internal raw caches, operational logs and superseded
pilot tables are not promoted into this public research catalog.
'''


def install_sql(rows, objects):
    def install(db, name, values):
        keys = list(values[0])
        types = {k: 'INTEGER' if k in ('position', 'rows', 'applicable_rows', 'missing_count', 'columns') else 'REAL' if k == 'missing_pct' else 'TEXT' for k in keys}
        existing = [r[1] for r in db.execute('PRAGMA table_info("' + name + '")')]
        if existing and existing != keys:
            assert name in {'_data_catalog_columns','_data_catalog_sources','_data_catalog_datasets'}
            db.execute('DROP TABLE "' + name + '"')  # replace only regenerable catalog metadata
        db.execute('CREATE TABLE IF NOT EXISTS "' + name + '" (' + ','.join('"' + k + '" ' + types[k] for k in keys) + ')')
        assert [r[1] for r in db.execute('PRAGMA table_info("' + name + '")')] == keys, ('Catalog schema changed', name)
        db.execute('DELETE FROM "' + name + '"')
        db.executemany('INSERT INTO "' + name + '" VALUES (' + ','.join('?' for _ in keys) + ')',
            [tuple(json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v for v in r.values()) for r in values])
    db = sqlite3.connect(DB, timeout=60)
    try:
        with db:
            install(db, '_data_catalog_columns', rows)
            install(db, '_data_catalog_sources', list(SOURCES.values()))
            # SQL and export dataset records have intentionally unified keys.
            normalized_objects = [{k: r.get(k) for k in ['dataset', 'object_type', 'kind', 'scope', 'description', 'rows', 'columns', 'note', 'query', 'parameters']} for r in objects]
            install(db, '_data_catalog_datasets', normalized_objects)
            db.execute('CREATE INDEX IF NOT EXISTS ix_data_catalog_fields ON _data_catalog_columns(dataset,column_name)')
            db.execute('CREATE VIEW IF NOT EXISTS data_catalog AS SELECT * FROM _data_catalog_columns')
        assert db.execute('SELECT COUNT(*) FROM data_catalog').fetchone()[0] == len(rows)
    finally:
        db.close()


def main():
    now = dt.datetime.now(dt.UTC).isoformat()
    inventory = json.loads((REPORTS / 'all_outputs_inventory.json').read_text(encoding='utf-8'))
    audit = json.loads((REPORTS / 'missing_data_verification.json').read_text(encoding='utf-8'))
    assert audit['status'] == 'WORKING' and not audit['errors'], 'Finish missing-count verification before publishing the catalog'
    verified = {x['dataset']: x for x in audit['datasets']}
    assert set(verified) == {x['dataset'] for x in inventory['outputs']}
    db = sqlite3.connect(pathlib.Path(DB).resolve().as_uri() + '?mode=ro', uri=True)
    db.row_factory = sqlite3.Row
    setup_sources(db)
    rows, objects, checks = [], [], []
    for item in inventory['outputs']:
        proof = verified[item['dataset']]
        assert proof['rows'] == item['rows'] and proof['columns'] == len(item['columns'])
        verified_fields = {f['column_name']: f for f in proof['fields']}
        for col in item['columns']:
            assert verified_fields[col['column']]['counts_match'] and verified_fields[col['column']]['parquet_missing'] == col['missing']
        path = ROOT / item['parquet']
        parquet = pq.ParquetFile(path)
        names = parquet.schema_arrow.names
        assert names == [c['column'] for c in item['columns']], item['dataset']
        assert parquet.metadata.num_rows == item['rows'], item['dataset']
        assert path.stat().st_size == item['parquet_bytes'], ('Stale inventory size', path)
        csv_path = ROOT / item['csv']
        assert csv_path.stat().st_size == item['csv_bytes'], ('Stale CSV inventory size', csv_path)
        with csv_path.open(encoding='utf-8-sig', newline='') as f:
            assert next(csv.reader(f)) == names, ('CSV header mismatch', csv_path)
        sql, params = public_query(item['dataset'], names)
        assert [d[0] for d in db.execute(sql + ' LIMIT 0', params).description] == names
        kind, scope, provider = context(item['dataset'])
        objects.append(dict(dataset=item['dataset'], object_type='CSV + Parquet export', kind=kind, scope=scope,
            row_grain=grain(kind), rows=item['rows'], columns=len(names), note='', query=sql, parameters=json.dumps(params)))
        for col in item['columns']:
            row = dict(object_type='export', dataset=item['dataset'], position=col['position'], column_name=col['column'],
                physical_type=col['type'], rows=item['rows'], missing_count=col['missing'], missing_pct=col['missing_pct'],
                scope=scope, row_grain=grain(kind), sql_query=sql, sql_parameters=json.dumps(params))
            row.update(describe(col['column'], kind, scope, provider))
            row['interface_note'] = 'Independent SQL/CSV/Parquet counts verified at ' + proof.get('verified_at_utc', audit['generated_at_utc']) + '; audit ' + proof.get('source_audit_id', audit['audit_id']) + '. Current file sizes, schema and Parquet counts reconfirmed for this catalog.'
            rows.append(enrich(row))
        checks.append(dict(dataset=item['dataset'], columns=len(names), rows=item['rows'], parquet_schema=True, csv_header=True, sql_projection=True, file_sizes_match_inventory=True))
    sql_rows, sql_objects = sql_interfaces(db)
    add_missing_details(db, rows, sql_rows, sql_objects)
    from catalog_render import table_description
    descriptions = {}
    for obj in objects + sql_objects:
        obj['description'] = table_description(obj)
        obj.pop('row_grain')
        descriptions[obj['dataset']] = obj['description']
    for row in rows + sql_rows:
        row['table_description'] = descriptions[row['dataset']]
        row.pop('row_grain')
    all_rows = rows + sql_rows
    tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type IN ('table','view')")}
    unresolved = sorted({t for r in all_rows for t in r['lineage_tables'] if t not in tables})
    assert not unresolved, ('Unresolved lineage tables', unresolved)
    assert len({(r['object_type'], r['dataset'], r['column_name']) for r in all_rows}) == len(all_rows)
    assert all(k in SOURCES for r in all_rows for k in r['source_ids'])
    assert not any(re.search(r'_pre_(60|72)_', r['column_name']) for r in all_rows)
    scope = dict(db.execute('SELECT * FROM _collection_scope').fetchone())
    db.close()
    write_csv(REPORTS / 'data_catalog_columns.csv', rows)
    write_csv(REPORTS / 'data_catalog_sql_columns.csv', sql_rows)
    write_csv(REPORTS / 'data_catalog_sources.csv', list(SOURCES.values()))
    from catalog_render import render
    render(REPORTS, all_rows, objects + sql_objects, SOURCES, inventory, now, GUIDE)
    write_csv(REPORTS / 'data_catalog_missing.csv', [{k: r[k] for k in ['object_type','dataset','column_name','rows','applicable_rows','missing_count','missing_pct','structural_not_applicable_count','missing_reason','missing_basis']} for r in all_rows])
    install_sql(all_rows, objects + sql_objects)
    validation = dict(generated_at_utc=now, catalog_status='WORKING', missing_report='data_catalog_missing.csv',
        export_datasets=len(objects), export_columns=len(rows), sql_interfaces=len(sql_objects), sql_columns=len(sql_rows),
        source_families=len(SOURCES), collection_scope=scope,
        schema_checks=checks, unresolved_columns=[], unresolved_lineage_tables=unresolved,
        missing_counts_inventory_timestamp=inventory['generated_at_utc'],
        verification_scope='Current CSV headers, Parquet schema/row counts, file sizes and SQL projections checked. All field-source mappings and units resolve. SQL missing counts use verified disjoint export rollups or direct SQL counts for SQL-only projections. No new data acquisition or broad fresh per-value semantic audit claimed; weather was separately fully reverified.',
        warnings=['NHL injury zero/false is the requested no-report default, not a verified medical negative.',
                  'Some ranking URLs are syndicated evidence, distinct from the attributed publisher.',
                  'In-game missing percentages require checkpoint-slot denominators; cell nullness is insufficient.'])
    (REPORTS / 'data_catalog_validation.json').write_text(json.dumps(validation, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in validation.items() if k not in ('schema_checks', 'warnings')}, indent=2))


if __name__ == '__main__':
    main()
