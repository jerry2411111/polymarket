"""Check dated venue metadata before assigning both participants Away."""
import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

db=sqlite3.connect(DB);s={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_mlb_schedule')};f={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_mlb_feeds')};out=collections.Counter();examples=[]
for b, in db.execute('SELECT body FROM _mlb_canonical_games'):
    g=json.loads(b);raw=s[g['official_game_id']]['raw_game'];v=f[g['official_game_id']]['venue'];h=raw['teams']['home']['team'];a=raw['teams']['away']['team'];vs={t.get(k,{}).get('id') for t in [h,a] for k in ['venue','springVenue']}-{None}
    if v['id'] not in vs:
        key=(g['date'][:4],v['name'],h['name'],h.get('season'));out[key]+=1
        examples.append(dict(game_id=g['game_id'],raw_game_fields={k:z for k,z in raw.items() if k not in ['teams','probablePitchers','ruleSettings']},home_team=h,away_team=a,actual_venue=v))
report=dict(groups=[dict(year=k[0],venue=k[1],home=k[2],team_metadata_season=k[3],games=n) for k,n in out.items()],examples=examples)
(ROOT/'reports/mlb_venue_designations.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report['groups'],ensure_ascii=False))
