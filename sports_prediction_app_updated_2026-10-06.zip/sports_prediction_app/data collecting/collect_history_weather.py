"""NOAA weather for verified game cities/dates; no invented venue or weather."""
import argparse,bisect,collections,concurrent.futures,datetime as dt,io,json,sqlite3,types
import pyarrow as pa
import pyarrow.parquet as pq
from history_client import HistoryClient
from history_index import records
from probe_history import ROOT
from build_history_catalog import DB
from core import utc,odd
from weather_values import value,quality,weather_type,weather_codes,STATIONS as ORIGINAL_STATIONS

STATIONS={**ORIGINAL_STATIONS,'Boston':'USW00014739','Denver':'USW00003017','Minneapolis':'USW00014922','Indianapolis':'USW00093819','Dallas':'USW00013960','Los Angeles':'USW00023174','Inglewood':'USW00023174','San Francisco':'USW00023234','Portland':'USW00024229','Milwaukee':'USW00014839','Oklahoma City':'USW00013967','Memphis':'USW00013893','Toronto':'CAN06158665','Phoenix':'USW00023183','Orlando':'USW00012815','Washington':'USW00013743','Detroit':'USW00094847','Charlotte':'USW00013881','Atlanta':'USW00013874','New Orleans':'USW00012916','Salt Lake City':'USW00024127','Sacramento':'USW00023232','Philadelphia':'USW00013739','Houston':'USW00012960','Miami':'USW00012839','Brooklyn':'USW00094728','Las Vegas':'USW00023169','Abu Dhabi':'AEI0000OMAA','San Diego':'USW00023188','Honolulu':'USW00022521'}
STATIONS.update({'Toronto':'CAN06158733','Macao, China':'MCM00045020','Birmingham':'USW00013876','Greensboro':'USW00013723','Austin':'USW00013958','Palm Desert':'USW00093138','San Juan,Puerto Rico':'RQW00011641','Charleston':'USW00013880','Fort Worth':'USW00003985','Vancouver':'CAN01108447','Mexico City':'MXM00076680','Berlin':'GMN00000399','London':'UKI0000EGLL','Paris':'FRM00007156'})
STATIONS.update({'Toronto':'CAN06158731','Vancouver':'CAN01108395','Macao, China':'MCI0000VMMC','Berlin':'GMI0000EDDB','Fort Worth':'USW00013961'})
DOC='https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/doc/'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--through-date',default=dt.date.today().isoformat());ap.add_argument('--league',choices=['NBA','MLB','NHL','EU soccer']);args=ap.parse_args();c=HistoryClient()
    for f in ['ghcnh_DOCUMENTATION.pdf','ghcnh-present-weather-elements.pdf','ghcnh-sky-cover-elements.pdf','ghcnh-station-list.txt']:c.get(DOC+f,document=True)
    b,r=c.get(DOC+'ghcnh-station-list.txt',document=True);station_rows={line[:11]:line for line in b.decode().splitlines()}
    if any(s not in station_rows for s in STATIONS.values()):raise ValueError('Selected station absent from official station directory')
    db=sqlite3.connect(DB,timeout=60);gs={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _history_games')};fs=[json.loads(r[0]) for r in db.execute('SELECT body FROM _official_game_facts') if json.loads(r[0])['league']!='NBA']
    nba_ids={r[0] for r in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='NBA' UNION SELECT game_id FROM kalshi_pre_match WHERE league='NBA'")}
    for gid,body in db.execute('SELECT id,body FROM _nba_canonical_games'):
        if gid in nba_ids:
            g=json.loads(body);gs[gid]=g;fs.append(g)
    selected_ids={r[0] for r in db.execute('SELECT game_id FROM polymarket_pre_match UNION SELECT game_id FROM kalshi_pre_match')}
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_game_weather_locations'").fetchone():
        eu_ids={r[0] for r in db.execute('SELECT game_id FROM _source_polymarket_soccer_pre_match UNION SELECT game_id FROM _source_kalshi_soccer_pre_match')};selected_ids.update(eu_ids)
        for gid,b,location in db.execute('SELECT g.game_id,g.body,l.body FROM _eu_game_facts g JOIN _eu_game_weather_locations l USING(game_id)'):
            if gid in eu_ids:g=json.loads(b);g['city']=json.loads(location)['city'];gs[gid]=g;fs.append(g)
    extra_stations={(city,year):station for city,year,station in db.execute('SELECT city,year,station_id FROM _weather_city_stations')} if db.execute("SELECT 1 FROM sqlite_master WHERE name='_weather_city_stations'").fetchone() else {}
    def station_for(city,date):return extra_stations.get((city,date[:4])) or STATIONS.get(city)
    fs=[{**gs.get(f['game_id'],{}),**f} for f in fs if f['game_id'] in selected_ids]
    for f in fs:gs[f['game_id']]=f
    db.row_factory=sqlite3.Row;previous=[dict(r) for r in db.execute('SELECT * FROM weather')];previous_audit=[json.loads(r[0]) for r in db.execute('SELECT body FROM _weather_observation_audit')];db.close();targets={};unmapped=[];game_links=[]
    for f in fs:
        if args.league and f['league']!=args.league:continue
        if f['date']>args.through_date:continue
        city=f.get('city')
        if not city:unmapped.append(f['game_id']);continue
        if not station_for(city,f['date']):unmapped.append(f['game_id'])
        key=(city,f['date']);g=gs[f['game_id']]
        game_links.append((g['game_id'],city,f['date']))
        if key not in targets or g['start']<targets[key]['start']:targets[key]=g
    # A city/date is shared across leagues. Its time anchor must precede ALL
    # linked games, even when only one league is being expanded in this run.
    for f in fs:
        key=(f.get('city'),f['date'])
        if key in targets and utc(f['start'])<utc(targets[key]['start']):targets[key]=f
    wanted=sorted({(station_for(city,date),date[:4]) for city,date in targets if station_for(city,date)});loaded={};issues=[];target_times=collections.defaultdict(set)
    for (city,date),g in targets.items():
        station=station_for(city,date)
        if station:target_times[station,date[:4]].add(utc(g['start']).timestamp())
    def fetch(key):
        station,year=key;url=f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/parquet/GHCNh_{station}_{year}.parquet'
        try:
            b,r=c.get(url,document=True);cols=pq.ParquetFile(io.BytesIO(b)).schema_arrow.names
            base=['temperature','relative_humidity','wind_direction','wind_speed','sky_condition']+[f'pres_wx_{grp}{n}' for grp in ['AW','MW','AU'] for n in [1,2,3]]+[f'sky_cover_{grp}_{n}' for grp in ['layer','summation'] for n in [1,2,3,4]]
            selected=['STATION','DATE']+[k+s for k in base for s in ['','_Quality_Code','_Source_Code','_Measurement_Code'] if k+s in cols]
            # Keep the nearest eligible observation per actual requested time.
            # This preserves original row indices without holding hundreds of
            # complete annual station archives as Python dictionaries.
            requested=sorted(target_times[key]);best={};offset=0
            for batch in pq.ParquetFile(io.BytesIO(b)).iter_batches(batch_size=1024,columns=selected):
                for j,x in enumerate(batch.to_pylist()):
                    if value(x,'temperature') is None and value(x,'relative_humidity') is None:continue
                    date=str(x['DATE']);t=utc(date if date.endswith('Z') or '+' in date else date+'Z').timestamp();i=offset+j;first=bisect.bisect_left(requested,t);last=bisect.bisect_right(requested,t+5400)
                    for target in requested[first:last]:
                        if target not in best or (t,i)>best[target][:2]:best[target]=(t,i,x)
                offset+=batch.num_rows
            eligible={v[1]:v for v in best.values()}
            return key,sorted(eligible.values(),key=lambda a:(a[0],a[1])),r,None
        except Exception as e:return key,[],None,dict(station=station,year=year,url=url,error=str(e))
    milestone=10
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for n,(key,rows,r,error) in enumerate(pool.map(fetch,wanted),1):
            loaded[key]=(rows,r)
            if error:issues.append(error)
            if n*100//len(wanted)>=milestone or n==len(wanted):
                print('WEATHER ARCHIVES',milestone,'percent;',n,len(wanted),'issues',len(issues),flush=True);milestone+=10
    codes=weather_codes(types.SimpleNamespace(root=ROOT,records=list(records())));out=[];audit=[]
    for (city,date),g in sorted(targets.items()):
        station=station_for(city,date);items,r=loaded.get((station,date[:4]),([],None));ts=[x[0] for x in items];target=utc(g['start']).timestamp();i=bisect.bisect_right(ts,target)-1;hit=items[i] if i>=0 and target-items[i][0]<=5400 else None
        row=dict(city=city,date=date,humidity_pct=None,weather_type=None,temperature_c=None,wind_direction=None)
        if hit:
            t,n,x=hit;rh=value(x,'relative_humidity');temp=value(x,'temperature');wind=value(x,'wind_direction')
            if rh is not None and not 0<=rh<=100:raise ValueError('Invalid source humidity')
            row.update(humidity_pct=rh,temperature_c=temp,weather_type=weather_type(x,codes))
            if quality(x,'wind_direction') and x.get('wind_direction_Measurement_Code')=='V':row['wind_direction']='Variable'
            elif wind is not None:
                if not 0<=wind<=360:raise ValueError('Invalid source wind direction')
                row['wind_direction']='Calm' if wind==0 else str(int(wind))+' degrees'
            audit.append(dict(city=city,date=date,game_id=g['game_id'],station_id=station,station_directory_row=station_rows[station],request_id=r['request_id'],row_index=n,observation_timestamp_utc=utc(t).isoformat(),raw=x,normalized=row))
        else:audit.append(dict(city=city,date=date,game_id=g['game_id'],station_id=station,reason='No reviewed station with a usable annual archive' if station is None else 'No station observation within 90 minutes before earliest collected game in this city/date',request_id=r['request_id'] if r else None))
        out.append(row)
    collected_out=list(out)
    if args.league:
        out=sorted([r for r in previous if (r['city'],r['date']) not in targets]+out,key=lambda r:(r['city'],r['date']))
        audit=[r for r in previous_audit if (r['city'],r['date']) not in targets]+audit
    db=sqlite3.connect(DB,timeout=60);db.execute('DROP TABLE IF EXISTS weather');db.execute('CREATE TABLE weather(city TEXT NOT NULL,date TEXT NOT NULL,humidity_pct REAL,weather_type TEXT,temperature_c REAL,wind_direction TEXT,PRIMARY KEY(city,date)) STRICT');db.executemany('INSERT INTO weather VALUES(?,?,?,?,?,?)',[tuple(r.values()) for r in out]);db.execute('CREATE TABLE IF NOT EXISTS _weather_observation_audit(body TEXT NOT NULL)');db.execute('DELETE FROM _weather_observation_audit');db.executemany('INSERT INTO _weather_observation_audit VALUES(?)',[(json.dumps(x),) for x in audit]);db.execute('CREATE TABLE IF NOT EXISTS _game_weather_links (game_id TEXT PRIMARY KEY,city TEXT NOT NULL,date TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _game_weather_links VALUES (?,?,?)',game_links);db.commit();db.close()
    from dataset_export import export
    export(ROOT,'weather',out,['city','date','humidity_pct','weather_type','temperature_c','wind_direction'],dict(humidity_pct=pa.float64(),temperature_c=pa.float64()))
    result=dict(city_dates=len(out),cities=len({r['city'] for r in out}),league_processed=args.league,league_city_dates=len(collected_out),games_linked=len(game_links),station_year_archives=len(wanted),new_requests=c.requests,missing_verified_city_or_station_games=len(unmapped),field_missing={k:dict(missing=sum(r[k] is None for r in collected_out),total=len(collected_out),pct=100*sum(r[k] is None for r in collected_out)/len(collected_out) if collected_out else None) for k in ['humidity_pct','weather_type','temperature_c','wind_direction']},issues=issues,scope='Outdoor station weather for verified game city; first selected game in city/date supplies time anchor; latest qualifying prior weather <=90min. Not indoor arena conditions.')
    (ROOT/'reports/history_weather.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    if args.league:(ROOT/'reports'/f'{args.league.lower().replace(" ","_")}_weather_acquisition.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))

if __name__=='__main__':main()
