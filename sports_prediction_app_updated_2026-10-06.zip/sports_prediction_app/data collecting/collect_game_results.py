"""Acquire finished-game scores and available player statistics in official batches."""
import json,os
from probe_history import Client,ROOT
from history_index import index,real_milestones

def main():
 os.environ['PILOT_MAX_REQUESTS']='1000';c=Client(ROOT)
 games=sorted(real_milestones(index()),key=lambda x:x[0]);out=[]
 for start in range(0,len(games),100):
  ids=[x[0] for x in games[start:start+100]]
  try:
   d,r=c.get('https://external-api.kalshi.com/trade-api/v2/live_data/batch',{'milestone_ids':ids,'include_player_stats':'true'})
   got={x['milestone_id'] for x in d['live_datas']}
   if not got<=set(ids):raise ValueError('Unexpected milestone in batch')
   out.append(dict(request_id=r['request_id'],requested=len(ids),obtained=len(got),missing=sorted(set(ids)-got)))
  except Exception as e:out.append(dict(ids=ids,error=str(e)))
  print('RESULTS',min(start+100,len(games)),'/',len(games),flush=True)
 (ROOT/'reports/game_results_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
if __name__=='__main__':main()
