import sys
from collect_history_weather import DOC
from history_client import HistoryClient
c=HistoryClient();b,r=c.get(DOC+'ghcnh-station-list.txt',document=True)
terms=sys.argv[1:] or ['CYYZ','CYVR','EDDB','VMMC','PEARSON','SCHONEFELD','BRANDENBURG','FT WORTH','11641']
lines=b.decode().splitlines()
for term in terms:
    hits=[line for line in lines if term in line.upper()]
    print(term)
    for line in hits[:12]:print(line)
