"""Official NBA identity helpers, including repeat games and temporary teams."""
import collections,json,sqlite3
from bs4 import BeautifulSoup
from history_client import HistoryClient
from build_history_catalog import DB,clean

SPECIAL = {
    'KEN': ('1610616853', "Kenny's Young Stars", 2025),
    'CHK': ('1610616851', "Chuck's Global Stars", 2025),
    'SHQ': ('1610616852', "Shaq's OGs", 2025),
    'CAN': ('1610616854', "Candace's Rising Stars", 2025),
    'WLD': ('1610616861', 'Team World', 2026),
    'STR': ('1610616859', 'USA Stars', 2026),
    'STP': ('1610616860', 'USA Stripes', 2026),
}
SOURCES = {2025:'https://www.nba.com/allstar/2025/roster',
           2026:'https://www.nba.com/news/2026-all-star-teams-announcement'}

def full_team_name(name):
    return {'LA Clippers':'Los Angeles Clippers'}.get(name,name)

def canonical_ids(cards):
    groups=collections.defaultdict(list)
    for c in cards:
        groups[c['date'],frozenset(c['team_tricodes'])].append(c)
    result={}
    for group in groups.values():
        group.sort(key=lambda c:(c['start_utc'],c['official_game_id']))
        for n,c in enumerate(group,1):
            gid='NBA_'+c['date'].replace('-','')+'_'+'_'.join(c['team_tricodes'])
            if len(group)>1:gid+='_G'+str(n)
            result[c['official_game_id']]=gid
    return result

def special_teams(db):
    if not db.execute("SELECT 1 FROM sqlite_master WHERE name='_official_nba_special_teams'").fetchone():return {}
    return {c:json.loads(b) for c,b in db.execute('SELECT code,body FROM _official_nba_special_teams')}

def main():
    db=sqlite3.connect(DB,timeout=60);client=HistoryClient();docs={}
    for year,url in SOURCES.items():
        body,r=client.get(url,document=True)
        docs[year]=(clean(BeautifulSoup(body,'html.parser').get_text(' ',strip=True)),r)
    cards=[json.loads(b) for (b,) in db.execute('SELECT body FROM _official_nba_schedule')]
    rows=[]
    for code,(native,name,year) in SPECIAL.items():
        text,r=docs[year]
        # The official roster headline says Team World or World in different revisions.
        term='World' if code=='WLD' else name
        assert clean(term) in text, ('Official full-name source changed',code)
        evidence=[c for c in cards if code in c['team_tricodes'] and c['date'].startswith(str(year))]
        assert evidence and all(c['official_team_ids'][c['team_tricodes'].index(code)]==native for c in evidence)
        row=dict(code=code,official_team_id=native,full_name=name,team_type='temporary_all_star',
                 source_url=SOURCES[year],request_id=r['request_id'],official_game_ids=[c['official_game_id'] for c in evidence])
        rows.append((code,json.dumps(row)))
    db.execute('CREATE TABLE IF NOT EXISTS _official_nba_special_teams (code TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
    db.executemany('INSERT OR REPLACE INTO _official_nba_special_teams VALUES (?,?)',rows);db.commit();db.close()
    print('Verified official All-Star team names:',len(rows),'new requests:',client.requests)

if __name__=='__main__':main()
