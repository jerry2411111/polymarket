"""Helpers for the NHL's current public API and league-authored reports."""
import datetime as dt,re
from bs4 import BeautifulSoup
from official_html import decode_html
from zoneinfo import ZoneInfo

def full_team_name(t):
 parts=[str(t.get(k,{}).get('default') or '').strip() for k in ['placeName','commonName']]
 if str(t.get('id'))=='67' and t.get('abbrev')=='USA':return 'United States'
 if parts[0] and parts[1].startswith(parts[0]+' '):return parts[1]
 return ' '.join(dict.fromkeys(p for p in parts if p))

def report_clock_utc(clock,zone,scheduled,venue_timezone):
 if not clock or not venue_timezone:return None
 reference=dt.datetime.fromisoformat(scheduled.replace('Z','+00:00'));tz=ZoneInfo(venue_timezone);local=reference.astimezone(tz)
 h,m=map(int,clock.split(':'));choices=[]
 for delta in [-1,0,1]:
  for hour in {h%12,h%12+12}:
   stamp=dt.datetime.combine(local.date()+dt.timedelta(days=delta),dt.time(hour,m),tz)
   if zone and stamp.tzname()!=zone:continue
   choices.append(stamp.astimezone(dt.UTC))
 if not choices:return None
 result=min(choices,key=lambda x:abs((x-reference).total_seconds()))
 return result.isoformat() if -1800<=(result-reference).total_seconds()<=3*3600 else None

def minutes(value):
 if value is None:return None
 assert re.fullmatch(r'\d+:\d{2}',value),value
 m,s=map(int,value.split(':'));assert 0<=s<60
 return m+s/60

def period_clocks(body,scheduled,venue_timezone):
 soup=body if isinstance(body,BeautifulSoup) else BeautifulSoup(decode_html(body),'html.parser');out=[];starters=None;previous=None
 reference=dt.datetime.fromisoformat(scheduled.replace('Z','+00:00'));tz=ZoneInfo(venue_timezone) if venue_timezone else None
 for ri,row in enumerate(soup.find_all('tr')):
  cells=row.find_all('td',recursive=False)
  if len(cells) not in [7,8]:continue
  values=[x.get_text(' ',strip=True) for x in cells]
  if values[4] not in ['PSTR','PEND','GEND']:continue
  hit=re.search(r'Local time:\s*(\d{1,2}:\d{2})\s+([A-Z]+)',values[5]);stamp=None
  if hit and tz:
   h,m=map(int,hit[1].split(':'));choices=[]
   for delta in [-1,0,1,2]:
    for hour in ({h} if h>12 else {h%12,h%12+12}):
     t=dt.datetime.combine(reference.astimezone(tz).date()+dt.timedelta(days=delta),dt.time(hour,m),tz).astimezone(dt.UTC)
     if t.astimezone(tz).tzname()!=hit[2]:continue
     if previous is None:
      if -1800<=(t-reference).total_seconds()<=10800:choices.append(t)
     elif 0<=(t-previous).total_seconds()<=4*3600:choices.append(t)
   if choices:stamp=min(choices,key=lambda t:abs((t-(previous or reference)).total_seconds()));previous=stamp
  out.append(dict(period=int(values[1]),event=values[4],timestamp_utc=stamp.isoformat() if stamp else None,raw_description=values[5],html_row=ri))
  if values[4]=='PSTR' and values[1]=='1' and len(values)==8:
   lineups=[[int(n) for n in re.findall(r'\b(\d+)\s+[CLRDG]\b',values[i])] for i in [6,7]]
   if all(len(v) in [5,6] and len(v)==len(set(v)) for v in lineups):starters=lineups
 return out,starters
