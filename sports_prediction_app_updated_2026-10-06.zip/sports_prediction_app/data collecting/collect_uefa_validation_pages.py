"""Retain official season totals and a disputed-score club timeline for validation."""
import datetime as dt,json,re
from bs4 import BeautifulSoup
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS

def main():
 HOSTS.update({'www.uefa.com','www.mff.se','www.glimt.no'});c=HistoryClient();rows=[]
 urls=['https://www.uefa.com/uefachampionsleague/history/seasons/'+str(y)+'/statistics/' for y in [2025,2026]]+['https://www.mff.se/nyheter/rydstrom-det-var-en-galen-och-fantastisk-match-2024-08-13/','https://www.glimt.no/lag/import/tournament/uefa-champions-league/season/fotballsesongen-2024/match/bodo-glimt--rfs-copy-2']
 for url in urls:
  b,r,redirects=get(c,url);soup=BeautifulSoup(b,'html.parser');text=' '.join(soup.get_text(' ',strip=True).split());contexts=[]
  for m in re.finditer(r'189|Matches played|99′|3 – 4|90\+5|4 - 1|13\. august',text):
   contexts.append(text[max(0,m.start()-40):m.end()+100])
   if len(contexts)==6:break
  rows.append(dict(url=url,request_id=r['request_id'],title=soup.title.get_text(),contexts=contexts));print(json.dumps(rows[-1],ensure_ascii=False),flush=True)
 (ROOT/'reports/uefa_validation_pages.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=rows,new_requests=c.requests),indent=2),encoding='utf-8')

if __name__=='__main__':main()
