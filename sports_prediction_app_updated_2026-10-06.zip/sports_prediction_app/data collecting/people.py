"""Helpers retained from verified acquisition; obsolete pilot builders removed."""
import unicodedata


def namekey(s):return ''.join(c for c in unicodedata.normalize('NFKD',s).casefold() if c.isalnum())

def minutes(s):
    if not s:return None
    m,sec=map(int,s.split(':'));return m+sec/60
