"""NHL dated profiles: past evidence only, separate from collected-game results."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from build_nba_dated_profiles import months
from build_nhl_temporal_events import franchise
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    facts=[json.loads(b) for b, in db.execute('SELECT body FROM _nhl_player_game_facts')];wanted={p['player_id'] for p in facts}
    assert len(wanted)>100,'Expanded NHL performance facts are required'
    bios={'NHL:'+pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _official_nhl_player_bios') if json.loads(b)['status']=='ok'}
    assert wanted<=set(bios),'Complete player biography acquisition first'
    selected_game_ids={p['game_id'] for p in facts}
    games={gid:json.loads(b) for gid,b in db.execute('SELECT * FROM _nhl_canonical_games') if gid in selected_game_ids}
    roster=collections.defaultdict(list);events=collections.defaultdict(list);career=collections.defaultdict(list);dated=collections.defaultdict(list);seasons=collections.defaultdict(set);full_logs=collections.defaultdict(lambda:True);expected_logs=collections.defaultdict(set);native_names=collections.defaultdict(set)
    for b, in db.execute('SELECT body FROM _official_nhl_schedule'):
        s=json.loads(b)
        for side,key in enumerate(['awayTeam','homeTeam']):native_names[str(s['raw'][key]['id'])].add(s['teams'][side].replace('Montréal','Montreal'))
    for p in facts:roster[p['game_date']].append(p)
    for b, in db.execute('SELECT body FROM _nhl_temporal_events ORDER BY known_date,event_id'):
        e=json.loads(b)
        if e['player_id'] in wanted:events[e['known_date']].append(e)
    for b, in db.execute('SELECT body FROM _nhl_career_season_facts'):
        r=json.loads(b)
        if r['player_id'] not in wanted:continue
        if r['game_type_code']==2:seasons[r['player_id']].add(r['season'])
        if r['season']<20232024:career[r['completed_season_available_date']].append(r)
        else:expected_logs[r['player_id']].add(r['player_id'].split(':')[1]+':'+str(r['season'])+':'+str(r['game_type_code']))
    validation={k:json.loads(b) for k,b in db.execute('SELECT * FROM _nhl_game_log_validation')}
    for pid,keys in expected_logs.items():full_logs[pid]=all(validation.get(k,{}).get('complete',False) for k in keys)
    for key,b in db.execute('SELECT * FROM _official_nhl_player_game_logs'):
        r=json.loads(b);pid='NHL:'+r['official_player_id']
        if pid not in wanted:continue
        full_logs[pid]&=r['status']=='ok' and validation.get(key,{}).get('complete',False)
        if r['status']!='ok':continue
        for n,g in enumerate(r['games']):
            own=g['homeTeam'] if g['homeRoadFlag']=='H' else g['awayTeam'];names=native_names[str(own['id'])]
            assert len(names)==1,('Native NHL team ID must resolve to one official full name',own,names)
            name=next(iter(names))
            dated[g['gameDate']].append(dict(player_id=pid,team_name=name,franchise_id=franchise(name),request_id=r['request_id'],pointer='/gameLog/'+str(n),game_id=str(g['id'])))
    changes=collections.defaultdict(list)
    for r in db.execute("SELECT * FROM _player_performance_periods WHERE league='NHL'"):changes[r['effective_from']].append(dict(r))
    assert changes,'Install NHL collected-game performance intervals first'
    cohorts={r['as_of_date']:dict(r) for r in db.execute("SELECT * FROM _player_score_cohorts WHERE league='NHL'")}
    game_days=collections.defaultdict(list)
    for g in games.values():game_days[(dt.date.fromisoformat(g['date'])-dt.timedelta(days=1)).isoformat()].append(g)
    state={};perf={};aff=[];history_audit=[];issues=[];latest_rosters={};links=[];link_audit=[];rows=[];missing=collections.Counter();count=0
    def person(pid):return state.setdefault(pid,dict(team=None,fid=None,history=[],history_ids=[],tenure=None,n=0,played=0,current_n=0,current_played=0,current_starts=0,current_starts_known=0))
    def display(name,day):
        if franchise(name)=='utah_nhl':return 'Utah Hockey Club' if day<'2025-05-07' else 'Utah Mammoth'
        return name.replace('Montréal','Montreal')
    def history(pid,name,day,source_id,pointer):
        p=person(pid);fid=franchise(name);name=display(name,day)
        if not p['history_ids'] or p['history_ids'][-1]!=fid:p['history_ids'].append(fid);p['history'].append(name)
        elif fid=='utah_nhl':p['history'][-1]=name
        history_audit.append((pid,day,json.dumps(dict(team_name=name,franchise_id=fid,request_id=source_id,pointer=pointer))))
    def affiliation(pid,name,day,rid,pointer,acquire=False):
        p=person(pid);fid=franchise(name) if name else None
        if p['fid']!=fid:p.update(team=display(name,day) if name else None,fid=fid,tenure=day if acquire and name else None,current_n=0,current_played=0,current_starts=0,current_starts_known=0)
        elif name:
            p['team']=display(name,day)
            if acquire and p['tenure'] is None:p['tenure']=day
        if name:history(pid,name,day,rid,pointer)
        aff.append((pid,day,p['team'],rid+':'+pointer))
    def apply_day(day,with_sample):
        # Completed old career seasons support history/experience, not current
        # affiliation or any performance statistic.
        for r in sorted(career[day],key=lambda r:(r['season'],r.get('sequence') or 0,r['game_type_code'])):history(r['player_id'],r['team_name'],day,r['request_id'],r['pointer'])
        for r in sorted(dated[day],key=lambda r:r['game_id']):affiliation(r['player_id'],r['team_name'],day,r['request_id'],r['pointer'])
        groups=collections.defaultdict(set)
        if with_sample:
            for p in sorted(roster[day],key=lambda p:p['game_id']):
                if not p['affiliation_observation_safe']:continue
                pid=p['player_id'];s=person(pid)
                if not p['temporary_team']:affiliation(pid,p['team_name'],day,p['request_id'],p['pointer'])
                # Unknown appearance is not a false appearance or a denominator.
                if p['did_play'] is not None:
                    s['n']+=1;s['played']+=p['did_play']
                    if not p['temporary_team']:
                        s['current_n']+=1;s['current_played']+=p['did_play']
                        if p['did_play'] and p['starter'] is not None:s['current_starts']+=p['starter'];s['current_starts_known']+=1
                program='National' if p['temporary_team'] else 'NHL'
                groups[p['game_id'],franchise(p['team_name']),program].add(pid)
            for (gid,fid,program),ids in groups.items():latest_rosters[fid,program]=dict(game_id=gid,observed_date=day,players=ids)
        per=collections.defaultdict(list)
        for e in events[day]:per[e['player_id']].append(e)
        for pid,es in per.items():
            targets={e['franchise_id'] for e in es if e['kind']=='acquire'}
            if len(targets)>1:
                affiliation(pid,None,day,'AMBIGUOUS','same-day-moves');issues.append(dict(player_id=pid,date=day,reason='Multiple dated acquisitions without verified order',event_ids=[e['event_id'] for e in es]));continue
            for e in es:affiliation(pid,e['team_name'] if e['kind']=='acquire' else None,day,e['request_id'],e['pointer'],e['kind']=='acquire')
        if day=='2025-05-07':
            for pid,p in state.items():
                if p['fid']=='utah_nhl':affiliation(pid,'Utah Mammoth',day,'aa117b46b38a4e69b98b3728f7389012','official-franchise-renaming')
    for day in sorted(set(career)|set(dated)|set(events)):
        if day<start:apply_day(day,False)
    cols=[r[1] for r in db.execute('PRAGMA table_info(player_profiles)')]
    for table,where in [('game_player_profiles',"game_id LIKE 'NHL_%'"),('player_profiles',"league='NHL'")]:
        while True:
            cur=db.execute('DELETE FROM '+table+' WHERE rowid IN (SELECT rowid FROM '+table+' WHERE '+where+' LIMIT 5000)');db.commit()
            if not cur.rowcount:break
    insert='INSERT INTO player_profiles VALUES ('+','.join('?' for _ in cols)+')';first=dt.date.fromisoformat(start);total=(dt.date.fromisoformat(end)-first).days+1;milestone=10
    for i in range(total):
        d=first+dt.timedelta(days=i);day=d.isoformat();apply_day(day,True)
        for p in changes[day]:perf[p['player_id']]=p
        cohort=cohorts.get(day,{})
        for pid,p in state.items():
            b=bios[pid];m=perf.get(pid,{});dob=dt.date.fromisoformat(b['birth_date']) if b['birth_date'] else None;avg=m.get('average_score_per_game');mu=cohort.get('mu');sigma=cohort.get('sigma')
            row=dict(player_id=pid,player_name=b['player_name'],game_type='Hockey',league='NHL',team=p['team'],overall_winrate=m.get('overall_winrate'),average_score_per_game=avg,average_assists_per_game=m.get('average_assists_per_game'),std_score_per_game=m.get('std_score_per_game'),std_assists_per_game=m.get('std_assists_per_game'),age=d.year-dob.year-((d.month,d.day)<(dob.month,dob.day)) if dob else None,weight_kg=b['weight_kg'],height_cm=b['height_cm'],years_played=sum(str(s)[4:]+'-07-01'<=day for s in seasons[pid]),score_z_score=(avg-mu)/sigma if avg is not None and mu is not None and sigma else None,injured_times_till_as_of_date=0,currently_injured_till_as_of_date=0,number_of_teams_served=len(set(p['history_ids'])) if full_logs[pid] and p['history_ids'] else None,participation_rate_current_team=p['current_played']/p['current_n'] if p['current_n'] else None,participation_rate_overall=p['played']/p['n'] if p['n'] else None,starter_percentage_current_team=p['current_starts']/p['current_played'] if p['current_played'] and p['current_starts_known']==p['current_played'] else None,starter_percentage_overall=m.get('starter_percentage_overall'),average_minutes_per_game=m.get('average_minutes_per_game'),std_minutes_per_game=m.get('std_minutes_per_game'),served_team_history=','.join(p['history']) or None,months_serving_current_team=months(p['tenure'],day) if p['tenure'] else None,as_of_date=day)
            rows.append(tuple(row[c] for c in cols));count+=1;missing.update(k for k,v in row.items() if v is None)
        for g in game_days[day]:
            program='National' if any(k in g['season'] for k in ['All-Star','4 Nations']) else 'NHL';eligible=set();proof=[]
            for team in g['teams']:
                fid=franchise(team);r=latest_rosters.get((fid,program))
                if r:
                    eligible.update(pid for pid in r['players'] if pid in state and (program=='National' or state[pid]['fid']==fid));proof.append(dict(team=team,source_game_id=r['game_id'],observed_date=r['observed_date']))
                if program=='NHL':eligible.update(pid for pid,p in state.items() if p['fid']==fid and p['tenure'] and (r is None or p['tenure']>r['observed_date']))
            links.extend((g['game_id'],pid,day) for pid in sorted(eligible));link_audit.append(dict(game_id=g['game_id'],as_of_date=day,profile_links=len(eligible),prior_roster_sources=proof))
        if len(rows)>=5000:db.executemany(insert,rows);db.commit();rows=[]
        if (i+1)*100//total>=milestone:print('NHL DATED PLAYER PROFILES',milestone,'percent;',day,'rows',count,flush=True);milestone+=10
    if rows:db.executemany(insert,rows);db.commit()
    with db:
        db.executemany('INSERT INTO game_player_profiles VALUES (?,?,?)',links)
        db.execute('CREATE TABLE IF NOT EXISTS _nhl_affiliation_daily (player_id TEXT,observed_date TEXT,team_name TEXT,observation_id TEXT,PRIMARY KEY(player_id,observed_date)) STRICT');db.execute('DELETE FROM _nhl_affiliation_daily');db.executemany('INSERT OR REPLACE INTO _nhl_affiliation_daily VALUES (?,?,?,?)',aff)
        db.execute('CREATE TABLE IF NOT EXISTS _nhl_player_history_audit (player_id TEXT,known_date TEXT,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nhl_player_history_audit');db.executemany('INSERT INTO _nhl_player_history_audit VALUES (?,?,?)',history_audit)
        db.execute('CREATE TABLE IF NOT EXISTS _nhl_game_profile_link_audit (game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nhl_game_profile_link_audit');db.executemany('INSERT INTO _nhl_game_profile_link_audit VALUES (?,?)',[(r['game_id'],json.dumps(r)) for r in link_audit])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',profile_rows=count,native_players=len(state),calendar_dates=total,t_minus_one_links=len(links),games_without_prior_rosters=sum(not r['prior_roster_sources'] for r in link_audit),issues=issues,missing={k:dict(count=v,total=count,percentage=round(v*100/count,4)) for k,v in missing.items()},meaning=dict(performance='Only collected completed games through each query date; no statistics from non-sample career logs',participation='Appearances / dated collected roster opportunities; current-team counters reset only on franchise changes',history='Completed older NHL seasons plus dated game appearances and documented NHL moves; current roster never backfilled',experience='Documented completed NHL regular seasons, counted only after July 1 of their ending year',injury='No collected dated NHL injury report defaults to false/zero by user convention; this does not establish health or complete injury history',tenure='Completed months since documented acquisition in current observed stint; first observed game cannot establish exact start',links='Previous collected roster plus subsequent documented acquisitions through t-1; actual future lineup is not used'))
    (ROOT/'reports/nhl_dated_profiles.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['missing','issues','meaning']}));db.close()

if __name__=='__main__':main()
