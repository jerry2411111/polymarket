import io,re
from pypdf import PdfReader
from collect_history_weather import DOC
from history_client import HistoryClient
c=HistoryClient()
for file in ['ghcnh_DOCUMENTATION.pdf','ghcnh-sky-cover-elements.pdf']:
    b,r=c.get(DOC+file,document=True);pdf=PdfReader(io.BytesIO(b));print('DOC',file,r['request_id'])
    for n,page in enumerate(pdf.pages):
        t=re.sub(r'\s+',' ',page.extract_text())
        if any(term in t.lower() for term in ['semicolon','sky_condition','quality code','delimited']):
            print('PAGE',n+1,t[:6200])
