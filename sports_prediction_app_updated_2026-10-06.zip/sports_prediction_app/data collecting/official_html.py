"""Decode league HTML without discarding malformed bytes or altering raw files."""
def decode_html(body):
    # NHL's older HTML declaration can say Windows-1252 while the actual body
    # contains UTF-8 punctuation. Both decoders are strict and lossless here.
    try:return body.decode('utf-8-sig')
    except UnicodeDecodeError:return body.decode('windows-1252')
