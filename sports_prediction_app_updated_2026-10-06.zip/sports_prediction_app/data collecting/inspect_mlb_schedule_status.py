﻿import json,sqlite3
from probe_history import ROOT
from build_history_catalog import DB
db=sqlite3.connect(DB)
for (s,) in db.execute("SELECT metadata_json FROM _request_audit WHERE json_extract(metadata_json,'$.endpoint')='https://statsapi.mlb.com/api/v1/schedule' AND json_extract(metadata_json,'$.parameters.date')='2024-09-26'"):
 r=json.loads(s);d=json.loads((ROOT/r['raw_file']).read_bytes())
 for day in d['dates']:
  for g in day['games']:
   if g['status']['abstractGameState']=='Final' and any('score' not in g['teams'][side] for side in ['away','home']):print(g['gamePk'],g['status'],g['gameType'])
