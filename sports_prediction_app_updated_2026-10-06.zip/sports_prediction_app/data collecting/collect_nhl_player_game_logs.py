"""Dated career affiliation evidence; never import non-sample games as performance."""
import concurrent.futures,datetime as dt,json,re,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _official_nhl_player_game_logs (job_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();done={k for k,b in db.execute('SELECT * FROM _official_nhl_player_game_logs') if json.loads(b)['status'] in ['ok','unavailable']};jobs=set()
    for pid,b in db.execute('SELECT * FROM _official_nhl_career_sources'):
        x=json.loads(b)
        if x['status']!='ok':continue
        for row in x['season_totals']:
            if row.get('leagueAbbrev')=='NHL' and row['season']>=20232024 and row['season']<=20252026 and row.get('gameTypeId') in [2,3] and (row.get('gamesPlayed') or 0)>0:jobs.add((pid,row['season'],row['gameTypeId']))
    todo=sorted(j for j in jobs if ':'.join(map(str,j)) not in done);client=HistoryClient();errors=[];counts=0
    def fetch(job):
        pid,season,kind=job;key=':'.join(map(str,job));rid=None
        try:
            d,r=client.get(f'https://api-web.nhle.com/v2/player/{pid}/game-log/{season}/{kind}');rid=r['request_id'];rows=d.get('gameLog')
            assert d['seasonId']==season and d['gameTypeId']==kind
            if rows is None:return key,dict(status='unavailable',official_player_id=pid,season=season,game_type_code=kind,request_id=rid,games=None,reason='Official API returned season metadata but omitted gameLog; absence is not zero games')
            assert isinstance(rows,list),'Expected dated gameLog array'
            assert len({row['id'] for row in rows})==len(rows),'Duplicate native player/game identity'
            assert all(dt.date.fromisoformat(row['gameDate']) and str(row['id'])[:4]==str(season)[:4] for row in rows)
            return key,dict(status='ok',official_player_id=pid,season=season,game_type_code=kind,request_id=rid,games=rows,meaning='Only dated affiliation and prior career seasons; sample performance uses separate odds-selected official boxscores')
        except Exception as e:return key,dict(status='error',official_player_id=pid,season=season,game_type_code=kind,request_id=rid,error=type(e).__name__+': '+str(e))
    print('NHL DATED CAREER LOGS',len(todo),'pending;',len(jobs),'eligible keys',flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for n,(key,row) in enumerate(pool.map(fetch,todo),1):
            db.execute('INSERT OR REPLACE INTO _official_nhl_player_game_logs VALUES (?,?)',(key,json.dumps(row)));db.commit()
            if row['status']=='error':errors.append(row)
            if n%100==0:print('NHL DATED CAREER LOGS',n,'/',len(todo),'errors',len(errors),flush=True)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),eligible_keys=len(jobs),attempted=len(todo),new_requests=client.requests,errors=errors,total_successful=db.execute("SELECT count(*) FROM _official_nhl_player_game_logs WHERE json_extract(body,'$.status')='ok'").fetchone()[0],scope='Incremental coverage; career-source collection can add further eligible player/seasons on resume')
    (ROOT/'reports/nhl_dated_career_log_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
