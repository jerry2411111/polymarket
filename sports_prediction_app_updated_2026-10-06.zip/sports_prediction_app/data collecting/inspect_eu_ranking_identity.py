import collections,json,sqlite3
from collect_laliga_people import namekey
from build_history_catalog import DB
db=sqlite3.connect(DB);people={p:json.loads(b) for p,b in db.execute('SELECT * FROM _eu_people_registry')};games=collections.defaultdict(list)
for b, in db.execute('SELECT body FROM _eu_player_game_facts'):
 p=json.loads(b);games[p['player_id']].append(p)
seen=set()
for b, in db.execute('SELECT body FROM _eu_ranking_candidate_facts'):
 r=json.loads(b)
 if not r['player_id'] and r['source_player_name'] not in seen:
  seen.add(r['source_player_name']);key=namekey(r['source_player_name']);ps=[p for p in people.values() if key in {namekey(x) for x in p['aliases']} or any(key in namekey(x) or namekey(x) in key for x in p['aliases'] if len(namekey(x))>5)]
  print(r['source_player_name'],json.dumps([dict(pid=p['person_id'],name=p['person_name'],aliases=p['aliases'],teams=sorted({g['team_name'] for g in games[p['person_id']]})) for p in ps],ensure_ascii=False))
pairs=collections.defaultdict(set)
for b, in db.execute('SELECT body FROM _eu_ranking_candidate_facts'):
 r=json.loads(b)
 for club in r['source_club'].split('/'):
  pairs[club].update(r.get('official_club_candidates',[]))
print('club candidates',json.dumps({k:sorted(v) for k,v in pairs.items()},ensure_ascii=False))
for b, in db.execute('SELECT body FROM _eu_people_registry'):
 p=json.loads(b)
 if any(n in p['person_name'] for n in ['Haaland','Mbappé','Mourinho','Flick']):print('CONTRACT PERSON',p['person_id'],p['person_name'])
db.close()
