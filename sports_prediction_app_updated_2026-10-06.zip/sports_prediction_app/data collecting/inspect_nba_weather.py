import collections,json,sqlite3
from build_history_catalog import DB
from collect_history_weather import DOC,STATIONS
from history_client import HistoryClient
from probe_history import ROOT
db=sqlite3.connect(DB);wanted={r[0] for r in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='NBA' UNION SELECT game_id FROM kalshi_pre_match WHERE league='NBA'")}
gs=[json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_games') if i in wanted]
print('Cities',dict(collections.Counter(g.get('city') for g in gs)))
print('Missing station games',[(g['game_id'],g.get('city'),g['location']) for g in gs if g.get('city') not in STATIONS][:20])
c=HistoryClient();b,r=c.get(DOC+'ghcnh-station-list.txt',document=True)
for line in b.decode().splitlines():
    if any(s in line.upper() for s in ['TORONTO','MACAO','MACAU']):print(line)
report=json.loads((ROOT/'reports/nba_bucket_timestamp_correction.json').read_text());validation=json.loads((ROOT/'reports/nba_main_validation.json').read_text())
print('Main validation keys',validation.keys())
if validation['status']=='WORKING':
    report.update(status='RESOLVED_REBUILT_AND_REVALIDATED',validation_report='reports/nba_main_validation.json',resolution='Aggregate observation windows must finish before pre-match target and fit wholly within the in-game break. Raw bucket timestamps remain preserved.')
    (ROOT/'reports/nba_bucket_timestamp_correction.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
