"""Official final scorer PDFs: historical lineups, minutes and venue absent from APIs.

This is the existing official scorer-document route, not the NBA Stats download
API. Failed access is logged and never bypassed. Three dates are checked first.
"""
import argparse,collections,concurrent.futures,io,json,sqlite3,time
from pypdf import PdfReader
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--probe',action='store_true');ap.add_argument('--recovered-only',action='store_true');ap.add_argument('--from-date',default='2023-09-13');ap.add_argument('--through-date',default='2026-09-13');args=ap.parse_args()
 db=sqlite3.connect(DB);gs=sorted([json.loads(r[0]) for r in db.execute('SELECT body FROM _history_games') if json.loads(r[0])['league']=='NBA'],key=lambda g:g['date']);db.close()
 gs=[g for g in gs if args.from_date<=g['date']<=args.through_date]
 if args.recovered_only:
  db=sqlite3.connect(DB);ids={r[0] for r in db.execute('SELECT DISTINCT game_id FROM _nba_recovered_checkpoints')};db.close();gs=[g for g in gs if g['game_id'] in ids]
 if args.probe:gs=[gs[0],gs[len(gs)//2],gs[-1]]
 c=HistoryClient();counts=collections.Counter()
 def task(g):
  day=g['date'].replace('-','');a,b=g['game_id'].split('_')[2:4];url=f'https://statsdmz.nba.com/pdfs/{day}/{day}_{a}{b}_book.pdf'
  try:
   reversed_order=False
   try:b,r=c.get(url,document=True)
   except RuntimeError as exc:
    if 'HTTP failure 404' not in str(exc):raise
    # Older grouped PM markets may list the home team first. Validate the actual
    # official document's named visitor/home teams before assigning either side.
    url=f'https://statsdmz.nba.com/pdfs/{day}/{day}_{b}{a}_book.pdf';b,r=c.get(url,document=True);reversed_order=True
   if not b.startswith(b'%PDF'):raise ValueError('Response is not a PDF')
   t=PdfReader(io.BytesIO(b)).pages[0].extract_text()
   if args.probe:print('EXAMPLE',g['game_id'],t[:6500],flush=True)
   return dict(game_id=g['game_id'],status='ok',request_id=r['request_id'],reversed_order=reversed_order,pages_first_text_chars=len(t))
  except Exception as e:return dict(game_id=g['game_id'],status='error',error=str(e))
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool,(ROOT/'reports/nba_gamebook_acquisition.jsonl').open('a',encoding='utf-8') as f:
  for n,result in enumerate(pool.map(task,gs),1):
   f.write(json.dumps(result)+'\n');f.flush();counts[result['status']]+=1
   if n%100==0 or n==len(gs):print('NBA BOOKS',n,len(gs),dict(counts),flush=True)
   if n>=10 and counts['error']==n:raise RuntimeError('Consistent access failure; stopped instead of retrying the entire league')
if __name__=='__main__':main()
