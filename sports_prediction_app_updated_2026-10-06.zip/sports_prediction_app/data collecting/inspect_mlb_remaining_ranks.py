import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
x=json.loads(db.execute("SELECT body FROM _mlb_ranking_sources WHERE url LIKE '%top-100-mlb-players-for-2026%'").fetchone()[0]);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(x['request_id'],)).fetchone()[0]);s=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
for text in s.find_all(string=re.compile(r'\b(?:81|91)[.)]')):
 if text.parent.name in ['script','style']:continue
 print(str(text.parent)[:1800])
db.close()
