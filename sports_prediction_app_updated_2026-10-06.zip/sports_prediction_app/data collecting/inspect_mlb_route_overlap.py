import json,sqlite3
from build_history_catalog import DB
from history_index import records,payload
rids=json.load(open(__import__('pathlib').Path(__file__).resolve().parents[1]/'reports/mlb_kalshi_metadata_refresh.json'))['routes'];hist={};live={}
for i,route in enumerate(rids[:2]):
 dest=hist if i==0 else live
 for rid in route['request_ids']:
  import pathlib
  db=sqlite3.connect(DB);s=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);db.close()
  for m in payload(s)['markets']:dest[m['ticker']]=m
shared=set(hist)&set(live);fields=['event_ticker','custom_strike','result','settlement_value_dollars','open_time','close_time','settlement_ts'];diff=[(k,[f for f in fields if hist[k].get(f)!=live[k].get(f)]) for k in shared if any(hist[k].get(f)!=live[k].get(f) for f in fields)];print('OVERLAP',len(shared),'KEY FIELD DIFFERENCES',len(diff),diff[:5]);print('ONE MARKET',{k:v for k,v in next(iter(live.values())).items() if k in ['ticker','event_ticker','custom_strike','result','settlement_value_dollars','open_time','close_time','settlement_ts','occurrence_datetime','title','yes_sub_title']})
