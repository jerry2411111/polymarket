"""Inspect bounded official coach and calendar identity structures."""
import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for code,table in [('LAL','laliga'),('BUN','bundesliga'),('SEA','seriea'),('FL1','ligue1'),('UCL','uefa')]:
 row=db.execute("SELECT body FROM _eu_source_manager_game_facts WHERE json_extract(body,'$.competition_code')=? LIMIT 1",(code,)).fetchone()
 if row:print('COACH',code,json.dumps(json.loads(row[0])['raw'],ensure_ascii=False)[:2500])
 c=json.loads(db.execute('SELECT body FROM _official_'+table+'_calendar LIMIT 1').fetchone()[0]);print('CALENDAR',code,'keys',list(c),'pointer',c.get('pointer'),'raw keys',list(c.get('raw',{})))
 if code in ['FL1','SEA']:print('RAW HOME',code,json.dumps(c['raw']['home'],ensure_ascii=False)[:1700])
db.close()
