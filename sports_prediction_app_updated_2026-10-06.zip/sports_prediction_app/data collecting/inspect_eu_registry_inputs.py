"""Bounded biography and dated-fact structure inspection for identity linking."""
import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for table in ['_official_bundesliga_people_sources','_official_laliga_people_sources','_official_seriea_people_sources','_epl_people_biographies','_epl_manager_game_facts','_eu_source_player_game_facts','_eu_source_manager_game_facts']:
 print('TABLE',table,'COLUMNS',[(r[1],r[2]) for r in db.execute('PRAGMA table_info('+table+')')])
 row=json.loads(db.execute('SELECT body FROM '+table+' LIMIT 1').fetchone()[0]);print('KEYS',list(row))
 if 'data' in row:
  d=row['data'];print('DATA',json.dumps({k:v for k,v in d.items() if k not in ['images','photos','socialMedia','socialAccounts','translations','seasons','team']},ensure_ascii=False)[:3500])
 else:print('SAMPLE',json.dumps({k:v for k,v in row.items() if k not in ['raw_player','sources','raw','completed_season_evidence']},ensure_ascii=False)[:1800])
db.close()
