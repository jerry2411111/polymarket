"""Update only acquired NHL candidates with independently sourced city and clocks."""
import datetime as dt,json,sqlite3
from build_history_catalog import DB
from build_nhl_odds import enrich
from history_index import records
from probe_history import ROOT
db=sqlite3.connect(DB,timeout=60);s={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_nhl_schedule')};reports={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_nhl_game_reports')};rs={r['request_id']:r for r in records()};rows=[]
for gid,b in db.execute('SELECT * FROM _nhl_canonical_games'):
 g=json.loads(b)
 if g['official_game_id'] not in reports:continue
 g=enrich(g,reports[g['official_game_id']],s[g['official_game_id']],rs);rows.append((json.dumps(g),gid))
with db:db.executemany('UPDATE _nhl_canonical_games SET body=? WHERE id=?',rows)
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),enriched_games=len(rows),cities=sorted({json.loads(b)['city'] for b,g in rows if json.loads(b).get('city')}),missing_city=sum(not json.loads(b).get('city') for b,g in rows),scope='Internal candidates only. Public main rows require a coherent pair of real price histories.')
(ROOT/'reports/nhl_game_metadata_progress.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
