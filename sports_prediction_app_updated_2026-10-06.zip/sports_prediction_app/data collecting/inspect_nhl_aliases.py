import collections,json,sqlite3
from build_history_catalog import DB,clean
db=sqlite3.connect(DB);seen=collections.defaultdict(set)
for b, in db.execute('SELECT body FROM _official_nhl_schedule'):
 g=json.loads(b)
 for s in ['awayTeam','homeTeam']:
  t=g['raw'][s]
  if any(n in json.dumps(t) for n in ['Utah','Vegas','Montreal','Washington']):seen[(str(t['id']),t.get('placeName',{}).get('default'),t.get('commonName',{}).get('default'),t['abbrev'])].add(g['season'])
print('NATIVE ALIASES',[(k,sorted(v)) for k,v in seen.items()])
print('ISSUES',collections.Counter(tuple(json.loads(b).get('outcomes',[])) for b, in db.execute('SELECT body FROM _nhl_market_matching_audit')).most_common(8))
for native,b in db.execute('SELECT * FROM _official_nhl_game_reports'):
 r=json.loads(b);print('PILOT',native,r['actual_start_utc'],r['break_scores'],r['breaks'],'starters',[(s,sum(p['starter'] is True for p in r['players'] if p['side']==s)) for s in [0,1]])
db.close()
