"""Explain excluded old event structures instead of assuming metadata coverage is complete."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from build_premier_market_candidates import array
db=sqlite3.connect(DB);rows=[]
for code in ['LAL','BUN','SEA','FL1','UCL']:
 counts=collections.Counter();examples=collections.defaultdict(list);accepted={json.loads(b)['event_id'] for b, in db.execute("SELECT body FROM _eu_validated_contracts WHERE competition=? AND provider='polymarket'",(code,))}
 for eid,b in db.execute('SELECT event_id,body FROM _eu_pm_events WHERE event_id IN (SELECT event_id FROM _eu_pm_event_sources WHERE competition=?)',(code,)):
  e=json.loads(b);date=(e.get('startTime') or e.get('endDate') or '')[:10]
  if not date.startswith('2024'):continue
  ms=e.get('markets',[]);kind=('accepted' if eid in accepted else 'not_accepted')+':'+str(len(ms))+':'+','.join(sorted({str(len(array(m.get('outcomes')))) for m in ms}));counts[kind]+=1
  if len(examples[kind])<3:examples[kind].append(dict(event_id=eid,title=e.get('title'),startTime=e.get('startTime'),endDate=e.get('endDate'),markets=[{k:m.get(k) for k in ['id','question','sportsMarketType','outcomes','gameStartTime','closed']} for m in ms[:4]]))
 row=dict(competition=code,counts=dict(counts),examples=dict(examples));rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
(ROOT/'reports/eu_2024_discovery_funnel.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),competitions=rows),indent=2),encoding='utf-8');db.close()
