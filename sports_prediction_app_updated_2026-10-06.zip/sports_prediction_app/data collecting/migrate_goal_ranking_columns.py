"""Add configured publisher flags without changing existing publisher values."""
import datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from temporal_queries import FLAGS
from probe_history import ROOT
db=sqlite3.connect(DB,timeout=60);table='_ranking_flag_results';oldcols=[r[1] for r in db.execute('PRAGMA table_info('+table+')')]
def digest():
 h=hashlib.sha256()
 for row in db.execute('SELECT '+','.join(oldcols)+' FROM '+table+' ORDER BY 1,2,3'):h.update(json.dumps(row,separators=(',',':')).encode())
 return h.hexdigest()
before=digest()
with db:
 for c in FLAGS:
  if c not in oldcols:db.execute('ALTER TABLE '+table+' ADD COLUMN '+c+' INTEGER')
 from index_ranking_flags import refresh
 result=refresh(db);sql=db.execute("SELECT sql FROM sqlite_master WHERE name='player_performance'").fetchone()[0]
 missing=[c for c in FLAGS if 'r.'+c not in sql]
 if missing:
  select,rest=sql.split(' FROM ',1);sql=select+','+','.join('r.'+c for c in missing)+' FROM '+rest;db.execute('DROP VIEW player_performance');db.execute(sql)
 assert before==digest()
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',preserved_previous_publisher_values_sha256=before,cache=result,new_columns=[c for c in FLAGS if c not in oldcols]);(ROOT/'reports/goal_column_migration.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
