"""Install cross-competition facts only for games with published provider odds."""
import collections,datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

def unaffected(db):
 out={}
 for table in ['_player_game_results','_manager_game_results','_team_game_results']:
  h=hashlib.sha256();n=0
  for row in db.execute('SELECT * FROM '+table+" WHERE league<>'EU soccer' ORDER BY game_id,2"):
   h.update((json.dumps(row,separators=(',',':'),ensure_ascii=False)+'\n').encode());n+=1
  out[table]=dict(rows=n,sha256=h.hexdigest())
 return out

def main():
 db=sqlite3.connect(DB,timeout=60)
 for file in ['eu_source_player_facts_validation.json','eu_identity_validation.json','eu_odds_outputs_validation.json','epl_outputs_validation.json']:
  assert json.loads((ROOT/'reports'/file).read_text())['status']=='WORKING',file
 scope=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone();published={gid:json.loads(b) for gid,b in db.execute('SELECT * FROM _eu_game_facts')};cross={pid:cid for pid,cid in db.execute('SELECT source_person_id,person_id FROM _eu_person_crosswalk')};people={pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _eu_people_registry')};clubs={(code,tid):json.loads(b) for code,tid,b in db.execute('SELECT * FROM _eu_team_identity')};players=[];managers=[];teams=[];counts=collections.defaultdict(collections.Counter);outside=[]
 before=unaffected(db)
 for table in ['_epl_player_game_facts','_eu_source_player_game_facts']:
  for b, in db.execute('SELECT body FROM '+table):
   p=json.loads(b);gid=p['game_id']
   if gid not in published:continue
   if not scope[0]<=p['game_date']<=scope[1]:outside.append(dict(game_id=gid,source_person_id=p['player_id'],available_date=p['game_date']));continue
   g=published[gid];native=p['player_id'];pid=cross[native];code=p.get('competition_code','PL');club=clubs[code,p['official_team_id']];assert club['team_name']==g['teams'][p['side']],(gid,club['team_name'],g['teams']);p.update(source_person_id=native,player_id=pid,player_name=people[pid]['person_name'],team_name=club['team_name'],canonical_team_id=club['team_id']);players.append(p);counts[p['competition']]['roster_rows']+=1;counts[p['competition']]['played_rows']+=p['did_play'] is True
 for table in ['_epl_manager_game_facts','_eu_source_manager_game_facts']:
  for b, in db.execute('SELECT body FROM '+table):
   p=json.loads(b);gid=p['game_id']
   if gid not in published or not scope[0]<=p['game_date']<=scope[1]:continue
   g=published[gid];native=p['manager_id'];mid=cross[native];side=p.get('side',g['teams'].index(p['team_name']) if p['team_name'] in g['teams'] else None);assert side in [0,1];p.update(source_person_id=native,manager_id=mid,manager_name=people[mid]['person_name'],team_name=g['teams'][side],side=side,home_away=g.get('home_away','Away;Home').split(';')[side]);managers.append(p);counts[p['competition']]['coach_game_rows']+=1
 availability=collections.defaultdict(set)
 for p in players:availability[p['game_id']].add(p['game_date'])
 assert all(len(days)==1 for days in availability.values());available={gid:next(iter(days)) for gid,days in availability.items()}
 for gid,g in published.items():
  if gid not in available:continue
  day=available[gid];ha=g.get('home_away','Away;Home').split(';')
  for side in [0,1]:teams.append((gid,g['teams'][side],'Soccer','EU soccer',day,ha[side],g['scores'][side],g['scores'][1-side],int(g['scores'][side]>g['scores'][1-side])))
  counts[g['competition']]['games']+=1
 assert len(players)==len({(p['player_id'],p['game_id']) for p in players});assert len(managers)==len({(p['manager_id'],p['game_id']) for p in managers});played=[p for p in players if p['did_play'] is True]
 with db:
  for table,idcol,rows in [('_eu_player_game_facts','player_id',players),('_eu_manager_game_facts','manager_id',managers)]:
   db.execute('CREATE TABLE IF NOT EXISTS '+table+' ('+idcol+' TEXT,game_id TEXT,body TEXT NOT NULL,PRIMARY KEY('+idcol+',game_id)) STRICT');db.execute('DELETE FROM '+table);db.executemany('INSERT INTO '+table+' VALUES (?,?,?)',[(p[idcol],p['game_id'],json.dumps(p)) for p in rows])
  for table in ['_player_game_results','_manager_game_results','_team_game_results']:db.execute('DELETE FROM '+table+" WHERE league='EU soccer'")
  db.executemany('INSERT INTO _player_game_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',[(p['player_id'],p['player_name'],'Soccer','EU soccer',p['team_name'],p['game_id'],p['game_date'],p['score'],p['assists'],p['minutes'],int(p['starter']) if p['starter'] is not None else None,p['win']) for p in played]);db.executemany('INSERT INTO _manager_game_results VALUES (?,?,?,?,?,?,?,?,?,?,?)',[tuple(p[k] for k in ['manager_id','manager_name','game_type','league','team_name','game_id','game_date','home_away','score_for','score_against','win']) for p in managers]);db.executemany('INSERT INTO _team_game_results VALUES (?,?,?,?,?,?,?,?,?)',teams)
 after=unaffected(db);assert before==after,'US-league game facts changed unexpectedly'
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',scope='Collected completed games with published usable odds only; no outside career totals enter performance.',collection_start=scope[0],collection_end=scope[1],counts={k:dict(v) for k,v in counts.items()},canonical_players=len({p['player_id'] for p in players}),canonical_managers=len({p['manager_id'] for p in managers}),played_rows=len(played),roster_rows=len(players),team_rows=len(teams),outside_availability_range=outside,unaffected_US_game_facts=after,missing={k:dict(count=sum(p[k] is None for p in played),total=len(played),percentage=round(sum(p[k] is None for p in played)*100/len(played),4)) for k in ['score','assists','minutes','starter']});(ROOT/'reports/eu_performance_facts_install.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['outside_availability_range','unaffected_US_game_facts','missing']}));db.close()

if __name__=='__main__':main()
