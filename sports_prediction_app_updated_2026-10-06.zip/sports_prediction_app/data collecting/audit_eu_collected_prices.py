"""Check collected raw odds and provisional quote ages; do not publish unfinished rows."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from epl_price_points import Sources,load
from eu_official_games import CONFIG,games
from core import utc
from schema import HOURS
from quote_selection import nearest_pregame

def main():
 db=sqlite3.connect(DB,timeout=60);db.execute('BEGIN');cs={(p,cid):json.loads(b) for p,cid,b in db.execute('SELECT provider,contract_id,body FROM _eu_validated_contracts')};official={code:games(db,code) for code in CONFIG};src=Sources(db);points,conflicts,excluded=load(db,cs,src,['_eu_price_acquisition']);jobs=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_price_acquisition')];finished={(j['provider'],j['contract_id']) for j in jobs if j['status']=='ok'};rows=collections.defaultdict(lambda:dict(contracts=0,empty_contracts=0,raw_points=0,targets=collections.Counter(),missing=collections.Counter(),ages=collections.defaultdict(list),resolutions=collections.Counter()))
 for key in finished:
  if key not in cs:continue
  c=cs[key];g=official[c['competition']][c['official_match_id']];bucket=rows[c['competition']+':'+key[0]+':'+g['date'][:4]];bucket['contracts']+=1;xs=points[key];bucket['empty_contracts']+=not xs;bucket['raw_points']+=len(xs);bucket['resolutions'].update(x['resolution_seconds'] for x in xs);start=utc(g['scheduled_start_utc']).timestamp();opened=utc(c['open']).timestamp();xs=[x for x in xs if x['timestamp']>=opened]
  for h in HOURS:
   target=start-h*3600;x=nearest_pregame(xs,target,start);bucket['targets'][str(h)]+=1
   if x is None:bucket['missing'][str(h)]+=1;continue
   bucket['ages'][str(h)].append((target-x['timestamp'])/3600)
 outrows={}
 for key,row in rows.items():
  ages=row.pop('ages');row['quote_age_hours']={h:dict(observations=len(v),median=sorted(v)[len(v)//2],maximum=max(v)) for h,v in ages.items()};row['missing_percentages']={h:round(row['missing'][h]*100/n,4) for h,n in row['targets'].items()};outrows[key]=row
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING' if not conflicts else 'SCHEMA PROBLEM',scope='Retained prices acquired so far only. Quote ages use scheduled kickoff provisionally; actual clocks and missing-prior recovery still required.',completed_contracts=len(finished),raw_source_hashes=len(src.cache),source_price_conflicts=conflicts,excluded_source_points=excluded,coverage=outrows);(ROOT/'reports/eu_collected_prices_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['coverage','source_price_conflicts']}),flush=True)
 for key,row in sorted(outrows.items()):print(key,'contracts',row['contracts'],'empty',row['empty_contracts'],'pre0 age',row['quote_age_hours'].get('0'),'resolutions',row['resolutions'],flush=True)
 db.close()

if __name__=='__main__':main()
