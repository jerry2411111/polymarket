"""Render catalog in the requested order: SQL structure, fields, missing data."""
import collections
import html
import json


RELATIONSHIPS = [
    ('main', 'polymarket_pre_match / kalshi_pre_match', 'UNION ALL; provider + game_id identifies the provider/game row'),
    ('in_game', 'polymarket_in_game / kalshi_in_game', 'UNION ALL; join main on provider AND game_id'),
    ('polymarket_in_game_checkpoints / kalshi_in_game_checkpoints', 'US provider in_game table', 'One sequence position per row; game_id + checkpoint_index'),
    ('main', '_game_weather_links', 'game_id; weather then joins on city AND date'),
    ('_game_weather_links', 'weather', 'city AND date; one weather row may serve multiple games'),
    ('main', 'game_player_profiles', 'game_id; link contains player_id and the t-1 as_of_date'),
    ('game_player_profiles', 'player_profiles / player_current_team', 'player_id AND as_of_date'),
    ('main', 'game_manager_profiles', 'game_id; link contains manager_id and the t-1 as_of_date'),
    ('game_manager_profiles', 'manager_profiles', 'manager_id AND as_of_date'),
    ('player_profiles', 'player_performance', 'player_id AND league AND as_of_date; performance includes zero-appearance dates with an explicit status'),
    ('manager_profiles', 'manager_performance', 'manager_id AND league AND as_of_date'),
    ('team_history', 'team identity / selected date', 'team_name AND league AND as_of_date; official name/affiliation mapping, not substring matching'),
    ('player_performance', 'internal ranking editions and _ranking_asof_selection', 'player_id AND league; latest eligible publisher edition on or before the selected date, carried forward until superseded'),
]


def table_description(obj):
    """Describe the stored contents, independently of row granularity or coverage."""
    kind, name, scope = obj['kind'], obj['dataset'], obj['scope']
    leagues = {'us': 'NBA, MLB and NHL', 'all': 'NBA, MLB, NHL and EU soccer',
               'nba': 'NBA', 'mlb': 'MLB', 'nhl': 'NHL', 'eu_soccer': 'EU soccer'}[scope]
    provider = 'Polymarket' if 'polymarket' in name else 'Kalshi' if 'kalshi' in name else 'Polymarket and Kalshi'
    if kind == 'pre_match':
        return (f'{provider} pre-match game data: full team names, game date and UTC start time, '
                'sport, league and season; each team\'s odds and implied probabilities at 0, 12, 24, 36 and 48 hours before start; '
                'venue, home/away designations, winner, final scores and game ID.'
                ' league identifies NBA, MLB, NHL, Premier League, La Liga, Bundesliga, Serie A, Ligue 1 or UEFA Champions League. '
                'Draw odds/probabilities apply only when the market explicitly offers a draw.')
    if kind == 'in_game':
        return (f'{provider} in-game data: team names, sport, league, season, checkpoint names and UTC times, '
                'each team\'s odds and implied probabilities, checkpoint scores and game ID.'
                ' Soccer competitions use the same league column as NBA, MLB and NHL. '
                'Draw odds/probabilities apply only when the market explicitly offers a draw.')
    if kind == 'checkpoints':
        return (f'{provider} NBA, MLB and NHL checkpoint data: game ID, team names, sport, league, checkpoint index, '
                'checkpoint name and UTC time, each team\'s odds and implied probability, and checkpoint scores.')
    if kind == 'weather':
        return 'Game-city weather by date: city, local date, relative humidity, weather description, air temperature and wind direction.'
    if kind == 'player_profiles':
        return (f'Dated {leagues} player profiles: player identity, sport, league, team, age, weight, height, seasons played, '
                'win rate, scoring/assist/playing-time averages and standard deviations, scoring z-score, injury indicators, '
                'team history, team-service duration, participation rates and starting-player percentages.')
    if kind == 'player_current_team':
        return (f'{leagues} player-to-team mapping by date: player ID and name, sport, league, recorded team and as-of date. '
                'Filter as_of_date to retrieve the recorded team on the selected historical date; this view projects player_profiles.team as current_team.')
    if kind == 'player_performance':
        return (f'{leagues} player performance by date: player identity and team, games played, win rate, scoring/assist/playing-time '
                'averages and standard deviations, scoring z-score, starting-player percentage, appearance-history status and publisher-specific top-5, top-10, top-20 and top-50 flags. Performance accumulates daily from 2024-01-01 through the query date, without resetting by year or season. Results begin at the first observed game; only zero appearances are labeled insufficient matches.')
    if kind == 'manager_profiles':
        return (f'Dated {leagues} head-coach/manager profiles: manager ID and name, sport, league, current team, '
                'number of teams served, served-team history and overall win rate. Only dated records with a known team are included.')
    if kind == 'manager_performance':
        return (f'{leagues} head-coach/manager performance by date: manager ID and name, sport, league, games managed, '
                'win rate, home and away game counts, and average team scoring margin. Performance accumulates from 2024-01-01 through the query date, without a year or season reset.')
    if kind == 'team_history':
        return (f'{leagues} team performance by date: team name, sport, league, wins as a fraction of games played, '
                'game count, home and away counts, and average signed scoring margin: mean(team score minus opponent score). '
                'Losses contribute negative margins. Filter as_of_date to select a date. Performance accumulates over collected completed games '
                'from 2024-01-01 through that date, without resetting by year or season.')
    if kind == 'player_rankings_quarterly':
        return (f'{leagues} dated player rankings by publisher: player identity, publisher, ranking date, rank, rating, ranking scope, '
                'source age, carry-forward indicator, coverage classification and source URL.')
    if kind == 'game_player_profiles':
        return 'Game-to-player-profile links: game ID, player ID and the profile date on the day before the game.'
    if kind == 'game_manager_profiles':
        return 'Game-to-head-coach/manager-profile links: game ID, manager ID and the profile date on the day before the game.'
    if kind == 'game_weather_links':
        return 'Game-to-weather links: canonical game ID, game city and local game date.'
    raise ValueError(('No table contents description', kind, name))


def cell(x):
    return str('' if x is None else x).replace('|', '\\|').replace('\n', ' ')


def md_table(headers, rows):
    return ['| ' + ' | '.join(headers) + ' |', '|' + '|'.join(['---']*len(headers)) + '|'] + [
        '| ' + ' | '.join(cell(x) for x in row) + ' |' for row in rows]


def render(reports, rows, objects, sources, inventory, now, guide):
    sql_objects = [o for o in objects if o['object_type'].startswith('SQL')]
    exports = [o for o in objects if not o['object_type'].startswith('SQL')]
    grouped = collections.defaultdict(list)
    for r in rows:
        grouped[r['object_type'], r['dataset']].append(r)
    slots = [dict(dataset=o['dataset'], **r) for o in inventory['outputs'] for r in o['checkpoint_missing']]
    intro = (f'Generated {now}. This catalogs {len(sql_objects)} current research SQL interfaces and '
             f'{len(exports)} exported datasets, with {sum(o["columns"] for o in exports)} export fields. '
             'CSV and Parquet are two formats of the same logical dataset.')
    lines = ['# Data catalog', '', intro, '',
        '[Searchable HTML](data_catalog.html) | [Column CSV](data_catalog_columns.csv) | '
        '[SQL-column CSV](data_catalog_sql_columns.csv) | [Missing report CSV](data_catalog_missing.csv)', '',
        '## 1. SQL database structure', '',
        '']
    lines += md_table(['SQL table/view', 'Type', 'Rows', 'Columns', 'Description'], [
        [o['dataset'], o['object_type'], o['rows'], o['columns'], o['description']] for o in sql_objects])
    lines += ['', '### Relationships and join keys', '']
    lines += md_table(['From', 'To', 'Join / relationship'], RELATIONSHIPS)
    lines += ['', '### Export mapping', '', 'These files project the SQL data; row counts must not be added to the SQL counts.', '']
    lines += md_table(['CSV/Parquet dataset', 'Rows', 'Columns', 'Description', 'SQL projection parameters'], [
        [o['dataset'], o['rows'], o['columns'], o['description'], o['query'] + ' ; parameters=' + o['parameters']] for o in exports])
    # Retain carefully qualified query examples and rules after the structure overview.
    lines += ['', '### Date and source conventions', '',
        guide.split('## Structure and time rules', 1)[1].split('## SQL examples', 1)[0], '',
        '### Date-query examples', '', guide.split('## SQL examples', 1)[1], '',
        '## 2. Every column: meaning, unit and source', '',
        'Source IDs in the field tables resolve to the source registry below. The searchable HTML also shows '
        'the actual links and internal record-level trace for each field. A source family does not mean every '
        'row comes from the same URL. Source values, derived values and requested defaults are identified separately.', '']
    for objtype in ['sql', 'export']:
        lines += ['### ' + ('SQL tables and views' if objtype == 'sql' else 'Export file projections'), '']
        for (kind, name), columns in grouped.items():
            if kind != objtype:
                continue
            lines += ['#### ' + name, '', columns[0]['table_description'], '']
            lines += md_table(['#', 'Column', 'Stored type', 'Unit / structure', 'Meaning / derivation', 'Data source', 'Raw field / internal evidence'], [
                [r['position'], r['column_name'], r['physical_type'], r['unit'], r['meaning'] + ' ' + r['derivation'],
                 r['source_names'] + ' [' + ', '.join(r['source_ids']) + ']', r['source_fields'] + ' ' + '; '.join(r['lineage_tables'])] for r in columns])
            lines.append('')
    lines += ['### Source registry', '',
        'Backup sources are acceptable and explicitly labeled. Republished pages keep the attributed original '
        'publisher AND the actual acquired URL. Weather is direct NOAA, with direct official SMHI backup; '
        'agency-derived humidity is distinguished from a direct sensor reading in the weather provenance report.', '']
    for s in sources.values():
        lines += ['#### ' + s['source_id'], '', s['source_name'] + ' — ' + s['acquisition_path'] + '. ' + s['note'], '']
        lines += ['- [' + u + '](' + u + ')' for u in s['urls']]
        lines.append('')
    lines += ['## 3. Missing report: every column and percentage', '',
        'Missing % = 100 × missing cells / rows in the stated table or export. NULL, NaN and empty strings '
        'are missing; zero/false are values. '
        'Games without a draw option are structurally not applicable for draw fields and counted separately. '
        'Daily profile denominators are person-date rows. Repeated SQL views/exports are not independent datasets.', '']
    for objtype in ['sql','export']:
        for (kind,name), columns in grouped.items():
            if kind != objtype:
                continue
            lines += ['### ' + name + ' (' + objtype + ')', '']
            lines += md_table(['Column', 'Missing', 'Total rows', 'Applicable rows', 'Missing %', 'Structural N/A', 'Reason / interpretation'], [
                [r['column_name'], r['missing_count'], r['rows'], r['applicable_rows'], r['missing_pct'], r['structural_not_applicable_count'],
                 r['missing_reason'] if r['missing_count'] else 'No missing cells in this projection.'] for r in columns])
            lines.append('')
    lines += ['### Missing in-game checkpoint values', '',
        'A nonempty sequence can contain null checkpoints. These percentages use positions, not table-cell nullness. '
        'Entirely absent in-game rows are reported separately against main games in '
        '[all-game checkpoint coverage](in_game_checkpoint_coverage_all_games.csv).', '']
    lines += md_table(['Dataset', 'League', 'Checkpoint', 'Column', 'Missing slots', 'Slots', 'Missing %'], [
        [r['dataset'],r['league'],r['checkpoint'],r['column'],r['missing'],r['slots'],r['missing_pct']] for r in slots])
    (reports / 'data_catalog.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    payload = json.dumps(dict(rows=rows, objects=objects, sources=sources, slots=slots, relationships=RELATIONSHIPS),ensure_ascii=False).replace('<','\\u003c')
    page = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sentinent Snake — SQL data catalog</title><style>
body{font:15px/1.55 system-ui,sans-serif;margin:0;background:#f4f6f9;color:#172335}header{background:#183b56;color:white;padding:24px 4%}main{padding:20px 4%;max-width:1500px;margin:auto}h1{margin:0}h2{font-size:24px;margin-top:36px}h3{font-size:18px}a{color:#0c5da8}header a{color:#c4e4ff}input,select,button{font:inherit;padding:8px;border:1px solid #aebcca;border-radius:4px}input{min-width:260px}.controls{display:flex;gap:10px;flex-wrap:wrap;margin:15px 0}article{background:white;border:1px solid #d7dee7;border-radius:7px;margin:12px 0;padding:16px}.muted{color:#566575}.tag{font-size:12px;background:#e8f0f7;padding:3px 7px;border-radius:4px;margin-right:5px}dl{display:grid;grid-template-columns:165px 1fr;gap:8px}dt{font-weight:600}dd{margin:0;overflow-wrap:anywhere}code{font-family:Consolas,monospace;font-size:13px}details{margin:10px 0}summary,button{cursor:pointer}.notice{border-left:4px solid #dba232;padding:12px;background:#fff7e8}.table{overflow:auto;background:white;max-height:650px}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:8px;text-align:left;border:1px solid #dde4eb;vertical-align:top}th{position:sticky;top:0;background:#e8eff5}td{overflow-wrap:anywhere}nav a{margin-right:20px}section{scroll-margin-top:10px}.num{white-space:nowrap}#structure code{white-space:nowrap}input[type=checkbox]{min-width:0}@media(max-width:700px){dl{grid-template-columns:1fr}input{min-width:170px}}</style>
<header><h1>SQL data catalog</h1><p>INTRO</p><nav><a href="#structure">1. Database structure</a><a href="#fields">2. Column dictionary</a><a href="#missing">3. Missing report</a></nav></header><main>
<section id="structure"><h2>1. Full research SQL structure</h2>
<div class="table"><table><thead><tr><th>Table/view (click for columns)</th><th>Type</th><th>Rows</th><th>Columns</th><th>Description</th></tr></thead><tbody id="tables"></tbody></table></div>
<h3>How the tables connect</h3><div class="table"><table><thead><tr><th>From</th><th>To</th><th>Join keys / relationship</th></tr></thead><tbody id="joins"></tbody></table></div>
<details><summary>All EXPORT_COUNT CSV/Parquet exports and their SQL mapping</summary><div class="table"><table><thead><tr><th>Dataset</th><th>Rows</th><th>Columns</th><th>Description</th><th>SQL and parameters</th></tr></thead><tbody id="exports"></tbody></table></div></details>
<p><a href="data_catalog.md">Full Markdown catalog and date-query examples</a> · <a href="data_catalog_validation.json">Catalog checks</a> · <a href="weather_source_verification.md">Weather source verification</a></p>
<pre><code>SELECT * FROM main WHERE date = :query_date AND provider = 'kalshi';
SELECT * FROM team_history WHERE as_of_date = :query_date;
SELECT * FROM player_current_team WHERE as_of_date = :query_date;
SELECT * FROM player_performance WHERE as_of_date = :query_date;</code></pre></section>
<section id="fields"><h2>2. Every column: meaning, unit and data source</h2><p>Pregame lookbacks: 0, 12, 24, 36, 48 hours. Probability is 0–1; odds are 1/p. In-game values are ordered checkpoint sequences. Exact quote times remain in audit tables. Final scores/winners use official sports reports.</p>
<p>Player performance uses all collected completed games from 2024-01-01 through the selected date. Results begin with the first available game, including the first year. Only zero appearances receive <code>performance_status='insufficient matches'</code> and zero performance values; otherwise the status is <code>observed matches</code>. Sample standard deviations require two valid observations.</p>
<p>Date queries include the selected day's completed results; pre-game features use the preceding date. <a href="player_performance_asof_20250801.md">2025-08-01 performance check against collected game history</a>.</p>
<div class="controls"><select id="kind"><option value="sql">SQL interfaces</option><option value="export">Export files</option><option value="">Both</option></select><select id="dataset" aria-label="Dataset"></select><input id="search" placeholder="Search field, meaning or source" aria-label="Search columns"></div><p id="tableDescription"></p><p id="count"></p><div id="cards"></div><button id="more">Show 100 more fields</button>
<details><summary>Source registry: primary, official backup and republished evidence</summary><div id="sources"></div></details></section>
<section id="missing"><h2>3. Missing report: column by column</h2><p>Missing % = missing cells / rows × 100. Zero observations and false flags are not missing. Profile denominators are dated rows, not distinct people. Overlapping exports/views must not be added together.</p>
<p><a href="data_catalog_missing.csv">Download all column missing counts and percentages</a> · <a href="data_catalog_columns.csv">Export dictionary CSV</a> · <a href="data_catalog_sql_columns.csv">SQL dictionary CSV</a></p>
<div class="controls"><select id="missingKind"><option value="sql">SQL interfaces</option><option value="export">Export files</option><option value="">Both</option></select><input id="missingSearch" placeholder="Filter table or column" aria-label="Filter missing data"><label><input type="checkbox" id="onlyMissing"> Only columns with missing values</label></div><p id="missingCount"></p>
<div class="table"><table><thead><tr><th>Table / dataset</th><th>Column</th><th>Missing</th><th>Total rows</th><th>Applicable rows</th><th>Missing %</th><th>Structural N/A</th><th>Meaning of missing</th></tr></thead><tbody id="missingRows"></tbody></table></div>
<h3>Missing values inside in-game checkpoints</h3><p>Nonempty sequences can contain missing positions. Counts below concern retained in-game rows. For games with no in-game rows at all, see <a href="in_game_checkpoint_coverage_all_games.csv">coverage against all main games</a>.</p><div class="table"><table><thead><tr><th>Dataset</th><th>League</th><th>Checkpoint</th><th>Column</th><th>Missing slots</th><th>Slots</th><th>Missing %</th></tr></thead><tbody id="slots"></tbody></table></div></section>
</main><script type="application/json" id="payload">PAYLOAD</script><script>
const data=JSON.parse(document.getElementById('payload').textContent);const el=id=>document.getElementById(id);let limit=100;
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const tr=xs=>'<tr>'+xs.map(x=>'<td>'+esc(x)+'</td>').join('')+'</tr>';const pair=(k,v)=>'<dt>'+esc(k)+'</dt><dd>'+esc(v)+'</dd>';
const sql=data.objects.filter(o=>o.object_type.startsWith('SQL'));
el('tables').innerHTML=sql.map(o=>'<tr><td><a href="#fields" class="tableLink" data-name="'+esc(o.dataset)+'"><code>'+esc(o.dataset)+'</code></a></td>'+[o.object_type,o.rows,o.columns,o.description].map(x=>'<td>'+esc(x)+'</td>').join('')+'</tr>').join('');
el('joins').innerHTML=data.relationships.map(tr).join('');el('exports').innerHTML=data.objects.filter(o=>!o.object_type.startsWith('SQL')).map(o=>tr([o.dataset,o.rows,o.columns,o.description,o.query+'; parameters='+o.parameters])).join('');
function datasets(){const kind=el('kind').value;el('dataset').innerHTML='<option value="">All tables / datasets</option>'+[...new Set(data.rows.filter(r=>!kind||r.object_type===kind).map(r=>r.dataset))].sort().map(x=>'<option>'+esc(x)+'</option>').join('');}
function render(){const q=el('search').value.toLowerCase().split(/\\s+/).filter(Boolean),k=el('kind').value,d=el('dataset').value;const rows=data.rows.filter(r=>(!k||r.object_type===k)&&(!d||r.dataset===d)&&q.every(t=>[r.column_name,r.meaning,r.unit,r.source_names,r.dataset].join(' ').toLowerCase().includes(t)));el('count').textContent=rows.length+' columns match; showing '+Math.min(rows.length,limit)+'. Column positions are zero-based.';
el('tableDescription').textContent=d?(data.objects.find(o=>o.dataset===d)?.description||''):'';
el('cards').innerHTML=rows.slice(0,limit).map(r=>'<article><h3><code>'+esc(r.column_name)+'</code></h3><p class="muted">'+esc(r.dataset)+' · column '+r.position+'</p><span class="tag">'+esc(r.physical_type)+'</span><span class="tag">'+esc(r.value_origin)+'</span><dl>'+pair('Meaning',r.meaning)+pair('Unit / structure',r.unit)+pair('Calculation',r.derivation)+pair('Data source',r.source_names)+pair('Raw source field',r.source_fields)+pair('Date rule',r.temporal_rule)+pair('Limits / defaults',r.limitations)+'</dl><details><summary>Exact source references and SQL trace</summary><dl>'+pair('SQL query',r.sql_query)+pair('Parameters',r.sql_parameters)+pair('Internal evidence',r.lineage_lookup)+pair('Interface note',r.interface_note)+'</dl>'+r.source_ids.map(id=>{const s=data.sources[id];return '<p><b>'+esc(id)+' — '+esc(s.acquisition_path)+'</b><br>'+esc(s.note)+'</p>'+s.urls.map(u=>'<div><a href="'+esc(u)+'" target="_blank" rel="noopener">'+esc(u)+'</a></div>').join('');}).join('')+'</details></article>').join('');el('more').hidden=rows.length<=limit;}
el('sources').innerHTML=Object.values(data.sources).map(s=>'<article><h3>'+esc(s.source_id)+'</h3><p>'+esc(s.source_name)+'</p><p><b>'+esc(s.acquisition_path)+'</b> '+esc(s.note)+'</p>'+s.urls.map(u=>'<div><a href="'+esc(u)+'" target="_blank" rel="noopener">'+esc(u)+'</a></div>').join('')+'</article>').join('');
function missing(){const k=el('missingKind').value,q=el('missingSearch').value.toLowerCase().split(/\\s+/).filter(Boolean),only=el('onlyMissing').checked;const rs=data.rows.filter(r=>(!k||r.object_type===k)&&(!only||r.missing_count>0)&&q.every(t=>(r.dataset+' '+r.column_name).toLowerCase().includes(t)));el('missingCount').textContent=rs.length+' columns';el('missingRows').innerHTML=rs.map(r=>tr([r.dataset,r.column_name,r.missing_count,r.rows,r.applicable_rows,r.missing_pct===null?'N/A':r.missing_pct+'%',r.structural_not_applicable_count,r.missing_count?r.missing_reason:'No missing cells.'])).join('');}
el('slots').innerHTML=data.slots.map(r=>tr([r.dataset,r.league,r.checkpoint,r.column,r.missing,r.slots,r.missing_pct+'%'])).join('');
el('kind').addEventListener('change',()=>{limit=100;datasets();render();});['dataset','search'].forEach(id=>el(id).addEventListener(id==='search'?'input':'change',()=>{limit=100;render();}));el('more').addEventListener('click',()=>{limit+=100;render();});['missingKind','missingSearch','onlyMissing'].forEach(id=>el(id).addEventListener(id==='missingSearch'?'input':'change',missing));document.querySelectorAll('.tableLink').forEach(a=>a.addEventListener('click',()=>{el('kind').value='sql';datasets();el('dataset').value=a.dataset.name;el('search').value='';limit=100;render();}));datasets();render();missing();
</script></html>'''
    page=page.replace('INTRO',html.escape(intro)).replace('EXPORT_COUNT',str(len(exports))).replace('PAYLOAD',payload)
    (reports/'data_catalog.html').write_text(page,encoding='utf-8')
