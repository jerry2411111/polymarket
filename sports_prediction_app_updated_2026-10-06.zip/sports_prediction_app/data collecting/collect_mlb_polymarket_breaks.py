"""Small minute buckets wholly inside recent official MLB break intervals.

Older dated probes are documented separately; their empty responses do not
establish universal absence. No entire minute-level game history is requested.
"""
import collections,concurrent.futures,datetime as dt,json,sqlite3
from build_history_catalog import DB
from core import utc
from history_client import HistoryClient
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);gs={i:json.loads(b) for i,b in db.execute('SELECT * FROM _mlb_canonical_games')};feeds={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_mlb_feeds')}
    floor=dt.datetime.now(dt.UTC).timestamp()-7*86400;jobs=[];older=0
    for b, in db.execute("SELECT body FROM _mlb_market_candidates WHERE json_extract(body,'$.provider')='polymarket'"):
        m=json.loads(b);g=gs[m['game_id']];f=feeds[g['official_game_id']];start=utc(f['actual_first_pitch_utc']).timestamp()
        windows=[(0,start,start+120)]+[(n,utc(x['start_utc']).timestamp(),utc(x['end_utc']).timestamp()) for n,x in enumerate(f['breaks'],1) if x['start_utc'] and x['end_utc']]
        for n,lo,hi in windows:
            if lo<floor:older+=1;continue
            if not 0<hi-lo<=7200:continue
            jobs.append(dict(game_id=g['game_id'],date=g['date'],contract_id=m['contract_id'],checkpoint=n,lo=lo,hi=hi))
    db.execute('CREATE TABLE IF NOT EXISTS _mlb_polymarket_break_acquisition (job_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();c=HistoryClient();counts=collections.Counter();milestone=10
    def fetch(j):
        ids=[]
        try:
            d,r=c.get('https://data-api.polymarket.com/v2/prices-history',dict(token_id=j['contract_id'],start=int(j['lo']),end=int(j['hi'])+1,bucket_seconds=60,limit=10000));ids.append(r['request_id'])
            assert not d.get('pagination',{}).get('next_cursor') and not d.get('pagination',{}).get('has_more')
            for x in d['data']:assert 0<=x['price']<=1
            usable=[x for x in d['data'] if x['resolution_seconds']>0 and j['lo']<=x['timestamp'] and x['timestamp']+x['resolution_seconds']<=j['hi']]
            return dict(**j,status='ok',request_ids=ids,returned=len(d['data']),usable=len(usable),first_usable=min(usable,key=lambda x:x['timestamp']) if usable else None)
        except Exception as e:return dict(**j,status='error',request_ids=ids,error=type(e).__name__+': '+str(e))
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        for n,r in enumerate(pool.map(fetch,jobs),1):
            db.execute('INSERT OR REPLACE INTO _mlb_polymarket_break_acquisition VALUES (?,?)',(r['contract_id']+':'+str(r['checkpoint'])+':'+str(r['lo']),json.dumps(r)));db.commit();counts[r['status']]+=1;counts['usable_windows']+=bool(r.get('usable'));counts['usable_points']+=r.get('usable',0)
            while n*100//len(jobs)>=milestone:print('MLB RECENT POLYMARKET BREAKS',milestone,'percent;',n,'/',len(jobs),dict(counts),flush=True);milestone+=10
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),jobs=len(jobs),results=dict(counts),new_requests=c.requests,earliest_target=min((j['date'] for j in jobs),default=None),latest_target=max((j['date'] for j in jobs),default=None),older_windows_not_expanded=older,note='Recent seven-day acquisition only; older verified probes and coarse retained histories remain available. Older missing breaks are not a claim that every fine-resolution history was exhaustively checked. Settlement-like zero-duration points excluded.')
    (ROOT/'reports/mlb_polymarket_break_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
