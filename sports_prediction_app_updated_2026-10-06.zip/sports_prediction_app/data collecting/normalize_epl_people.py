"""Validate official person IDs, retain constant biometrics and dated club-membership facts."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources
from probe_history import ROOT

def valid_date(value):
    if not isinstance(value,str):return None
    try:return dt.date.fromisoformat(value).isoformat()
    except ValueError:return None

def main():
    db=sqlite3.connect(DB,timeout=60);src=Sources(db);teams={};bio_rows=[];membership_rows=[];issues=[];counts=collections.Counter();examples=[]
    for b, in db.execute('SELECT body FROM _official_epl_calendar'):
        g=json.loads(b)
        for side in ['away','home']:
            t=g[side];assert t['id'] not in teams or teams[t['id']]==t['name'];teams[t['id']]=t['name']
    for key,b in db.execute('SELECT * FROM _official_epl_people_sources'):
        row=json.loads(b);pid=row['official_person_id'];kind=row['kind']
        if row['status']!='ok':issues.append(dict(person_key=key,reason='Source acquisition incomplete',error=row.get('error')))
        if 'biography' not in row['sources']:continue
        for name,s in row['sources'].items():
            raw,r=src.get(s['request_id']);assert raw==s['raw'] and r['endpoint']==s['endpoint'];assert ('/players/'+pid if kind=='player' else '/managers/'+pid) in r['endpoint'];counts['complete_raw_response_equality']+=1
        s=row['sources']['biography'];raw=s['raw'];out=dict(person_key=key,official_person_id=pid,kind=kind,first_collected_date=row['first_collected_date'],birth_date=None,weight_kg=None,height_cm=None,sources={},biography_request_id=s['request_id'])
        if kind=='manager':
            assert isinstance(raw,dict) and str(raw['id'])==pid;out.update(person_name=raw['name'].get('known') or ' '.join(filter(None,[raw['name'].get('first'),raw['name'].get('last')])),birth_date=valid_date(raw.get('dates',{}).get('birth')),raw_current_team=raw.get('currentTeam'),raw_joined_club=valid_date(raw.get('dates',{}).get('joinedClub')),affiliation_warning='Biography affiliation is not used as a historical or current employment interval without dated corroboration');out['sources']['birth_date']='/dates/birth'
        else:
            assert isinstance(raw,list) and all(str(v['id']['playerId'])==pid for v in raw);eligible=[(i,v) for i,v in enumerate(raw) if int(v['id']['seasonId'])<=2026]
            if not eligible:issues.append(dict(person_key=key,reason='No in-scope biography season'));continue
            eligible.sort(key=lambda pair:(-int(pair[1]['id']['seasonId']),str(pair[1]['id']['competitionId'])!='8',str(pair[1]['id']['competitionId']),pair[0]));idx,latest=eligible[0];out['person_name']=latest['name']['display'];birth={valid_date(v.get('dates',{}).get('birth')) for _,v in eligible}-{None}
            if len(birth)==1:out['birth_date']=next(iter(birth));out['sources']['birth_date']='/'+str(next(i for i,v in eligible if v.get('dates',{}).get('birth')==out['birth_date']))+'/dates/birth'
            elif len(birth)>1:
                candidate_birth=valid_date(latest.get('dates',{}).get('birth'));latest_birth={valid_date(v.get('dates',{}).get('birth')) for _,v in eligible if v['id']['seasonId']==latest['id']['seasonId']}-{None};career_source=row['sources'].get('career');career_persons=career_source['raw'].get('person',[]) if career_source and isinstance(career_source['raw'],dict) else []
                corroborated=len(career_persons)==1 and str(career_persons[0].get('opId'))==pid and valid_date(career_persons[0].get('dateOfBirth'))==candidate_birth
                if candidate_birth and latest_birth=={candidate_birth} and corroborated:
                    out['birth_date']=candidate_birth;out['sources']['birth_date']='/'+str(idx)+'/dates/birth';out['birth_date_resolution']=dict(raw_values=sorted(birth),selected=candidate_birth,reason='Latest official biography season agrees with separate official career response; earlier conflicting season values are retained in raw',career_request_id=career_source['request_id'],career_pointer='/person/0/dateOfBirth');counts['birth_conflicts_resolved_by_latest_and_career']+=1
                else:issues.append(dict(person_key=key,reason='Conflicting birth dates',values=sorted(birth)))
            for field,key_out in [('weight','weight_kg'),('height','height_cm')]:
                candidates=[(i,v) for i,v in eligible if isinstance(v.get(field),(int,float)) and v[field]>0]
                if candidates:
                    i,v=candidates[0];same=[m[field] for _,m in candidates if m['id']['seasonId']==v['id']['seasonId'] and m['id']['competitionId']==v['id']['competitionId']]
                    if len(set(same))==1:out[key_out]=v[field];out['sources'][key_out]='/'+str(i)+'/'+field
                    else:issues.append(dict(person_key=key,reason='Conflicting latest biometrics',field=field,values=same))
            career=row['sources'].get('career');persons=career['raw'].get('person',[]) if career and isinstance(career['raw'],dict) else [];experience={}
            if career and (len(persons)!=1 or str(persons[0].get('opId'))!=pid):issues.append(dict(person_key=key,reason='Career response does not establish the requested native person',request_id=career['request_id']));career=None;persons=[]
            if career:counts['career_native_identity']+=1
            for i,m in enumerate(persons[0].get('membership',[]) if persons else []):
                if m.get('contestantType')!='club' or m.get('role')!='player':continue
                start=m.get('startDate');end=m.get('endDate');start=start.removesuffix('Z') if start else None;end=end.removesuffix('Z') if end else None
                if start:assert dt.date.fromisoformat(start).isoformat()==start
                if end:assert dt.date.fromisoformat(end).isoformat()==end
                if start and end and end<start:issues.append(dict(person_key=key,reason='Membership ends before start',pointer='/person/0/membership/'+str(i)));continue
                mid=str(m.get('opContestantId') or m['contestantId']);name=teams.get(mid) or m.get('contestantOptaOfficialName') or m.get('contestantName');assert name
                mem=dict(player_id='EU_PL:'+pid,official_team_id=mid,team_name=name,start_date=start,end_date=end,request_id=career['request_id'],pointer='/person/0/membership/'+str(i),native_membership_id=m['id'],transfer_type=m.get('transferType'),raw_fields={k:v for k,v in m.items() if k!='stat'});membership_rows.append(('EU_PL:'+pid,m['id'],json.dumps(mem)));counts['dated_club_memberships']+=1
                for j,stat in enumerate(m.get('stat',[])):
                    season=stat.get('tournamentCalendarName','')
                    if stat.get('isFriendly')=='no' and len(season)==9 and season[4]=='/' and season[:4].isdigit() and season[5:].isdigit() and stat.get('appearances',0)>0:
                        available=season[5:]+'-07-01'
                        if int(season[5:])==int(season[:4])+1:experience.setdefault(season,dict(available_date=available,request_id=career['request_id'],pointer=f'/person/0/membership/{i}/stat/{j}'))
            out['completed_season_evidence']=experience if career else None;out['history_scope']='Club memberships present in the official career response; career completeness is not established';out['biometrics_policy']='Latest available official season record, preferring Premier League when tied; constant values across query dates by user request'
        if out['birth_date']:dt.date.fromisoformat(out['birth_date'])
        bio_rows.append((key,json.dumps(out)));counts[kind]+=1
        if len(examples)<6:examples.append({k:out.get(k) for k in ['person_key','person_name','birth_date','height_cm','weight_kg']})
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _epl_people_biographies (person_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _epl_people_biographies');db.executemany('INSERT INTO _epl_people_biographies VALUES (?,?)',bio_rows);db.execute('CREATE TABLE IF NOT EXISTS _epl_player_memberships (player_id TEXT,native_membership_id TEXT,body TEXT NOT NULL,PRIMARY KEY(player_id,native_membership_id)) STRICT');db.execute('DELETE FROM _epl_player_memberships');db.executemany('INSERT INTO _epl_player_memberships VALUES (?,?,?)',membership_rows)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING' if issues else 'WORKING',scope='Acquired official person sources only; unacquired people and date-specific profiles require further work',checks=dict(counts),raw_hash_checks=len(src.cache),issues=issues,examples=examples,limits=['Career seasonal performance totals are never inserted into collected-game performance.','Historical membership dates are separate from contract value and term; no salary is inferred.','Birth dates can support date-specific age; latest height and weight are constant properties by user instruction.']);(ROOT/'reports/epl_people_source_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
