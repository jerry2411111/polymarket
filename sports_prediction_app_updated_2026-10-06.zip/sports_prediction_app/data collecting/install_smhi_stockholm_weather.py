"""Publish quality-approved official Stockholm observations without interpolation."""
import bisect,csv,datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from core import utc
from probe_history import ROOT

FIELDS={'1':'temperature_c','6':'humidity_pct','13':'weather_type','3':'wind_direction'}

def main():
    db=sqlite3.connect(DB,timeout=60);wanted={r[0] for r in db.execute('SELECT game_id FROM polymarket_pre_match UNION SELECT game_id FROM kalshi_pre_match')}
    games=[json.loads(b) for gid,b in db.execute('SELECT * FROM _nhl_canonical_games') if gid in wanted and json.loads(b).get('city')=='Stockholm'];targets={}
    for g in games:
        key=g['city'],g['date']
        if key not in targets or utc(g['start'])<utc(targets[key]['start']):targets[key]=g
    assert len(targets)==2,'Review scope before expanding this fallback'
    docs=json.loads((ROOT/'reports/smhi_quality_and_codes.json').read_text());sources=json.loads((ROOT/'reports/smhi_stockholm_archives.json').read_text())['sources'];sources=[s for s in sources if str(s['parameter'])!='6']+[docs['humidity_source']]
    def raw(rid):
        r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];return b
    codes=json.loads(raw(docs['code_documentation']['request_id']));code_names={e['key']:e['value'] for e in codes['entry']};assert code_names[100]=='Inget signifikant väder observerat'
    date_keys={utc(g['start']).date().isoformat() for g in games}|{(utc(g['start'])-dt.timedelta(minutes=90)).date().isoformat() for g in games}
    selected={key:{} for key in targets};audits={key:{} for key in targets}
    for s in sources:
        rows=list(csv.reader(raw(s['request_id']).decode('utf-8-sig').splitlines(),delimiter=';'));assert rows[1][1]==str(s['station_id']) and rows[9][1]=='Tid (UTC)' and rows[9][3]=='Kvalitet'
        assert any('Grön (G) = Kontrollerade och godkända värden.' in ';'.join(x) for x in rows[:25])
        eligible=[]
        for n,row in enumerate(rows):
            if len(row)>=4 and row[0] in date_keys and row[3]=='G' and row[2]:
                stamp=utc(row[0]+'T'+row[1]+'Z').timestamp();eligible.append((stamp,n,row))
        eligible.sort();times=[e[0] for e in eligible];field=FIELDS[str(s['parameter'])]
        for key,g in targets.items():
            target=utc(g['start']).timestamp();i=bisect.bisect_right(times,target)-1;hit=eligible[i] if i>=0 and target-times[i]<=5400 else None
            if not hit:selected[key][field]=None;audits[key][field]=dict(request_id=s['request_id'],station_id=s['station_id'],reason='No quality G value within 90 minutes before game');continue
            stamp,n,row=hit;value=float(row[2])
            if field=='humidity_pct':assert 0<=value<=100
            if field=='wind_direction':assert 0<=value<=360;value=format(value,'g')+' degrees'
            if field=='weather_type':
                assert int(value)==value and int(value) in code_names
                # Preserve other officially described weather, rather than
                # forcing no-significant-weather into a "sunny" category.
                value='No significant weather observed' if int(value)==100 else code_names[int(value)]
            selected[key][field]=value;audits[key][field]=dict(request_id=s['request_id'],station_id=s['station_id'],csv_row_index=n,raw=row,observation_timestamp_utc=utc(stamp).isoformat(),quality='G',normalized_value=value)
    output=[]
    with db:
        for key,g in targets.items():
            row=dict(city=key[0],date=key[1],humidity_pct=selected[key]['humidity_pct'],weather_type=selected[key]['weather_type'],temperature_c=selected[key]['temperature_c'],wind_direction=selected[key]['wind_direction']);output.append(row)
            db.execute('INSERT OR REPLACE INTO weather VALUES (?,?,?,?,?,?)',tuple(row.values()));db.execute("DELETE FROM _weather_observation_audit WHERE json_extract(body,'$.city')=? AND json_extract(body,'$.date')=?",key)
            audit=dict(provider='SMHI',city=key[0],date=key[1],game_id=g['game_id'],earliest_game_timestamp_utc=g['start'],field_sources=audits[key],code_documentation_request_id=docs['code_documentation']['request_id'],normalized=row,station_selection='Official Stockholm-Bromma airport for temperature, wind and present weather; official Stockholm-Observatoriekullen A for humidity because airport humidity is only quality Y. All selected values quality G. Outdoor observations, not indoor arena conditions.')
            db.execute('INSERT INTO _weather_observation_audit VALUES (?)',(json.dumps(audit),))
        db.executemany('INSERT OR REPLACE INTO _game_weather_links VALUES (?,?,?)',[(g['game_id'],g['city'],g['date']) for g in games])
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',games_linked=len(games),city_dates=len(targets),rows=output,field_sources=[dict(city=k[0],date=k[1],fields=v) for k,v in audits.items()],documentation=docs['code_documentation']['url'])
    (ROOT/'reports/smhi_stockholm_weather.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='field_sources'}));db.close()

if __name__=='__main__':main()
