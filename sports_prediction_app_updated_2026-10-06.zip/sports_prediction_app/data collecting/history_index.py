"""Read acquired metadata lazily; preserve IDs and source request pointers."""
import json
from probe_history import ROOT
from request_audit import all_records

def records(root=ROOT):
 yield from all_records(root)

def payload(r,root=ROOT):return json.loads((root/r['raw_file']).read_bytes())

def index(root=ROOT):
 out={k:{} for k in ['milestones','teams','players','kalshi_markets','polymarket_events']}
 for r in records(root):
  if r.get('status')!=200:continue
  u=r['endpoint'];kind=None
  if u.endswith('/milestones'):kind='milestones';key='milestones'
  elif u.endswith('/structured_targets'):kind='targets';key='structured_targets'
  elif u.startswith('https://external-api.kalshi.com/') and (u.endswith('/markets')):kind='kalshi_markets';key='markets'
  elif u=='https://gamma-api.polymarket.com/events':kind='polymarket_events';key=None
  elif u=='https://gamma-api.polymarket.com/events/keyset':kind='polymarket_events';key='events'
  if kind is None:continue
  d=payload(r,root);items=d[key] if key else d
  for n,x in enumerate(items):
   dest=kind
   if kind=='targets':
    if x['details'].get('league') not in {'NBA','MLB','NHL'}:continue
    dest='teams' if x['type'].endswith('_team') else 'players' if x['type'].endswith('_player') else None
    if dest is None:continue
   uid=x.get('id') or x.get('ticker')
   out[dest][uid]=(x,r['request_id'],('/'+key if key else '')+'/'+str(n))
 return out

def real_milestones(data):
 for mid,(m,rid,ptr) in data['milestones'].items():
  if m['details'].get('league') not in {'NBA','MLB','NHL'}:continue
  tickers=m.get('primary_event_tickers',[])
  if any(t.startswith('SIM') for t in tickers):continue
  if not ('2023-09-13'<=m['start_date'][:10]<='2026-09-14'):continue
  yield mid,m,rid,ptr
