"""Refresh small league weather files from the validated common city/date table."""
import collections,csv,datetime as dt,json,sqlite3
import pyarrow as pa
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row;assert json.loads((ROOT/'reports/weather_cleanup.json').read_text())['status']=='WORKING';cols=['city','date','humidity_pct','weather_type','temperature_c','wind_direction'];schema=pa.schema([(c,pa.float64() if c in ['humidity_pct','temperature_c'] else pa.string()) for c in cols]);outputs=[]
for league in ['NBA','MLB','NHL']:
 rows=[dict(r) for r in db.execute('SELECT w.* FROM weather w WHERE EXISTS(SELECT 1 FROM _game_weather_links l JOIN main m ON m.game_id=l.game_id WHERE l.city=w.city AND l.date=w.date AND m.league=?) ORDER BY w.city,w.date',(league,))];dest=ROOT/'data/result'/league.lower();old=pq.read_table(dest/'weather.parquet').to_pylist() if (dest/'weather.parquet').exists() else [];oldmap={(r['city'],r['date']):r for r in old};changed=sum(oldmap.get((r['city'],r['date']))!=r for r in rows)
 with (dest/'weather.csv').open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)
 pq.write_table(pa.Table.from_pylist(rows,schema=schema),dest/'weather.parquet',compression='zstd');assert pq.read_table(dest/'weather.parquet').to_pylist()==rows
 with (dest/'weather.csv').open(newline='',encoding='utf-8') as f:actual=list(csv.DictReader(f))
 assert actual==[{k:'' if v is None else str(v) for k,v in r.items()} for r in rows]
 out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),table='weather',league=league,rows=len(rows),columns=6,changed_or_new_rows=changed,csv=(dest/'weather.csv').relative_to(ROOT).as_posix(),parquet=(dest/'weather.parquet').relative_to(ROOT).as_posix(),missing={c:dict(count=sum(r[c] is None for r in rows),total=len(rows),percentage=round(sum(r[c] is None for r in rows)*100/len(rows),4)) for c in cols});outputs.append(out);(ROOT/'reports'/(league.lower()+'_weather_export.json')).write_text(json.dumps(out,indent=2),encoding='utf-8');print(league,'weather',len(rows),'changed/new',changed,flush=True)
(ROOT/'reports/league_weather_exports_validation.json').write_text(json.dumps(dict(status='WORKING',generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),outputs=outputs),indent=2),encoding='utf-8');db.close()
