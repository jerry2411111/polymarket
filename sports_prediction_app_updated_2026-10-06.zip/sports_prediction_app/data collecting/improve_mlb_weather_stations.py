"""Try nearby official hourly stations for cities with major weather gaps."""
import datetime as dt,io,json,sqlite3,statistics,types
import pyarrow.parquet as pq
from build_history_catalog import DB
from collect_history_weather import DOC,STATIONS
from core import utc
from history_client import HistoryClient
from history_index import records
from prepare_mlb_weather_stations import distance
from probe_history import ROOT
from weather_values import value,weather_type,weather_codes

def main():
    db=sqlite3.connect(DB,timeout=60);bad={r[0] for r in db.execute("""SELECT city FROM weather w WHERE EXISTS(SELECT 1 FROM _game_weather_links l WHERE l.city=w.city AND l.date=w.date AND l.game_id LIKE 'MLB_%') GROUP BY city HAVING sum(temperature_c IS NULL)>count(*)*.2 OR sum(weather_type IS NULL)>count(*)*.7 OR sum(wind_direction IS NULL)>count(*)*.7""")};targets={}
    feeds={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_mlb_feeds')}
    for b, in db.execute('SELECT body FROM _mlb_canonical_games'):
        g=json.loads(b);v=feeds[g['official_game_id']]['venue'];loc=v.get('location',{});xy=loc.get('defaultCoordinates',{})
        if loc.get('city') in bad and xy.get('latitude') is not None:targets.setdefault((loc['city'],g['date'][:4]),dict(coordinates=[xy['latitude'],xy['longitude']],source_game_id=g['game_id'],source_request_id=feeds[g['official_game_id']]['request_id']))
    old={(city,year):(station,json.loads(b)) for city,year,station,b in db.execute('SELECT * FROM _weather_city_stations')};c=HistoryClient();raw,dr=c.get(DOC+'ghcnh-station-list.txt',document=True);stations={}
    for line in raw.decode().splitlines():
        parts=line.split(maxsplit=4)
        if len(parts)<5:continue
        try:lat,lon=float(parts[1]),float(parts[2])
        except ValueError:continue
        if abs(lat)<=90 and abs(lon)<=180:stations[parts[0]]=(lat,lon,line)
    codes=weather_codes(types.SimpleNamespace(root=ROOT,records=list(records(ROOT))));memo={};results=[]
    for (city,year),proof in sorted(targets.items()):
        current=old.get((city,year),(STATIONS.get(city),{}))[0];ranked=sorted((distance(proof['coordinates'],xy[:2]),s) for s,xy in stations.items());checks=[];chosen=None
        for km,s in ranked[:35]:
            if km>50:break
            if city=='Toronto' and not s.startswith('CAN'):continue
            if s==current:continue
            key=s,year
            if key not in memo:
                try:
                    b,r=c.get(f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/parquet/GHCNh_{s}_{year}.parquet',document=True);pf=pq.ParquetFile(io.BytesIO(b));cols=[k for k in pf.schema_arrow.names if k in ['DATE','STATION'] or k.startswith(('temperature','relative_humidity','wind_direction','wind_speed','sky_','pres_wx_'))];xs=pf.read(columns=cols).to_pylist();ts=sorted({utc(str(x['DATE']) if '+' in str(x['DATE']) or str(x['DATE']).endswith('Z') else str(x['DATE'])+'Z').timestamp() for x in xs});gaps=[b-a for a,b in zip(ts,ts[1:])];sample=xs[::max(1,len(xs)//1000)];fractions={k:sum(value(x,rawkey) is not None for x in sample)/len(sample) if sample else 0 for k,rawkey in [('temperature','temperature'),('humidity','relative_humidity'),('wind','wind_direction')]};fractions['weather']=sum(weather_type(x,codes) is not None for x in sample)/len(sample) if sample else 0
                    median=statistics.median(gaps) if gaps else None;memo[key]=dict(station=s,request_id=r['request_id'],rows=len(xs),first_timestamp=utc(ts[0]).isoformat() if ts else None,last_timestamp=utc(ts[-1]).isoformat() if ts else None,median_interval_seconds=median,field_fractions=fractions,usable=bool(median and median<=3600 and min(fractions.values())>=.5))
                except Exception as e:memo[key]=dict(station=s,error=type(e).__name__+': '+str(e),usable=False)
            check=dict(memo[key],distance_km=km);checks.append(check)
            if check['usable']:chosen=check;break
        if chosen:
            body=dict(**proof,city=city,year=year,station=chosen['station'],distance_km=chosen['distance_km'],previous_station=current,station_directory_request_id=dr['request_id'],station_directory_row=stations[chosen['station']][2],archive_request_id=chosen['request_id'],alternatives=checks,method='Nearest alternative within 50 km with median observation interval <=1 hour and >=50% nonmissing temperature, humidity, weather type and wind in a deterministic archive sample; Toronto alternatives stay in Canada; exact game-time values verified separately')
            db.execute('INSERT OR REPLACE INTO _weather_city_stations VALUES (?,?,?,?)',(city,year,chosen['station'],json.dumps(body)));db.commit()
        results.append(dict(city=city,year=year,previous_station=current,selected=chosen,checked=checks));print('MLB WEATHER ALTERNATIVE',city,year,chosen['station'] if chosen else 'No qualifying alternative',flush=True)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),cities=sorted(bad),results=results,new_requests=c.requests)
    (ROOT/'reports/mlb_weather_station_improvements.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(dict(city_years=len(results),improved=sum(x['selected'] is not None for x in results),new_requests=c.requests)));db.close()

if __name__=='__main__':main()
