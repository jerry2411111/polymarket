"""Official archive pages: recover native season IDs, or results where API requires a key."""
import datetime as dt,json,re
from bs4 import BeautifulSoup
from urllib.parse import urlsplit
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def main():
    c=HistoryClient();rows=[]
    urls=[f'https://www.bundesliga.com/en/bundesliga/matchday/{season}/{day}' for season,day in [('2023-2024',17),('2024-2025',1),('2025-2026',1)]]+[f'https://www.laliga.com/en-GB/laliga-easports/results/{season}/gameweek-{day}' for season,day in [('2023-24',19),('2024-25',1),('2025-26',1)]]
    for url in urls:
        HOSTS.add(urlsplit(url).hostname)
        try:
            b,r=c.get(url,document=True);soup=BeautifulSoup(b,'html.parser');row=dict(url=url,request_id=r['request_id'],title=soup.title.get_text() if soup.title else None)
            if 'bundesliga.com' in url:
                states=[json.loads(t.get_text()) for t in soup.find_all('script',type='application/json')];found=[]
                for state in states:
                    for key,value in state.items():
                        if key.startswith('_getDataFromFirebase-') and '/matches' in key:found.append(dict(state_key=key,rows=len(value),example=value[0] if isinstance(value,list) and value else None))
                row['match_sources']=found
            else:
                state=json.loads(soup.find('script',id='__NEXT_DATA__').get_text());p=state['props']['pageProps'];row.update(season=p.get('season'),gameweek=p.get('gameweek'),matches=len(p.get('matches',[])),example=p.get('matches',[None])[0])
            rows.append(row);print(json.dumps(row,ensure_ascii=False)[:3200],flush=True)
        except Exception as e:rows.append(dict(url=url,error=str(e)));print('ARCHIVE PAGE ERROR',url,str(e),flush=True)
    (ROOT/'reports/eu_soccer_archive_pages.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),new_requests=c.requests,sources=rows),indent=2),encoding='utf-8')

if __name__=='__main__':main()
