$taskRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).ProviderPath
$taskRawRoot = (Resolve-Path -LiteralPath (Join-Path $taskRoot 'data\raw\responses')).ProviderPath
if (-not $taskRawRoot.StartsWith($taskRoot + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Raw directory is outside the task workspace' }
$taskCopies = @(
    @{ orphan = '3cb82d85227e482ba826a0b9907876be'; retained = 'c29fe31f901e4cf1bb8c4ee182b0ead7'; sha256 = '48f95fa1fbd68fcc35ed6d2fd91d2b17181b63463a3fc278e40f0b34e6cb5e92' },
    @{ orphan = 'bcc3c28cae6240fa98838b16cf02cdcd'; retained = 'e3305f64a1484170a3e3c8603f81ea65'; sha256 = 'a11a14121dea6ddd1ac446300cdc8bed07f9f7d20edb045c5f20b395ab71b61c' },
    @{ orphan = 'c84b3f19ce4541f1bed3976eccc50792'; retained = 'e7580bc27c2c4aa48dea8240e8d264de'; sha256 = 'df5af7692a5a61e5a9dca98c5e3ca5524e19311365367ae5773467b3de236960' }
)
$taskVerified = @()
foreach ($taskCopy in $taskCopies) {
    $taskOrphan = Join-Path $taskRawRoot ($taskCopy.orphan + '.json')
    if (-not (Test-Path -LiteralPath $taskOrphan)) { continue }
    $taskOrphan = (Resolve-Path -LiteralPath $taskOrphan).ProviderPath
    $taskRetained = (Resolve-Path -LiteralPath (Join-Path $taskRawRoot ($taskCopy.retained + '.json'))).ProviderPath
    foreach ($taskPath in @($taskOrphan, $taskRetained)) {
        if (-not $taskPath.StartsWith($taskRawRoot + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected path outside raw directory' }
        if ((Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskCopy.sha256) { throw 'Raw response hash changed' }
    }
    $taskVerified += @{ removed_path = $taskOrphan; retained_path = $taskRetained; retained_request_id = $taskCopy.retained; sha256 = $taskCopy.sha256; reason = 'Unreferenced old copy; byte-identical independently logged response retained. The missing original request parameters were not reconstructed or claimed.' }
}
@{ checked_at_utc = [DateTime]::UtcNow.ToString('o'); records = $taskVerified } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskRoot 'reports\verified_orphan_cleanup.json') -Encoding UTF8
foreach ($taskCopy in $taskVerified) { Remove-Item -LiteralPath $taskCopy.removed_path }
Write-Output ('Removed verified redundant raw copies: ' + $taskVerified.Count)
