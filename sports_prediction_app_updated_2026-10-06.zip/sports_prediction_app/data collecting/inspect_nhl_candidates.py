import collections,json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
issues=[json.loads(b) for b, in db.execute('SELECT body FROM _nhl_market_matching_audit')]
print('OUTCOME LABEL ISSUES',collections.Counter(tuple(x.get('outcomes',[])) for x in issues if 'labels' in x['reason']).most_common())
print('OTHER ISSUES',json.dumps([x for x in issues if 'labels' not in x['reason']],indent=2))
games=[json.loads(b) for b, in db.execute('SELECT body FROM _official_nhl_schedule')]
print('CALENDAR SEASONS/TYPES',collections.Counter((g['season'],g['game_type_code']) for g in games))
print('SPECIAL GAME EXAMPLES',json.dumps([g for g in games if g['game_type_code'] not in [1,2,3]][:8],indent=2))
print('TABLES',[n for n, in db.execute("SELECT name FROM sqlite_master WHERE name LIKE '%nhl%' OR name LIKE '%checkpoint%'")])
db.close()
