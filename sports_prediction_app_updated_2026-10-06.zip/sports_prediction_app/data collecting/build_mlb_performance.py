"""Official MLB player/team facts for the games actually present in odds tables.

Suspended games contribute final statistics only on their completion date.
Pitching runs allowed are never substituted for the player's runs scored.
"""
import collections,datetime as dt,json,re,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);wanted={x[0] for x in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='MLB' UNION SELECT game_id FROM kalshi_pre_match WHERE league='MLB'")}
    gs={i:json.loads(b) for i,b in db.execute('SELECT * FROM _mlb_canonical_games') if i in wanted};assert set(gs)==wanted,'Publish canonical MLB odds before rebuilding performance'
    feeds={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_mlb_feeds')};source_rows=[];team_rows=[];bio={};issues=[]
    for gid,g in gs.items():
        f=feeds[g['official_game_id']];assert f['scores']==g['scores'];day=f['completion_local_date']
        assert day and day>=g['date'],'Missing or reversed official completion date'
        if day>'2026-09-14':issues.append(dict(game_id=gid,reason='Game completed after collection cutoff; final performance withheld'));continue
        wins=[int(g['winner']==team) for team in g['teams']]
        for side in range(2):team_rows.append((gid,g['teams'][side],'Baseball','MLB',day,g['home_away'].split(';')[side],g['scores'][side],g['scores'][1-side],wins[side]))
        for source in f['players']:
            p=dict(source,game_id=gid,game_type='Baseball',league='MLB',game_date=day,original_game_date=g['date'],win=wins[source['side']],temporary_team='All-Star' in g['season'],spans_multiple_local_dates=f['spans_multiple_local_dates'],affiliation_observation_safe=not f['spans_multiple_local_dates'])
            source_rows.append(p);b=source.get('biography') or {};pid=source['player_id']
            # MLB's hydrated current biography is used only for constant facts.
            # Historical affiliation comes from the dated boxscore, never b.team.
            h=re.fullmatch(r"(\d+)['′]\s*(\d+)[\"″]?",b.get('height') or '')
            entry=dict(player_id=pid,player_name=source['player_name'],birth_date=b.get('birthDate'),weight_kg=b['weight']*0.45359237 if isinstance(b.get('weight'),(int,float)) else None,height_cm=(int(h[1])*12+int(h[2]))*2.54 if h else None,mlb_debut_date=b.get('mlbDebutDate'),request_id=source['request_id'],pointer='/gameData/players/ID'+source['official_player_id'])
            if pid not in bio or sum(v is not None for v in entry.values())>sum(v is not None for v in bio[pid].values()):bio[pid]=entry
    keys=collections.Counter((p['player_id'],p['game_id']) for p in source_rows)
    ambiguous=[k for k,n in keys.items() if n>1]
    assert not ambiguous,('Same person on both teams in one game requires explicit role aggregation',ambiguous)
    played=[p for p in source_rows if p['did_play']]
    bygame=collections.defaultdict(list)
    for p in played:bygame[p['game_id'],p['side']].append(p)
    for gid,g in gs.items():
        for side in range(2):
            ps=bygame[gid,side]
            if ps:assert sum(p['score'] for p in ps if p['score'] is not None)==g['scores'][side]
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _mlb_player_game_facts (player_id TEXT,game_id TEXT,body TEXT NOT NULL,PRIMARY KEY(player_id,game_id)) STRICT');db.execute('DELETE FROM _mlb_player_game_facts');db.executemany('INSERT INTO _mlb_player_game_facts VALUES (?,?,?)',[(p['player_id'],p['game_id'],json.dumps(p)) for p in source_rows])
        db.execute("DELETE FROM _player_game_results WHERE league='MLB'");db.executemany('INSERT INTO _player_game_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',[(p['player_id'],p['player_name'],'Baseball','MLB',p['team_name'],p['game_id'],p['game_date'],p['score'],p['assists'],p['minutes'],p['starter'],p['win']) for p in played])
        db.execute("DELETE FROM _team_game_results WHERE league='MLB'");db.executemany('INSERT INTO _team_game_results VALUES (?,?,?,?,?,?,?,?,?)',team_rows)
        db.execute('CREATE TABLE IF NOT EXISTS _mlb_player_bio_constants (player_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _mlb_player_bio_constants');db.executemany('INSERT INTO _mlb_player_bio_constants VALUES (?,?)',[(pid,json.dumps(b)) for pid,b in bio.items()])
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',selected_games=len(gs),roster_rows=len(source_rows),played_rows=len(played),native_players=len(bio),suspended_or_overnight_games=sum(f['spans_multiple_local_dates'] for f in feeds.values() if any(g['official_game_id']==f['official_game_id'] for g in gs.values())),issues=issues,missing={k:dict(count=sum(p[k] is None for p in played),total=len(played),percentage=round(sum(p[k] is None for p in played)*100/len(played),4) if played else None) for k in ['score','assists','minutes','starter']},meaning=dict(score='Individual batting runs scored, not runs batted in or pitcher runs allowed; absent batting value remains null',assists='Official fielding assists, not a basketball-equivalent measure',minutes='Not provided as individual playing duration by this official feed; null',performance_date='Local final-completion date from the last official play; suspended game final totals never enter earlier profiles',biography='Constant DOB, height, weight only; hydrated current team and currentAge are not historical evidence'))
    db.close();(ROOT/'reports/mlb_performance_facts.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))

if __name__=='__main__':main()
