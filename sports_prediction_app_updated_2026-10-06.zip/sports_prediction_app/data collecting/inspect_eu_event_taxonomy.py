"""Bounded event field inspection for player-statistic derivation."""
import collections,json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for code,table in [('LAL','laliga'),('BUN','bundesliga'),('UCL','uefa')]:
 counts=collections.Counter();examples={};goal_keys=collections.Counter()
 for b, in db.execute('SELECT body FROM _official_'+table+'_game_reports'):
  r=json.loads(b);s=r['sources'];ev=s['match_page']['data']['events'] if code=='LAL' else s['match']['data']['liveBlogEntries'].values() if code=='BUN' else s['events']['data']
  for e in ev:
   kind=e['match_event_kind']['name'] if code=='LAL' else e['entryType'] if code=='BUN' else e['type'];counts[kind]+=1
   if 'goal' in kind.lower() and isinstance(e.get('detail'),dict):goal_keys.update(e['detail'].keys())
   if kind in examples or not any(x in kind.lower() for x in ['goal','sub','assist','red','retir','tactical','injury']):continue
   out={}
   for k,v in e.items():
    if k in ['primaryActor','secondaryActor']:out[k]=dict(person_id=v.get('person',{}).get('id'),name=v.get('person',{}).get('internationalName'),team_id=v.get('team',{}).get('id'))
    elif k not in ['fieldPosition','fspFieldPosition']:out[k]=v
   examples[kind]=out
 print(code,'COUNTS',dict(counts));print('GOAL_DETAIL_KEYS',dict(goal_keys))
 for k,v in examples.items():print('EXAMPLE',k,json.dumps(v,ensure_ascii=False)[:1800])
db.close()
