"""Acquire constant personal properties for native IDs in collected NHL games.

Current roster/career totals never establish a past affiliation or performance.
The bio text is preserved for subsequent dated-source review, not auto-imputed.
"""
import collections,concurrent.futures,datetime as dt,json,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT
db=sqlite3.connect(DB,timeout=60);names=collections.defaultdict(set)
for b, in db.execute('SELECT body FROM _official_nhl_game_reports'):
 for p in json.loads(b)['players']:
  if p.get('player_name'):names[p['official_player_id']].add(p['player_name'])
db.execute('CREATE TABLE IF NOT EXISTS _official_nhl_player_bios (official_player_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();done={p for p,b in db.execute('SELECT * FROM _official_nhl_player_bios') if json.loads(b)['status']=='ok'};todo=sorted(set(names)-done);c=HistoryClient();errors=[];count=0
def fetch(pid):
 try:
  d,r=c.get('https://api-web.nhle.com/v2/player/'+pid+'/bio');v=d.get('vitals',{});bio=d.get('bio',{});name=' '.join(bio.get(k,{}).get('default','') for k in ['firstName','lastName']).strip();assert name
  if v.get('birthDate'):dt.date.fromisoformat(v['birthDate'])
  h=v.get('heightInches');w=v.get('weightPounds');assert h is None or 30<=h<=100;assert w is None or 50<=w<=500
  return pid,dict(status='ok',official_player_id=pid,player_name=name,observed_game_names=sorted(names[pid]),birth_date=v.get('birthDate'),height_cm=h*2.54 if h is not None else None,weight_kg=w*0.45359237 if w is not None else None,raw_height_inches=h,raw_weight_pounds=w,request_id=r['request_id'],birth_pointer='/vitals/birthDate',height_pointer='/vitals/heightInches',weight_pointer='/vitals/weightPounds',raw_bio=bio,raw_current_team=d.get('currentTeam'),meaning='Constant personal properties only; age recomputed from birth date. Current team and biography text require dated evidence before historical use.')
 except Exception as e:return pid,dict(status='error',official_player_id=pid,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for pid,row in pool.map(fetch,todo):
  db.execute('INSERT OR REPLACE INTO _official_nhl_player_bios VALUES (?,?)',(pid,json.dumps(row)));db.commit();count+=1
  if row['status']=='error':errors.append(row)
  if count%100==0:print('NHL BIOGRAPHIES',count,'/',len(todo),'errors',len(errors),flush=True)
out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),currently_observed_native_players=len(names),attempted=len(todo),new_requests=c.requests,errors=errors,total_cached_biographies=db.execute("SELECT count(*) FROM _official_nhl_player_bios WHERE json_extract(body,'$.status')='ok'").fetchone()[0],scope='Incremental biography collection; game-report acquisition is still expanding the player population.')
(ROOT/'reports/nhl_player_biography_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
