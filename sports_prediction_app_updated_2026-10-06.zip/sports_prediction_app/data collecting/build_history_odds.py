"""Build compact provider-separated odds tables at the configured lookback hours.

Pre-match selections use the closest previous observation at or before
the target, restricted to strictly before game start. In-game uses the first
available observation inside a verified break or opening interval.
No interpolation, complement-price inference, or zero filling is performed.
"""
import argparse,bisect,collections,csv,datetime as dt,itertools,json,sqlite3
import pyarrow as pa
import pyarrow.parquet as pq
from probe_history import ROOT
from build_history_catalog import DB,ORIGINAL
from history_index import records,payload
from core import utc,odd
from schema import PRE_COLUMNS,INGAME_COLUMNS,HOURS,CHECKPOINTS,aligned
from quote_selection import nearest_pregame,available_at,inside_window
from reconcile_nba_games import apply as apply_nba_mapping,select_families

def export(name,rows,columns,db=None):
 from league_odds import installed,export_provider
 parts=name.split('/')
 if parts[-1] in ['pre_match','in_game'] and parts[-2] in ['polymarket','kalshi']:
  own=db is None
  connection=sqlite3.connect(DB) if own else db
  try:
   if installed(connection):
    export_provider(connection,parts[-2],parts[-1]);return
  finally:
   if own:connection.close()
 path=ROOT/'data/result'/name;path.parent.mkdir(parents=True,exist_ok=True)
 numeric={k for k in columns if '_pre_' in k};ints={'teamA_final_score','teamB_final_score'}
 schema=pa.schema([pa.field(k,pa.float64() if k in numeric else pa.int64() if k in ints else pa.string()) for k in columns])
 pq.write_table(pa.Table.from_pylist(rows,schema=schema),path.with_suffix('.parquet'),compression='zstd')
 with path.with_suffix('.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=columns);w.writeheader();w.writerows(rows)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--rebuild-prices',action='store_true');args=ap.parse_args()
 db=sqlite3.connect(DB);games={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _history_games')};cs=[json.loads(r[0]) for r in db.execute('SELECT body FROM _history_contracts')];contracts={(c['provider'],c['contract_id']):c for c in cs}
 official={r[0]:json.loads(r[1]) for r in db.execute('SELECT game_id,body FROM _official_game_facts')}
 clocks={r[0]:json.loads(r[1]) for r in db.execute('SELECT game_id,body FROM _official_nba_clocks')}
 cps=collections.defaultdict(list)
 for r in db.execute('SELECT body FROM _history_checkpoints'):
  x=json.loads(r[0]);cps[x['game_id']].append(x)
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='_nba_recovered_checkpoints'").fetchone():
  recovered=collections.defaultdict(list)
  for (body,) in db.execute('SELECT body FROM _nba_recovered_checkpoints'):
   x=json.loads(body);recovered[x['game_id']].append(x)
  for gid,rows in recovered.items():
   if not cps[gid]:cps[gid]=rows
 games,cs,cps,clocks=apply_nba_mapping(db,games,cs,cps,clocks)
 contracts={(c['provider'],c['contract_id']):c for c in cs}
 points={};conflicts=[];duplicates=0;seen_requests=set();reused=0;parsed_requests=[]
 if not args.rebuild_prices and db.execute("SELECT 1 FROM sqlite_master WHERE name='_history_price_points'").fetchone():
  for (body,) in db.execute('SELECT body FROM _history_price_points'):
   x=json.loads(body);points[x['provider'],x['contract_id'],x['timestamp'],x['kind'],x['resolution_seconds']]=x;seen_requests.add(x['request_id'])
  reused=len(points)
  if db.execute("SELECT 1 FROM sqlite_master WHERE name='_history_price_conflicts'").fetchone():conflicts=[json.loads(b) for (b,) in db.execute('SELECT body FROM _history_price_conflicts')]
  if db.execute("SELECT 1 FROM sqlite_master WHERE name='_history_price_requests'").fetchone():seen_requests.update(r[0] for r in db.execute('SELECT request_id FROM _history_price_requests'))
 print('ODDS cached observations',reused,flush=True)
 for root in dict.fromkeys([ORIGINAL,ROOT]):
  for r in records(root):
   if r.get('status')!=200:continue
   u=r['endpoint'];p=r.get('parameters',{})
   if not u.endswith(('/candlesticks','/prices-history')):continue
   if '/markets/candlesticks' in u:continue # Exploratory batch response is audited separately.
   if r['request_id'] in seen_requests:continue
   d=payload(r,root)
   if u.endswith('/candlesticks'):
    provider='kalshi';cid=d.get('ticker');items=d.get('candlesticks',[]);suffix='close' if '/historical/' in u else 'close_dollars';kind='candle';resolution=int(p.get('period_interval',60))*60
   else:
    provider='polymarket';cid=p.get('token_id') or p.get('market');kind='v2' if '/v2/' in u else 'clob';items=d.get('data' if kind=='v2' else 'history',[])
   if (provider,cid) not in contracts:continue
   parsed_requests.append(r['request_id'])
   if len(parsed_requests)%500==0:print('ODDS new raw responses',len(parsed_requests),flush=True)
   for n,v in enumerate(items):
    if kind=='candle':
     price=v.get('yes_bid',{}).get(suffix);ask=v.get('yes_ask',{}).get(suffix);ts=v['end_period_ts'];ptr=f'/candlesticks/{n}/yes_bid/{suffix}'
     if price is not None and ask is not None and float(price)>float(ask):conflicts.append(dict(request_id=r['request_id'],pointer=ptr,reason='Crossed source bid/ask'));continue
    else:
     tk,pk=('timestamp','price') if kind=='v2' else ('t','p');price=v.get(pk);ts=v[tk];ptr=f'/{"data" if kind=="v2" else "history"}/{n}/{pk}';resolution=v.get('resolution_seconds',int(p.get('fidelity',1))*60)
    if price is None:continue
    price=float(price)
    if not 0<=price<=1:raise ValueError('Probability scale error')
    key=(provider,cid,ts,kind,resolution);x=dict(provider=provider,contract_id=cid,timestamp=ts,price=price,implied_probability=price,resolution_seconds=resolution,request_id=r['request_id'],pointer=ptr,kind=kind,retrieved_at_utc=r['retrieved_at_utc'])
    if key in points:
     duplicates+=1
     if points[key]['price']!=price:
      conflicts.append(dict(provider=provider,contract_id=cid,timestamp=ts,previous=points[key],replacement=x,reason='Changed source observation; newest retrieved response selected'))
     if points[key]['retrieved_at_utc']>=x['retrieved_at_utc']:continue
    points[key]=x
 grouped=collections.defaultdict(list)
 for x in points.values():grouped[x['provider'],x['contract_id']].append(x)
 for xs in grouped.values():xs.sort(key=lambda x:(x['timestamp'],-x['resolution_seconds'],x['retrieved_at_utc']))
 cs=select_families(db,games,cs,grouped,clocks,cps)
 audits=[];eligibility=[];output={p:{'pre_match':[],'in_game':[]} for p in ['polymarket','kalshi']};bygame=collections.defaultdict(list)
 for c in cs:bygame[c['game_id'],c['provider']].append(c)
 def select(c,g,label,target,max_age,window_end=None):
  xs=grouped[c['provider'],c['contract_id']]
  if label.startswith('pre_'):
   start=int(utc(g['start']).timestamp());x=nearest_pregame(xs,target,start)
  else:
   eligible=[x for x in xs if inside_window(x,target,window_end)]
   x=min(eligible,key=lambda x:(available_at(x),x['timestamp'],x['resolution_seconds'])) if eligible else None
  age=(target-x['timestamp']) if x else None;opened=utc(c['open']);not_open=target is not None and opened is not None and target<int(opened.timestamp());reason=None
  if target is None or (label.startswith('ingame_') and window_end is None):reason='Verified break/opening time interval unavailable'
  elif x and opened is not None and x['timestamp']<int(opened.timestamp()):reason='Source observation precedes recorded market open'
  elif not x:reason='No source observation at or before target' if label.startswith('pre_') else 'No available quote during the verified break/opening interval'
  elif max_age is not None and age>max_age:reason='Latest source observation is too old'
  if label.startswith('ingame_') and x and label!='ingame_0' and x['timestamp']<int(utc(g['start']).timestamp()):reason='Latest observation precedes game start'
  audits.append(dict(provider=c['provider'],game_id=g['game_id'],side=c['side'],target=label,target_timestamp_utc=utc(target).isoformat() if target is not None else None,window_end_utc=utc(window_end).isoformat() if window_end is not None else None,source_timestamp_utc=utc(x['timestamp']).isoformat() if x else None,source_age_seconds=age,source_offset_seconds=-age if age is not None else None,target_precedes_market_open=not_open,selection_method='closest previous; timestamp <= target and < game start' if label.startswith('pre_') else 'first available quote inside verified break/opening interval',source_resolution_seconds=x['resolution_seconds'] if x else None,source_price=x['price'] if x else None,normalized_price=x['price'] if x and not reason else None,request_id=x['request_id'] if x else None,pointer=x['pointer'] if x else None,reason=reason))
  audits[-1].update(source_available_at_utc=utc(available_at(x)).isoformat() if x else None,source_is_aggregate_bucket_start=bool(x and x['kind']=='v2' and x['resolution_seconds']>0),source_kind=x['kind'] if x else None,selection_method='latest fully completed observation window at or before target; raw ticks strictly before game start' if label.startswith('pre_') else 'first fully contained observation inside verified break/opening interval')
  return x['price'] if x and not reason else None
 for (gid,provider),ms in sorted(bygame.items()):
  g=dict(games[gid]);fact=official.get(gid);clock=clocks.get(gid)
  if not fact or g.get('validation_status','').startswith('QUARANTINED'):
   eligibility.append(dict(provider=provider,game_id=gid,date=g['date'],league=g['league'],competition_type=fact.get('competition_type') if fact else None,is_training=fact.get('is_training') if fact else None,usable_odds=None,included=False,classification_request_id=fact.get('classification_request_id') if fact else None,reason='Official game identity or final result remains unverified'))
   continue
  if clock:g['start']=clock['official_start_utc']
  start=int(utc(g['start']).timestamp());row={k:None for k in PRE_COLUMNS};row.update(match='/'.join(g['teams']),date=g['date'],timestamp=g['start'],game_type=g['game_type'],league=g['league'],season=fact.get('season') if fact else None,location=fact.get('location') if fact else None,home_away=fact.get('home_away') if fact else None,final=fact['winner'] if fact else None,teamA_final_score=fact['scores'][0] if fact else None,teamB_final_score=fact['scores'][1] if fact else None,game_id=gid)
  for m in ms:
   side='AB'[m['side']]
   for h in HOURS:
    price=select(m,g,'pre_'+str(h),start-h*3600-(1 if h==0 else 0),None);row[f'team{side}_pre_{h}_p']=price;row[f'team{side}_pre_{h}_odd']=odd(price)
  cp=sorted(cps[gid],key=lambda x:x['ordinal']);names=CHECKPOINTS[g['game_type']]
  if len(cp)!=len(names):raise ValueError('Checkpoint structure lost')
  cp=[dict(x,teamA_score=None,teamB_score=None,window_end=None) for x in cp]
  for i,x in enumerate(cp):
   if fact:x['teamA_score'],x['teamB_score']=fact['break_scores'][i]
   if clock:
    if i==0:x['timestamp']=utc(start+60).isoformat();x['window_end']=utc(start+120).isoformat()
    else:x['timestamp']=clock['breaks'][i-1]['start_utc'];x['window_end']=clock['breaks'][i-1]['end_utc']
   elif i==0 and x['timestamp']:x['window_end']=(utc(x['timestamp'])+dt.timedelta(seconds=120)).isoformat()
  ing=dict(match=row['match'],game_type=g['game_type'],league=g['league'],season=row['season'],timestamp=aligned([x['timestamp'] for x in cp]),checkpoint=';'.join(names),teamA_score=aligned([x['teamA_score'] for x in cp]),teamB_score=aligned([x['teamB_score'] for x in cp]),game_id=gid)
  for m in ms:
   vals=[select(m,g,'ingame_'+str(i),int(utc(x['timestamp']).timestamp()) if x['timestamp'] else None,None,int(utc(x['window_end']).timestamp()) if x['window_end'] else None) for i,x in enumerate(cp)];side='AB'[m['side']];ing[f'team{side}_ingame_p']=aligned(vals);ing[f'team{side}_ingame_odd']=aligned([odd(p) for p in vals])
  # Latest scope: every competition is eligible, but every included game must
  # have a real observation usable in at least one requested output slot.
  available=any(row[k] is not None for k in PRE_COLUMNS if k.endswith('_p')) or any(v!='null' for k in ['teamA_ingame_p','teamB_ingame_p'] for v in ing.get(k,'null').split(';'))
  training=fact.get('is_training') if fact else None
  # The latest all-competitions-with-odds clarification concerns NBA. Retain
  # the earlier other-league policy, excluding training games without quotes.
  included=available if g['league']=='NBA' or training is True else True
  eligibility.append(dict(provider=provider,game_id=gid,date=g['date'],league=g['league'],competition_type=fact.get('competition_type') if fact else None,is_training=training,usable_odds=available,included=included,classification_request_id=fact.get('classification_request_id') if fact else None,reason='No usable odds acquired yet' if not included else None))
  if included:
   output[provider]['pre_match'].append(row);output[provider]['in_game'].append(ing)
 # Existing immutable contract/source histories are retained; replace only the
 # requested provider output tables and their derived observation audit.
 for view in ['main','in_game']:db.execute(f'DROP VIEW IF EXISTS {view}')
 for provider,tables in output.items():
  for kind,rows in tables.items():
   name='_source_'+provider+'_us_'+kind;columns=PRE_COLUMNS if kind=='pre_match' else INGAME_COLUMNS;db.execute(f'DROP TABLE IF EXISTS {name}')
   defs=[f'"{k}" '+('REAL' if '_pre_' in k else 'INTEGER' if k in {'teamA_final_score','teamB_final_score'} else 'TEXT')+(' PRIMARY KEY' if k=='game_id' else '') for k in columns]
   db.execute(f'CREATE TABLE {name} ('+','.join(defs)+') STRICT');db.executemany(f'INSERT INTO {name} VALUES ('+','.join('?' for _ in columns)+')',[tuple(r[k] for k in columns) for r in rows]);export(provider+'/'+kind,rows,columns,db=db)
 from eu_schema import refresh_main_views
 refresh_main_views(db)
 db.commit()
 for name,rows in [('_history_price_points',list(points.values())),('_history_selections',audits),('_history_price_conflicts',conflicts),('_game_odds_eligibility',eligibility)]:
  tmp=name+'_building';db.execute(f'DROP TABLE IF EXISTS {tmp}');db.execute(f'CREATE TABLE {tmp} (body TEXT NOT NULL)');db.commit();it=iter(rows)
  while batch:=list(itertools.islice(it,2000)):
   db.executemany(f'INSERT INTO {tmp} VALUES (?)',[(json.dumps(r),) for r in batch]);db.commit()
  db.execute(f'DROP TABLE IF EXISTS {name}');db.execute(f'ALTER TABLE {tmp} RENAME TO {name}');db.commit()
 # Mark responses consumed only after their normalized points are durable.
 db.execute('CREATE TABLE IF NOT EXISTS _history_price_requests (request_id TEXT PRIMARY KEY) STRICT')
 if args.rebuild_prices:db.execute('DELETE FROM _history_price_requests')
 db.executemany('INSERT OR IGNORE INTO _history_price_requests VALUES (?)',[(rid,) for rid in seen_requests.union(parsed_requests)]);db.commit()
 db.commit();db.close()
 summary=dict(hours=HOURS,pre_columns=len(PRE_COLUMNS),in_game_columns=len(INGAME_COLUMNS),pre_selection='Closest previous observation at or before the target, strictly before game start; actual timestamp retained',in_game_selection='First quote inside verified break interval; opening sample within first two minutes where timing exists',final_and_break_score_source='Official NBA/MLB/NHL reports only',observations=len(points),reused_observations=reused,newly_parsed_responses=len(parsed_requests),duplicate_observations_in_this_update=duplicates,source_discrepancies=len(conflicts),providers={p:{kind:len(rows) for kind,rows in tables.items()} for p,tables in output.items()},selection_reasons=dict(collections.Counter(a['reason'] or 'Source value selected exactly' for a in audits)))
 (ROOT/'reports/history_odds.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary,indent=2))
 training=[e for e in eligibility if e['is_training'] is True and e['usable_odds'] is not None]
 (ROOT/'reports/training_game_filter.json').write_text(json.dumps(dict(rule='Exclude training games without usable odds from each provider output',classified_training_game_provider_pairs=len(training),kept=sum(e['included'] for e in training),excluded=sum(not e['included'] for e in training),records=training),indent=2),encoding='utf-8')

if __name__=='__main__':main()
