"""Export validated support tables as CSV/Parquet; SQLite retains as-of logic."""
import argparse,csv,datetime as dt,json,sqlite3
import pyarrow as pa
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT

def export(db,name,sql):
    if name=='player_performance':
        from temporal_queries import FLAGS,PLAYER_OUTPUT
        from ranking_policy import active_flags
        sql=sql.replace('SELECT *','SELECT '+','.join(PLAYER_OUTPUT+active_flags(db,'NBA',FLAGS)),1)
    dest=ROOT/'data/result/nba';dest.mkdir(exist_ok=True)
    cursor=db.execute(sql);cols=[x[0] for x in cursor.description];n=0;writer=None
    types={r[1]:r[2] for r in db.execute('PRAGMA table_info('+name+')')}
    if name in ['player_performance','manager_performance']:
        text_cols={'player_id','player_name','manager_id','manager_name','game_type','league','team','as_of_date','performance_status'}
        integer_cols={'games_played','home_times','away_times'}
        types={c:'TEXT' if c in text_cols else 'INTEGER' if c in integer_cols or '_top_' in c else 'REAL' for c in cols}
    schema=pa.schema([(c,pa.int64() if types.get(c)=='INTEGER' else pa.float64() if types.get(c)=='REAL' else pa.string()) for c in cols])
    with (dest/(name+'.csv')).open('w',newline='',encoding='utf-8') as f:
        csvwriter=csv.writer(f);csvwriter.writerow(cols)
        with pq.ParquetWriter(dest/(name+'.parquet'),schema,compression='zstd') as writer:
            while batch:=cursor.fetchmany(10000):
                csvwriter.writerows(batch);writer.write_table(pa.Table.from_pylist([dict(zip(cols,r)) for r in batch],schema=schema));n+=len(batch)
    return dict(table=name,rows=n,columns=len(cols),csv='data/result/nba/'+name+'.csv',parquet='data/result/nba/'+name+'.parquet')

def main():
    p=argparse.ArgumentParser();p.add_argument('--people-only',action='store_true');p.add_argument('--performance-only',action='store_true');a=p.parse_args()
    report=json.loads((ROOT/'reports/nba_profiles_validation.json').read_text());assert report['status']=='WORKING'
    db=sqlite3.connect(DB,timeout=60);outputs=[]
    if a.performance_only:
        for name in ['player_performance','manager_performance']:
            outputs.append(export(db,name,"SELECT * FROM "+name+" WHERE league='NBA'"));print('EXPORTED',outputs[-1],flush=True)
        (ROOT/'reports/nba_performance_exports.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),outputs=outputs),indent=2),encoding='utf-8');db.close();return
    for name in ['player_profiles','player_current_team']:
        outputs.append(export(db,name,"SELECT * FROM "+name+" WHERE league='NBA' ORDER BY as_of_date,player_id"));print('EXPORTED',outputs[-1],flush=True)
    if not a.people_only:
        for name in ['team_history','manager_profiles']:
            outputs.append(export(db,name,"SELECT * FROM "+name+" WHERE league='NBA'"));print('EXPORTED',outputs[-1],flush=True)
    (ROOT/'reports/nba_support_exports.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),outputs=outputs),indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
