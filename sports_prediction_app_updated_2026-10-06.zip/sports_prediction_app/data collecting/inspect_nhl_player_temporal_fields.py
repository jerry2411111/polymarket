import json
from history_client import HistoryClient
c=HistoryClient()
for pid in ['8471214','8478402','8480012']:
 d,r=c.get('https://api-web.nhle.com/v2/player/'+pid+'/player-stats');print('CAREER SEASONS',pid,json.dumps(d.get('seasonTotals',[]))[:2800])
 b,br=c.get('https://api-web.nhle.com/v2/player/'+pid+'/bio');print('BIO',pid,b.get('vitals'),{k:v for k,v in b.get('bio',{}).items() if k!='about'},'CURRENT TEAM',b.get('currentTeam'))
