"""Date-batched official NOAA archive checks for verified European game cities."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,io,json,math,re,sqlite3,unicodedata
import pyarrow.parquet as pq
from bs4 import BeautifulSoup
from build_history_catalog import DB
from collect_history_weather import DOC
from history_client import HistoryClient
from eu_official_games import CONFIG,games
from probe_history import ROOT

def norm(s):return re.sub(r'[^A-Z0-9]+',' ',unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().upper()).strip()
def distance(a,b,c,d):
 x,y,z,w=map(math.radians,[a,b,c,d]);return 6371*2*math.asin(min(1,math.sqrt(math.sin((z-x)/2)**2+math.cos(x)*math.cos(z)*math.sin((w-y)/2)**2)))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--retry-unavailable',action='store_true');ap.add_argument('--through-percent',type=int,default=100);a=ap.parse_args();db=sqlite3.connect(DB,timeout=60);c=HistoryClient()
 for name in ['ghcnh_DOCUMENTATION.pdf','ghcnh-present-weather-elements.pdf','ghcnh-sky-cover-elements.pdf']:c.get(DOC+name,document=True)
 raw,dr=c.get(DOC+'ghcnh-station-list.txt',document=True);stations={}
 for line in raw.decode().splitlines():
  try:sid=line[:11];lat,lon=map(float,line[11:].split()[:2]);country=line[-2:];name=line[38:];assert -90<=lat<=90 and -180<=lon<=180
  except (ValueError,AssertionError):continue
  stations[sid]=dict(station_id=sid,latitude=lat,longitude=lon,country=country,line=line,name=name)
 inventories={}
 for year in ['2024','2025','2026']:
  url=f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/parquet/'
  try:
   b,r=c.get(url,document=True);files={a.get('href','') for a in BeautifulSoup(b,'html.parser').find_all('a')};available={m[1] for f in files if (m:=re.search(r'GHCNh_(.{11})_'+year+r'\.parquet$',f))};assert available,'Official archive directory has no recognizable files';inventories[year]=dict(stations=available,request_id=r['request_id'])
  except Exception as e:inventories[year]=dict(stations=None,request_id=None,error=str(e));print('NOAA DIRECTORY',year,'unavailable; checking individual official files',flush=True)
 official={g['game_id']:g for code in CONFIG for g in games(db,code).values()};targets=collections.defaultdict(list)
 for gid,b in db.execute('SELECT * FROM _eu_game_weather_locations'):
  if gid not in official:continue
  r=json.loads(b);r['date']=official[gid]['date'];targets[r['city'],r['date'][:4]].append(r)
 with db:db.execute('CREATE TABLE IF NOT EXISTS _eu_weather_station_jobs (city TEXT,year TEXT,body TEXT NOT NULL,PRIMARY KEY(city,year)) STRICT')
 done={(city,year):json.loads(b) for city,year,b in db.execute('SELECT * FROM _eu_weather_station_jobs')};by_month=collections.defaultdict(list)
 for key,rs in sorted(targets.items()):by_month[min(r['date'] for r in rs)[:7]].append((key,rs))
 if a.pilot:
  pilot=[]
  for country in ['DE','ES','IT','FR','MC']:
   opts=[(key,rs) for key,rs in targets.items() if rs[0]['country']==country]
   if opts:pilot.append(min(opts,key=lambda pair:(min(r['date'] for r in pair[1]),pair[0])))
  by_month=collections.defaultdict(list)
  for key,rs in pilot:by_month[min(r['date'] for r in rs)[:7]].append((key,rs))
 def fetch(job):
  (city,year),rs=job
  if (city,year) in done and not (a.retry_unavailable and done[city,year]['status']!='ok'):
   row=dict(done[city,year],official_city_evidence=rs);return city,year,row
  countries={r['country'] for r in rs};assert len(countries)==1;country=next(iter(countries));geo=[r for r in rs if r.get('latitude') is not None and r.get('longitude') is not None];candidates=[];aliases={norm(r['raw_city']) for r in rs};aliases|={norm(r['raw_city'].translate(str.maketrans({'ä':'ae','ö':'oe','ü':'ue','Ä':'Ae','Ö':'Oe','Ü':'Ue','ß':'ss'}))) for r in rs}
  for sid,s in stations.items():
   if inventories[year]['stations'] is not None and sid not in inventories[year]['stations']:continue
   if geo:
    dist=max(distance(r['latitude'],r['longitude'],s['latitude'],s['longitude']) for r in geo)
    if dist<=60:candidates.append((dist,sid,'Official venue coordinates; station within 60 km of all collected venues in this city'))
   elif s['country']==country and any(re.search(r'(?<![A-Z0-9])'+re.escape(n)+r'(?![A-Z0-9])',norm(s['name'])) for n in aliases):candidates.append((0,sid,'Exact whole city-name match in official station directory with matching country; no nearest-distance claim'))
  candidates.sort(key=lambda x:({'I':0,'M':1,'N':2}.get(x[1][2],3),x[0],x[1]) if inventories[year]['stations'] is None else (0,x[0],x[1]));checked=[];hit=None
  for dist,sid,method in candidates[:8]:
   url=f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/parquet/GHCNh_{sid}_{year}.parquet';item=dict(station_id=sid,distance_km=dist if geo else None)
   try:
    b,r=c.get(url,document=True);pf=pq.ParquetFile(io.BytesIO(b));usable=pf.metadata.num_rows>=100 and all(k in pf.schema_arrow.names for k in ['STATION','DATE','temperature']);item.update(request_id=r['request_id'],rows=pf.metadata.num_rows,usable=usable)
    if usable:hit=dict(station=sid,archive_request_id=r['request_id'],station_directory_row=stations[sid]['line'],maximum_venue_distance_km=dist if geo else None,method=method)
   except Exception as e:item['error']=type(e).__name__+': '+str(e)
   checked.append(item)
   if hit:break
  body=dict(city=city,year=year,status='ok' if hit else 'unavailable',official_city_evidence=rs,station_directory_request_id=dr['request_id'],annual_archive_inventory_request_id=inventories[year]['request_id'],inventory_error=inventories[year].get('error'),candidate_order='ICAO, WMO, national identifiers then remaining directory stations, within the original geographic bound' if inventories[year]['stations'] is None else 'Closest available official archive',candidate_count=len(candidates),alternatives=checked,**(hit or {}));return city,year,body
 day=dt.date(2024,1,1);parts=[];milestone=10
 while day<=dt.date(2026,9,14) and len(parts)<math.ceil(33*a.through_percent/100):
  month=day.strftime('%Y-%m');counts=collections.Counter()
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
   for city,year,row in pool.map(fetch,by_month[month]):
    with db:
     db.execute('INSERT OR REPLACE INTO _eu_weather_station_jobs VALUES (?,?,?)',(city,year,json.dumps(row)))
     if row['status']=='ok':db.execute('INSERT OR REPLACE INTO _weather_city_stations VALUES (?,?,?,?)',(city,year,row['station'],json.dumps(row)))
    counts[row['status']]+=1
  parts.append(dict(month=month,city_years=len(by_month[month]),counts=dict(counts)));out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='European weather station archives by first game date',pilot=a.pilot,processed_months=len(parts),total_months=33,new_requests=c.requests,months=parts,scope='Official annual station archives only; observations will be normalized after final published-game filtering');(ROOT/'reports'/('eu_weather_stations_'+('pilot' if a.pilot else 'months')+'.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
  if counts:print('EU WEATHER STATIONS',month,dict(counts),flush=True)
  while not a.pilot and milestone<=100 and len(parts)>=math.ceil(33*milestone/100):print('EU WEATHER STATION DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print('EU WEATHER STATION NEW REQUESTS',c.requests);db.close()

if __name__=='__main__':main()
