"""Verify scorer documents and extract aligned single boundary observations."""
import argparse,collections,datetime as dt,io,json,re,sqlite3,types,unicodedata
from pypdf import PdfReader
from history_index import records,payload
from probe_history import ROOT
from build_history_catalog import DB,ORIGINAL,clean
from core import checkpoint_rows,utc
from people import namekey,minutes
from schema import CHECKPOINTS

def jsonlines(path):
 if path.exists():
  for line in path.read_text(encoding='utf-8').splitlines():
   if line:yield json.loads(line)

def parse_book(body,g):
 text=PdfReader(io.BytesIO(body)).pages[0].extract_text();tokens=[t.strip() for t in text.splitlines() if t.strip()];joined=' '.join(tokens)
 vm=re.search(r'VISITOR:\s*(.*?)\s*\(',joined);hm=re.search(r'HOME:\s*(.*?)\s*\(',joined)
 labelled=bool(vm and hm)
 if labelled:names=[vm[1],hm[1]]
 else:
  # Neutral-site scorer reports can omit HOME/VISITOR. Identify each box by
  # its full team name and following standings, without inferring home status.
  names=[tokens[i] for i in range(len(tokens)-1) if clean(tokens[i]) in {clean(n) for n in g['teams']} and re.fullmatch(r'\(\d+-\d+\)',tokens[i+1])]
  if len(names)!=2:raise ValueError('Missing two identifiable team-box headers')
 if {clean(n) for n in names}!={clean(n) for n in g['teams']}:raise ValueError('Official gamebook names do not match the requested game')
 order=[next(i for i,n in enumerate(g['teams']) if clean(n)==clean(x)) for x in names]
 second_header=next(i for i,t in enumerate(tokens) if clean(t.removeprefix('HOME:').strip())==clean(names[1]))
 parsed=[];totals=[]
 for i,t in enumerate(tokens):
  if not re.fullmatch(r'\d{2,3}:\d{2}',t) or i<2:continue
  v=tokens[i+1:i+17]
  if len(v)!=16 or not all(re.fullmatch(r'[+-]?\d+',x) for x in v):continue
  side=order[int(i>second_header)]
  if len(t.split(':')[0])==3:totals.append((side,int(v[15]),t));continue
  pos=tokens[i-1] if tokens[i-1] in {'F','G','C'} else None;name=tokens[i-2] if pos else tokens[i-1]
  if name[0].isdigit():continue
  parsed.append(dict(name=name,team=g['teams'][side],side=side,score=int(v[15]),assists=int(v[9]),minutes=minutes(t),raw_minutes=t,starter=int(bool(pos))))
 if len(parsed)<10 or len(totals)!=2:raise ValueError('Incomplete final-box schema')
 scores=[None,None]
 for side,score,mt in totals:
  scores[side]=score
  if sum(p['score'] for p in parsed if p['side']==side)!=score:raise ValueError('Player point total differs from official team total')
  if abs(sum(p['minutes'] for p in parsed if p['side']==side)-minutes(mt))>.2:raise ValueError('Player minutes do not sum to official team minutes')
 provider_scores=g.get('provider_scores',g['scores'])
 discrepancy=all(x is not None for x in provider_scores) and scores!=provider_scores
 official_winner=g['teams'][int(scores[1]>scores[0])]
 date=dt.date.fromisoformat(g['date']);date_regex=date.strftime('%A')+r',\s*'+date.strftime('%B')+r'\s+'+str(date.day)+r',\s*'+str(date.year)
 hit=re.search(date_regex+r'\s+(.*?)\s+Officials:',joined)
 if not hit:raise ValueError('Official scorer report date differs or venue header missing')
 location=hit[1]
 # Score-by-period stores cumulative points at the breaks; no clock-time guessing.
 match=re.search(r'SCORE BY\s+PERIOD\s+(.*?)\s+Inactive:',joined)
 qscore=None
 if match and 'FINAL' in match[1]:
  header,vals=match[1].split('FINAL',1);periods=len(re.findall(r'\b[1-9]\d*\b|\b(?:\d*OT)\b',header))
  chunks=re.findall(r'(?:\d+\s+){3,}\d+',vals)
  if len(chunks)==2:
   nums=[list(map(int,x.split())) for x in chunks]
   if all(len(x)>=5 and sum(x[:-1])==x[-1] for x in nums):
    qscore=[[0,0] for _ in range(4)]
    for doc_side,ns in enumerate(nums):
     if ns[-1]!=scores[order[doc_side]]:raise ValueError('Quarter sum disagrees with final')
     for q in range(1,4):qscore[q][order[doc_side]]=sum(ns[:q])
 return dict(players=parsed,scores=scores,winner=official_winner,location=location,home_away=';'.join('Home' if s==order[1] else 'Away' for s in range(2)) if labelled else None,quarter_scores=qscore,provider_scores=provider_scores,score_discrepancy=discrepancy)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--recovered-only',action='store_true');args=ap.parse_args()
 db=sqlite3.connect(DB);games={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _history_games')};directory={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _history_players')}
 if args.recovered_only:
  wanted={r[0] for r in db.execute('SELECT DISTINCT game_id FROM _nba_recovered_checkpoints')};games={k:g for k,g in games.items() if k in wanted}
 byname=collections.defaultdict(list)
 for pid,item in directory.items():byname[item['data']['details']['league'],namekey(re.sub(r' \([A-Z]{2,3}\)$','',item['data']['name']))].append(pid)
 rs={r['request_id']:r for r in records()};books={r['game_id']:r for r in jsonlines(ROOT/'reports/nba_gamebook_acquisition.jsonl') if r['status']=='ok'}
 pbps={r['game_id']:r for r in jsonlines(ROOT/'reports/history_acquisition_jobs.jsonl') if r['kind']=='pbp' and r['status']=='ok'}
 findings=[];appearance=[];checkpoints=[];counts=collections.Counter()
 # Restore nine previously verified venue/start anchors exactly, without making
 # their source evidence represent another game's venue or an entire franchise.
 oldgames={gid:json.loads(body) for gid,body in db.execute('SELECT game_id,body FROM _verified_pilot_anchors')}
 for gid,g in games.items():
  g['validation_status']='PROVIDER_CONSISTENCY_ONLY'
  if gid in oldgames:
   v=oldgames[gid];g['location']=v.get('location');g['home_away']=v.get('home_away');g['start']=v.get('anchor') or g['start'];g['start_basis']=v.get('anchor_basis',g['start_basis']);g['city']=v.get('city')
  elif not g.get('milestone_id'):g['home_away']=None
  book=None
  if gid in books:
   item=books[gid];r=rs[item['request_id']]
   try:
    book=parse_book((ROOT/r['raw_file']).read_bytes(),g)
    if book['score_discrepancy']:
     findings.append(dict(game_id=gid,source='nba_gamebook',request_id=r['request_id'],error='Gamebook final differs from provider result',provider_scores=book['provider_scores'],official_scores=book['scores'],resolution_status='RESOLVED_OFFICIAL_SCORER',basis='Full teams, calendar date, player point totals, team minutes, and winner checked against official final scorer report'))
    g.setdefault('provider_winner',g['winner'])
    if book['winner']!=g['provider_winner']:findings.append(dict(game_id=gid,source='nba_gamebook',request_id=r['request_id'],error='Gamebook winner differs from provider result',provider_winner=g['provider_winner'],official_winner=book['winner'],resolution_status='RESOLVED_OFFICIAL_SCORER'))
    g['provider_scores']=book['provider_scores'];g.update({k:book[k] for k in ['location','home_away','scores','winner']});g['venue_request_id']=r['request_id'];g['official_score_request_id']=r['request_id'];g['official_result_verified']=True;g['validation_status']='OFFICIAL_NBA_FINAL_VERIFIED'
    g['city']=book['location'].split(',')[-2].strip() if ',' in book['location'] else None;counts['verified_nba_books']+=1
    for x in book['players']:
     ids=byname['NBA',namekey(x['name'])];pid=ids[0] if len(ids)==1 else 'NBA:'+namekey(x['name'])
     appearance.append(dict(player_id=pid,player_name=x['name'],game_type='Basketball',league='NBA',team_name=x['team'],game_id=gid,game_date=g['date'],score=x['score'],assists=x['assists'],minutes=x['minutes'],starter=x['starter'],win=int(x['team']==g['winner']),request_id=r['request_id'],raw_minutes=x['raw_minutes'],source='NBA official final scorer report, page 1'))
   except Exception as e:
    g['validation_status']='QUARANTINED_SCORER_VALIDATION';findings.append(dict(game_id=gid,source='nba_gamebook',request_id=r['request_id'],error=str(e),resolution_status='UNRESOLVED'))
  cp=[dict(time=None,a=None,b=None,pointer=None) for _ in CHECKPOINTS[g['game_type']]]
  if gid in pbps:
   item=pbps[gid];r=rs[item['request_id']];d=payload(r)
   try:cp=checkpoint_rows(d,g['game_type'].lower())
   except Exception as e:findings.append(dict(game_id=gid,source='pbp',request_id=r['request_id'],error=str(e)))
   if g['league']=='MLB':
    hitters={}
    for period in (d.get('pbp') or {}).get('periods') or []:
     for e in period.get('events') or []:
      if e.get('hitter_name') and e.get('attribution') in g['team_ids']:
       hitters[e['hitter_name']]=g['team_ids'].index(e['attribution'])
    for name,side in hitters.items():
     ids=byname['MLB',namekey(name)];pid=ids[0] if len(ids)==1 else 'MLB:'+namekey(name)
     appearance.append(dict(player_id=pid,player_name=name,game_type='Baseball',league='MLB',team_name=g['teams'][side],game_id=gid,game_date=g['date'],score=None,assists=None,minutes=None,starter=None,win=int(g['teams'][side]==g['winner']),request_id=r['request_id'],raw_minutes=None,source='Official Kalshi play-by-play hitter identity; pitching-only players and batting statistics unavailable'))
  if cp[0]['time']:
   g['start']=cp[0]['time'].isoformat();g['start_basis']='Actual play-by-play opening boundary'
  for i,name in enumerate(CHECKPOINTS[g['game_type']]):
   c=cp[i];scores=[c.get('a'),c.get('b')];source=pbps.get(gid,{}).get('request_id')
   if book and book['quarter_scores'] is not None:
    bs=book['quarter_scores'][i]
    if all(s is not None for s in scores) and scores!=bs:findings.append(dict(game_id=gid,source='checkpoint_score',checkpoint=name,pbp=scores,gamebook=bs))
    scores=bs
   checkpoints.append(dict(game_id=gid,checkpoint=name,ordinal=i,timestamp=c['time'].isoformat() if c['time'] else None,teamA_score=scores[0],teamB_score=scores[1],request_id=source,pointer=c['pointer'],score_request_id=books.get(gid,{}).get('request_id') if book else source))
 for name,items in [('_history_appearances',appearance),('_history_checkpoints',checkpoints),('_history_enrichment_audit',findings)]:
  db.execute(f'CREATE TABLE IF NOT EXISTS {name} (body TEXT NOT NULL)')
  if args.recovered_only:db.execute(f"DELETE FROM {name} WHERE json_extract(body,'$.game_id') IN ("+','.join('?' for _ in games)+')',list(games))
  else:db.execute(f'DELETE FROM {name}')
  db.executemany(f'INSERT INTO {name} VALUES (?)',[(json.dumps(x),) for x in items])
 db.executemany('UPDATE _history_games SET body=? WHERE id=?',[(json.dumps(g),gid) for gid,g in games.items()]);db.commit();db.close()
 summary=dict(counts=counts,appearances=len(appearance),checkpoints=len(checkpoints),timed_checkpoints=sum(c['timestamp'] is not None for c in checkpoints),issues=len(findings));(ROOT/'reports/history_enrichment.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))

if __name__=='__main__':main()
