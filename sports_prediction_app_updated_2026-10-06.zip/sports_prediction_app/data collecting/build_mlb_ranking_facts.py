"""Extract overall MLB ranks, preserve edition dates and verify native identities."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_nba_performance import identity_keys
from build_nba_ranking_facts import source_dates
from probe_history import ROOT

def extract(s,pub):
    facts=[]
    if pub=='cbs_sports':
        for i,tr in enumerate(s.select('table.ranked-players tr')):
            cs=tr.find_all('td',recursive=False);name=tr.select_one('.player-name')
            if name and cs and re.fullmatch(r'\d+',cs[0].get_text(strip=True)):
                facts.append(dict(rank=int(cs[0].get_text(strip=True)),source_player_name=name.get_text(' ',strip=True),selector='table.ranked-players tr',index=i,raw_value=tr.get_text(' ',strip=True)))
        return facts
    selector='p' if pub in ['mlb_network','bleacher_report'] else 'h2,h3,h4'
    for i,tag in enumerate(s.select(selector)):
        raw=tag.get_text(' ',strip=True)
        if pub=='mlb_network':
            # Only line starts separated by actual HTML <br> delimiters are
            # rankings. Parenthesized previous-year ranks are not new entries.
            copy=BeautifulSoup(str(tag),'html.parser')
            for br in copy.find_all('br'):br.replace_with('\n')
            text=copy.get_text('',strip=False)
            matches=list(re.finditer(r'(?m)^\s*(\d+)[.)]?\s+([^,\n]+),',text))
        elif pub=='bleacher_report':
            matches=list(re.finditer(r'^(?:No\.\s*)?(\d+)[.:]\s+(.+?)(?:\s+—\s+|,)',raw))
        else:matches=list(re.finditer(r'^(\d+)\.\s+([^,]+),',raw))
        for m in matches:
            rank=int(m[1]);names=[m[2].strip()]
            # Two explicitly shared entries in the publisher's 2025 edition.
            # Preserve the shared rank for both named people, not a made-up order.
            if pub=='bleacher_report' and re.search(r',\s*\w+(?:/\w+)?\s+and\s+',raw):
                second=re.search(r',\s*\w+(?:/\w+)?\s+and\s+([^,]+),',raw)
                if second:names.append(second[1].strip())
            for name in names:
                facts.append(dict(rank=rank,source_player_name=name,selector=selector,index=i,raw_value=raw,shared_rank=len(names)>1))
    return facts

def main():
    db=sqlite3.connect(DB,timeout=60);index=collections.defaultdict(set);canonical={}
    for pid,b in db.execute('SELECT * FROM _mlb_player_bio_constants'):
        x=json.loads(b);canonical[pid]=x['player_name']
        for key in identity_keys(x['player_name']):index[key].add(pid)
    aliases={a:json.loads(b) for a,b in db.execute('SELECT * FROM _mlb_verified_ranking_aliases')} if db.execute("SELECT 1 FROM sqlite_master WHERE name='_mlb_verified_ranking_aliases'").fetchone() else {}
    facts=[];editions=[];issues=[]
    for b, in db.execute('SELECT body FROM _mlb_ranking_sources'):
        x=json.loads(b)
        if x['status']!='ACQUIRED_NOT_VALIDATED':issues.append(dict(url=x['url'],reason=x.get('error')));continue
        published,version,article=source_dates(x)
        if article.get('isAccessibleForFree') is False:issues.append(dict(url=x['url'],reason='Subscription-marked article; no extraction'));continue
        r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(x['request_id'],)).fetchone()[0]);raw=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];s=BeautifulSoup(raw,'html.parser');notes=[]
        if x['publisher']=='fox_sports':
            visible=re.search(r'Updated\s+([A-Za-z]+)\.?\s+(\d{1,2}),\s+(\d{4})',s.get_text(' ',strip=True));assert visible
            visible_date=dt.datetime.strptime(' '.join(visible.groups()),'%b %d %Y').date().isoformat();version=max(version,visible_date);notes.append('Visible update date takes precedence when later than structured metadata')
        fs=extract(s,x['publisher']);eid='MLB_'+x['publisher'].upper()+'_'+published.replace('-','')+'_'+hashlib.sha256(x['url'].encode()).hexdigest()[:8]
        ranks={f['rank'] for f in fs};expected=50 if 'top-50' in x['url'] else 25 if 'top-25' in x['url'] else 100
        complete=ranks==set(range(1,expected+1))
        assert all(1<=f['rank']<=expected for f in fs),(x['url'],'Unexpected rank')
        ed=dict(list_id=eid,publisher_key=x['publisher'],publication_date=published,version_verified_date=version,complete_list=complete,source_url=x['url'],request_id=x['request_id'],expected_ranks=expected,observed_ranks=len(ranks),facts=len(fs),missing_ranks=sorted(set(range(1,expected+1))-ranks),note='; '.join(notes+['Overall MLB editorial ranking; not fantasy, position-only, awards or a postseason participant subset. Shared entries retain their published rank.']))
        editions.append(ed)
        for f in fs:
            ids=set().union(*(index[k] for k in identity_keys(f['source_player_name'])))
            pid=next(iter(ids)) if len(ids)==1 else None
            alias=aliases.get(f['source_player_name'])
            if pid is None and alias and (not alias['required_ranking_context'] or alias['required_ranking_context'] in f['raw_value']):
                if f['source_player_name']=='Elly Da La Cruz':assert x['publisher']=='fox_sports' and 'Cincinnati Reds' in f['raw_value']
                pid=alias['player_id'];f['identity_verification']=alias
            f.update(list_id=eid,publisher_key=x['publisher'],player_id=pid,player_name=canonical.get(pid),source_url=x['url'],request_id=x['request_id'],source_version_date=version)
            if pid is None:issues.append(dict(url=x['url'],name=f['source_player_name'],reason='Native identity unmatched or ambiguous',candidate_ids=sorted(ids)))
            facts.append(f)
    assert len({(f['list_id'],f['source_player_name']) for f in facts})==len(facts),'Repeated player label within an edition'
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _mlb_ranking_candidate_facts (body TEXT NOT NULL)');db.execute('DELETE FROM _mlb_ranking_candidate_facts');db.executemany('INSERT INTO _mlb_ranking_candidate_facts VALUES (?)',[(json.dumps(f),) for f in facts])
        db.execute('CREATE TABLE IF NOT EXISTS _mlb_ranking_candidate_editions (list_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _mlb_ranking_candidate_editions');db.executemany('INSERT INTO _mlb_ranking_candidate_editions VALUES (?,?)',[(e['list_id'],json.dumps(e)) for e in editions])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),facts=len(facts),native_mapped=sum(f['player_id'] is not None for f in facts),editions=editions,issues=issues)
    (ROOT/'reports/mlb_ranking_candidates.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(dict(facts=len(facts),native_mapped=out['native_mapped'],editions=[dict(publisher=e['publisher_key'],date=e['version_verified_date'],ranks=e['observed_ranks'],complete=e['complete_list']) for e in editions],issues=issues)));db.close()

if __name__=='__main__':main()
