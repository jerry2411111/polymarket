"""NBA performance facts from selected games and official player box scores.

Only games present in at least one verified provider odds table enter the
performance population. Raw official player IDs and request pointers remain in
private source facts. All-Star appearances do not establish franchise tenure.
"""
import collections,datetime as dt,json,re,sqlite3,unicodedata
from build_history_catalog import DB
from probe_history import ROOT
from nba_identity import full_team_name

def name_key(value):
    return ''.join(c for c in unicodedata.normalize('NFKD',value).casefold() if c.isalnum())

def identity_keys(value):
    # Suffix and two-token order variants are only used with a unique official
    # game/team candidate. Never merge distinct NBA native IDs by name alone.
    base=re.sub(r'\s+(?:Jr\.?|Sr\.?|II|III|IV)$','',value,flags=re.I)
    keys={name_key(value),name_key(base)}
    if len(base.split())==2:keys.add(name_key(' '.join(reversed(base.split()))))
    return keys

def main():
    db=sqlite3.connect(DB,timeout=60)
    wanted={r[0] for r in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='NBA' UNION SELECT game_id FROM kalshi_pre_match WHERE league='NBA'")}
    games={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_games') if i in wanted}
    native={g['official_game_id']:gid for gid,g in games.items()};maps={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_map')}
    pages={i:json.loads(b) for i,b in db.execute('SELECT official_game_id,body FROM _official_nba_page_games')}
    cards={i:json.loads(b) for i,b in db.execute('SELECT official_game_id,body FROM _official_nba_schedule')}
    names=collections.defaultdict(set);team_names=collections.defaultdict(set);game_names=collections.defaultdict(set);display=collections.defaultdict(collections.Counter);source_rows=[];issues=[];bridges=collections.defaultdict(set)
    profiles={pid:json.loads(b) for pid,b in db.execute('SELECT official_player_id,body FROM _nba_profile_sources') if json.loads(b).get('status')=='ok'}
    for gid,pid,b in db.execute('SELECT official_game_id,official_player_id,body FROM _official_nba_page_players'):
        p=json.loads(b);display[pid][p['player_name']]+=1
        aliases=[p['player_name']]+[a for a in profiles.get(pid,{}).get('aliases',[]) if a]
        for alias in aliases:
            for key in identity_keys(alias):
                names[key].add(pid)
                team_names[key,cards[gid]['official_team_ids'][p['side']]].add(pid)
                game_names[key,gid,p['side']].add(pid)
        if gid not in native:continue
        g=games[native[gid]];page=pages[gid]
        assert page['scores']==g['scores'] and p['game_date']==g['date'],'Official player/game mismatch'
        if 'active_roster' not in p:issues.append(dict(game_id=g['game_id'],reason='Inactive-roster extraction pending'))
        side=p['side'];p=dict(p,player_id='NBA:'+pid,game_id=g['game_id'],game_type='Basketball',league='NBA',season=g['season'],team_name=g['teams'][side],game_date=g['date'],win=int(g['scores'][side]>g['scores'][1-side]),temporary_team='All-Star' in g['season'],source='Official NBA structured game page')
        source_rows.append(p)
    covered={p['game_id'] for p in source_rows};fallback_games=wanted-covered;fallback=[];pdf_by_person={};stat_changes=[]
    for (b,) in db.execute("SELECT body FROM _history_appearances WHERE json_extract(body,'$.league')='NBA'"):
        p=json.loads(b);p['team_name']=full_team_name(p['team_name']);m=maps.get(p['game_id'])
        if not m or m['game_id'] not in wanted:continue
        g=games[m['game_id']];side=g['teams'].index(p['team_name']);tid=cards[g['official_game_id']]['official_team_ids'][side]
        keys=identity_keys(p['player_name'])
        ids=set().union(*(game_names[k,g['official_game_id'],side] for k in keys))
        if not ids:ids=set().union(*(team_names[k,tid] for k in keys)) or set().union(*(names[k] for k in keys))
        if len(ids)!=1:
            issues.append(dict(game_id=g['game_id'],player_name=p['player_name'],reason='Official player ID unavailable or ambiguous for scorer-PDF fallback'));continue
        pid=next(iter(ids));side=g['teams'].index(p['team_name']);bridges[p['player_id']].add('NBA:'+pid)
        fact=dict(p,player_id='NBA:'+pid,official_player_id=pid,official_game_id=g['official_game_id'],game_id=g['game_id'],game_date=g['date'],season=g['season'],did_play=True,active_roster=None,side=side,win=int(g['scores'][side]>g['scores'][1-side]),temporary_team='All-Star' in g['season'],pointer=None)
        pdf_by_person[fact['player_id'],g['game_id']]=fact
        if g['game_id'] in fallback_games:fallback.append(fact)
    for p in source_rows:
        final=pdf_by_person.get((p['player_id'],p['game_id']))
        if final is None:continue
        differences={k:dict(game_page=p[k],final_scorer=final[k]) for k in ['score','assists','minutes','starter'] if p[k]!=final[k]}
        if differences:stat_changes.append(dict(game_id=p['game_id'],player_id=p['player_id'],player_name=final['player_name'],page_request_id=p['request_id'],scorer_request_id=final['request_id'],values=differences,choice='Official final scorer report, already validated against complete team point/minute totals'))
        p.update(roster_request_id=p['request_id'],roster_pointer=p['pointer'],source_player_name=p['player_name'],request_id=final['request_id'],pointer=None,source='Official NBA final scorer report; native identity/roster from official game page',did_play=True)
        p.update({k:final[k] for k in ['score','assists','minutes','raw_minutes','starter']})
    # Multiple original provider game IDs can have referred to the same game.
    unique={}
    for p in source_rows+fallback:
        key=p['player_id'],p['game_id']
        if key in unique:
            for field in ['team_name','score','assists','minutes','starter','win']:assert unique[key][field]==p[field],('Conflicting official appearance',key,field)
        else:unique[key]=p
    source_rows=list(unique.values());bygame=collections.defaultdict(list)
    for p in source_rows:
        p.setdefault('source_player_name',p['player_name'])
        pid=p['official_player_id'];p['player_name']=profiles.get(pid,{}).get('player_name') or display[pid].most_common(1)[0][0]
        bygame[p['game_id']].append(p)
    for gid,ps in bygame.items():
        g=games[gid]
        for side in range(2):
            players=[p for p in ps if p['side']==side and p['did_play']]
            assert players and all(p['score'] is not None for p in players),('Incomplete played-player score values',gid,side,[(p['player_name'],p.get('raw_minutes'),p['score'],p['did_play']) for p in ps if p['side']==side])
            assert sum(p['score'] for p in players)==g['scores'][side],('Player scores do not equal official result',gid,side)
    unparsed={x['game_id'] for x in issues if x['reason']=='Inactive-roster extraction pending'}
    if unparsed:raise ValueError('Complete existing official roster replay first; games pending: '+str(len(unparsed)))
    db.execute('CREATE TABLE IF NOT EXISTS _nba_player_game_facts (player_id TEXT NOT NULL,game_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(player_id,game_id)) STRICT')
    db.execute('DELETE FROM _nba_player_game_facts');db.executemany('INSERT INTO _nba_player_game_facts VALUES (?,?,?)',[(p['player_id'],p['game_id'],json.dumps(p)) for p in source_rows]);db.commit()
    played=[p for p in source_rows if p['did_play']]
    db.execute("DELETE FROM _player_game_results WHERE league='NBA'")
    db.executemany('INSERT INTO _player_game_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',[(p['player_id'],p['player_name'],'Basketball','NBA',p['team_name'],p['game_id'],p['game_date'],p['score'],p['assists'],p['minutes'],p['starter'],p['win']) for p in played]);db.commit()
    db.execute("DELETE FROM _team_game_results WHERE league='NBA'")
    for gid,g in games.items():
        for side in range(2):
            db.execute('INSERT INTO _team_game_results VALUES (?,?,?,?,?,?,?,?,?)',(gid,g['teams'][side],'Basketball','NBA',g['date'],g['home_away'].split(';')[side],g['scores'][side],g['scores'][1-side],int(g['scores'][side]>g['scores'][1-side])))
    db.execute('UPDATE _collection_scope SET collection_start=?,collection_end=?,performance_scope=?',('2024-01-01','2026-09-14','Only collected games in provider result tables; date-bounded cumulative performance. Other league expansion remains in progress.'));db.commit()
    db.execute('CREATE TABLE IF NOT EXISTS _nba_player_stat_audit (body TEXT NOT NULL)');db.execute('DELETE FROM _nba_player_stat_audit');db.executemany('INSERT INTO _nba_player_stat_audit VALUES (?)',[(json.dumps(i),) for i in issues]);db.commit();db.close()
    db=sqlite3.connect(DB,timeout=60)
    db.execute('CREATE TABLE IF NOT EXISTS _player_identity_aliases (source_player_id TEXT NOT NULL,league TEXT NOT NULL,player_id TEXT NOT NULL,basis TEXT NOT NULL,PRIMARY KEY(source_player_id,league)) STRICT')
    db.execute("DELETE FROM _player_identity_aliases WHERE league='NBA'")
    db.executemany('INSERT INTO _player_identity_aliases VALUES (?,?,?,?)',[(old,'NBA',next(iter(ids)),'Official scorer name matched uniquely to official game/team native player ID') for old,ids in bridges.items() if len(ids)==1]);db.commit();db.close()
    (ROOT/'reports/nba_player_stat_source_differences.json').write_text(json.dumps(stat_changes,indent=2),encoding='utf-8')
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),selected_nba_games=len(games),games_with_player_statistics=len(bygame),missing_games=sorted(wanted-set(bygame)),player_game_roster_rows=len(source_rows),played_appearances=len(played),distinct_players=len({p['player_id'] for p in source_rows}),distinct_played_players=len({p['player_id'] for p in played}),scorer_pdf_fallback_games=len({p['game_id'] for p in fallback}),issues=issues,scope='Only games with acquired odds; performance queries must apply game_date <= requested date. Coach, contracts, profiles, membership, rankings and weather are separate completion checks.')
    (ROOT/'reports/nba_performance_facts.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='issues'}))

if __name__=='__main__':main()
