"""Inspect one retained game per competition for performance and clock mappings."""
import json,sqlite3,collections
from build_history_catalog import DB
from probe_eu_official_reports import brief
db=sqlite3.connect(DB)
for code,table in [('BUN','bundesliga'),('LAL','laliga')]:
 mid,b=db.execute("SELECT * FROM _official_"+table+"_game_reports WHERE json_extract(body,'$.status')='ok' LIMIT 1").fetchone();s=json.loads(b)['sources'];print(code,mid)
 if code=='BUN':
  line=s['lineups']['data'];match=s['match']['data']
  for side in ['away','home']:
   for kind,v in line[side].items():
    print('BUN',side,kind,json.dumps(brief(v),ensure_ascii=False))
    for field,values in v.items():
     if isinstance(values,list) and values:print('FIRST',field,json.dumps(brief(values[0]),ensure_ascii=False))
  print('BUN BLOG TYPES',dict(collections.Counter(v['entryType'] for v in match['liveBlogEntries'].values())))
  for k,v in match['liveBlogEntries'].items():
   if v['entryType'] in ['kickoff','kickOff','halfTime','halftime','secondHalf','matchStart','finalWhistle'] or v['matchSection']=='HALF':print('CLOCK',k,json.dumps(v,ensure_ascii=False)[:1800])
 else:
  p=s['match_page']['data'];print('PERIOD STARTS',p['match'].get('period_started'));print('COMMENT KIND',p['data']['comments'][0]['match_comment_kind'])
  for side in ['away','home']:
   v=p['data']['lineups'][side];print('LINEUP',side,json.dumps(brief(v),ensure_ascii=False))
  for v in p['data']['comments']:
   if any(w in v['content'].lower() for w in ['half ends','half begins','half kicks']):print('COMMENT',json.dumps(v,ensure_ascii=False))
db.close()
