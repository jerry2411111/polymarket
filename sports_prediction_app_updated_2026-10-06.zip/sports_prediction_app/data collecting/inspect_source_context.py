"""Read bounded literal context from an already retained official source."""
import argparse,json,re,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

def main():
    ap=argparse.ArgumentParser();ap.add_argument('request_id');ap.add_argument('pattern');ap.add_argument('--width',type=int,default=700);ap.add_argument('--limit',type=int,default=8);ap.add_argument('--after',type=int,default=0);a=ap.parse_args();db=sqlite3.connect(DB);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(a.request_id,)).fetchone()[0]);s=(ROOT/r['raw_file']).read_text(encoding='utf-8',errors='replace');db.close()
    for n,m in enumerate(re.compile(a.pattern,re.I).finditer(s,a.after)):
        if n>=a.limit:break
        v=s[max(0,m.start()-min(a.width//4,150)):min(m.end()+a.width,m.start()+max(1000,2*a.width))].replace('\\"','"');v=re.sub(r'(?i)([\w-]*(?:api[_-]?key|key|token|secret|password)[\w-]*["\x27]?\s*[:=]\s*["\x27])[^"\x27]+',r'\1[redacted]',v);print('OFFSET',m.start(),v)

if __name__=='__main__':main()
