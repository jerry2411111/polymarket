"""Refresh official event discovery in independently resumable calendar months."""
import argparse,calendar,datetime as dt,json
from history_client import HistoryClient
from history_index import index
from probe_history import ROOT

DOC='https://docs.polymarket.com/api-reference/events/list-events-keyset-pagination'
TAGS={'NBA':745,'MLB':100381,'NHL':899}

def main():
    p=argparse.ArgumentParser();p.add_argument('--league',required=True,choices=list(TAGS));p.add_argument('--max-new-months',type=int);a=p.parse_args()
    client=HistoryClient();docbody,doc=client.get(DOC+'.md',document=True)
    assert b'after_cursor' in docbody and b'end_date_min' in docbody and b'end_date_max' in docbody
    path=ROOT/'reports'/(a.league.lower()+'_date_discovery.json');old=json.loads(path.read_text()) if path.exists() else {};completed={x['month']:x for x in old.get('months',[]) if x['pagination_exhausted']}
    known=set(index()['polymarket_events']);day=dt.date(2024,1,1);end=dt.date(2026,9,15);parts=[];nnew=0
    while day<end:
        hi=min(day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1),end);month=day.strftime('%Y-%m')
        if month in completed:parts.append(completed[month]);day=hi;continue
        if a.max_new_months and nnew>=a.max_new_months:break
        params=dict(tag_id=TAGS[a.league],end_date_min=day.isoformat()+'T00:00:00Z',end_date_max=hi.isoformat()+'T00:00:00Z',order='id',ascending='true',limit=500);seen=set();cursors=set();requests=[];error=None
        try:
            for _ in range(100):
                data,r=client.get('https://gamma-api.polymarket.com/events/keyset',params);requests.append(r['request_id'])
                for event in data['events']:
                    assert event['id'] not in seen,'Repeated event within pagination'
                    assert day.isoformat()<=(event.get('endDate') or '')[:10]<=hi.isoformat(),'Returned date outside API filter'
                    seen.add(event['id'])
                cursor=data.get('next_cursor')
                if not cursor:break
                assert cursor not in cursors,'Repeated continuation cursor';cursors.add(cursor);params['after_cursor']=cursor
            else:raise ValueError('Pagination safety bound reached')
        except Exception as e:error=str(e)
        parts.append(dict(month=month,from_date=day.isoformat(),through_date=(hi-dt.timedelta(days=1)).isoformat(),events=len(seen),event_ids=sorted(seen),new_event_ids=sorted(seen-known),pagination_exhausted=error is None,error=error,request_ids=requests));nnew+=1
        result=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),league=a.league,phase='Polymarket event discovery by month; scores and odds validation remain separate',from_date='2024-01-01',through_date='2026-09-14',total_months=33,completed_months=sum(x['pagination_exhausted'] for x in parts),documentation_url=DOC,documentation_request_id=doc['request_id'],closed_filter='omitted',months=parts)
        result['percent']=round(100*result['completed_months']/33,2);path.write_text(json.dumps(result,indent=2),encoding='utf-8')
        print('DATE DISCOVERY',a.league,month,'events',len(seen),'new',len(seen-known),'status',error or 'verified pagination','progress',result['completed_months'],'/33',flush=True)
        if error:break
        day=hi
    print('DISCOVERY SUMMARY',json.dumps(dict(league=a.league,completed_months=len([x for x in parts if x['pagination_exhausted']]),total_months=33,new_requests=client.requests)),flush=True)

if __name__=='__main__':main()
