"""Exhaust official commentary pagination and capture independently written league reports."""
import datetime as dt,json,sqlite3
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT,HOSTS
from collect_premier_pilot import BASE

ARTICLES={'2367731':'3840379','2367736':'3840388','2367742':'3855322'}

def main():
    HOSTS.update({'sdp-prem-prod.premier-league-prod.pulselive.com','www.premierleague.com'});client=HistoryClient();db=sqlite3.connect(DB,timeout=60);out=[]
    for mid,b in db.execute('SELECT * FROM _official_epl_game_reports').fetchall():
        row=json.loads(b);commentary=[];requests=[];cursors=set();seen=set();params={'lang':'en'}
        for _ in range(100):
            data,r=client.get(BASE+'/v2/matches/'+mid+'/commentary',params);requests.append(r['request_id'])
            for i,c in enumerate(data['data']):
                ident=json.dumps(c,sort_keys=True);assert ident not in seen,'Repeated commentary across pages';seen.add(ident);commentary.append(dict(raw=c,request_id=r['request_id'],pointer='/data/'+str(i)))
            cursor=data['pagination'].get('_next')
            if not cursor:break
            assert cursor not in cursors,'Repeated continuation cursor';cursors.add(cursor);params['_next']=cursor
        else:raise ValueError('Pagination safety bound exceeded')
        url='https://www.premierleague.com/en/news/'+ARTICLES[mid];raw,r=client.get(url,document=True);row['commentary_complete']=dict(request_ids=requests,rows=commentary,pagination_exhausted=True);row['independent_report']=dict(url=url,request_id=r['request_id'])
        with db:db.execute('UPDATE _official_epl_game_reports SET body=? WHERE match_id=?',(json.dumps(row),mid))
        checkpoints=[x['raw'] for x in commentary if x['raw'].get('type') in ['start','end'] or any(w in x['raw'].get('comment','') for w in ['Half ends','Half begins','Match ends'])];out.append(dict(match_id=mid,commentary_rows=len(commentary),requests=len(requests),checkpoints=checkpoints,independent_report=row['independent_report']));print(json.dumps(out[-1]),flush=True)
    (ROOT/'reports/epl_complete_pilot_sources.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),games=out,new_requests=client.requests),indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
