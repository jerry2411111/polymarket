"""Verify old native seasons against official archive pages and test date filtering."""
import datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

BASE='https://bundesliga-web-prod.europe-west1.firebasedatabase.app'

def main():
    HOSTS.add('bundesliga-web-prod.europe-west1.firebasedatabase.app');client=HistoryClient();db=sqlite3.connect(DB);sources=json.loads((ROOT/'reports/eu_soccer_archive_pages.json').read_text())['sources'];examples=[];seasons={};date_probe=None
    for s in sources:
        if 'bundesliga.com' not in s['url']:continue
        year=int(s['url'].split('/matchday/')[1][:4]);day=int(s['url'].rsplit('/',1)[1]);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(s['request_id'],)).fetchone()[0]);b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];soup=BeautifulSoup(b,'html.parser');assert f'{year}/{str(year+1)[2:]}' in soup.title.get_text();matches=[]
        for script in soup.find_all('script',type='application/json'):
            for key,v in json.loads(script.get_text()).items():
                if key.startswith('_getDataFromFirebase-') and key.endswith('/matchesmatchday'+str(day)+'99'):
                    native=re.search('/seasons/([^/]+)/',key)[1]
                    if v and all(str(x['plannedKickOff'])[:4] in [str(year),str(year+1)] for x in v):matches.append((native,v))
        assert len(matches)==1;native,rows=matches[0];seasons[str(year)]=dict(native_season_id=native,official_page=s['url'],page_request_id=s['request_id']);data,rr=client.get(BASE+'/all/DFL-COM-000001/seasons/'+native+'/matches.json',dict(orderBy='"matchday"',equalTo=day));assert isinstance(data,dict) and len(data)==len(rows)==9;byid={x['matchId']:x for x in data.values()}
        for x in rows:
            assert byid[x['matchId']]==x;assert x['matchStatus']=='FINAL_WHISTLE';assert x['teams']['away']['dflDatalibraryClubId']!=x['teams']['home']['dflDatalibraryClubId'];assert all(isinstance(x['score'][k].get('fulltime',x['score'][k]['live']),int) for k in ['away','home'])
        examples.append(dict(year=year,season_id=native,round=day,games=9,raw_to_official_page_matches=True,request_id=rr['request_id'],page_request_id=s['request_id'],example=rows[0]));print('BUNDESLIGA HISTORICAL PILOT',year,native,'9 exact official page/API matches',flush=True)
    try:
        native=seasons['2023']['native_season_id'];p=dict(orderBy='"plannedKickOff"',startAt='"2024-01-01T00:00:00+0000"',endAt='"2024-01-31T23:59:59+0000"');data,r=client.get(BASE+'/all/DFL-COM-000001/seasons/'+native+'/matches.json',p);assert isinstance(data,dict) and all('2024-01-01'<=x['plannedKickOff'][:10]<='2024-01-31' for x in data.values());date_probe=dict(status='WORKING',request_id=r['request_id'],rows=len(data),parameters=p)
    except Exception as e:date_probe=dict(status='UNAVAILABLE',error=str(e))
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',seasons=seasons,examples=examples,date_filter_probe=date_probe,new_requests=client.requests);(ROOT/'reports/bundesliga_historical_pilot.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('BUNDESLIGA DATE FILTER',date_probe);db.close()

if __name__=='__main__':main()
