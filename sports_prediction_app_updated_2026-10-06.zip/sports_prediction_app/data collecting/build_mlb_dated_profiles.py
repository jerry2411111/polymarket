"""MLB date-queryable profiles from collected games and dated official moves."""
import collections,datetime as dt,json,sqlite3
from build_history_catalog import DB
from build_nba_dated_profiles import months
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    bio={pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _mlb_player_bio_constants')}
    events=collections.defaultdict(list)
    for b, in db.execute('SELECT body FROM _mlb_temporal_events ORDER BY known_date,event_id'):
        e=json.loads(b)
        if e['player_id'] in bio:events[e['known_date']].append(e)
    assert len({e['player_id'] for es in events.values() for e in es})>len(bio)*0.9,'Transaction/native player identity coverage mismatch'
    rosters=collections.defaultdict(list)
    for b, in db.execute('SELECT body FROM _mlb_player_game_facts'):
        p=json.loads(b);rosters[p['game_date']].append(p)
    changes=collections.defaultdict(list)
    for r in db.execute("SELECT * FROM _player_performance_periods WHERE league='MLB'"):changes[r['effective_from']].append(dict(r))
    cohorts={r['as_of_date']:dict(r) for r in db.execute("SELECT * FROM _player_score_cohorts WHERE league='MLB'")}
    wanted={r[0] for r in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='MLB' UNION SELECT game_id FROM kalshi_pre_match WHERE league='MLB'")}
    gs={gid:json.loads(b) for gid,b in db.execute('SELECT * FROM _mlb_canonical_games') if gid in wanted};game_days=collections.defaultdict(list)
    for g in gs.values():game_days[(dt.date.fromisoformat(g['date'])-dt.timedelta(days=1)).isoformat()].append(g)
    state={};performance={};missing=collections.Counter();rows=[];links=[];link_audit=[];aff=[];ambiguities=[];latest_rosters={};count=0
    def person(pid):
        return state.setdefault(pid,dict(team_id=None,team=None,history=[],history_ids=[],tenure_start=None,injured=False,ever_injured=False,active=None,overall_n=0,overall_played=0,current_n=0,current_played=0,current_starts=0,current_starts_known=0,first_known=None))
    def set_team(pid,tid,name,day,source_id,acquisition=False,leaving=False):
        p=person(pid);p['first_known']=p['first_known'] or day
        if leaving and p['team_id'] not in [None,tid]:return
        if leaving:tid=None;name=None
        if p['team_id']!=tid:
            p.update(team_id=tid,team=name,tenure_start=day if acquisition and tid else None,current_n=0,current_played=0,current_starts=0,current_starts_known=0,active=None)
            if tid:p['history_ids'].append(tid);p['history'].append(name)
        elif tid:
            p['team']=name
            if p['history_ids'] and p['history_ids'][-1]==tid:p['history'][-1]=name
            if p['tenure_start'] is None and acquisition:p['tenure_start']=day
        aff.append((pid,day,name,source_id))
    def apply_events(day):
        byperson=collections.defaultdict(list)
        for e in events[day]:byperson[e['player_id']].append(e)
        for pid,es in byperson.items():
            es.sort(key=lambda e:int(e['raw']['id']))
            acquired=[e for e in es if e['acquisition']];targets={e['team_id'] for e in acquired}
            if len(targets)>1:
                froms={str(e['raw'].get('fromTeam',{}).get('id','')) for e in acquired};finals=targets-froms
                if len(finals)!=1:
                    p=person(pid);p.update(team_id=None,team=None,tenure_start=None,active=None)
                    ambiguities.append(dict(player_id=pid,date=day,reason='Multiple same-day club acquisitions without a unique transfer-chain endpoint',event_ids=[e['event_id'] for e in es]));aff.append((pid,day,None,'AMBIGUOUS:'+day));continue
                final=next(iter(finals));es.sort(key=lambda e:(e['team_id']==final,int(e['raw']['id'])))
            for e in es:
                p=person(pid)
                if e['affiliation_action']:set_team(pid,e['team_id'],e['team_name'],day,e['event_id'],e['acquisition'],e['affiliation_action']=='depart')
                if e['injury_action']=='injured':p['injured']=True;p['ever_injured']=True
                elif e['injury_action']=='clear':p['injured']=False
                if e['active_roster'] is not None:p['active']=e['active_roster']
    for day in sorted(d for d in events if d<start):apply_events(day)
    cols=[r[1] for r in db.execute('PRAGMA table_info(player_profiles)')]
    # Large DELETE transactions can block the shared request audit for minutes.
    # Keep each derived-row removal small, committing between bounded batches.
    for table,where in [('game_player_profiles',"game_id LIKE 'MLB_%'"),('player_profiles',"league='MLB'")]:
        while True:
            cur=db.execute('DELETE FROM '+table+' WHERE rowid IN (SELECT rowid FROM '+table+' WHERE '+where+' LIMIT 5000)');db.commit()
            if not cur.rowcount:break
    insert='INSERT INTO player_profiles VALUES ('+','.join('?' for _ in cols)+')'
    first=dt.date.fromisoformat(start);total=(dt.date.fromisoformat(end)-first).days+1;milestone=10
    for i in range(total):
        d=first+dt.timedelta(days=i);day=d.isoformat()
        groups=collections.defaultdict(set)
        for r in sorted(rosters[day],key=lambda r:r['game_id']):
            # A suspended game's final boxscore can contain players who left
            # the club before the resumption, and substitutes added later.
            # It cannot date every listed player's affiliation reliably.
            if not r.get('affiliation_observation_safe',not r.get('spans_multiple_local_dates',False)):continue
            pid=r['player_id'];p=person(pid);p['first_known']=p['first_known'] or day
            if not r['temporary_team']:
                set_team(pid,str(gs[r['game_id']]['team_ids'][r['side']]),r['team_name'],day,'GAME:'+r['game_id'])
            p['overall_n']+=1;p['overall_played']+=r['did_play']
            if not r['temporary_team'] and p['team']==r['team_name']:
                p['current_n']+=1;p['current_played']+=r['did_play']
                if r['did_play'] and r['starter'] is not None:p['current_starts']+=r['starter'];p['current_starts_known']+=1
            # Appearing in a game is a dated observation of availability; a
            # later same-day published IL move below can supersede it.
            if r['did_play']:p['injured']=False;p['active']=True
            program='All-Star' if r['temporary_team'] else 'Spring' if gs[r['game_id']]['is_training'] else 'MLB'
            groups[r['game_id'],r['team_name'],program].add(pid)
        for (gid,team,program),ids in groups.items():latest_rosters[team,program]=dict(game_id=gid,observed_date=day,players=ids)
        apply_events(day)
        for p in changes[day]:performance[p['player_id']]=p
        cohort=cohorts.get(day,{})
        for pid,p in state.items():
            b=bio[pid];m=performance.get(pid,{});dob=dt.date.fromisoformat(b['birth_date']) if b['birth_date'] else None;avg=m.get('average_score_per_game');mu=cohort.get('mu');sigma=cohort.get('sigma')
            row=dict(player_id=pid,player_name=b['player_name'],game_type='Baseball',league='MLB',team=p['team'],overall_winrate=m.get('overall_winrate'),average_score_per_game=avg,average_assists_per_game=m.get('average_assists_per_game'),std_score_per_game=m.get('std_score_per_game'),std_assists_per_game=m.get('std_assists_per_game'),age=d.year-dob.year-((d.month,d.day)<(dob.month,dob.day)) if dob else None,weight_kg=b['weight_kg'],height_cm=b['height_cm'],years_played=None,score_z_score=(avg-mu)/sigma if avg is not None and mu is not None and sigma else None,injured_times_till_as_of_date=None if p['ever_injured'] else 0,currently_injured_till_as_of_date=int(p['injured']),number_of_teams_served=None,participation_rate_current_team=p['current_played']/p['current_n'] if p['current_n'] else None,participation_rate_overall=p['overall_played']/p['overall_n'] if p['overall_n'] else None,starter_percentage_current_team=p['current_starts']/p['current_played'] if p['current_played'] and p['current_starts_known']==p['current_played'] else None,starter_percentage_overall=m.get('starter_percentage_overall'),average_minutes_per_game=m.get('average_minutes_per_game'),std_minutes_per_game=m.get('std_minutes_per_game'),served_team_history=','.join(p['history']) or None,months_serving_current_team=months(p['tenure_start'],day) if p['tenure_start'] else None,as_of_date=day)
            rows.append(tuple(row[c] for c in cols));count+=1
            missing.update(k for k,v in row.items() if v is None)
        for g in game_days[day]:
            program='All-Star' if 'All-Star' in g['season'] else 'Spring' if g['is_training'] else 'MLB';eligible=set();sources=[]
            for team in g['teams']:
                r=latest_rosters.get((team,program))
                if r:
                    eligible.update(pid for pid in r['players'] if pid in state and (program=='All-Star' or state[pid]['team']==team));sources.append(dict(team=team,source_game_id=r['game_id'],observed_date=r['observed_date']))
                # New dated acquisitions supplement the previous observed
                # roster; there is no look-ahead to tomorrow's actual lineup.
                if program!='All-Star':eligible.update(pid for pid,p in state.items() if p['team']==team and p['active'] is True)
            links.extend((g['game_id'],pid,day) for pid in sorted(eligible));link_audit.append(dict(game_id=g['game_id'],as_of_date=day,profile_links=len(eligible),prior_roster_sources=sources))
        if len(rows)>=10000:db.executemany(insert,rows);db.commit();rows=[]
        if (i+1)*100//total>=milestone:print('MLB DATED PLAYER PROFILES',milestone,'percent;',day,'rows',count,flush=True);milestone+=10
    if rows:db.executemany(insert,rows)
    db.executemany('INSERT INTO game_player_profiles VALUES (?,?,?)',links)
    db.execute('CREATE TABLE IF NOT EXISTS _mlb_affiliation_daily (player_id TEXT,observed_date TEXT,team_name TEXT,observation_id TEXT,PRIMARY KEY(player_id,observed_date)) STRICT')
    db.execute('DELETE FROM _mlb_affiliation_daily');db.executemany('INSERT OR REPLACE INTO _mlb_affiliation_daily VALUES (?,?,?,?)',aff)
    db.execute('CREATE TABLE IF NOT EXISTS _mlb_game_profile_link_audit (game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _mlb_game_profile_link_audit');db.executemany('INSERT INTO _mlb_game_profile_link_audit VALUES (?,?)',[(x['game_id'],json.dumps(x)) for x in link_audit]);db.commit()
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',player_profiles=count,native_players=len(state),calendar_dates=total,t_minus_one_game_links=len(links),games_without_prior_rosters=sum(not x['prior_roster_sources'] for x in link_audit),same_day_transfer_ambiguities=ambiguities,missing={k:dict(count=v,total=count,percentage=round(v*100/count,4)) for k,v in missing.items()},meaning=dict(performance='Only collected game appearances completed by query date',participation='Appearances / collected single-date boxscore roster opportunities; multi-date final boxscores cannot date each player affiliation and are excluded from this denominator',history='Documented MLB club sequence; native franchise retained across name changes, affiliates and temporary teams excluded',tenure='Completed months since a documented acquisition into current observed club stint',injury='Official MLB injured-list reports carried until activation or a played appearance; no reported injury defaults false by user instruction. Complete medical episode counts are unavailable, so count becomes null after any positive report',years_played='Null: first debut date does not establish how many seasons a player actually served',links='Only affiliations and observed roster information known by t-1; no future lineup selection'))
    (ROOT/'reports/mlb_dated_profiles.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['missing','same_day_transfer_ambiguities']}));db.close()

if __name__=='__main__':main()
