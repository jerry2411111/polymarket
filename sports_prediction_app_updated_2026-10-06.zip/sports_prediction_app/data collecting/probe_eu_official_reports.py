"""Inspect official match report payloads using observed current client routes."""
import datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from epl_price_points import Sources

def brief(v):
 if isinstance(v,dict):return {k:(list(x)[:20] if isinstance(x,dict) else dict(length=len(x),first_keys=list(x[0]) if x and isinstance(x[0],dict) else None) if isinstance(x,list) else x) for k,x in v.items()}
 return dict(type=type(v).__name__,length=len(v)) if isinstance(v,(list,str)) else v

def main():
 db=sqlite3.connect(DB);c=HistoryClient();rows=[];HOSTS.update({'ma-api.ligue1.fr','bundesliga-web-prod.europe-west1.firebasedatabase.app'})
 for mid in ['l1_championship_match_71794']:
  url='https://ma-api.ligue1.fr/championship-match/'+mid
  try:
   d,r=c.get(url);rows.append(dict(kind='ligue1_match',request_id=r['request_id'],url=url));print('LIGUE1',r['request_id'],json.dumps(brief(d),ensure_ascii=False),flush=True)
  except Exception as e:print('LIGUE1 ERROR',str(e),flush=True)
 for rid,kind in [('3b142708657b446a91eb34ab262435b5','bundesliga'),('aea7cd9071d4493ea96242219b4e14cc','laliga')]:
  r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);soup=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
  for script in soup.find_all('script',type='application/json'):
   d=json.loads(script.get_text())
   if kind=='laliga':
    p=d['props']['pageProps'];print('LALIGA PROPS',json.dumps(brief(p),ensure_ascii=False),flush=True)
   else:
    for key,v in d.items():
     if not key.startswith('_getDataFromFirebase-') or '/DFL-SEA-0001K7/' not in key:continue
     print('BUNDESLIGA',key,json.dumps(brief(v),ensure_ascii=False),flush=True)
     if key.endswith('/lineup'):url='https://bundesliga-web-prod.europe-west1.firebasedatabase.app'+key.removeprefix('_getDataFromFirebase-')+'.json'
     else:continue
     data,rr=c.get(url);assert data==v;rows.append(dict(kind='bundesliga_lineup',url=url,request_id=rr['request_id'],official_page_request_id=rid));print('BUNDESLIGA EXACT PAGE API',rr['request_id'],flush=True)
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=rows,new_requests=c.requests);(ROOT/'reports/eu_official_report_probes.json').write_text(json.dumps(report,indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
