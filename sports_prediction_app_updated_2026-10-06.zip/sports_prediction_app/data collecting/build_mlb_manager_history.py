"""Official MLB head-manager observations, date profiles and collected results."""
import collections,datetime as dt,hashlib,json,sqlite3
from build_history_catalog import DB
from build_nba_dated_profiles import months
from history_index import records
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone()
    wanted={r[0] for r in db.execute("SELECT game_id FROM polymarket_pre_match WHERE league='MLB' UNION SELECT game_id FROM kalshi_pre_match WHERE league='MLB'")};gs={i:json.loads(b) for i,b in db.execute('SELECT * FROM _mlb_canonical_games') if i in wanted}
    observations={(t,d):json.loads(b) for t,d,b in db.execute('SELECT * FROM _official_mlb_coach_observations')};source={r['request_id']:r for r in records(ROOT)};needed={(str(t),g['date']) for g in gs.values() for t in g['team_ids']}
    missing_checks=needed-set(observations)
    assert not missing_checks,('Complete game-date manager acquisition first',len(missing_checks))
    facts=[];issues=[];hashes=set();rawchecks=0;names={}
    team_names=collections.defaultdict(list)
    for g in gs.values():
        for tid,name in zip(g['team_ids'],g['teams']):team_names[str(tid)].append((g['date'],name))
    def tm(tid,day):
        before=[x for x in team_names[tid] if x[0]<=day]
        return max(before)[1] if before else min(team_names[tid])[1]
    interim_proof=json.loads((ROOT/'reports/mlb_interim_manager_verification.json').read_text())
    montgomery=next(x for e in interim_proof['dated_examples'] for x in e['coaches'] if x['person']['id']==119268)
    goins=next(x for e in interim_proof['dated_examples'] for x in e['coaches'] if x['person']['id']==572365)
    names['MLB_MANAGER:119268']='Ray Montgomery';names['MLB_MANAGER:572365']='Ryan Goins'
    def manager(o):
        # Formal manager Washington and interim manager Montgomery coexist
        # in the official roster; the dated interim takes team responsibility.
        interim=[m for m in o.get('managers',[]) if m['jobId']=='NTRM']
        if len(interim)==1:return interim[0]
        if o.get('team_id')=='108' and '2025-06-20'<=o['date']<'2025-06-27':return montgomery
        return o['managers'][0] if len(o.get('managers',[]))==1 else None
    for (tid,day),o in observations.items():
        r=source[o['request_id']];raw=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];hashes.add(r['request_id']);d=json.loads(raw);assert str(d['teamId'])==tid
        actual=[dict(x,pointer='/roster/'+str(n)) for n,x in enumerate(d['roster']) if x.get('jobId') in ['MNGR','NTRM']];assert actual==o['managers'];rawchecks+=len(actual)
        if manager(o):names['MLB_MANAGER:'+str(manager(o)['person']['id'])]=manager(o)['person']['fullName']
    for g in gs.values():
        for side,tid in enumerate(g['team_ids']):
            if g.get('spans_multiple_local_dates'):
                issues.append(dict(game_id=g['game_id'],team=g['teams'][side],reason='Multi-date game needs explicit credited-manager evidence; roster on original date is insufficient',request_id=g['result_request_id']));continue
            o=observations[str(tid),g['date']];m=manager(o)
            if not m:issues.append(dict(game_id=g['game_id'],team=g['teams'][side],reason='Missing or multiple official head-manager roster entries',request_id=o['request_id']));continue
            if str(tid)=='108' and g['date'] in ['2025-09-13','2025-09-14']:m=goins
            mid='MLB_MANAGER:'+str(m['person']['id']);day=g['completion_local_date']
            if str(tid)=='108' and g['date']=='2025-09-13':day=max(day,'2025-09-14') # First acquired dated report confirms the two-game replacement on Sep 14.
            facts.append((mid,m['person']['fullName'],'Baseball','MLB',g['teams'][side],g['game_id'],day,g['home_away'].split(';')[side],g['scores'][side],g['scores'][1-side],int(g['winner']==g['teams'][side])))
    byday=collections.defaultdict(list)
    for (tid,day),o in observations.items():
        if tid not in ['159','160']:byday[day].append((tid,o))
    games=collections.defaultdict(list)
    for g in gs.values():games[(dt.date.fromisoformat(g['date'])-dt.timedelta(days=1)).isoformat()].append(g)
    perf=collections.defaultdict(list)
    for f in facts:perf[f[6]].append(f)
    current={};state={};profiles=[];links=[];ambiguities=[];transition_audit=[]
    first=dt.date.fromisoformat(start);total=(dt.date.fromisoformat(end)-first).days+1
    for n in range(total):
        day=(first+dt.timedelta(days=n)).isoformat()
        for tid,o in byday[day]:
            m=manager(o);mid='MLB_MANAGER:'+str(m['person']['id']) if m else None;prev=current.get(tid)
            if prev and prev['mid']!=mid and prev['mid'] in state:state[prev['mid']]['team_id']=None;state[prev['mid']]['tenure_start']=None
            if mid:
                p=state.setdefault(mid,dict(team_id=tid,history_ids=[],history=[],tenure_start=None,games=0,wins=0))
                if p['team_id'] not in [None,tid] and current.get(p['team_id'],{}).get('mid')==mid:
                    ambiguities.append(dict(manager_id=mid,date=day,team_ids=[p['team_id'],tid],reason='Same manager observed in two permanent clubs'));p['team_id']=None
                else:p['team_id']=tid
                if not p['history_ids'] or p['history_ids'][-1]!=tid:p['history_ids'].append(tid);p['history'].append(tm(tid,day))
                if not prev or prev['mid']!=mid:
                    exact=bool(prev and (dt.date.fromisoformat(day)-dt.date.fromisoformat(prev['date'])).days==1)
                    p['tenure_start']=day if exact else None;transition_audit.append(dict(team_id=tid,manager_id=mid,first_observed_date=day,previous_observed_date=prev['date'] if prev else None,previous_manager_id=prev['mid'] if prev else None,exact_daily_transition=exact))
            current[tid]=dict(mid=mid,date=day)
        for f in perf[day]:
            p=state.setdefault(f[0],dict(team_id=None,history_ids=[],history=[],tenure_start=None,games=0,wins=0));p['games']+=1;p['wins']+=f[10]
        for mid,p in state.items():
            if not p['team_id']:continue
            profiles.append((mid,names[mid],'Baseball','MLB',tm(p['team_id'],day),None,','.join(p['history']) or None,p['wins']/p['games'] if p['games'] else None,day))
        for g in games[day]:
            for tid in g['team_ids']:
                # Use the exact t-1 roster response; never tomorrow's manager.
                o=observations.get((str(tid),day));m=manager(o) if o else None
                if m:
                    mid='MLB_MANAGER:'+str(m['person']['id'])
                    if mid in state and state[mid]['team_id']:links.append((g['game_id'],mid,day))
    assert len({(f[0],f[5]) for f in facts})==len(facts),'Same manager attached to both sides of one game'
    with db:
        db.execute("DELETE FROM _manager_game_results WHERE league='MLB'");db.executemany('INSERT INTO _manager_game_results VALUES (?,?,?,?,?,?,?,?,?,?,?)',facts)
        db.execute("DELETE FROM game_manager_profiles WHERE game_id LIKE 'MLB_%'");db.execute("DELETE FROM manager_profiles WHERE league='MLB'");db.executemany('INSERT INTO manager_profiles VALUES (?,?,?,?,?,?,?,?,?)',profiles);db.executemany('INSERT OR IGNORE INTO game_manager_profiles VALUES (?,?,?)',links)
        db.execute('CREATE TABLE IF NOT EXISTS _mlb_manager_transition_audit (body TEXT NOT NULL)');db.execute('DELETE FROM _mlb_manager_transition_audit');db.executemany('INSERT INTO _mlb_manager_transition_audit VALUES (?)',[(json.dumps(x),) for x in transition_audit])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',source_hash_checks=len(hashes),raw_manager_checks=rawchecks,collected_games=len(gs),manager_game_facts=len(facts),missing_game_manager_rows=len(issues),missing_game_manager_percentage=round(100*len(issues)/(2*len(gs)),4),daily_profile_rows=len(profiles),native_manager_ids=len(state),t_minus_one_links=len(links),exact_transitions=sum(x['exact_daily_transition'] for x in transition_audit),unconfirmed_stint_starts=sum(not x['exact_daily_transition'] for x in transition_audit),issues=issues,ambiguities=ambiguities,acting_manager_source_request_ids=[p['request_id'] for p in interim_proof['source_pages']],meaning=dict(manager='Official club head/interim manager for game date, with documented Washington/Montgomery and two-game Goins corrections; brief replacements not comprehensively verified',performance='Only selected games completed and manager responsibility documented by as-of date',tenure='Months only when consecutive dated official roster observations establish the transition',history='Observed manager-club sequence; full pre-collection career count remains null'))
    (ROOT/'reports/mlb_manager_history.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['issues','ambiguities']}));db.close()

if __name__=='__main__':main()
