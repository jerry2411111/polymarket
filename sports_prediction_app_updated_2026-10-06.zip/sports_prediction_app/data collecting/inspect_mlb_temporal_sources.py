"""Small read-only source examples before temporal normalization."""
import collections,json,sqlite3
from build_history_catalog import DB

db=sqlite3.connect(DB,timeout=60)
for name in ['manager_profiles','game_manager_profiles','_manager_game_results','_mlb_player_transaction_history','_official_mlb_coach_observations']:
    print(name,db.execute('SELECT sql FROM sqlite_master WHERE name=?',(name,)).fetchone())
for pid in ['592450','641933','660271']:
    row=db.execute('SELECT body FROM _mlb_player_transaction_history WHERE player_id=?',(pid,)).fetchone()
    if row:
        b=json.loads(row[0]);print('PERSON',pid,b['player_name'],len(b.get('records',[])))
        for x in b.get('records',[])[:3]+b.get('records',[])[-5:]:print(json.dumps(x,ensure_ascii=False))
codes=collections.Counter();example={}
for b, in db.execute('SELECT body FROM _official_mlb_transactions'):
    b=json.loads(b);x=b.get('raw',b.get('raw_transaction',{}))
    if not x:
        print('TRANSACTION BODY',json.dumps(b));break
    key=x.get('typeCode'),x.get('typeDesc');codes[key]+=1;example.setdefault(str(key),x)
print('CODES',codes)
for key,x in example.items():print('TYPE',key,json.dumps(x))
for table in ['_mlb_canonical_games','_official_mlb_coach_observations']:
    print('SAMPLE',table,db.execute('SELECT body FROM '+table+' LIMIT 1').fetchone()[0][:2500])
db.close()
