import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for code,table in [('UCL','uefa'),('SEA','seriea'),('BUN','bundesliga')]:
 r=json.loads(db.execute('SELECT body FROM _official_'+table+'_game_reports LIMIT 1').fetchone()[0]);s=r['sources']
 if code=='UCL':
  pe=s['match']['data']['playerEvents'];print('UEFA PLAYER EVENTS',list(pe))
  for k,v in pe.items():print(k,json.dumps(v[:1] if isinstance(v,list) else v)[:1100])
  print('COACH TYPES',[{k:v for k,v in c.items() if k not in ['person','imageUrl']} for c in s['lineups']['data']['homeTeam']['coaches']])
 elif code=='SEA':
  seen=set()
  for e in s['feed']['data']['events']:
   if e['type'] in seen or e['type'] not in ['goal','penalty-goal','own-goal','substitution','red-card','yellow-red-card','injury-event']:continue
   seen.add(e['type']);print('SEA',e['type'],json.dumps(e,ensure_ascii=False)[:2600])
 else:
  found=False
  for b, in db.execute('SELECT body FROM _official_bundesliga_game_reports'):
   for e in json.loads(b)['sources']['match']['data']['liveBlogEntries'].values():
    if 'assist' in e.get('detail',{}):print('BUN ASSIST',json.dumps(e['detail']['assist']));found=True;break
   if found:break
db.close()
