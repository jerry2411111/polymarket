import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for n,b in db.execute('SELECT * FROM _official_nhl_game_reports'):
 r=json.loads(b)
 if any(not x['start_utc'] for x in r['breaks']):print(json.dumps({k:r[k] for k in ['official_game_id','date','teams','actual_start_utc','breaks','period_clock_events','issues']}))
db.close()
