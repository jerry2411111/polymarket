﻿import sqlite3,json
from build_history_catalog import DB
db=sqlite3.connect(DB);fs=[json.loads(b) for (b,) in db.execute('SELECT body FROM _nba_ranking_candidate_facts')]
for pub in ['espn','cbs_sports','action_network']:
 a={f['player_id']:f['rank'] for f in fs if f['publisher_key']==pub and '2024' in f['list_id'] and 'syndicated' not in f['list_id']};b=[f for f in fs if f['publisher_key']==pub and 'syndicated' in f['list_id']];diff=[(f['player_name'],a.get(f['player_id']),f['rank']) for f in b if a.get(f['player_id'])!=f['rank']];print(pub,'compared',len(b),'differences',diff)
