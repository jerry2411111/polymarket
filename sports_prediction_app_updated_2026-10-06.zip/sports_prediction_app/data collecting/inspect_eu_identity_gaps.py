"""Print only unresolved person identity groups and their dated official roles."""
import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB);report=json.loads((ROOT/'reports/eu_person_registry.json').read_text())
for issue in report['issues']:
 print('ISSUE',json.dumps(issue))
 for pid in issue.get('source_person_ids',[]):
  c=json.loads(db.execute('SELECT body FROM _eu_person_crosswalk WHERE source_person_id=?',(pid,)).fetchone()[0]);print('PERSON',pid,c['names'],c['birth_date'])
  rs=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_source_manager_game_facts WHERE manager_id=?',(pid,))];print('ROLES',[{k:r.get(k) for k in ['game_id','manager_name','team_name','game_date','request_id']} for r in sorted(rs,key=lambda r:r['game_date'])[:3]])
cross={pid:cid for pid,cid in db.execute('SELECT source_person_id,person_id FROM _eu_person_crosswalk')};groups=collections.defaultdict(list)
for pid,gid,b in db.execute('SELECT * FROM _eu_source_player_game_facts'):groups[cross[pid],gid].append(json.loads(b))
for (pid,gid),rows in groups.items():
 if len(rows)>1:print('SAME GAME COLLISION',pid,gid,[{k:p.get(k) for k in ['player_id','player_name','side','did_play','starter','score','assists','minutes','official_team_id','external_ids']} for p in rows])
db.close()
