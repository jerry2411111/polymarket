"""Compact soccer outputs retain the underlying competition and independent draw prices."""
from schema import HOURS,PRE_COLUMNS,INGAME_COLUMNS
EU_PRE_COLUMNS=['match','date','timestamp','game_type','league','competition','season']+[f'{side}_pre_{h}_{kind}' for h in HOURS for side in ['teamA','teamB','draw'] for kind in ['odd','p']]+['location','home_away','final','teamA_final_score','teamB_final_score','game_id']
EU_INGAME_COLUMNS=['match','game_type','league','competition','season','timestamp','checkpoint','teamA_ingame_odd','teamB_ingame_odd','draw_ingame_odd','teamA_ingame_p','teamB_ingame_p','draw_ingame_p','teamA_score','teamB_score','game_id']

def refresh_main_views(db):
    from league_odds import installed, refresh_views
    if installed(db):
        refresh_views(db)
        return
    exists=lambda name:bool(db.execute('SELECT 1 FROM sqlite_master WHERE name=?',(name,)).fetchone())
    extended=all(exists(p+'_eu_soccer_pre_match') and exists(p+'_eu_soccer_in_game') for p in ['polymarket','kalshi']);pre=[c for c in (EU_PRE_COLUMNS if extended else PRE_COLUMNS) if not c.startswith('draw_')];ing=[c for c in (EU_INGAME_COLUMNS if extended else INGAME_COLUMNS) if not c.startswith('draw_')];queries=[];inqueries=[]
    for provider in ['polymarket','kalshi']:
        oldpre=','.join('league AS competition' if c=='competition' else 'NULL AS "'+c+'"' if c.startswith('draw_') else '"'+c+'"' for c in pre)
        olding=','.join('i.league AS competition' if c=='competition' else 'NULL AS "'+c+'"' if c.startswith('draw_') else 'i."'+c+'"' for c in ing)
        queries.append(f"SELECT {oldpre},'{provider}' AS provider FROM {provider}_pre_match")
        inqueries.append(f"SELECT {olding},p.date,'{provider}' AS provider FROM {provider}_in_game i JOIN {provider}_pre_match p USING(game_id)")
        if extended:
            queries.append("SELECT "+','.join('"'+c+'"' for c in pre)+f",'{provider}' AS provider FROM {provider}_eu_soccer_pre_match")
            inqueries.append("SELECT "+','.join('i."'+c+'"' for c in ing)+f",p.date,'{provider}' AS provider FROM {provider}_eu_soccer_in_game i JOIN {provider}_eu_soccer_pre_match p USING(game_id)")
    db.execute('DROP VIEW IF EXISTS main');db.execute('CREATE VIEW main AS '+' UNION ALL '.join(queries));db.execute('DROP VIEW IF EXISTS in_game');db.execute('CREATE VIEW in_game AS '+' UNION ALL '.join(inqueries))
