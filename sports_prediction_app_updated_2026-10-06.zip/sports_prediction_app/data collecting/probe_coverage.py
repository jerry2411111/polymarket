"""Small real endpoint probes after reading official API specifications."""
import json,re
from probe_history import Client,ROOT

def main():
 c=Client(ROOT);out=[]
 cases=[
  ('https://external-api.kalshi.com/trade-api/v2/milestones',{'limit':3,'minimum_start_date':'2023-09-13T00:00:00Z','type':'basketball_game'}),
  ('https://external-api.kalshi.com/trade-api/v2/historical/markets',{'limit':3,'series_ticker':'KXNBAGAME'}),
  ('https://external-api.kalshi.com/trade-api/v2/structured_targets',{'limit':3,'type':'basketball_team'}),
  ('https://gamma-api.polymarket.com/events',{'limit':3,'closed':'true','order':'endDate','ascending':'true','end_date_min':'2023-09-13T00:00:00Z','tag_id':745}),
  ('https://docs.statsapi.mlb.com/assets/js/main.1902ab9b.js',{}),
 ]
 for url,params in cases:
  try:
   doc=url.endswith('.js');d,r=c.get(url,params,document=doc)
   if doc:
    t=d.decode('utf-8');summary=[t[max(0,m.start()-100):m.start()+250] for m in re.finditer(r'openapi|swagger|sign.?in|/docs/|/api/v1|oauth',t,re.I)][:30]
   elif isinstance(d,list):summary=[{k:x.get(k) for k in ['id','title','startDate','endDate','startTime','slug','score']} for x in d]
   else:summary=d
   out.append(dict(endpoint=url,parameters=params,request_id=r['request_id'],data=summary))
  except Exception as e:out.append(dict(endpoint=url,parameters=params,error=str(e)))
 (ROOT/'reports/coverage_probes.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
 print('Coverage probes saved; inspect selected fields in reports/coverage_probes.json',flush=True)
if __name__=='__main__':main()
