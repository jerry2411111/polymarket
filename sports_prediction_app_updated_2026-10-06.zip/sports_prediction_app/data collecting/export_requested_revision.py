"""Publish revised league projections and verify every written batch."""
import collections,csv,datetime as dt,json,sqlite3,hashlib,argparse
import pyarrow as pa
import pyarrow.parquet as pq
from build_history_catalog import DB
from probe_history import ROOT
from temporal_queries import PLAYER_OUTPUT,FLAGS
from ranking_policy import active_flags

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--manager-performance-only',action='store_true');ap.add_argument('--profiles-only',action='store_true');ap.add_argument('--performance-only',action='store_true');args=ap.parse_args()
 db=sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True,timeout=120);out=[]
 for league in ['NBA','MLB','NHL','EU soccer']:
  dest=ROOT/'data/result'/league.lower().replace(' ','_')
  for name in (['manager_performance'] if args.manager_performance_only else ['player_profiles'] if args.profiles_only else ['player_performance'] if args.performance_only else ['manager_profiles','player_profiles','player_performance']):
   cols=PLAYER_OUTPUT+active_flags(db,league,FLAGS) if name=='player_performance' else [r[1] for r in db.execute('PRAGMA table_info('+name+')')]
   text={'player_id','player_name','manager_id','manager_name','game_type','league','team','as_of_date','performance_status'};ints={'games_played','home_times','away_times'}
   types={r[1]:r[2] for r in db.execute('PRAGMA table_info('+name+')')}
   if name in ['player_performance','manager_performance']:types={c:'TEXT' if c in text else 'INTEGER' if c in ints or '_top_' in c else 'REAL' for c in cols}
   schema=pa.schema([(c,pa.int64() if types.get(c)=='INTEGER' else pa.float64() if types.get(c)=='REAL' else pa.string()) for c in cols])
   sql='SELECT '+','.join(cols)+' FROM '+name+' WHERE league=?';total=db.execute('SELECT count(*) FROM '+name+' WHERE league=?',(league,)).fetchone()[0]
   cur=db.execute(sql,(league,));n=0;mark=10;missing=collections.Counter();zero=collections.Counter()
   temp=dest/(name+'.revised.parquet');csvtemp=dest/(name+'.revised.csv');checks=[]
   with csvtemp.open('w',newline='',encoding='utf-8') as f,pq.ParquetWriter(temp,schema,compression='zstd') as w:
    cw=csv.writer(f);cw.writerow(cols)
    while rows:=cur.fetchmany(25000):
     arr=pa.Table.from_arrays([pa.array(v,type=schema.field(c).type) for c,v in zip(cols,zip(*rows))],schema=schema)
     w.write_table(arr,row_group_size=len(rows));cw.writerows(rows)
     checks.append(hashlib.sha256(json.dumps(arr.to_pydict(),sort_keys=True,separators=(',',':')).encode()).hexdigest())
     for i,c in enumerate(cols):missing[c]+=arr.column(i).null_count
     n+=len(rows)
     while n*100//total>=mark:print('REVISED EXPORT',league,name,mark,'percent;',n,'/',total,flush=True);mark+=10
   pf=pq.ParquetFile(temp);assert pf.metadata.num_rows==n==total
   for i,expected in enumerate(checks):
    arr=pf.read_row_group(i)
    assert hashlib.sha256(json.dumps(arr.to_pydict(),sort_keys=True,separators=(',',':')).encode()).hexdigest()==expected,(league,name,i)
   pf.close()
   with csvtemp.open(newline='',encoding='utf-8') as f:
    reader=csv.reader(f);assert next(reader)==cols
    assert sum(1 for _ in reader)==n
   for c in cols:
    if '_top_' in c:assert missing[c]<n,(league,'100% missing flag',c)
   temp.replace(dest/(name+'.parquet'));csvtemp.replace(dest/(name+'.csv'))
   out.append(dict(league=league,table=name,rows=n,columns=len(cols),parquet_all_values_verified=True,csv_rows_verified=True,missing={c:dict(count=missing[c],percentage=100*missing[c]/n if n else 0) for c in cols}))
   (ROOT/'reports'/('revised_manager_performance_exports.json' if args.manager_performance_only else 'revised_zero_profile_exports.json' if args.profiles_only else 'revised_player_performance_exports.json' if args.performance_only else 'revised_exports.json')).write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),outputs=out),indent=2),encoding='utf-8')
 db.close()
if __name__=='__main__':main()
