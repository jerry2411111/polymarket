"""Bounded as-of recovery for missing, post-creation MLB lookback slots."""
import collections,concurrent.futures,datetime as dt,json,sqlite3
from build_history_catalog import DB
from core import utc
from history_client import HistoryClient
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);cs={json.loads(b)['contract_id']:json.loads(b) for b, in db.execute("SELECT body FROM _mlb_market_candidates WHERE json_extract(body,'$.provider')='polymarket'")};jobs=[];skipped=0
    for b, in db.execute("SELECT body FROM _history_selections WHERE json_extract(body,'$.provider')='polymarket' AND json_extract(body,'$.game_id') LIKE 'MLB_%'"):
        a=json.loads(b)
        if not a['target'].startswith('pre_') or a['normalized_price'] is not None:continue
        c=cs[a['contract_id']];target=utc(a['target_timestamp_utc']).timestamp();ask=int(target)-(1 if a['target']=='pre_0' and int(target)==target else 0)
        if utc(c['open']).timestamp()>ask:skipped+=1;continue
        jobs.append(dict(game_id=a['game_id'],contract_id=a['contract_id'],target=a['target'],as_of=ask,target_timestamp=target))
    db.execute('CREATE TABLE IF NOT EXISTS _mlb_polymarket_asof (job_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();c=HistoryClient();counts=collections.Counter();resolutions=collections.Counter();milestone=10
    def fetch(j):
        ask=j['as_of'];ids=[];x=None
        try:
            for _ in range(4):
                d,r=c.get('https://data-api.polymarket.com/v2/prices-history',dict(token_id=j['contract_id'],as_of=ask));ids.append(r['request_id']);assert not d.get('pagination',{}).get('next_cursor') and len(d['data'])<=1
                x=d['data'][0] if d['data'] else None
                if not x:break
                assert x['timestamp']<=ask and 0<=x['price']<=1
                if x['resolution_seconds']>0 and x['timestamp']+x['resolution_seconds']<=j['target_timestamp']:break
                ask=x['timestamp']-1
            valid=bool(x and x['resolution_seconds']>0 and x['timestamp']+x['resolution_seconds']<=j['target_timestamp'])
            return dict(**j,status='ok',request_ids=ids,point=x,usable=valid)
        except Exception as e:return dict(**j,status='error',request_ids=ids,error=type(e).__name__+': '+str(e))
    print('MLB POLYMARKET MISSING TARGETS',len(jobs),'eligible;',skipped,'precede contract creation',flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        for n,r in enumerate(pool.map(fetch,jobs),1):
            key=r['contract_id']+':'+str(r['as_of']);db.execute('INSERT OR REPLACE INTO _mlb_polymarket_asof VALUES (?,?)',(key,json.dumps(r)));db.commit();counts[r['status']]+=1;counts['usable']+=bool(r.get('usable'))
            if r.get('usable'):resolutions[r['point']['resolution_seconds']]+=1
            while n*100//len(jobs)>=milestone:
                print('MLB POLYMARKET RECOVERY',milestone,'percent;',n,'/',len(jobs),'results',dict(counts),flush=True);milestone+=10
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),eligible_missing_targets=len(jobs),targets_before_contract_creation=skipped,new_requests=c.requests,results=dict(counts),resolutions=dict(resolutions),note='Only missing targets after contract creation; no future observation, interpolation or ambiguous zero-duration settlement tick accepted')
    (ROOT/'reports/mlb_polymarket_missing_targets.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
