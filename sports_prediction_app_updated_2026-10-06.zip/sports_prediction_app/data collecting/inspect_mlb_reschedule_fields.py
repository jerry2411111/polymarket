import collections,json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB);examples=[];keys=collections.Counter()
for b, in db.execute('SELECT body FROM _official_mlb_schedule'):
    g=json.loads(b);r=g['raw_game'];extra={k:v for k,v in r.items() if 'resched' in k.lower() or 'resume' in k.lower()};keys.update(extra.keys())
    if extra and len(examples)<12:examples.append(dict(id=g['official_game_id'],date=g['official_date'],teams=g['teams'],gameDate=g['scheduled_start_utc'],extra=extra))
print(keys);print(json.dumps(examples,indent=2))
