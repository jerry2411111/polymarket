"""Follow closing-date pages beyond the last requested GAME date."""
import datetime as dt,json
from history_client import HistoryClient
from probe_history import ROOT

def main():
    c=HistoryClient();parts=[];unique=set();moneylines=set()
    # The cutoff is a game-date cutoff, not a contract-closing-date cutoff.
    # Two weeks of overlapping future closing dates cover this observed edge;
    # successful official game matching still excludes future fixtures.
    for n in range(23):
        day=dt.date(2026,9,8)+dt.timedelta(days=n);end=day+dt.timedelta(days=1);offset=0;seen=set();ids=[]
        while True:
            q=dict(tag_id=100381,end_date_min=day.isoformat()+'T00:00:00Z',end_date_max=end.isoformat()+'T00:00:00Z',order='id',ascending='true',limit=100,offset=offset)
            d,r=c.get('https://gamma-api.polymarket.com/events',q,refresh=True);ids.append(r['request_id'])
            if not d:break
            for e in d:
                assert e['id'] not in seen,'Repeated event within closing-date pagination';seen.add(e['id']);unique.add(e['id'])
                assert day.isoformat()<=e['endDate'][:10]<=end.isoformat(),'Provider date filter not honored'
                moneylines.update(m['id'] for m in e.get('markets',[]) if m.get('sportsMarketType')=='moneyline')
            offset+=len(d)
            if offset>2000:raise ValueError('Single-day discovery exceeded offset bound; use documented keyset continuation')
        parts.append(dict(closing_date=day.isoformat(),events=len(seen),pagination_exhausted=True,request_ids=ids));print('MLB FINAL-WINDOW DISCOVERY',day.isoformat(),'events',len(seen),flush=True)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),game_date_cutoff='2026-09-14',closing_date_search_through='2026-09-30',events=len(unique),full_game_market_candidates=len(moneylines),partitions=parts,new_requests=c.requests,note='Future closing dates are discovery only. Only officially completed games within the requested game-date range may enter the data.')
    (ROOT/'reports/mlb_polymarket_final_window_discovery.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='partitions'}))

if __name__=='__main__':main()
