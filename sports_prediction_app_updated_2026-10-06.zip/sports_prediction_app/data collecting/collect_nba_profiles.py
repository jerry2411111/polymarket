"""Read official NBA roster biographies, one representative profile per team."""
import concurrent.futures,datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT
from build_history_catalog import DB

def next_data(b):
    node=BeautifulSoup(b,'html.parser').find('script',id='__NEXT_DATA__')
    if not node:raise ValueError('Official player page has no structured page data')
    return json.loads(node.string)['props']['pageProps']

def main():
    c=HistoryClient();b,r=c.get('https://www.nba.com/players',document=True);players=next_data(b)['players'];teams={}
    for p in players:
        if p['TEAM_ID']:teams.setdefault(p['TEAM_ID'],p)
    rows=[];issues=[]
    def fetch(p):
        url=f"https://www.nba.com/player/{p['PERSON_ID']}/{p['PLAYER_SLUG']}"
        try:
            b,r=c.get(url,document=True);player=next_data(b)['player'];info=player['info'];team=info['TEAM_CITY']+' '+info['TEAM_NAME']
            if info['TEAM_ID']!=p['TEAM_ID']:raise ValueError('Official roster team changed while collecting')
            entries=[]
            for x in player.get('roster',[]):
                if not x.get('BIRTH_DATE'):continue
                entries.append(dict(player_name=x['PLAYER'],official_player_id=x.get('PLAYER_ID'),league='NBA',team_name=team,birth_date=dt.datetime.strptime(x['BIRTH_DATE'],'%b %d, %Y').date().isoformat(),height=x.get('HEIGHT'),weight=x.get('WEIGHT'),years_played=x.get('EXP'),how_acquired=x.get('HOW_ACQUIRED'),observed_at_utc=r['retrieved_at_utc'],request_id=r['request_id'],source_url=url))
            if not entries:raise ValueError('Official profile did not return roster birth dates')
            return entries,None
        except Exception as e:return [],dict(team=p['TEAM_CITY']+' '+p['TEAM_NAME'],url=url,error=str(e))
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for n,(items,error) in enumerate(pool.map(fetch,teams.values()),1):
            rows.extend(items)
            if error:issues.append(error)
            print('NBA PROFILES',n,len(teams),'roster entries',len(rows),'issues',len(issues),flush=True)
    db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _official_player_biographies (league TEXT NOT NULL,player_name TEXT NOT NULL,observed_at_utc TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(league,player_name,observed_at_utc)) STRICT')
    for x in rows:db.execute('INSERT OR IGNORE INTO _official_player_biographies VALUES (?,?,?,?)',(x['league'],x['player_name'],x['observed_at_utc'],json.dumps(x)))
    db.commit();db.close();(ROOT/'reports/official_nba_biographies.json').write_text(json.dumps(dict(teams_attempted=len(teams),roster_entries=len(rows),new_requests=c.requests,issues=issues),indent=2),encoding='utf-8')

if __name__=='__main__':main()
