"""Capture official NBA date cards, including final scores and competition type.

The official public page embeds date-specific gameCardFeed JSON. This is a
website fallback for the league facts unavailable in the market APIs.
"""
import argparse,collections,concurrent.futures,datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from history_client import HistoryClient
from probe_history import ROOT
from build_history_catalog import DB

def parse(body,date,rid):
    soup=BeautifulSoup(body,'html.parser');script=soup.find('script',id='__NEXT_DATA__')
    if script is None:raise ValueError('Official NBA structured date page absent')
    p=json.loads(script.string)['props']['pageProps']
    if p.get('selectedDate')!=date:raise ValueError('Returned NBA date differs from requested date')
    feed=p.get('gameCardFeed',{})
    if feed.get('nextPageToken'):raise ValueError('NBA date feed requires pagination; refusing partial date')
    rows=[]
    for module in feed.get('modules',[]):
        for card in module.get('cards',[]):
            g=card.get('cardData',{})
            if not g.get('gameId') or g.get('gameStatus')!=3:continue
            teams=[g.get('awayTeam',{}),g.get('homeTeam',{})]
            if any(t.get('teamId') is None or t.get('score') is None for t in teams):raise ValueError('NBA final card lacks official teams/scores')
            scores=[int(t['score']) for t in teams]
            if scores[0]==scores[1]:raise ValueError('Tied NBA final card')
            kind=g.get('seasonType') or g.get('cardHat')
            periods=[{int(q['period']):int(q['score']) for q in t.get('periods',[])} for t in teams]
            short_format=kind=='All-Star' and all(len(q)<4 for q in periods)
            if all(periods) and [sum(q.values()) for q in periods]!=scores and not short_format:raise ValueError('NBA period totals disagree with final')
            cp=[[0,0]]+[[sum(q.get(n,0) for n in range(1,i+1)) if all(n in q for n in range(1,i+1)) else None for q in periods] for i in [1,2,3]]
            if short_format:cp=[[0,0]]+[[None,None] for _ in range(3)]
            rows.append(dict(league='NBA',season_year=g.get('seasonYear'),date=date,official_game_id=g['gameId'],official_team_ids=[str(t['teamId']) for t in teams],team_tricodes=[t.get('teamTricode') for t in teams],team_names=[t.get('teamName') for t in teams],scores=scores,break_scores=cp,start_utc=g.get('gameTimeUtc'),competition_type=kind,is_training=any(w in (kind or '').lower() for w in ['preseason','summer','exhibition']),source_url=g.get('shareUrl') or 'https://www.nba.com/game/'+g['gameId'],request_id=rid))
    return list({r['official_game_id']:r for r in rows}.values())

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--from-date',default='2024-01-01');ap.add_argument('--through-date',default=dt.date.today().isoformat());ap.add_argument('--limit',type=int);ap.add_argument('--all-calendar-dates',action='store_true');args=ap.parse_args()
    db=sqlite3.connect(DB,timeout=60)
    games=[json.loads(x[0]) for x in db.execute('SELECT body FROM _history_games')]
    dates=sorted({g['date'] for g in games if g['league']=='NBA' and args.from_date<=g['date']<=args.through_date});dates=dates[:args.limit] if args.limit else dates
    db.execute('CREATE TABLE IF NOT EXISTS _official_nba_schedule (official_game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit()
    client=HistoryClient();errors=[];count=0;types=collections.Counter()
    if args.all_calendar_dates:
        dates=set();calendar_sources=[]
        for year in range(int(args.from_date[:4]),int(args.through_date[:4])+1):
            body,r=client.get('https://www.nba.com/games',{'date':f'{year}-01-01'},document=True)
            soup=BeautifulSoup(body,'html.parser');p=json.loads(soup.find('script',id='__NEXT_DATA__').string)['props']['pageProps']
            calendar=p['allGamesInCurrentYear'].get(str(year))
            if not calendar:raise ValueError('Official NBA year calendar missing')
            dates.update(d for d,n in calendar.items() if n>0 and args.from_date<=d<=args.through_date)
            calendar_sources.append(dict(year=year,request_id=r['request_id'],calendar=calendar))
        dates=sorted(dates);dates=dates[:args.limit] if args.limit else dates
        (ROOT/'reports/official_nba_calendars.json').write_text(json.dumps(calendar_sources,indent=2),encoding='utf-8')
    def fetch(date):
        try:
            body,r=client.get('https://www.nba.com/games',{'date':date},document=True)
            return date,parse(body,date,r['request_id']),None
        except Exception as e:return date,[],str(e)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for n,(date,rows,error) in enumerate(pool.map(fetch,dates),1):
            if error:errors.append(dict(date=date,error=error))
            for r in rows:
                db.execute('INSERT OR REPLACE INTO _official_nba_schedule VALUES (?,?)',(r['official_game_id'],json.dumps(r)));types[r['competition_type']]+=1
            db.commit();count+=len(rows)
            if n%25==0 or n==len(dates):print('NBA OFFICIAL DATES',n,len(dates),'games',count,'issues',len(errors),flush=True)
    db.close();report=dict(dates=len(dates),final_games=count,competition_types=dict(types),new_requests=client.requests,errors=errors)
    (ROOT/'reports/official_nba_schedule_acquisition.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report),flush=True)

if __name__=='__main__':main()
