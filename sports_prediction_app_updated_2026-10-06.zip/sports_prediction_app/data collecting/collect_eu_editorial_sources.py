"""Retain public publisher/club documents for dated ranking and identity review."""
import datetime as dt,json,sqlite3
from urllib.parse import urlsplit
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
URLS=[
('ranking_review','france_football','https://www.uefa.com/ballondor/news/0292-1c33aa864c69-d47a84004f4d-1000--rodri-wins-/'),
('ranking_review','france_football','https://www.uefa.com/uefachampionsleague/news/029d-1ec96c30aa3f-f6868c869cbd-1000--ousmane-dembele-wins-2025-men-s-ballon-d-or/'),
('ranking_review','espn','https://espnpressroom.com/press-release/espn-com-announce-the-2025-fc-100-list-ranking-the-best-players-in-mens-soccer/'),
('ranking_review','sky_sports','https://www.skysports.com/football/news/11685/13411114/sky-sports-ranks-the-premier-leagues-top-25-players-ahead-of-2025-26-season'),
('ranking_review','bbc','https://www.bbc.co.uk/sport/football/articles/ckgm37r4z45o'),
('ranking_review','sports_illustrated','https://www.si.com/soccer/top-50-premier-league-players-of-all-time-digital-cover'),
('ranking_review','fourfourtwo','https://www.fourfourtwo.com/person/player/best-players-in-the-world-2025'),
('ranking_review','the_guardian','https://www.theguardian.com/football/ng-interactive/2025/dec/16/the-100-best-male-footballers-in-the-world-2025'),
('ranking_review','cbs_sports','https://www.cbssports.com/soccer/news/golazo-100-countdown-kylian-mbappe-vinicius-jr-top-the-best-mens-soccer-players-in-the-world-list-for-2024/'),
('identity','real_madrid','https://www.realmadrid.com/fr-FR/football/equipe-premiere/effectif/vinicius-paixao-de-oliveira-junior'),
('identity','laliga','https://www.laliga.com/en-GB/player/valverde-1'),
('ranking','goal','https://www.goal.com/en/lists/top-50-players-2024-25-european-season/blta1119bb143b33904'),
('ranking','goal','https://www.goal.com/en/lists/european-player-of-the-year-top-50-footballers-2025-26-season-ranked/bltf1921c49a32aa3b1'),
]
def main():
 db=sqlite3.connect(DB,timeout=60);c=HistoryClient();rows=[]
 with db:db.execute('CREATE TABLE IF NOT EXISTS _eu_editorial_sources (url TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
 for kind,publisher,url in URLS:
  HOSTS.add(urlsplit(url).hostname);out=dict(kind=kind,publisher=publisher,url=url)
  previous=db.execute('SELECT body FROM _eu_editorial_sources WHERE url=?',(url,)).fetchone()
  if previous and json.loads(previous[0])['status']=='UNAVAILABLE':
   rows.append(json.loads(previous[0]));continue
  try:
   raw,r=c.get(url,document=True);s=BeautifulSoup(raw,'html.parser');structured=[]
   for el in s.select('script[type="application/ld+json"]'):
    try:structured.append(json.loads(el.string or el.get_text()))
    except ValueError:pass
   out.update(status='RETRIEVED_REQUIRES_REVIEW',request_id=r['request_id'],raw_file=r['raw_file'],metadata=dict(title=s.title.get_text() if s.title else None,structured=structured),headings=[x.get_text(' ',strip=True) for x in s.select('h1,h2,h3')])
  except Exception as e:out.update(status='UNAVAILABLE',error=str(e))
  with db:db.execute('INSERT OR REPLACE INTO _eu_editorial_sources VALUES (?,?)',(url,json.dumps(out)))
  rows.append(out);print(kind,publisher,out['status'],flush=True)
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),new_requests=c.requests,sources=[{k:v for k,v in r.items() if k not in ['metadata','headings']} for r in rows]);(ROOT/'reports/eu_editorial_sources.json').write_text(json.dumps(report,indent=2),encoding='utf-8');db.close()
if __name__=='__main__':main()
