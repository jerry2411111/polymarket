"""Read actual provider and official identity variants for one label."""
import argparse,json,sqlite3
from build_history_catalog import DB
from eu_official_games import games
p=argparse.ArgumentParser();p.add_argument('competition');p.add_argument('text');a=p.parse_args();db=sqlite3.connect(DB);needle=a.text.lower();seen=set()
for g in games(db,a.competition).values():
 for s in ['away','home']:
  t=g[s]
  if any(needle in n.lower() for n in t['aliases']) and t['id'] not in seen:print('OFFICIAL',json.dumps(t,ensure_ascii=False));seen.add(t['id'])
n=0
for b, in db.execute('SELECT body FROM _eu_kalshi_markets WHERE competition=?',(a.competition,)):
 m=json.loads(b)
 if needle in m['yes_sub_title'].lower():print('KALSHI',json.dumps({k:m.get(k) for k in ['ticker','event_ticker','title','yes_sub_title','rules_primary','result']},ensure_ascii=False));n+=1
 if n==2:break
seen=set()
for b, in db.execute('SELECT body FROM _eu_pm_events WHERE event_id IN (SELECT event_id FROM _eu_pm_event_sources WHERE competition=?)',(a.competition,)):
 e=json.loads(b)
 for t in e.get('teams') or []:
  if needle in t['name'].lower() and t['id'] not in seen:print('POLYMARKET',json.dumps({k:t.get(k) for k in ['id','name','abbreviation','alias','providerId']},ensure_ascii=False));seen.add(t['id'])
 if len(seen)>=4:break
db.close()
