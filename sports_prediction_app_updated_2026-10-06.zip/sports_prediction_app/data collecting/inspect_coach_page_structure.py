import json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
u='https://www.nba.com/pacers/news/indiana-pacers-sign-head-coach-rick-carlisle-to-multi-year-extension'
b=json.loads(db.execute('SELECT body FROM _nba_coach_contract_revision_sources WHERE url=?',(u,)).fetchone()[0]);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(b['request_id'],)).fetchone()[0]);s=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
print('TEXT',b['text'][:1800]);print('TITLE',s.title)
for script in s.find_all('script'):
    text=script.string or script.get_text()
    if script.get('id')=='__NEXT_DATA__':
        def walk(x,path=''):
            if isinstance(x,dict):
                for k,v in x.items():walk(v,path+'/'+k)
            elif isinstance(x,list):
                for i,v in enumerate(x):walk(v,path+'/'+str(i))
            elif isinstance(x,str) and ('terms of the deal' in x or 'INDIANAPOLIS' in x):print('ARTICLE PATH',path,x[:1200])
        walk(json.loads(text))
db.close()
