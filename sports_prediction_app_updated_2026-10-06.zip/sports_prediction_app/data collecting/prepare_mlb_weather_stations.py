"""Map additional MLB game cities to nearby available official NOAA stations."""
import collections,datetime as dt,io,json,math,re,sqlite3
import pyarrow.parquet as pq
from bs4 import BeautifulSoup
from build_history_catalog import DB
from collect_history_weather import DOC,STATIONS
from history_client import HistoryClient
from probe_history import ROOT

def distance(a,b):
    lat1,lon1,lat2,lon2=map(math.radians,[a[0],a[1],b[0],b[1]])
    return 6371*2*math.asin(min(1,math.sqrt(math.sin((lat2-lat1)/2)**2+math.cos(lat1)*math.cos(lat2)*math.sin((lon2-lon1)/2)**2)))

def main():
    db=sqlite3.connect(DB,timeout=60);feeds={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_mlb_feeds')};cities={}
    for b, in db.execute('SELECT body FROM _mlb_canonical_games'):
        g=json.loads(b);f=feeds[g['official_game_id']];v=f['venue'];loc=v.get('location',{});city=loc.get('city');coordinates=loc.get('defaultCoordinates',{})
        if city not in STATIONS and coordinates.get('latitude') is not None:cities.setdefault((city,g['date'][:4]),dict(coordinates=[coordinates['latitude'],coordinates['longitude']],source_game_id=g['game_id'],source_request_id=f['request_id'],source_pointer='/gameData/venue/location/defaultCoordinates'))
    c=HistoryClient();b,dr=c.get(DOC+'ghcnh-station-list.txt',document=True);stations={}
    for line in b.decode().splitlines():
        parts=line.split(maxsplit=4)
        if len(parts)<5:continue
        try:lat,lon=float(parts[1]),float(parts[2])
        except ValueError:continue
        if abs(lat)<=90 and abs(lon)<=180:stations[parts[0]]=(lat,lon,line)
    available={};directory_ids={};directory_errors=[]
    for year in sorted({year for city,year in cities}):
        try:
            b,r=c.get(f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/parquet/',document=True)
            available[year]={m[1] for a in BeautifulSoup(b,'html.parser').find_all('a') if (m:=re.search(r'GHCNh_(.{11})_'+year+r'\.parquet$',a.get('href','')))};directory_ids[year]=r['request_id']
        except RuntimeError as e:
            directory_errors.append(dict(year=year,error=str(e)));available[year]=set(stations);directory_ids[year]=None
    rows=[];issues=[]
    for (city,year),proof in sorted(cities.items()):
        ranked=sorted((distance(proof['coordinates'],stations[s][:2]),s) for s in available[year] if s in stations)
        checked=[];hit=None
        for km,station in ranked[:30]:
            if km>75:break
            try:
                b,r=c.get(f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/parquet/GHCNh_{station}_{year}.parquet',document=True)
                pf=pq.ParquetFile(io.BytesIO(b));columns=pf.schema_arrow.names
                count=pf.metadata.num_rows
                usable=bool(count>=100 and 'temperature' in columns and 'DATE' in columns)
                checked.append(dict(station=station,distance_km=km,request_id=r['request_id'],rows=count,usable=usable))
                if usable:hit=(km,station,r['request_id']);break
            except RuntimeError as e:checked.append(dict(station=station,distance_km=km,error=str(e)))
        if hit is None:issues.append(dict(city=city,year=year,reason='No qualifying individual annual station archive in the 30 nearest candidates within 75 km',checked=checked));continue
        km,station,archive_id=hit
        body=dict(**proof,city=city,year=year,station=station,distance_km=km,station_directory_request_id=dr['request_id'],archive_directory_request_id=directory_ids[year],archive_request_id=archive_id,station_directory_row=stations[station][2],alternatives=checked,method='Nearest tested NOAA annual hourly archive with temperature and at least 100 rows, within 75 km of the official game venue; timestamp/field quality validated separately')
        rows.append((city,year,station,json.dumps(body)));print('MLB WEATHER STATION',city,year,station,round(km,2),'km',flush=True)
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _weather_city_stations (city TEXT,year TEXT,station_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(city,year)) STRICT');db.executemany('INSERT OR REPLACE INTO _weather_city_stations VALUES (?,?,?,?)',rows)
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),new_city_year_mappings=len(rows),unmapped=issues,directory_errors=directory_errors,new_requests=c.requests)
    (ROOT/'reports/mlb_weather_station_mapping.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));db.close()

if __name__=='__main__':main()
