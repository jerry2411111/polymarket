"""Official global person/career records for source-retained Opta/asset identities."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from collect_laliga_people import namekey
from probe_history import ROOT,HOSTS
BASE='https://sdp-prem-prod.premier-league-prod.pulselive.com/api'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--through-percent',type=int,default=100);a=ap.parse_args();db=sqlite3.connect(DB,timeout=60);people={};HOSTS.add('sdp-prem-prod.premier-league-prod.pulselive.com')
 for b, in db.execute("SELECT body FROM _eu_source_player_game_facts WHERE json_extract(body,'$.competition_code') IN ('LAL','FL1')"):
  p=json.loads(b);code=p['competition_code'];native=p['official_player_id'].removeprefix('p') if code=='LAL' and p['official_player_id'].startswith('p') else p.get('external_ids',{}).get('shortOptaId')
  if native is None or not str(native).isdigit():continue
  native=str(native);v=people.setdefault(native,dict(native_id=native,first_date=p['game_date'],source_person_ids=set(),names=set(),birth_dates=set(),lineup_request_ids=set(),codes=set()));v['first_date']=min(v['first_date'],p['game_date']);v['source_person_ids'].add(p['player_id']);v['names'].add(p['player_name']);v['names'].update(p.get('aliases',[]));v['lineup_request_ids'].add(p['roster_request_id']);v['codes'].add(code)
  if p.get('biography',{}).get('birth_date'):v['birth_dates'].add(p['biography']['birth_date'][:10])
 with db:db.execute('CREATE TABLE IF NOT EXISTS _official_eu_opta_people_sources (native_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
 done={pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _official_eu_opta_people_sources')};by_month=collections.defaultdict(list);selected=list(people.values())
 if a.pilot:
  selected=[]
  for code in ['LAL','FL1']:selected+=sorted((p for p in people.values() if code in p['codes']),key=lambda p:(p['first_date'],p['native_id']))[:3]
 for p in selected:
  for key in ['source_person_ids','names','birth_dates','lineup_request_ids','codes']:p[key]=sorted(p[key])
  by_month[p['first_date'][:7]].append(p)
 c=HistoryClient()
 def fetch(p):
  pid=p['native_id']
  if pid in done:return pid,done[pid]
  out=dict(p,sources={})
  try:
   raw,r=c.get(BASE+'/v1/players/'+pid);out['sources']['biography']=dict(request_id=r['request_id'],endpoint=r['endpoint'],raw=raw);assert isinstance(raw,list) and raw and all(str(x['id']['playerId'])==pid for x in raw),'No official native biography';aliases={namekey(n) for n in p['names']};assert any(namekey(x['name']['display']) in aliases for x in raw),'Official native person name differs from dated source'
   birth={x.get('dates',{}).get('birth') for x in raw}-{None}
   if p['birth_dates']:assert birth&set(p['birth_dates']),'Official native person DOB differs from dated Ligue 1 identity'
   out['biography_identity_verified']=True;raw,r=c.get(BASE+'/v1/players/'+pid+'/career');out['sources']['career']=dict(request_id=r['request_id'],endpoint=r['endpoint'],raw=raw);persons=raw.get('person',[]) if isinstance(raw,dict) else [];assert len(persons)==1 and str(persons[0].get('opId'))==pid,'No unambiguous native career response';out['status']='ok'
  except Exception as e:out.update(status='partial' if out.get('biography_identity_verified') else 'unavailable',error=type(e).__name__+': '+str(e))
  return pid,out
 day=dt.date(2024,1,1);parts=[];milestone=10
 while day<=dt.date(2026,9,14) and len(parts)<math.ceil(33*a.through_percent/100):
  month=day.strftime('%Y-%m');counts=collections.Counter()
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
   for pid,row in pool.map(fetch,by_month[month]):
    if pid not in done:
     with db:db.execute('INSERT OR REPLACE INTO _official_eu_opta_people_sources VALUES (?,?)',(pid,json.dumps(row)))
    counts[row['status']]+=1
  parts.append(dict(month=month,people=len(by_month[month]),counts=dict(counts)));out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Official global person biographies and dated club histories by first collected game date',pilot=a.pilot,total_people=len(selected),processed_months=len(parts),total_months=33,new_requests=c.requests,months=parts,scope='Personal constants and dated membership evidence only; source career performance totals are never added to collected-game performance');(ROOT/'reports'/('eu_opta_people_'+('pilot' if a.pilot else 'months')+'.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
  if counts:print('EU OFFICIAL PEOPLE',month,dict(counts),flush=True)
  while not a.pilot and milestone<=100 and len(parts)>=math.ceil(33*milestone/100):print('EU OFFICIAL PEOPLE DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print('EU OFFICIAL PEOPLE NEW REQUESTS',c.requests);db.close()

if __name__=='__main__':main()
