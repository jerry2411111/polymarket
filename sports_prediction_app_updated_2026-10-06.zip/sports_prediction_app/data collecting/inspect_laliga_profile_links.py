"""Read official player links from retained match HTML; inspect dated profile payloads."""
import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
from probe_eu_official_reports import brief

def main():
 db=sqlite3.connect(DB)
 for rid in ['aea7cd9071d4493ea96242219b4e14cc','d2973e644d1c4bd1bbc3e7e00ffadf37']:
  r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);text=(ROOT/r['raw_file']).read_text(encoding='utf-8');print('SOURCE',rid,'PLAYER LINKS',list(dict.fromkeys(re.findall(r'href="([^\"]*/player/[^\"]+)"',text)))[:10]);soup=BeautifulSoup(text,'html.parser');p=json.loads(soup.find('script',id='__NEXT_DATA__').get_text())['props']['pageProps']
  if 'player' in p:print('SQUADS',json.dumps(brief(p['allSquadsData']),ensure_ascii=False)[:1700]);print('PLAYER KEYS',list(p['player']))
 db.close()

if __name__=='__main__':main()
