"""Recover missing hourly lookbacks through official previous-observation queries."""
import collections,concurrent.futures,datetime as dt,json,sqlite3
from build_history_catalog import DB
from build_nhl_odds import load_points
from core import utc
from history_client import HistoryClient
from quote_selection import nearest_pregame
from probe_history import ROOT
from schema import HOURS

def main():
    db=sqlite3.connect(DB,timeout=60);cs={('polymarket',r['contract_id']):r for b, in db.execute('SELECT body FROM _nhl_market_candidates') if (r:=json.loads(b))['provider']=='polymarket'};games={g:json.loads(b) for g,b in db.execute('SELECT * FROM _nhl_canonical_games')};feeds={g:json.loads(b) for g,b in db.execute('SELECT * FROM _official_nhl_game_reports')}
    print('NHL PREVIOUS QUOTES: reading real retained observations',flush=True);points,_,_,_=load_points(db,cs);xs=collections.defaultdict(list)
    for x in points:
        c=cs['polymarket',x['contract_id']];opened=utc(c['open'])
        if x['resolution_seconds']>0 and (not opened or x['timestamp']>=opened.timestamp()):xs[x['contract_id']].append(x)
    jobs=[];before_open=0
    for c in cs.values():
        g=games[c['game_id']];f=feeds[g['official_game_id']];start=utc(f['actual_start_utc'] or g['start']).timestamp();opened=utc(c['open'])
        for h in HOURS:
            target=start-h*3600;ask=int(target)-(1 if h==0 and int(target)==target else 0)
            if opened and opened.timestamp()>ask:before_open+=1;continue
            if nearest_pregame(xs[c['contract_id']],target,start) is not None:continue
            jobs.append(dict(game_id=c['game_id'],contract_id=c['contract_id'],target='pre_'+str(h),as_of=ask,target_timestamp=target,open_timestamp=opened.timestamp() if opened else None))
    db.execute('CREATE TABLE IF NOT EXISTS _nhl_polymarket_asof (job_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();client=HistoryClient();counts=collections.Counter();resolutions=collections.Counter();milestone=10
    def fetch(j):
        ask=j['as_of'];ids=[];x=None
        try:
            for _ in range(8):
                d,r=client.get('https://data-api.polymarket.com/v2/prices-history',dict(token_id=j['contract_id'],as_of=ask));ids.append(r['request_id']);assert not d.get('pagination',{}).get('next_cursor') and len(d['data'])<=1
                x=d['data'][0] if d['data'] else None
                if not x:break
                assert x['timestamp']<=ask and 0<=x['price']<=1
                if x['resolution_seconds']>0 and x['timestamp']+x['resolution_seconds']<=j['target_timestamp']:break
                ask=x['timestamp']-1
            valid=bool(x and x['resolution_seconds']>0 and x['timestamp']+x['resolution_seconds']<=j['target_timestamp'] and (j['open_timestamp'] is None or x['timestamp']>=j['open_timestamp']))
            return dict(**j,status='ok',request_ids=ids,point=x,usable=valid)
        except Exception as e:return dict(**j,status='error',request_ids=ids,error=str(e))
    print('NHL PREVIOUS QUOTES',len(jobs),'eligible missing targets;',before_open,'before contract creation',flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        for n,r in enumerate(pool.map(fetch,jobs),1):
            db.execute('INSERT OR REPLACE INTO _nhl_polymarket_asof VALUES (?,?)',(r['contract_id']+':'+str(r['as_of']),json.dumps(r)));db.commit();counts[r['status']]+=1;counts['usable']+=bool(r.get('usable'))
            if r.get('usable'):resolutions[r['point']['resolution_seconds']]+=1
            while n*100//len(jobs)>=milestone:print('NHL PREVIOUS QUOTE RECOVERY',milestone,'percent;',n,'/',len(jobs),dict(counts),flush=True);milestone+=10
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),eligible_missing_targets=len(jobs),before_contract_creation=before_open,results=dict(counts),new_requests=client.requests,resolutions=dict(resolutions),meaning='Official as-of queries for missing slots only. No future bucket, interpolation or ambiguous zero-duration settlement observation accepted.')
    (ROOT/'reports/nhl_missing_previous_quotes.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
