import json,collections
from history_index import index,records,payload,real_milestones

def main():
 d=index(); print('COUNTS', {k:len(v) for k,v in d.items()})
 for league in ['NBA','MLB','NHL']:
  ts=[x[0] for x in d['teams'].values() if x[0]['details']['league']==league]
  print('TEAMS',league,json.dumps(ts[:2]));print('ALL TEAMS',[(x['id'],x['name'],x['details'].get('abbreviation'),x['details'].get('team_name')) for x in ts])
  ms=sorted([x for x in real_milestones(d) if x[1]['details']['league']==league],key=lambda x:x[1]['start_date'])
  print('MILESTONE',league,json.dumps(ms[0][1])[:4000])
  km=[x[0] for x in d['kalshi_markets'].values() if x[0]['event_ticker'].startswith({'NBA':'KXNBA','MLB':'KXMLB','NHL':'KXNHL'}[league])]
  print('MARKET',league,json.dumps(km[0])[:5500])
  ex=[x[0] for x in d['polymarket_events'].values() if any(m.get('sportsMarketType')=='moneyline' for m in x[0]['markets']) and x[0].get('ticker','').startswith(league.lower())]
  if ex:print('PM',league,json.dumps(ex[-1])[:5000])
 live={}
 for r in records():
  if r['status']==200 and r['endpoint'].endswith('/live_data/batch'):
   for x in payload(r)['live_datas']:live[x['milestone_id']]=x
 print('LIVE STATUSES',collections.Counter((x['details'].get('status'),x['details'].get('widget_status')) for x in live.values()))
 for k,v in live.items():
  if v['details'].get('player_stats'):
   print('PLAYER GAME',json.dumps(d['milestones'][k][0])[:3000]);print('PLAYER VALUES',list(v['details']['player_stats'].items())[:2]);break
 print('PLAYER',json.dumps(next(iter(d['players'].values()))[0]))
 for mid,m,r,p in real_milestones(d):
  if m['details'].get('away_last_games'):print('LAST GAMES',m['details']['league'],json.dumps(m['details']['away_last_games'])[:3000]);break
 for mid,m,r,p in real_milestones(d):
  if m['details'].get('game_injuries'):print('INJURIES',json.dumps(m['details']['game_injuries'])[:3000]);break

if __name__=='__main__':main()
