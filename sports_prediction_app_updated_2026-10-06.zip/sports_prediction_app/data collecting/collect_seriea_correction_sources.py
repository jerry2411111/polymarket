"""Official club corroboration where league event records contradict participants."""
import concurrent.futures,datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from urllib.parse import urlsplit
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS
JOBS=[
 ('SEA_20250420_ATA_MIL','https://www.acmilan.com/it/news/articoli/serie-a/2025-04-20/milan-superato-dall-atalanta-0-1-a-san-siro','Pulisic'),
 ('SEA_20250423_JUV_PAR','https://www.juventus.com/it/news/articoli/parma-juventus-il-tabellino','Pellegrino'),
 ('SEA_20250518_LAZ_INT','https://www.inter.it/it/notizie/inter-lazio-serie-a-2024-25','Gila'),
 ('SEA_20250518_MIL_ROM','https://www.acmilan.com/en/news/articles/serie-a/2025-05-18/defeat-at-the-olimpico','Gabbia'),
 ('SEA_20251026_GEN_TOR','https://www.torinofc.it/calendario/2025-2026/prima-squadra/8','Genoa')]
db=sqlite3.connect(DB,timeout=60);c=HistoryClient();HOSTS.update(urlsplit(url).hostname for _,url,_ in JOBS)
def fetch(job):
 gid,url,term=job
 try:
  b,r,redirects=get(c,url);soup=BeautifulSoup(b,'html.parser');text=soup.get_text(' ',strip=True);assert term in text;row=dict(game_id=gid,url=url,request_id=r['request_id'],status='ok',redirects=redirects,reason='Official league event data inconsistent; independent official club report');matches=[p.get_text(' ',strip=True) for p in soup.find_all(['p','section']) if term in p.get_text() and len(p.get_text())<3000];print(gid,r['request_id'],json.dumps(matches[-2:],ensure_ascii=False)[:1500],flush=True)
 except Exception as e:row=dict(game_id=gid,url=url,status='unavailable',error=str(e));print(gid,str(e),flush=True)
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(fetch,JOBS))
with db:
 db.execute('CREATE TABLE IF NOT EXISTS _seriea_official_correction_sources (game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _seriea_official_correction_sources VALUES (?,?)',[(r['game_id'],json.dumps(r)) for r in rows])
(ROOT/'reports/seriea_official_correction_sources.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=rows,new_requests=c.requests),indent=2),encoding='utf-8');db.close()
