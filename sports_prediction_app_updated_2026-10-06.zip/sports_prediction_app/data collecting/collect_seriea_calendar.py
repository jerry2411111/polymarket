"""Date-batched Serie A calendar through September 14, 2026, using the verified public API."""
import argparse,calendar,collections,datetime as dt,json,math,sqlite3
from urllib.parse import quote
from zoneinfo import ZoneInfo
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from probe_seriea_api import BASE

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100;assert json.loads((ROOT/'reports/seriea_pilot_validation.json').read_text())['status']=='WORKING';HOSTS.add('seriea-api.prd.sdp.deltatre.digital');client=HistoryClient();db=sqlite3.connect(DB,timeout=60);pilot=json.loads((ROOT/'reports/seriea_match_pilot.json').read_text());seasons={s['seasonName']:s for s in pilot['seasons']};loaded={};start=dt.date(2024,1,1);end=dt.date(2026,9,15);day=start;n=0
 with db:
  db.execute('CREATE TABLE IF NOT EXISTS _official_seriea_calendar (match_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('CREATE TABLE IF NOT EXISTS _official_seriea_calendar_months (month TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
 while day<end and n<math.ceil(33*a.through_percent/100):
  hi=min(day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1),end);month=day.strftime('%Y-%m');prior=db.execute('SELECT body FROM _official_seriea_calendar_months WHERE month=?',(month,)).fetchone()
  if prior and json.loads(prior[0])['complete']:n+=1;day=hi;continue
  year=day.year if day.month>=7 else day.year-1;name=f'{year}/{year+1}';season=seasons[name];sid=season['seasonId']
  if sid not in loaded:
   raw,r=client.get(BASE+'/seasons/'+quote(sid,safe='')+'/matches');assert raw['competition']['competitionId']==pilot['competition']['competitionId'] and raw['competition']['seasonId']==sid;ms=raw['matches'];assert len(ms)==len({m['matchId'] for m in ms});assert len(ms)==380,'Full 20-club season calendar required; investigate pagination or missing records';loaded[sid]=(raw,r)
  raw,r=loaded[sid];rows=[]
  for i,m in enumerate(raw['matches']):
   if m['status']!='FINISHED':continue
   assert m['seasonId']==sid and m['phase']=='FULL_TIME' and not m['isUnknownKickOffTime'];stamp=dt.datetime.fromisoformat(m['matchDateUtc']);assert stamp.tzinfo;local=stamp.astimezone(ZoneInfo('Europe/Rome'));date=local.date().isoformat()
   if not day.isoformat()<=date<hi.isoformat():continue
   assert local.replace(tzinfo=None)==dt.datetime.fromisoformat(m['matchDateLocal']);assert [m['homeScorePush'],m['awayScorePush']]==[m['providerHomeScore'],m['providerAwayScore']];assert all(type(m[k]) is int and m[k]>=0 for k in ['providerHomeScore','providerAwayScore']);sides={}
   for side in ['away','home']:
    t=m[side];assert not t['isTeamFake'];sides[side]=dict(id=t['teamId'],provider_id=t['providerId'],name=t['officialName'],abbr=t['acronymName'],score=m['provider'+side.title()+'Score'])
   assert sides['away']['id']!=sides['home']['id'];scores=[sides[x]['score'] for x in ['away','home']];winner='Draw' if scores[0]==scores[1] else sides[['away','home'][scores[1]>scores[0]]]['name'];winner_id=None if scores[0]==scores[1] else sides[['away','home'][scores[1]>scores[0]]]['id'];assert not m['winTeamId'] or m['winTeamId']==winner_id;expected_offset=local.strftime('%z');expected_offset=expected_offset[:3]+':'+expected_offset[3:]
   g=dict(official_match_id=m['matchId'],provider_match_id=m['providerId'],competition='Serie A',competition_id=pilot['competition']['competitionId'],season_id=sid,season=f'{year}-{str(year+1)[-2:]}',date=date,scheduled_start_utc=stamp.astimezone(dt.UTC).isoformat(),home=sides['home'],away=sides['away'],winner=winner,status='FINISHED',location=', '.join(filter(None,[m.get('stadiumName'),m.get('cityName')])),city=m.get('cityName'),stadium_id=m.get('stadiumId'),matchday_id=m.get('matchSet',{}).get('matchSetId'),request_id=r['request_id'],pointer='/matches/'+str(i),raw=m,time_offset_discrepancy=dict(raw=m['localTimeUtcOffset'],expected=expected_offset,handling='Verified explicit UTC/local pair using Europe/Rome') if m['localTimeUtcOffset']!=expected_offset else None);rows.append((m['matchId'],json.dumps(g)))
  rows=[(mid,json.dumps(dict(json.loads(body),scores=[json.loads(body)[s]['score'] for s in ['away','home']]))) for mid,body in rows]
  part=dict(month=month,complete=True,completed_games=len(rows),season_id=sid,request_id=r['request_id'],full_source_calendar_rows=len(raw['matches']))
  with db:db.executemany('INSERT OR REPLACE INTO _official_seriea_calendar VALUES (?,?)',rows);db.execute('INSERT OR REPLACE INTO _official_seriea_calendar_months VALUES (?,?)',(month,json.dumps(part)))
  n+=1;print('SERIE A CALENDAR',month,len(rows),'completed games;',n,'/33',flush=True);day=hi
 # Migrate earlier retained normalized rows without modifying their raw evidence.
 with db:
  for mid,body in db.execute('SELECT match_id,body FROM _official_seriea_calendar').fetchall():
   g=json.loads(body)
   if 'scores' not in g:
    g['scores']=[g[s]['score'] for s in ['away','home']];db.execute('UPDATE _official_seriea_calendar SET body=? WHERE match_id=?',(json.dumps(g),mid))
 games=[json.loads(b) for b, in db.execute('SELECT body FROM _official_seriea_calendar')];parts=[json.loads(b) for b, in db.execute('SELECT body FROM _official_seriea_calendar_months ORDER BY month')];out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='ACQUIRED_REQUIRES_INDEPENDENT_VALIDATION',completed_months=sum(p['complete'] for p in parts),total_months=33,completed_games=len(games),by_season=dict(collections.Counter(g['season'] for g in games)),earliest_date=min((g['date'] for g in games),default=None),latest_date=max((g['date'] for g in games),default=None),incorrect_offset_fields=sum(g['time_offset_discrepancy'] is not None for g in games),new_requests=client.requests,months=parts,scope='Completed Serie A fixtures within the requested calendar range; quote and supporting-table coverage require separate matching/acquisition.');(ROOT/'reports/seriea_calendar_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='months'}));db.close()

if __name__=='__main__':main()
