"""Small current EU acquisition summary, with no request payloads or secrets."""
import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
people=collections.Counter(json.loads(b)['status'] for b, in db.execute('SELECT body FROM _official_eu_opta_people_sources'));print('ADDITIONAL PERSON SOURCES',dict(people),'TOTAL',sum(people.values()))
locations=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_game_weather_locations')];wanted={(r['city'],r['game_id'].split('_')[1][:4]) for r in locations if r.get('competition')};counts=collections.Counter();missing=[]
for city,year,b in db.execute('SELECT * FROM _eu_weather_station_jobs'):
 if (city,year) in wanted:
  r=json.loads(b);counts[r['status']]+=1
  if r['status']!='ok':missing.append((city,year))
print('CURRENT WEATHER CANDIDATE CITY YEARS',len(wanted),'STATUS',dict(counts));print('STATION MISSING',len(missing))
for name in ['eu_opta_people_months.json','eu_weather_stations_months.json']:
 r=json.loads((ROOT/'reports'/name).read_text());print(name,'MONTHS',r['processed_months'],'OF',r['total_months'],'REQUESTS',r['new_requests'])
db.close()
