import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

db=sqlite3.connect(DB)
report=json.loads((ROOT/'reports/nba_individual_biographies.json').read_text())
print('Failures',dict(collections.Counter(x['error'].split(';')[0] for x in report['unavailable'])))
for x in report['unavailable'][:25]:
    rid=x['error'].split('request ')[-1]
    r=db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()
    print(json.dumps(dict(player=x['player_name'],id=x['official_player_id'],url=x['source_url'],location=json.loads(r[0]).get('location') if r else None,error=x['error'])))
wanted={p.split(':')[1] for (p,) in db.execute('SELECT DISTINCT player_id FROM _nba_player_game_facts')}
bios={str(json.loads(b)['official_player_id']) for (b,) in db.execute("SELECT body FROM _official_player_biographies WHERE league='NBA'")}
print('Combined biography coverage',len(wanted&bios),'/',len(wanted))
issues=json.loads((ROOT/'reports/nba_performance_facts.json').read_text())['issues']
print('Remaining stat identity issues',len(issues),dict(collections.Counter(x['player_name'] for x in issues)))
