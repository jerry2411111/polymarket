"""A date-only official calendar field is not a verified kickoff time."""
import datetime as dt

def verified_calendar_start(match):
    value=match.get('time')
    if not value:return None
    when=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
    if when.tzinfo is None:raise ValueError('La Liga kickoff must include a UTC offset')
    return when.astimezone(dt.UTC)
