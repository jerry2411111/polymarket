"""Summarize acquired soccer metadata without counting provider listings as verified matches."""
import argparse,collections,json,sqlite3
from build_history_catalog import DB

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--competition');ap.add_argument('--summary',action='store_true');a=ap.parse_args();db=sqlite3.connect(DB)
    for comp,n in db.execute('SELECT competition,count(DISTINCT event_id) FROM _eu_pm_event_sources GROUP BY competition'):
        if a.competition and comp!=a.competition:continue
        print('POLYMARKET',comp,n,'distinct source events')
        if a.summary:continue
        rows=db.execute("SELECT body FROM (SELECT s.*,row_number() OVER (PARTITION BY event_id ORDER BY a.request_number DESC) rn FROM _eu_pm_event_sources s JOIN _request_audit a USING(request_id) WHERE competition=?) WHERE rn=1 ORDER BY json_extract(body,'$.endDate')",(comp,)).fetchall()
        for row in [*rows[:2],rows[len(rows)//2]]:
            e=json.loads(row[0]);print(json.dumps(dict(event_id=e['id'],title=e['title'],slug=e.get('slug'),end_date=e.get('endDate'),start=e.get('startTime'),event_teams=e.get('teams'),markets=[{k:m.get(k) for k in ['id','question','sportsMarketType','gameStartTime','outcomes','clobTokenIds','outcomePrices','description']} for m in e.get('markets',[])[:3]]),ensure_ascii=False)[:5000])
    print('KALSHI',db.execute('SELECT competition,route,count(*) FROM _eu_kalshi_market_sources GROUP BY competition,route').fetchall())
    if a.competition:
        for b, in db.execute("SELECT body FROM _eu_kalshi_market_sources WHERE competition=? ORDER BY json_extract(body,'$.close_time') LIMIT 3",(a.competition,)):
            m=json.loads(b);print(json.dumps({k:m.get(k) for k in ['ticker','event_ticker','title','yes_sub_title','result','close_time','rules_primary','rules_secondary']},ensure_ascii=False))
    db.close()

if __name__=='__main__':main()
