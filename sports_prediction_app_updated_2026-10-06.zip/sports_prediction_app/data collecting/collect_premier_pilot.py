"""Acquire three real historical match examples from official Premier League resources."""
import datetime as dt,json,re,sqlite3
from bs4 import BeautifulSoup
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT,HOSTS

BASE='https://sdp-prem-prod.premier-league-prod.pulselive.com/api'

def main():
    HOSTS.update({'sdp-prem-prod.premier-league-prod.pulselive.com','www.premierleague.com'});client=HistoryClient();db=sqlite3.connect(DB);source=json.loads((ROOT/'reports/eu_soccer_premier_dates_probes.json').read_text())['sources'][0];assert source['verified_date_filter'];r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(source['request_id'],)).fetchone()[0]);matches=json.loads((ROOT/r['raw_file']).read_bytes())['data'];out=[]
    for match in matches[:3]:
        mid=match['matchId'];row=dict(match_id=mid,schedule_request_id=r['request_id'],schedule=match,sources={})
        for key,path in [('match','/v2/matches/'+mid),('lineups','/v3/matches/'+mid+'/lineups'),('events','/v1/matches/'+mid+'/events'),('timeline','/v1/matches/'+mid+'/timeline'),('stats','/v3/matches/'+mid+'/stats'),('commentary','/v2/matches/'+mid+'/commentary')]:
            try:
                data,rr=client.get(BASE+path,{'lang':'en'} if key=='commentary' else None);row['sources'][key]=dict(request_id=rr['request_id'],data=data);print('EPL PILOT',mid,key,rr['request_id'],'keys',list(data) if isinstance(data,dict) else 'array '+str(len(data)),flush=True)
            except Exception as e:row['sources'][key]=dict(error=str(e));print('EPL PILOT GAP',mid,key,str(e),flush=True)
        slug=lambda s:re.sub(r'[^a-z0-9-]','',s.lower().replace(' ','-'));url='https://www.premierleague.com/en/match/'+mid+'/'+slug(match['homeTeam']['name'])+'-vs-'+slug(match['awayTeam']['name'])+'/overview'
        try:
            b,rr=client.get(url,document=True);soup=BeautifulSoup(b,'html.parser');row['public_page']=dict(url=url,request_id=rr['request_id'],title=soup.title.get_text() if soup.title else None,structured=[json.loads(t.get_text()) for t in soup.find_all('script',type='application/ld+json')]);print('EPL PUBLIC PAGE',json.dumps(row['public_page'])[:1500],flush=True)
        except Exception as e:row['public_page']=dict(url=url,error=str(e))
        out.append(row)
    db.execute('CREATE TABLE IF NOT EXISTS _official_epl_game_reports (match_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
    with db:db.executemany('INSERT OR REPLACE INTO _official_epl_game_reports VALUES (?,?)',[(r['match_id'],json.dumps(r)) for r in out])
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='ACQUIRED_REQUIRES_VALIDATION',games=len(out),request_count=client.requests,examples=[dict(match_id=r['match_id'],match=r['schedule']['homeTeam']['name']+' / '+r['schedule']['awayTeam']['name'],sources={k:{n:v for n,v in x.items() if n!='data'} for k,x in r['sources'].items()},public_page=r['public_page']) for r in out]);(ROOT/'reports/epl_official_pilot_acquisition.json').write_text(json.dumps(report,indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
