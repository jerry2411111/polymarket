import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB)
    report=json.loads((ROOT/'reports/nba_performance_facts.json').read_text())
    print('Issues',len(report['issues']),dict(collections.Counter(x['player_name'] for x in report['issues'])))
    diffs=json.loads((ROOT/'reports/nba_player_stat_source_differences.json').read_text())
    print('Source differences',len(diffs),dict(collections.Counter(k for x in diffs for k in x['values'])))
    for x in [x for x in diffs if 'score' in x['values'] or 'starter' in x['values']]:print(json.dumps(x))
    print('Schemas')
    for t in ['player_profiles','player_current_team','manager_profiles','team_history','_official_player_biographies','_player_ranking_flags_quarterly','_history_players']:
        print(t,[r[1] for r in db.execute('PRAGMA table_info('+t+')')])
    print('Official aliases')
    names=collections.defaultdict(collections.Counter)
    for pid,b in db.execute('SELECT official_player_id,body FROM _official_nba_page_players'):
        names[pid][json.loads(b)['player_name']]+=1
    print([(pid,dict(ns)) for pid,ns in names.items() if len(ns)>1][:20])
    print('Suspect surname candidates')
    wanted=['yang','sarr','carrington','telfort','lovering','shumate','dainja','austin','zeng','butler','tait','thomas']
    print([(pid,dict(ns)) for pid,ns in names.items() if any(w in n.lower() for n in ns for w in wanted)])
    bios={str(json.loads(b)['official_player_id']) for (b,) in db.execute("SELECT body FROM _official_player_biographies WHERE league='NBA'")}
    wantedids={r[0].split(':')[1] for r in db.execute('SELECT DISTINCT player_id FROM _nba_player_game_facts')}
    print('Missing biography IDs',len(wantedids-bios),[(p,names[p].most_common(1)) for p in sorted(wantedids-bios)][:15])
    print('One biography',db.execute("SELECT body FROM _official_player_biographies WHERE league='NBA' LIMIT 1").fetchone()[0])
    print('One original provider player',db.execute("SELECT body FROM _history_players WHERE json_extract(body,'$.data.details.league')='NBA' LIMIT 1").fetchone())
    print('Main view',db.execute("SELECT sql FROM sqlite_master WHERE name='main'").fetchone())
    print('Ranking rows',db.execute('SELECT * FROM player_rankings_quarterly LIMIT 2').fetchall())

if __name__=='__main__':main()
