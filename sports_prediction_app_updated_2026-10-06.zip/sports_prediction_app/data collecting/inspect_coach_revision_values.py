import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
for b, in db.execute('SELECT body FROM _nba_coach_contract_revision_sources'):
    s=json.loads(b)
    if s['status']!='ok':continue
    r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(s['request_id'],)).fetchone()[0]);html=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
    print('SOURCE',s['url'])
    print('DATE',s['dated_metadata'])
    paragraphs=[p.get_text(' ',strip=True) for p in html.select('p')]
    print('\n'.join(p for p in paragraphs if re.search(r'\$|extension|terms',p,re.I))[:3000])
db.close()
