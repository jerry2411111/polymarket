"""Summarize retained official phase anomalies without printing full reports."""
import collections,json,sqlite3
from build_history_catalog import DB

def main():
 db=sqlite3.connect(DB);counts=collections.Counter()
 for mid,b in db.execute('SELECT * FROM _official_seriea_game_reports'):
  r=json.loads(b);d=r.get('derived',{});g=json.loads(db.execute('SELECT body FROM _official_seriea_calendar WHERE match_id=?',(mid,)).fetchone()[0]);issues=list(d.get('issues',[]))
  for e in r.get('sources',{}).get('feed',{}).get('data',{}).get('events',[]):
   if e['type']=='first-half' and [e.get(s+'ScorePush') for s in ['away','home']]!=[0,0]:issues.append(dict(reason='Nonzero opening event score',event_id=e['eventId'],score=[e.get(s+'ScorePush') for s in ['away','home']],timestamp=e['timeStamp']))
  if issues:print(json.dumps(dict(date=g['date'],match=g['away']['name']+'/'+g['home']['name'],match_id=mid,scheduled=g['scheduled_start_utc'],raw_request_id=r['sources']['feed']['request_id'],issues=issues)),flush=True)
  counts.update(x['reason'] for x in issues)
 print('TOTAL',dict(counts));db.close()

if __name__=='__main__':main()
