"""Helpers retained from verified acquisition; obsolete pilot builders removed."""
import datetime as dt
import json,math
from decimal import Decimal


def utc(v):
    if v is None or v=='':return None
    if isinstance(v,(int,float)):return dt.datetime.fromtimestamp(v,dt.UTC)
    if isinstance(v,dt.datetime):d=v
    else:d=dt.datetime.fromisoformat(v.replace('Z','+00:00'))
    if d.tzinfo is None:raise ValueError('Missing UTC offset')
    return d.astimezone(dt.UTC)

def iso(v):return v.isoformat() if v is not None else None

def num(v):
    if v is None or v=='':return None
    if isinstance(v,bool):raise ValueError('Boolean statistic')
    n=float(Decimal(str(v)))
    if not math.isfinite(n):raise ValueError('Nonfinite statistic')
    return n

def odd(p):return float(Decimal(1)/Decimal(str(p))) if p is not None and p>0 else None

def array(v):return json.loads(v) if isinstance(v,str) else v

def pointer(d,p):
    for k in p.strip('/').split('/') if p else []:
        k=k.replace('~1','/').replace('~0','~');d=d[int(k)] if isinstance(d,list) else d[k]
    return d

def boundary(e):
    if e.get('event_type') in {'startperiod','endperiod'}:return e['event_type']
    d=e.get('description','').lower()
    if any(w in d for w in ['quarter','period','half']):
        if d.startswith('start of '):return 'startperiod'
        if d.startswith('end of '):return 'endperiod'

def checkpoint_rows(pbp,sport):
    specs={'basketball':[(1,'startperiod'),(1,'endperiod'),(2,'endperiod'),(3,'endperiod')],
           'baseball':[(1,'first_pitch'),(3,'third_out'),(5,'third_out'),(7,'third_out')],
           'hockey':[(1,'startperiod'),(1,'endperiod'),(2,'endperiod')]}[sport]
    rows=[]
    for n,kind in specs:
        hits=[]
        for pi,p in enumerate((pbp.get('pbp') or {}).get('periods') or []):
            if p.get('period_number')!=n or p.get('period_type') in {'overtime','shootout','OT'}:continue
            if kind=='third_out' and p.get('half')!='bottom':continue
            for ei,e in enumerate(p.get('events') or []):
                match=boundary(e)==kind or (kind=='third_out' and e.get('outs')==3)
                if kind=='startperiod' and sport=='basketball' and n==1:
                    match=match or e.get('event_type')=='opentip' or (e.get('clock')=='12:00' and ' vs. ' in e.get('description','') and 'gains possession' in e.get('description',''))
                if match:hits.append((e,pi,ei))
        if kind=='third_out' and hits:hits=[max(hits,key=lambda x:(x[0].get('sequence',-1),x[0].get('wall_clock',-1)))]
        if len(hits)>1:
            exact=[h for h in hits if boundary(h[0])==kind]
            if len(exact)==1:hits=exact
            else:raise ValueError('Ambiguous boundary')
        e,pi,ei=hits[0] if hits else ({},None,None)
        rows.append(dict(time=utc(e.get('wall_clock')),a=e.get('away_points'),b=e.get('home_points'),pointer=f'/pbp/periods/{pi}/events/{ei}' if hits else None))
    return rows
