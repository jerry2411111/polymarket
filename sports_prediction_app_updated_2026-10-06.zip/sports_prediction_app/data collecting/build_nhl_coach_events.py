"""Date native coach identity/history evidence without importing future totals."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_nhl_market_candidates import clean
from probe_history import ROOT

# Each appointment below was read in the saved original official registry
# description. Assistant/associate positions are deliberately not head jobs.
APPOINTMENTS=[('142','briefDescription','Tampa Bay Lightning','2013-03-25','March 25, 2013'),('156','briefDescription','Detroit Red Wings','2015-06-09','June 9, 2015'),('157','briefDescription','New Jersey Devils','2015-06-02','June 2, 2015'),('70','briefDescription','Pittsburgh Penguins','2015-12-12','Dec. 12, 2015'),('1743','briefDescription','New York Islanders','2022-05-16','May 16, 2022'),('58','briefDescription','Dallas Stars','2013-06-21','June 21, 2013'),('64','briefDescription','Toronto Maple Leafs','2015-05-20','May 20, 2015'),('74','briefDescription','Nashville Predators','2014-05-06','May 6, 2014'),('144','briefDescription','Colorado Avalanche','2013-05-23','May 23, 2013'),('105','briefDescription','Edmonton Oilers','2015-05-19','May 19, 2015'),('73','briefDescription','Winnipeg Jets','2014-01-12','January 12, 2014'),('107','briefDescription','San Jose Sharks','2015-05-28','May 28, 2015'),('1865','description','Toronto Maple Leafs','2019-11-20','Nov. 20, 2019'),('113','description','Buffalo Sabres','2015-05-28','May 28, 2015'),('48','briefDescription','Chicago Blackhawks','2008-10-16','Oct. 16, 2008')]

def main():
    db=sqlite3.connect(DB,timeout=60);registry={n:json.loads(b) for n,b in db.execute('SELECT * FROM _official_nhl_coach_registry')};byname={clean(r['full_name']):r for r in registry.values()};audit={r:json.loads(b) for r,b in db.execute('SELECT request_id,metadata_json FROM _request_audit')};events=[];hashes=set()
    def checked(rid):
        r=audit[rid];b=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];hashes.add(rid);return b
    def add(native,team,day,rid,pointer,kind,raw_value,exact=False):
        dt.date.fromisoformat(day);events.append(dict(manager_id='NHL_COACH:'+native,manager_name=registry[native]['full_name'],team_name=team.replace('Montréal','Montreal'),known_date=day,kind=kind,exact_appointment=exact,request_id=rid,pointer=pointer,raw_value=raw_value))
    for native,r in registry.items():
        original=json.loads(checked(r['request_id']))['data'][0];assert original==r['raw']
        for n,s in enumerate(original['coachFranchiseSeasonRecords']):
            if not s['games'] or s.get('gameTypeId') not in [2,3]:continue
            day=s['firstCoachedDate'];assert day and day<=s['lastCoachedDate'];team=s['teamName']
            if s['teamId'] in [59,68]:team='Utah Hockey Club' if day<'2025-05-07' else 'Utah Mammoth'
            add(native,team,day,r['request_id'],f'/data/0/coachFranchiseSeasonRecords/{n}','observed_first_game',dict(firstCoachedDate=day,teamId=s['teamId'],teamName=s['teamName'],season=s['season'],franchiseId=s['franchiseId']))
    for native,field,team,day,phrase in APPOINTMENTS:
        r=registry[native];text=BeautifulSoup(r['raw'].get(field) or '','html.parser').get_text(' ',strip=True);assert phrase in text and any(clean(s['teamName'])==clean(team) for s in r['raw']['coachFranchiseSeasonRecords'])
        add(native,team,day,r['request_id'],'/data/0/'+field,'documented_appointment',text,True)
    reviewed=[
        ('_nhl_coach_sources','https://www.nhl.com/news/dan-bylsma-named-seattle-coach','Dan Bylsma','Seattle Kraken','2024-05-28',2,'Dan Bylsma was named coach of the Seattle Kraken','documented_appointment'),
        ('_nhl_coach_sources','https://www.nhl.com/news/sheldon-keefe-fired-by-toronto','Sheldon Keefe','Toronto Maple Leafs','2024-05-09',2,'Sheldon Keefe was fired as coach of the Toronto Maple Leafs','documented_departure'),
        ('_nhl_coach_sources','https://www.nhl.com/news/todd-mclellan-fired-by-los-angeles','Todd McLellan','Los Angeles Kings','2024-02-02',2,'Todd McLellan was fired as coach of the Los Angeles Kings','documented_departure'),
        ('_nhl_coach_sources','https://www.nhl.com/news/todd-mclellan-fired-by-los-angeles','Jim Hiller','Los Angeles Kings','2024-02-02',2,'replaced by Jim Hiller on an interim basis','documented_appointment'),
        ('_nhl_coach_sources','https://www.nhl.com/goldenknights/news/vegas-golden-knights-announce-changes-to-team-s-coaching-staff','Bruce Cassidy','Vegas Golden Knights','2026-03-29',1,'Bruce Cassidy has been relieved of his duties','documented_departure'),
        ('_nhl_coach_sources','https://www.nhl.com/goldenknights/news/vegas-golden-knights-announce-changes-to-team-s-coaching-staff','John Tortorella','Vegas Golden Knights','2026-03-29',1,'John Tortorella has been named the team’s head coach','documented_appointment'),
        ('_nhl_coach_sources','https://www.nhl.com/rangers/news/topic/press-releases/mike-sullivan-named-rangers-head-coach','Mike Sullivan','New York Rangers','2025-05-02',0,'team has named Mike Sullivan the 38th Head Coach','documented_appointment')]
    for table,url,name,team,day,index,phrase,kind in reviewed:
        r=json.loads(db.execute('SELECT body FROM '+table+' WHERE url=?',(url,)).fetchone()[0]);soup=BeautifulSoup(checked(r['request_id']),'html.parser');text=soup.select('p')[index].get_text(' ',strip=True);assert phrase in text;article=next(a for a in r['metadata']['structured'] if a.get('@type')=='NewsArticle');assert article['datePublished'][:10]==day
        add(byname[clean(name)]['official_coach_id'],team,day,r['request_id'],'p/'+str(index),kind,text,kind=='documented_appointment')
    snapshots=[]
    for b, in db.execute("SELECT body FROM _nhl_coach_sources WHERE url LIKE '%nhl-coaches-2023-24-season%'"):
        r=json.loads(b);checked(r['request_id']);articles=[a for a in r['metadata']['structured'] if a.get('@type')=='NewsArticle'];assert len(articles)==1;a=articles[0];day=max(a['datePublished'][:10],a.get('dateModified',a['datePublished'])[:10]);body=re.sub(r'\[([^]]+)\]\([^)]*\)',r'\1',a['articleBody'].replace('**',''));body=body.replace('Here is a list of the coaches for all 32 NHL teams:','');pairs=[]
        for line in body.splitlines():
            m=re.fullmatch(r'(.+?):\s*(.+)',line.strip())
            if not m:continue
            team,name=m.groups();person=byname[clean(name)];add(person['official_coach_id'],team,day,r['request_id'],'NewsArticle/articleBody','dated_roster',line);pairs.append((team,person['official_coach_id']))
        assert len(pairs)==32 and len({t for t,n in pairs})==32 and len({n for t,n in pairs})==32;snapshots.append(dict(date=day,teams=len(pairs),request_id=r['request_id']))
    for e in events:e['event_id']=hashlib.sha256(json.dumps(e,sort_keys=True).encode()).hexdigest()
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _nhl_coach_affiliation_events (event_id TEXT PRIMARY KEY,manager_id TEXT,known_date TEXT,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nhl_coach_affiliation_events');db.executemany('INSERT INTO _nhl_coach_affiliation_events VALUES (?,?,?,?)',[(e['event_id'],e['manager_id'],e['known_date'],json.dumps(e)) for e in events])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),native_coaches=len(registry),dated_events=len(events),verified_exact_appointments=sum(e['exact_appointment'] for e in events),verified_departures=sum(e['kind']=='documented_departure' for e in events),current_roster_snapshots=snapshots,source_hash_checks=len(hashes),meaning='A first coached game establishes an affiliation observation, not a hire date. Exact tenure requires a dated appointment. Current cumulative coach statistics are not historical performance. Dated official announcements are retrospective event-date evidence, not a claim to hold a contemporaneous capture. All season source fields remain raw and excluded from performance aggregation.')
    (ROOT/'reports/nhl_coach_temporal_events.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
