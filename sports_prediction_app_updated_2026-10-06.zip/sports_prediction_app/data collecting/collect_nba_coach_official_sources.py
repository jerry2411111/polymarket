"""Capture official appointment reports and season media guides, raw first."""
import concurrent.futures,datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

URLS=[
'https://www.nba.com/bucks/news/milwaukee-bucks-hire-doc-rivers-as-head-coach',
'https://www.nba.com/bucks/news/doc-rivers-steps-down-as-milwaukee-bucks-head-coach',
'https://www.nba.com/news/knicks-mike-brown-new-coach',
'https://www.nba.com/news/jj-redick-agrees-deal-lakers-coach',
'https://www.nba.com/news/2026-coaching-tracker',
'https://www.nba.com/news/gregg-popovich-career-record-adjusted-by-nba',
'https://www.nba.com/news/gregg-popovich-becomes-spurs-team-president',
'https://www.nba.com/kings/news/mike-brown-relieved-as-kings-head-coach',
'https://www.nba.com/news/doug-christie-named-coach-kings',
'https://www.nba.com/news/nba-fantasy-implications-of-offseason-coaching-changes-in-2024',
'https://cdn.nba.com/teams/uploads/sites/1610612760/2024/10/2024-25-Thunder-Media-Guide.pdf',
'https://cdn.nba.com/teams/uploads/sites/1610612754/2025/10/2025-26-Indiana-Pacers-Media-Guide-web.pdf',
'https://cdn.nba.com/teams/uploads/sites/1610612758/2025/01/2024-25-Sacramento-Kings-Media-Guide.pdf',
'https://cdn.nba.com/teams/uploads/sites/1610612740/2024/10/2024-25-Pelicans-Media-Guide-v2.pdf',
'https://www.nba.com/gamenotes/lakers.pdf',
'https://www.nba.com/gamenotes/knicks.pdf',
'https://www.nba.com/gamenotes/spurs.pdf',
'https://www.nba.com/pistons/news/detroit-pistons-announce-j-b-bickerstaff-as-head-coach',
'https://www.nba.com/news/nets-hire-jordi-fernandez-as-coach',
'https://www.nba.com/news/hornets-hire-charles-lee-new-coach',
'https://www.nba.com/news/cavs-to-hire-kenny-atkinson-as-coach',
'https://www.nba.com/news/cavs-hire-jordan-ott-coach',
'https://www.nba.com/news/grizzlies-name-tuomas-iisalo-head-coach',
'https://www.nba.com/nuggets/news/denver-nuggets-relieve-head-coach-michael-malone-of-duties-will-not-extend-calvin-booth',
'https://www.nba.com/gamenotes/sixers.pdf',
'https://www.nba.com/sixers/76ers-coaches/nick-nurse',
'https://www.nba.com/news/steve-clifford-to-step-down-hornets',
'https://www.nba.com/news/nba-starting-5-june-3-2024',
]
URLS=list(dict.fromkeys(URLS+['https://www.nba.com/gamenotes/'+team+'.pdf' for team in ['hawks','celtics','nets','hornets','bulls','cavaliers','mavericks','nuggets','pistons','warriors','rockets','pacers','clippers','lakers','grizzlies','heat','bucks','timberwolves','pelicans','knicks','thunder','magic','76ers','suns','blazers','kings','spurs','raptors','jazz','wizards']]))

def main():
    c=HistoryClient();out=[]
    db=sqlite3.connect(DB);r=db.execute("SELECT body FROM _nba_coach_official_sources WHERE url LIKE '%2026-coaching-tracker'").fetchone();db.close()
    if r:
        URLS.extend(u for u in json.loads(r[0]).get('official_links',[]) if u.startswith('https://www.nba.com/news/') and any(w in u for w in ['coach','jason-kidd','willie-green','doc-rivers']))
    urls=list(dict.fromkeys(URLS))
    def get(url):
        try:
            b,r=c.get(url,document=True)
            x=dict(url=url,request_id=r['request_id'],status='ok',retrieved_at_utc=r['retrieved_at_utc'])
            if not b.startswith(b'%PDF'):
                s=BeautifulSoup(b,'html.parser');x['title']=s.title.get_text() if s.title else None
                x['official_links']=sorted({a['href'] for a in s.select('a[href]') if '/news/' in a['href'] and (a['href'].startswith('https://www.nba.com/') or a['href'].startswith('/news/'))})
            return x
        except Exception as e:return dict(url=url,status='unavailable',error=str(e))
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for i,x in enumerate(pool.map(get,urls),1):out.append(x);print('OFFICIAL COACH SOURCE',i,'/',len(urls),x['status'],x['url'],flush=True)
    db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _nba_coach_official_sources (url TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _nba_coach_official_sources VALUES (?,?)',[(x['url'],json.dumps(x)) for x in out]);db.commit();db.close()
    (ROOT/'reports/nba_coach_official_acquisition.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=out),indent=2),encoding='utf-8')

if __name__=='__main__':main()
