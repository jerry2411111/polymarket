"""Match regulation-win/draw contracts to official EPL games, preserving each YES token."""
import collections,datetime as dt,json,re,sqlite3,unicodedata
from build_history_catalog import DB
from probe_history import ROOT

def clean(s):
    s=unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().lower();s=re.sub(r'\b(?:fc|afc|football club)\b','',s);return re.sub('[^a-z0-9]','',s)
def array(v):return json.loads(v) if isinstance(v,str) else v or []
def utc(v):
    if not v:return None
    x=dt.datetime.fromisoformat(v.replace('Z','+00:00'));assert x.tzinfo;return x.astimezone(dt.UTC)

def main():
    assert json.loads((ROOT/'reports/epl_calendar_validation.json').read_text())['status']=='WORKING';db=sqlite3.connect(DB,timeout=60);games={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_epl_calendar') if json.loads(b)['status']=='FullTime'};aliases=collections.defaultdict(set);bydate=collections.defaultdict(list);issues=[];candidates=[];families=[]
    for g in games.values():
        bydate[g['date']].append(g)
        for side in ['away','home']:
            t=g[side]
            for name in [t.get('name'),t.get('shortName'),t.get('abbr')]:
                if name:aliases[clean(name)].add(t['id'])
    resolutions={(p,f):json.loads(b) for p,f,b in db.execute('SELECT * FROM _epl_date_resolutions')} if db.execute("SELECT 1 FROM sqlite_master WHERE name='_epl_date_resolutions'").fetchone() else {}
    # A provider alias is usable only when its own full name maps uniquely to
    # a native official team, rather than assuming abbreviation conventions.
    events=[(eid,rid,ptr,json.loads(b)) for eid,rid,ptr,b in db.execute('SELECT event_id,request_id,pointer,body FROM _eu_pm_events')]
    for eid,rid,ptr,e in events:
        for t in e.get('teams') or []:
            ids=aliases[clean(t.get('name'))]
            if len(ids)==1:
                for name in [t.get('abbreviation'),t.get('alias')]:
                    if name:aliases[clean(name)].update(ids)
    def ids(name):return aliases[clean(name)]
    # Kalshi sometimes shortens a club's official name. Accept a prefix only
    # when the native contract suffix independently agrees with the league's
    # official abbreviation, and exactly one league team has that combination.
    kalshi_alias_checks=[]
    for ticker,b in db.execute("SELECT ticker,body FROM _eu_kalshi_markets WHERE competition='EPL'"):
        m=json.loads(b);name=m.get('yes_sub_title','');suffix=ticker.rsplit('-',1)[-1]
        if ids(name) or clean(name) in ['tie','draw']:continue
        found={g[s]['id'] for g in games.values() for s in ['away','home'] if clean(g[s]['name']).startswith(clean(name)) and g[s]['abbr']==suffix}
        if len(found)==1:
            aliases[clean(name)].update(found);kalshi_alias_checks.append(dict(label=name,native_suffix=suffix,official_team_id=next(iter(found)),basis='Official full-name prefix and exact official abbreviation'))
    def match(pair,day):
        if len(pair)!=2:return None
        found=[g for g in bydate[day] if {g['away']['id'],g['home']['id']}==set(pair)];return found[0] if len(found)==1 else None
    def record_family(provider,fid,g,cs):
        for c in cs:
            if c.get('draw_half_payout_rule'):
                issues.append(dict(provider=provider,event_id=fid,official_match_id=g['official_match_id'],reason='Written draw rule pays 50-50; team YES price is not an unambiguous win probability',market_id=c['market_id'],request_id=c['request_id'],pointer=c['pointer']+'/description',disposition='Retain acquired raw and candidate metadata; exclude this family from probability/odds publication'))
        sides=collections.Counter(c['side'] for c in cs)
        if sides!={0:1,1:1,2:1}:issues.append(dict(provider=provider,family_id=fid,reason='Incomplete or ambiguous three-outcome family',sides=dict(sides)));return
        expected=2 if g['away']['score']==g['home']['score'] else int(g['home']['score']>g['away']['score'])
        if any(c['settlement_yes'] is not None and c['settlement_yes']!=int(c['side']==expected) for c in cs):issues.append(dict(provider=provider,family_id=fid,official_match_id=g['official_match_id'],reason='Provider resolution disagrees with official regulation result',official_scores=[g['away']['score'],g['home']['score']],settlements=[(c['side'],c['settlement_yes']) for c in cs]));return
        gid='EPL_'+g['date'].replace('-','')+'_'+g['away']['abbr']+'_'+g['home']['abbr']
        for c in cs:c.update(game_id=gid,official_match_id=g['official_match_id'],official_schedule_request_id=g['request_id'])
        candidates.extend(cs);families.append(dict(provider=provider,family_id=fid,game_id=gid,official_match_id=g['official_match_id'],date=g['date'],outcomes=3))
    for eid,rid,ptr,e in events:
        if not any(x[0] in ['EPL'] for x in db.execute('SELECT DISTINCT competition FROM _eu_pm_event_sources WHERE event_id=?',(eid,))):continue
        ms=[]
        for mi,m in enumerate(e.get('markets',[])):
            if m.get('sportsMarketType') not in [None,'moneyline']:continue
            if re.search(r'\b(first half|second half|1st half|2nd half|advance|qualif|champion|title|season|top \d|relegat|both teams|score first)\b',m.get('question',''),re.I):continue
            outcomes=array(m.get('outcomes'));tokens=array(m.get('clobTokenIds'));q=m.get('question','').strip();values=array(m.get('outcomePrices'))
            if len(outcomes)!=2 or {clean(v) for v in outcomes}!={'yes','no'} or len(tokens)!=2 or len(set(tokens))!=2:continue
            if re.search(r'\b(draw|tie)\b',q,re.I):team='DRAW'
            else:
                t=re.match(r'Will (.+?) (?:win|beat|defeat)\b',q,re.I)
                if not t:continue
                team=t[1]
                if len(ids(team))!=1:continue
            ms.append((mi,m,team,outcomes,tokens,values))
        tids={next(iter(ids(t))) for _,_,t,_,_,_ in ms if t!='DRAW'}
        if len(tids)!=2 or len(ms)!=3:continue
        starts={utc(m['gameStartTime']) for _,m,_,_,_,_ in ms if m.get('gameStartTime')}
        correction=resolutions.get(('polymarket',eid))
        if len(starts)>1 and not correction:issues.append(dict(provider='polymarket',event_id=eid,reason='Different start times within proposed family'));continue
        raw_start=(utc(e.get('startTime')) if correction else next(iter(starts),None)) or utc(e.get('startTime'));day=correction['date'] if correction else (raw_start.date().isoformat() if raw_start else (e.get('endDate') or '')[:10]);g=match(tids,day)
        if not g:issues.append(dict(provider='polymarket',event_id=eid,reason='No unique official EPL fixture on proposed date',date=day,team_ids=sorted(tids)));continue
        if correction:assert correction['official_match_id']==g['official_match_id']
        if not correction and raw_start and abs((raw_start-utc(g['scheduled_start_utc'])).total_seconds())>6*3600:issues.append(dict(provider='polymarket',event_id=eid,reason='Start-time difference exceeds six hours'));continue
        cs=[]
        for mi,m,team,outcomes,tokens,values in ms:
            idx=next(i for i,v in enumerate(outcomes) if clean(v)=='yes');side=2 if team=='DRAW' else int(next(iter(ids(team)))==g['home']['id']);sv=float(values[idx]) if len(values)==2 else None
            cs.append(dict(provider='polymarket',contract_id=tokens[idx],market_id=m['id'],event_id=eid,family_id=eid,side=side,outcome=outcomes[idx],outcome_index=idx,team_question=team,open=m.get('createdAt'),settled=m.get('closedTime') or m.get('endDate'),series=None,settlement_yes=sv if m.get('closed') else None,request_id=rid,pointer=ptr+'/markets/'+str(mi),source_start_utc=raw_start.isoformat() if raw_start else None,draw_half_payout_rule=bool(team!='DRAW' and re.search(r'(?:tie|draw).{0,140}(?:50.?50|50%)',m.get('description',''),re.I)),identity_basis='Three explicit YES win/draw questions, unique official native teams and game date'))
        record_family('polymarket',eid,g,cs)
    kalshi=collections.defaultdict(list)
    for ticker,rid,ptr,b in db.execute("SELECT ticker,request_id,pointer,body FROM _eu_kalshi_markets WHERE competition='EPL'"):
        m=json.loads(b);kalshi[m['event_ticker']].append((m,rid,ptr))
    for eid,ms in kalshi.items():
        if len(ms)!=3 or any(m.get('result') not in ['yes','no'] for m,_,_ in ms):continue
        parsed=re.match(r'KXEPLGAME-(\d{2})([A-Z]{3})(\d{2})',eid);assert parsed;day=dt.datetime.strptime('20'+parsed[1]+parsed[2]+parsed[3],'%Y%b%d').date().isoformat();correction=resolutions.get(('kalshi',eid));day=correction['date'] if correction else day;tids={next(iter(ids(m['yes_sub_title']))) for m,_,_ in ms if len(ids(m['yes_sub_title']))==1};g=match(tids,day)
        if not g:issues.append(dict(provider='kalshi',event_id=eid,reason='No unique official EPL fixture for native ticker date and outcome labels',date=day));continue
        if correction:assert correction['official_match_id']==g['official_match_id']
        cs=[]
        for m,rid,ptr in ms:
            team=m['yes_sub_title'];side=2 if clean(team) in ['tie','draw'] else int(next(iter(ids(team)))==g['home']['id']) if len(ids(team))==1 else None
            if side is None:continue
            assert '90 minutes plus stoppage time' in m['rules_primary'] and 'does not include extra time or penalties' in m['rules_primary'],'Unreviewed market duration'
            cs.append(dict(provider='kalshi',contract_id=m['ticker'],market_id=m['ticker'],event_id=eid,family_id=eid,side=side,outcome='Yes',team_question=team,open=m['open_time'],settled=m.get('settlement_ts') or m.get('settlement_time') or m.get('close_time'),series='KXEPLGAME',settlement_yes=int(m['result']=='yes'),request_id=rid,pointer=ptr,identity_basis='Three explicit YES regulation win/draw contracts, unique native official teams and ticker game date'))
        record_family('kalshi',eid,g,cs)
    assert len(candidates)==len({(c['provider'],c['contract_id']) for c in candidates})
    with db:
        for table in ['_epl_market_candidates','_epl_market_families','_epl_matching_issues']:db.execute('CREATE TABLE IF NOT EXISTS '+table+' (body TEXT NOT NULL) STRICT');db.execute('DELETE FROM '+table)
        db.executemany('INSERT INTO _epl_market_candidates VALUES (?)',[(json.dumps(c),) for c in candidates]);db.executemany('INSERT INTO _epl_market_families VALUES (?)',[(json.dumps(c),) for c in families]);db.executemany('INSERT INTO _epl_matching_issues VALUES (?)',[(json.dumps(c),) for c in issues])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='CANDIDATES_REQUIRE_PRICES_AND_FULL_REPORTS',families_by_provider=dict(collections.Counter(c['provider'] for c in families)),unique_games=len({c['game_id'] for c in families}),outcome_contracts=len(candidates),issues=dict(collections.Counter(c['reason'] for c in issues)),verified_abbreviated_labels=kalshi_alias_checks,earliest_by_provider={p:min((c['date'] for c in families if c['provider']==p),default=None) for p in ['polymarket','kalshi']},limits=['Initial exact three-outcome matching. Other question formats and postponed dates remain under review.','Provider settlement is only compared against official game scores; it never supplies a winner.','A matched family is not evidence that usable historical quotes exist.']);(ROOT/'reports/epl_market_candidates.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
