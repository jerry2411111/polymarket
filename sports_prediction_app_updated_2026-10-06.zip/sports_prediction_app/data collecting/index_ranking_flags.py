"""Index derived canonical publisher flags without changing their values.

The grouped alias view otherwise makes full-history queries scan thousands of
players for every output date. This internal cache has a native-person/date key.
"""
import datetime as dt,hashlib,json,sqlite3,time
from build_history_catalog import DB
from probe_history import ROOT
from temporal_queries import FLAGS

def canonical_sql():
 return 'SELECT r.as_of_date,coalesce(a.player_id,r.player_id) AS player_id,r.league,'+','.join('max(r.'+c+') AS '+c for c in FLAGS)+' FROM _player_ranking_flags_quarterly r LEFT JOIN _player_identity_aliases a ON a.source_player_id=r.player_id AND a.league=r.league GROUP BY r.as_of_date,coalesce(a.player_id,r.player_id),r.league'

def refresh(db):
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='_ranking_asof_policy'").fetchone():
  from install_latest_rankings import refresh as latest
  return latest(db)
 rows=[tuple(r) for r in db.execute(canonical_sql()+' ORDER BY r.as_of_date,player_id,r.league')]
 db.execute('CREATE TABLE IF NOT EXISTS _ranking_canonical_cache (as_of_date TEXT NOT NULL,player_id TEXT NOT NULL,league TEXT NOT NULL,'+','.join(c+' INTEGER' for c in FLAGS)+',PRIMARY KEY(player_id,league,as_of_date)) STRICT')
 existing={r[1] for r in db.execute('PRAGMA table_info(_ranking_canonical_cache)')}
 for c in FLAGS:
  if c not in existing:db.execute('ALTER TABLE _ranking_canonical_cache ADD COLUMN '+c+' INTEGER')
 db.execute('DELETE FROM _ranking_canonical_cache');db.executemany('INSERT INTO _ranking_canonical_cache VALUES ('+','.join('?' for _ in range(3+len(FLAGS)))+')',rows)
 actual=[tuple(r) for r in db.execute('SELECT * FROM _ranking_canonical_cache ORDER BY as_of_date,player_id,league')];assert rows==actual,'Derived index changed ranking flags'
 db.execute('DROP VIEW IF EXISTS _player_ranking_flags_canonical');db.execute('CREATE VIEW _player_ranking_flags_canonical AS SELECT * FROM _ranking_canonical_cache')
 from ranking_policy import refresh_policy
 refresh_policy(db,FLAGS)
 return dict(rows=len(rows),publisher_values_checked=len(rows)*len(FLAGS),values_sha256=hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest())

def main():
 db=sqlite3.connect(DB,timeout=60);before=time.perf_counter()
 with db:
  out=refresh(db);db.execute('CREATE INDEX IF NOT EXISTS _performance_league_intervals ON _player_performance_periods(league,effective_from,effective_to)')
 out.update(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',index_build_seconds=round(time.perf_counter()-before,3));started=time.perf_counter();count=db.execute("SELECT count(*) FROM player_performance WHERE league='MLB'").fetchone()[0];out.update(mlb_performance_rows=count,full_history_count_seconds=round(time.perf_counter()-started,3));out['query_plan']=[tuple(r) for r in db.execute("EXPLAIN QUERY PLAN SELECT count(*) FROM player_performance WHERE league='MLB'")]
 (ROOT/'reports/ranking_index_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()

if __name__=='__main__':main()
