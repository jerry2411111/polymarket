"""Extract dated publisher-specific ranks with native IDs and cumulative rollouts."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_nba_performance import identity_keys
from build_nba_ranking_facts import source_dates
from build_nhl_market_candidates import clean
from probe_history import ROOT

def dates(source,soup):
    if source['publisher']=='sportsnet':
        tag=soup.select_one('meta[name="sn-post-date"]')
        if not tag:raise ValueError('No dated Sportsnet article body/metadata acquired')
        day=dt.datetime.strptime(tag['content'],'%Y/%m/%d').date().isoformat()
        return day,day,{}
    return source_dates(source)

def extract(s,pub):
    facts=[];selector='p' if pub in ['sportsnet','the_hockey_news'] else 'h2,h3,h4'
    if pub=='cbs_sports':
        for i,tr in enumerate(s.select('table.ranked-players tr')):
            cells=tr.find_all('td',recursive=False);name=tr.select_one('.player-name')
            if name and cells and re.fullmatch(r'\d+',cells[0].get_text(strip=True)):
                detail=tr.select_one('.player-position').get_text(' ',strip=True);match=re.fullmatch(r'(.+) (C|D|G|LW|RW)',detail);assert match
                prose=tr.find_next_sibling('tr')
                facts.append(dict(rank=int(cells[0].get_text(strip=True)),source_player_name=name.get_text(' ',strip=True),selector='table.ranked-players tr',index=i,raw_value=tr.get_text(' ',strip=True),source_position=match[2],source_team=match[1],editorial_context=prose.get_text(' ',strip=True) if prose else None,editorial_context_index=i+1))
        return facts
    for index,tag in enumerate(s.select(selector)):
        raw=tag.get_text(' ',strip=True)
        if pub=='the_hockey_news':
            # Four explicit original-publisher facts; do not infer ranks from
            # stats, related headlines or the source's inconsistent "five" typo.
            rules=[('Quinn Hughes',9,r'highest-ranked Canucks player.*ranked ninth'),('Thatcher Demko',15,r'Next at 15th is Thatcher Demko'),('J.T. Miller',27,r'Moving ahead to 27th.*J\.T\. Miller'),('Elias Pettersson',32,r'fourth and final player.*Elias Pettersson.*ranked 32nd')]
            for name,rank,pattern in rules:
                if re.search(pattern,raw):facts.append(dict(rank=rank,source_player_name=name,selector=selector,index=index,raw_value=raw,source_position=None))
            continue
        if pub=='sportsnet':
            copy=BeautifulSoup(str(tag),'html.parser')
            for br in copy.find_all('br'):br.replace_with('\n')
            text=copy.get_text('',strip=False)
            matches=re.finditer(r'(?m)^\s*(\d+)[.]?\s+([^,\n]+),\s*([^,\n]+),\s*([^\n]+)',text)
        else:matches=re.finditer(r'^(\d+)\.\s+([^,]+),\s*(.*)',raw)
        for m in matches:
            rest=m[3].strip();position=rest.split(',')[0].strip() if re.match(r'^(?:C|D|G|F|LW|RW)(?:/\w+)?(?:,|$)',rest) else None
            facts.append(dict(rank=int(m[1]),source_player_name=m[2].strip(),selector=selector,index=index,raw_value=raw,source_position=position,source_team=m[4].strip() if pub=='sportsnet' else rest.split(',',1)[-1].strip()))
    return facts

def main():
    db=sqlite3.connect(DB,timeout=60);index=collections.defaultdict(set);canonical={};positions=collections.defaultdict(set);teams=collections.defaultdict(set)
    career={pid:json.loads(b) for pid,b in db.execute('SELECT * FROM _official_nhl_career_sources') if json.loads(b)['status']=='ok'}
    aliases={a:json.loads(b) for a,b in db.execute('SELECT * FROM _nhl_verified_ranking_aliases')} if db.execute("SELECT 1 FROM sqlite_master WHERE name='_nhl_verified_ranking_aliases'").fetchone() else {}
    for pid,b in db.execute('SELECT * FROM _official_nhl_player_bios'):
        p=json.loads(b)
        if p['status']!='ok':continue
        canonical[pid]=p['player_name']
        for name in [p['player_name']]+p.get('observed_game_names',[]):
            for key in identity_keys(name):index[key].add(pid)
    team_labels=collections.defaultdict(set)
    for b, in db.execute('SELECT body FROM _official_nhl_schedule'):
        game=json.loads(b)
        for side,key in enumerate(['awayTeam','homeTeam']):team_labels[clean(game['teams'][side])].update([game['teams'][side],game['raw'][key]['abbrev']])
    for b, in db.execute('SELECT body FROM _official_nhl_game_reports'):
        for p in json.loads(b)['players']:
            positions[p['official_player_id']].add(p.get('position'))
            teams[p['official_player_id']].add(p.get('team_name'))
            teams[p['official_player_id']].update(team_labels[clean(p.get('team_name'))])
    pages=[];issues=[];dedup={}
    for b, in db.execute('SELECT body FROM _nhl_ranking_sources'):
        source=json.loads(b)
        if source['status']!='ACQUIRED_NOT_VALIDATED':issues.append(dict(url=source['url'],reason=source.get('error')));continue
        r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(source['request_id'],)).fetchone()[0]);raw=(ROOT/r['raw_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];s=BeautifulSoup(raw,'html.parser')
        try:published,version,article=dates(source,s)
        except Exception as e:issues.append(dict(url=source['url'],reason=str(e)));continue
        if article.get('isAccessibleForFree') is False:issues.append(dict(url=source['url'],reason='Subscription-marked article excluded'));continue
        fs=extract(s,source['publisher'])
        if not fs:issues.append(dict(url=source['url'],reason='No rank-bearing public article body acquired'));continue
        expected=100 if source['publisher']=='espn' else 75 if source['publisher']=='cbs_sports' else 32 if source['publisher']=='bleacher_report' else 50
        assert all(1<=f['rank']<=expected for f in fs)
        assert len({f['rank'] for f in fs})==len(fs),'Duplicate page rank'
        for f in fs:
            ids=set().union(*(index[k] for k in identity_keys(f['source_player_name'])))
            if len(ids)>1 and f.get('source_team'):
                ids={pid for pid in ids if f['source_team'] in teams[pid]}
            is_pettersson_context=f['source_player_name']=='Elias Pettersson' and (source['publisher']=='the_hockey_news' or (source['publisher']=='cbs_sports' and 'In 2022-23, he hit 102 points' in (f.get('editorial_context') or '')))
            if len(ids)>1 and is_pettersson_context:
                proof=[]
                for pid in ids:
                    for n,season in enumerate(career.get(pid,{}).get('season_totals',[])):
                        if season.get('leagueAbbrev')=='NHL' and season.get('gameTypeId')==2 and season['season']<=20222023 and season.get('points',0)>=100:
                            proof.append((pid,n))
                ids={p for p,n in proof}
                if len(ids)==1:
                    native,n=proof[0];f['identity_evidence']=dict(reason='Article identifies a player who already had a 100-point season; official completed career season distinguishes the namesakes',request_id=career[native]['request_id'],pointer='/seasonTotals/'+str(n),raw_value=career[native]['season_totals'][n])
                    if source['publisher']=='cbs_sports':f['source_identity_discrepancy']='CBS player widget links to the defenseman namesake; the adjacent editorial text explicitly identifies the 102-point forward. Native identity follows the independently matched official career season.'
            if len(ids)>1 and f['source_position']:
                narrowed={pid for pid in ids if positions[pid]&set(f['source_position'].split('/'))}
                if narrowed:ids=narrowed
            if not ids and f['source_player_name'] in aliases:
                proof=aliases[f['source_player_name']];ids={proof['official_player_id']};f['verified_name_alias']=proof
            pid=next(iter(ids)) if len(ids)==1 else None
            f.update(player_id='NHL:'+pid if pid else None,player_name=canonical.get(pid),publisher_key=source['publisher'],source_url=source['url'],request_id=source['request_id'],source_version_date=version,source_publication_date=published)
            if pid is None:issues.append(dict(url=source['url'],name=f['source_player_name'],reason='No unique official native player identity',candidate_ids=sorted(ids)))
        # Different topic URLs can expose the very same ten-player installment.
        key=(source['publisher'],published,version,tuple((f['rank'],f['source_player_name']) for f in fs))
        if key in dedup:continue
        dedup[key]=source['url'];pages.append(dict(publisher=source['publisher'],publication=published,version=version,expected=expected,facts=fs))
    groups=collections.defaultdict(list)
    for page in pages:groups[page['publisher'],page['publication'][:4]].append(page)
    editions=[];facts=[]
    for (publisher,year),parts in groups.items():
        for day in sorted({p['version'] for p in parts}):
            eligible=sorted((p for p in parts if p['version']<=day),key=lambda p:(p['version'],p['publication']))
            ranks={};seen_names={}
            for page in eligible:
                for f in page['facts']:
                    old=ranks.get(f['rank'])
                    assert not old or old['source_player_name']==f['source_player_name'],('Conflicting within-season publisher ranks need explicit editions',publisher,year,f['rank'])
                    ranks[f['rank']]=f
            fs=list(ranks.values());expected=max(p['expected'] for p in eligible);eid='NHL_'+publisher.upper()+'_'+year+'_'+day.replace('-','')
            assert len({f['source_player_name'] for f in fs})==len(fs)
            e=dict(list_id=eid,publisher_key=publisher,publication_date=min(p['publication'] for p in eligible),version_verified_date=day,complete_list=set(ranks)==set(range(1,expected+1)),expected_ranks=expected,observed_ranks=len(ranks),request_ids=sorted({f['request_id'] for f in fs}),note='Overall current-league ranking; cumulative explicitly published installments for one season. Later revised text becomes available only at its revision date. An unlisted person is unknown, not false.')
            editions.append(e);facts.extend(dict(f,list_id=eid) for f in fs)
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _nhl_ranking_candidate_facts (body TEXT NOT NULL)');db.execute('DELETE FROM _nhl_ranking_candidate_facts');db.executemany('INSERT INTO _nhl_ranking_candidate_facts VALUES (?)',[(json.dumps(f),) for f in facts])
        db.execute('CREATE TABLE IF NOT EXISTS _nhl_ranking_candidate_editions (list_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nhl_ranking_candidate_editions');db.executemany('INSERT INTO _nhl_ranking_candidate_editions VALUES (?,?)',[(e['list_id'],json.dumps(e)) for e in editions])
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),facts=len(facts),native_mapped=sum(f['player_id'] is not None for f in facts),unique_publisher_player_source_facts=len({(f['publisher_key'],f['player_id'],f['request_id'],f['rank']) for f in facts}),publishers=len({p for p,y in groups}),editions=editions,issues=issues)
    (ROOT/'reports/nhl_ranking_candidates.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='editions'}));db.close()

if __name__=='__main__':main()
