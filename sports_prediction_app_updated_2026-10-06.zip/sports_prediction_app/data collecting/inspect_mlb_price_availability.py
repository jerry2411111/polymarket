import collections,json,sqlite3
from build_history_catalog import DB
from core import utc
from quote_selection import nearest_pregame,available_at
db=sqlite3.connect(DB);gs={g:json.loads(b) for g,b in db.execute('SELECT * FROM _mlb_canonical_games')};cs=[json.loads(b) for b, in db.execute('SELECT body FROM _mlb_market_candidates')];feeds={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_mlb_feeds')};points=collections.defaultdict(list)
for b, in db.execute('SELECT body FROM _history_price_points'):
    x=json.loads(b)
    if (x['provider']=='kalshi' and x['contract_id'].startswith('KXMLBGAME-')) or x['provider']=='polymarket':points[x['provider'],x['contract_id']].append(x)
counts=collections.Counter();examples=[]
for c in cs:
    g=gs[c['game_id']];f=feeds[g['official_game_id']];start=utc(f['actual_first_pitch_utc'] or g['start']).timestamp();opened=utc(c['open']).timestamp();xs=points[c['provider'],c['contract_id']];valid=[x for x in xs if x['timestamp']>=opened]
    p=nearest_pregame(valid,start,start);why='usable pre0' if p else 'no cached raw points' if not xs else 'all points precede recorded market creation' if not valid else 'no complete pregame observation'
    counts[c['provider'],g['date'][:4],why]+=1
    if not p and xs and len(examples)<12:examples.append(dict(game=g['game_id'],provider=c['provider'],start=utc(start).isoformat(),open=c['open'],cid=c['contract_id'],reason=why,points=sorted(xs,key=lambda x:x['timestamp'])[:3]))
print('COUNTS',json.dumps([dict(provider=k[0],year=k[1],reason=k[2],contracts=v) for k,v in counts.items()]));print('EXAMPLES',json.dumps(examples))
