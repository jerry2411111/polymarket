"""Official biography and dated career sources for people in published EPL games."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from build_history_catalog import DB
from collect_premier_pilot import BASE
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--retry-errors',action='store_true');ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100
    HOSTS.add('sdp-prem-prod.premier-league-prod.pulselive.com');db=sqlite3.connect(DB,timeout=60);first={};coaches={}
    for gid,b in db.execute("SELECT * FROM _eu_game_facts WHERE json_extract(body,'$.competition')='Premier League' ORDER BY json_extract(body,'$.date')"):
        g=json.loads(b);r=json.loads(db.execute('SELECT body FROM _official_epl_game_reports WHERE match_id=?',(g['official_match_id'],)).fetchone()[0])
        for side in ['away_team','home_team']:
            lineup=r['sources']['lineups']['data'][side]
            for p in lineup['players']:first.setdefault(p['id'],g['date'])
            for p in lineup['managers']:
                if p.get('type')=='Manager':coaches.setdefault(p['id'],g['date'])
    db.execute('CREATE TABLE IF NOT EXISTS _official_epl_people_sources (person_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();done={k:json.loads(b) for k,b in db.execute('SELECT * FROM _official_epl_people_sources') if json.loads(b)['status']=='ok' or not a.retry_errors};jobs=collections.defaultdict(list)
    for kind,people in [('player',first),('manager',coaches)]:
        for pid,day in sorted(people.items(),key=lambda x:(x[1],x[0]))[:3 if a.pilot else None]:jobs[day[:7]].append((kind,pid,day))
    client=HistoryClient();client.min_interval=.5;parts=[];day=dt.date(2024,1,1)
    def fetch(job):
        kind,pid,first_date=job;key=kind+':'+pid
        if key in done:return key,done[key]
        sources={};row=dict(kind=kind,official_person_id=pid,first_collected_date=first_date,sources=sources)
        try:
            paths={'biography':f'/v1/players/{pid}','career':f'/v1/players/{pid}/career'} if kind=='player' else {'biography':f'/v1/managers/{pid}'}
            for name,path in paths.items():
                raw,r=client.get(BASE+path,refresh=a.retry_errors and name=='career');sources[name]=dict(request_id=r['request_id'],endpoint=r['endpoint'],raw=raw)
                if name=='biography' and kind=='player':assert isinstance(raw,list) and all(str(p['id']['playerId'])==pid for p in raw)
                elif name=='career':assert isinstance(raw,dict) and isinstance(raw.get('person'),list)
                else:assert isinstance(raw,(dict,list))
            row['status']='ok'
        except Exception as e:row.update(status='error',error=type(e).__name__+': '+str(e))
        return key,row
    while day<=dt.date(2026,9,14) and (a.pilot or len(parts)<math.ceil(33*a.through_percent/100)):
        month=day.strftime('%Y-%m');counts=collections.Counter();errors=[];before=client.requests
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            for key,row in pool.map(fetch,jobs[month]):
                if key not in done:
                    with db:db.execute('INSERT OR REPLACE INTO _official_epl_people_sources VALUES (?,?)',(key,json.dumps(row)))
                counts[row['status']]+=1
                if row['status']=='error':errors.append(dict(person_key=key,error=row['error']))
        parts.append(dict(month=month,people=len(jobs[month]),counts=dict(counts),errors=errors))
        out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='EPL people source acquisition',pilot=a.pilot,total_months=33,months_processed=len(parts),completed_months=sum(not p['errors'] for p in parts),unique_players=len(first),unique_head_coaches=len(coaches),new_requests=client.requests,months=parts,limits=['Only official biography/career raw sources acquired here; no source season totals enter date-specific performance.','Manager biography affiliation can be stale; official dated game lineups remain the affiliation observations.','Salary and complete historical injury reporting are separate acquisition tasks.'])
        (ROOT/'reports'/('epl_people_'+('pilot' if a.pilot else 'months')+'.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
        if client.requests>before or errors:print('EPL PEOPLE',month,dict(counts),'months',len(parts),'/33',flush=True)
        # One unavailable person must not prevent independent later-date people
        # from being attempted. Failed responses remain explicit and retryable.
        day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
    print('EPL PEOPLE REQUESTS',client.requests,flush=True);db.close()

if __name__=='__main__':main()
