"""Date-batched, bounded previous-price queries for still-missing EPL targets."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from build_history_catalog import DB
from core import utc
from epl_price_points import Sources,load
from history_client import HistoryClient
from probe_history import ROOT
from quote_selection import nearest_pregame
from schema import HOURS

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100
    db=sqlite3.connect(DB,timeout=60);cs={('polymarket',c['contract_id']):c for b, in db.execute('SELECT body FROM _epl_market_candidates') if (c:=json.loads(b))['provider']=='polymarket' and not c.get('draw_half_payout_rule')};reports={m:json.loads(b) for m,b in db.execute('SELECT * FROM _official_epl_game_reports')};games={m:json.loads(b) for m,b in db.execute('SELECT * FROM _official_epl_calendar')};src=Sources(db);points,conflicts,_=load(db,cs,src)
    assert not conflicts,'Resolve raw quote revisions before recovery'
    db.execute('CREATE TABLE IF NOT EXISTS _epl_polymarket_asof (job_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();done={k:json.loads(b) for k,b in db.execute('SELECT * FROM _epl_polymarket_asof') if json.loads(b)['status']=='ok'};by_month=collections.defaultdict(list);before_open=0
    for key,c in cs.items():
        mid=c['official_match_id'];s=reports.get(mid,{}).get('derived',{}).get('actual_start_utc')
        if not s:continue
        start=utc(s).timestamp();opened=utc(c['open']);opened=opened.timestamp() if opened else None;xs=[x for x in points[key] if opened is None or x['timestamp']>=opened]
        for h in HOURS:
            target=start-h*3600;ask=math.ceil(target)-1 if h==0 else math.floor(target)
            if opened is not None and opened>ask:before_open+=1;continue
            if nearest_pregame(xs,target,start) is not None:continue
            by_month[games[mid]['date'][:7]].append(dict(provider='polymarket',game_id=c['game_id'],contract_id=c['contract_id'],target='pre_'+str(h),as_of=ask,target_timestamp=target,open_timestamp=opened))
    client=HistoryClient();parts=[];day=dt.date(2024,1,1)
    def fetch(j):
        key=j['contract_id']+':'+str(j['as_of'])
        if key in done:return key,done[key]
        ask=j['as_of'];ids=[];x=None
        try:
            for _ in range(8):
                data,r=client.get('https://data-api.polymarket.com/v2/prices-history',dict(token_id=j['contract_id'],as_of=ask));ids.append(r['request_id']);assert len(data['data'])<=1 and not data.get('pagination',{}).get('next_cursor');x=data['data'][0] if data['data'] else None
                if x is None:break
                assert x['timestamp']<=ask and 0<=x['price']<=1
                if x['resolution_seconds']>0 and x['timestamp']+x['resolution_seconds']<=j['target_timestamp']:break
                ask=x['timestamp']-1
            valid=bool(x and x['resolution_seconds']>0 and x['timestamp']+x['resolution_seconds']<=j['target_timestamp'] and (j['open_timestamp'] is None or x['timestamp']>=j['open_timestamp']))
            return key,dict(**j,status='ok',request_ids=ids,point=x,usable=valid)
        except Exception as e:return key,dict(**j,status='error',request_ids=ids,error=type(e).__name__+': '+str(e))
    while day<=dt.date(2026,9,14) and len(parts)<math.ceil(33*a.through_percent/100):
        month=day.strftime('%Y-%m');counts=collections.Counter();errors=[]
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            for key,row in pool.map(fetch,by_month[month]):
                if key not in done:
                    with db:db.execute('INSERT OR REPLACE INTO _epl_polymarket_asof VALUES (?,?)',(key,json.dumps(row)))
                counts[row['status']]+=1;counts['usable']+=bool(row.get('usable'))
                if row['status']=='error':errors.append(row)
        parts.append(dict(month=month,missing_targets=len(by_month[month]),results=dict(counts),errors=errors))
        out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='EPL missing previous-price recovery',total_months=33,months_processed=len(parts),completed_months=sum(not p['errors'] for p in parts),before_contract_creation=before_open,new_requests=client.requests,months=parts,meaning='Only missing targets, using official as_of and no more than eight backward steps. No future bucket or zero-duration terminal value. Raw query provenance retained.')
        (ROOT/'reports/epl_missing_previous_quotes.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
        if counts:print('EPL PREVIOUS QUOTES',month,dict(counts),'months',len(parts),'/33',flush=True)
        if errors:break
        day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
    print('EPL PREVIOUS QUOTE REQUESTS',client.requests,flush=True);db.close()

if __name__=='__main__':main()
