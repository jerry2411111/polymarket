"""Dated official roster/acquisition evidence, biography constants and injuries."""
import collections,datetime as dt,json,re,sqlite3
from build_history_catalog import DB
from probe_history import ROOT

def main():
    db=sqlite3.connect(DB,timeout=60);wanted={r[0].split(':')[1] for r in db.execute('SELECT DISTINCT player_id FROM _nba_player_game_facts')}
    names={pid.split(':')[1]:json.loads(b)['player_name'] for pid,b in db.execute('SELECT player_id,body FROM _nba_player_game_facts')}
    sources=collections.defaultdict(list)
    for (body,) in db.execute("SELECT body FROM _official_player_biographies WHERE league='NBA'"):
        b=json.loads(body);pid=str(b['official_player_id'])
        if pid in wanted:sources[pid].append(b)
    constants=[];affiliations=[];issues=[]
    for pid in sorted(wanted):
        rows=sorted(sources[pid],key=lambda x:(x.get('pointer')=='/props/pageProps/player/info',x['observed_at_utc']),reverse=True)
        b=dict(rows[0]) if rows else {};height=weight=None;field_sources={}
        for field in ['height','weight','birth_date','seasons']:
            hits=[x for x in rows if x.get(field) not in [None,'']]
            if hits:b[field]=hits[0][field];field_sources[field]=hits[0]['request_id']
        if b.get('height'):
            m=re.fullmatch(r'(\d+)-(\d+)',str(b['height']))
            if m:height=(int(m[1])*12+int(m[2]))*2.54
            else:issues.append(dict(player_id=pid,field='height',raw=b['height']))
        if b.get('weight'):
            try:weight=float(b['weight'])*0.45359237
            except ValueError:issues.append(dict(player_id=pid,field='weight',raw=b['weight']))
        regular_seasons=sorted({int(s[1:]) for s in b.get('seasons',[]) or [] if re.fullmatch(r'2\d{4}',str(s))})
        constants.append((f'NBA:{pid}',names[pid],b.get('birth_date'),weight,height,json.dumps(regular_seasons) if b.get('seasons') is not None else None,b.get('request_id'),json.dumps(dict(source_url=b.get('source_url'),field_source_request_ids=field_sources,raw_height=b.get('height'),raw_weight=b.get('weight'),physical_measurements_are_sourced_constants=True,experience_basis='Count of documented regular seasons ending before the selected date; not a projection of current SEASON_EXP'))))
        for b in rows:
            # Individual inactive-career profiles can display a former team.
            # Only an actual current official team-roster entry is used here.
            how=b.get('how_acquired')
            if how is None or not b.get('team_name'):continue
            observed=b['observed_at_utc'][:10]
            shared=dict(player_id='NBA:'+pid,team_name={'LA Clippers':'Los Angeles Clippers'}.get(b['team_name'],b['team_name']),request_id=b['request_id'],source_url=b['source_url'],raw_how_acquired=how)
            affiliations.append(dict(**shared,event_date=observed,kind='CURRENT_OFFICIAL_ROSTER_OBSERVATION',tenure_start=None))
            m=re.fullmatch(r'(?:Signed on|Traded from [A-Z]{2,3} on) (\d{2}/\d{2}/\d{2})',how)
            if m:
                start=dt.datetime.strptime(m[1],'%m/%d/%y').date().isoformat()
                if start>observed:issues.append(dict(player_id=pid,field='how_acquired',raw=how,reason='Acquisition after observation date'));continue
                affiliations.append(dict(**shared,event_date=start,kind='DATED_OFFICIAL_ACQUISITION',tenure_start=start))
    db.execute('CREATE TABLE IF NOT EXISTS _nba_player_bio_constants (player_id TEXT PRIMARY KEY,player_name TEXT NOT NULL,birth_date TEXT,weight_kg REAL,height_cm REAL,regular_seasons TEXT,source_request_id TEXT,audit_json TEXT NOT NULL) STRICT');db.execute('DELETE FROM _nba_player_bio_constants');db.executemany('INSERT INTO _nba_player_bio_constants VALUES (?,?,?,?,?,?,?,?)',constants)
    # Different source roster pages can repeat the same acquisition; preserve a
    # unique factual event while retaining each original source in the raw store.
    unique={(a['player_id'],a['event_date'],a['team_name'],a['kind']):a for a in affiliations}
    db.execute('CREATE TABLE IF NOT EXISTS _nba_affiliation_events (player_id TEXT NOT NULL,event_date TEXT NOT NULL,team_name TEXT NOT NULL,kind TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(player_id,event_date,team_name,kind)) STRICT');db.execute('DELETE FROM _nba_affiliation_events');db.executemany('INSERT INTO _nba_affiliation_events VALUES (?,?,?,?,?)',[(pid,day,team,kind,json.dumps(a)) for (pid,day,team,kind),a in unique.items()])
    roster=[];injuries=[]
    for pid,gid,body in db.execute('SELECT player_id,game_id,body FROM _nba_player_game_facts'):
        p=json.loads(body);source=p.get('roster_request_id') or p['request_id'];comment=p.get('comment') or ''
        injured=not p['did_play'] and ('injury/illness' in comment.lower() or 'concussion' in comment.lower())
        roster.append((pid,gid,p['game_date'],p['team_name'],int(p['did_play']),p['starter'],int(p['temporary_team']),source))
        injuries.append((pid,p['game_date'],gid,int(injured),source,json.dumps(dict(raw_comment=comment,classification='REPORTED_INJURY_ILLNESS_OR_CONCUSSION' if injured else 'NOT_INJURED_DEFAULT_NO_INJURY_REPORTED',source='Official NBA game-page roster',episode_id=None,note='No medical episode identifier. Consecutive missed games cannot establish a count of distinct injuries.'))))
    db.execute('CREATE TABLE IF NOT EXISTS _nba_roster_game_observations (player_id TEXT NOT NULL,game_id TEXT NOT NULL,game_date TEXT NOT NULL,team_name TEXT NOT NULL,did_play INTEGER NOT NULL,starter INTEGER,is_temporary INTEGER NOT NULL,source_request_id TEXT NOT NULL,PRIMARY KEY(player_id,game_id)) STRICT');db.execute('DELETE FROM _nba_roster_game_observations');db.executemany('INSERT INTO _nba_roster_game_observations VALUES (?,?,?,?,?,?,?,?)',roster)
    db.execute('CREATE TABLE IF NOT EXISTS _nba_injury_observations (player_id TEXT NOT NULL,observation_date TEXT NOT NULL,game_id TEXT NOT NULL,reported_injured INTEGER NOT NULL,source_request_id TEXT NOT NULL,audit_json TEXT NOT NULL,PRIMARY KEY(player_id,game_id)) STRICT');db.execute('DELETE FROM _nba_injury_observations');db.executemany('INSERT INTO _nba_injury_observations VALUES (?,?,?,?,?,?)',injuries)
    db.execute('CREATE INDEX IF NOT EXISTS _nba_roster_person_date ON _nba_roster_game_observations(player_id,game_date,team_name)');db.execute('CREATE INDEX IF NOT EXISTS _nba_injury_person_date ON _nba_injury_observations(player_id,observation_date DESC,game_id DESC)');db.commit();db.close()
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),native_player_ids=len(wanted),biographies_with_source=sum(x[6] is not None for x in constants),missing_constants={k:sum(x[i] is None for x in constants) for k,i in [('birth_date',2),('weight_kg',3),('height_cm',4),('regular_seasons',5)]},dated_affiliation_events=len(unique),official_acquisition_events=sum(x['kind']=='DATED_OFFICIAL_ACQUISITION' for x in unique.values()),roster_game_rows=len(roster),reported_injury_illness_concussion_observations=sum(x[3] for x in injuries),issues=issues,scope='Biography constants plus dated evidence only. Distinct injury counts and complete career team-history counts remain unavailable without sufficient source records.')
    (ROOT/'reports/nba_personal_facts.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))

if __name__=='__main__':main()
