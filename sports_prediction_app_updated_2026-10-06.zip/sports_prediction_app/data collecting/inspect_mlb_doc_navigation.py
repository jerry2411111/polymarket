﻿import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
for rid in ['4d764a175e0c46488360e9df3fcec834','d19b986fe8f14cfb9d72197ac08d817a']:
 r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);text=(ROOT/r['raw_file']).read_text(encoding='utf-8',errors='replace')
 if 'docs.statsapi' in r['endpoint']:
  print('DOC ROUTES',sorted(set(x for x in re.findall(r'"(/[^"\s]{1,150})"',text) if any(w in x for w in ['getting-started','introduction','authentication','gumbo','swagger','reference']))))
 else:
  s=BeautifulSoup(text,'html.parser');data=json.loads(s.find('script',id='appInfo').string);print('APPINFO KEYS',list(data));print('PUBLIC DATA LOCATIONS',{k:v for k,v in data.items() if k.lower() in ['gamepk','statsapi','statsapihost','api','gametype','gameinfo','game']})
