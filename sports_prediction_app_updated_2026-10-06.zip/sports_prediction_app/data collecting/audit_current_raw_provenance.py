"""Read-only check for interrupted requests and unreferenced response files."""
import datetime as dt,json,sqlite3,time
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB);rs=[json.loads(b) for b, in db.execute('SELECT metadata_json FROM _request_audit')];known={r['raw_file'] for r in rs if r.get('raw_file')};now=time.time();unreferenced=[]
for p in (ROOT/'data/raw/responses').iterdir():
    if p.is_file() and now-p.stat().st_mtime>120 and p.relative_to(ROOT).as_posix() not in known:unreferenced.append(dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size))
pending=[dict(request_id=r['request_id'],endpoint=r['endpoint'],parameters=r['parameters'],requested_at_utc=r['requested_at_utc']) for r in rs if r.get('request_state')=='in_flight']
report=dict(checked_at_utc=dt.datetime.now(dt.UTC).isoformat(),logged_requests=len(rs),unreferenced_raw_files_older_than_120_seconds=unreferenced,pending_requests=pending,note='Read-only audit; files from active requests younger than two minutes are excluded from orphan detection. A pending request has not yet supplied a usable response.')
(ROOT/'reports/raw_provenance_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='pending_requests'}));print('Pending',len(pending));db.close()
