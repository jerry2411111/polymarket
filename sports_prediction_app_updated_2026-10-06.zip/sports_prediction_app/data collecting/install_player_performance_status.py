"""Expose zero-appearance status without suppressing any observed performance."""
import datetime as dt
import json
import sqlite3

from build_history_catalog import DB
from probe_history import ROOT
from temporal_queries import PUBLIC_PLAYER, PLAYER_STATUS_SQL


def main():
    db = sqlite3.connect(DB, timeout=120)
    sql = db.execute("SELECT sql FROM sqlite_master WHERE name='player_performance'").fetchone()[0]
    columns = [r[1] for r in db.execute('PRAGMA table_info(player_performance)')]
    changed = 'performance_status' not in columns
    if changed:
        prefix = 'CREATE VIEW player_performance AS SELECT ' + ','.join('p.' + c for c in PUBLIC_PLAYER)
        if not sql.startswith(prefix + ','):
            raise ValueError('Unexpected view definition; no changes made')
        replacement = sql.replace(prefix, prefix + ',' + PLAYER_STATUS_SQL, 1)
        with db:
            db.execute('DROP VIEW player_performance')
            db.execute(replacement)
            assert 'performance_status' in [r[1] for r in db.execute('PRAGMA table_info(player_performance)')]
    report = dict(
        generated_at_utc=dt.datetime.now(dt.UTC).isoformat(), changed=changed,
        field='performance_status',
        values={'insufficient matches': 'Zero collected played appearances through the query date.',
                'observed matches': 'At least one collected played appearance; compute each statistic from its available values.'},
        no_year_exclusion=True,
        zero_policy='Performance statistics are zero only for no observations, or where the observed statistic genuinely equals zero.',
        undefined_statistics='Sample SD remains NULL with one valid observation; missing source statistics after appearances remain NULL.',
    )
    (ROOT / 'reports/player_performance_status_install.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    db.close()
    print(json.dumps(report))


if __name__ == '__main__':
    main()
