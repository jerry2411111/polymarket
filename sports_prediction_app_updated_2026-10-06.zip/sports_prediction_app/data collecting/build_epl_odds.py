"""Publish only source-verified EPL probabilities into provider-separated EU soccer tables."""
import collections,datetime as dt,hashlib,json,math,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from build_history_odds import export
from epl_price_points import Sources,pointer,load
from eu_schema import EU_PRE_COLUMNS,EU_INGAME_COLUMNS,refresh_main_views
from schema import HOURS,aligned
from core import utc,odd
from quote_selection import available_at,nearest_pregame,inside_window

def main():
    db=sqlite3.connect(DB,timeout=60);src=Sources(db);validation=json.loads((ROOT/'reports/epl_full_report_validation.json').read_text());verified=set(validation['verified_match_ids']);assert verified;assert json.loads((ROOT/'reports/epl_price_pilot_validation.json').read_text())['status']=='WORKING'
    games={mid:json.loads(b) for mid,b in db.execute('SELECT * FROM _official_epl_calendar')};reports={mid:json.loads(b) for mid,b in db.execute('SELECT * FROM _official_epl_game_reports')};cs={(c['provider'],c['contract_id']):c for b, in db.execute('SELECT body FROM _epl_market_candidates') if (c:=json.loads(b))['official_match_id'] in verified};points,conflicts,excluded=load(db,cs,src);families=collections.defaultdict(list);audits=[];eligibility=[];canonical={}
    for c in cs.values():
        raw,_=src.get(c['request_id']);m=pointer(raw,c['pointer'])
        if c['provider']=='polymarket':
            array=lambda v:json.loads(v) if isinstance(v,str) else v;assert array(m['clobTokenIds'])[c['outcome_index']]==c['contract_id'] and array(m['outcomes'])[c['outcome_index']]=='Yes'
        else:assert m['ticker']==c['contract_id'] and m['yes_sub_title']==c['team_question']
        opened=utc(c['open'])
        points[c['provider'],c['contract_id']]=[p for p in points[c['provider'],c['contract_id']] if not opened or p['timestamp']>=opened.timestamp()]
        families[c['provider'],c['game_id'],c['family_id']].append(c)
    choices=collections.defaultdict(list)
    for (p,gid,fid),members in families.items():
        reason=None
        if sorted(c['side'] for c in members)!=[0,1,2]:reason='Incomplete explicit team/draw outcome family'
        elif any(c.get('draw_half_payout_rule') for c in members):reason='Written draw payout is 50-50; not an unambiguous team-win probability'
        if reason:eligibility.append(dict(provider=p,game_id=gid,family_id=fid,included=False,reason=reason));continue
        choices[p,gid].append((max(c['open'] for c in members),fid,members))
    outputs={p:{'pre_match':[],'in_game':[]} for p in ['polymarket','kalshi']};selected_checks=0
    def select(c,field,lo,start,hi=None):
        nonlocal selected_checks
        xs=points[c['provider'],c['contract_id']];x=nearest_pregame(xs,lo,start) if hi is None and lo is not None else min((x for x in xs if inside_window(x,lo,hi)),key=lambda x:(available_at(x),x['timestamp'],x['resolution_seconds']),default=None)
        r=None
        if x:
            raw,r=src.get(x['request_id']);assert float(pointer(raw,x['pointer']))==x['price'];selected_checks+=1
        audits.append(dict(provider=c['provider'],game_id=c['game_id'],family_id=c['family_id'],side=c['side'],contract_id=c['contract_id'],market_id=c['market_id'],target=field,target_timestamp_utc=utc(lo).isoformat() if lo is not None else None,window_end_utc=utc(hi).isoformat() if hi is not None else None,price=x['price'] if x else None,source=x,source_age_seconds=lo-x['timestamp'] if x else None,request_endpoint=r['endpoint'] if r else None,request_parameters=r['parameters'] if r else None,reason=None if x else 'No eligible previous observation' if hi is None else 'No available quote within verified checkpoint window'))
        return x['price'] if x else None
    for (provider,gid),variants in sorted(choices.items()):
        best=None
        for _,fid,members in sorted(variants):
            mid=members[0]['official_match_id'];g=games[mid];f=reports[mid];d=f['derived'];s=d['actual_start_utc']
            if not s:continue
            start=utc(s).timestamp();row=dict.fromkeys(EU_PRE_COLUMNS);row.update(match=g['away']['name']+'/'+g['home']['name'],date=g['date'],timestamp=s,game_type='Soccer',league='EU soccer',competition='Premier League',season=g['season'],location=g['location'],home_away='Away;Home',final=g['winner'],teamA_final_score=g['away']['score'],teamB_final_score=g['home']['score'],game_id=gid)
            for c in members:
                side=['teamA','teamB','draw'][c['side']]
                for h in HOURS:
                    p=select(c,'pre_'+str(h),start-h*3600,start);row[f'{side}_pre_{h}_p']=p;row[f'{side}_pre_{h}_odd']=odd(p)
            hs=utc(d['halftime_start_utc']).timestamp() if d['halftime_start_utc'] else None;rs=utc(d['second_half_start_utc']).timestamp() if d['second_half_start_utc'] else None;windows=[(start,start+120),(hs,rs),(rs,rs+120 if rs else None)];ing=dict(match=row['match'],game_type='Soccer',league='EU soccer',competition='Premier League',season=g['season'],timestamp=aligned([utc(v[0]).isoformat() if v[0] is not None else None for v in windows]),checkpoint='START;HALFTIME;SECOND_HALF_START',teamA_score=aligned([0,g['away']['halfTimeScore'],g['away']['halfTimeScore']]),teamB_score=aligned([0,g['home']['halfTimeScore'],g['home']['halfTimeScore']]),game_id=gid);ing_count=0
            for c in members:
                vals=[select(c,'ingame_'+str(n),lo,start,hi) if lo is not None and hi is not None else None for n,(lo,hi) in enumerate(windows)];side=['teamA','teamB','draw'][c['side']];ing[side+'_ingame_p']=aligned(vals);ing[side+'_ingame_odd']=aligned([odd(v) for v in vals]);ing_count+=sum(v is not None for v in vals)
            if any(row[k] is not None for k in EU_PRE_COLUMNS if k.endswith('_p')) or ing_count:best=(row,ing,ing_count,members,g,f);break
            eligibility.append(dict(provider=provider,game_id=gid,family_id=fid,included=False,reason='No usable pre-match or checkpoint observations acquired'))
        if best:
            row,ing,ing_count,members,g,f=best;outputs[provider]['pre_match'].append(row)
            if ing_count:outputs[provider]['in_game'].append(ing)
            eligibility.append(dict(provider=provider,game_id=gid,family_id=members[0]['family_id'],included=True,reason=None));canonical[gid]=dict(game_id=gid,league='EU soccer',competition='Premier League',game_type='Soccer',date=g['date'],season=g['season'],official_match_id=g['official_match_id'],teams=[g['away']['name'],g['home']['name']],team_ids=[g['away']['id'],g['home']['id']],scores=[g['away']['score'],g['home']['score']],winner=g['winner'],start=row['timestamp'],location=g['location'],home_away=row['home_away'],official_request_id=f['sources']['match']['request_id'],completion_utc=f['derived']['regulation_end_utc'])
    selected_families={(r['provider'],r['game_id'],r['family_id']) for r in eligibility if r['included']}
    for a in audits:a['selected_family']=(a['provider'],a['game_id'],a['family_id']) in selected_families
    existing={t:hashlib.sha256(json.dumps(db.execute('SELECT * FROM '+t+' ORDER BY game_id').fetchall()).encode()).hexdigest() for t in ['polymarket_pre_match','kalshi_pre_match','polymarket_in_game','kalshi_in_game']}
    with db:
        for provider,tables in outputs.items():
            for kind,rows in tables.items():
                table='_source_'+provider+'_soccer_'+kind;columns=EU_PRE_COLUMNS if kind=='pre_match' else EU_INGAME_COLUMNS;defs=['"'+c+'" '+('REAL' if '_pre_' in c else 'INTEGER' if c in ['teamA_final_score','teamB_final_score'] else 'TEXT')+(' PRIMARY KEY' if c=='game_id' else '') for c in columns];db.execute('CREATE TABLE IF NOT EXISTS '+table+' ('+','.join(defs)+') STRICT');db.execute('DELETE FROM '+table+" WHERE competition='Premier League'");db.executemany('INSERT INTO '+table+' VALUES ('+','.join('?' for _ in columns)+')',[tuple(r[c] for c in columns) for r in rows])
        for name,rows in [('_epl_odds_selections',audits),('_epl_odds_eligibility',eligibility)]:db.execute('CREATE TABLE IF NOT EXISTS '+name+' (body TEXT NOT NULL) STRICT');db.execute('DELETE FROM '+name);db.executemany('INSERT INTO '+name+' VALUES (?)',[(json.dumps(r),) for r in rows])
        db.execute('CREATE TABLE IF NOT EXISTS _eu_game_facts (game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute("DELETE FROM _eu_game_facts WHERE json_extract(body,'$.competition')='Premier League'");db.executemany('INSERT INTO _eu_game_facts VALUES (?,?)',[(gid,json.dumps(g)) for gid,g in canonical.items()]);refresh_main_views(db)
    for t,digest in existing.items():assert hashlib.sha256(json.dumps(db.execute('SELECT * FROM '+t+' ORDER BY game_id').fetchall()).encode()).hexdigest()==digest
    for provider in outputs:
        for kind,columns in [('pre_match',EU_PRE_COLUMNS),('in_game',EU_INGAME_COLUMNS)]:
            cursor=db.execute('SELECT * FROM '+'_source_'+provider+'_soccer_'+kind+' ORDER BY date,game_id' if kind=='pre_match' else 'SELECT * FROM '+'_source_'+provider+'_soccer_'+kind+' ORDER BY game_id');names=[v[0] for v in cursor.description];rows=[dict(zip(names,r)) for r in cursor];export('eu_soccer/'+provider+'/'+kind,rows,columns,db=db)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='PARTIALLY WORKING',scope='Published verified EPL within combined EU soccer outputs; all 33 requested date batches attempted for pre-match and break prices. Other five competitions and incomplete supporting fields remain pending.',providers={p:{k:len(v) for k,v in tables.items()} for p,tables in outputs.items()},distinct_games=len(canonical),raw_selected_value_checks=selected_checks,raw_source_hash_checks=len(src.cache),source_conflicts=conflicts,excluded_observations=excluded,excluded_families=dict(collections.Counter(x['reason'] for x in eligibility if not x['included'])),official_report_validation_generated_at=validation['generated_at_utc'],missing_percent={p:{c:round(sum(r[c] is None for r in tables['pre_match'])*100/len(tables['pre_match']),4) if tables['pre_match'] else None for c in EU_PRE_COLUMNS} for p,tables in outputs.items()},sql_main_view_includes_eu=True)
    (ROOT/'reports/epl_odds_publication.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['missing_percent','source_conflicts']}));db.close()

if __name__=='__main__':main()
