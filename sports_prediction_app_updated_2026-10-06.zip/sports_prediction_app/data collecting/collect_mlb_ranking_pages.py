"""Retain dated major-publisher MLB rankings for native-ID verification."""
import concurrent.futures,datetime as dt,json,sqlite3
from urllib.parse import urlsplit
from bs4 import BeautifulSoup
from build_history_catalog import DB
from collect_nba_ranking_pages import metadata
from history_client import HistoryClient
from probe_history import ROOT,HOSTS

PAGES=[
('espn','https://www.espn.com/mlb/story/_/id/39652798/mlb-rank-2024-baseball-top-100-players'),
('espn','https://www.espn.com/mlb/story/_/id/44479475/mlb-rank-2025-top-100-baseball-players-ohtani-judge-betts-skenes-witt'),
('espn','https://www.espn.com/mlb/story/_/id/45947026/mlb-rank-2025-season-update-top-50-baseball-players-judge-ohtani-skubal-raleigh'),
('mlb_network','https://www.mlb.com/news/mlb-network-top-100-players-for-2025'),
('mlb_network','https://www.mlb.com/news/top-100-mlb-players-for-2026-by-mlb-network'),
('cbs_sports','https://www.cbssports.com/mlb/news/ranking-mlbs-top-100-players-in-2025-shohei-ohtani-is-no-1-but-how-do-baseballs-other-stars-stack-up/'),
('fox_sports','https://www.foxsports.com/stories/mlb/2025-top-50-mlb-players-shohei-ohtani-still-no-1'),
('bleacher_report','https://bleacherreport.com/articles/25172763-ranking-shohei-ohtani-aaron-judge-and-top-25-mlb-players-2025'),
('bleacher_report','https://bleacherreport.com/articles/25405322-ranking-shohei-ohtani-paul-skenes-and-top-25-mlb-players-2026'),
]

def main():
    HOSTS.update(urlsplit(u).hostname for _,u in PAGES);c=HistoryClient();db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _mlb_ranking_sources (url TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();prior={u:json.loads(b) for u,b in db.execute('SELECT * FROM _mlb_ranking_sources')};rows=[]
    def fetch(item):
        pub,url=item
        if url in prior:return prior[url]
        try:
            b,r=c.get(url,document=True);s=BeautifulSoup(b,'html.parser')
            return dict(publisher=pub,url=url,status='ACQUIRED_NOT_VALIDATED',request_id=r['request_id'],retrieved_at_utc=r['retrieved_at_utc'],title=s.title.get_text(' ',strip=True) if s.title else None,metadata=metadata(s))
        except Exception as e:return dict(publisher=pub,url=url,status='UNAVAILABLE',error=type(e).__name__+': '+str(e))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for x in pool.map(fetch,PAGES):
            db.execute('INSERT OR REPLACE INTO _mlb_ranking_sources VALUES (?,?)',(x['url'],json.dumps(x)));db.commit();rows.append(x);print('MLB RANKING SOURCE',x['publisher'],x['status'],flush=True)
    out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=rows,new_requests=c.requests,note='Raw acquisition only; publisher independence, edition/revision date, list scope, rank and native player identity require validation before performance flags.')
    (ROOT/'reports/mlb_ranking_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
