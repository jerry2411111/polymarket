"""Verify the official SSR match-detail query against its public Firebase response."""
import datetime as dt,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from probe_bundesliga_archives import BASE
from probe_eu_official_reports import brief

def main():
 db=sqlite3.connect(DB);rid='3b142708657b446a91eb34ab262435b5';r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);soup=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser');pairs=[(k,v) for script in soup.find_all('script',type='application/json') for k,v in json.loads(script.get_text()).items() if k.startswith('_getDataFromFirebase-/en/')];assert len(pairs)==1;k,v=pairs[0];node,slug=k.removeprefix('_getDataFromFirebase-').split('slugs/slugLong');assert slug.endswith('2');slug=slug[:-1];c=HistoryClient();HOSTS.add('bundesliga-web-prod.europe-west1.firebasedatabase.app');params=dict(orderBy='"slugs/slugLong"',equalTo=json.dumps(slug),limitToFirst=2);d,rr=c.get(BASE+node+'.json',params);assert list(d.values())==v;mid=next(iter(d));m=d[mid];print('EXACT MATCH DETAIL',rr['request_id'],mid,flush=True)
 for key,x in m.get('liveBlogEntries',{}).items():
  if any(t in json.dumps(x).lower() for t in ['halftime','half-time','kick-off','second half','whistle']):print('LIVE BLOG',key,json.dumps(brief(x),ensure_ascii=False)[:1500],flush=True)
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='WORKING',page_request_id=rid,api_request_id=rr['request_id'],endpoint=BASE+node+'.json',parameters=params,match_id=mid,new_requests=c.requests);(ROOT/'reports/bundesliga_match_detail_pilot.json').write_text(json.dumps(report,indent=2),encoding='utf-8');db.close()

if __name__=='__main__':main()
