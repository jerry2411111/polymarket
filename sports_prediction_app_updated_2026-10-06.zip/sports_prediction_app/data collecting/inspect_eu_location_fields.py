"""Inspect only official venue/city fields for weather bindings."""
import json,sqlite3
from build_history_catalog import DB
from eu_official_games import CONFIG
db=sqlite3.connect(DB)
for code,(_,name,__) in CONFIG.items():
 r=json.loads(db.execute('SELECT body FROM _official_'+name+'_game_reports LIMIT 1').fetchone()[0]);print('COMPETITION',code)
 for kind,s in r['sources'].items():
  data=s['data'];hits=[]
  def walk(v,path,depth=0):
   if depth>4:return
   if isinstance(v,dict):
    for k,x in v.items():
     if any(t in k.lower() for t in ['venue','stadium','city','ground']):hits.append((path+'/'+k,x))
     elif k not in ['events','lineups','players','person','player','liveBlogEntries','comments','translations']:walk(x,path+'/'+k,depth+1)
  walk(data,'')
  if hits:print(kind,json.dumps(hits,ensure_ascii=False)[:2600])
db.close()
