"""Print bounded examples of native settlement rules and unresolved date cases."""
import collections,json,sqlite3
from build_history_catalog import DB
from epl_price_points import Sources,pointer
db=sqlite3.connect(DB);src=Sources(db);seen=collections.Counter()
for code,b in db.execute('SELECT competition,body FROM _eu_market_candidates'):
 c=json.loads(b);k=code,c['provider']
 if seen[k]>=2 or c['side']==2:continue
 seen[k]+=1;raw,_=src.get(c['request_id']);m=pointer(raw,c['pointer']);print(json.dumps(dict(competition=code,provider=c['provider'],date=c['date'],contract=c['contract_id'],question=m.get('question') or m.get('yes_sub_title'),rules=m.get('description') or m.get('rules_primary')),ensure_ascii=False))
db.close()
