import json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB)
for b, in db.execute('SELECT body FROM _official_mlb_schedule'):
    g=json.loads(b)
    if g['game_type_code']=='A':
        print(g['official_date'],g['scores'],g['winner_flags'])
        for side in ['away','home']:print(json.dumps(g['raw_game']['teams'][side]['team']))
