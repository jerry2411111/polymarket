import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB,timeout=60)
for b, in db.execute('SELECT body FROM _mlb_ranking_sources'):
    x=json.loads(b)
    if x['publisher'] not in ['fox_sports','cbs_sports','bleacher_report']:continue
    r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(x['request_id'],)).fetchone()[0]);s=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
    if x['publisher']=='cbs_sports':print('CBS',str(s.select_one('table'))[:1800])
    elif x['publisher']=='fox_sports':print('FOX',s.get_text(' ',strip=True)[:800])
    elif '2026' in x['url']:
        a=s.find('article') or s
        print('BR2026',[(tag.name,tag.get_text(' ',strip=True)[:150]) for tag in a.select('p,strong,b,h2,h3,h4,h5,h6') if re.match(r'^\d+[.)]',tag.get_text(' ',strip=True))][:30])
        t=a.get_text('\n',strip=True);pos=t.find('Nick Kurtz');print(t[pos:pos+800])
db.close()
