import json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_nba_ranking_facts import source_dates
from probe_history import ROOT

db=sqlite3.connect(DB,timeout=60)
for b, in db.execute('SELECT body FROM _mlb_ranking_sources'):
    x=json.loads(b)
    if x['status']!='ACQUIRED_NOT_VALIDATED':continue
    r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(x['request_id'],)).fetchone()[0]);s=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
    try:ds=source_dates(x)[:2]
    except Exception as e:ds=str(e)
    print(json.dumps(dict(publisher=x['publisher'],url=x['url'],dates=ds,headings=[h.get_text(' ',strip=True) for h in s.select('h2,h3,h4')][:14],tables=[t.get_text(' ',strip=True)[:300] for t in s.select('table')][:2],paragraphs=[p.get_text(' ',strip=True) for p in (s.find('article') or s).find_all('p') if p.get_text(' ',strip=True)[:1].isdigit()][:6]),ensure_ascii=False))
db.close()
