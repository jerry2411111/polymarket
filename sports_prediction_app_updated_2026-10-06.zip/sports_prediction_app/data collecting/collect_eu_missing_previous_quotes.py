"""Bounded official as-of recovery for genuinely missing pregame targets."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from build_history_catalog import DB
from core import utc
from epl_price_points import Sources,load
from eu_official_games import CONFIG,games
from eu_verified_details import details
from history_client import HistoryClient
from probe_history import ROOT
from quote_selection import nearest_pregame
from schema import HOURS

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--through-percent',type=int,default=10);a=ap.parse_args();assert 0<a.through_percent<=100;db=sqlite3.connect(DB,timeout=60)
 with db:db.execute('CREATE TABLE IF NOT EXISTS _eu_polymarket_asof (job_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT')
 db.execute('BEGIN');cs={('polymarket',cid):json.loads(b) for cid,b in db.execute("SELECT contract_id,body FROM _eu_validated_contracts WHERE provider='polymarket'")};ds=details(db);gs={code:games(db,code) for code in CONFIG};src=Sources(db);points,conflicts,_=load(db,cs,src,['_eu_price_acquisition','_eu_polymarket_asof']);assert not conflicts;done={k:json.loads(b) for k,b in db.execute('SELECT * FROM _eu_polymarket_asof') if json.loads(b)['status']=='ok'};by_month=collections.defaultdict(list);before_open=0
 for key,c in cs.items():
  code=c['competition'];mid=c['official_match_id'];g=gs[code][mid];d=ds.get((code,mid))
  if not d:continue
  s=d['clock'].get('actual_start_utc') or g['scheduled_start_utc'];start=utc(s).timestamp();opened=utc(c['open']).timestamp();xs=[x for x in points[key] if x['timestamp']>=opened]
  for h in HOURS:
   target=start-h*3600;ask=math.ceil(target)-1 if h==0 else math.floor(target)
   if opened>ask:before_open+=1;continue
   if nearest_pregame(xs,target,start) is not None:continue
   by_month[g['date'][:7]].append(dict(competition=code,provider='polymarket',game_id=c['game_id'],contract_id=c['contract_id'],target='pre_'+str(h),as_of=ask,target_timestamp=target,open_timestamp=opened))
 db.commit();client=HistoryClient();parts=[];day=dt.date(2024,1,1);milestone=10
 def fetch(j):
  key=j['contract_id']+':'+str(j['as_of'])
  if key in done:return key,done[key]
  ask=j['as_of'];ids=[];x=None
  try:
   for _ in range(8):
    data,r=client.get('https://data-api.polymarket.com/v2/prices-history',dict(token_id=j['contract_id'],as_of=ask));ids.append(r['request_id']);assert len(data['data'])<=1 and not data.get('pagination',{}).get('next_cursor');x=data['data'][0] if data['data'] else None
    if x is None:break
    assert x['timestamp']<=ask and 0<=x['price']<=1
    if x['resolution_seconds']>0 and x['timestamp']+x['resolution_seconds']<=j['target_timestamp']:break
    ask=x['timestamp']-1
   valid=bool(x and x['resolution_seconds']>0 and x['timestamp']+x['resolution_seconds']<=j['target_timestamp'] and x['timestamp']>=j['open_timestamp']);return key,dict(**j,status='ok',request_ids=ids,point=x,usable=valid)
  except Exception as e:return key,dict(**j,status='error',request_ids=ids,error=type(e).__name__+': '+str(e))
 while day<=dt.date(2026,9,14) and len(parts)<math.ceil(33*a.through_percent/100):
  month=day.strftime('%Y-%m');counts=collections.Counter();errors=[]
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
   for key,row in pool.map(fetch,by_month[month]):
    if key not in done:
     with db:db.execute('INSERT OR REPLACE INTO _eu_polymarket_asof VALUES (?,?)',(key,json.dumps(row)))
    counts[row['status']]+=1;counts['usable']+=bool(row.get('usable'))
    if row['status']=='error':errors.append(row)
  parts.append(dict(month=month,missing_targets=len(by_month[month]),results=dict(counts),errors=errors));out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Five EU competitions missing previous-price recovery',processed_months=len(parts),total_months=33,before_contract_creation=before_open,new_requests=client.requests,months=parts);(ROOT/'reports/eu_missing_previous_quotes.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
  if counts:print('EU PREVIOUS QUOTES',month,dict(counts),'months',len(parts),'/33',flush=True)
  while milestone<=100 and len(parts)>=math.ceil(33*milestone/100):print('EU PREVIOUS QUOTES DATE PHASE',milestone,'PERCENT',flush=True);milestone+=10
  if errors:break
  day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
 print('EU PREVIOUS QUOTE REQUESTS',client.requests,flush=True);db.close()

if __name__=='__main__':main()
