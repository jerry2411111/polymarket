"""Bind official game-city strings to explicitly named UK weather stations."""
import argparse,collections,datetime as dt,io,json,sqlite3
import pyarrow.parquet as pq
from build_history_catalog import DB
from collect_history_weather import DOC
from epl_price_points import Sources,pointer
from history_client import HistoryClient
from probe_history import ROOT

# IDs and names were read from the current official NOAA station directory.
# Neighboring stations are explicit regional proxies, not stadium observations
# or a claim to be the geographically nearest available station.
CANDIDATES={
 'Birmingham':['UKA00035311','UKU81-00123','UKM00003535'],
 'Bournemouth':['UKI0000EGHH'], 'Brentford':['UKI0000EGLL'],
 'Burnley':['UKU67-00078','UKI0000EGNH'], 'Coventry':['UKI0000EGBE','UKM00003544'],
 'Falmer':['UKI0000EGKA','UKA00038793'], 'Hull':['UKI0000EGNJ','UKI0000EGXV'],
 'Ipswich':['UKM00003591','UKI0000EGVG'], 'Leeds':['UKI0000EGNM','UKA00033470'],
 'Leicester':['UKM00003544'], 'Liverpool':['UKI0000EGGP'],
 'London':['UKI0000EGLL'], 'Manchester':['UKI0000EGCC','UKI0000EGCB'],
 'Newcastle':['UKM00003245','UKM00003246','UKM00003238'], 'Nottingham':['UKM00003354','UKU81-00062'],
 'Southampton':['UKI0000EGHI'], 'Sunderland':['UKM00003245','UKM00003246','UKM00003238'],
 'Wolverhampton':['UKM00003535']}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');a=ap.parse_args();db=sqlite3.connect(DB,timeout=60);src=Sources(db);client=HistoryClient();raw,dr=client.get(DOC+'ghcnh-station-list.txt',document=True);stations={line[:11]:line for line in raw.decode().splitlines()};targets=collections.defaultdict(list);locations=[]
 for gid,b in db.execute("SELECT * FROM _eu_game_facts WHERE json_extract(body,'$.competition')='Premier League'"):
  g=json.loads(b);cal=json.loads(db.execute('SELECT body FROM _official_epl_calendar WHERE match_id=?',(g['official_match_id'],)).fetchone()[0]);r,_=src.get(cal['request_id']);ground=pointer(r,cal['pointer']+'/ground');assert ground==g['location'] and ', ' in ground;city=ground.rsplit(', ',1)[1];assert city in CANDIDATES,'Unreviewed official city';weather_city='Birmingham, England' if city=='Birmingham' else city;body=dict(game_id=gid,raw_city=city,city=weather_city,country='United Kingdom',request_id=cal['request_id'],pointer=cal['pointer']+'/ground',raw_location=ground,city_derivation='Final comma-separated city in official ground string; Birmingham qualified to distinguish the Alabama city');locations.append((gid,json.dumps(body)));targets[weather_city,g['date'][:4]].append(body)
 with db:db.execute('CREATE TABLE IF NOT EXISTS _eu_game_weather_locations (game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _eu_game_weather_locations VALUES (?,?)',locations)
 wanted=sorted(targets)
 if a.pilot:wanted=[k for k in wanted if k in [('London','2024'),('Birmingham, England','2024'),('Manchester','2024')]]
 rows=[];issues=[];checked_rows=[]
 for city,year in wanted:
  evidence=targets[city,year];raw_city=evidence[0]['raw_city'];checked=[];hit=None
  for sid in CANDIDATES[raw_city]:
   assert sid in stations,'Unknown official station ID';line=stations[sid];assert line.rstrip().endswith('GB');lat,lon=map(float,line[11:].split()[:2]);assert 49<=lat<=56 and -5<=lon<=2,'Station is outside the reviewed English region'
   url=f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/parquet/GHCNh_{sid}_{year}.parquet'
   try:
    b,r=client.get(url,document=True);pf=pq.ParquetFile(io.BytesIO(b));cols=pf.schema_arrow.names;usable=pf.metadata.num_rows>=100 and all(k in cols for k in ['STATION','DATE','temperature']);item=dict(station=sid,station_directory_row=line,request_id=r['request_id'],rows=pf.metadata.num_rows,usable=usable);checked.append(item)
    if usable:hit=item;break
   except Exception as e:checked.append(dict(station=sid,url=url,error=str(e)))
  if hit:
   body=dict(city=city,year=year,station=hit['station'],official_city_evidence=evidence,station_directory_request_id=dr['request_id'],archive_request_id=hit['request_id'],station_directory_row=hit['station_directory_row'],alternatives=checked,method='Explicit reviewed English city/region to NOAA station; regional outdoor conditions, not stadium measurement or verified nearest station');rows.append((city,year,hit['station'],json.dumps(body)))
  else:issues.append(dict(city=city,year=year,reason='No usable archive among reviewed official stations',checked=checked))
  checked_rows.append(dict(city=city,year=year,checked=checked));print('EPL WEATHER STATION',city,year,hit['station'] if hit else 'unavailable',flush=True)
 with db:db.executemany('INSERT OR REPLACE INTO _weather_city_stations VALUES (?,?,?,?)',rows)
 report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),scope='Three-city archive pilot' if a.pilot else 'All published EPL game-city/year targets',city_years=len(wanted),mapped=len(rows),issues=issues,checked=checked_rows,official_location_hash_checks=len(src.cache),new_requests=client.requests);(ROOT/'reports'/('epl_weather_station_pilot.json' if a.pilot else 'epl_weather_station_mapping.json')).write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['checked','issues']}));db.close()

if __name__=='__main__':main()
