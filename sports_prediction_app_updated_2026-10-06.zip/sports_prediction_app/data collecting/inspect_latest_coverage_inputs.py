﻿import json
from probe_history import ROOT
for name in ['nba_main_validation','nba_full_team_names_validation','nba_dated_profiles','nba_weather_validation','nba_player_contract_install','nba_contract_candidate_validation']:
 x=json.loads((ROOT/'reports'/ (name+'.json')).read_text());print(name,{k:v for k,v in x.items() if not isinstance(v,(dict,list))});print('collections',{k:len(v) for k,v in x.items() if isinstance(v,(dict,list))})
