import collections,json,sqlite3
from build_history_catalog import DB
db=sqlite3.connect(DB);items=[json.loads(b) for (b,) in db.execute('SELECT body FROM _weather_observation_audit')];missing=[x for x in items if x.get('raw') and x['normalized']['weather_type'] is None]
print('Missing weather with source rows',len(missing))
for x in missing[:12]:print(json.dumps({k:x[k] for k in ['city','date','request_id','row_index']}|{'sky_values':{k:v for k,v in x['raw'].items() if ('sky_' in k or 'pres_wx_' in k) and v is not None}}))
print('Missing type cities',dict(collections.Counter(x['city'] for x in missing)))
