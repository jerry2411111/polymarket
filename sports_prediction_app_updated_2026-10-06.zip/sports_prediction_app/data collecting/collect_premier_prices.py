"""Acquire three independent outcome price histories using verified official game clocks."""
import argparse,calendar,collections,concurrent.futures,datetime as dt,json,math,sqlite3
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT
from collect_premier_game_reports import PILOT
from build_premier_market_candidates import utc
K='https://external-api.kalshi.com/trade-api/v2'

def main():
    p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');p.add_argument('--through-percent',type=int,default=10);p.add_argument('--mode',choices=['pre','break'],default='pre');a=p.parse_args();assert 0<a.through_percent<=100
    db=sqlite3.connect(DB,timeout=60);client=HistoryClient();cutoff,cr=client.get(K+'/historical/cutoff',refresh=True);cut=utc(cutoff['market_settled_ts']);reports={mid:json.loads(b) for mid,b in db.execute('SELECT * FROM _official_epl_game_reports')};games={mid:json.loads(b) for mid,b in db.execute('SELECT * FROM _official_epl_calendar')};by_month=collections.defaultdict(list)
    for b, in db.execute('SELECT body FROM _epl_market_candidates'):
        m=json.loads(b)
        if m.get('draw_half_payout_rule'):continue
        if not a.pilot or m['official_match_id'] in PILOT:by_month[games[m['official_match_id']]['date'][:7]].append(m)
    db.execute('CREATE TABLE IF NOT EXISTS _epl_price_acquisition (job_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit()
    done={key:json.loads(b) for key,b in db.execute('SELECT * FROM _epl_price_acquisition') if json.loads(b)['status']=='ok'}
    def fetch(job):
        m,n,lo,hi=job;cid=m['contract_id'];key=f'{a.mode}:{m["provider"]}:{cid}:{n}:{lo}:{hi}';rids=[]
        if key in done:return key,done[key]
        row=dict(provider=m['provider'],contract_id=cid,game_id=m['game_id'],official_match_id=m['official_match_id'],mode=a.mode,checkpoint=n,start_ts=lo,end_ts=hi,request_ids=rids)
        try:
            if m['provider']=='kalshi':
                archive=utc(m['settled'])<cut;path='/historical/markets/'+cid+'/candlesticks' if archive else '/series/'+m['series']+'/markets/'+cid+'/candlesticks';interval=60 if a.mode=='pre' else 1
                data,r=client.get(K+path,dict(start_ts=lo,end_ts=hi,period_interval=interval));rids.append(r['request_id']);assert data['ticker']==cid;rows=data['candlesticks'];price_key='close' if archive else 'close_dollars'
                for v in rows:
                    bid=v.get('yes_bid',{}).get(price_key);ask=v.get('yes_ask',{}).get(price_key);assert bid is None or 0<=float(bid)<=1;assert bid is None or ask is None or float(bid)<=float(ask)
                row.update(rows=len(rows),resolutions=[interval*60],route='historical' if archive else 'recent',price_key=price_key,cutoff_request_id=cr['request_id'])
            else:
                params=dict(token_id=cid,start=lo,end=hi,bucket_seconds=3600 if a.mode=='pre' else 60,limit=10000);total=0;res=set();cursors=set()
                for page in range(20):
                    data,r=client.get('https://data-api.polymarket.com/v2/prices-history',params);rids.append(r['request_id']);rows=data['data']
                    if page==0 and not rows and a.mode=='pre':
                        params.pop('bucket_seconds');data,r=client.get('https://data-api.polymarket.com/v2/prices-history',params);rids.append(r['request_id']);rows=data['data']
                    for v in rows:assert 0<=v['price']<=1 and isinstance(v['timestamp'],int);res.add(v['resolution_seconds'])
                    total+=len(rows);cursor=data.get('pagination',{}).get('next_cursor')
                    if not cursor:assert not data.get('pagination',{}).get('has_more');break
                    assert cursor not in cursors;cursors.add(cursor);params['cursor']=cursor
                else:raise ValueError('Unexhausted historical price pagination')
                row.update(rows=total,resolutions=sorted(res))
            row['status']='ok'
        except Exception as e:row.update(status='error',error=type(e).__name__+': '+str(e))
        return key,row
    day=dt.date(2024,1,1);parts=[]
    while day<=dt.date(2026,9,14) and (a.pilot or len(parts)<math.ceil(33*a.through_percent/100)):
        month=day.strftime('%Y-%m');jobs=[];missing=[];before_requests=client.requests
        for m in by_month[month]:
            report=reports.get(m['official_match_id'],{}).get('derived',{});s=report.get('actual_start_utc')
            if not s:missing.append(m['contract_id']);continue
            start=int(utc(s).timestamp())
            if a.mode=='pre':jobs.append((m,'pre',start-84*3600,start))
            else:
                # One opening quote, the first available quote inside half-time,
                # and one second-half opening quote. No dense full-game request.
                hs=report.get('halftime_start_utc');rs=report.get('second_half_start_utc');windows=[(0,start,start+120)]
                if hs and rs:windows.extend([(1,int(utc(hs).timestamp()),int(utc(rs).timestamp())),(2,int(utc(rs).timestamp()),int(utc(rs).timestamp())+120)])
                for n,lo,hi in windows:jobs.append((m,n,lo-60,hi))
        counts=collections.Counter();errors=[];rows=0
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            for key,result in pool.map(fetch,jobs):
                if key not in done:
                    with db:db.execute('INSERT OR REPLACE INTO _epl_price_acquisition VALUES (?,?)',(key,json.dumps(result)))
                counts[result['status']]+=1;rows+=result.get('rows',0)
                if result['status']=='error':errors.append(result)
                elif not result['rows']:counts['empty']+=1
        part=dict(month=month,jobs=len(jobs),rows=rows,counts=dict(counts),errors=errors,missing_verified_official_clock=len(missing));parts.append(part)
        out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='EPL '+a.mode+' price acquisition',pilot=a.pilot,total_months=33,processed_months=len(parts),completed_months=sum(not p['errors'] and not p['missing_verified_official_clock'] for p in parts),cutoff=cutoff,cutoff_request_id=cr['request_id'],new_requests=client.requests,months=parts)
        (ROOT/'reports'/('epl_'+a.mode+'_prices_'+('pilot' if a.pilot else 'months')+'.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
        if client.requests>before_requests or errors or missing:print('EPL PRICE MONTH',a.mode,month,'jobs',len(jobs),'rows',rows,'counts',dict(counts),'missing clock',len(missing),'months',len(parts),'/33',flush=True)
        if errors or missing:break
        day=day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1)
    print('EPL PRICE REQUESTS',client.requests,flush=True);db.close()

if __name__=='__main__':main()
