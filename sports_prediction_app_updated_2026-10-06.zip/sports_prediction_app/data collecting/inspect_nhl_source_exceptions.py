import json,sqlite3
from history_index import records
from build_history_catalog import DB
from probe_history import ROOT
from bs4 import BeautifulSoup
from official_html import decode_html
db=sqlite3.connect(DB);rs={r['request_id']:r for r in records()}
for n,b in db.execute('SELECT * FROM _official_nhl_career_sources'):
 r=json.loads(b)
 if r['status']=='ok':continue
 sources=[x for x in rs.values() if x['endpoint']=='https://api-web.nhle.com/v2/player/'+n+'/player-stats' and x.get('status')==200];print('CAREER ISSUE',n,r)
 if sources:
  d=json.loads((ROOT/sources[-1]['raw_file']).read_bytes());print('CAREER SCHEMA',list(d),'BAD SEASONS',[x for x in (d.get('seasonTotals') or []) if not isinstance(x.get('season'),int) or x.get('gamesPlayed') is None])
for n,b in db.execute('SELECT * FROM _official_nhl_game_reports'):
 f=json.loads(b)
 if f['issues']:
  print('GAME ISSUE',n,f['date'],f['teams'],f['issues']);r=rs[f['request_ids']['GS']];s=BeautifulSoup(decode_html((ROOT/r['raw_file']).read_bytes()),'html.parser');headers=[]
  for t in s.find_all('table'):
   rows=t.find_all('tr',recursive=False)
   if rows:
    cells=[x.get_text(' ',strip=True) for x in rows[0].find_all(['td','th'],recursive=False)]
    if 'Goals' in cells or 'Per' in cells:headers.append(cells)
  print('GS HEADERS',headers)
 if n=='2024021099':
  r=rs[f['request_ids']['PL']];s=BeautifulSoup(decode_html((ROOT/r['raw_file']).read_bytes()),'html.parser');rows=s.find_all('tr');print('DUPLICATE ROWS',[[x.get_text(' ',strip=True) for x in rows[i].find_all('td',recursive=False)][:6] for i in [5359,5360]])
db.close()
