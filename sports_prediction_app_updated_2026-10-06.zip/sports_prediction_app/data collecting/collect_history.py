"""Acquire bounded hourly game windows and one PBP response per real game.

The complete response is retained. No trade-download endpoint is called.
Progress/error records are append-only, and successful requests use hash-verified
cache entries when resumed. Price windows are 84 hours, not full token lifetimes.
"""
import argparse,collections,concurrent.futures,datetime as dt,json,sqlite3,time
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT
from core import utc
K='https://external-api.kalshi.com/trade-api/v2'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--kind',choices=['prices','pbp','all'],default='all');ap.add_argument('--league',choices=['NBA','MLB','NHL']);ap.add_argument('--recovered-only',action='store_true');ap.add_argument('--limit',type=int);ap.add_argument('--from-date',default='2023-09-13');ap.add_argument('--through-date',default='2026-09-13');args=ap.parse_args()
 c=HistoryClient();db=sqlite3.connect(DB)
 games={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _history_games')};contracts=[json.loads(r[0]) for r in db.execute('SELECT body FROM _history_contracts')];db.close()
 games={gid:g for gid,g in games.items() if args.from_date<=g['date']<=args.through_date and (not args.league or g['league']==args.league)};contracts=[m for m in contracts if m['game_id'] in games]
 if args.recovered_only:contracts=[m for m in contracts if m.get('recovered_using_official_game_id')]
 cutoff,r=c.get(K+'/historical/cutoff',refresh=True);cut=utc(cutoff['market_settled_ts'])
 jobs=[]
 if args.kind in ['all','pbp']:
  jobs.extend(dict(kind='pbp',game_id=g['game_id'],milestone_id=g['milestone_id']) for g in sorted(games.values(),key=lambda g:g['date']) if g.get('milestone_id'))
 if args.kind in ['all','prices']:
  jobs.extend(dict(kind='price',contract=m,game_id=m['game_id']) for m in sorted(contracts,key=lambda m:(games[m['game_id']]['date'],m['provider'],m['contract_id'])))
 if args.limit:jobs=jobs[:args.limit]
 report=ROOT/'reports/history_acquisition_jobs.jsonl';started=time.monotonic();counts=collections.Counter()
 def task(job):
  try:
   g=games[job['game_id']]
   if job['kind']=='pbp':
    d,r=c.get(K+'/live_data/milestone/'+job['milestone_id']+'/game_stats');periods=(d.get('pbp') or {}).get('periods') or []
    events=[e for p in periods for e in (p.get('events') or [])]
    return dict(**job,status='ok',request_id=r['request_id'],periods=len(periods),events=len(events),wall_clock=sum(e.get('wall_clock') is not None for e in events))
   m=job['contract'];anchor=utc(g['start']);start=int((anchor-dt.timedelta(hours=84)).timestamp());end=int((anchor+dt.timedelta(hours=6)).timestamp())
   if m['provider']=='kalshi':
    archive=utc(m['settled'])<cut
    path='/historical/markets/'+m['contract_id']+'/candlesticks' if archive else '/series/'+m['series']+'/markets/'+m['contract_id']+'/candlesticks'
    d,r=c.get(K+path,dict(start_ts=start,end_ts=end,period_interval=60))
    if d.get('ticker')!=m['contract_id']:raise ValueError('Wrong returned ticker')
    return dict(kind='price',provider='kalshi',game_id=g['game_id'],contract_id=m['contract_id'],status='ok',request_id=r['request_id'],rows=len(d['candlesticks']),route='historical' if archive else 'recent')
   # Official permanent old-history series is 3-hour resolution. Recent data use
   # hourly buckets. Expired requested buckets return empty; one adaptive fallback.
   bucket=10800 if anchor<dt.datetime(2026,6,15,tzinfo=dt.UTC) else 3600
   params=dict(token_id=m['contract_id'],start=start,end=end,bucket_seconds=bucket,limit=10000);total=0;seen=set();ids=[];res=set()
   for page in range(10):
    d,r=c.get('https://data-api.polymarket.com/v2/prices-history',params);ids.append(r['request_id']);items=d.get('data',[])
    if not items and page==0:
     params.pop('bucket_seconds',None);d,r=c.get('https://data-api.polymarket.com/v2/prices-history',params);ids.append(r['request_id']);items=d.get('data',[])
    total+=len(items);res.update(x.get('resolution_seconds') for x in items)
    pagination=d.get('pagination') or {};cursor=pagination.get('next_cursor')
    if not cursor:
     if pagination.get('has_more'):raise ValueError('Missing continuation cursor')
     break
    if cursor in seen:raise ValueError('Repeated history cursor')
    seen.add(cursor);params['cursor']=cursor
   else:raise ValueError('History page safety bound exceeded')
   return dict(kind='price',provider='polymarket',game_id=g['game_id'],contract_id=m['contract_id'],status='ok',request_ids=ids,rows=total,resolutions=sorted(res,key=str))
  except Exception as e:return dict(kind=job['kind'],game_id=job['game_id'],contract_id=job.get('contract',{}).get('contract_id'),status='error',error=str(e))
 with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool,report.open('a',encoding='utf-8') as f:
  futures={pool.submit(task,j):j for j in jobs}
  for n,future in enumerate(concurrent.futures.as_completed(futures),1):
   result=future.result();f.write(json.dumps(result)+'\n');f.flush();counts[result['status']]+=1
   if n%100==0 or n==len(jobs):print(json.dumps(dict(completed=n,total=len(jobs),requests=c.requests,counts=counts,elapsed_seconds=round(time.monotonic()-started))),flush=True)
 print('DONE',dict(counts),flush=True)

if __name__=='__main__':main()
