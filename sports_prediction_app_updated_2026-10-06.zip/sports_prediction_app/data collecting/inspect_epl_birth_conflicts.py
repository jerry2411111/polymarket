"""Bounded display of conflicting official biographical dates for manual source review."""
import collections,json,sqlite3
from build_history_catalog import DB
from normalize_epl_people import valid_date

def main():
 db=sqlite3.connect(DB);out=[]
 for key,b in db.execute('SELECT * FROM _official_epl_people_sources'):
  r=json.loads(b)
  if r['kind']!='player' or 'biography' not in r['sources']:continue
  vals=r['sources']['biography']['raw'];valid=[v for v in vals if int(v['id']['seasonId'])<=2026 and valid_date(v.get('dates',{}).get('birth'))];birth={v['dates']['birth'] for v in valid}
  if len(birth)<2:continue
  latest=sorted(valid,key=lambda v:(-int(v['id']['seasonId']),str(v['id']['competitionId'])!='8'))
  grouped=collections.defaultdict(list)
  for v in latest:grouped[v['dates']['birth']].append(str(v['id']['seasonId'])+':'+str(v['id']['competitionId']))
  career=r['sources'].get('career',{}).get('raw',{});persons=career.get('person',[])
  out.append(dict(key=key,name=latest[0]['name']['display'],dates={k:vs[:8] for k,vs in grouped.items()},career_date=persons[0].get('dateOfBirth') if persons else None,biography_request_id=r['sources']['biography']['request_id']))
 print(json.dumps(out,ensure_ascii=False));db.close()

if __name__=='__main__':main()
