"""Source-native per-game facts; no career totals or inferred missing statistics."""
import collections,re
from core import utc
from collect_laliga_people import namekey

SIDES=['away','home']
PHASES=['FIRST_HALF','SECOND_HALF','FirstHalf','SecondHalf']

def person_name(p):
 return p.get('internationalName') or p.get('translations',{}).get('name',{}).get('EN') or p.get('name')

def photo_id(p,manager=False):
 prefix='man' if manager else 'p';ids=set(re.findall(r'/('+prefix+r'\d+)/',str(p.get('photos',{}))))
 return next(iter(ids)) if len(ids)==1 else None

def lineups(code,g,r):
 rows=[];coaches=[];issues=[];s=r['sources']
 for side,side_name in enumerate(SIDES):
  if code=='BUN':
   line=s['lineups']['data'][side_name];groups=[(True,line['startingEleven']['persons']),(False,line['bench']['persons'])];ms=[p for p in line['coaches']['persons'] if p['role']=='HEADCOACH'];rid=s['lineups']['request_id']
  elif code=='LAL':
   line=s['match_page']['data']['data']['lineups'][side_name];groups=[(True,line['starts']),(False,line['subs'])];ms=line['manager'];rid=s['match_page']['request_id']
  elif code=='FL1':
   line=s['match']['data'][side_name];groups=[(None,list(line['players'].values()))];ms=[line['manager']] if line.get('manager') else [];rid=s['match']['request_id']
  elif code=='SEA':
   line=s['lineups']['data'][side_name];groups=[(True,line['fielded']),(False,line['benched'])];ms=[p for p in line['staff'] if p['role']==101];rid=s['lineups']['request_id']
  else:
   line=s['lineups']['data'][side_name+'Team'];groups=[(True,line['field']),(False,line['bench'])];ms=[p for p in line['coaches'] if p['role']=='COACH'];rid=s['lineups']['request_ids'][0]
  for starter,ps in groups:
   for p in ps:
    bio={};aliases=[];stable=True;external={}
    if code=='BUN':native=p['dflDatalibraryObjectId'];name=p['name']
    elif code=='LAL':
     native=photo_id(p);stable=native is not None;native=native or 'lineup:'+g['game_id']+':'+str(p['id']);name=p['person']['name'];aliases=[p['person'].get('nickname')];external['transient_lineup_id']=p['id']
    elif code=='FL1':
     q=p['playerIdentity'];native=str(q.get('shortOptaId') or q['id']);stable=q.get('shortOptaId') is not None;name=' '.join(filter(None,[q.get('firstName'),q.get('lastName')]));starter=p.get('startedMatch');bio=dict(birth_date=q.get('birthDate'));external=dict(shortOptaId=q.get('shortOptaId'),dated_player_id=q['id'])
    elif code=='SEA':native=p['playerId'];name=' '.join(filter(None,[p.get('mediaFirstName'),p.get('mediaLastName')]));aliases=[p.get('shortName')];external['provider_id']=p.get('providerId')
    else:
     q=p['player'];native=q['id'];name=person_name(q);bio=dict(birth_date=q.get('birthDate'),height_cm=q.get('height'),weight_kg=q.get('weight'));aliases=[q.get('translations',{}).get('name',{}).get('EN')]
    assert name and native;rows.append(dict(player_id='EU_'+code+':'+native,official_player_id=native,player_name=name,aliases=[a for a in aliases if a],source_identity_stable=stable,external_ids=external,side=side,starter=starter,raw_player=p,biography=bio,roster_request_id=rid))
  if len(ms)!=1:issues.append(dict(field='manager',side=side,reason='Official report does not identify exactly one head coach',count=len(ms)))
  else:
   p=ms[0]
   if code=='BUN':native=p['dflDatalibraryObjectId'];name=p['name']
   elif code=='LAL':native=photo_id(p,True) or 'lineup:'+g['game_id']+':'+str(p['id']);name=p['person']['name']
   elif code=='FL1':native=str(p['id']);name=' '.join(filter(None,[p.get('firstName'),p.get('lastName')]))
   elif code=='SEA':native=p['staffId'];name=' '.join(filter(None,[p.get('mediaFirstName'),p.get('mediaLastName')]))
   else:native=p['person']['id'];name=person_name(p['person'])
   coaches.append(dict(manager_id='EU_'+code+'_COACH:'+native,official_manager_id=native,manager_name=name,side=side,request_id=rid,raw=p))
 assert len(rows)==len({p['official_player_id'] for p in rows})
 for side in [0,1]:
  n=sum(p['starter'] is True for p in rows if p['side']==side)
  if n!=11:issues.append(dict(field='starter',side=side,reason='Starting lineup count differs from eleven',count=n))
 return rows,coaches,issues

def derive(code,g,r,d,corrections=None):
 rows,coaches,issues=lineups(code,g,r);byid={p['official_player_id']:p for p in rows};starters={p['official_player_id'] for p in rows if p['starter']};played=set(starters);goals=collections.Counter();assists=collections.Counter();timeline=[];injuries=set();goal_proofs=[];assist_proofs=[];team_goals=[0,0];goals_ok=True;assists_ok=True;s=r['sources'];event_rids=[];own=collections.Counter()
 def act(pid):
  assert pid in byid,'Event participant is absent from the official player roster';return byid[pid]
 def sub(off,on,when,proof):
  act(off);act(on);assert byid[off]['side']==byid[on]['side'];played.add(on);timeline.append(dict(kind='sub',off=off,on=on,timestamp=when,proof=proof))
 def red(pid,when,proof):
  if pid in byid:timeline.append(dict(kind='red',off=pid,on=None,timestamp=when,proof=proof))
 def goal(pid,side,is_own,proof):
  act(pid);assert byid[pid]['side']==side;team_goals[1-side if is_own else side]+=1;goal_proofs.append(dict(player_id=pid,credited_side=1-side if is_own else side,own_goal=is_own,source=proof))
  if not is_own:goals[pid]+=1
  else:own[pid]+=1
 if code=='FL1':
  for p in rows:
   raw=p['raw_player'];p.update(did_play=raw.get('playedMatch'),score=raw.get('goals') if raw.get('playedMatch') else None,assists=raw.get('goalsAssists') if raw.get('playedMatch') else None,minutes=raw.get('minutesPlayed') if raw.get('playedMatch') else None,minutes_basis='Official per-match minutesPlayed statistic, rounded source convention',injury_reported=False,injured_departure=False)
   assert type(p['did_play']) is bool and type(p['starter']) is bool
   for key in ['score','assists','minutes']:
    if p[key] is not None:assert isinstance(p[key],(int,float)) and p[key]>=0
  return rows,coaches,issues,dict(mode='Direct official per-player match fields',request_ids=[s['match']['request_id']])
 try:
  if code=='BUN':
   event_rids=[s['match']['request_id']]
   for key,e in s['match']['data']['liveBlogEntries'].items():
    t=e['entryType'];v=e.get('detail',{});proof=dict(request_id=event_rids[0],pointer=s['match']['pointer']+'/liveBlogEntries/'+key);when=e.get('entryDate')
    if t in ['goal','ownGoal']:
     pid=v['scorer']['dflDatalibraryObjectId'];goal(pid,SIDES.index(e['side']),t=='ownGoal',proof)
     if t!='ownGoal':
      if 'assist' not in v:assists_ok=False
      elif v['assist']:aid=v['assist']['dflDatalibraryObjectId'];act(aid);assists[aid]+=1;assist_proofs.append(dict(player_id=aid,source=proof))
    elif t=='sub':sub(v['out']['dflDatalibraryObjectId'],v['in']['dflDatalibraryObjectId'],when,proof)
    elif t in ['redCard','yellowRedCard']:red(v['person']['dflDatalibraryObjectId'],when,proof)
  elif code=='LAL':
   page=s['match_page']['data'];event_rids=[s['match_page']['request_id']];names=collections.defaultdict(set)
   for p in rows:names[p['side'],namekey(p['player_name'])].add(p['official_player_id'])
   def lookup(v):
    side=next(i for i,x in enumerate(SIDES) if str(page['match'][x+'_team']['id'])==str(v['team']['id']));ids=names[side,namekey(v['person']['name'])];assert len(ids)==1,'Event name does not uniquely match the dated team lineup';return next(iter(ids)),side
   for i,e in enumerate(page['events']):
    t=e['match_event_kind']['collection'];kind=e['match_event_kind']['name'];proof=dict(request_id=event_rids[0],pointer='/props/pageProps/events/'+str(i));when=e.get('date_source')
    if t=='goal':
     pid,side=lookup(e['lineup']);goal(pid,side,kind=='Own',proof)
     if kind!='Own':
      if 'assist' not in e:assists_ok=False
      elif e['assist']:aid,asi=lookup(e['assist']);assert asi==side;assists[aid]+=1;assist_proofs.append(dict(player_id=aid,source=proof))
    elif t=='substitution':
     on,_=lookup(e['lineup']);off,_=lookup(e['lineup_off']);sub(off,on,when,proof)
     if kind=='Injury':injuries.add(off)
    elif t=='booking' and kind in ['Second Yellow','Straight Red']:
     try:pid,_=lookup(e['lineup'])
     except AssertionError:continue # A coach/bench-staff card is not a player substitution.
     red(pid,when,proof)
  elif code=='UCL':
   m=s['match']['data'];event_rids=s['events']['request_ids'];events=s['events']['data'];ids=[g[x]['id'] for x in SIDES]
   for i,e in enumerate(m.get('playerEvents',{}).get('scorers',[])):
    if e['phase'] not in PHASES:continue
    goal(e['player']['id'],ids.index(e['teamId']),e['goalType']=='OWN',dict(request_id=s['match']['request_ids'][0],pointer='/playerEvents/scorers/'+str(i)))
   for i,e in enumerate(events):
    if e.get('phase') not in PHASES:continue
    t=e['type'];proof=dict(event_id=e['id'],combined_event_index=i,request_ids=event_rids);when=e.get('timestamp')
    if t=='SUBSTITUTION':sub(e['primaryActor']['person']['id'],e['secondaryActor']['person']['id'],when,proof)
    elif t in ['RED_CARD','RED_YELLOW_CARD']:
     actor=e['primaryActor']['person']
     if 'id' not in actor:
      # UEFA wraps disciplined coaches/staff in a second person object.
      # They are not players and cannot reduce anyone's playing minutes.
      assert actor.get('person',{}).get('id') and e['primaryActor'].get('type')=='COACH' and actor['person']['id'] not in byid,'Nested disciplinary actor is not explicitly a non-player coach/staff member'
      continue
     red(actor['id'],when,proof)
    elif t=='ASSIST':pid=e['primaryActor']['person']['id'];act(pid);assists[pid]+=1;assist_proofs.append(dict(player_id=pid,source=proof))
  else:
   event_rids=[s['feed']['request_id']];events=s['feed']['data']['events'];recon=r['derived']['goal_reconciliation'];goals_ok=bool(recon) and r['derived']['final_score_verified'];flip=recon.get('own_goal_side_inverted',False) if recon else False
   for i,e in enumerate(events):
    vals=[(side,e.get(n)) for side,n in enumerate(SIDES) if e.get(n)];t=e['type']
    if len(vals)!=1:continue
    side,v=vals[0]
    if v.get('phase') not in PHASES:continue
    p=v.get('player') or {};pid=p.get('playerId');proof=dict(request_id=event_rids[0],pointer='/events/'+str(i));when=e.get('timeStamp')
    if t in ['goal','penalty-goal','own-goal']:
     # The roster identifies the own-goal offender even where the source event
     # is nested under the beneficiary team. Keep both source conventions.
     act(pid);actual_side=byid[pid]['side'];assert actual_side==(side if t!='own-goal' or flip else 1-side);goal(pid,actual_side,t=='own-goal',proof)
     if t!='own-goal':
      if 'assistPlayerId' not in p:assists_ok=False
      elif p['assistPlayerId']:aid=p['assistPlayerId'];act(aid);assists[aid]+=1;assist_proofs.append(dict(player_id=aid,source=proof))
    elif t=='substitution':
     correction=(corrections or {}).get(e['eventId'])
     if correction:
      assert correction['old_player_id']==pid and correction['player_off_id']==p['relatedPlayerId'];pid=correction['new_player_id'];when=None;proof=dict(proof,correction=correction)
     sub(p['relatedPlayerId'],pid,when,proof)
    elif t in ['red-card','yellow-red-card','second-yellow-card']:red(pid,when,proof)
    elif t=='injury-event' and pid in byid:injuries.add(pid)
 except (KeyError,AssertionError,ValueError,TypeError) as e:
  issues.append(dict(field='event_derivation',reason=type(e).__name__+': '+str(e)));goals_ok=assists_ok=False;played=None
 if team_goals!=g['scores']:issues.append(dict(field='goals',reason='Goal event count does not reconcile with official regulation score',counted=team_goals,official=g['scores']));goals_ok=False
 if played is not None and (set(goals)|set(assists))-played:issues.append(dict(field='events',reason='A credited player is not in the reconstructed appearances'));goals_ok=assists_ok=False
 minutes={};minute_error=None;clock=d['clock'];times=[utc(clock.get(k)) for k in ['actual_start_utc','halftime_start_utc','second_half_start_utc','regulation_end_utc']]
 if all(times) and played is not None and len(starters)==22:
  start,hs,rs,end=[v.timestamp() for v in times];elapsed=lambda lo,hi:((hi-lo)-max(0,min(hi,rs)-max(lo,hs)))/60;active={p:start for p in starters};total=collections.defaultdict(float)
  try:
   assert start<hs<rs<end
   for v in sorted(timeline,key=lambda v:(utc(v['timestamp']).timestamp() if v['timestamp'] else -1,v['kind'])):
    assert v['timestamp'],'Missing substitution/card timestamp';when=utc(v['timestamp']).timestamp();off,on=v['off'],v['on']
    if v['kind']=='red' and (off not in active or when>end):continue
    assert start<=when<=end,'Event timestamp outside the verified game clock'
    assert off in active and on not in active,'Substitution/card contradicts the starting lineup or prior substitution'
    total[off]+=elapsed(active.pop(off),when)
    if on is not None:active[on]=when
   for pid,lo in active.items():total[pid]+=elapsed(lo,end)
   assert set(total)==played and all(0<=n<=elapsed(start,end)+1e-7 for n in total.values());minutes=dict(total)
  except (AssertionError,ValueError,TypeError) as e:minute_error=str(e);issues.append(dict(field='minutes',reason=minute_error))
 else:minute_error='Missing verified phase clock or complete appearance/starting-lineup evidence'
 for p in rows:
  pid=p['official_player_id'];did=pid in played if played is not None else True if p['starter'] else None;p.update(did_play=did,score=goals[pid] if did and goals_ok else None,assists=assists[pid] if did and assists_ok and goals_ok else None,minutes=minutes.get(pid) if did and not minute_error else None,minutes_basis='Elapsed regulation playing time including added time, excluding halftime; exact official substitutions and dismissal timestamps',minutes_reason=minute_error,injury_reported=pid in injuries,injured_departure=pid in injuries and any(v['kind']=='sub' and v['off']==pid for v in timeline))
 return rows,coaches,issues,dict(request_ids=event_rids,goal_proofs=goal_proofs,assist_proofs=assist_proofs,timeline=timeline,goal_counts_reconciled=goals_ok,assist_fields_complete=assists_ok,regulation_only=True)
