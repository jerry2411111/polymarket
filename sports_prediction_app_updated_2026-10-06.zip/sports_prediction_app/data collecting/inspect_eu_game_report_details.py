"""Inspect relevant official clock, player and score fields without full nested dumps."""
import collections,json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from epl_price_points import Sources
from probe_history import ROOT
from probe_eu_official_reports import brief
db=sqlite3.connect(DB);src=Sources(db);d,_=src.get('81e32575a6cf4289bda7172b5d5b5b95')
for s in ['away','home']:
 t=d[s];print('FL1',s,'MANAGER',brief(t['manager']));print('FL1 PLAYER STRUCTURE',type(t['players']).__name__)
 p=next(iter(t['players'].values())) if isinstance(t['players'],dict) else t['players'][0];print('FL1 PLAYER',json.dumps(brief(p),ensure_ascii=False));print('FL1 GOALS',json.dumps(t['goals'],ensure_ascii=False)[:1000])
print('FL1 TIMELINE',json.dumps(d['timeline'],ensure_ascii=False));print('FL1 STADIUM',json.dumps(d['stadium'],ensure_ascii=False)[:1200])
for rid,kind in [('3b142708657b446a91eb34ab262435b5','BUN'),('aea7cd9071d4493ea96242219b4e14cc','LAL')]:
 r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);soup=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
 for script in soup.find_all('script',type='application/json'):
  d=json.loads(script.get_text())
  if kind=='BUN':
   for k,v in d.items():
    if k.startswith('_getDataFromFirebase-/en/'):print('BUN DETAIL',json.dumps(brief(v[0]),ensure_ascii=False))
  else:
   p=d['props']['pageProps'];print('LAL MATCH',json.dumps(brief(p['match']),ensure_ascii=False));print('LAL DATA',json.dumps(brief(p['data']),ensure_ascii=False));print('LAL EVENTS',json.dumps([brief(v) for v in p['events']],ensure_ascii=False)[:6500])
db.close()
