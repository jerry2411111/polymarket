"""Compare retained app model recipes under dated training windows.

Read-only inputs; no app/model deployment. Every forecast uses an earlier-only
monthly fit and an unchanged as-of feature row. Never select a betting side from
prices. Run: final_models/.venv/Scripts/python.exe -B "data collecting/nba_mlb_training_windows.py"
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[k]='1'
from pathlib import Path
import argparse,collections,datetime as dt,hashlib,html,json,math,sqlite3,sys,time
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from scipy.special import softmax
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,log_loss,brier_score_loss,roc_auc_score
from sklearn.pipeline import Pipeline
from catboost import CatBoostClassifier
from threadpoolctl import threadpool_limits

PROJECT=Path(__file__).resolve().parents[1]
FINAL=PROJECT/'final_models'
OUT=PROJECT/'collected data/result/training_window_comparison'
sys.path.insert(0,str(FINAL/'runtime'))
import complete_model as cm
import daily_model as dm
import mlb_base
WINDOWS={'expanding':None,'24_months':24,'12_months':12,'6_months':6}
END=pd.Timestamp('2026-09-30',tz='UTC')

def dates(x):return pd.to_datetime(x,utc=True,format='mixed')
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=True,allow_nan=False,default=str),encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ro(p):return sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True)

def initialize():
    OUT.mkdir(parents=True,exist_ok=True)
    paths=['history/nba_all_features.parquet','history/mlb_all_features.parquet','mlb/features.parquet',
           'nba/columns.json','nba/template.pkl','mlb/columns.json','nba/backtest.sqlite','reference_market/features.parquet']
    plan=dict(created_utc=dt.datetime.now(dt.UTC).isoformat(),windows=WINDOWS,
        fit_cadence='First UTC day of each calendar month; identical cadence for all windows',
        test_game_dates='2024-01-01 through latest retained history, no later than 2026-09-29',
        selection='2024-2025 combined probability log loss on common games; 2026 reported separately, no 2026 tuning',
        caveat='2026 has been examined in prior research; this is chronological out-of-sample, not a previously untouched holdout',
        feature_history='Unchanged as-of features, including earlier career/Elo history; window restricts fitting observations, not feature histories',
        calibration='Same trailing calibration games from expanding partition in every window; purge training labels after first calibration feature cutoff',
        insufficient='No fit if fewer than 200 training or 100 calibration games, or calibration extends outside specified window; never backfill older rows',
        recipes='Unchanged NBA interaction logistic; MLB 19-input preliminary logistic; MLB 53-input confirmed logistic/CatBoost ensemble',
        betting='Predicted winner only, 1% current account equity per game, 20% aggregate open-cost cap; MLB requires p-price >=0.05, NBA all winners; hold through result availability',
        price='Retained Polymarket international history only; not Polymarket US executable quotes; age <=24h and available at decision',
        sharpe='sqrt(365.25) * mean / sample standard deviation of daily account returns, including idle calendar days; open positions held at cost; no costs',
        source_sha256={str(FINAL/p):sha(FINAL/p) for p in paths},script_sha256=sha(Path(__file__)))
    if not (OUT/'plan.json').exists():dump(OUT/'plan.json',plan)
    else:
        saved=json.loads((OUT/'plan.json').read_text());assert saved['source_sha256']==plan['source_sha256']
    return plan

def inputs(name):
    if name=='nba':
        f,cols,template,_=cm.inputs('nba');sport='nba'
    else:
        sport='mlb';template=None
        f=pd.read_parquet(FINAL/('history/mlb_all_features.parquet' if name=='mlb_preliminary' else 'mlb/features.parquet'))
        cols=list(mlb_base.FEATURES) if name=='mlb_preliminary' else dm.COLS
    assert not f.game_id.duplicated().any()
    f['_label_ns']=dates(f.label_available_at_utc).dt.as_unit('ns').astype('int64')
    f['_cut_ns']=dates(f.prediction_timestamp_utc).dt.as_unit('ns').astype('int64')
    f['_game_ns']=dates(f.timestamp).dt.as_unit('ns').astype('int64')
    for c in ['history_through_utc','history_available_through_utc']:
        if c in f:assert (dates(f[c]).dropna()<dates(f.loc[f[c].notna(),'prediction_timestamp_utc'])).all()
    test=f[cm.eligibility(f,sport)&f.date.ge('2024-01-01')&f.date.le('2026-09-29')].copy()
    test['month']=test.prediction_timestamp_utc.str[:7]
    return f,test,cols,template,sport

def fit_predict(name,tr,cal,test,cols,template):
    if name=='nba':
        model,t=cm.fit(tr,cal,template,cols)
        return softmax(np.log(np.clip(model.predict_proba(test[cols]),1e-12,1))/t,axis=1),[t]
    estimators=[LogisticRegression(C=.1,max_iter=5000,tol=1e-7)]
    if name=='mlb_confirmed':estimators.append(CatBoostClassifier(iterations=300,depth=3,learning_rate=.05,l2_leaf_reg=10,thread_count=1,random_seed=37,verbose=False,allow_writing_files=False))
    members=[];temps=[]
    for estimator in estimators:
        model=Pipeline([('scale',cm.ObservedScale()),('model',estimator)])
        model.fit(pd.concat([tr[cols],-tr[cols]],ignore_index=True),np.r_[tr.target.to_numpy(int),1-tr.target.to_numpy(int)])
        lp=np.log(np.clip(dm.probabilities(model,cal,cols),1e-12,1));y=cal.target.to_numpy(int)
        t=float(minimize_scalar(lambda v:-np.log(softmax(lp/v,axis=1)[np.arange(len(y)),y]).mean(),bounds=(.5,3),method='bounded').x)
        members.append(softmax(np.log(np.clip(dm.probabilities(model,test,cols),1e-12,1))/t,axis=1));temps.append(t)
    return np.mean(members,axis=0),temps

@threadpool_limits.wrap(limits=1)
def run(name):
    initialize();f,test,cols,template,sport=inputs(name);records=[];audits=[];count=0
    total=test.month.nunique()*len(WINDOWS);next_progress=10
    for month,part in test.groupby('month',sort=True):
        cut=pd.Timestamp(month+'-01',tz='UTC');base,cal,purged=cm.partition(f,cut.value,sport)
        for window,months in WINDOWS.items():
            started=time.monotonic();lower=cut-pd.DateOffset(months=months) if months else pd.Timestamp('2021-01-01',tz='UTC')
            tr=base[base._game_ns.ge(lower.value)]
            enough=len(tr)>=200 and len(cal)>=100 and cal._game_ns.min()>=lower.value
            audit=dict(model=name,window=window,month=month,fit_cutoff_utc=cut.isoformat(),window_start_utc=lower.isoformat(),
                training_games=len(tr),calibration_games=len(cal),purged_games=len(purged),test_games=len(part),status='fitted' if enough else 'insufficient_observations')
            if enough:
                assert tr._label_ns.max()<cal._cut_ns.min() and cal._label_ns.max()<cut.value<=part._cut_ns.min()
                assert not set(tr.game_id).intersection(cal.game_id) and not (set(tr.game_id)|set(cal.game_id)).intersection(part.game_id)
                pr,temperatures=fit_predict(name,tr,cal,part,cols,template)
                assert np.isfinite(pr).all() and np.allclose(pr.sum(1),1)
                audit.update(training_first_date=tr.date.min(),training_last_date=tr.date.max(),training_last_label_utc=pd.Timestamp(tr._label_ns.max(),tz='UTC').isoformat(),
                    calibration_first_cutoff_utc=pd.Timestamp(cal._cut_ns.min(),tz='UTC').isoformat(),calibration_last_label_utc=pd.Timestamp(cal._label_ns.max(),tz='UTC').isoformat(),
                    training_ids_json=json.dumps(tr.game_id.tolist()),calibration_ids_json=json.dumps(cal.game_id.tolist()),temperatures_json=json.dumps(temperatures))
                keep=['game_id','date','timestamp','prediction_timestamp_utc','label_available_at_utc','target','teamA','teamB','phase','history_group']
                r=part[keep].copy();r['model']=name;r['window']=window;r['fit_cutoff_utc']=cut.isoformat();r['p0']=pr[:,0];r['p1']=pr[:,1]
                r['pick']=np.argmax(pr,axis=1);r['probability']=np.max(pr,axis=1);r['correct']=r.pick.eq(r.target)
                records.append(r)
            audit['elapsed_seconds']=time.monotonic()-started;audits.append(audit);count+=1
            if 100*count/total>=next_progress:
                print(json.dumps(dict(model=name,progress_pct=next_progress,folds=count,total=total)),flush=True);next_progress+=10
    result=pd.concat(records,ignore_index=True);result.to_parquet(OUT/(name+'_predictions.parquet'),index=False)
    pd.DataFrame(audits).to_parquet(OUT/(name+'_fits.parquet'),index=False)
    print(json.dumps(dict(model=name,status='complete',forecasts=len(result),skipped_fits=sum(r['status']!='fitted' for r in audits))),flush=True)

def predictive_metrics(f):
    y=f.target.astype(int);p=f.p1.to_numpy();return dict(games=len(f),accuracy_pct=100*accuracy_score(y,f.pick),log_loss=log_loss(y,np.column_stack([1-p,p]),labels=[0,1]),
        brier=brier_score_loss(y,p),auc=roc_auc_score(y,p) if y.nunique()==2 else None,mean_confidence_pct=100*f.probability.mean())

def quote_rows(name,pred):
    if name=='nba':
        with ro(FINAL/'nba/backtest.sqlite') as c:q=pd.read_sql_query('select * from quote_audit',c)
        q=q.rename(columns={'class_index':'pick','entry_price':'price','entry_source_utc':'source_utc','entry_available_utc':'available_utc','entry_age_hours':'age_hours','entry_request_id':'request_id','entry_contract_id':'contract_id'})
        q=q[q.valid.eq(1)]
    else:
        original=pd.read_parquet(FINAL/'reference_market/features.parquet');parts=[]
        for side in [0,1]:
            fields=['price','source_utc','available_utc','age_hours','request_id','pointer','contract_id','eligible']
            q=original[['game_id']+[k+str(side) for k in fields]].rename(columns={k+str(side):k for k in fields});q['pick']=side;parts.append(q[q.eligible.eq(True)])
        q=pd.concat(parts,ignore_index=True)
    q=q[['game_id','pick','price','source_utc','available_utc','age_hours','request_id','contract_id']]
    joined=pred.merge(q,on=['game_id','pick'],how='left',validate='many_to_one')
    for c in ['prediction_timestamp_utc','timestamp','label_available_at_utc','source_utc','available_utc']:joined[c]=dates(joined[c])
    # MLB preliminary cutoffs differ from confirmed-lineup prices. A future quote
    # is never carried backwards to create a preliminary strategy result.
    valid=(joined.price.between(0,1,inclusive='neither')&joined.source_utc.le(joined.prediction_timestamp_utc)&joined.available_utc.le(joined.prediction_timestamp_utc)&
        (joined.prediction_timestamp_utc-joined.source_utc).dt.total_seconds().between(0,86400)&joined.prediction_timestamp_utc.lt(joined.timestamp))
    joined['quote_valid']=valid
    return joined

def simulate(f,year):
    start=pd.Timestamp(f'{year}-01-01',tz='UTC');end=min(pd.Timestamp(f'{year+1}-01-01',tz='UTC'),END)
    f=f[f.prediction_timestamp_utc.ge(start)&f.prediction_timestamp_utc.lt(end)].copy()
    events=collections.defaultdict(lambda:dict(entries=[],exits=[],day=False))
    for day in pd.date_range(start,end,freq='D'):events[day]['day']=True
    for r in f.to_dict('records'):
        events[r['prediction_timestamp_utc']]['entries'].append(r)
        if r['label_available_at_utc']<end:events[r['label_available_at_utc']]['exits'].append(r['game_id'])
    cash=10000.;opened={};bets=[];daily=[];peak=cash;drawdown=0.
    for at,e in sorted(events.items()):
        equity=cash+sum(x['stake'] for x in opened.values())
        if e['day'] and at>start:daily.append(dict(date=(at-pd.Timedelta(days=1)).date().isoformat(),equity=equity))
        if at>=end:break
        for gid in e['exits']:
            if gid in opened:cash+=opened.pop(gid)['payout']
        committed=sum(x['stake'] for x in opened.values());equity=cash+committed
        entries=e['entries'];room=max(0.,min(cash,.2*equity-committed));stake=min(.01*equity,room/len(entries)) if entries else 0
        for r in entries:
            if stake<=1e-10:continue
            assert r['game_id'] not in opened
            payout=stake/r['price']*int(r['pick']==r['target'])
            rec=r|dict(stake=stake,payout=payout,profit=payout-stake,unit_return=int(r['pick']==r['target'])/r['price']-1,settled_before_end=r['label_available_at_utc']<end)
            opened[r['game_id']]=rec;bets.append(rec);cash-=stake
        assert cash>=-1e-7
        peak=max(peak,equity);drawdown=max(drawdown,1-equity/peak)
    b=pd.DataFrame(bets);d=pd.DataFrame(daily);d['return']=d.equity/d.equity.shift(1,fill_value=10000.)-1
    sd=d['return'].std(ddof=1);final=d.equity.iloc[-1]
    assert np.isclose(final,10000.+(b.loc[b.settled_before_end,'profit'].sum() if len(b) else 0),atol=1e-6)
    m=dict(year=year,funded_games=len(b),win_rate_pct=100*b.correct.mean() if len(b) else None,return_pct=100*(final/10000-1),
        sharpe=float(np.sqrt(365.25)*d['return'].mean()/sd) if sd>0 else None,max_drawdown_pct=100*drawdown,
        mean_bet_return_pct=100*b.unit_return.mean() if len(b) else None,calendar_days=len(d),unsettled_at_end=len(opened))
    return m,b,d

def finish():
    initialize();metrics=[];coverage=[];selections=[];paired=[];betmetrics=[];betrows=[];dailyrows=[];skips=[];replays=[]
    for name in ['nba','mlb_preliminary','mlb_confirmed']:
        p=pd.read_parquet(OUT/(name+'_predictions.parquet'));p['year']=p.date.str[:4].astype(int)
        fits=pd.read_parquet(OUT/(name+'_fits.parquet'));skips.append(fits[fits.status.ne('fitted')])
        common=set.intersection(*(set(p.loc[p.window.eq(w),'game_id']) for w in WINDOWS))
        core_windows=['expanding','24_months','12_months']
        core_common=set.intersection(*(set(p.loc[p.window.eq(w),'game_id']) for w in core_windows))
        for w,g in p.groupby('window'):
            scopes=[('available',g),('common_all_windows',g[g.game_id.isin(common)])]
            if w in core_windows:scopes.append(('common_full_coverage_windows',g[g.game_id.isin(core_common)]))
            for scope,part in scopes:
                for y,partyear in part.groupby('year'):metrics.append(dict(model=name,window=w,scope=scope,year=int(y),**predictive_metrics(partyear)))
                dev=part[part.year.lt(2026)]
                if len(dev):metrics.append(dict(model=name,window=w,scope=scope,year='2024-2025',**predictive_metrics(dev)))
        m=pd.DataFrame(metrics);pick=m[m.model.eq(name)&m.scope.eq('common_all_windows')&m.year.eq('2024-2025')].sort_values('log_loss').iloc[0]
        selections.append(dict(model=name,selected_window=pick.window,development_log_loss=float(pick.log_loss),development_accuracy_pct=float(pick.accuracy_pct)))
        core_pick=m[m.model.eq(name)&m.scope.eq('common_full_coverage_windows')&m.year.eq('2024-2025')].sort_values('log_loss').iloc[0]
        selections[-1].update(full_coverage_sensitivity_window=core_pick.window,full_coverage_sensitivity_log_loss=float(core_pick.log_loss))
        # Paired monthly resampling measures uncertainty without treating all games
        # on the same match day as independent. It is descriptive, not a new gate.
        evalp=p[p.game_id.isin(common)&p.year.eq(2026)].copy();base=evalp[evalp.window.eq('expanding')].set_index('game_id')
        for w in WINDOWS:
            if w=='expanding':continue
            g=evalp[evalp.window.eq(w)].set_index('game_id').loc[base.index]
            y=g.target.to_numpy(int);new=-np.log(np.where(y,g.p1,g.p0));old=-np.log(np.where(y,base.p1,base.p0))
            diff=pd.DataFrame(dict(month=g.date.str[:7].to_numpy(),delta=new-old,correct=g.correct.astype(int).to_numpy()-base.correct.astype(int).to_numpy()))
            groups=[v for _,v in diff.groupby('month')];rng=np.random.default_rng(20261003);samples=[]
            for _ in range(2000):
                draw=[groups[i] for i in rng.integers(len(groups),size=len(groups))];samples.append(sum(x.delta.sum() for x in draw)/sum(len(x) for x in draw))
            paired.append(dict(model=name,window=w,games=len(g),accuracy_change_pp=100*diff.correct.mean(),log_loss_change=diff.delta.mean(),
                monthly_bootstrap_loss_change_low=float(np.quantile(samples,.025)),monthly_bootstrap_loss_change_high=float(np.quantile(samples,.975))))
        if name=='mlb_preliminary':continue
        if name=='mlb_confirmed':
            saved=pd.read_parquet(FINAL/'mlb/predictions.parquet')
            replay=p[p.window.eq('expanding')].merge(saved,on='game_id',suffixes=('_new','_saved'),validate='one_to_one')
            replay=replay[replay.fit_date.str[:10].eq(replay.fit_cutoff_utc.str[:10])]
            assert len(replay)>0 and np.allclose(replay[['p0_new','p1_new']],replay[['p0_saved','p1_saved']],atol=1e-12,rtol=0)
            replays.append(dict(model=name,same_fit_date_forecasts=len(replay),maximum_probability_difference=float(np.max(np.abs(replay[['p0_new','p1_new']].to_numpy()-replay[['p0_saved','p1_saved']].to_numpy())))))
        quoted=quote_rows(name,p)
        # Require a valid quote for every window's selected winner so changed
        # picks do not create window-specific market-coverage advantages.
        count=quoted[quoted.quote_valid].groupby('game_id').window.nunique()
        matched=set(count[count.eq(len(WINDOWS))].index)&common
        core_count=quoted[quoted.quote_valid&quoted.window.isin(core_windows)].groupby('game_id').window.nunique()
        core_matched=set(core_count[core_count.eq(len(core_windows))].index)&core_common
        for w,g in quoted.groupby('window'):
            for y,h in g.groupby('year'):coverage.append(dict(model=name,window=w,year=int(y),forecasts=len(h),valid_winner_quotes=int(h.quote_valid.sum()),matched_games=int(h.game_id.isin(matched).sum()),full_coverage_matched_games=int(h.game_id.isin(core_matched).sum()) if w in core_windows else None))
            universes=[('common_all_windows',matched)]
            if w in core_windows:universes.append(('common_full_coverage_windows',core_matched))
            for scope,universe in universes:
                allowed=g[g.game_id.isin(universe)&g.quote_valid].copy()
                if name=='mlb_confirmed':allowed=allowed[allowed.probability.sub(allowed.price).ge(.05)]
                for year in [2024,2025,2026]:
                    m,b,d=simulate(allowed,year);meta=dict(model=name,window=w,scope=scope)
                    betmetrics.append(meta|m)
                    if len(b):betrows.append(b.assign(**meta))
                    dailyrows.append(d.assign(**meta,year=year))
    pd.DataFrame(metrics).to_csv(OUT/'prediction_metrics.csv',index=False)
    pd.DataFrame(paired).to_csv(OUT/'paired_2026.csv',index=False)
    pd.DataFrame(coverage).to_csv(OUT/'price_coverage.csv',index=False)
    pd.DataFrame(betmetrics).to_csv(OUT/'betting_annual.csv',index=False)
    pd.concat(betrows,ignore_index=True).to_parquet(OUT/'bets.parquet',index=False)
    pd.concat(dailyrows,ignore_index=True).to_parquet(OUT/'daily_equity.parquet',index=False)
    pd.concat(skips,ignore_index=True).drop(columns=['training_ids_json','calibration_ids_json'],errors='ignore').to_csv(OUT/'insufficient_fits.csv',index=False)
    dump(OUT/'selection.json',selections)
    dump(OUT/'validation.json',dict(status='PASS',fit_labels_before_calibration=True,calibration_labels_before_fit=True,fit_before_prediction=True,
        no_test_games_in_fit=True,all_window_dates_checked=True,all_quotes_available_before_entry=True,no_app_models_modified=True,
        strategy_cash_and_final_equity_reconciled=True,source_hashes_unchanged=True,retained_recipe_replays=replays,
        script_sha256=sha(Path(__file__)),completed_utc=dt.datetime.now(dt.UTC).isoformat()))
    report()
    print(json.dumps(selections),flush=True)

def report():
    plan=json.loads((OUT/'plan.json').read_text());audit=json.loads((OUT/'app_update_audit.json').read_text())
    metrics=pd.read_csv(OUT/'prediction_metrics.csv');bets=pd.read_csv(OUT/'betting_annual.csv')
    selection=pd.DataFrame(json.loads((OUT/'selection.json').read_text()))
    body=['<h1>NBA and MLB training-window comparison</h1>',
        '<p>These are monthly rolling refits, using the retained app model recipes. Each forecast uses only earlier available labels. All-history means expanding observations beginning in 2021. Short windows change training examples; existing as-of career and recent-form features are unchanged.</p>',
        '<h2>Running app audit</h2>',
        '<p>MLB checks completed games hourly and has appended nine newer games, through October 3. These update forecast inputs, but both MLB training paths still read static feature files ending September 29. Daily fit dates therefore do not demonstrate training on new observations. NBA has no equivalent automatic completed-game updater; its saved data ends July 19. Started-game forecasts remain frozen.</p>',
        '<p>The most recent 300 known games are reserved for probability calibration, with a temporal purge before them. Consequently the coefficient-training date is deliberately earlier than the latest calibration date. The problem is the absence of new rows in the training/calibration source, not that separation.</p>',
        '<h2>Comparison design</h2><ul>']
    for k in ['fit_cadence','selection','caveat','feature_history','calibration','insufficient','recipes','betting','price','sharpe']:
        body.append('<li><b>'+html.escape(k.replace('_',' '))+':</b> '+html.escape(plan[k])+'</li>')
    body.extend(['</ul><p>The comparison does not deploy a new model or repair the running app update paths. The app remains on its existing models.</p>',
        '<h2>Window selected using 2024–2025 probability error</h2>',selection.to_html(index=False,float_format=lambda v:f'{v:.6f}'),
        '<h2>Prediction results on identical games across all four windows</h2>',
        metrics[metrics.scope.eq('common_all_windows')].to_html(index=False,float_format=lambda v:f'{v:.6f}'),
        '<h2>Full-season coverage sensitivity: all history versus 24 and 12 months</h2><p>This additional comparison was added after identifying six-month coverage exclusions. It retains season-opening months and is reported separately from the initially specified four-window common sample. It is not a new independent holdout.</p>',
        metrics[metrics.scope.eq('common_full_coverage_windows')].to_html(index=False,float_format=lambda v:f'{v:.6f}'),
        '<h2>Prediction results on every available test game</h2><p>Check game counts: six-month fits cannot cover several season-opening months. Do not compare unequal subsets as if they were the same games.</p>',
        metrics[metrics.scope.eq('available')].to_html(index=False,float_format=lambda v:f'{v:.6f}'),
        '<h2>Betting results on the common covered universe</h2><p>All rows use the same exposure and entry rule within a sport. MLB uses the confirmed model and its five-percentage-point price advantage requirement. NBA buys its predicted winner. Prices are retained international Polymarket observations, not US executable prices. Missing quotes are excluded without substituting the other team.</p>',
        bets.to_html(index=False,float_format=lambda v:f'{v:.6f}'),
        '<h2>Market coverage</h2>',pd.read_csv(OUT/'price_coverage.csv').to_html(index=False),
        '<h2>Paired 2026 uncertainty</h2><p>Negative log-loss changes favour the shorter window. The interval resamples calendar months; limited months and prior research exposure restrict the inference.</p>',pd.read_csv(OUT/'paired_2026.csv').to_html(index=False,float_format=lambda v:f'{v:.6f}'),
        '<h2>Fits with insufficient observations</h2>',pd.read_csv(OUT/'insufficient_fits.csv').to_html(index=False),
        '<h2>Data and reproducibility</h2><p>Source files, hashes, exact fit memberships, forecasts, matched betting ledgers, daily equity and validation are retained in this folder. Run the script stages init, nba, mlb_preliminary, mlb_confirmed, finish in order; the three model stages can run independently after init. No temporary fitted models are retained.</p>',
        '<p>Audit time: '+html.escape(audit['checked_at_utc'])+'</p>'])
    page='<!doctype html><html><head><meta charset="utf-8"><title>NBA and MLB training-window comparison</title><style>body{font-family:Arial,sans-serif;margin:32px;line-height:1.45;color:#172033}table{border-collapse:collapse;font-size:12px;margin-bottom:24px}td,th{padding:6px;border:1px solid #ccd3dc}th{background:#edf2f8}h2{margin-top:32px}</style></head><body>'+''.join(body)+'</body></html>'
    (OUT/'report.html').write_text(page,encoding='utf-8')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['init','nba','mlb_preliminary','mlb_confirmed','finish']);args=parser.parse_args()
    if args.stage=='init':initialize()
    elif args.stage=='finish':finish()
    else:run(args.stage)
