"""Official Premier League schedule by calendar month, validating the real operator filters."""
import argparse,calendar,datetime as dt,json,sqlite3
from zoneinfo import ZoneInfo
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT,HOSTS

BASE='https://sdp-prem-prod.premier-league-prod.pulselive.com/api'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--through-percent',type=int,default=100);a=ap.parse_args();HOSTS.add('sdp-prem-prod.premier-league-prod.pulselive.com');client=HistoryClient();db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _official_epl_calendar (match_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('CREATE TABLE IF NOT EXISTS _official_epl_calendar_partitions (month TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();day=dt.date(2024,1,1);end=dt.date(2026,9,15);n=0
    while day<end:
        hi=min(day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1),end);month=day.strftime('%Y-%m');previous=db.execute('SELECT body FROM _official_epl_calendar_partitions WHERE month=?',(month,)).fetchone()
        if previous and json.loads(previous[0])['pagination_exhausted']:day=hi;n+=1;continue
        if n*100>=a.through_percent*33:break
        season=str(day.year if day.month>=7 else day.year-1);url=BASE+'/v2/matches?kickoff>'+day.isoformat()+'&kickoff<'+hi.isoformat();params=dict(competition='8',season=season,_limit=100);seen=set();cursors=set();requests=[];rows=[];error=None
        try:
            for _ in range(100):
                d,r=client.get(url,params);requests.append(r['request_id']);assert isinstance(d['data'],list)
                for i,g in enumerate(d['data']):
                    assert day.isoformat()<=g['kickoff'][:10]<hi.isoformat(),'Ignored date filters';assert g['competitionId']=='8' and g['season']==season,'Wrong competition/season';mid=g['matchId'];assert mid not in seen,'Pagination duplicate';seen.add(mid)
                    local=dt.datetime.fromisoformat(g['kickoff']).replace(tzinfo=ZoneInfo(g['kickoffTimezoneString']));assert local.tzname()==g['kickoffTimezone'];normalized=dict(official_match_id=mid,competition='Premier League',competition_id=g['competitionId'],season=season+'-'+str(int(season)+1)[-2:],date=local.date().isoformat(),scheduled_start_utc=local.astimezone(dt.UTC).isoformat(),home=g['homeTeam'],away=g['awayTeam'],location=g.get('ground'),status=g['period'],result_type=g.get('resultType'),request_id=r['request_id'],pointer='/data/'+str(i),raw=g)
                    if g['period']=='FullTime':
                        assert all(type(g[t].get('score')) is int and type(g[t].get('halfTimeScore')) is int for t in ['homeTeam','awayTeam']);normalized['winner']='Draw' if g['homeTeam']['score']==g['awayTeam']['score'] else g['homeTeam']['name'] if g['homeTeam']['score']>g['awayTeam']['score'] else g['awayTeam']['name']
                    rows.append((mid,json.dumps(normalized)))
                cursor=d['pagination'].get('_next')
                if not cursor:break
                assert cursor not in cursors,'Repeated cursor';cursors.add(cursor);params['_next']=cursor
            else:raise ValueError('Pagination safety bound exceeded')
        except Exception as e:error=str(e)
        record=dict(month=month,request_ids=requests,matches=len(rows),pagination_exhausted=error is None,error=error)
        with db:db.executemany('INSERT OR REPLACE INTO _official_epl_calendar VALUES (?,?)',rows);db.execute('INSERT OR REPLACE INTO _official_epl_calendar_partitions VALUES (?,?)',(month,json.dumps(record)))
        n+=error is None;print('EPL OFFICIAL CALENDAR',month,len(rows),error or 'checked',n,'/33',flush=True);write_report(db,client.requests)
        if error:break
        day=hi
    write_report(db,client.requests);db.close()

def write_report(db,requests):
    parts=[json.loads(b) for b, in db.execute('SELECT body FROM _official_epl_calendar_partitions ORDER BY month')];count=sum(p['pagination_exhausted'] for p in parts);rows=[json.loads(b) for b, in db.execute('SELECT body FROM _official_epl_calendar')];done=[r for r in rows if r['status']=='FullTime'];out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='ACQUIRED_REQUIRES_INDEPENDENT_VALIDATION',months_complete=count,total_months=33,percent=round(count*100/33,2),matches=len(rows),completed_matches=len(done),earliest_date=min((r['date'] for r in done),default=None),latest_date=max((r['date'] for r in done),default=None),new_requests= requests,partitions=parts,limitation='Official calendar coverage is not quote coverage. Seasons crossing the collection start/end are partial. Scheduled start may differ from the official actual opening timestamp.')
    (ROOT/'reports/epl_calendar_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8')

if __name__=='__main__':main()
