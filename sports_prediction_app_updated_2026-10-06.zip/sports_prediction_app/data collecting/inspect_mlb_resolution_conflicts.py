import json,sqlite3
from build_history_catalog import DB
from history_index import index
db=sqlite3.connect(DB);data=index()
issues=[json.loads(b) for b, in db.execute('SELECT body FROM _mlb_market_matching_audit') if 'disagrees' in json.loads(b)['reason']]
for x in issues:
    g=json.loads(db.execute('SELECT body FROM _official_mlb_schedule WHERE official_game_id=?',(x['official_game_id'],)).fetchone()[0])
    print('ISSUE',x);print('SCHEDULE',json.dumps(g['raw_game']))
    if x['provider']=='kalshi':
        m=data['kalshi_markets'][x['market_id']][0];print('MARKET',json.dumps(m))
        for mid,(v,_,_) in data['milestones'].items():
            if m['event_ticker'] in v.get('primary_event_tickers',[]):print('MILESTONE',json.dumps(v))
    else:
        for eid,(e,_,_) in data['polymarket_events'].items():
            for m in e.get('markets',[]):
                if m['id']==x['market_id']:print('PM',json.dumps(m));print('EVENT',{k:v for k,v in e.items() if k in ['id','title','slug','startTime']})
