"""Retain official club reports for three independent Serie A calendar checks."""
import datetime as dt,json,re
from bs4 import BeautifulSoup
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS

URLS=['https://www.inter.it/it/match_center/5171','https://www.acmilan.com/en/news/articles/serie-a/2024-01-07/empoli-v-ac-milan-the-official-line-ups','https://www.acmilan.com/it/news/articoli/serie-a/2024-01-07/il-milan-vince-e-convince-3-0-a-empoli','https://www.asroma.com/it/notizie/70228/la-gallery-di-roma-atalanta-1-1','https://www.asroma.com/it/notizie/70207/tutti-insieme-allo-stadio-per-spingere-i-nostri-le-info-per-vivere-roma-atalanta-allolimpico']
def main():
 HOSTS.update({'www.inter.it','www.acmilan.com','www.asroma.com'});c=HistoryClient();rows=[]
 for url in URLS:
  try:
   b,r,red=get(c,url);soup=BeautifulSoup(b,'html.parser');text=' '.join(soup.get_text(' ',strip=True).split());context=[]
   for hit in re.finditer(r'6 Gennaio 2024|07 gennaio 2024|7 gennaio, 2024|12:30|20\.45|3-0 A EMPOLI|Roma-Atalanta 1-1|January 7th 2024',text,re.I):
    context.append(text[max(0,hit.start()-80):hit.end()+230])
    if len(context)==5:break
   row=dict(url=url,request_id=r['request_id'],redirects=red,title=soup.title.get_text() if soup.title else None,contexts=context,status='ACQUIRED_REQUIRES_VALIDATION');print(json.dumps(row,ensure_ascii=False),flush=True)
  except Exception as e:row=dict(url=url,error=str(e),status='ERROR');print(json.dumps(row),flush=True)
  rows.append(row)
 (ROOT/'reports/seriea_public_pilot_sources.json').write_text(json.dumps(dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),sources=rows,new_requests=c.requests),indent=2),encoding='utf-8')

if __name__=='__main__':main()
