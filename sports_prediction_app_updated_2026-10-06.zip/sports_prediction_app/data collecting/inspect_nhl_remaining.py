import json,sqlite3
from build_history_catalog import DB
from history_index import index
db=sqlite3.connect(DB);issues=[json.loads(b) for b, in db.execute('SELECT body FROM _nhl_market_matching_audit') if 'Not an entire' not in b];print('ISSUES',json.dumps(issues));d=index();wanted={x['market_id'] for x in issues}
for eid,(e,r,p) in d['polymarket_events'].items():
 for m in e.get('markets',[]):
  if m['id'] in wanted:print('PM',json.dumps({k:m.get(k) for k in ['id','question','description','outcomes','gameStartTime','sportsMarketType']}),json.dumps({k:e.get(k) for k in ['id','title','slug','teams']}))
for mid,(m,r,p) in d['kalshi_markets'].items():
 if mid in wanted:print('K',json.dumps({k:m.get(k) for k in ['ticker','event_ticker','title','yes_sub_title','custom_strike','result']}))
for mid,(m,r,p) in d['milestones'].items():
 if '26JAN26' in json.dumps(m) and 'NHL' in json.dumps(m):print('MILE',json.dumps(m))
