"""Run calendar-month acquisition batches, preserving common date-queryable SQL.

Raw responses are reused across months where windows overlap. A month's batch
report distinguishes complete request accounting from complete data availability.
"""
import argparse,calendar,collections,datetime as dt,json,sqlite3,subprocess,sys
from build_history_catalog import DB
from probe_history import ROOT
from history_index import records,payload
def months(start,end):
 cur=start.replace(day=1)
 while cur<=end:
  last=cur.replace(day=calendar.monthrange(cur.year,cur.month)[1]);yield max(cur,start),min(last,end)
  cur=(last+dt.timedelta(days=1))
def validate(start,end):
 db=sqlite3.connect(DB);gs={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,body FROM _history_games')};cs=[json.loads(r[0]) for r in db.execute('SELECT body FROM _history_contracts')];db.close()
 gs={k:g for k,g in gs.items() if start<=g['date']<=end};cs=[c for c in cs if c['game_id'] in gs];jobs={}
 path=ROOT/'reports/history_acquisition_jobs.jsonl'
 if path.exists():
  for line in path.read_text().splitlines():
   if not line:continue
   j=json.loads(line)
   if j['game_id'] in gs:jobs[j['kind'],j.get('contract_id') or j['game_id']]=j
 rs={r['request_id']:r for r in records()};missing=[];errors=[];empty=[];observed=collections.Counter();rawchecks=0
 for c in cs:
  j=jobs.get(('price',c['contract_id']))
  if not j:missing.append(c['contract_id']);continue
  if j['status']!='ok':errors.append(j);continue
  if j.get('rows')==0:empty.append(c['contract_id'])
  for rid in j.get('request_ids') or [j['request_id']]:
   r=rs[rid];d=payload(r)
   if r['status']!=200:raise ValueError('Successful job linked to failed request')
   values=d.get('data') if c['provider']=='polymarket' else d.get('candlesticks')
   if values is None:raise ValueError('History schema missing observations')
   for x in values:
    if c['provider']=='polymarket':p=x['price'];t=x['timestamp']
    else:
     suffix='close' if '/historical/' in r['endpoint'] else 'close_dollars';p=x['yes_bid'].get(suffix);t=x['end_period_ts'];ask=x['yes_ask'].get(suffix)
     if p is not None and ask is not None and float(p)>float(ask):raise ValueError('Crossed bid/ask')
    if p is not None and not 0<=float(p)<=1:raise ValueError('Invalid probability scale')
    if not isinstance(t,int):raise ValueError('Invalid source timestamp')
    rawchecks+=1
   observed[c['provider']]+=len(values)
 status='NO_MATCHED_MARKETS' if not gs else 'INCOMPLETE_REQUESTS' if missing or errors else 'REQUESTS_ACCOUNTED_FOR'
 result=dict(month=start[:7],from_date=start,through_date=end,status=status,matched_games=len(gs),games_by_league=dict(collections.Counter(g['league'] for g in gs.values())),contracts=len(cs),missing_jobs=missing,failed_jobs=errors,empty_price_histories=len(empty),empty_contract_ids=empty,returned_observations_by_provider=dict(observed),raw_value_checks=rawchecks,full_dataset_validation='Pending normalization, checkpoint selection and date-specific supporting-table checks. HTTP success does not establish completeness.')
 dest=ROOT/'reports/monthly'/start[:7];dest.mkdir(parents=True,exist_ok=True);(dest/'acquisition.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print('MONTH',start[:7],status,'games',len(gs),'empty histories',len(empty),'errors',len(errors),flush=True)
 return result
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--from-date',default='2023-09-13');ap.add_argument('--through-date',default='2026-09-13');ap.add_argument('--validate-only',action='store_true');args=ap.parse_args()
 out=[]
 for start,end in months(dt.date.fromisoformat(args.from_date),dt.date.fromisoformat(args.through_date)):
  lo,hi=start.isoformat(),end.isoformat()
  if not args.validate_only:
   for script in ['collect_nba_gamebooks.py','collect_history.py']:
    subprocess.run([sys.executable,str(ROOT/'data collecting'/script),'--from-date',lo,'--through-date',hi],check=True,cwd=ROOT)
  out.append(validate(lo,hi))
  if out[-1]['missing_jobs'] or out[-1]['failed_jobs']:raise RuntimeError('This month has acquisition failures; resolve before advancing')
 (ROOT/'reports/monthly_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
if __name__=='__main__':main()
