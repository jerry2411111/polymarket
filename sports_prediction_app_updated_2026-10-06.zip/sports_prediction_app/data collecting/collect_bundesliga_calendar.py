"""Read four small official season calendars and retain only completed games in scope."""
import collections,datetime as dt,json,sqlite3
from zoneinfo import ZoneInfo
from build_history_catalog import DB
from history_client import HistoryClient
from probe_history import ROOT,HOSTS
from probe_bundesliga_archives import BASE

def main():
    HOSTS.update({'bundesliga-web-prod.europe-west1.firebasedatabase.app','www.dfb.de','www.bundesliga.com'});client=HistoryClient();db=sqlite3.connect(DB,timeout=60);pilot=json.loads((ROOT/'reports/bundesliga_historical_pilot.json').read_text());assert pilot['status']=='WORKING';seasons=pilot['seasons'];seasons['2026']=dict(native_season_id='DFL-SEA-0001KA',page_request_id='df92202f720446a69e81ee9263513ecf');rows=[];parts=[];revisions=[]
    ruling_url='https://www.dfb.de/news/dfb-sportgericht-wertet-bundesligaspiel-in-berlin-fuer-bochum';ruling,rr=client.get(ruling_url,document=True)
    from bs4 import BeautifulSoup
    text=BeautifulSoup(ruling,'html.parser').get_text(' ',strip=True);assert '09.01.2025' in text and '2:0' in text and 'Bochum' in text
    for year,s in sorted(seasons.items()):
        native=s['native_season_id'];data,r=client.get(BASE+'/all/DFL-COM-000001/seasons/'+native+'/matches.json');assert isinstance(data,dict);ids=set();kept=[]
        for key,m in data.items():
            assert key==m['matchId'] and m['dflDatalibrarySeasonId']==native and m['dflDatalibraryCompetitionId']=='DFL-COM-000001';assert key not in ids;ids.add(key)
            when=dt.datetime.fromisoformat(m['plannedKickOff']);assert when.tzinfo;local=when.astimezone(ZoneInfo('Europe/Berlin'));day=local.date().isoformat()
            if not '2024-01-01'<=day<='2026-09-14' or m['matchStatus']!='FINAL_WHISTLE':continue
            scores=[];score_fields=[]
            for side in ['away','home']:
                field='fulltime' if 'fulltime' in m['score'][side] else 'live'
                if 'fulltime'in m['score'][side] and m['score'][side]['fulltime']!=m['score'][side]['live']:
                    assert key=='DFL-MAT-J0406K' and day=='2024-12-14','Unreviewed change between played and awarded score';field='live'
                value=m['score'][side][field];assert type(value)is int and value>=0
                scores.append(value);score_fields.append('/score/'+side+'/'+field)
            teams=[m['teams'][side] for side in ['away','home']];assert teams[0]['dflDatalibraryClubId']!=teams[1]['dflDatalibraryClubId'];actual=dt.datetime.fromisoformat(m['kickOff']);assert actual.tzinfo
            row=dict(official_match_id=key,competition='Bundesliga',competition_id='DFL-COM-000001',season=year+'-'+str(int(year)+1)[2:],native_season_id=native,date=day,scheduled_start_utc=when.astimezone(dt.UTC).isoformat(),actual_start_utc=actual.astimezone(dt.UTC).isoformat(),home=m['teams']['home'],away=m['teams']['away'],scores=scores,score_fields=score_fields,halftime_scores=[m['score'][side].get('halftime') for side in ['away','home']],winner='Draw' if scores[0]==scores[1] else teams[int(scores[1]>scores[0])]['nameFull'],status=m['matchStatus'],request_id=r['request_id'],pointer='/'+key,raw=m)
            if key=='DFL-MAT-J0406K':
                assert scores==[2,0] and [m['score'][s]['fulltime'] for s in ['away','home']]==[1,1]
                row['result_revision']=dict(played_score=[1,1],awarded_score=[2,0],award_effective_from='2025-01-09',official_ruling_url=ruling_url,ruling_request_id=rr['request_id'],warning='Future performance queries before the ruling must use the played draw. Provider regulation-win resolution requires separate review.');revisions.append(dict(official_match_id=key,**row['result_revision']))
            rows.append((key,json.dumps(row)));kept.append(row)
        # Exact full season sanity checks independently establish 18 x 34 / 2.
        counts=collections.Counter(t['dflDatalibraryClubId'] for m in kept for t in [m['away'],m['home']]);complete=year in ['2024','2025']
        if complete:assert len(kept)==306 and len(counts)==18 and set(counts.values())=={34}
        parts.append(dict(season=year,native_season_id=native,request_id=r['request_id'],source_rows=len(data),in_scope_completed=len(kept),complete_season=complete,teams=len(counts)));print('BUNDESLIGA CALENDAR',parts[-1],flush=True)
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS _official_bundesliga_calendar (match_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _official_bundesliga_calendar VALUES (?,?)',rows)
    months=collections.Counter(json.loads(b)['date'][:7] for _,b in rows);out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='ACQUIRED_REQUIRES_FULL_RAW_VALIDATION',completed_games=len(rows),seasons=parts,monthly_counts=dict(sorted(months.items())),new_requests=client.requests,result_revisions=revisions,limits=['Date filtering is not indexed by this official Firebase API (HTTP 400). Each whole-season calendar is only 306 games; raw contains future/out-of-scope entries which are excluded from normalized facts.','For older final-whistle records without fulltime, the explicitly final live score is retained with its original field pointer.','Calendar acquisition does not prove provider matching, break coverage or historical quote availability.']);(ROOT/'reports/bundesliga_calendar_acquisition.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('BUNDESLIGA TOTAL',len(rows));db.close()

if __name__=='__main__':main()
