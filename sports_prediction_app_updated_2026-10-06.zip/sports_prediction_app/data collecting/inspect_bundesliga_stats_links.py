import json,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB);r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',('3b142708657b446a91eb34ab262435b5',)).fetchone()[0]);soup=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
for link in soup.find_all('a',href=True):
 if 'bayern-muenchen-vs-1-fc-union-berlin' in link['href']:print(link.get_text(' ',strip=True)[:80],link['href'])
db.close()
