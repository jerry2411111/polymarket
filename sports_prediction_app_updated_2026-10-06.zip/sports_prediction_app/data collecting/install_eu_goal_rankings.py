"""Validate and publish two original GOAL editions with quarterly as-of flags."""
import collections,datetime as dt,hashlib,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from build_nba_ranking_facts import source_dates
from collect_laliga_people import namekey
from index_ranking_flags import refresh
from probe_history import ROOT
from temporal_queries import FLAGS
CLUBS={'Barcelona':'FC Barcelona','Real Madrid':'Real Madrid C.F.','Inter':'FC Internazionale Milano','Marseille':'Olympique de Marseille','Bayern Munich':'FC Bayern München','Atletico Madrid':'Atlético de Madrid','Atalanta':'Atalanta BC','Bayer Leverkusen':'Bayer 04 Leverkusen','Napoli':'SSC Napoli','Newcastle':'Newcastle United','Sporting CP':'Sporting Clube de Portugal','Galatasaray':'Galatasaray A.Ş.','Roma':'AS Roma','Hamburg':'Hamburger SV','Angers':'Angers SCO','Rennes':'Stade Rennais FC','Lens':'RC Lens','Mallorca':'Real Club Deportivo Mallorca SAD','Stuttgart':'VfB Stuttgart','Como':'Como 1907'}
def digest(db,table):
 h=hashlib.sha256()
 for row in db.execute('SELECT * FROM '+table+" WHERE league!='EU soccer' ORDER BY 1,2,3"):h.update(json.dumps(row,separators=(',',':')).encode())
 return h.hexdigest()
def main():
 db=sqlite3.connect(DB,timeout=60);facts=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_ranking_candidate_facts')];eds={i:json.loads(b) for i,b in db.execute('SELECT * FROM _eu_ranking_candidate_editions')};people={p:json.loads(b) for p,b in db.execute('SELECT * FROM _eu_people_registry')};games=collections.defaultdict(list);first={};sources={r['request_id']:r for b, in db.execute('SELECT body FROM _eu_editorial_sources') for r in [json.loads(b)] if 'request_id' in r};raws={};checks=collections.Counter();start=db.execute('SELECT collection_start FROM _collection_scope').fetchone()[0]
 for b, in db.execute('SELECT body FROM _eu_player_game_facts'):
  p=json.loads(b);games[p['player_id']].append(p);first[p['player_id']]=min(first.get(p['player_id'],p['game_date']),p['game_date'])
 for b, in db.execute('SELECT body FROM _eu_player_memberships'):
  m=json.loads(b)
  if m['player_id'] in first and m['start_date']:first[m['player_id']]=min(first[m['player_id']],max(start,m['start_date']))
 assert len(facts)==100 and len({(f['list_id'],f['player_id']) for f in facts})==100 and all(f['player_id'] for f in facts)
 for f in facts:
  rid=f['request_id'];p=people[f['player_id']]
  if rid not in raws:
   m=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(rid,)).fetchone()[0]);b=(ROOT/m['raw_file']).read_bytes();assert hashlib.sha256(b).hexdigest()==m['sha256'];raws[rid]=(m,BeautifulSoup(b,'html.parser'));checks['source_sha256']+=1
  m,s=raws[rid];text=s.select(f['selector'])[f['index']].get_text(' ',strip=True);assert text==f['raw_value'];match=re.fullmatch(r'(\d+)\s+(.+?)\s*\((.+)\)',text);assert (int(match[1]),match[2],match[3])==(f['rank'],f['source_player_name'],f['source_club']);checks['independent_raw_rank_name_club']+=1
  pub,version,_=source_dates(sources[rid]);assert (pub,version)==(f['publication_date'],f['version_verified_date']);checks['publication_and_modification_dates']+=1
  lookup={'Vinicius Jr':'Vinícius Júnior'}.get(f['source_player_name'],f['source_player_name']);assert namekey(lookup) in {namekey(n) for n in p['aliases']};allowed={CLUBS.get(t,t) for t in f['source_club'].split('/')};proof=[g for g in games[f['player_id']] if g['team_name'] in allowed and g['game_date']<=version];assert proof,(f['source_player_name'],allowed,sorted({g['team_name'] for g in games[f['player_id']]}));proof=max(proof,key=lambda g:g['game_date']);f['official_identity_proof']=dict(game_id=proof['game_id'],native_person_id=proof['official_player_id'],source_person_id=proof['source_person_id'],request_id=proof['roster_request_id'],team_name=proof['team_name'],game_date=proof['game_date']);checks['official_name_and_prior_club']+=1
 now=dt.datetime.now(dt.UTC).isoformat()
 with db:
  for eid,e in eds.items():
   row=(eid,'EU_GOAL','GOAL','EU soccer','European overall',e['publication_date'],e['version_verified_date'],1,'PUBLIC_ORIGINAL_PUBLISHER_HTML',e['note'],now);old=db.execute('SELECT * FROM ranking_list_versions WHERE list_id=?',(eid,)).fetchone()
   if old:assert old[:-1]==row[:-1]
   else:db.execute('INSERT INTO ranking_list_versions VALUES (?,?,?,?,?,?,?,?,?,?,?)',row)
   db.execute('INSERT OR IGNORE INTO _ranking_edition_audit VALUES (?,?,1)',(eid,json.dumps(e)))
  for f in facts:
   row=(f['list_id'],f['player_id'],f['player_name'],'EU soccer',f['rank'],None,f['source_url'],raws[f['request_id']][0]['raw_file']);old=db.execute('SELECT * FROM player_media_rankings WHERE list_id=? AND player_id=?',row[:2]).fetchone()
   if old:assert old==row
   else:db.execute('INSERT INTO player_media_rankings VALUES (?,?,?,?,?,?,?,?)',row)
   db.execute('INSERT OR IGNORE INTO _ranking_fact_audit VALUES (?,?,?)',(f['list_id'],f['player_id'],json.dumps(f)))
 dates=[d for d, in db.execute('SELECT as_of_date FROM _ranking_snapshot_dates ORDER BY 1')];observations={(f['list_id'],f['player_id']):f for f in facts};snaps=[];flags=[];counts=[]
 for day in dates:
  eligible=[e for e in eds.values() if max(e['publication_date'],e['version_verified_date'])<=day];e=max(eligible,key=lambda e:(e['version_verified_date'],e['publication_date'],e['list_id']),default=None);known=0
  for pid,first_day in first.items():
   if first_day>day:continue
   o=observations.get((e['list_id'],pid)) if e else None;rank=o['rank'] if o else None;age=(dt.date.fromisoformat(day)-dt.date.fromisoformat(e['version_verified_date'])).days if e else None;values={c:None for c in FLAGS}
   for n in [5,10,20,50]:values['goal_top_'+str(n)]=int(rank<=n) if rank is not None else None
   flags.append((day,pid,'EU soccer')+tuple(values[c] for c in FLAGS));snaps.append((day,pid,people[pid]['person_name'],'EU soccer','GOAL',e['publication_date'] if e else None,rank,None,'European overall',age,int(age>=90) if age is not None else None,'OBSERVED' if o else 'NOT_LISTED_ELIGIBILITY_UNKNOWN' if e else 'NO_DATED_LIST_ACQUIRED',o['source_url'] if o else None));known+=rank is not None
  counts.append(dict(date=day,observed_ranks=known,edition=e['list_id'] if e else None))
 tables=['_ranking_quarterly_results','_ranking_flag_results'];before={t:digest(db,t) for t in tables}
 with db:
  for t in tables:db.execute('DELETE FROM '+t+" WHERE league='EU soccer'")
  db.executemany('INSERT INTO _ranking_quarterly_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',snaps);db.executemany('INSERT INTO _ranking_flag_results VALUES ('+','.join('?' for _ in range(3+len(FLAGS)))+')',flags);assert before=={t:digest(db,t) for t in tables};refresh(db)
 out=dict(generated_at_utc=now,status='WORKING',coverage_status='PARTIALLY WORKING',checks=dict(checks),editions=2,independent_publishers=1,required_publishers=10,facts=100,ranked_players=len({f['player_id'] for f in facts}),quarterly_rows=len(snaps),quarterly_coverage=counts,limits=['One original publisher, not ten; nine GOAL voters are not nine independent lists.','Annual editions are carried forward quarterly with source age retained; missing quarterly editions are not fabricated.','Unlisted players remain null; positional, all-time, worldwide and one-domestic-league lists are not mislabeled as combined-Europe overall rankings.','Presently retrieved historical publication pages are not contemporaneous archive captures.']);(ROOT/'reports/eu_goal_rankings_validation.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));db.close()
if __name__=='__main__':main()
