"""Conservative game matching from original official market responses.

Only a resolved two-team game becomes a game row. Ambiguous identities, conflicting
scores, canceled markets and missing start dates are retained in the audit.
"""
import collections,datetime as dt,json,re,sqlite3,shutil
from zoneinfo import ZoneInfo
from history_index import index,records,payload,real_milestones
from probe_history import ROOT
from core import utc,array

ORIGINAL=ROOT  # Earlier raw evidence has been migrated into this one project.
DB=ROOT/'data/result/sentinent_snake.sqlite'
SPORT={'NBA':'Basketball','MLB':'Baseball','NHL':'Hockey'}
SERIES={'NBA':'KXNBAGAME','MLB':'KXMLBGAME','NHL':'KXNHLGAME'}
def clean(s):return re.sub(r'[^a-z0-9]+','',str(s).lower())
def team_name(t,date=None):
 d=t['details'];nick=re.sub(r'^[A-Z]{2,3} ','',d.get('team_name',''));city=d.get('market') or re.sub(r' (WS|[LCIMRYA])$','',t['name'])
 if nick=='Athletics':return ('Oakland Athletics' if date and date<'2025-01-01' else 'Athletics')
 # The source's present-day brand must not be projected onto its first season.
 if d['league']=='NHL' and d.get('abbreviation')=='UTA' and date and date<'2025-05-07':return 'Utah Hockey Club'
 return (city+' '+nick).strip()
def short(t):return t['details'].get('abbreviation')
def main():
 data=index(); recs=list(records());byid={r['request_id']:r for r in recs}; teams=data['teams'];live={}
 for r in recs:
  if r.get('status')==200 and r['endpoint'].endswith('/live_data/batch'):
   for n,x in enumerate(payload(r)['live_datas']):live[x['milestone_id']]=(x,r['request_id'],f'/live_datas/{n}')
 validteams={k:v for k,v in teams.items() if short(v[0]) and v[0]['details'].get('team_name') and short(v[0])!='SPR'}
 aliases=collections.defaultdict(set)
 for tid,(t,_,_) in validteams.items():
  d=t['details'];nick=re.sub(r'^[A-Z]{2,3} ','',d['team_name'])
  for n in [t['name'],d['team_name'],d.get('short_name'),short(t),team_name(t),nick]:
   if n:aliases[d['league'],clean(n)].add(tid)
  if short(t)=='ATH':
   for n in ['Athletics','Oakland Athletics','Oakland',"A's",'OAK']:aliases[d['league'],clean(n)].add(tid)
  if d['league']=='NHL' and short(t)=='UTA':
   for n in ['Utah Hockey Club','Utah HC','Utah']:aliases['NHL',clean(n)].add(tid)
 games={};contracts=[];audit=[];native_games={}
 def reason(provider,uid,why,**kw):audit.append(dict(provider=provider,source_id=uid,reason=why,**kw))
 for mid,m,rid,ptr in real_milestones(data):
  d=m['details'];league=d['league'];li=live.get(mid);f=li[0]['details'] if li else {}
  if f.get('widget_status')!='finished':reason('kalshi',mid,'Game not verified finished');continue
  tids=[d.get('away_team_id'),d.get('home_team_id')]
  if any(t not in validteams for t in tids) or len(set(tids))!=2:reason('kalshi',mid,'Unknown or non-league participants');continue
  ev=next((t for t in m.get('primary_event_tickers',[]) if t.startswith(SERIES[league]+'-')),None)
  if not ev:ev=d.get('main_game_event_ticker')
  if not ev or not ev.startswith(SERIES[league]+'-'):reason('kalshi',mid,'No main moneyline event');continue
  # Game date is encoded by the native event's scheduled-game identifier.
  hit=re.match(r'^[^-]+-(\d{2}[A-Z]{3}\d{2})',ev)
  if not hit:reason('kalshi',mid,'Unrecognized native date');continue
  date=dt.datetime.strptime(hit[1],'%y%b%d').date().isoformat()
  if not '2023-09-13'<=date<='2026-09-13':continue
  score=[f.get('away_points'),f.get('home_points')]
  if any(not isinstance(s,int) for s in score) or score[0]==score[1]:reason('kalshi',mid,'Missing or tied final score');continue
  start=utc(m['start_date']);codes=[short(validteams[t][0]) for t in tids]
  gid=f'{league}_{date.replace("-", "")}_{codes[0]}_{codes[1]}'
  if league=='MLB':gid+='_G'+str(d.get('double_header_game_number') or 1)
  if gid in games:
   old=games[gid]
   if old['start']==start.isoformat() and old['scores']==score:
    native_games[ev]=old;reason('kalshi',mid,'Duplicate milestone, same game/start/score');continue
   # Doubleheaders without an explicit ordinal are resolved below by start order.
   gid+='_'+mid[:8]
  g=dict(game_id=gid,league=league,game_type=SPORT[league],date=date,start=start.isoformat(),start_basis='Scheduled start from Kalshi milestone',
   team_ids=tids,teams=[team_name(validteams[t][0],date) for t in tids],scores=score,home_away='Away;Home',location=None,
   milestone_id=mid,kalshi_event=ev,milestone_request_id=rid,milestone_pointer=ptr,result_request_id=li[1],result_pointer=li[2],
   doubleheader_number=d.get('double_header_game_number'),end=m.get('end_date'),provider_sources=['kalshi'])
  games[gid]=g;native_games[ev]=g
 # Normalize all observed same-day baseball games to a distinct stable ordinal.
 groups=collections.defaultdict(list)
 for g in games.values():
  if g['league']=='MLB':groups[(g['date'],*g['team_ids'])].append(g)
 for group in groups.values():
  if len(group)>1:
   used=set()
   for n,g in enumerate(sorted(group,key=lambda g:g['start']),1):
    ordinal=g['doubleheader_number'] or n
    if ordinal in used:raise ValueError('Conflicting doubleheader ordinal')
    used.add(ordinal);g['game_id']='_'.join(g['game_id'].split('_')[:4])+'_G'+str(ordinal)
 games={g['game_id']:g for g in games.values()}
 for ticker,(m,rid,ptr) in data['kalshi_markets'].items():
  g=native_games.get(m['event_ticker'])
  if not g:continue
  tid=(m.get('custom_strike') or {}).get(g['game_type'].lower()+'_team')
  if tid not in g['team_ids']:reason('kalshi',ticker,'Team contract mapping missing');continue
  side=g['team_ids'].index(tid);win=int(g['scores'][side]>g['scores'][1-side])
  if m.get('result')!=('yes' if win else 'no') or float(m.get('settlement_value_dollars') or -1)!=win:
   reason('kalshi',ticker,'Market settlement disagrees with game final score');continue
  contracts.append(dict(provider='kalshi',game_id=g['game_id'],side=side,contract_id=ticker,market_id=ticker,event_id=m['event_ticker'],
   series=SERIES[g['league']],open=m['open_time'],close=m['close_time'],settled=m.get('settlement_ts'),request_id=rid,pointer=ptr,condition_id=None,outcome=m.get('yes_sub_title')))
 # PM ordering comes from the explicit sports away/home metadata; align to Kalshi
 # using actual team identifiers, then check result and score before accepting.
 matchindex=collections.defaultdict(list)
 for g in games.values():matchindex[g['league'],g['date'],frozenset(g['team_ids'])].append(g)
 pmseen=set();scorechecks=0
 for eid,(e,rid,ptr) in data['polymarket_events'].items():
  tag=str(byid[rid]['parameters'].get('tag_id',''));league={'745':'NBA','100381':'MLB','899':'NHL'}.get(tag)
  if not league:continue
  for mi,m in enumerate(e.get('markets',[])):
   if m.get('sportsMarketType')!='moneyline' or m['id'] in pmseen:continue
   pmseen.add(m['id']);labels=array(m.get('outcomes','[]'));tokens=array(m.get('clobTokenIds','[]'));values=array(m.get('outcomePrices','[]'))
   if len(labels)!=2 or len(tokens)!=2 or len(set(tokens))!=2 or sorted(map(float,values or []))!=[0.,1.]:reason('polymarket',m['id'],'Not a resolved binary team winner');continue
   matches=[aliases[league,clean(label)] for label in labels]
   if any(len(x)!=1 for x in matches):reason('polymarket',m['id'],'Outcome team unknown or ambiguous',outcomes=labels);continue
   tids=[next(iter(x)) for x in matches]
   if tids[0]==tids[1]:reason('polymarket',m['id'],'Two outcomes mapped to same team');continue
   start=utc(m.get('gameStartTime') or e.get('startTime'))
   if start is None:reason('polymarket',m['id'],'No verified game start timestamp');continue
   hit=re.search(r'(\d{4}-\d{2}-\d{2})',m.get('slug',''))
   date=hit[1] if hit else e.get('eventDate')
   if not date:date=start.astimezone(ZoneInfo('America/New_York')).date().isoformat()
   if not '2023-09-13'<=date<='2026-09-13':continue
   candidates=matchindex[league,date,frozenset(tids)]
   if len(candidates)>1:candidates=[g for g in candidates if abs((utc(g['start'])-start).total_seconds())<300]
   if len(candidates)>1:reason('polymarket',m['id'],'Ambiguous doubleheader match');continue
   g=candidates[0] if candidates else None
   # A multi-market daily event's scoreboard does not belong to each child game.
   score=None
   if len([x for x in e['markets'] if x.get('sportsMarketType')=='moneyline'])==1:
    s=re.fullmatch(r'\s*(\d+)\s*[-:]\s*(\d+)\s*',str(e.get('score','')))
    if s:score=list(map(int,s.groups()))
   if g:
    sideorder=[g['team_ids'].index(t) for t in tids]
    if all(v is not None for v in g['scores']) and any(float(values[i])!=int(g['scores'][s]>g['scores'][1-s]) for i,s in enumerate(sideorder)):
     reason('polymarket',m['id'],'Resolution disagrees with matched game');continue
    if score is not None and all(v is not None for v in g['scores']):
     if score!=[g['scores'][s] for s in sideorder]:reason('polymarket',m['id'],'Provider score discrepancy',scores=score,kalshi_scores=g['scores']);continue
     scorechecks+=1
    if abs((utc(g['start'])-start).total_seconds())>3600:reason('polymarket',m['id'],'Start time discrepancy over one hour');continue
   else:
    if score is not None and any(float(values[s])!=int(score[s]>score[1-s]) for s in [0,1]):reason('polymarket',m['id'],'Score and market resolution disagree');continue
    codes=[short(validteams[t][0]) for t in tids];gid=f'{league}_{date.replace("-", "")}_{codes[0]}_{codes[1]}'
    if league=='MLB':
     ordinal=re.search(r'-(?:game)?([12])$',m.get('slug',''))
     gid+='_G'+(ordinal[1] if ordinal else '1')
    if gid in games:reason('polymarket',m['id'],'Conflicting canonical identity');continue
    g=dict(game_id=gid,league=league,game_type=SPORT[league],date=date,start=start.isoformat(),start_basis='Scheduled gameStartTime from Polymarket',
     team_ids=tids,teams=[team_name(validteams[t][0],date) for t in tids],scores=score or [None,None],home_away='Away;Home',location=None,
     milestone_id=None,kalshi_event=None,milestone_request_id=rid,milestone_pointer=ptr+f'/markets/{mi}',result_request_id=rid,result_pointer=ptr,
     doubleheader_number=None,end=e.get('ended'),provider_sources=[])
    games[gid]=g;matchindex[league,date,frozenset(tids)].append(g)
   g['winner']=g['teams'][g['team_ids'].index(tids[values.index('1') if '1' in values else values.index(1)])]
   g['provider_sources']=sorted(set(g['provider_sources']+['polymarket']))
   for token,label,tid in zip(tokens,labels,tids):
    contracts.append(dict(provider='polymarket',game_id=g['game_id'],side=g['team_ids'].index(tid),contract_id=token,market_id=m['id'],event_id=eid,series=None,
     open=m.get('startDate'),close=m.get('closedTime'),settled=m.get('umaEndDate'),request_id=rid,pointer=ptr+f'/markets/{mi}',condition_id=m.get('conditionId'),outcome=label))
 # Prefer a unique market per game/provider; duplicates require review instead of
 # arbitrarily combining a YES contract from one listing with another listing.
 cg=collections.defaultdict(list)
 for c in contracts:cg[c['game_id'],c['provider']].append(c)
 accepted=[]
 for key,cs in cg.items():
  if len(cs)!=2 or {c['side'] for c in cs}!={0,1}:
   reason(key[1],key[0],'Not exactly two unambiguous team outcome contracts',count=len(cs));continue
  accepted.extend(cs)
 good={c['game_id'] for c in accepted};games={k:g for k,g in games.items() if k in good}
 for g in games.values():
  if 'winner' not in g:g['winner']=g['teams'][int(g['scores'][1]>g['scores'][0])]
 DB.parent.mkdir(parents=True,exist_ok=True)
 db=sqlite3.connect(DB)
 for name,items,key in [('_history_games',games.values(),'game_id'),('_history_contracts',accepted,'contract_id'),('_history_teams',[dict(id=k,data=v[0],request_id=v[1],pointer=v[2]) for k,v in validteams.items()],'id'),('_history_players',[dict(id=k,data=v[0],request_id=v[1],pointer=v[2]) for k,v in data['players'].items()],'id')]:
  db.execute(f'CREATE TABLE IF NOT EXISTS {name} (id TEXT PRIMARY KEY, body TEXT NOT NULL)');db.execute(f'DELETE FROM {name}')
  db.executemany(f'INSERT INTO {name} VALUES (?,?)',[(x[key],json.dumps(x)) for x in items])
 db.execute('CREATE TABLE IF NOT EXISTS _history_matching_audit (body TEXT NOT NULL)');db.execute('DELETE FROM _history_matching_audit');db.executemany('INSERT INTO _history_matching_audit VALUES (?)',[(json.dumps(x),) for x in audit]);db.commit();db.close()
 summary=dict(games=len(games),contracts=len(accepted),by_league={league:dict(games=len(gs:=[g for g in games.values() if g['league']==league]),first=min(g['date'] for g in gs),last=max(g['date'] for g in gs)) for league in SPORT},providers=dict(collections.Counter(c['provider'] for c in accepted)),score_comparisons=scorechecks,excluded=dict(collections.Counter(x['reason'] for x in audit)))
 (ROOT/'reports/history_matching.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
