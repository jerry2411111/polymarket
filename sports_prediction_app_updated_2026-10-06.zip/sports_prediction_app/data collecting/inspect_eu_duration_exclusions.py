"""Review real excluded rules and UEFA competition formats before classification."""
import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from epl_price_points import Sources,pointer
db=sqlite3.connect(DB);src=Sources(db);seen=collections.Counter();items=json.loads((ROOT/'reports/eu_market_candidates_validation.json').read_text())['excluded_rule_families']
for i in items:
 cs=[json.loads(b) for b, in db.execute("SELECT body FROM _eu_market_candidates WHERE competition='UCL'") if json.loads(b)['family_id']==i['family_id']];g=json.loads(db.execute('SELECT body FROM _official_uefa_calendar WHERE match_id=?',(cs[0]['official_match_id'],)).fetchone()[0]);m=g['raw'];key=m['type'],m['round']['mode'];seen[key]+=1
 if seen[key]>2:continue
 print('FORMAT',key,'date',g['date'],'phase',m['competitionPhase'],'game',g['away']['name'],g['home']['name'])
 for c in cs:
  if c['market_id'] not in i['markets']:continue
  raw,_=src.get(c['request_id']);v=pointer(raw,c['pointer']);print('RULE',c['event_id'],c['market_id'],v['question'],v['description'])
print('FORMATS',dict(seen));db.close()
