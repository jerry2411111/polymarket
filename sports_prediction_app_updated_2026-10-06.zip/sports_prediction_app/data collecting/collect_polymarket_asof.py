"""Official point-in-time Polymarket reads at requested NBA lookback targets.

This probes the documented as_of operation before scaling. A coarse returned
bucket is accepted only after its whole observation interval has completed.
"""
import argparse,collections,concurrent.futures,datetime as dt,json,sqlite3
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT
from core import utc
from schema import HOURS

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--probe',action='store_true');ap.add_argument('--missing-only',action='store_true');ap.add_argument('--from-date',default='2024-01-01');ap.add_argument('--through-date',default='2026-09-14');args=ap.parse_args()
    db=sqlite3.connect(DB,timeout=60);maps={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_map')};games={i:json.loads(b) for i,b in db.execute('SELECT id,body FROM _nba_canonical_games')};clocks={i:json.loads(b) for i,r,b in db.execute('SELECT game_id,request_id,body FROM _official_nba_clocks')}
    excluded=set()
    for table in ['_nba_contract_choice_audit','_nba_market_family_choices']:
        for (b,) in db.execute('SELECT body FROM '+table):excluded.update(json.loads(b)['excluded_contract_ids'])
    bygame=collections.defaultdict(list)
    for (b,) in db.execute('SELECT body FROM _history_contracts'):
        c=json.loads(b)
        if c['provider']=='polymarket' and c['contract_id'] not in excluded and c['game_id'] in maps:
            gid=maps[c['game_id']]['game_id']
            if args.from_date<=games[gid]['date']<=args.through_date:bygame[gid].append(c)
    ids=sorted(bygame,key=lambda gid:(games[gid]['date'],gid))
    if args.probe:
        chosen=[]
        for year in ['2024','2025','2026']:
            match=next((gid for gid in ids if games[gid]['date'].startswith(year)),None)
            if match:chosen.append(match)
        for year in ['2025','2026']:
            match=next((gid for gid in ids if games[gid]['date'].startswith(year) and 'All-Star' in games[gid]['season']),None)
            if match:chosen.append(match)
        ids=list(dict.fromkeys(chosen))
    missing=set()
    if args.missing_only:
        for (b,) in db.execute("SELECT body FROM _history_selections WHERE json_extract(body,'$.provider')='polymarket' AND json_extract(body,'$.game_id') LIKE 'NBA_%'"):
            a=json.loads(b)
            if a['target'].startswith('pre_') and a['normalized_price'] is None:missing.add((a['game_id'],a['side'],int(a['target'][4:])))
    jobs=[]
    for gid in ids:
        clock=next((clocks[s] for s in games[gid]['source_game_ids'] if s in clocks),None)
        start=int(utc(clock['official_start_utc'] if clock else games[gid]['start']).timestamp())
        for c in bygame[gid]:
            for hour in ([HOURS[0],HOURS[1],HOURS[-1]] if args.probe else HOURS):
                side=maps[c['game_id']]['source_to_canonical'][c['side']]
                if args.missing_only and (gid,side,hour) not in missing:continue
                target=start-3600*hour-(1 if hour==0 else 0)
                # A market cannot have a valid observation before it existed.
                if c.get('open') and int(utc(c['open']).timestamp())>target:continue
                jobs.append((gid,c,hour,target))
    client=HistoryClient();db.execute('CREATE TABLE IF NOT EXISTS _nba_polymarket_asof (job_key TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();counts=collections.Counter();resolutions=collections.Counter();examples=[]
    def fetch(job):
        gid,c,h,target=job;ids0=[];ask=target
        try:
            for _ in range(3):
                data,r=client.get('https://data-api.polymarket.com/v2/prices-history',dict(token_id=c['contract_id'],as_of=ask));ids0.append(r['request_id'])
                if data.get('pagination',{}).get('next_cursor') or len(data['data'])>1:raise ValueError('Unexpected multi-point as_of response')
                x=data['data'][0] if data['data'] else None
                if x is None:break
                if x['timestamp']>ask or not 0<=x['price']<=1:raise ValueError('Wrong as-of time or probability scale')
                if x['timestamp']+x['resolution_seconds']<=target:break
                ask=x['timestamp']-1
            else:raise ValueError('No causally safe aggregate after bounded fallback')
            return dict(game_id=gid,contract_id=c['contract_id'],hour=h,target_utc=utc(target).isoformat(),status='ok',request_ids=ids0,point=x,observation_fully_before_target=x is not None)
        except Exception as e:return dict(game_id=gid,contract_id=c['contract_id'],hour=h,target_utc=utc(target).isoformat(),status='error',request_ids=ids0,error=str(e))
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        for n,r in enumerate(pool.map(fetch,jobs),1):
            key=f'{r["contract_id"]}:{r["target_utc"]}';db.execute('INSERT OR REPLACE INTO _nba_polymarket_asof VALUES (?,?)',(key,json.dumps(r)));db.commit();counts[r['status']]+=1
            if r.get('point'):resolutions[r['point']['resolution_seconds']]+=1
            if args.probe:examples.append(r)
            if n%500==0 or n==len(jobs):print('NBA POLYMARKET AS-OF',n,len(jobs),'status',dict(counts),'resolutions',dict(resolutions),flush=True)
    db.close();report=dict(probe=args.probe,missing_only=args.missing_only,from_date=args.from_date,through_date=args.through_date,games_with_requested_targets=len({j[0] for j in jobs}),targets_requested=len(jobs),new_requests=client.requests,status=dict(counts),resolutions=dict(resolutions),examples=examples)
    (ROOT/('reports/nba_polymarket_asof_probe.json' if args.probe else 'reports/nba_polymarket_asof_acquisition.json')).write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='examples'}))

if __name__=='__main__':main()
