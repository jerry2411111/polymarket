"""Official public MLB schedule/feed adapter, validated against MLB reports.

The current public Baseball Savant client supplies the schedule request syntax.
The official schedule returns each game's feed link. Partner documentation is
Okta-gated; no authentication or access-control bypass is used. Source URLs and
the exact public client asset are recorded in reports and README.
"""
import datetime as dt,json
from zoneinfo import ZoneInfo
from core import utc

BASE='https://statsapi.mlb.com'
KINDS={'R':'Regular Season','S':'Spring Training','E':'Exhibition','A':'All-Star','F':'Wild Card','D':'Division Series','L':'League Championship Series','W':'World Series'}

def schedule(client,date):
    d,r=client.get(BASE+'/api/v1/schedule',dict(sportId=1,date=date,hydrate='team,probablePitcher,ruleSettings'))
    assert isinstance(d.get('dates'),list) and sum(len(x['games']) for x in d['dates'])==d['totalGames'],'Schedule pagination/count mismatch'
    out=[]
    for di,day in enumerate(d['dates']):
        assert day['date']==date,'Schedule returned a different requested date'
        for gi,g in enumerate(day['games']):
            if g['status']['abstractGameState']!='Final':continue
            if g['status'].get('detailedState') in ['Postponed','Cancelled']:continue
            teams=[g['teams'][side] for side in ['away','home']]
            assert all(isinstance(t.get('score'),int) for t in teams),'Missing official score'
            assert g['link'].startswith('/api/') and str(g['gamePk']) in g['link']
            out.append(dict(official_game_id=str(g['gamePk']),official_date=g['officialDate'],requested_date=date,scheduled_start_utc=g['gameDate'],game_type_code=g['gameType'],competition_type=g.get('seriesDescription') or KINDS.get(g['gameType']),season_year=g['season'],teams=[t['team']['name'] for t in teams],official_team_ids=[str(t['team']['id']) for t in teams],team_codes=[t['team'].get('abbreviation') for t in teams],scores=[t['score'] for t in teams],winner_flags=[t.get('isWinner') for t in teams],game_number=g.get('gameNumber'),double_header=g.get('doubleHeader'),reverse_home_away=g.get('reverseHomeAwayStatus'),venue=g.get('venue'),feed_link=g['link'],request_id=r['request_id'],pointer=f'/dates/{di}/games/{gi}',source_url=BASE+'/api/v1/schedule',status=g['status'],raw_game=g))
    assert len({g['official_game_id'] for g in out})==len(out),'Duplicate official game ID on one date'
    return out,r

def parse_feed(d,r,s):
    native=s['official_game_id'];assert str(d['gamePk'])==native
    g=d['gameData'];live=d['liveData'];box=live['boxscore'];line=live['linescore'];plays=live['plays']['allPlays']
    assert g['status']['abstractGameState']=='Final'
    ids=[str(g['teams'][side]['id']) for side in ['away','home']];scores=[line['teams'][side]['runs'] for side in ['away','home']]
    assert ids==s['official_team_ids'] and scores==s['scores'],'Official schedule/feed score or team mismatch'
    innings={x['num']:x for x in line['innings']};break_scores=[[0,0]]
    for n in [3,5,7]:
        # Do not count a missing bottom inning as a recorded zero.
        vals=[]
        for side in ['away','home']:
            cells=[innings.get(i,{}).get(side,{}).get('runs') for i in range(1,n+1)]
            vals.append(sum(cells) if all(v is not None for v in cells) else None)
        break_scores.append(vals)
    pitches=[e for p in plays for e in p.get('playEvents',[]) if e.get('isPitch') and e.get('startTime')]
    first=min((utc(e['startTime']) for e in pitches),default=None)
    last_play=max((utc(p['about']['endTime']) for p in plays if p['about'].get('endTime')),default=None)
    zone=g['venue'].get('timeZone',{}).get('id')
    completion_date=last_play.astimezone(ZoneInfo(zone)).date().isoformat() if last_play and zone else None
    first_date=first.astimezone(ZoneInfo(zone)).date().isoformat() if first and zone else None
    breaks=[]
    for n in [3,5,7]:
        before=[p for p in plays if p['about'].get('inning')==n and p['about'].get('halfInning')=='bottom' and p['about'].get('isComplete')]
        after=[p for p in plays if p['about'].get('inning')==n+1 and p['about'].get('halfInning')=='top']
        lo=max((utc(p['about']['endTime']) for p in before if p['about'].get('endTime')),default=None)
        hi=min((utc(e['startTime']) for p in after for e in p.get('playEvents',[]) if e.get('isPitch') and e.get('startTime')),default=None)
        # A completed half inning needs an actual third out. Suspension and
        # clock anomalies are retained as missing intervals, not nominal times.
        last=before[-1] if before else None;third=last and last.get('count',{}).get('outs')==3
        valid=bool(lo and hi and lo<hi and third)
        breaks.append(dict(checkpoint='Inning'+str(n),start_utc=lo.isoformat() if valid else None,end_utc=hi.isoformat() if valid else None,source_play_index=last['about']['atBatIndex'] if last else None,reason=None if valid else 'No consistent completed-inning/next-pitch boundary'))
    players=[]
    for side in ['away','home']:
        b=box['teams'][side]
        for key,p in b['players'].items():
            stat=p.get('stats',{});bat=stat.get('batting',{});pit=stat.get('pitching',{});field=stat.get('fielding',{})
            played=any(x.get('gamesPlayed',0)>0 for x in [bat,pit])
            starter=any(x.get('gamesStarted',0)>0 for x in [bat,pit,field]) if played else None
            players.append(dict(player_id='MLB:'+str(p['person']['id']),official_player_id=str(p['person']['id']),player_name=p['person']['fullName'],official_game_id=native,side=0 if side=='away' else 1,team_name=g['teams'][side]['name'],official_team_id=str(g['teams'][side]['id']),did_play=played,score=bat.get('runs') if played else None,assists=field.get('assists') if played else None,minutes=None,starter=int(starter) if starter is not None else None,injury_status=p.get('status'),request_id=r['request_id'],pointer=f'/liveData/boxscore/teams/{side}/players/{key}',biography=g.get('players',{}).get('ID'+str(p['person']['id'])),biography_warning='Hydrated biography can be current; use birthDate for historical age and boxscore team for game-date membership. No currentAge or current team backfill.'))
        if sum(p['score'] for p in players if p['side']==(0 if side=='away' else 1) and p['score'] is not None)!=line['teams'][side]['runs']:raise ValueError('Player runs do not sum to official team score')
    return dict(official_game_id=native,official_date=g['datetime'].get('officialDate'),scheduled_start_utc=g['datetime']['dateTime'],actual_first_pitch_utc=first.isoformat() if first else None,last_play_utc=last_play.isoformat() if last_play else None,first_pitch_local_date=first_date,completion_local_date=completion_date,spans_multiple_local_dates=bool(first_date and completion_date and first_date!=completion_date),teams=[g['teams'][x]['name'] for x in ['away','home']],official_team_ids=ids,scores=scores,break_scores=break_scores,breaks=breaks,venue=g['venue'],game_info=g.get('gameInfo'),weather=g.get('weather'),game=g['game'],players=players,official_report=g.get('officialScorer'),request_id=r['request_id'],schedule_request_id=s['request_id'],source_url=r['endpoint'])

def feed(client,s):
    d,r=client.get(BASE+s['feed_link']);return parse_feed(d,r,s)
