"""Official current club pages used solely to identify explicitly named venues."""
import concurrent.futures,datetime as dt,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from history_client import HistoryClient
from official_redirects import get
from probe_history import ROOT,HOSTS
db=sqlite3.connect(DB,timeout=60);clubs={}
for b, in db.execute('SELECT body FROM _official_laliga_calendar'):
 g=json.loads(b)
 for side in ['away','home']:
  t=g['raw'][side+'_team'];clubs[str(t['id'])]=dict(team_id=str(t['id']),slug=t['slug'],name=t['name'])
c=HistoryClient();HOSTS.add('www.laliga.com');rows=[]
def fetch(t):
 row=dict(t);url='https://www.laliga.com/en-GB/clubs/'+t['slug']
 try:
  raw,r,redirects=get(c,url);soup=BeautifulSoup(raw,'html.parser');script=soup.find('script',id='__NEXT_DATA__');d=json.loads(script.get_text())['props']['pageProps'];club=d['club'];assert str(club.get('id') or club['team']['id'])==t['team_id'];faqs=[]
  for s in soup.find_all('script',type='application/ld+json'):
   x=json.loads(s.get_text());xs=x if isinstance(x,list) else [x]
   for x in xs:
    if x.get('@type')=='FAQPage':faqs.extend(x.get('mainEntity',[]))
  row.update(status='ok',url=url,request_id=r['request_id'],redirects=redirects,club=club,faqs=faqs)
 except Exception as e:row.update(status='unavailable',url=url,error=type(e).__name__+': '+str(e))
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for row in pool.map(fetch,clubs.values()):rows.append(row);print('LALIGA VENUE',row['name'],row['status'],flush=True)
with db:
 db.execute('CREATE TABLE IF NOT EXISTS _official_laliga_club_location_sources (team_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.executemany('INSERT OR REPLACE INTO _official_laliga_club_location_sources VALUES (?,?)',[(r['team_id'],json.dumps(r)) for r in rows])
report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),requested=len(rows),ok=sum(r['status']=='ok' for r in rows),new_requests=c.requests,scope='Current official club-page venue descriptions only. Historical games are linked by the actual dated venue name, never assumed to use the current home stadium.',errors=[r for r in rows if r['status']!='ok']);(ROOT/'reports/laliga_club_location_sources.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));db.close()
