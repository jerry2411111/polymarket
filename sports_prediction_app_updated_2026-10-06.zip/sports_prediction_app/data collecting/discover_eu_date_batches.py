"""Collect six competitions' event metadata by month, keeping old and current native tags."""
import argparse,calendar,datetime as dt,json,sqlite3
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT

COMPETITIONS={'EPL':dict(name='Premier League',tags=[82,306],series='KXEPLGAME'),'LAL':dict(name='La Liga',tags=[780],series='KXLALIGAGAME'),'BUN':dict(name='Bundesliga',tags=[1494],series='KXBUNDESLIGAGAME'),'SEA':dict(name='Serie A',tags=[100618,101962],series='KXSERIEAGAME'),'FL1':dict(name='Ligue 1',tags=[102070],series='KXLIGUE1GAME'),'UCL':dict(name='UEFA Champions League',tags=[1234,100977],series='KXUCLGAME')}
DOC='https://docs.polymarket.com/api-reference/events/list-events-keyset-pagination.md'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--through-percent',type=int,default=100);a=ap.parse_args();assert 1<=a.through_percent<=100;client=HistoryClient();b,dr=client.get(DOC,document=True);assert all(v in b for v in [b'after_cursor',b'end_date_min',b'end_date_max']);db=sqlite3.connect(DB,timeout=60)
    db.execute('CREATE TABLE IF NOT EXISTS _eu_pm_event_sources (competition TEXT,event_id TEXT,request_id TEXT,pointer TEXT,body TEXT NOT NULL,PRIMARY KEY(competition,event_id,request_id)) STRICT');db.execute('CREATE TABLE IF NOT EXISTS _eu_pm_discovery_partitions (competition TEXT,month TEXT,body TEXT NOT NULL,PRIMARY KEY(competition,month)) STRICT');db.commit();jobs=[];day=dt.date(2024,1,1);end=dt.date(2026,9,15)
    while day<end:
        hi=min(day.replace(day=calendar.monthrange(day.year,day.month)[1])+dt.timedelta(days=1),end)
        for comp,config in COMPETITIONS.items():jobs.append((comp,config,day,hi))
        day=hi
    assert len(jobs)==198;done=0
    for comp,config,day,hi in jobs:
        month=day.strftime('%Y-%m');prior=db.execute('SELECT body FROM _eu_pm_discovery_partitions WHERE competition=? AND month=?',(comp,month)).fetchone()
        if prior and json.loads(prior[0])['pagination_exhausted']:done+=1;continue
        if done*100>=a.through_percent*len(jobs):break
        ids=set();sources=[];error=None;tag_results=[]
        try:
            for tag in config['tags']:
                params=dict(tag_id=tag,end_date_min=day.isoformat()+'T00:00:00Z',end_date_max=hi.isoformat()+'T00:00:00Z',order='id',ascending='true',limit=500);seen=set();cursors=set();requests=[]
                for _ in range(100):
                    data,r=client.get('https://gamma-api.polymarket.com/events/keyset',params);requests.append(r['request_id']);assert isinstance(data['events'],list)
                    for i,e in enumerate(data['events']):
                        eid=str(e['id']);assert eid not in seen,'Repeated event ID across pages';seen.add(eid);end_date=(e.get('endDate') or '')[:10];assert day.isoformat()<=end_date<=hi.isoformat(),'Ignored date filter'
                        assert str(tag) in {str(t['id']) for t in e.get('tags',[])},'Ignored competition tag filter'
                        if end_date==hi.isoformat():continue # API upper bound is inclusive; our date partitions are half-open.
                        ids.add(eid);sources.append((comp,eid,r['request_id'],'/events/'+str(i),json.dumps(e)))
                    cursor=data.get('next_cursor')
                    if not cursor:break
                    assert cursor not in cursors,'Repeated pagination cursor';cursors.add(cursor);params['after_cursor']=cursor
                else:raise ValueError('Pagination safety bound reached')
                tag_results.append(dict(tag_id=tag,source_events=len(seen),request_ids=requests,pagination_exhausted=True))
        except Exception as e:error=str(e)
        result=dict(competition=comp,name=config['name'],month=month,from_date=day.isoformat(),through_date=(hi-dt.timedelta(days=1)).isoformat(),events=len(ids),event_ids=sorted(ids),pagination_exhausted=error is None,error=error,tags=tag_results)
        with db:db.executemany('INSERT OR IGNORE INTO _eu_pm_event_sources VALUES (?,?,?,?,?)',sources);db.execute('INSERT OR REPLACE INTO _eu_pm_discovery_partitions VALUES (?,?,?)',(comp,month,json.dumps(result)))
        done+=error is None;print('EU SOCCER DATE DISCOVERY',month,comp,len(ids),'events',error or 'exhausted',done,'/',len(jobs),flush=True)
        write_report(db,dr,client.requests)
        if error:break
    write_report(db,dr,client.requests);db.close()

def write_report(db,dr,requests):
    rows=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_pm_discovery_partitions ORDER BY month,competition')];n=sum(r['pagination_exhausted'] for r in rows);out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='Polymarket EU soccer metadata discovery, not verified game/odds coverage',completed_partitions=n,total_partitions=198,percent=round(n*100/198,2),documentation_url=DOC,documentation_request_id=dr['request_id'],new_requests_this_run=requests,distinct_competition_events=db.execute('SELECT count(*) FROM (SELECT DISTINCT competition,event_id FROM _eu_pm_event_sources)').fetchone()[0],partitions=rows)
    (ROOT/'reports/eu_soccer_date_discovery.json').write_text(json.dumps(out,indent=2),encoding='utf-8')

if __name__=='__main__':main()
