"""Acquire native NHL game/player data and API-missing official clock reports.

Only completed games with matched provider contracts are requested. Full raw
responses precede parsing, and the monthly collector resumes verified games.
"""
import argparse,collections,concurrent.futures,datetime as dt,json,re,sqlite3
from bs4 import BeautifulSoup
from official_html import decode_html
from build_history_catalog import DB
from build_nhl_market_candidates import clean
from history_client import HistoryClient
from probe_history import ROOT
from collect_official_results import nhl_summary
from build_official_game_facts import nhl_period_scores
from nhl_official import full_team_name,minutes,period_clocks,report_clock_utc

def collect(c,g,s):
 native=g['official_game_id'];sources={};data={};issues=[]
 for kind in ['boxscore','landing','play-by-play','right-rail']:
  d,r=c.get('https://api-web.nhle.com/v1/gamecenter/'+native+'/'+kind);data[kind]=d;sources[kind]=r['request_id']
  if kind!='right-rail':
   assert str(d['id'])==native and [str(d[k]['id']) for k in ['awayTeam','homeTeam']]==g['team_ids']
   assert [d[k]['score'] for k in ['awayTeam','homeTeam']]==g['scores']
 box=data['boxscore'];landing=data['landing'];pbp=data['play-by-play'];rail=data['right-rail'];assert box['gameState'] in ['OFF','FINAL']
 report=None;break_scores=[[0,0],[None,None],[None,None]];actual=None;clocks=[];starters=None;summary_body=None
 for kind in ['GS','PL']:
  url=f'https://www.nhl.com/scores/htmlreports/{s["season"]}/{kind}{native[4:]}.HTM'
  try:
   b,r=c.get(url,document=True);sources[kind]=r['request_id'];soup=BeautifulSoup(decode_html(b),'html.parser')
   if kind=='GS':
    report=nhl_summary(soup,s['season'],native[4:],r['request_id']);assert report and report['scores']==g['scores'] and report['date']==g['date']
    assert [clean(n) for n in report['teams']]==[clean(n) for n in g['teams']]
    break_scores=nhl_period_scores(soup,g['scores']);actual=report_clock_utc(report['start_clock'],report['start_zone'],s['scheduled_start_utc'],g['venue_timezone']);summary_body=b
   else:
    independent=nhl_summary(soup,s['season'],native[4:],r['request_id']);assert independent and independent['scores']==g['scores'] and independent['date']==g['date']
    assert [clean(n) for n in independent['teams']]==[clean(n) for n in g['teams']]
    clocks,starters=period_clocks(soup,s['scheduled_start_utc'],g['venue_timezone'])
  except Exception as e:issues.append(dict(component=kind,error=type(e).__name__+': '+str(e)))
 # Every API period summary explicitly enumerates the goals, including an
 # empty list in a scoreless period. Never assume an absent period is zero.
 summary={x['periodDescriptor']['number']:x for x in landing.get('summary',{}).get('scoring',[]) if x['periodDescriptor']['periodType']=='REG'}
 running=[0,0];api_break_scores=[[0,0]];complete=True
 for p in [1,2]:
  if p not in summary:api_break_scores.append([None,None]);complete=False;continue
  for goal in summary[p].get('goals',[]):
   code=goal['teamAbbrev']['default'];side=[box[k]['abbrev'] for k in ['awayTeam','homeTeam']].index(code);running[side]+=1
  api_break_scores.append(list(running) if complete else [None,None])
 if summary_body:
  assert all(a==b for a,b in zip(api_break_scores,break_scores) if None not in a),'Official API and scorer report period scores disagree'
 else:break_scores=api_break_scores
 first=[x for x in clocks if x['period']==1 and x['event']=='PSTR' and x['timestamp_utc']]
 if len(first)==1:
  if actual:assert actual==first[0]['timestamp_utc'],'Official GS and PL opening times disagree'
  actual=first[0]['timestamp_utc']
 boundaries=[]
 for p in [1,2]:
  end_events=[x for x in clocks if x['period']==p and x['event']=='PEND'];start_events=[x for x in clocks if x['period']==p+1 and x['event']=='PSTR']
  # Repeated period-start records can have distinct event numbers but the
  # same clock. Only identical boundary times may collapse; disagreements
  # remain ambiguous, and all original clock events remain in the audit.
  ends=list({x['timestamp_utc']:x for x in end_events}.values());starts=list({x['timestamp_utc']:x for x in start_events}.values());lo=hi=None
  if len(ends)==len(starts)==1 and ends[0]['timestamp_utc'] and starts[0]['timestamp_utc']:
   left=dt.datetime.fromisoformat(ends[0]['timestamp_utc']);right=dt.datetime.fromisoformat(starts[0]['timestamp_utc'])
   # Reports resolve time only to a minute. Exclude the uncertain ending
   # minute and stop at the earliest possible restart, with no guessed clock.
   if 60<(right-left).total_seconds()<=7200:lo=(left+dt.timedelta(seconds=60)).isoformat();hi=right.isoformat()
  boundaries.append(dict(period=p,start_utc=lo,end_utc=hi,reported_end_utc=ends[0]['timestamp_utc'] if len(ends)==1 else None,reported_next_start_utc=starts[0]['timestamp_utc'] if len(starts)==1 else None,request_id=sources.get('PL'),precision_seconds=60,end_html_rows=[e['html_row'] for e in end_events],restart_html_rows=[e['html_row'] for e in start_events]))
 roster={str(x['playerId']):x for x in pbp.get('rosterSpots',[])};players=[];seen=set()
 for side,key in enumerate(['awayTeam','homeTeam']):
  for group,items in box.get('playerByGameStats',{}).get(key,{}).items():
   for n,p in enumerate(items):
    pid=str(p['playerId']);r=roster.get(pid);assert pid not in seen;seen.add(pid)
    if r:assert str(r['teamId'])==g['team_ids'][side]
    name=' '.join(r[k]['default'] for k in ['firstName','lastName']) if r else None
    time=minutes(p.get('toi'));played=time>0 if time is not None else None
    start=p.get('starter') if group=='goalies' else (int(p['sweaterNumber']) in starters[side] if starters else None)
    row=dict(official_player_id=pid,player_name=name,official_team_id=g['team_ids'][side],team_name=g['teams'][side],side=side,position=p.get('position'),played=played,score=p.get('goals'),assists=p.get('assists'),minutes=time,starter=start,raw_toi=p.get('toi'),request_id=sources['boxscore'],pointer=f'/playerByGameStats/{key}/{group}/{n}',name_request_id=sources['play-by-play'] if r else None,starter_request_id=sources['boxscore'] if group=='goalies' else sources.get('PL') if starters else None,raw=p)
    players.append(row)
  for n,p in enumerate(rail.get('gameInfo',{}).get(key,{}).get('scratches',[])):
   pid=str(p['id'])
   if pid in seen:issues.append(dict(component='roster',error='Player both boxscore and scratch',official_player_id=pid));continue
   seen.add(pid);players.append(dict(official_player_id=pid,player_name=' '.join(p[k]['default'] for k in ['firstName','lastName']),official_team_id=g['team_ids'][side],team_name=g['teams'][side],side=side,position=None,played=False,score=None,assists=None,minutes=None,starter=False,request_id=sources['right-rail'],pointer=f'/gameInfo/{key}/scratches/{n}',raw=p))
 return dict(official_game_id=native,game_id=g['game_id'],date=g['date'],official_team_ids=g['team_ids'],teams=g['teams'],scores=g['scores'],winner=g['winner'],break_scores=break_scores,api_break_scores=api_break_scores,actual_start_utc=actual,scheduled_start_utc=s['scheduled_start_utc'],start_precision_seconds=60 if actual else None,breaks=boundaries,period_clock_events=clocks,players=players,coaches=[rail.get('gameInfo',{}).get(k,{}).get('headCoach',{}).get('default') for k in ['awayTeam','homeTeam']],request_ids=sources,issues=issues,status='WORKING' if not issues else 'PARTIALLY WORKING',api_identity_score_validated=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--limit',type=int);ap.add_argument('--through-month');ap.add_argument('--retry-partial',action='store_true');ap.add_argument('--game-id',action='append');a=ap.parse_args();db=sqlite3.connect(DB,timeout=60)
 games=[json.loads(b) for b, in db.execute('SELECT body FROM _nhl_canonical_games')];schedule={i:json.loads(b) for i,b in db.execute('SELECT * FROM _official_nhl_schedule')}
 db.execute('CREATE TABLE IF NOT EXISTS _official_nhl_game_reports (official_game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit();done={i for i,b in db.execute('SELECT * FROM _official_nhl_game_reports') if json.loads(b).get('api_identity_score_validated')};wanted={g['official_game_id'] for g in games};completed=len(done & wanted);total=len(wanted);todo=sorted([g for g in games if g['official_game_id'] not in done],key=lambda g:(g['date'],g['game_id']));todo=todo[:a.limit] if a.limit else todo
 if a.retry_partial:
  partial={i for i,b in db.execute('SELECT * FROM _official_nhl_game_reports') if json.loads(b).get('status')!='WORKING'}
  todo=sorted([g for g in games if g['official_game_id'] in partial or g['official_game_id'] not in done],key=lambda g:(g['date'],g['game_id']))
 if a.through_month:todo=[g for g in todo if g['date'][:7]<=a.through_month]
 if a.game_id:todo=[g for g in games if g['official_game_id'] in a.game_id]
 if a.limit:todo=todo[:a.limit]
 c=HistoryClient();lastmilestone=completed*10//total;errors=[];count=0;current_month=None;path=ROOT/'reports'/('nhl_game_report_acquisition'+('_through_'+a.through_month if a.through_month else '')+'.json')
 def fetch(g):
  try:return g,collect(c,g,schedule[g['official_game_id']]),None
  except Exception as e:return g,None,dict(game_id=g['game_id'],official_game_id=g['official_game_id'],error=type(e).__name__+': '+str(e))
 def report():
  rows=[json.loads(b) for i,b in db.execute('SELECT * FROM _official_nhl_game_reports') if i in wanted]
  out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),phase='NHL official game reports and player game facts',total_games=total,completed_games=len(rows),percentage=round(len(rows)*100/total,2),new_requests=c.requests,errors=errors,official_break_intervals=sum(bool(b['start_utc']) for r in rows for b in r['breaks']),possible_break_intervals=2*len(rows),player_rows=sum(len(r['players']) for r in rows),source_issues=dict(collections.Counter(x['component']+': '+x['error'] for r in rows for x in r['issues'])))
  path.write_text(json.dumps(out,indent=2),encoding='utf-8');return out
 # Each batch contains a single calendar month, and each returned game is
 # committed independently. No long writer lock can block another collector.
 by_month=collections.defaultdict(list)
 for g in todo:by_month[g['date'][:7]].append(g)
 for month,items in sorted(by_month.items()):
  with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
   for g,row,error in pool.map(fetch,items):
    if error:errors.append(error)
    else:
     db.execute('INSERT OR REPLACE INTO _official_nhl_game_reports VALUES (?,?)',(row['official_game_id'],json.dumps(row)));db.commit()
     if row['official_game_id'] not in done:completed+=1;done.add(row['official_game_id'])
    count+=1
    if count%50==0:print('NHL OFFICIAL REPORTS',month,completed,'/',total,'errors',len(errors),flush=True);report()
    while completed*10//total>lastmilestone:lastmilestone+=1;print('NHL OFFICIAL REPORTS',str(lastmilestone*10)+'%',completed,'/',total,flush=True);report()
  print('NHL OFFICIAL REPORT MONTH',month,len(items),'attempted',flush=True);report()
 print(json.dumps(report()),flush=True);db.close()

if __name__=='__main__':main()
