import json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
for b, in db.execute('SELECT body FROM _nba_ranking_sources'):
    s=json.loads(b)
    if s['publisher'] not in ['tnt_inside_nba'] or s['status']!='ACQUIRED_NOT_VALIDATED':continue
    r=json.loads(db.execute('SELECT metadata_json FROM _request_audit WHERE request_id=?',(s['request_id'],)).fetchone()[0]);html=BeautifulSoup((ROOT/r['raw_file']).read_bytes(),'html.parser')
    print('SOURCE',s['url']);print('DATES',[(d.get('@type'),d.get('datePublished'),d.get('dateModified')) for d in s['metadata']['structured'] if isinstance(d,dict)])
    heads=[h.get_text(' ',strip=True) for h in html.select('h1,h2,h3,h4')]
    if s['publisher']=='bleacher_report':print('UNMATCHED HEADINGS',[h for h in heads if re.search(r'\b(1[0-9]|2[0-9]|3[0-9]|4[0-9])\b',h) and not re.match(r'^\d+\. ',h)])
    else:
        print('HEADERS',heads[:12]);print('TABLES',[(t.get('class'),len(t.select('tr')),t.get_text(' ',strip=True)[:300]) for t in html.find_all('table')][:5])
        print('SCRIPTS',[(x.get('id'),x.get('type'),len(x.string or x.get_text())) for x in html.find_all('script') if 'Jokic' in (x.string or x.get_text())][:5]);print('DATE TEXT',re.findall(r'.{0,60}(?:Updated|updated|Last Update|September|August).{0,100}',html.get_text(' ',strip=True))[:8])
db.close()
