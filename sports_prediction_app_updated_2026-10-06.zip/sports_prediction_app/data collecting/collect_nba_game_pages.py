"""Official NBA game pages fill missing identity, venue and neutral-site facts.

Only NBA's own structured page data are consumed. Raw HTML is retained before
normalization; third-party odds widgets and news story prose are not used.
"""
import argparse,collections,concurrent.futures,datetime as dt,json,re,sqlite3
from bs4 import BeautifulSoup
from build_history_catalog import DB
from probe_history import ROOT
from history_client import HistoryClient
from core import utc

RECOVERY_SLUGS=['tor-vs-cle-0042500132','atl-vs-nyk-0042500122','min-vs-den-0042500162']

def duration_minutes(value):
    if value is None:return None
    if isinstance(value,(int,float)) and not isinstance(value,bool):return float(value)
    if re.fullmatch(r'\d+:\d{2}',str(value)):
        mm,ss=map(int,value.split(':'));return mm+ss/60
    match=re.fullmatch(r'PT(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?',str(value))
    if match and any(x is not None for x in match.groups()):
        hours,mins,secs=[float(x) if x is not None else 0 for x in match.groups()];return hours*60+mins+secs/60
    return None

def parse(body,rid,url,known=None):
    script=re.search(rb'<script\b[^>]*\bid="__NEXT_DATA__"[^>]*>(.*?)</script>',body,re.S)
    if script is None:raise ValueError('Official structured game page absent')
    p=json.loads(script[1])['props']['pageProps'];g=p['game'];a=p['analyticsObject']
    if g['gameStatus']!=3:raise ValueError('Official game page is not final')
    date=dt.datetime.strptime(g['gameCode'].split('/')[0],'%Y%m%d').date().isoformat();teams=[g['awayTeam'],g['homeTeam']];scores=[int(t['score']) for t in teams]
    if scores[0]==scores[1]:raise ValueError('Tied NBA final')
    kind=known.get('competition_type') if known else None
    kind=kind or {'All Star':'All-Star'}.get(a['seasonType'],a['seasonType']);year=known.get('season_year') if known else None
    if not year:
        y=int(a['season']);year=str(y) if kind=='Summer League' else f'{y}-{(y+1)%100:02d}'
    periods=[{int(q['period']):int(q['score']) for q in t['periods']} for t in teams]
    short_format=kind=='All-Star' and all(len(q)<4 for q in periods)
    if [sum(q.values()) for q in periods]!=scores and not short_format:raise ValueError('Official game page period scores disagree with final')
    cp=[[0,0]]+[[sum(q[n] for n in range(1,i+1)) if all(n in q for n in range(1,i+1)) else None for q in periods] for i in [1,2,3]]
    if short_format:cp=[[0,0]]+[[None,None] for _ in range(3)]
    names=[(t['teamCity']+' '+t['teamName']).strip() for t in teams];arena=g.get('arena') or {};neutral=g.get('isNeutral')
    row=dict(league='NBA',season_year=year,date=date,official_game_id=g['gameId'],official_team_ids=[str(t['teamId']) for t in teams],team_tricodes=[t['teamTricode'] for t in teams],team_names=[t['teamName'] for t in teams],full_team_names=names,scores=scores,break_scores=cp,start_utc=g['gameTimeUTC'],competition_type=kind,is_training=any(w in kind.lower() for w in ['preseason','summer','exhibition']),source_url=url,request_id=rid,source_kind='official_game_page',location=', '.join(str(arena[k]) for k in ['arenaName','arenaCity','arenaState'] if arena.get(k)),city=arena.get('arenaCity'),is_neutral=neutral,home_away='Away;Away' if neutral is True else 'Away;Home' if neutral is False else None)
    players=[];minute_checks=[]
    for side,t in enumerate(teams):
        ps=t.get('players') or [];points=[];minutes=[]
        for i,pl in enumerate(ps):
            st=pl.get('statistics') or {};mt=st.get('minutes');mins=duration_minutes(mt)
            name=(pl['firstName']+' '+pl['familyName']).strip();pts=st.get('points');ast=st.get('assists');comment=pl.get('comment')
            did_play=str(pl['played'])=='1' if pl.get('played') is not None else bool(mins is not None and mins>0)
            starter=int(str(pl['starter'])=='1') if pl.get('starter') is not None else int(bool(pl.get('position')))
            players.append(dict(official_game_id=g['gameId'],official_player_id=str(pl['personId']),player_name=name,game_date=date,team_name=names[side],side=side,score=pts,assists=ast,minutes=mins,raw_minutes=mt,starter=starter if did_play else None,did_play=did_play,active_roster=pl.get('status')!='INACTIVE',comment=comment,request_id=rid,pointer=f'/props/pageProps/game/{"awayTeam" if side==0 else "homeTeam"}/players/{i}'))
            if pts is not None:points.append(pts)
            if mins is not None:minutes.append(mins)
        if ps and sum(points)!=scores[side]:raise ValueError('Player points do not sum to official team score')
        total=t.get('statistics',{}).get('minutes')
        total_minutes=duration_minutes(total)
        if total_minutes is not None:
            delta=sum(minutes)-total_minutes
            minute_checks.append(dict(side=side,reported_team_minutes=total,sum_individual_minutes=sum(minutes),difference_seconds=delta*60,match_within_twelve_seconds=abs(delta)<=.2))
        listed={str(pl['personId']) for pl in ps}
        for i,pl in enumerate(t.get('inactives') or []):
            native=str(pl['personId'])
            if native in listed:
                existing=next(x for x in players if x['side']==side and x['official_player_id']==native)
                existing['active_roster']=None if existing['did_play'] else False
                existing['inactive_pointer']=f'/props/pageProps/game/{"awayTeam" if side==0 else "homeTeam"}/inactives/{i}'
                existing['roster_discrepancy']='Official page lists a played participant as inactive' if existing['did_play'] else None
                continue
            name=(pl['firstName']+' '+pl['familyName']).strip()
            players.append(dict(official_game_id=g['gameId'],official_player_id=native,player_name=name,game_date=date,team_name=names[side],side=side,score=None,assists=None,minutes=None,raw_minutes=None,starter=None,did_play=False,active_roster=False,comment=pl.get('comment'),request_id=rid,pointer=f'/props/pageProps/game/{"awayTeam" if side==0 else "homeTeam"}/inactives/{i}'))
    # A source's rounded team-minutes total is a separate player-statistic
    # discrepancy; it does not invalidate verified game identity or scores.
    row['player_minute_checks']=minute_checks
    return row,players

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--recovery-only',action='store_true');ap.add_argument('--all-star-only',action='store_true');ap.add_argument('--missing-only',action='store_true');ap.add_argument('--existing-only',action='store_true');ap.add_argument('--missing-rosters-only',action='store_true');ap.add_argument('--iso-only',action='store_true');ap.add_argument('--limit',type=int);args=ap.parse_args()
    db=sqlite3.connect(DB,timeout=60);cards={i:json.loads(b) for i,b in db.execute('SELECT official_game_id,body FROM _official_nba_schedule')}
    ids={json.loads(b).get('official_game_id') for (b,) in db.execute('SELECT body FROM _nba_canonical_games')}
    urls={'https://www.nba.com/game/'+slug for slug in RECOVERY_SLUGS}
    if not args.recovery_only:
        urls.update('https://www.nba.com/game/'+c['team_tricodes'][0].lower()+'-vs-'+c['team_tricodes'][1].lower()+'-'+gid for gid,c in cards.items() if gid in ids)
    if args.all_star_only:urls={'https://www.nba.com/game/'+c['team_tricodes'][0].lower()+'-vs-'+c['team_tricodes'][1].lower()+'-'+gid for gid,c in cards.items() if c['competition_type']=='All-Star'}
    if args.missing_only:
        done={i for (i,) in db.execute('SELECT official_game_id FROM _official_nba_page_games')};urls={u for u in urls if u.rsplit('-',1)[-1] not in done}
    if args.existing_only:urls={json.loads(b)['source_url'] for (b,) in db.execute('SELECT body FROM _official_nba_page_games')}
    if args.missing_rosters_only:
        pending={i for (i,) in db.execute("SELECT DISTINCT official_game_id FROM _official_nba_page_players WHERE json_type(body,'$.active_roster') IS NULL")}
        urls={u for u in urls if u.rsplit('-',1)[-1] in pending}
    if args.iso_only:
        iso_ids={i for (i,) in db.execute("SELECT DISTINCT official_game_id FROM _official_nba_page_players WHERE json_extract(body,'$.raw_minutes') LIKE 'PT%'")}
        urls={u for u in urls if u.rsplit('-',1)[-1] in iso_ids}
    urls=sorted(urls);urls=urls[:args.limit] if args.limit else urls
    db.execute('CREATE TABLE IF NOT EXISTS _official_nba_page_players (official_game_id TEXT NOT NULL,official_player_id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(official_game_id,official_player_id)) STRICT')
    db.execute('CREATE TABLE IF NOT EXISTS _official_nba_page_games (official_game_id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('CREATE TABLE IF NOT EXISTS _official_nba_page_acquisition (url TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.commit()
    c=HistoryClient();errors=[];ok=0;people=0
    def fetch(url):
        try:
            b,r=c.get(url,document=True);gid=url.rsplit('-',1)[-1];game,players=parse(b,r['request_id'],url,cards.get(gid));return game,players,None
        except Exception as e:return None,[],dict(url=url,error=str(e))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for n,(g,ps,error) in enumerate(pool.map(fetch,urls),1):
            if error:
                errors.append(error);db.execute('INSERT OR REPLACE INTO _official_nba_page_acquisition VALUES (?,?)',(error['url'],json.dumps(dict(status='error',**error))));db.commit()
            else:
                old=cards.get(g['official_game_id'])
                if old and (old['date']!=g['date'] or old['scores']!=g['scores'] or old['official_team_ids']!=g['official_team_ids']):
                    errors.append(dict(url=g['source_url'],error='Official date card and individual game page disagree',request_ids=[old['request_id'],g['request_id']]));continue
                db.execute('INSERT OR REPLACE INTO _official_nba_page_games VALUES (?,?)',(g['official_game_id'],json.dumps(g)))
                db.execute('INSERT OR REPLACE INTO _official_nba_page_acquisition VALUES (?,?)',(g['source_url'],json.dumps(dict(status='ok',url=g['source_url'],request_id=g['request_id'],official_game_id=g['official_game_id'],player_minutes_mismatch=any(not x['match_within_twelve_seconds'] for x in g['player_minute_checks'])))))
                if old is None:db.execute('INSERT INTO _official_nba_schedule VALUES (?,?)',(g['official_game_id'],json.dumps(g)))
                db.executemany('INSERT OR REPLACE INTO _official_nba_page_players VALUES (?,?,?)',[(p['official_game_id'],p['official_player_id'],json.dumps(p)) for p in ps]);db.commit();ok+=1;people+=len(ps)
            if n%100==0 or n==len(urls):print('NBA GAME PAGES',n,len(urls),'verified',ok,'player game rows',people,'issues',len(errors),flush=True)
    db.close();report=dict(attempted=len(urls),verified=ok,player_game_rows=people,new_requests=c.requests,errors=errors);(ROOT/'reports/official_nba_game_pages.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='errors'}))

if __name__=='__main__':main()
