"""Page both Kalshi storage tiers; the historical listing API has no date-range parameters."""
import argparse,collections,datetime as dt,json,sqlite3
from history_client import HistoryClient
from build_history_catalog import DB
from probe_history import ROOT
from discover_eu_date_batches import COMPETITIONS

BASE='https://external-api.kalshi.com/trade-api/v2'
DOCS=['https://docs.kalshi.com/api-reference/historical/get-historical-markets.md','https://docs.kalshi.com/api-reference/market/get-markets.md']

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--max-new-routes',type=int,default=12);a=ap.parse_args();client=HistoryClient();docs=[]
    for url in DOCS:
        b,r=client.get(url,document=True);assert b'SeriesTickerQuery' in b and b'CursorQuery' in b;docs.append(dict(url=url,request_id=r['request_id']))
    cutoff,r=client.get(BASE+'/historical/cutoff');db=sqlite3.connect(DB,timeout=60);db.execute('CREATE TABLE IF NOT EXISTS _eu_kalshi_market_sources (competition TEXT,ticker TEXT,route TEXT,request_id TEXT,pointer TEXT,body TEXT NOT NULL,PRIMARY KEY(competition,ticker,route)) STRICT');db.execute('CREATE TABLE IF NOT EXISTS _eu_kalshi_metadata_routes (competition TEXT,route TEXT,body TEXT NOT NULL,PRIMARY KEY(competition,route)) STRICT');db.commit();n=0
    for comp,config in COMPETITIONS.items():
        for route in ['/historical/markets','/markets']:
            old=db.execute('SELECT body FROM _eu_kalshi_metadata_routes WHERE competition=? AND route=?',(comp,route)).fetchone()
            if old and json.loads(old[0])['pagination_exhausted']:continue
            if n>=a.max_new_routes:write_report(db,cutoff,r,docs,client.requests);db.close();return
            params=dict(series_ticker=config['series'],limit=1000);seen=set();cursors=set();requests=[];error=None;months=collections.Counter()
            try:
                for _ in range(100):
                    data,rr=client.get(BASE+route,params);requests.append(rr['request_id']);rows=[]
                    for i,m in enumerate(data['markets']):
                        ticker=m['ticker'];assert ticker not in seen,'Repeated ticker across pages';assert m['event_ticker'].startswith(config['series']+'-'),'Wrong series filter';seen.add(ticker);rows.append((comp,ticker,route,rr['request_id'],'/markets/'+str(i),json.dumps(m)));months[(m.get('close_time') or '')[:7]]+=1
                    with db:db.executemany('INSERT OR REPLACE INTO _eu_kalshi_market_sources VALUES (?,?,?,?,?,?)',rows)
                    cursor=data.get('cursor')
                    if not cursor:break
                    assert cursor not in cursors,'Repeated cursor';cursors.add(cursor);params['cursor']=cursor
                else:raise ValueError('Pagination safety bound exceeded')
            except Exception as e:error=str(e)
            result=dict(competition=comp,route=route,series_ticker=config['series'],rows=len(seen),pagination_exhausted=error is None,error=error,request_ids=requests,source_close_month_counts=dict(sorted(months.items())))
            with db:db.execute('INSERT OR REPLACE INTO _eu_kalshi_metadata_routes VALUES (?,?,?)',(comp,route,json.dumps(result)))
            n+=1;print('EU KALSHI METADATA',comp,route,len(seen),len(requests),'pages',error or 'exhausted',flush=True);write_report(db,cutoff,r,docs,client.requests)
            if error:db.close();return
    db.close()

def write_report(db,cutoff,record,docs,requests):
    routes=[json.loads(b) for b, in db.execute('SELECT body FROM _eu_kalshi_metadata_routes ORDER BY competition,route')];overlap=[dict(competition=c,ticker=t,copies=n) for c,t,n in db.execute('SELECT competition,ticker,count(*) FROM _eu_kalshi_market_sources GROUP BY competition,ticker HAVING count(*)>1')];out=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='DISCOVERY_ONLY',routes_complete=sum(r['pagination_exhausted'] for r in routes),total_routes=12,cutoff=cutoff,cutoff_request_id=record['request_id'],documentation=docs,new_requests_this_run=requests,routes=routes,duplicate_route_markets=overlap,meaning='Historical listing does not support date bounds. Its six game-result series are paginated once; subsequent game matching and prices are partitioned by actual official game date. Current live listing includes future games, which are not published as historical results. Native ticker deduplicates the two storage routes.')
    (ROOT/'reports/eu_soccer_kalshi_metadata.json').write_text(json.dumps(out,indent=2),encoding='utf-8')

if __name__=='__main__':main()
