"""Recover individual counts only from a demonstrably complete official goal list."""
import collections


def verified_counts(landing, game, players):
    assert str(landing['id']) == game['official_game_id']
    assert [str(landing[k]['id']) for k in ['awayTeam', 'homeTeam']] == game['team_ids']
    assert [landing[k]['score'] for k in ['awayTeam', 'homeTeam']] == game['scores']
    periods = landing.get('summary', {}).get('scoring')
    if not isinstance(periods, list):
        return None, 'Official scoring summary absent'
    expected = list(game['scores'])
    if landing.get('gameOutcome', {}).get('lastPeriodType') == 'SO':
        expected[0 if expected[0] > expected[1] else 1] -= 1
    totals = [0, 0]
    counts = collections.defaultdict(lambda: dict(score=0, assists=0))
    ids = set()
    roster = {p['official_player_id']: p for p in players}
    pointers = []
    for pi, period in enumerate(periods):
        if period['periodDescriptor']['periodType'] == 'SO':
            continue
        if not isinstance(period.get('goals'), list):
            return None, 'Period goals array absent'
        for gi, goal in enumerate(period['goals']):
            if not all(k in goal for k in ['eventId', 'playerId', 'isHome', 'assists', 'awayScore', 'homeScore']):
                return None, 'Required explicit scoring-event field absent'
            if goal['eventId'] in ids or type(goal['isHome']) is not bool or not isinstance(goal['assists'], list):
                return None, 'Duplicate or malformed scoring event'
            ids.add(goal['eventId'])
            side = int(goal['isHome'])
            totals[side] += 1
            if totals != [goal['awayScore'], goal['homeScore']]:
                return None, 'Goal-by-goal score progression incomplete'
            scorer = str(goal['playerId'])
            assistants = [str(a['playerId']) for a in goal['assists'] if a.get('playerId') is not None]
            if len(assistants) != len(goal['assists']) or len(assistants) > 2 or len(set(assistants + [scorer])) != len(assistants) + 1:
                return None, 'Scorer/assist identity incomplete or duplicated'
            for native in [scorer] + assistants:
                if native not in roster or roster[native]['side'] != side:
                    return None, 'Scorer/assist identity does not match official same-team roster'
            counts[scorer]['score'] += 1
            for native in assistants:
                counts[native]['assists'] += 1
            pointers.append('/summary/scoring/' + str(pi) + '/goals/' + str(gi))
    if totals != expected:
        return None, 'Non-shootout goal count does not match final score'
    checked = 0
    for p in players:
        if p['played'] is not True:
            continue
        for field in ['score', 'assists']:
            if p[field] is not None:
                checked += 1
                if p[field] != counts[p['official_player_id']][field]:
                    return None, 'Scoring event count differs from explicit player boxscore'
    if not checked:
        return None, 'No independently populated player statistics to cross-check'
    return dict(counts=dict(counts), goal_pointers=pointers, non_shootout_final_score=totals,
                explicit_player_statistics_checked=checked), None
