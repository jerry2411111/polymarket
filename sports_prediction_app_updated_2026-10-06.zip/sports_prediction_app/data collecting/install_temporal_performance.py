"""Compact cumulative performance intervals plus date-queryable public views."""
import collections,datetime as dt,json,math,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
from temporal_queries import FLAGS,PUBLIC_PLAYER,ranked

def dates(start,end):
    day=dt.date.fromisoformat(start);last=dt.date.fromisoformat(end)
    while day<=last:
        yield day.isoformat();day+=dt.timedelta(days=1)

def periods(rows,end,sample_counts=None):
    grouped=collections.defaultdict(list)
    for r in rows:grouped[r['player_id'],r['league']].append(r)
    output=[]
    for (pid,league),games in grouped.items():
        days=collections.defaultdict(list)
        for r in games:days[r['game_date']].append(r)
        daylist=sorted(days);total=0;wins=0;stats={c:[0,0.,0.] for c in ['score','assists','minutes','starter']}
        for i,day in enumerate(daylist):
            for r in days[day]:
                total+=1;wins+=r['win']
                for c,(count,s,ss) in list(stats.items()):
                    v=r[c]
                    if v is not None:stats[c]=[count+1,s+v,ss+v*v]
            last=days[day][-1]
            p=dict(player_id=pid,player_name=last['player_name'],game_type=last['game_type'],league=league,effective_from=day,effective_to=daylist[i+1] if i+1<len(daylist) else end,games_played=total,overall_winrate=wins/total)
            for c in ['score','assists','minutes']:
                count,s,ss=stats[c]
                p['average_'+c+'_per_game']=s/count if count else None
                p['std_'+c+'_per_game']=math.sqrt(max(0,(ss-s*s/count)/(count-1))) if count>1 else None
            p['starter_percentage_overall']=stats['starter'][1]/stats['starter'][0] if stats['starter'][0] else None
            if sample_counts is not None:
                sample_counts.append((pid,league,day,p['effective_to'],total,*[stats[c][0] for c in ['score','assists','minutes','starter']]))
            output.append(p)
    return output

def main():
    db=sqlite3.connect(DB,timeout=60);db.row_factory=sqlite3.Row
    start,end=db.execute('SELECT collection_start,collection_end FROM _collection_scope').fetchone();end_exclusive=(dt.date.fromisoformat(end)+dt.timedelta(days=1)).isoformat()
    games=[dict(r) for r in db.execute('SELECT * FROM _player_game_results WHERE game_date BETWEEN ? AND ? ORDER BY game_date,game_id',(start,end))]
    sample_counts=[];ps=periods(games,end_exclusive,sample_counts)
    # Dated official roster observations establish that-day affiliation only.
    # Last-observed affiliation is explicitly not a verified contract interval.
    db.execute('CREATE TABLE IF NOT EXISTS _player_team_observations (player_id TEXT NOT NULL,league TEXT NOT NULL,team_name TEXT NOT NULL,observed_date TEXT NOT NULL,game_id TEXT NOT NULL,is_temporary INTEGER NOT NULL,source_request_id TEXT,PRIMARY KEY(player_id,league,game_id)) STRICT')
    obs=[]
    for pid,gid,b in db.execute('SELECT player_id,game_id,body FROM _nba_player_game_facts'):
        p=json.loads(b);obs.append((pid,'NBA',p['team_name'],p['game_date'],gid,int(p['temporary_team']),p.get('roster_request_id') or p['request_id']))
    expanded_mlb=bool(db.execute("SELECT 1 FROM sqlite_master WHERE name='_mlb_player_game_facts'").fetchone())
    if expanded_mlb:
        for pid,gid,b in db.execute('SELECT player_id,game_id,body FROM _mlb_player_game_facts'):
            p=json.loads(b)
            if not p.get('affiliation_observation_safe',not p.get('spans_multiple_local_dates',False)):continue
            obs.append((pid,'MLB',p['team_name'],p['game_date'],gid,int(p['temporary_team']),p['request_id']))
    expanded_nhl=bool(db.execute("SELECT 1 FROM sqlite_master WHERE name='_nhl_player_game_facts'").fetchone())
    if expanded_nhl:
        for pid,gid,b in db.execute('SELECT player_id,game_id,body FROM _nhl_player_game_facts'):
            p=json.loads(b)
            if not p['affiliation_observation_safe']:continue
            obs.append((pid,'NHL',p['team_name'],p['game_date'],gid,int(p['temporary_team']),p['request_id']))
    expanded_eu=bool(db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_player_game_facts'").fetchone())
    expanded_epl=bool(db.execute("SELECT 1 FROM sqlite_master WHERE name='_epl_player_game_facts'").fetchone())
    if expanded_eu:
        for pid,gid,b in db.execute('SELECT player_id,game_id,body FROM _eu_player_game_facts'):
            p=json.loads(b)
            if p['affiliation_observation_safe']:obs.append((pid,'EU soccer',p['team_name'],p['game_date'],gid,0,p['roster_request_id']))
    elif expanded_epl:
        for pid,gid,b in db.execute('SELECT player_id,game_id,body FROM _epl_player_game_facts'):
            p=json.loads(b)
            if p['affiliation_observation_safe']:obs.append((pid,'EU soccer',p['team_name'],p['game_date'],gid,0,p['roster_request_id']))
    obs.extend((r['player_id'],r['league'],r['team_name'],r['game_date'],r['game_id'],0,None) for r in games if r['league']!='NBA' and not (expanded_mlb and r['league']=='MLB') and not (expanded_nhl and r['league']=='NHL') and not (expanded_eu and r['league']=='EU soccer') and not (expanded_epl and r['player_id'].startswith('EU_PL:')))
    db.execute('DELETE FROM _player_team_observations');db.executemany('INSERT INTO _player_team_observations VALUES (?,?,?,?,?,?,?)',obs)
    db.execute('CREATE INDEX IF NOT EXISTS _player_team_dates ON _player_team_observations(player_id,league,is_temporary,observed_date DESC,game_id DESC)')
    db.execute('DROP VIEW IF EXISTS _player_affiliation_observations')
    affiliation_sql='SELECT player_id,league,team_name,observed_date,is_temporary,game_id AS observation_id FROM _player_team_observations'
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='_nba_affiliation_events'").fetchone():
        affiliation_sql+=" UNION ALL SELECT player_id,'NBA',team_name,event_date,0,'ROSTER_EVENT:'||kind||':'||event_date FROM _nba_affiliation_events"
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='_mlb_affiliation_daily'").fetchone():
        affiliation_sql+=" UNION ALL SELECT player_id,'MLB',team_name,observed_date,0,'ROSTER_EVENT:'||observation_id FROM _mlb_affiliation_daily"
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='_nhl_affiliation_daily'").fetchone():
        affiliation_sql+=" UNION ALL SELECT player_id,'NHL',team_name,observed_date,0,'ROSTER_EVENT:'||observation_id FROM _nhl_affiliation_daily"
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_affiliation_daily'").fetchone():
        affiliation_sql+=" UNION ALL SELECT player_id,'EU soccer',team_name,observed_date,0,'ROSTER_EVENT:'||observation_id FROM _eu_affiliation_daily"
    elif db.execute("SELECT 1 FROM sqlite_master WHERE name='_epl_affiliation_daily'").fetchone():
        affiliation_sql+=" UNION ALL SELECT player_id,'EU soccer',team_name,observed_date,0,'ROSTER_EVENT:'||observation_id FROM _epl_affiliation_daily"
    db.execute('CREATE VIEW _player_affiliation_observations AS '+affiliation_sql)
    from index_ranking_flags import refresh
    refresh(db)
    db.execute('DROP VIEW IF EXISTS player_performance')
    db.execute('DROP TABLE IF EXISTS _player_performance_periods')
    types={k:('INTEGER' if k=='games_played' else 'TEXT' if k in ['player_id','player_name','game_type','league','effective_from','effective_to'] else 'REAL') for k in ps[0]}
    db.execute('CREATE TABLE _player_performance_periods ('+','.join(k+' '+t for k,t in types.items())+',PRIMARY KEY(player_id,league,effective_from)) STRICT')
    db.executemany('INSERT INTO _player_performance_periods VALUES ('+','.join('?' for _ in types)+')',[tuple(p.values()) for p in ps])
    db.execute('CREATE INDEX _performance_interval_dates ON _player_performance_periods(effective_from,effective_to,league)')
    db.execute('CREATE INDEX _performance_league_intervals ON _player_performance_periods(league,effective_from,effective_to)')
    db.execute('DROP TABLE IF EXISTS _player_performance_sample_counts')
    db.execute('CREATE TABLE _player_performance_sample_counts (player_id TEXT,league TEXT,effective_from TEXT,effective_to TEXT,games_played INTEGER,score_count INTEGER,assists_count INTEGER,minutes_count INTEGER,starter_count INTEGER,PRIMARY KEY(player_id,league,effective_from)) STRICT')
    db.executemany('INSERT INTO _player_performance_sample_counts VALUES (?,?,?,?,?,?,?,?,?)',sample_counts)
    db.execute('CREATE TABLE IF NOT EXISTS _query_dates (as_of_date TEXT PRIMARY KEY) STRICT');db.execute('DELETE FROM _query_dates');db.executemany('INSERT INTO _query_dates VALUES (?)',[(d,) for d in dates(start,end)])
    changes=collections.defaultdict(list)
    for p in ps:changes[p['effective_from']].append(p)
    active=collections.defaultdict(dict);cohorts=[]
    for day in dates(start,end):
        for p in changes[day]:active[p['league']][p['player_id']]=p['average_score_per_game']
        for league,values in active.items():
            vs=[v for v in values.values() if v is not None]
            mean=sum(vs)/len(vs) if vs else None
            sigma=math.sqrt(sum((v-mean)**2 for v in vs)/len(vs)) if vs else None
            cohorts.append((day,league,mean,sigma))
    db.execute('DROP TABLE IF EXISTS _player_score_cohorts');db.execute('CREATE TABLE _player_score_cohorts (as_of_date TEXT NOT NULL,league TEXT NOT NULL,mu REAL,sigma REAL,PRIMARY KEY(as_of_date,league)) STRICT');db.executemany('INSERT INTO _player_score_cohorts VALUES (?,?,?,?)',cohorts)
    base='''SELECT m.player_id,m.player_name,m.game_type,m.league,
    (SELECT team_name FROM _player_affiliation_observations o WHERE o.player_id=m.player_id AND o.league=m.league
      AND o.is_temporary=0 AND o.observed_date<=d.as_of_date ORDER BY o.observed_date DESC,o.observation_id DESC LIMIT 1) AS team,
    d.as_of_date,m.games_played,m.overall_winrate,
    m.average_score_per_game,m.std_score_per_game,m.average_assists_per_game,m.std_assists_per_game,
    m.average_minutes_per_game,m.std_minutes_per_game,
    CASE WHEN c.sigma>0 THEN (m.average_score_per_game-c.mu)/c.sigma END AS score_z_score,m.starter_percentage_overall
    FROM _query_dates d JOIN _player_performance_periods m ON m.effective_from<=d.as_of_date AND m.effective_to>d.as_of_date
    JOIN _player_score_cohorts c ON c.as_of_date=d.as_of_date AND c.league=m.league'''
    from ranking_policy import active_flags
    from no_observation_policy import include_unobserved_player
    db.execute('CREATE VIEW player_performance AS '+ranked(include_unobserved_player(base),flags=active_flags(db,fallback=FLAGS),use_policy=True))
    db.execute('DROP VIEW IF EXISTS manager_performance')
    db.execute('''CREATE VIEW manager_performance AS
    SELECT g.manager_id,g.manager_name,g.game_type,g.league,d.as_of_date,
     count(*) AS games_played,avg(g.win) AS overall_winrate,
     sum(g.home_away='Home') AS home_times,sum(g.home_away='Away') AS away_times,
     avg(g.score_for-g.score_against) AS average_score_margin
    FROM _query_dates d JOIN _manager_game_results g
     ON g.game_date>= (SELECT collection_start FROM _collection_scope) AND g.game_date<=d.as_of_date
    GROUP BY d.as_of_date,g.manager_id,g.manager_name,g.game_type,g.league''')
    # Rebuild the existing public team-history table for every collection date.
    tg=collections.defaultdict(list)
    for r in db.execute('SELECT * FROM _team_game_results WHERE game_date BETWEEN ? AND ? ORDER BY game_date,game_id',(start,end)):tg[r['game_date']].append(dict(r))
    active={};teamrows=[]
    for day in dates(start,end):
        for g in tg[day]:
            team_key='_NHL_UTAH_' if g['league']=='NHL' and g['team_name'] in ['Utah Hockey Club','Utah Mammoth'] else g['team_name']
            key=team_key,g['league'];s=active.setdefault(key,dict(game_type=g['game_type'],n=0,w=0,h=0,a=0,margin=0))
            s['n']+=1;s['w']+=g['win'];s['h']+=g['home_away']=='Home';s['a']+=g['home_away']=='Away';s['margin']+=g['score_for']-g['score_against']
        for (team,league),s in active.items():
            if team=='_NHL_UTAH_':team='Utah Hockey Club' if day<'2025-05-07' else 'Utah Mammoth'
            teamrows.append((team,s['game_type'],league,day,s['w']/s['n'],s['n'],s['h'],s['a'],s['margin']/s['n']))
    original_team_cols=['team_name','game_type','league','as_of_date','winrate','games_played','home_times','away_times','average_score_margin']
    team_cols=[r[1] for r in db.execute('PRAGMA table_info(team_history)')]
    db.execute('DELETE FROM team_history');db.executemany('INSERT INTO team_history ('+','.join(team_cols)+') VALUES ('+','.join('?' for _ in team_cols)+')',[tuple(dict(zip(original_team_cols,r))[c] for c in team_cols) for r in teamrows])
    db.commit()
    report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),collection_start=start,collection_end=end,player_game_rows=len(games),player_performance_intervals=len(ps),team_history_rows=len(teamrows),dated_roster_observations=len(obs),source_ids_retained=True,team_field_basis='Most recently observed non-All-Star roster on or before query date; this is not a verified transaction or contract interval',std_definition='Sample standard deviation, denominator valid observations minus 1; null with fewer than two observations',missing_statistics='Each statistic uses its available observations through the date; missing source values are not zero-filled.',scope='Only collected game facts through the query date. Expanded manager, biography/profile, weather and ranking coverage remains separately tracked.')
    (ROOT/'reports/temporal_performance_install.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));db.close()

if __name__=='__main__':main()
