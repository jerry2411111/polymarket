import collections,json,sqlite3
from build_history_catalog import DB
from probe_history import ROOT
db=sqlite3.connect(DB)
r=json.loads(db.execute("SELECT metadata_json FROM _request_audit WHERE json_extract(metadata_json,'$.endpoint')='https://statsapi.mlb.com/api/v1/transactions' AND json_extract(metadata_json,'$.parameters.date')='2024-01-05'").fetchone()[0]);xs=json.loads((ROOT/r['raw_file']).read_bytes())['transactions'];counts=collections.Counter(x['id'] for x in xs)
for x in xs:
    if counts[x['id']]>1:print(json.dumps(x))
