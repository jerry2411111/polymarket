"""Match explicit team-win/draw contracts to official games in each EU competition."""
import argparse,collections,datetime as dt,json,re,sqlite3,unicodedata
from build_history_catalog import DB
from probe_history import ROOT
from build_premier_market_candidates import array,utc
from eu_official_games import CONFIG,club_key,games as official_games

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--competition',choices=list(CONFIG));a=ap.parse_args();db=sqlite3.connect(DB,timeout=60)
 for code in ([a.competition] if a.competition else CONFIG):
  games=official_games(db,code);aliases=collections.defaultdict(set);bydate=collections.defaultdict(list);issues=[];cs=[];families=[];unmatched=collections.Counter();alias_proofs=[];events=[]
  for g in games.values():
   bydate[g['date']].append(g)
   for s in ['away','home']:
    for v in g[s]['aliases']:aliases[club_key(v)].add(g[s]['id'])
  official_clubs={g[s]['id']:g[s] for g in games.values() for s in ['away','home']}
  date_reviews={(p,f):json.loads(b) for p,f,b in db.execute('SELECT provider,family_id,body FROM _eu_fixture_date_reviews WHERE competition=?',(code,))} if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_fixture_date_reviews'").fetchone() else {}
  literal=lambda s:re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower())
  exact_aliases=collections.defaultdict(set)
  for tid,t in official_clubs.items():
   exact_aliases[literal(t['name'])].add(tid)
  if db.execute("SELECT 1 FROM sqlite_master WHERE name='_eu_club_alias_evidence'").fetchone():
   for tid,label,b in db.execute('SELECT team_id,alias,body FROM _eu_club_alias_evidence WHERE competition=?',(code,)):
    assert tid in official_clubs;aliases[club_key(label)].add(tid);alias_proofs.append(dict(label=label,native_team_id=tid,**json.loads(b)))
  def name_words(label):
   stop={'fc','cf','afc','sad','ac','as','ss','ssc','acf','us','sc','rc','bv','sv','tsg','fsv','club','clubs','football','futbol','de','del','calcio'}
   return {club_key(w) for w in re.split(r'\W+',label) if club_key(w) and not w.isdigit() and club_key(w) not in stop}
  def resolve(label):
   direct=exact_aliases[literal(label)]
   if len(direct)==1:return direct
   found=aliases[club_key(label)]
   if found or club_key(label) in ['draw','tie']:return found
   words=name_words(label);found={tid for tid,t in official_clubs.items() if any((nw:=name_words(n)) and max(map(len,nw))>=4 and (nw<=words or words<=nw) for n in t['aliases'] if len(n)>3) and words and max(map(len,words))>=4}
   if len(found)==1:
    aliases[club_key(label)].update(found);alias_proofs.append(dict(label=label,native_team_id=next(iter(found)),reason='Unique official name/nickname containment after club-prefix and founding-year normalization; fixture date and both opponents required'))
   return found
  def alias_candidate(label,abbr):
   # A short code alone is insufficient. Also require an official name
   # component of at least four letters and uniqueness in this competition.
   words={club_key(w) for w in re.split(r'\W+',label) if len(club_key(w))>=4 and not w.isdigit()}-{'football','club','calcio','deportivo','atletico','real','sporting','united','city'}
   return {tid for tid,t in official_clubs.items() if (club_key(abbr) in {club_key(v) for v in t['aliases'] if len(club_key(v))<=4} or aliases[club_key(abbr)]=={tid}) and words&{club_key(w) for n in t['aliases'] for w in re.split(r'\W+',n)}}
  for eid,rid,ptr,b in db.execute('SELECT event_id,request_id,pointer,body FROM _eu_pm_events WHERE event_id IN (SELECT event_id FROM _eu_pm_event_sources WHERE competition=?)',(code,)):
   e=json.loads(b)
   if not e.get('startTime') and not any(m.get('gameStartTime') for m in e.get('markets',[])) and not re.search(r'\bvs?\.?\s',e.get('title',''),re.I):continue
   events.append((eid,rid,ptr,e))
   for t in e.get('teams') or []:
    found=resolve(t.get('name',''))
    if not found:
     found=alias_candidate(t.get('name',''),t.get('abbreviation',''))
     if len(found)==1:aliases[club_key(t['name'])].update(found);alias_proofs.append(dict(label=t['name'],suffix=t.get('abbreviation'),native_team_id=next(iter(found)),request_id=rid,pointer=ptr+'/teams/'+str(e['teams'].index(t)),reason='Exact official abbreviation plus official name component and unique club'))
    if len(found)==1:
     for v in [t.get('abbreviation'),t.get('alias')]:
      if v:aliases[club_key(v)].update(found)
  km=[(json.loads(b),rid,ptr) for rid,ptr,b in db.execute('SELECT request_id,pointer,body FROM _eu_kalshi_markets WHERE competition=?',(code,))]
  def kalshi_label(m):return re.sub(r'^Reg Time:\s*','',m.get('yes_sub_title',''),flags=re.I)
  kalshi_ids={}
  for m,rid,ptr in km:
   label=kalshi_label(m);suffix=m['ticker'].rsplit('-',1)[-1]
   full={tid for tid,t in official_clubs.items() if literal(t['name'])==literal(label)};bycode=alias_candidate(label,suffix);found=full if len(full)==1 else bycode if len(bycode)==1 else resolve(label)
   if found:kalshi_ids[m['ticker']]=found
   if len(found)==1:continue
   if not label or club_key(label) in ['draw','tie']:continue
   found=alias_candidate(label,suffix)
   if len(found)==1:kalshi_ids[m['ticker']]=found;alias_proofs.append(dict(label=label,suffix=suffix,native_team_id=next(iter(found)),request_id=rid,pointer=ptr,reason='Verified abbreviation plus official name component and unique club; scoped to this contract'))
  def match(tids,day):
   found=[g for g in bydate[day] if {g['away']['id'],g['home']['id']}==set(tids)];return found[0] if len(found)==1 else None
  def match_sets(sets,day):
   if len(sets)!=2:return None,None
   found=[]
   for g in bydate[day]:
    for order in [(g['away']['id'],g['home']['id']),(g['home']['id'],g['away']['id'])]:
     if all(tid in options for tid,options in zip(order,sets)):found.append((g,order))
   return found[0] if len(found)==1 else (None,None)
  def issue(provider,fid,reason,**kw):issues.append(dict(competition=code,provider=provider,family_id=fid,reason=reason,**kw))
  def add(provider,fid,g,members):
   if collections.Counter(c['side'] for c in members)!={0:1,1:1,2:1}:issue(provider,fid,'Incomplete or ambiguous three-outcome family');return
   if g.get('result_revision'):issue(provider,fid,'Dated disciplinary score revision requires rule review',official_match_id=g['official_match_id'],result_revision=g['result_revision']);return
   if g.get('scores') is None:issue(provider,fid,'Official regulation score unresolved',official_match_id=g['official_match_id']);return
   expected=2 if g['scores'][0]==g['scores'][1] else int(g['scores'][1]>g['scores'][0]);rulebad=any(c.get('draw_half_payout_rule') for c in members)
   if rulebad:issue(provider,fid,'Written draw payout is 50-50; not an unambiguous team-win probability',official_match_id=g['official_match_id']);return
   if any(c['settlement_yes'] is not None and c['settlement_yes']!=int(c['side']==expected) for c in members):issue(provider,fid,'Provider settlement differs from official regulation result',official_match_id=g['official_match_id'],scores=g['scores'],settlements=[(c['side'],c['settlement_yes']) for c in members]);return
   for c in members:c.update(competition=code,game_id=g['game_id'],official_match_id=g['official_match_id'],official_schedule_request_id=g['request_id'],date=g['date'],native_team_id=g[['away','home'][c['side']]]['id'] if c['side']<2 else None,official_away_team_id=g['away']['id'],official_home_team_id=g['home']['id'],fixture_date_review=date_reviews.get((provider,fid)))
   cs.extend(members);families.append(dict(competition=code,provider=provider,family_id=fid,game_id=g['game_id'],official_match_id=g['official_match_id'],date=g['date'],outcomes=3))
  for eid,rid,ptr,e in events:
   ms=[];unknown=[]
   for mi,m in enumerate(e.get('markets',[])):
    q=m.get('question','').strip()
    if m.get('sportsMarketType') not in [None,'moneyline'] or re.search(r'\b(first half|second half|1st half|2nd half|advance|qualif|champion|title|season|top \d|relegat|both teams|score first)\b',q,re.I):continue
    outcomes=array(m.get('outcomes'));tokens=array(m.get('clobTokenIds'));values=array(m.get('outcomePrices'))
    if len(outcomes)!=2 or {club_key(v) for v in outcomes}!={'yes','no'} or len(tokens)!=2 or len(set(tokens))!=2:continue
    if re.search(r'\b(draw|tie)\b',q,re.I):team='DRAW'
    else:
     parsed=re.match(r'Will (.+?) (?:win|beat|defeat)\b',q,re.I)
     if not parsed:continue
     team=parsed[1]
     if not resolve(team):unknown.append(team);unmatched[team]+=1;continue
    ms.append((mi,m,team,outcomes,tokens,values))
   if unknown:issue('polymarket',eid,'Unmatched or ambiguous explicit team label',labels=sorted(set(unknown)),request_id=rid,pointer=ptr)
   labels=[t for _,_,t,_,_,_ in ms if t!='DRAW'];sets=[resolve(t) for t in labels];tids=set().union(*sets) if sets else set()
   if len(labels)!=2 or len(ms)!=3:continue
   starts={utc(m['gameStartTime']) for _,m,_,_,_,_ in ms if m.get('gameStartTime')};raw_start=min(starts) if starts else utc(e.get('startTime'));review=date_reviews.get(('polymarket',eid))
   if len(starts)>1 and not review:issue('polymarket',eid,'Different start times within proposed family',request_id=rid);continue
   day=review['official_date'] if review else raw_start.date().isoformat() if raw_start else (e.get('endDate') or '')[:10];g,order=match_sets(sets,day);assigned=dict(zip(labels,order)) if order else {}
   if review:assert g and g['official_match_id']==review['official_match_id']
   if not g:issue('polymarket',eid,'No unique official fixture on proposed date',date=day,team_ids=sorted(tids),request_id=rid,pointer=ptr);continue
   if not review and raw_start and abs((raw_start-utc(g['scheduled_start_utc'])).total_seconds())>6*3600:issue('polymarket',eid,'Source start differs by more than six hours',official_match_id=g['official_match_id']);continue
   members=[]
   for mi,m,team,outs,tokens,values in ms:
    oi=next(i for i,v in enumerate(outs) if club_key(v)=='yes');side=2 if team=='DRAW' else int(assigned[team]==g['home']['id']);v=float(values[oi]) if len(values)==2 else None;desc=m.get('description','');members.append(dict(provider='polymarket',contract_id=tokens[oi],market_id=m['id'],event_id=eid,family_id=eid,side=side,outcome=outs[oi],outcome_index=oi,team_question=team,open=m.get('createdAt'),settled=m.get('closedTime') or m.get('endDate'),series=None,settlement_yes=v if m.get('closed') else None,request_id=rid,pointer=ptr+'/markets/'+str(mi),source_start_utc=raw_start.isoformat() if raw_start else None,draw_half_payout_rule=bool(team!='DRAW' and re.search(r'(?:tie|draw).{0,140}(?:50.?50|50%)',desc,re.I)),identity_basis='Explicit three-outcome questions; unique native club assignment jointly constrained by both opponents and official game date'))
   add('polymarket',eid,g,members)
  groups=collections.defaultdict(list)
  for m,rid,ptr in km:groups[m['event_ticker']].append((m,rid,ptr))
  for eid,ms in groups.items():
   if len(ms)!=3 or any(m.get('result') not in ['yes','no'] for m,_,_ in ms):continue
   parsed=re.match(re.escape(CONFIG[code][2])+r'-(\d{2})([A-Z]{3})(\d{2})',eid);assert parsed;day=dt.datetime.strptime('20'+parsed[1]+parsed[2]+parsed[3],'%Y%b%d').date().isoformat();tids=set();unknown=[]
   for m,_,_ in ms:
    label=kalshi_label(m);found=kalshi_ids.get(m['ticker'],set())
    if club_key(label) in ['draw','tie']:continue
    if found:tids.update(found)
    else:unknown.append(label);unmatched[label]+=1
   if unknown:issue('kalshi',eid,'Unmatched or ambiguous explicit team label',labels=unknown,date=day);continue
   review=date_reviews.get(('kalshi',eid));team_members=[m for m,_,_ in ms if club_key(kalshi_label(m)) not in ['draw','tie']];g,order=match_sets([kalshi_ids.get(m['ticker'],set()) for m in team_members],review['official_date'] if review else day);assigned=dict(zip([m['ticker'] for m in team_members],order)) if order else {}
   if review:assert g and g['official_match_id']==review['official_match_id']
   if not g:issue('kalshi',eid,'No unique official fixture for native ticker date',date=day,team_ids=sorted(tids));continue
   members=[]
   for m,rid,ptr in ms:
    label=kalshi_label(m);side=2 if club_key(label) in ['tie','draw'] else int(assigned[m['ticker']]==g['home']['id']);rules=m['rules_primary']
    if '90 minutes plus stoppage time' not in rules or 'does not include extra time or penalties' not in rules:issue('kalshi',eid,'Unreviewed market duration rule',market_id=m['ticker'],request_id=rid,pointer=ptr);continue
    members.append(dict(provider='kalshi',contract_id=m['ticker'],market_id=m['ticker'],event_id=eid,family_id=eid,side=side,outcome='Yes',team_question=m['yes_sub_title'],mapping_label=label,open=m['open_time'],settled=m.get('settlement_ts') or m.get('settlement_time') or m.get('close_time'),series=CONFIG[code][2],settlement_yes=int(m['result']=='yes'),request_id=rid,pointer=ptr,identity_basis='Explicit regulation-win/draw contracts; unique native official clubs and ticker date'))
   add('kalshi',eid,g,members)
  assert len(cs)==len({(c['provider'],c['contract_id']) for c in cs})
  with db:
   for table,rows in [('_eu_market_candidates',cs),('_eu_market_families',families),('_eu_matching_issues',issues)]:db.execute('CREATE TABLE IF NOT EXISTS '+table+' (competition TEXT NOT NULL,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM '+table+' WHERE competition=?',(code,));db.executemany('INSERT INTO '+table+' VALUES (?,?)',[(code,json.dumps(r)) for r in rows])
  report=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),competition=code,status='CANDIDATES_REQUIRE_RULE_VALIDATION_REPORTS_AND_PRICES',official_games=len(games),families_by_provider=dict(collections.Counter(f['provider'] for f in families)),unique_games=len({f['game_id'] for f in families}),outcome_contracts=len(cs),issues=dict(collections.Counter(i['reason'] for i in issues)),unmatched_labels=dict(unmatched),provider_alias_proofs=alias_proofs,earliest_by_provider={p:min((f['date'] for f in families if f['provider']==p),default=None) for p in ['polymarket','kalshi']},scope='Internal candidates only. No new public odds rows until metadata, rules, raw quotes and official reports pass validation.');(ROOT/'reports'/(CONFIG[code][1]+'_market_candidates.json')).write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report),flush=True)
 db.close()

if __name__=='__main__':main()
