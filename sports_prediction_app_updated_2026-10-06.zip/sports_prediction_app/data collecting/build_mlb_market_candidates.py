"""Match MLB winner contracts to official native games without using scores.

Score/settlement agreement is checked only after identity matching. Repeated
opponents require official game numbers or a distinct close start-time match.
"""
import collections,datetime as dt,json,re,sqlite3
from build_history_catalog import DB,clean,team_name,short
from history_index import index,records
from core import utc,array
from probe_history import ROOT

def main():
    data=index();rs={r['request_id']:r for r in records()};db=sqlite3.connect(DB,timeout=60)
    schedules={n:json.loads(b) for n,b in db.execute('SELECT * FROM _official_mlb_schedule')};aliases=collections.defaultdict(set);by_pair=collections.defaultdict(list);teams={}
    previous={i:json.loads(b) for i,b in db.execute('SELECT * FROM _mlb_canonical_games')} if db.execute("SELECT 1 FROM sqlite_master WHERE name='_mlb_canonical_games'").fetchone() else {}
    for g in schedules.values():
        by_pair[frozenset(g['official_team_ids'])].append(g)
        for side in ['away','home']:
            t=g['raw_game']['teams'][side]['team'];tid=str(t['id']);teams[tid]=t
            # Exhibition opponents can share nicknames (e.g. Hanshin Tigers).
            # Winner contracts here are MLB clubs; retain full non-MLB names,
            # but never let their nicknames collide with major-league aliases.
            major=t.get('league',{}).get('id') in [103,104]
            names=[t['name'],t.get('teamName'),t.get('clubName'),t.get('shortName'),t.get('abbreviation')] if major else [t['name']]
            if t.get('allStarStatus')=='Y':names.append(t.get('league',{}).get('name'))
            for name in names:
                if name:aliases[clean(name)].add(tid)
    provider_teams={};issues=[]
    for pid,(t,rid,ptr) in data['teams'].items():
        if t['details'].get('league')!='MLB':continue
        names=[team_name(t),t.get('name'),t['details'].get('team_name'),t['details'].get('short_name'),short(t)]
        found={next(iter(aliases[clean(n)])) for n in names if n and len(aliases[clean(n)])==1}
        if len(found)==1:provider_teams[pid]=next(iter(found))
    def match(tids,start,ordinal=None):
        if len(tids)!=2 or len(set(tids))!=2 or start is None:return None,'Missing or ambiguous participant/start mapping'
        def distance(g):
            times=[g['scheduled_start_utc'],g['raw_game'].get('resumeDate'),g['raw_game'].get('rescheduledFrom')]
            return min(abs((utc(t)-start).total_seconds()) for t in times if t)
        possible=[g for g in by_pair[frozenset(tids)] if distance(g)<=6*3600]
        if ordinal and len(possible)>1:possible=[g for g in possible if g['game_number']==ordinal]
        if len(possible)>1:
            possible.sort(key=distance);dist=[distance(g) for g in possible]
            if dist[0]<=15*60 and dist[1]-dist[0]>=60*60:possible=possible[:1]
        if len(possible)!=1:return None,'No unique official completed game within six hours of source start'
        return possible[0],None
    def canonical(g):
        assert all(g['team_codes']) and g['game_number'] in [1,2,3]
        return 'MLB_'+g['official_date'].replace('-','')+'_'+'_'.join(g['team_codes'])+'_G'+str(g['game_number'])
    events=collections.defaultdict(list)
    for mid,(m,rid,ptr) in data['milestones'].items():
        if m.get('details',{}).get('league')!='MLB' or not '2024-01-01'<=m['start_date'][:10]<='2026-09-15':continue
        for eid in m.get('primary_event_tickers',[]):
            if eid.startswith('KXMLBGAME-'):events[eid].append((m,rid,ptr))
    contracts=[];game_sources=collections.defaultdict(set);native_games={}
    for ticker,(m,rid,ptr) in data['kalshi_markets'].items():
        if not ticker.startswith('KXMLBGAME-'):continue
        eid=m['event_ticker'];candidates=[]
        for mile,mrid,mptr in events[eid]:
            d=mile['details'];tids=[provider_teams.get(d.get(k)) for k in ['away_team_id','home_team_id']]
            g,reason=match(tids,utc(mile['start_date']),d.get('double_header_game_number'))
            if g:candidates.append((g,mile,mrid,mptr))
        unique={g['official_game_id'] for g,_,_,_ in candidates}
        if len(unique)!=1:
            issues.append(dict(provider='kalshi',market_id=ticker,event_id=eid,reason='No unique completed official game from source milestone',candidate_native_ids=sorted(unique),request_id=rid));continue
        g,mile,mrid,mptr=candidates[0];tid=provider_teams.get((m.get('custom_strike') or {}).get('baseball_team'))
        if tid not in g['official_team_ids']:
            issues.append(dict(provider='kalshi',market_id=ticker,reason='YES outcome team identity is not uniquely established',request_id=rid));continue
        side=g['official_team_ids'].index(tid);winner_flags=g['winner_flags'];expected='yes' if winner_flags[side] is True else 'no' if winner_flags[1-side] is True else None
        if m.get('result') in ['yes','no'] and expected and m['result']!=expected:
            issues.append(dict(provider='kalshi',market_id=ticker,official_game_id=g['official_game_id'],reason='Market settlement disagrees after official identity match',official_winner=g['teams'][winner_flags.index(True)],market_result=m['result'],request_id=rid));continue
        gid=canonical(g);native_games[gid]=g;game_sources[gid].add('kalshi')
        contracts.append(dict(provider='kalshi',game_id=gid,official_game_id=g['official_game_id'],side=side,contract_id=ticker,market_id=ticker,event_id=eid,series='KXMLBGAME',open=m['open_time'],close=m['close_time'],settled=m.get('settlement_ts'),request_id=rid,pointer=ptr,condition_id=None,outcome=m.get('yes_sub_title'),source_milestone_id=mile['id'],source_start_utc=mile['start_date'],identity_request_id=mrid,official_schedule_request_id=g['request_id']))
    for eid,(e,rid,ptr) in data['polymarket_events'].items():
        if str(rs[rid]['parameters'].get('tag_id'))!='100381':continue
        for mi,m in enumerate(e.get('markets',[])):
            if m.get('sportsMarketType')!='moneyline':continue
            text=' '.join(str(m.get(k) or '') for k in ['question','slug','groupItemTitle'])
            if re.search(r'\b(?:first|1st|2nd|3rd|4th|5th|five|5)\s*[- ]?innings?\b',text,re.I):
                issues.append(dict(provider='polymarket',market_id=m['id'],reason='Partial-inning winner market excluded from full-game table',request_id=rid));continue
            labels=array(m.get('outcomes',[]));tokens=array(m.get('clobTokenIds',[]));values=array(m.get('outcomePrices',[]));start=utc(m.get('gameStartTime') or e.get('startTime'))
            if labels==['Yes','No'] and re.search(r'home runs|home run derby|winning margin|doubleheader.*sweep',m.get('question',''),re.I):
                issues.append(dict(provider='polymarket',market_id=m['id'],reason='Excluded non-game-winner market: player award, derby, margin or two-game sweep',request_id=rid));continue
            if len(labels)!=2 or len(tokens)!=2 or len(set(tokens))!=2:
                issues.append(dict(provider='polymarket',market_id=m['id'],reason='Not two distinct mapped team outcomes',request_id=rid));continue
            # These three source labels omit an 'l'; the same original market
            # question explicitly names "PHI Phillies". This is a documented
            # correction scoped to exact market IDs, not fuzzy team matching.
            typo=m['id'] in ['531710','531722','532682'] and 'PHI Phillies' in m.get('question','')
            mapping_labels=['Phillies' if typo and s=='Philies' else s for s in labels]
            sets=[aliases[clean(s)] for s in mapping_labels]
            if any(len(s)!=1 for s in sets):
                issues.append(dict(provider='polymarket',market_id=m['id'],reason='Outcome labels do not uniquely map to official teams',outcomes=labels,request_id=rid));continue
            tids=[next(iter(s)) for s in sets];ordinal=re.search(r'(?:game|g)[- ]?([12])\b',text,re.I);g,reason=match(tids,start,int(ordinal[1]) if ordinal else None)
            if not g:
                issues.append(dict(provider='polymarket',market_id=m['id'],reason=reason,source_start_utc=start.isoformat() if start else None,outcomes=labels,request_id=rid));continue
            order=[g['official_team_ids'].index(t) for t in tids];val=[float(v) for v in values] if len(values)==2 else []
            if m.get('umaResolutionStatus')=='resolved' and val==[.5,.5] and not (g['scores'][0]==g['scores'][1] and True not in g['winner_flags']):
                issues.append(dict(provider='polymarket',market_id=m['id'],official_game_id=g['official_game_id'],reason='Voided/split-resolution contract excluded from two-team game-winner features',request_id=rid));continue
            if sorted(val)==[0.,1.] and True in g['winner_flags'] and order[val.index(1.)]!=g['winner_flags'].index(True):
                issues.append(dict(provider='polymarket',market_id=m['id'],official_game_id=g['official_game_id'],reason='Market resolution disagrees after official identity match',request_id=rid));continue
            gid=canonical(g);native_games[gid]=g;game_sources[gid].add('polymarket')
            for i,token in enumerate(tokens):contracts.append(dict(provider='polymarket',game_id=gid,official_game_id=g['official_game_id'],side=order[i],contract_id=token,market_id=m['id'],event_id=eid,series=None,open=m.get('createdAt') or e.get('createdAt'),close=m.get('closedTime') or m.get('endDate'),settled=m.get('closedTime') or m.get('endDate'),request_id=rid,pointer=ptr+'/markets/'+str(mi),condition_id=m.get('conditionId'),outcome=labels[i],source_start_utc=start.isoformat(),official_schedule_request_id=g['request_id'],outcome_mapping_note='Source Philies typo corrected from PHI Phillies in this same market question' if mapping_labels[i]!=labels[i] else None))
    assert len({(c['provider'],c['contract_id']) for c in contracts})==len(contracts),'Repeated outcome contract'
    games=[]
    for gid,g in native_games.items():
        winners=[i for i,v in enumerate(g['winner_flags']) if v is True];assert len(winners)<=1
        games.append(dict(game_id=gid,league='MLB',game_type='Baseball',official_game_id=g['official_game_id'],date=g['official_date'],start=g['scheduled_start_utc'],start_basis='Official MLB scheduled start; first pitch overrides when verified',teams=g['teams'],team_ids=g['official_team_ids'],scores=g['scores'],winner=g['teams'][winners[0]] if winners else 'Draw' if g['scores'][0]==g['scores'][1] else None,home_away='Away;Home',location=g['venue'].get('name') if g['venue'] else None,city=None,season=g['season_year']+' '+g['competition_type'],competition_type=g['competition_type'],is_training=g['game_type_code'] in ['S','E'],provider_sources=sorted(game_sources[gid]),official_schedule_request_id=g['request_id'],validation_status='OFFICIAL_MLB_SCHEDULE_MATCHED',doubleheader_number=g['game_number']))
    for i,g in enumerate(games):
        old=previous.get(g['game_id'])
        if old and old['official_game_id']==g['official_game_id'] and old['teams']==g['teams'] and old['scores']==g['scores'] and old.get('start_basis')=='Official MLB first pitch':
            fresh={**old,**g}
            for key in ['start','start_basis','location','city','home_away','validation_status']:
                fresh[key]=old[key]
            games[i]=fresh
    for name,key,rows in [('_mlb_canonical_games','game_id',games),('_mlb_market_candidates','contract_id',contracts)]:
        db.execute('CREATE TABLE IF NOT EXISTS '+name+' (id TEXT PRIMARY KEY,body TEXT NOT NULL) STRICT');db.execute('DELETE FROM '+name);db.executemany('INSERT INTO '+name+' VALUES (?,?)',[(r[key],json.dumps(r)) for r in rows])
    db.execute('CREATE TABLE IF NOT EXISTS _mlb_market_matching_audit (body TEXT NOT NULL) STRICT');db.execute('DELETE FROM _mlb_market_matching_audit');db.executemany('INSERT INTO _mlb_market_matching_audit VALUES (?)',[(json.dumps(r),) for r in issues]);db.commit();db.close()
    result=dict(generated_at_utc=dt.datetime.now(dt.UTC).isoformat(),status='CANDIDATES_REQUIRE_PRICE_AND_FEED_VALIDATION',canonical_games=len(games),provider_contracts=dict(collections.Counter(c['provider'] for c in contracts)),earliest_game=min((g['date'] for g in games),default=None),latest_game=max((g['date'] for g in games),default=None),games_by_year=dict(collections.Counter(g['date'][:4] for g in games)),issues=dict(collections.Counter(x['reason'] for x in issues)))
    (ROOT/'reports/mlb_market_candidates.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))

if __name__=='__main__':main()
