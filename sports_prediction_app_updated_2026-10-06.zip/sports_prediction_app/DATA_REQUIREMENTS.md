# Data and model assets kept outside this source release

The source archive contains no real account information or datasets. Copy retained data through a private backup or another suitable data distribution process, keeping the original relative paths. Existing code retains the exact training recipes; a new source checkout alone does not reproduce the prepared installation's forecasts.

| Component | Existing local assets required |
| --- | --- |
| NBA | `final_models/nba/columns.json`, `final_models/nba/template.pkl`, and `final_models/history/` feature and observed player/team history tables |
| MLB | `final_models/mlb/columns.json`, `final_models/mlb/features.parquet`, retained fitted-model databases where used, and `final_models/history/` baseball history tables |
| Shared retained evidence | `final_models/sources/` and relevant official historical tables under `collected data/result/` used by feature reconstruction and data-dependent regression tests |
| NHL and soccer baselines | `collected data/result/nhl_soccer_iteration/retained_models/us_strategy_baselines/`, including the original hash manifest, model bundles, feature tables, and soccer confidence inputs |
| Prepared NHL/soccer history | `collected data/result/sports_live/` validated sports history and model artifacts, or all retained factual sources needed to rebuild them |
| Public collection evidence | Relevant official-source responses under `collected data/raw/` referenced by historical request records |

The NBA/MLB feature column JSON files are included as source metadata. Their datasets and fitted artifacts are excluded. For existing private installations, restore a consistent backup of the relevant research and public collection state rather than individual live SQLite files copied during writes.

Account secrets and state are separate: `polymarket_us.dpapi`, `sports_execution.sqlite` and its WAL/SHM files, account preferences, purchases, and private audit records must stay outside the source repository. Do not copy the current account database into a public example or fixture. New installations initialize their own local account state.

The Windows launch script expects its environment at `final_models/.venv/`; that environment is recreated from the dependency files. Runtime output paths are intentionally ignored by Git.
