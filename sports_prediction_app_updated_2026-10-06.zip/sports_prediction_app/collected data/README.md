# Use local storage

Run `../prepare_storage.ps1` from the project directory to initialize storage.
Collectors write original responses under `raw/` and normalized tables under
`result/`. The `data` junction points to this same directory for existing scripts.
Keep both together when moving the prepared project so SQL source references
continue to resolve. Query historical data using a date, league and provider.
