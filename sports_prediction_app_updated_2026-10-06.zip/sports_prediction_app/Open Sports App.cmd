@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0sports_app\launch.ps1"
